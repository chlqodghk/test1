package si.osi.dsig;

import iaik.asn1.ObjectID;
import iaik.x509.X509ExtensionInitException;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.Key;
import java.security.PublicKey;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.List;

import javax.xml.crypto.AlgorithmMethod;
import javax.xml.crypto.KeySelector;
import javax.xml.crypto.KeySelectorException;
import javax.xml.crypto.KeySelectorResult;
import javax.xml.crypto.MarshalException;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dom.DOMStructure;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.configuration.XMLConfiguration;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import si.osi.pki.exception.PkiErrorCode;
import si.osi.pki.exception.PkiErrorCodeString;
import si.osi.pki.servlet.EntPkiServletContext;

import com.entrust.toolkit.exceptions.CertificationException;
import com.entrust.toolkit.exceptions.CertificationRootException;
import com.entrust.toolkit.exceptions.RevocationException;
import com.entrust.toolkit.exceptions.UserFailureException;
import com.entrust.toolkit.x509.CertVerifier;

/**
 * Validates XMLDSig and return validation result (0 for OK or error code if
 * validation fails).
 * 
 * @author rudi.ponikvar@osi.si
 * @see exception.properties
 */
public class XMLDsigValidate {

	static Logger pkilog = Logger.getLogger(XMLDsigValidate.class.getName());
	
	private static boolean OFFICER_DSIG_VALIDATION = false;

	/**
	 * Validates XMLDSig (signature and signing cert validity for RM Officer DSig).
	 * Certificate is checked if Officer PKI CP OID is valid.
	 * <p>
	 * 
	 * @param xmldsig
	 *            XMLDsig to be validated.
	 * @return Status code (0 for OK or error code if validation fails).
	 * @see exception.properties
	 */
	public static int spkiOfficerDSigValidation(byte[] xmldsig){

		OFFICER_DSIG_VALIDATION = true;
		return spkiIFDigitalSignatureValidation(xmldsig);
	}
	
	/**
	 * Validates XMLDSig (signature and signing cert validity).
	 * <p>
	 * 
	 * @param xmldsig
	 *            XMLDsig to be validated.
	 * @return Status code (0 for OK or error code if validation fails).
	 * @see exception.properties
	 */
	public static int spkiIFDigitalSignatureValidation(byte[] xmldsig) {

		int status = 0;

		try {

			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			Document doc;

			InputStream is = new ByteArrayInputStream(xmldsig);
			doc = dbf.newDocumentBuilder().parse(is);

			NodeList nl = doc.getElementsByTagNameNS(XMLSignature.XMLNS, "Signature");
			if (nl.getLength() < 1) {
				pkilog.error(PkiErrorCode.XML_DSIG_NO_SIGNATURE_ERROR.getNumString() + ":"
						+ PkiErrorCodeString.Instance.getUserText(PkiErrorCode.XML_DSIG_NO_SIGNATURE_ERROR));
				return PkiErrorCode.XML_DSIG_NO_SIGNATURE_ERROR.getNumber();
			}

			// Validate cert
			if (isCertValid(getSignCert(doc))) {
				pkilog.debug("XMLDSig cert is valid");
			} else {
				pkilog.info("XMLDSig cert is NOT valid");
				return PkiErrorCode.PKI_CERT_VERIFY_ERROR.getNumber();
			}

			String providerName = System.getProperty("jsr105Provider", "org.jcp.xml.dsig.internal.dom.XMLDSigRI");
			XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM",
					new org.apache.jcp.xml.dsig.internal.dom.XMLDSigRI());
			// Create a DOMValidateContext and specify a KeyValue KeySelector
			// and document context
			DOMValidateContext valContext = new DOMValidateContext(new KeyValueKeySelector(), nl.item(0));

			// unmarshal the XMLSignature
			XMLSignature signature = fac.unmarshalXMLSignature(valContext);

			// Validate the XMLSignature
			boolean coreValidity = signature.validate(valContext);

			if (coreValidity == false) {
				pkilog.info("XML-DSig validation failed");
				status = PkiErrorCode.XML_DSIG_VALIDATE_ERROR.getNumber();
			} else {
				status = 0;
				pkilog.debug("XML-DSig validation passed");
			}

		} catch (Exception e) {
			e.printStackTrace();
			pkilog.error("XML-DSig validation exception: " + e.getMessage());
			return PkiErrorCode.XML_DSIG_ERROR.getNumber();
		}

		return status;
	}

	/**
	 * KeySelector which retrieves the public key out of the KeyValue element
	 * and returns it. NOTE: If the key algorithm doesn't match signature
	 * algorithm, then the public key will be ignored.
	 * 
	 */
	private static class KeyValueKeySelector extends KeySelector {
		public KeySelectorResult select(KeyInfo keyInfo, KeySelector.Purpose purpose, AlgorithmMethod method,
				XMLCryptoContext context) throws KeySelectorException {
			if (keyInfo == null) {
				throw new KeySelectorException("Null KeyInfo object!");
			}
			SignatureMethod sm = (SignatureMethod) method;
			List list = keyInfo.getContent();

			for (int i = 0; i < list.size(); i++) {
				XMLStructure xmlStructure = (XMLStructure) list.get(i);
				if (xmlStructure instanceof X509Data) {
					PublicKey pk = null;
					X509Data data = (X509Data) xmlStructure;
					for (Object o2 : data.getContent()) {
						if (o2 instanceof java.security.cert.X509Certificate) {
							X509Certificate cert = (X509Certificate) o2;
							pk = cert.getPublicKey();
						}
					}
					pkilog.debug("XMLDSig verification public key: " + pk.getAlgorithm());
					pkilog.debug("XMLDSig sign method: " + sm.getAlgorithm());
					// make sure algorithm is compatible with method
					if (algEquals(sm.getAlgorithm(), pk.getAlgorithm())) {
						return new SimpleKeySelectorResult(pk);
					}
				}
			}
			throw new KeySelectorException("No KeyValue element found!");
		}

		static boolean algEquals(String algURI, String algName) {
			if (algName.equalsIgnoreCase("DSA") && algURI.equalsIgnoreCase(SignatureMethod.DSA_SHA1)) {
				return true;
			} else if (algName.equalsIgnoreCase("RSA") && algURI.equalsIgnoreCase(SignatureMethod.RSA_SHA1)) {
				return true;
			} else if (algName.equalsIgnoreCase("RSA")
					&& algURI.equalsIgnoreCase("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256")) {
				return true;
			} else if (algName.equalsIgnoreCase("EC")
					&& algURI.equalsIgnoreCase("http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha256")) {
				return true;
			} else {
				return false;
			}
		}
	}

	private static class SimpleKeySelectorResult implements KeySelectorResult {
		private PublicKey pk;

		SimpleKeySelectorResult(PublicKey pk) {
			this.pk = pk;
		}

		public Key getKey() {
			return pk;
		}
	}

	private static X509Certificate getSignCert(Document doc) throws InstantiationException, IllegalAccessException,
			ClassNotFoundException, MarshalException {

		NodeList nl = doc.getElementsByTagNameNS(XMLSignature.XMLNS, "KeyInfo");
		if (nl.getLength() < 1) {
			pkilog.error(PkiErrorCode.XML_DSIG_NO_SIGNATURE_ERROR.getNumString() + ":"
					+ PkiErrorCodeString.Instance.getUserText(PkiErrorCode.XML_DSIG_NO_SIGNATURE_ERROR));
		}

		// String providerName = System.getProperty("jsr105Provider",
		// "org.jcp.xml.dsig.internal.dom.XMLDSigRI");
		// Java 1.5 workaround
		XMLSignatureFactory fac = XMLSignatureFactory.getInstance("DOM", new org.apache.jcp.xml.dsig.internal.dom.XMLDSigRI());

		KeyInfoFactory kif = fac.getKeyInfoFactory();

		KeyInfo ki = kif.unmarshalKeyInfo(new DOMStructure(nl.item(0)));
		List list = ki.getContent();

		X509Certificate cert = null;
		for (int i = 0; i < list.size(); i++) {
			XMLStructure xmlStructure = (XMLStructure) list.get(i);
			if (xmlStructure instanceof X509Data) {
				X509Data data = (X509Data) xmlStructure;
				for (Object o2 : data.getContent()) {
					if (o2 instanceof java.security.cert.X509Certificate) {
						cert = (X509Certificate) o2;
					}
				}
			}
		}

		return cert;

	}

	/**
	 * @param cert
	 * @return
	 */
	public static boolean isCertValid(X509Certificate cert) {
		
		XMLConfiguration pkiConfig = (XMLConfiguration) EntPkiServletContext.getServletContext().getAttribute("pkiConfig");

		try {

			CertVerifier certverifier = (CertVerifier) EntPkiServletContext.getServletContext().getAttribute(
					"entBaseCertVerifier");

			if (pkilog.isDebugEnabled()) {
				X509Certificate[] rootsOfTrust = certverifier.getRootsOfTrust();
				for (int i = 0; i < rootsOfTrust.length; i++) {
					pkilog.debug("XMLDSig tusted root: " + rootsOfTrust[i].getSubjectDN().getName());
				}
				pkilog.debug("CRL cache lifetime: "
						+ certverifier.getRevocationStore().getMemoryCRLCache().getCacheEntryLifetime());
			}

			if (OFFICER_DSIG_VALIDATION){
				String cpOID = pkiConfig.getString("xmldsig-officer-policy.certpolicy");
				boolean cp_require = pkiConfig.getBoolean("xmldsig-officer-policy.require_certpolicy", true);
				certverifier.getClientSettings().addAcceptablePolicy(new ObjectID(cpOID));
				certverifier.getClientSettings().setRequireExplicitPolicy(cp_require);
				
			} else {
				String cpOID = pkiConfig.getString("xmldsig-server-policy.certpolicy");
				boolean cp_require = pkiConfig.getBoolean("xmldsig-server-policy.require_certpolicy", true);
				certverifier.getClientSettings().addAcceptablePolicy(new ObjectID(cpOID));
				certverifier.getClientSettings().setRequireExplicitPolicy(cp_require);
				
			}
			
			X509Certificate[] validchain = certverifier.validate(new iaik.x509.X509Certificate(cert.getEncoded()));

			pkilog.debug("XMLDsig cert is valid: " + cert.getSubjectDN().getName() + ": " + cert.getSerialNumber().toString());

			for (int i = 0; i < validchain.length; i++) {
				pkilog.debug("XMLDsig cert chain: " + validchain[i].getSubjectDN().getName());
			}

		} catch (CertificationException e) {
			pkilog.error(e.toString());

			if (e instanceof CertificationRootException) {
				pkilog.error("Cert chain validation error: " + e.toString());
				return false;
			}

			if (e instanceof CertificationException) {
				pkilog.error("Cert validation error: " + e.toString());
				return false;
			}

			if ((e instanceof RevocationException)) {

				String errorcode = PkiErrorCode.PKI_CERT_REVOKED.getNumString();
				pkilog.error(errorcode + ": " + e.toString());

				try {
					pkilog.error("Revocation reason: " + ((RevocationException) e).getRevocationReason().getReasonCodeName());

				} catch (X509ExtensionInitException e1) {
					pkilog.error(e1.toString());

				}

				return false;
			}

		} catch (UserFailureException e) {
			pkilog.debug("PKI login error: " + e.toString());
			return true;
		} catch (CertificateEncodingException e) {
			pkilog.debug("Cert encoding error: " + e.toString());
			e.printStackTrace();
		} catch (CertificateException e) {
			pkilog.debug("Cert error: " + e.toString());
			e.printStackTrace();
		}

		return true;
	}

}