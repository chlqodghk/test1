package si.osi.dsig;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import si.osi.pki.exception.PkiErrorCode;
import si.osi.pki.servlet.XMLSignHSM;


public class XMLSignerP11 {
	
	private static final int TYPE_XML = 0;
	private static final int TYPE_STR = 1;
	
	static Logger pkilog = Logger.getLogger(XMLSignerP11.class.getName());

	/**
	 * Creates enveloped XML-DSig. 
	 * <p>
	 * XML structure received in as byte[] xml is signed with private key on HSM.
	 * HSM parameters are read from entrust-config.xml, section hsm-xmldsig.
	 * 
	 * @author rudi.ponikvar@osi.si
	 * 
	 * @param xmldata XML to be signed
	 * @return signedxml Returned Sting contains signed XML, or error code.
	 */
	private static String xmlsign (byte[] data, int data_type) {
		
		String signedxml = null;
		
		byte[] xmldata = null;
		
		XMLSignHSM.getInstance().lockSession();
		
		try {
			
			if ( data_type == XMLSignerP11.TYPE_STR ) {
				xmldata = buildRMDSigXML(data);
			} else {
				xmldata = data;
			}
			
			byte[] signedbytes = xmlByteSign(xmldata);
			signedxml = new String(signedbytes, "UTF-8");

		} catch (Exception e) {
			pkilog.error("XML-DSig exception: "+e.getMessage());
			return PkiErrorCode.XML_DSIG_ERROR.getNumString();
			
		} finally {
			XMLSignHSM.getInstance().unlockSession();
		}
		
		pkilog.debug("XML file signed");
		return signedxml;
	}
	
	
	

	/**
	 * Creates enveloped XML-DSig. 
	 * <p>
	 * XML structure received in as byte[] xml is signed with private key on HSM.
	 * HSM parameters are read from entrust-config.xml, section hsm-xmldsig.
	 * 
	 * @param xmldata XML to be signed
	 * @return signedxml Returned Sting contains signed XML, or error code.
	 */
	public static String spkiIFDigitalSignature (byte[] xmldata) {	
		return xmlsign(xmldata, XMLSignerP11.TYPE_XML);
	}
	
	
	/**
	 * Encodes input string as XML and creates enveloped XML-DSig. 
	 * <p>
	 * XML structure received in as byte[] xml is signed with private key on HSM.
	 * HSM parameters are read from entrust-config.xml, section hsm-xmldsig.
	 * 
	 * @param data String data to be signed
	 * @return signedxml Returned Sting contains signed XML, or error code.
	 * @throws TransformerException 
	 * @throws ParserConfigurationException 
	 * @throws UnsupportedEncodingException 
	 */
	public static String spkiIFRmStringDigitalSignature (String data) {	
		
		String result = "";
		
		try {
			result = xmlsign(data.getBytes("UTF8"), XMLSignerP11.TYPE_STR);
			
		} catch (UnsupportedEncodingException e) {
			// should never happen
			pkilog.error("Encoding error: ", e);
			
		}
		
		pkilog.debug("XML DSig result:");
		pkilog.debug("\n" + result);
		return result;
	}
	
	
	/**
	 * @param data	String to be included in a XMLDSig as <RMDSigData>
	 * @return		Constructed XML as String
	 * @throws ParserConfigurationException
	 * @throws TransformerException
	 */
	private static String buildRMDSigXML(String data) throws ParserConfigurationException, TransformerException {
		
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		
		Document doc = docBuilder.newDocument();
		Element rootElement = doc.createElement("root");
		doc.appendChild(rootElement);
		
		Element el = doc.createElement("RMDSigData");
		el.appendChild(doc.createTextNode(data));
		rootElement.appendChild(el);
		
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
		transformer.setOutputProperty(OutputKeys.METHOD, "xml");
	    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	    transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
	    transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "0");
	    
		StringWriter writer = new StringWriter();
		transformer.transform(new DOMSource(doc), new StreamResult(writer));
		String res = writer.getBuffer().toString();
			
		return res;
	}
	
	/**
	 * @param data	byte[] to be included in a XMLDSig as <RMDSigData>
	 * @return		Constructed XML as byte[]
	 * @throws ParserConfigurationException
	 * @throws TransformerException
	 * @throws UnsupportedEncodingException 
	 * @throws DOMException 
	 */
	private static byte[] buildRMDSigXML(byte[] data) throws ParserConfigurationException, TransformerException, DOMException, UnsupportedEncodingException {
		
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		
		Document doc = docBuilder.newDocument();
		Element rootElement = doc.createElement("root");
		doc.appendChild(rootElement);
		
		Element el = doc.createElement("RMDSigData");
		pkilog.debug("XMLDSig String input data:");
		pkilog.debug("\n"+new String(data, "UTF-8"));
		el.appendChild(doc.createCDATASection(new String(data, "UTF-8")));
//		el.appendChild(doc.createTextNode(new String(data, "UTF-8")));
		rootElement.appendChild(el);
	
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
		transformer.setOutputProperty(OutputKeys.METHOD, "xml");
	    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	    transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
	    transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "0");
	    
	    ByteArrayOutputStream bos=new ByteArrayOutputStream();
	    StreamResult result=new StreamResult(bos);
		transformer.transform(new DOMSource(doc), result);
		byte[] res =  bos.toByteArray();
		
		return res;
	}
	
	/**
	 * Implements XMLDSig.
	 *  
	 * @param xmldata
	 * @return
	 * @throws Exception
	 */
	private static byte[] xmlByteSign(byte[] xmldata) throws Exception {
		
		logXmlHeader(xmldata);
		
		byte[] signedbytes = null;
		
		PrivateKey dsigkey = XMLSignHSM.getInstance().getDsigkey();
		X509Certificate signcert = XMLSignHSM.getInstance().getSignercert();

//		String providerName = System.getProperty("jsr105Provider", "org.jcp.xml.dsig.internal.dom.XMLDSigRI");

		XMLSignatureFactory fac;
//		fac = XMLSignatureFactory.getInstance("DOM", (Provider) Class.forName(providerName).newInstance());
		/** Java 1.5 workaround */
		fac = XMLSignatureFactory.getInstance("DOM", new org.apache.jcp.xml.dsig.internal.dom.XMLDSigRI());

		SignedInfo si;
		try {
			Reference ref = fac.newReference("", fac.newDigestMethod(DigestMethod.SHA256, null),
					Collections.singletonList(fac.newTransform(Transform.ENVELOPED, (XMLStructure) null)), null, null);

			si = fac.newSignedInfo(
					fac.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE_WITH_COMMENTS, (XMLStructure) null),
					fac.newSignatureMethod("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256", null),
					Collections.singletonList(ref));

		} catch (InvalidAlgorithmParameterException ex) {
			throw new Exception("XML signing algorithm error", ex);
		} catch (NoSuchAlgorithmException ex) {
			throw new Exception("XML signing algorithm error", ex);
		}

		KeyInfoFactory kif = fac.getKeyInfoFactory();

		List X509Content = new LinkedList();
		X509Content.add(signcert.getSubjectDN().getName());
		X509Content.add(signcert);
		X509Data x509d = kif.newX509Data(X509Content);

		List<XMLStructure> kviItems = new LinkedList<XMLStructure>();
		kviItems.add(x509d);
		KeyInfo ki = kif.newKeyInfo(kviItems);

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		Document doc;

		InputStream is = new ByteArrayInputStream(xmldata);
		doc = dbf.newDocumentBuilder().parse(is);

		DOMSignContext dsc = new DOMSignContext(dsigkey, doc.getDocumentElement());
		dsc.setDefaultNamespacePrefix("ds");

		XMLSignature signature = fac.newXMLSignature(si, ki);
		signature.sign(dsc);

		ByteArrayOutputStream bout = new ByteArrayOutputStream();
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer trans = tf.newTransformer();
		trans.transform(new DOMSource(doc), new StreamResult(bout));

		signedbytes = bout.toByteArray();

		return signedbytes;

	} 
	
	
	/**
	 * Writes XML <Header> content to log
	 * 
	 * @param xmldata
	 * @throws Exception
	 */
	private static void logXmlHeader(byte[] xmldata) throws Exception {
		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		
		InputStream is = new ByteArrayInputStream(xmldata);
		Document doc = dBuilder.parse(is);
		
		NodeList nList = doc.getElementsByTagName("Header");

		for (int temp = 0; temp < nList.getLength(); temp++) {

			Node nNode = nList.item(temp);

			if (nNode.getNodeType() == Node.ELEMENT_NODE) {

				Element e = (Element) nNode;
				
				NodeList hList = e.getChildNodes();

				for (int i=0; i < hList.getLength(); i++) {
					Node hNode = hList.item(i);
					if (hNode.getNodeType() == Node.ELEMENT_NODE) {
					pkilog.info("XMLDSig file header: " +hNode.getNodeName() + ">" + hNode.getTextContent());
					}
				}

			}
		}
	}
    
}
