package si.osi.pki.officer;

import iaik.asn1.ObjectID;
import iaik.x509.X509Certificate;
import iaik.x509.X509ExtensionInitException;

import org.apache.commons.configuration.XMLConfiguration;
import org.apache.log4j.Logger;
import org.bouncycastle.asn1.DERUTF8String;
import org.bouncycastle.asn1.x500.AttributeTypeAndValue;
import org.bouncycastle.asn1.x500.RDN;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x500.style.RFC4519Style;

import si.osi.pki.exception.PkiErrorCode;
import si.osi.pki.servlet.EntPkiServletContext;

import com.entrust.toolkit.exceptions.CertificationException;
import com.entrust.toolkit.exceptions.CertificationRootException;
import com.entrust.toolkit.exceptions.RevocationException;
import com.entrust.toolkit.exceptions.UserFailureException;
import com.entrust.toolkit.x509.CertVerifier;

public class OfficerCertLogin {
	
	Logger pkilog = Logger.getLogger(OfficerCertLogin.class.getName());

//	javax.security.cert.X509Certificate
	public String doCertVerify(java.security.cert.X509Certificate xcert) {
		
		X509Certificate cert = null;
		try {
			cert = new X509Certificate(xcert.getEncoded());
			
		} catch (Exception e) {
			pkilog.error(e.toString());
			
		} 
		return this.doCertVerify(cert);
		
	}
	
	/**
	 * Officer login certificate verification.
	 * 
	 * Method verifies, if certificate is issued by the trusted CA, if is revoked, if policy is acceptable.
	 * 
	 * @param cert		X509Certificate to be validated.
	 * @return 			Status code. If certificate is valid, status "0" and userid in a form "0:userid". 
	 * 					Error code if cert validation fails.
	 * @see	exception.properties
	 */
	public String doCertVerify(X509Certificate cert) {
		
		String status = "-1";
//		AtkContext atkContext = (AtkContext) EntPkiServletContext
//				.getServletContext().getAttribute("atkcntxt");
		
		XMLConfiguration pkiConfig = (XMLConfiguration) EntPkiServletContext.getServletContext().getAttribute("pkiConfig");
		String cpOID = pkiConfig.getString("login-policy.certpolicy");
		boolean cp_require = pkiConfig.getBoolean("login-policy.require_certpolicy", true);
		
		try {
			
			if (cert == null) {
				throw new UserFailureException("Input cert in null.");
			}

			CertVerifier certverifier = (CertVerifier) EntPkiServletContext.getServletContext().getAttribute("entBaseCertVerifier");
			
			certverifier.getClientSettings().addAcceptablePolicy(new ObjectID(cpOID));
			certverifier.getClientSettings().setRequireExplicitPolicy(cp_require);
			certverifier.getClientSettings().setInhibitAnyPolicy(true);
						
			pkilog.info("Officer login cert received: "+cert.getSubjectDN().getName());

			X509Certificate[] validchain = certverifier.validate(cert);
			
			status =  "0:"+getDnUid(cert.getSubjectDN().getName());

			pkilog.info("Officer login cert is valid: "+cert.getSubjectDN().getName()+": "+cert.getSerialNumber().toString());
			for (int i=0; i < validchain.length; i++)  {
				pkilog.debug("Officer cert chain: "+validchain[i].getSubjectDN().getName());
			}

			
		} catch (CertificationException e) {
			pkilog.error(e.toString());
			Exception ex = e.getInnerException();
			if (ex != null){
				pkilog.error(e.getInnerException().toString());
			}
			
			
			if ((e instanceof RevocationException)) {
				String errorcode = PkiErrorCode.PKI_CERT_REVOKED.getNumString();
				pkilog.error(errorcode+": "+e.toString());
				try {
					pkilog.error("Revocation reason: "+ ((RevocationException) e).getRevocationReason().getReasonCodeName());
					
				} catch (X509ExtensionInitException e1) {
					pkilog.error(e1.toString());
					return  PkiErrorCode.PKI_CERT_VERIFY_ERROR.getNumString();
					
				}
				
				return errorcode;
				
			} else if (e instanceof CertificationRootException) {
				String errorcode = PkiErrorCode.PKI_CERT_NOT_TRUSTED.getNumString();
				pkilog.error(errorcode+": "+e.toString());
				return  errorcode;
				
			} 
		} catch (UserFailureException e) {
			pkilog.error(e.toString());
			return  PkiErrorCode.PKI_CERT_VERIFY_ERROR.getNumString();
		} 
		return status;
		
	}
	
	
	/**
	 * Extract UID from X509Certificate Subject (DN).
	 * 
	 * @param dn
	 * @return		User ID as encoded in the cert DN (RFC4519Style UID)
	 */
	private String getDnUid(String dn) {

		String uid = null;

		X500Name dnName = new X500Name(dn);

		RDN[] rdns = dnName.getRDNs(RFC4519Style.uid);
		for (int i = 0; i < rdns.length; i++) {
			
			AttributeTypeAndValue[] avs = rdns[i].getTypesAndValues();
			
			for (int j = 0; j < avs.length; j++) {
				if (avs[j].getType().getId().equalsIgnoreCase(RFC4519Style.uid.getId())) {
					pkilog.debug("cert rdn type: " + avs[j].getType().getId());
					pkilog.debug("cert rdn value: " + ((DERUTF8String) avs[j].getValue().toASN1Primitive()).getString());
					uid = ((DERUTF8String) avs[j].getValue().toASN1Primitive()).getString();
				}

			}
		}
		
		return uid;
	}
	

	/**
     * Instance of OfficerCertLogin
     */
    public static OfficerCertLogin Instance = new OfficerCertLogin();
}
