package si.osi.pki.servlet;

import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.Security;
import java.security.UnrecoverableKeyException;
import java.security.cert.X509Certificate;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.configuration.XMLConfiguration;
import org.apache.log4j.Logger;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

/**
 * Class holds global parameters of HSM used for XML-DSig.
 * It is called during Servlet Context initialization.
 * Class should not be called directly.
 * 
 * @author rudi.ponikvar@osi.si
 * @see EntPkiServletContext
 *
 */
public class XMLSignHSM {

	private PrivateKey dsigkey;
	private X509Certificate cacert;
	private X509Certificate rootcert;
	private X509Certificate signercert;
	
	private Logger pkilog = Logger.getLogger(XMLSignHSM.class.getName());
	
	private final Lock lock = new ReentrantLock();
	
	// private constructor for singleton
	private XMLSignHSM() {
	}
	
	/**
	 * Singleton holder inner class.
	 *
	 */
	private static class SingletonHolder {
		public static final XMLSignHSM INSTANCE = new XMLSignHSM();
	}
	
	/**
	 * Class instance
	 */
	public static XMLSignHSM getInstance() {
		return SingletonHolder.INSTANCE;
	}
	

	public void init() throws KeyStoreException, UnrecoverableKeyException, NoSuchAlgorithmException {
		
		XMLConfiguration pkiConfig = (XMLConfiguration) EntPkiServletContext.getServletContext().getAttribute("pkiConfig");
		
		String configFileName = pkiConfig.getString("hsm-xmldsig.p11-cfg-file");		
		Provider p = new sun.security.pkcs11.SunPKCS11(configFileName);
		Security.addProvider(p);
		
		pkilog.info("XMLSignHSM Sun P11 provider: " + p.getInfo());
		pkilog.info("XMLSignHSM Sun P11 provider: " + p.toString());
		
		StringBuffer pinsb = new StringBuffer(pkiConfig.getString("hsm-xmldsig.slot-pin"));
		KeyStore.PasswordProtection pp = new KeyStore.PasswordProtection(pinsb.toString().toCharArray());
		pinsb.setLength(0);
		
		KeyStore.Builder builder = KeyStore.Builder.newInstance("PKCS11", p, pp);
		KeyStore store = builder.getKeyStore();
		
		String keyAlias = pkiConfig.getString("hsm-xmldsig.key-alias");
		X509Certificate[] certChain = (X509Certificate[]) store.getCertificateChain(keyAlias);
		pkilog.debug("XMLDSig key alias: " + keyAlias);
		pkilog.debug("keystore chain lenth: " + certChain.length);
		for (int i=0; i<certChain.length; i++) 
		{
			pkilog.info("XML signer chain cert "+i+": "+certChain[i].getSubjectDN().getName());
			if (i==0) {
				signercert = certChain[i];
			} else if (i==1) {
				cacert = certChain[i];
			} else if (i==2) {
				rootcert = certChain[i];
			}
		}
        
		dsigkey = (PrivateKey) store.getKey(keyAlias, pp.getPassword());
        
	}
	
	
	public PrivateKey getDsigkey() {
		return dsigkey;
	}


	public X509Certificate getCacert() {
		return cacert;
	}


	public X509Certificate getSignercert() {
		return signercert;
	}

	
	public X509Certificate getRootcert() {
		return rootcert;
	}


	private List<X509Certificate> getCertChain(X509Certificate signcert) {
		
		List<X509Certificate> x509CertChain = new LinkedList<X509Certificate>();
		x509CertChain.add(signcert);
		
		return x509CertChain;
	}
	
    /**
     * Locks the HSM session - only one crypto operation at the time per session is allowed
     * 
     * @param slotname  name of the slot
     */
    public void lockSession()
    {
        lock.lock();
    }
    
    /**
     * Unlock the HSM session
     */
    public void unlockSession()
    {
        lock.unlock();        
    }
}
