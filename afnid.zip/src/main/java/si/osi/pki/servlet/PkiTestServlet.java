package si.osi.pki.servlet;

import iaik.x509.X509Certificate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.security.cert.CertificateException;

import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import si.osi.dsig.XMLDsigValidate;
import si.osi.dsig.XMLSignerP11;
import si.osi.pki.officer.OfficerCertLogin;

/**
 * This servelt is used only for ad-hoc devel testing. It will be deleted from the production version.
 * Servlet reads user data from hard-coded file or parameter and performs requested operation.
 * <p>
 * NOTE: Servelt and/or methods shall not be called from production code.
 * 
 * @author rudi.ponikvar@osi.si
 * 
 */
public class PkiTestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Logger pkilog = Logger.getLogger(PkiTestServlet.class.getName());

	// Sample calls
	// URL: http://127.0.0.1:8080/AF.RM.PKI.Wrapper/PkiTestServlet?action=officerLogin
	// URL: http://127.0.0.1:8080/AF.RM.PKI.Wrapper/PkiTestServlet?action=xmldsig

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PkiTestServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Do not use. For testing only.
	 * 
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setCharacterEncoding("UTF8");
		PrintWriter out = response.getWriter();
		String queryString = request.getQueryString();

		// AtkContext atkcntxt = (AtkContext)
		// EntPkiServletContext.getServletContext().getAttribute("atkcntxt");
		// pkilog.debug("test serverlt sm context: " + atkcntxt.toString());
		// out.println(atkcntxt.toString());
		// out.println(request.getQueryString());
		// out.println(PkiOpDummy.doPkiOpDummy());

		if (queryString.equalsIgnoreCase("action=officerLogin")) {
			doOfficerCertVerify(out);
		} else if (queryString.equalsIgnoreCase("user=officer")) {
			// doOfficer(out);
		} else if (queryString.equalsIgnoreCase("action=verifycertxml")) {
			doCertVerify(out);
		} else if (queryString.equalsIgnoreCase("action=signinfo")) {
			doListSignInfo(out);
		} else if (queryString.equalsIgnoreCase("action=xmldsig")) {
			doXMLDsig(out);
		} else if (queryString.equalsIgnoreCase("action=xmldsigvalidate")) {
			doXMLDsigValidate(out);
		} else if (queryString.equalsIgnoreCase("action=doXMLDsigValidateCert")) {
			doXMLDsigValidateCert(out);
		} else {
			out.println("unknown request: " + queryString);
		}

		out.close();

	}

	/**
	 * Do not use. For testing only.
	 * 
	 * @param out
	 */
	private void doListSignInfo(PrintWriter out) {
		out.println("sign cert: " + XMLSignHSM.getInstance().getSignercert().getSubjectDN().getName());
		out.println("\nsign key: " + XMLSignHSM.getInstance().getDsigkey().getAlgorithm());
		out.close();
	}

	/**
	 * Do not use. For testing only.
	 * 
	 * @param out
	 */
	private void doXMLDsigValidateCert(PrintWriter out) {

		try {

			File file = new File("d:/razvoj/af.rm.wrapper/data/TestXMLSigner.pem.crt");
			InputStream is = new FileInputStream(file);
			X509Certificate cert = new X509Certificate(is);

			out.println("XLDSig cert isValid: " + XMLDsigValidate.isCertValid(cert));

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CertificateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Do not use. For testing only.
	 * 
	 * @param out
	 */
	private void doXMLDsigValidate(PrintWriter out) {

		try {
//			File file = new File("d:/razvoj/af.rm.wrapper/data/RM_XMLDSig_StringData.xml");
			File file = new File("d:/razvoj/af.rm.wrapper/data/0100000_201306051038_01_DSig.xml");
			FileInputStream fin = new FileInputStream(file);
			byte[] fileContent = new byte[(int) file.length()];
			fin.read(fileContent);
			// fin.close();
			out.println("XMLDSig file size: " + fileContent.length);

			int status = XMLDsigValidate.spkiIFDigitalSignatureValidation(fileContent);
			out.println("XMLDSig validate status: " + status);
			out.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Do not use. For testing only.
	 * 
	 * @param out
	 */
	private void doXMLDsig(PrintWriter out) {

		try {
			File file = new File("d:/razvoj/af.rm.wrapper/data/0100000_201306051038_01.xml");
//			File file = new File("d:/razvoj/af.rm.wrapper/data/RM_XMLDSig_StringData.txt");
			FileInputStream fin = new FileInputStream(file);
			byte fileContent[] = new byte[(int) file.length()];
			fin.read(fileContent);

			// byte[] dsig = XMLSignerP11.sign(fileContent);
			// String dsig = XMLSignerP11.xmlsign(fileContent);
			// String dsig = XMLSignerP11.spkiIFDigitalSignature(new
			// String(fileContent, "UTF8"));

//			String dsig = XMLSignerP11.spkiIFRmStringDigitalSignature(new String(fileContent, "UTF8"));
			 String dsig = XMLSignerP11.spkiIFDigitalSignature(fileContent);

//			FileOutputStream fos = new FileOutputStream(new File("d:/razvoj/af.rm.wrapper/data/RM_XMLDSig_StringData.xml"));
			FileOutputStream fos = new FileOutputStream(new File("d:/razvoj/af.rm.wrapper/data/0100000_201306051038_01_DSig.xml"));
			fos.write(dsig.getBytes("UTF8"));
			fos.close();

			out.println(dsig);
			out.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Do not use. For testing only.
	 * 
	 * @param out
	 */
	private void doCertVerify(PrintWriter out) {

		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

			File inFile = new File("d:/razvoj/af.rm.wrapper/data/cert_validate.xml");

			Document doc = dBuilder.parse(inFile);

			NodeList nList = doc.getElementsByTagName("cert");

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element e = (Element) nNode;
					String fileName = e.getElementsByTagName("file").item(0).getTextContent();

					InputStream is = new FileInputStream(fileName);

					X509Certificate cert = new X509Certificate(is);

					String rv = OfficerCertLogin.Instance.doCertVerify(cert);
					out.println(rv);
					out.close();

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Do not use. For testing only.
	 * 
	 * @param out
	 */
	private void doOfficerCertVerify(PrintWriter out) {

		// pkilog.debug("context test data: "+ TestObject.Instance.getData());

		try {

			File inFile = new File("d:/razvoj/af.rm.wrapper/data/Officer01_valid_cp.crt");
			// File inFile = new
			// File("d:/razvoj/af.rm.wrapper/data/Officer01_revoked.crt");

			InputStream is = new FileInputStream(inFile);

			X509Certificate cert = new X509Certificate(is);

			String rv = OfficerCertLogin.Instance.doCertVerify(cert);
			out.println(rv);
			out.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
