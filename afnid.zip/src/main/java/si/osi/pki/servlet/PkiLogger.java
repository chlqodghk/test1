package si.osi.pki.servlet;

import java.io.File;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.PropertyConfigurator;

/**
 * Internal Logger implementation.
 * 
 * @author rudi.ponikvar@osi.si
 * @see Log4j
 * 
 */
public class PkiLogger {

	/**
	 * Initializes log4j
	 * 
	 * @param config
	 */
	public static void initPkiLogger(String config) {

		if (config == null) {
			System.err.println("*** No log4j-properties init param, so initializing log4j with BasicConfigurator");
			BasicConfigurator.configure();
		} else {
			File logConfigFile = new File(config);
			if (logConfigFile.exists()) {
				System.out.println("Initializing log4j with: " + config);
				PropertyConfigurator.configure(config);
			} else {
				System.err.println("*** " + config + " file not found, so initializing log4j with BasicConfigurator");
				BasicConfigurator.configure();
			}
		}

	}

}
