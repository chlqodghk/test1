package si.osi.pki.servlet;

import iaik.x509.X509Certificate;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;

import javax.naming.NamingException;

import org.apache.commons.configuration.XMLConfiguration;
import org.apache.log4j.Logger;

import com.entrust.toolkit.exceptions.CertificationRootException;
import com.entrust.toolkit.exceptions.UserFailureException;
import com.entrust.toolkit.exceptions.UserNotLoggedInException;
import com.entrust.toolkit.x509.CertVerifier;
import com.entrust.toolkit.x509.directory.JNDIDirectory;
import com.entrust.toolkit.x509.policies.ClientSettings;
import com.entrust.toolkit.x509.revocation.CollectionRS;
import com.entrust.toolkit.x509.revocation.DirectoryCRLRS;
import com.entrust.toolkit.x509.revocation.HttpCRLRS;

public class EntBaseCertVerifier {

	static Logger pkilog = Logger.getLogger(EntBaseCertVerifier.class.getName());
	
	/**
	 * Configures Entrust CertVerifier based on parameters in entrust-config.xml.
	 * Class should not be called directly. It is used to configure CertVerifier at start time.
	 * 
	 * @return		CertVerifier object
	 * @throws UserFailureException
	 * @throws UserNotLoggedInException
	 * @throws CertificateEncodingException
	 * @throws CertificationRootException
	 * @throws FileNotFoundException
	 * @throws CertificateException
	 * @throws IOException
	 * @throws NamingException
	 */
	public static CertVerifier setCertVerifier() throws UserFailureException, UserNotLoggedInException, CertificateEncodingException, CertificationRootException, FileNotFoundException, CertificateException, IOException, NamingException {
					
		XMLConfiguration pkiConfig = (XMLConfiguration) EntPkiServletContext.getServletContext().getAttribute("pkiConfig");
			
		X509Certificate[] rootsOfTrust = loadCATrustList(pkiConfig);
		
		String ldap_url = pkiConfig.getString("cert-verify.ldap_url", null);
		pkilog.debug("cert-verify.ldap_url: " + ldap_url.length());
		JNDIDirectory ldap = null;

		if ( ! (ldap_url.length() == 0 | ldap_url == null) ) {
			ldap = new JNDIDirectory(ldap_url);
		}
		
		CertVerifier certverifier = new CertVerifier(rootsOfTrust, ldap, new ClientSettings());
		
		boolean requireCRL = pkiConfig.getBoolean("cert-verify.require_crl", true);
		certverifier.getRevocationStore().requireCRL(requireCRL);
			
		CollectionRS collectionRS = certverifier.getRevocationStore();
		
		HttpCRLRS httpRS = new HttpCRLRS(certverifier);
		httpRS.enableOfflineLookup(true);
		collectionRS.attach(httpRS);
		
		DirectoryCRLRS ldapRS = new DirectoryCRLRS(certverifier);
		ldapRS.enableOfflineLookup(true);
		collectionRS.attach(ldapRS);
		
		CollectionRS revocationStoreCollection = certverifier.getRevocationStore();
		long crlLifetime = pkiConfig.getLong("cert-verify.crl_cache_lifetime", 120000);
		revocationStoreCollection.getMemoryCRLCache().setCacheEntryLifetime(crlLifetime);
		pkilog.debug("Officer login CRL cache entry lifetime: "+revocationStoreCollection.getMemoryCRLCache().getCacheEntryLifetime());
		
		return certverifier;
		
	}
	
	
	/**
	 * Builds and returns CA trust list with CA certificates defined in a entrust-config.xml.
	 *  
	 * @param pkiConfig	Apache XMLConfiguration object
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws CertificateException
	 * @throws CertificateEncodingException
	 * @throws CertificationRootException
	 */
	private static X509Certificate[] loadCATrustList(XMLConfiguration pkiConfig) throws FileNotFoundException, IOException,
			CertificateException, CertificateEncodingException, CertificationRootException {
		
		X509Certificate[] ca_trust_list;
		
		X509Certificate ca_cert = null;
		InputStream fis = null;
		
		try {
			
			// load trusted ca certs
			String[] ca_files = pkiConfig.getStringArray("xmldsig-trust-list.cacert-file");
			
			ca_trust_list = new X509Certificate[ca_files.length];

			for (int i = 0; i < ca_files.length; i++) {
				
				pkilog.debug("Loading CA cert from file: " + ca_files[i]);
				fis = new FileInputStream(ca_files[i]);
				
				ca_cert = new X509Certificate(fis);	
				ca_trust_list[i] = new X509Certificate(ca_cert.getEncoded());		
				pkilog.info("CA cert added to verification trust list: " + ca_cert.getSubjectDN().getName());
				
				fis.close();
			}
			
		} finally {
			if (fis != null) {
				fis.close();
			}
		}
		
		return ca_trust_list;
	}
	
	
	
	
	/**
	 * Instance of PkiCertVerifier
	 */
	public static EntBaseCertVerifier Instance = new EntBaseCertVerifier();
}
