package si.osi.pki.servlet;

import java.security.Security;
import java.security.cert.X509Certificate;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.log4j.Logger;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import com.entrust.toolkit.security.provider.Initializer;
import com.entrust.toolkit.x509.CertVerifier;

/**
 * @author rudi.ponikvar@osi.si
 * 
 * Application Life-cycle Listener implementation class EntPkiServletContext
 *
 */

public class EntPkiServletContext implements ServletContextListener {
	
	static ServletContext cntxt;
	static Logger pkilog;

    /**
     * Default constructor. 
     */
    public EntPkiServletContext() {}

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent c) {

		cntxt = c.getServletContext();

		System.out.println("EntPkiServletContext is initializing log4j");
		String log4jConfig = cntxt.getInitParameter("log4j-properties");
		PkiLogger.initPkiLogger(log4jConfig);

		pkilog = Logger.getLogger(EntPkiServletContext.class.getName());
		pkilog.info("EntPkiServletContext log4j initialized");

		pkilog.info("PKI wrapper Entrust configuration file: "
				+ cntxt.getInitParameter("entrust_config"));


		try {
			
			Security.addProvider(new BouncyCastleProvider());
			
			Initializer.getInstance().setProviders(Initializer.MODE_NORMAL);
			pkilog.info("Entrust provider initialized");
			
//			Load xml config object from config file as defined in web.xml
			XMLConfiguration pkiConfig = this.getConfig(cntxt.getInitParameter("entrust_config"));
			cntxt.setAttribute("pkiConfig", pkiConfig);
	
			CertVerifier certverifier = EntBaseCertVerifier.setCertVerifier();
			cntxt.setAttribute("entBaseCertVerifier", certverifier);
			
			X509Certificate[] rootsOfTrust = certverifier.getRootsOfTrust();
			for (int i=0; i < rootsOfTrust.length; i++)  {
				pkilog.debug("Tusted CA: "+rootsOfTrust[i].getSubjectDN().getName());
			}
		
			// Initialize XML Signer HSM key and cert
			XMLSignHSM.getInstance().init();
			
			pkilog.info("EntPkiServletContext contextInitialized");
			
		} catch (Exception e) {
			e.printStackTrace();
			pkilog.error("EntPkiServletContext: " + e);
			throw new RuntimeException("EntPkiServletContext: " + e.getMessage(), e);
		}

	}

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent arg0) {}
    
    public static ServletContext getServletContext() {
    	return cntxt;
    }
    
	/**
	 * Returns XMLConfiguration object
	 * @param config_file
	 * @return config XMLConfiguration
	 * @throws ConfigurationException
	 * @see org.apache.commons.configuration.XMLConfiguration
	 */
	private XMLConfiguration getConfig(String config_file) throws ConfigurationException {
		pkilog.info("loading citizen profile configuration from file: "+ config_file);
		XMLConfiguration config = new XMLConfiguration(config_file);
		return config;		
	}
	
}
