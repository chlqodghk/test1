package si.osi.pki.exception;

public enum PkiErrorCode implements PkiErrorCodeIf {
	
	PKI_GENERAL_ERROR(-1),
	PKI_CONFIG_LOAD_ERROR(1000),
	PKI_CERT_REVOKED(1010),
	PKI_CERT_NOT_TRUSTED(1020),
	PKI_CERT_VERIFY_ERROR(1030),
	ENT_EPF_LOGIN_ERROR(2000),
	PKI_USER_NOT_FOUND(2100),
	PKI_USER_STATE_INCORRECT(2010),
	ENT_ATK_QUEUE(2300),
	ENT_ATK_ERROR(3000),
	ENT_XAP_ERROR(3001),
	ENT_XAP_KEY_UPDATE_ERROR(3011),
	ENT_XAP_MSG_ERROR(3004),
	XML_DSIG_ERROR(4000),
	XML_DSIG_VALIDATE_ERROR(4010),
	XML_DSIG_NO_SIGNATURE_ERROR(4020),
	SYSTEM_ERROR(9000);
	
	
	private final int number;
	
	private PkiErrorCode(int number) {
		this.number = number;
	}

	public int getNumber() {
		// TODO Auto-generated method stub
		return number;
	}
	

	public String getNumString() {
		return new Integer(number).toString();
	}

}
