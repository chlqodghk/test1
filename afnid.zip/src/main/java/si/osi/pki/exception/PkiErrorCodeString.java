package si.osi.pki.exception;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author rudi.ponikvar@osi.si
 *
 */
public class PkiErrorCodeString {

	Properties props = new Properties();
	InputStream inputStream = this.getClass().getResourceAsStream("exception.properties");
	
    /**
     * @param errorCode
     * @return errorString
     * @throws IOException
     */
    public String getUserText(PkiErrorCode errorCode) {
        if (errorCode == null) {
            return null;
        }
        
        try {
			props.load(inputStream);
		} catch (Exception e) {	
			e.printStackTrace();
			return null;
		}
        String key = errorCode.toString();
        return props.getProperty(key);
        
    }
    
	public void instance() {
		
	}
	
	
    /**
     * Instance of SMConfig
     */
    public static PkiErrorCodeString Instance = new PkiErrorCodeString();
	
}
