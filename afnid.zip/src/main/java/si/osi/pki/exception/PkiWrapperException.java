package si.osi.pki.exception;


public class PkiWrapperException extends Exception {

	/**
	 * 
	 */
	public PkiWrapperException() {

	}

	/**
	 * @param message contains int error code
	 */
	public PkiWrapperException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public PkiWrapperException(Throwable cause) {
		super(cause);

	}

	/**
	 * @param message
	 * @param cause
	 */
	public PkiWrapperException(String message, Throwable cause) {
		super(message, cause);

	}

}
