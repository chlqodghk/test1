package si.osi.pki.exception;

/**
 * @author rudi.ponikvar@osi.si
 *
 */
public interface PkiErrorCodeIf {
	int getNumber();
}
