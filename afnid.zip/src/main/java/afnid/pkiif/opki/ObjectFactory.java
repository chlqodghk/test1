
package afnid.pkiif.opki;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the afnid.pkiif.opki package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _OpkiIFmailChangeResponse_QNAME = new QName("http://servlet.pki.osi.si/", "opkiIFmailChangeResponse");
    private final static QName _OpkiIFaccountRevocationResponse_QNAME = new QName("http://servlet.pki.osi.si/", "opkiIFaccountRevocationResponse");
    private final static QName _OpkiIFcertRevokeReissue_QNAME = new QName("http://servlet.pki.osi.si/", "opkiIFcertRevokeReissue");
    private final static QName _OpkiIFcerUnHold_QNAME = new QName("http://servlet.pki.osi.si/", "opkiIFcerUnHold");
    private final static QName _OpkiIFcertRevokeReissueResponse_QNAME = new QName("http://servlet.pki.osi.si/", "opkiIFcertRevokeReissueResponse");
    private final static QName _OpkiIfRegisterAccount_QNAME = new QName("http://servlet.pki.osi.si/", "opkiIfRegisterAccount");
    private final static QName _OpkiIFmailChange_QNAME = new QName("http://servlet.pki.osi.si/", "opkiIFmailChange");
    private final static QName _OpkiIFcertHoldResponse_QNAME = new QName("http://servlet.pki.osi.si/", "opkiIFcertHoldResponse");
    private final static QName _OpkiIFaccountChange_QNAME = new QName("http://servlet.pki.osi.si/", "opkiIFaccountChange");
    private final static QName _OpkiIFcertHold_QNAME = new QName("http://servlet.pki.osi.si/", "opkiIFcertHold");
    private final static QName _OpkiIFaccountChangeResponse_QNAME = new QName("http://servlet.pki.osi.si/", "opkiIFaccountChangeResponse");
    private final static QName _OpkiIFcerUnHoldResponse_QNAME = new QName("http://servlet.pki.osi.si/", "opkiIFcerUnHoldResponse");
    private final static QName _OpkiIfRegisterAccountResponse_QNAME = new QName("http://servlet.pki.osi.si/", "opkiIfRegisterAccountResponse");
    private final static QName _OpkiIFaccountRevocation_QNAME = new QName("http://servlet.pki.osi.si/", "opkiIFaccountRevocation");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: afnid.pkiif.opki
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link OpkiIFcertHoldResponse }
     * 
     */
    public OpkiIFcertHoldResponse createOpkiIFcertHoldResponse() {
        return new OpkiIFcertHoldResponse();
    }

    /**
     * Create an instance of {@link OpkiIFaccountChange }
     * 
     */
    public OpkiIFaccountChange createOpkiIFaccountChange() {
        return new OpkiIFaccountChange();
    }

    /**
     * Create an instance of {@link OpkiIFcertHold }
     * 
     */
    public OpkiIFcertHold createOpkiIFcertHold() {
        return new OpkiIFcertHold();
    }

    /**
     * Create an instance of {@link OpkiIFaccountChangeResponse }
     * 
     */
    public OpkiIFaccountChangeResponse createOpkiIFaccountChangeResponse() {
        return new OpkiIFaccountChangeResponse();
    }

    /**
     * Create an instance of {@link OpkiIFcerUnHoldResponse }
     * 
     */
    public OpkiIFcerUnHoldResponse createOpkiIFcerUnHoldResponse() {
        return new OpkiIFcerUnHoldResponse();
    }

    /**
     * Create an instance of {@link OpkiIfRegisterAccountResponse }
     * 
     */
    public OpkiIfRegisterAccountResponse createOpkiIfRegisterAccountResponse() {
        return new OpkiIfRegisterAccountResponse();
    }

    /**
     * Create an instance of {@link OpkiIFaccountRevocation }
     * 
     */
    public OpkiIFaccountRevocation createOpkiIFaccountRevocation() {
        return new OpkiIFaccountRevocation();
    }

    /**
     * Create an instance of {@link OpkiIFmailChangeResponse }
     * 
     */
    public OpkiIFmailChangeResponse createOpkiIFmailChangeResponse() {
        return new OpkiIFmailChangeResponse();
    }

    /**
     * Create an instance of {@link OpkiIFaccountRevocationResponse }
     * 
     */
    public OpkiIFaccountRevocationResponse createOpkiIFaccountRevocationResponse() {
        return new OpkiIFaccountRevocationResponse();
    }

    /**
     * Create an instance of {@link OpkiIFcertRevokeReissue }
     * 
     */
    public OpkiIFcertRevokeReissue createOpkiIFcertRevokeReissue() {
        return new OpkiIFcertRevokeReissue();
    }

    /**
     * Create an instance of {@link OpkiIFcerUnHold }
     * 
     */
    public OpkiIFcerUnHold createOpkiIFcerUnHold() {
        return new OpkiIFcerUnHold();
    }

    /**
     * Create an instance of {@link OpkiIfRegisterAccount }
     * 
     */
    public OpkiIfRegisterAccount createOpkiIfRegisterAccount() {
        return new OpkiIfRegisterAccount();
    }

    /**
     * Create an instance of {@link OpkiIFcertRevokeReissueResponse }
     * 
     */
    public OpkiIFcertRevokeReissueResponse createOpkiIFcertRevokeReissueResponse() {
        return new OpkiIFcertRevokeReissueResponse();
    }

    /**
     * Create an instance of {@link OpkiIFmailChange }
     * 
     */
    public OpkiIFmailChange createOpkiIFmailChange() {
        return new OpkiIFmailChange();
    }

    /**
     * Create an instance of {@link PkiRsWsResponse }
     * 
     */
    public PkiRsWsResponse createPkiRsWsResponse() {
        return new PkiRsWsResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpkiIFmailChangeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "opkiIFmailChangeResponse")
    public JAXBElement<OpkiIFmailChangeResponse> createOpkiIFmailChangeResponse(OpkiIFmailChangeResponse value) {
        return new JAXBElement<OpkiIFmailChangeResponse>(_OpkiIFmailChangeResponse_QNAME, OpkiIFmailChangeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpkiIFaccountRevocationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "opkiIFaccountRevocationResponse")
    public JAXBElement<OpkiIFaccountRevocationResponse> createOpkiIFaccountRevocationResponse(OpkiIFaccountRevocationResponse value) {
        return new JAXBElement<OpkiIFaccountRevocationResponse>(_OpkiIFaccountRevocationResponse_QNAME, OpkiIFaccountRevocationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpkiIFcertRevokeReissue }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "opkiIFcertRevokeReissue")
    public JAXBElement<OpkiIFcertRevokeReissue> createOpkiIFcertRevokeReissue(OpkiIFcertRevokeReissue value) {
        return new JAXBElement<OpkiIFcertRevokeReissue>(_OpkiIFcertRevokeReissue_QNAME, OpkiIFcertRevokeReissue.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpkiIFcerUnHold }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "opkiIFcerUnHold")
    public JAXBElement<OpkiIFcerUnHold> createOpkiIFcerUnHold(OpkiIFcerUnHold value) {
        return new JAXBElement<OpkiIFcerUnHold>(_OpkiIFcerUnHold_QNAME, OpkiIFcerUnHold.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpkiIFcertRevokeReissueResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "opkiIFcertRevokeReissueResponse")
    public JAXBElement<OpkiIFcertRevokeReissueResponse> createOpkiIFcertRevokeReissueResponse(OpkiIFcertRevokeReissueResponse value) {
        return new JAXBElement<OpkiIFcertRevokeReissueResponse>(_OpkiIFcertRevokeReissueResponse_QNAME, OpkiIFcertRevokeReissueResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpkiIfRegisterAccount }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "opkiIfRegisterAccount")
    public JAXBElement<OpkiIfRegisterAccount> createOpkiIfRegisterAccount(OpkiIfRegisterAccount value) {
        return new JAXBElement<OpkiIfRegisterAccount>(_OpkiIfRegisterAccount_QNAME, OpkiIfRegisterAccount.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpkiIFmailChange }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "opkiIFmailChange")
    public JAXBElement<OpkiIFmailChange> createOpkiIFmailChange(OpkiIFmailChange value) {
        return new JAXBElement<OpkiIFmailChange>(_OpkiIFmailChange_QNAME, OpkiIFmailChange.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpkiIFcertHoldResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "opkiIFcertHoldResponse")
    public JAXBElement<OpkiIFcertHoldResponse> createOpkiIFcertHoldResponse(OpkiIFcertHoldResponse value) {
        return new JAXBElement<OpkiIFcertHoldResponse>(_OpkiIFcertHoldResponse_QNAME, OpkiIFcertHoldResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpkiIFaccountChange }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "opkiIFaccountChange")
    public JAXBElement<OpkiIFaccountChange> createOpkiIFaccountChange(OpkiIFaccountChange value) {
        return new JAXBElement<OpkiIFaccountChange>(_OpkiIFaccountChange_QNAME, OpkiIFaccountChange.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpkiIFcertHold }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "opkiIFcertHold")
    public JAXBElement<OpkiIFcertHold> createOpkiIFcertHold(OpkiIFcertHold value) {
        return new JAXBElement<OpkiIFcertHold>(_OpkiIFcertHold_QNAME, OpkiIFcertHold.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpkiIFaccountChangeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "opkiIFaccountChangeResponse")
    public JAXBElement<OpkiIFaccountChangeResponse> createOpkiIFaccountChangeResponse(OpkiIFaccountChangeResponse value) {
        return new JAXBElement<OpkiIFaccountChangeResponse>(_OpkiIFaccountChangeResponse_QNAME, OpkiIFaccountChangeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpkiIFcerUnHoldResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "opkiIFcerUnHoldResponse")
    public JAXBElement<OpkiIFcerUnHoldResponse> createOpkiIFcerUnHoldResponse(OpkiIFcerUnHoldResponse value) {
        return new JAXBElement<OpkiIFcerUnHoldResponse>(_OpkiIFcerUnHoldResponse_QNAME, OpkiIFcerUnHoldResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpkiIfRegisterAccountResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "opkiIfRegisterAccountResponse")
    public JAXBElement<OpkiIfRegisterAccountResponse> createOpkiIfRegisterAccountResponse(OpkiIfRegisterAccountResponse value) {
        return new JAXBElement<OpkiIfRegisterAccountResponse>(_OpkiIfRegisterAccountResponse_QNAME, OpkiIfRegisterAccountResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OpkiIFaccountRevocation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "opkiIFaccountRevocation")
    public JAXBElement<OpkiIFaccountRevocation> createOpkiIFaccountRevocation(OpkiIFaccountRevocation value) {
        return new JAXBElement<OpkiIFaccountRevocation>(_OpkiIFaccountRevocation_QNAME, OpkiIFaccountRevocation.class, null, value);
    }

}
