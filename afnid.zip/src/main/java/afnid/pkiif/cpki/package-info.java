@javax.xml.bind.annotation.XmlSchema(namespace = "http://servlet.pki.osi.si/")
package afnid.pkiif.cpki;
