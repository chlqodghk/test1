
package afnid.pkiif.cpki;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the afnid.pkiif.cpki package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CpkiIFcertRevocationResponse_QNAME = new QName("http://servlet.pki.osi.si/", "cpkiIFcertRevocationResponse");
    private final static QName _CpkiIFaccountRevocation_QNAME = new QName("http://servlet.pki.osi.si/", "cpkiIFaccountRevocation");
    private final static QName _CpkiIFcertUnHoldResponse_QNAME = new QName("http://servlet.pki.osi.si/", "cpkiIFcertUnHoldResponse");
    private final static QName _CpkiIFaccountCitizenReactivate_QNAME = new QName("http://servlet.pki.osi.si/", "cpkiIFaccountCitizenReactivate");
    private final static QName _CpkiIFcertRevocation_QNAME = new QName("http://servlet.pki.osi.si/", "cpkiIFcertRevocation");
    private final static QName _CpkiIFcertUnHold_QNAME = new QName("http://servlet.pki.osi.si/", "cpkiIFcertUnHold");
    private final static QName _CpkiIFcertHold_QNAME = new QName("http://servlet.pki.osi.si/", "cpkiIFcertHold");
    private final static QName _CpkiIFaccountRevocationResponse_QNAME = new QName("http://servlet.pki.osi.si/", "cpkiIFaccountRevocationResponse");
    private final static QName _CpkiIFaccountCitizenReactivateResponse_QNAME = new QName("http://servlet.pki.osi.si/", "cpkiIFaccountCitizenReactivateResponse");
    private final static QName _CpkiIFcertHoldResponse_QNAME = new QName("http://servlet.pki.osi.si/", "cpkiIFcertHoldResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: afnid.pkiif.cpki
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CpkiIFaccountRevocation }
     * 
     */
    public CpkiIFaccountRevocation createCpkiIFaccountRevocation() {
        return new CpkiIFaccountRevocation();
    }

    /**
     * Create an instance of {@link CpkiIFcertRevocationResponse }
     * 
     */
    public CpkiIFcertRevocationResponse createCpkiIFcertRevocationResponse() {
        return new CpkiIFcertRevocationResponse();
    }

    /**
     * Create an instance of {@link CpkiIFaccountCitizenReactivate }
     * 
     */
    public CpkiIFaccountCitizenReactivate createCpkiIFaccountCitizenReactivate() {
        return new CpkiIFaccountCitizenReactivate();
    }

    /**
     * Create an instance of {@link CpkiIFcertUnHoldResponse }
     * 
     */
    public CpkiIFcertUnHoldResponse createCpkiIFcertUnHoldResponse() {
        return new CpkiIFcertUnHoldResponse();
    }

    /**
     * Create an instance of {@link CpkiIFcertUnHold }
     * 
     */
    public CpkiIFcertUnHold createCpkiIFcertUnHold() {
        return new CpkiIFcertUnHold();
    }

    /**
     * Create an instance of {@link CpkiIFcertRevocation }
     * 
     */
    public CpkiIFcertRevocation createCpkiIFcertRevocation() {
        return new CpkiIFcertRevocation();
    }

    /**
     * Create an instance of {@link CpkiIFaccountRevocationResponse }
     * 
     */
    public CpkiIFaccountRevocationResponse createCpkiIFaccountRevocationResponse() {
        return new CpkiIFaccountRevocationResponse();
    }

    /**
     * Create an instance of {@link CpkiIFcertHold }
     * 
     */
    public CpkiIFcertHold createCpkiIFcertHold() {
        return new CpkiIFcertHold();
    }

    /**
     * Create an instance of {@link CpkiIFcertHoldResponse }
     * 
     */
    public CpkiIFcertHoldResponse createCpkiIFcertHoldResponse() {
        return new CpkiIFcertHoldResponse();
    }

    /**
     * Create an instance of {@link CpkiIFaccountCitizenReactivateResponse }
     * 
     */
    public CpkiIFaccountCitizenReactivateResponse createCpkiIFaccountCitizenReactivateResponse() {
        return new CpkiIFaccountCitizenReactivateResponse();
    }

    /**
     * Create an instance of {@link PkiRsWsResponse }
     * 
     */
    public PkiRsWsResponse createPkiRsWsResponse() {
        return new PkiRsWsResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CpkiIFcertRevocationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "cpkiIFcertRevocationResponse")
    public JAXBElement<CpkiIFcertRevocationResponse> createCpkiIFcertRevocationResponse(CpkiIFcertRevocationResponse value) {
        return new JAXBElement<CpkiIFcertRevocationResponse>(_CpkiIFcertRevocationResponse_QNAME, CpkiIFcertRevocationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CpkiIFaccountRevocation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "cpkiIFaccountRevocation")
    public JAXBElement<CpkiIFaccountRevocation> createCpkiIFaccountRevocation(CpkiIFaccountRevocation value) {
        return new JAXBElement<CpkiIFaccountRevocation>(_CpkiIFaccountRevocation_QNAME, CpkiIFaccountRevocation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CpkiIFcertUnHoldResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "cpkiIFcertUnHoldResponse")
    public JAXBElement<CpkiIFcertUnHoldResponse> createCpkiIFcertUnHoldResponse(CpkiIFcertUnHoldResponse value) {
        return new JAXBElement<CpkiIFcertUnHoldResponse>(_CpkiIFcertUnHoldResponse_QNAME, CpkiIFcertUnHoldResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CpkiIFaccountCitizenReactivate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "cpkiIFaccountCitizenReactivate")
    public JAXBElement<CpkiIFaccountCitizenReactivate> createCpkiIFaccountCitizenReactivate(CpkiIFaccountCitizenReactivate value) {
        return new JAXBElement<CpkiIFaccountCitizenReactivate>(_CpkiIFaccountCitizenReactivate_QNAME, CpkiIFaccountCitizenReactivate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CpkiIFcertRevocation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "cpkiIFcertRevocation")
    public JAXBElement<CpkiIFcertRevocation> createCpkiIFcertRevocation(CpkiIFcertRevocation value) {
        return new JAXBElement<CpkiIFcertRevocation>(_CpkiIFcertRevocation_QNAME, CpkiIFcertRevocation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CpkiIFcertUnHold }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "cpkiIFcertUnHold")
    public JAXBElement<CpkiIFcertUnHold> createCpkiIFcertUnHold(CpkiIFcertUnHold value) {
        return new JAXBElement<CpkiIFcertUnHold>(_CpkiIFcertUnHold_QNAME, CpkiIFcertUnHold.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CpkiIFcertHold }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "cpkiIFcertHold")
    public JAXBElement<CpkiIFcertHold> createCpkiIFcertHold(CpkiIFcertHold value) {
        return new JAXBElement<CpkiIFcertHold>(_CpkiIFcertHold_QNAME, CpkiIFcertHold.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CpkiIFaccountRevocationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "cpkiIFaccountRevocationResponse")
    public JAXBElement<CpkiIFaccountRevocationResponse> createCpkiIFaccountRevocationResponse(CpkiIFaccountRevocationResponse value) {
        return new JAXBElement<CpkiIFaccountRevocationResponse>(_CpkiIFaccountRevocationResponse_QNAME, CpkiIFaccountRevocationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CpkiIFaccountCitizenReactivateResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "cpkiIFaccountCitizenReactivateResponse")
    public JAXBElement<CpkiIFaccountCitizenReactivateResponse> createCpkiIFaccountCitizenReactivateResponse(CpkiIFaccountCitizenReactivateResponse value) {
        return new JAXBElement<CpkiIFaccountCitizenReactivateResponse>(_CpkiIFaccountCitizenReactivateResponse_QNAME, CpkiIFaccountCitizenReactivateResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CpkiIFcertHoldResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servlet.pki.osi.si/", name = "cpkiIFcertHoldResponse")
    public JAXBElement<CpkiIFcertHoldResponse> createCpkiIFcertHoldResponse(CpkiIFcertHoldResponse value) {
        return new JAXBElement<CpkiIFcertHoldResponse>(_CpkiIFcertHoldResponse_QNAME, CpkiIFcertHoldResponse.class, null, value);
    }

}
