
package afnid.pkiif.ccm;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the afnid.pkiif.ccm package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CardKillChangePrintedSequenceNo_QNAME = new QName("http://ws.afga.apida/", "CardKillChangePrintedSequenceNo");
    private final static QName _CardKillChangePrintedSequenceNoResponse_QNAME = new QName("http://ws.afga.apida/", "CardKillChangePrintedSequenceNoResponse");
    private final static QName _CardKillRequestResponse_QNAME = new QName("http://ws.afga.apida/", "CardKillRequestResponse");
    private final static QName _RegisterCardChangesResponse_QNAME = new QName("http://ws.afga.apida/", "registerCardChangesResponse");
    private final static QName _CardKillRequest_QNAME = new QName("http://ws.afga.apida/", "CardKillRequest");
    private final static QName _CardKillResult_QNAME = new QName("http://ws.afga.apida/", "CardKillResult");
    private final static QName _CardKillResultResponse_QNAME = new QName("http://ws.afga.apida/", "CardKillResultResponse");
    private final static QName _RegisterCardChanges_QNAME = new QName("http://ws.afga.apida/", "registerCardChanges");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: afnid.pkiif.ccm
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RegisterCardChanges }
     * 
     */
    public RegisterCardChanges createRegisterCardChanges() {
        return new RegisterCardChanges();
    }

    /**
     * Create an instance of {@link CardKillResultResponse }
     * 
     */
    public CardKillResultResponse createCardKillResultResponse() {
        return new CardKillResultResponse();
    }

    /**
     * Create an instance of {@link CardKillResult }
     * 
     */
    public CardKillResult createCardKillResult() {
        return new CardKillResult();
    }

    /**
     * Create an instance of {@link CardKillRequest }
     * 
     */
    public CardKillRequest createCardKillRequest() {
        return new CardKillRequest();
    }

    /**
     * Create an instance of {@link RegisterCardChangesResponse }
     * 
     */
    public RegisterCardChangesResponse createRegisterCardChangesResponse() {
        return new RegisterCardChangesResponse();
    }

    /**
     * Create an instance of {@link CardKillRequestResponse }
     * 
     */
    public CardKillRequestResponse createCardKillRequestResponse() {
        return new CardKillRequestResponse();
    }

    /**
     * Create an instance of {@link CardKillChangePrintedSequenceNoResponse }
     * 
     */
    public CardKillChangePrintedSequenceNoResponse createCardKillChangePrintedSequenceNoResponse() {
        return new CardKillChangePrintedSequenceNoResponse();
    }

    /**
     * Create an instance of {@link CardKillChangePrintedSequenceNo }
     * 
     */
    public CardKillChangePrintedSequenceNo createCardKillChangePrintedSequenceNo() {
        return new CardKillChangePrintedSequenceNo();
    }

    /**
     * Create an instance of {@link CardKillResultInput }
     * 
     */
    public CardKillResultInput createCardKillResultInput() {
        return new CardKillResultInput();
    }

    /**
     * Create an instance of {@link CardKillResultOutput }
     * 
     */
    public CardKillResultOutput createCardKillResultOutput() {
        return new CardKillResultOutput();
    }

    /**
     * Create an instance of {@link CardKillRequestInput }
     * 
     */
    public CardKillRequestInput createCardKillRequestInput() {
        return new CardKillRequestInput();
    }

    /**
     * Create an instance of {@link CardKillRequestOutput }
     * 
     */
    public CardKillRequestOutput createCardKillRequestOutput() {
        return new CardKillRequestOutput();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CardKillChangePrintedSequenceNo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.afga.apida/", name = "CardKillChangePrintedSequenceNo")
    public JAXBElement<CardKillChangePrintedSequenceNo> createCardKillChangePrintedSequenceNo(CardKillChangePrintedSequenceNo value) {
        return new JAXBElement<CardKillChangePrintedSequenceNo>(_CardKillChangePrintedSequenceNo_QNAME, CardKillChangePrintedSequenceNo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CardKillChangePrintedSequenceNoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.afga.apida/", name = "CardKillChangePrintedSequenceNoResponse")
    public JAXBElement<CardKillChangePrintedSequenceNoResponse> createCardKillChangePrintedSequenceNoResponse(CardKillChangePrintedSequenceNoResponse value) {
        return new JAXBElement<CardKillChangePrintedSequenceNoResponse>(_CardKillChangePrintedSequenceNoResponse_QNAME, CardKillChangePrintedSequenceNoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CardKillRequestResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.afga.apida/", name = "CardKillRequestResponse")
    public JAXBElement<CardKillRequestResponse> createCardKillRequestResponse(CardKillRequestResponse value) {
        return new JAXBElement<CardKillRequestResponse>(_CardKillRequestResponse_QNAME, CardKillRequestResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegisterCardChangesResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.afga.apida/", name = "registerCardChangesResponse")
    public JAXBElement<RegisterCardChangesResponse> createRegisterCardChangesResponse(RegisterCardChangesResponse value) {
        return new JAXBElement<RegisterCardChangesResponse>(_RegisterCardChangesResponse_QNAME, RegisterCardChangesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CardKillRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.afga.apida/", name = "CardKillRequest")
    public JAXBElement<CardKillRequest> createCardKillRequest(CardKillRequest value) {
        return new JAXBElement<CardKillRequest>(_CardKillRequest_QNAME, CardKillRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CardKillResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.afga.apida/", name = "CardKillResult")
    public JAXBElement<CardKillResult> createCardKillResult(CardKillResult value) {
        return new JAXBElement<CardKillResult>(_CardKillResult_QNAME, CardKillResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CardKillResultResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.afga.apida/", name = "CardKillResultResponse")
    public JAXBElement<CardKillResultResponse> createCardKillResultResponse(CardKillResultResponse value) {
        return new JAXBElement<CardKillResultResponse>(_CardKillResultResponse_QNAME, CardKillResultResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegisterCardChanges }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.afga.apida/", name = "registerCardChanges")
    public JAXBElement<RegisterCardChanges> createRegisterCardChanges(RegisterCardChanges value) {
        return new JAXBElement<RegisterCardChanges>(_RegisterCardChanges_QNAME, RegisterCardChanges.class, null, value);
    }

}
