
package afnid.pkiif.ccm;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for cardKillRequestInput complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="cardKillRequestInput">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="requestType" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="reportNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="eNID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cardIssuanceDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lastIssuanceSequenceNo" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="printedIssuanceSequenceNo" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cardKillRequestInput", propOrder = {
    "requestType",
    "reportNumber",
    "enid",
    "cardIssuanceDate",
    "lastIssuanceSequenceNo",
    "printedIssuanceSequenceNo"
})
public class CardKillRequestInput {

    protected int requestType;
    protected String reportNumber;
    @XmlElement(name = "eNID")
    protected String enid;
    protected String cardIssuanceDate;
    protected int lastIssuanceSequenceNo;
    protected int printedIssuanceSequenceNo;

    /**
     * Gets the value of the requestType property.
     * 
     */
    public int getRequestType() {
        return requestType;
    }

    /**
     * Sets the value of the requestType property.
     * 
     */
    public void setRequestType(int value) {
        this.requestType = value;
    }

    /**
     * Gets the value of the reportNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReportNumber() {
        return reportNumber;
    }

    /**
     * Sets the value of the reportNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReportNumber(String value) {
        this.reportNumber = value;
    }

    /**
     * Gets the value of the enid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getENID() {
        return enid;
    }

    /**
     * Sets the value of the enid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setENID(String value) {
        this.enid = value;
    }

    /**
     * Gets the value of the cardIssuanceDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardIssuanceDate() {
        return cardIssuanceDate;
    }

    /**
     * Sets the value of the cardIssuanceDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardIssuanceDate(String value) {
        this.cardIssuanceDate = value;
    }

    /**
     * Gets the value of the lastIssuanceSequenceNo property.
     * 
     */
    public int getLastIssuanceSequenceNo() {
        return lastIssuanceSequenceNo;
    }

    /**
     * Sets the value of the lastIssuanceSequenceNo property.
     * 
     */
    public void setLastIssuanceSequenceNo(int value) {
        this.lastIssuanceSequenceNo = value;
    }

    /**
     * Gets the value of the printedIssuanceSequenceNo property.
     * 
     */
    public int getPrintedIssuanceSequenceNo() {
        return printedIssuanceSequenceNo;
    }

    /**
     * Sets the value of the printedIssuanceSequenceNo property.
     * 
     */
    public void setPrintedIssuanceSequenceNo(int value) {
        this.printedIssuanceSequenceNo = value;
    }

}
