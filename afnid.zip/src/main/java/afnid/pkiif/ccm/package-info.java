@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.afga.apida/")
package afnid.pkiif.ccm;
