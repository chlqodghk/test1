/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package afnid.cm;

import java.text.MessageFormat;

import javax.annotation.Resource;

import egovframework.rte.ptl.mvc.tags.ui.pagination.AbstractPaginationRenderer;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/**
 * @Class Name : ImagePaginationRenderer.java
 * @Description : ImagePaginationRenderer Class
 * @Modification Information @ @ Modified modifier modification @ --------- ---------
 *               ------------------------------- @ 2009.03.16 The first generation
 * 
 * @author The execution environment large team development framework
 * @since 2009. 03.16
 * @version 1.0
 * @see Copyright (C) by MOPAS All right reserved.
 */
public class NidImgPaginationRenderer extends AbstractPaginationRenderer {

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
	
	/**
	 * PaginationRenderer
	 * 
	 * @see The execution environment large team development framework
	 */
	public NidImgPaginationRenderer() {
		
		firstPageLabel = "<a tabindex=\"2003\" href=\"#\" onclick=\"{0}({1}); return false;\"><span class=\"font10\" >" +">> " + "</span></a>&#160;";
		previousPageLabel = "<a tabindex=\"2004\" href=\"#\" onclick=\"{0}({1}); return false;\"><span class=\"font10\">" + " > " + "</span></a>&#160;";
		currentPageLabel = "<span tabindex=\"{0}\" class=\"black bold\" style=\"font-size:14px;font-weight: bold;\" >{1}</span>&#160;";
		otherPageLabel = "<a tabindex=\"{0}\" href=\"#\" onclick=\"{1}({2}); return false;\">{3}</a>&#160;";
		nextPageLabel = "<a tabindex=\"2099\" href=\"#\" onclick=\"{0}({1}); return false;\"><span class=\"font10\">" + " < " + "</span></a>&#160;";
		lastPageLabel = "<a tabindex=\"2100\" href=\"#\" onclick=\"{0}({1}); return false;\"><span class=\"font10\">" + " << " + "</span></a>&#160;";

	}
	
	/**
     * Generated page navigation. <br>
     * 
     * @param paginationInfo Value-object of board to be parsed request(PaginationInfo)
     * @param jsFunction Value-object of board to be parsed request(String)
     * @return String string object 
     */
	@Override
	public String renderPagination(PaginationInfo paginationInfo, String jsFunction) {
		StringBuffer strBuff = new StringBuffer();

		int firstPageNo = paginationInfo.getFirstPageNo();
		int firstPageNoOnPageList = paginationInfo.getFirstPageNoOnPageList();
		int totalPageCount = paginationInfo.getTotalPageCount();
		int pageSize = paginationInfo.getPageSize();
		int lastPageNoOnPageList = paginationInfo.getLastPageNoOnPageList();
		int currentPageNo = paginationInfo.getCurrentPageNo();
		int lastPageNo = paginationInfo.getLastPageNo();
		
		strBuff.append("<table class=\"table_p\">");
	    strBuff.append("<colgroup>");
		strBuff.append("<col width=\"25%\" />");
		strBuff.append("<col width=\"50%\" />");
		strBuff.append("<col width=\"25%\" />");					
	    strBuff.append("</colgroup>");
		strBuff.append("<tr>");
		strBuff.append("<td>&nbsp;</td>");
		strBuff.append("<td>");
		strBuff.append("<span class=\"black\">");
		
		int nidGoPage = 0;
		
		if (totalPageCount > pageSize) {
			if (lastPageNoOnPageList < totalPageCount) {
				strBuff.append(MessageFormat.format(lastPageLabel, new Object[] { jsFunction, Integer.toString(lastPageNo) }));
				strBuff.append(MessageFormat.format(nextPageLabel, new Object[] { jsFunction, Integer.toString(firstPageNoOnPageList + pageSize) }));
			} else {
				strBuff.append(MessageFormat.format(lastPageLabel, new Object[] { jsFunction, Integer.toString(lastPageNo) }));
				strBuff.append(MessageFormat.format(nextPageLabel, new Object[] { jsFunction, Integer.toString(lastPageNo) }));
			}
		}
		
		int tabOrder = 0;
		
		for (int i = lastPageNoOnPageList; i >= firstPageNoOnPageList; i--) {
			if (i == currentPageNo) {
				strBuff.append(MessageFormat.format(currentPageLabel, getPageLabel(tabOrder, i)  ));
				nidGoPage = i;
			} else {
				strBuff.append(MessageFormat.format(otherPageLabel, getPageLabel(tabOrder, jsFunction,i) ));
			}
			tabOrder = tabOrder +1;
		}

		if (totalPageCount > pageSize) {
			if (firstPageNoOnPageList > pageSize) {
				strBuff.append(MessageFormat.format(previousPageLabel, new Object[] { jsFunction, Integer.toString(firstPageNoOnPageList - 1) }));
				strBuff.append(MessageFormat.format(firstPageLabel, new Object[] { jsFunction, Integer.toString(firstPageNo) }));
			} else {
				strBuff.append(MessageFormat.format(previousPageLabel, new Object[] { jsFunction, Integer.toString(firstPageNo) }));
				strBuff.append(MessageFormat.format(firstPageLabel, new Object[] { jsFunction, Integer.toString(firstPageNo) }));
			}
		}
		
		int limit = String.valueOf(lastPageNo).length();
		strBuff.append("</span>");
		strBuff.append("</td>");
		strBuff.append("<td class=\"tr pr_15\">");
		strBuff.append("<input name=\"nidGoPage\" tabindex=\"2002\" tabindex=\"\"id=\"nidGoPage\" value=\""+nidGoPage+"\" maxlength=\""+limit+"\" onkeydown=\"return fn_chk_no(event);\" type=\"text\" class=\"w_60\" /> ");
		strBuff.append("<input name=\"Button1\"  tabindex=\"2001\" class=\"blue_btn\" type=\"button\" onclick=\""+jsFunction+"(this.form.nidGoPage.value);\" value=\""+nidMessageSource.getMessage("goPage")+"\" />");
		strBuff.append("</td>");
		strBuff.append("</tr>");
		strBuff.append("</table>");
		
		return strBuff.toString();
	}
	
	/**
     * Page generated label. <br>
     * 
     * @param i Value-object of board to be parsed request(int)
     * @return Object
     */
	private Object[] getPageLabel(int tabOrder, int i){
		return new Object[] { Integer.toString(2014-tabOrder), Integer.toString(i)};
	}
	
	/**
     * Page generated label. <br>
     * 
     * @param jsFunction Value-object of board to be parsed request(String)
     * @param i Value-object of board to be parsed request(int)
     * @return Object 
     */
	private Object[] getPageLabel(int tabOrder, String jsFunction, int i){
		return new Object[] { Integer.toString(2014-tabOrder), jsFunction, Integer.toString(i), Integer.toString(i) };
	}

}
