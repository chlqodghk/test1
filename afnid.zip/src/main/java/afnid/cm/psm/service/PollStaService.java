package afnid.cm.psm.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service interface is biz-class of Polling Station. <br>
 * 
 * @author Afghanistan National ID Card System Application Team  Daesung Kim
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2013.05.15    		Daesung Kim          			Create
 *
 * </pre>
 */

public interface PollStaService {
	
	/**
	 * Retrieves list of Polling Station. <br>
	 * 
	 * @param vo Input item for retrieving list of Polling Station(PollStaVO).
	 * @return List Retrieve list of Polling Station
	 * @exception Exception
	 */
	List <PollStaVO> searchListPollSta(PollStaVO vo) throws Exception;
	
	/**
	 * Retrieves total count of Polling Station-list. <br>
	 * @param vo Input item for retrieving total count of Polling Station.(PollStaVO)
	 * @return int Total Count of Polling Station List
	 * @exception Exception
	 */
	int searchListPollStaTotCnt(PollStaVO vo) throws Exception;
	
	
	/**
	 * Retrieves information for Registration of Polling Station. <br>
	 * @param vo Input item for retrieving information of Polling Station and Address Name.(PollStaVO)
	 * @return PollStaVO information for Registration of Polling Station.
	 * @exception Exception
	 */
	PollStaVO searchPollSta(PollStaVO vo) throws Exception;
	
	/**
	 * Retrieves information of Polling Station. <br>
	 * @param vo Input item for retrieving information of Polling Station.(PollStaVO)
	 * @return PollStaVO information of Polling Station.
	 * @exception Exception
	 */
	PollStaVO searchPollStaInfr(PollStaVO vo) throws Exception;
	
	/**
	 * Modifies information of Polling Station. <br>
	 * 
	 * @param vo Input item for modifying Polling Station(PollStaVO).
	 * @return PollStaVO update result
	 * @exception Exception
	 */
	PollStaVO modifyPollSta (PollStaVO vo) throws Exception;
	
	/**
	 * Delete information of organization. <br>
	 * 
	 * @param vo Input item for deleting organization(OrgInfoVO).
	 * @return int update result
	 * @exception Exception
	 */
	int removePollSta (PollStaVO vo) throws Exception;
	
	/**
	 * Retrieves list of Polling Station Province. <br>
	 * 
	 * @param vo Input item for retrieving list of Polling Station Province(PollStaVO).
	 * @return List Retrieve list of Polling Station Province.
	 * @exception Exception
	 */
	List<VtrListVO> searchListPoliProvin(VtrListVO vo) throws Exception;
	
	/**
	 * Retrieves list of Polling Station District. <br>
	 * 
	 * @param vo Input item for retrieving list of Polling Station District(PollStaVO).
	 * @return List Retrieve list of Polling Station District.
	 * @exception Exception
	 */
	List<VtrListVO> searchListPoliDstr(VtrListVO vo) throws Exception;
	
	/**
	 * Retrieves list of Polling Station Area. <br>
	 * 
	 * @param vo Input item for retrieving list of Polling Station Area(PollStaVO).
	 * @return List Retrieve list of Polling Station Area.
	 * @exception Exception
	 */
	List<VtrListVO> searchListPoliAra(VtrListVO vo) throws Exception;
	
	/**
	 * Retrieves list of Polling Station Center. <br>
	 * 
	 * @param vo Input item for retrieving list of Polling Station Center(PollStaVO).
	 * @return List Retrieve list of Polling Station Center.
	 * @exception Exception
	 */
	List<VtrListVO> searchListPoliCntr(VtrListVO vo) throws Exception;
	
	/**
	 * Retrieves total count of Voter List. <br>
	 * @param vo Input item for retrieving total count of Voter List.(VtrListVO)
	 * @return int Total Count of Voter List
	 * @exception Exception
	 */
	int searchListTodayCnt(VtrListVO vo) throws Exception; 
	
	
	
	/**
	 * Retrieves Creation Date of Voter list. <br>
	 * 
	 * @param vo Input item for retrieving list of Voter(VtrListVO).
	 * @return List Retrieve list of Voter.
	 * @exception Exception
	 */
	List<VtrListVO> searchListCrnDd(VtrListVO vo) throws Exception;
	
	
	/**
	 * Register information of Voter List. <br>
	 * @param vo Input item for Register information of Voter List.(VtrListVO)
	 * @exception Exception
	 */
	int gnrVtrList(VtrListVO vo) throws Exception;
	
	/**
	 * Retrieves list of Voter. <br>
	 * 
	 * @param vo Input item for retrieving list of Voter(VtrListVO).
	 * @return List Retrieve list of Voter.
	 * @exception Exception
	 */
	List<VtrListVO> searchListVtr(VtrListVO vo) throws Exception;
	
	/**
	 * Retrieves total count of voter-list. <br>
	 * @param vo Input item for retrieving total count of voter list.(VtrListVO)
	 * @return int Total Count of voter List
	 * @exception Exception
	 */
	int searchListVtrTotCnt(VtrListVO vo) throws Exception;
	
	/**
	 * Retrieves voter list count to download Excel. <br>
	 * @param vo Input item for retrieving voter list count.(VtrListVO)
	 * @return int result count
	 * @exception Exception
	 */
	int searchListVtrExcelTotCnt(VtrListVO vo) throws Exception;
	
	/**
	 * Retrieves voter-list to download Excel. <br>
	 * @param vo Input item for retrieving voter list.(VtrListVO)
	 * @return ExcelVO
	 * @exception Exception
	 */
	List<EgovMap> searchListVtrExcel(VtrListVO vo) throws Exception;

	/**
	 * Retrieves Polling Station count to download Excel. <br>
	 * @param vo Input item for retrieving Polling Station count.(PollStaVO)
	 * @return int result count
	 * @exception Exception
	 */
	int searchListPollStaExcelTotCnt(PollStaVO vo) throws Exception;
	
	/**
	 * Retrieves Polling Station-list to download Excel. <br>
	 * @param vo Input item for retrieving Polling Station list.(PollStaVO)
	 * @return ExcelVO
	 * @exception Exception
	 */
	List<EgovMap> searchListPollStaExcel(PollStaVO vo) throws Exception;
	
	
	/**
	 * Retrieves voter-list to download Excel. <br>
	 * @param vo Input item for retrieving voter list.(VtrListVO)
	 * @return ExcelVO
	 * @exception Exception
	 */
	void searchListVtrExcelSign(VtrListVO vo) throws Exception;
	
}

