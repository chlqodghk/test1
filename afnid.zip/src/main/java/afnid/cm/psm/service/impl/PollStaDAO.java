package afnid.cm.psm.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import afnid.cm.psm.service.PollStaVO;
import afnid.cm.psm.service.VtrListVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This class is Database Access Object of Polling Station.
 * 
 * @author Afghanistan National ID Card System Application Team Daesung Kim
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2013.05.15    		Daesung Kim          			Create
 *
 * </pre>
 */
@Repository("pollStaDAO")
public class PollStaDAO extends EgovAbstractDAO{
	
	/**
	 * DAO-method for retrieving list Information of Polling Station. <br>
	 * 
	 * @param vo Input item for retrieving list information of Polling Station(PollStaVO).
	 * @return PollStaVO Retrieve list information of Polling Station
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<PollStaVO> selectListPollSta(PollStaVO vo) throws Exception{
		return list("pollStaDAO.selectListPollSta", vo);
	}
	
	/**
	 * DAO-method for retrieving total count of Polling Station. <br>
	 * 
	 * @param vo Input item for retrieving total count of Polling Station(PollStaVO).
	 * @return int Total Count of Polling Station List
	 * @exception Exception
	 */
    public int selectListPollStaTotCnt(PollStaVO vo)  throws Exception{
        return (Integer)selectByPk("pollStaDAO.selectListPollStaTotCnt", vo);
    }
    
    /**
	 * DAO-method for retrieving information for Registration of Polling Station. <br>
	 * 
	 * @param vo Input item for retrieving information of Polling Station and Address Name.(PollStaVO)
	 * @return PollStaVO information for Registration of Polling Station.
	 * @exception Exception
	 */
    public PollStaVO selectPollSta(PollStaVO vo)  throws Exception{
    	return (PollStaVO)selectByPk("pollStaDAO.selectValForPollSta", vo);
    }
    
    /**
	 * DAO-method for retrieving count for Registration of Polling Station. <br>
	 * 
	 * @param vo Input item for retrieving count of Polling Station and Address Name.(PollStaVO)
	 * @return int Count for Registration of Polling Station.
	 * @exception Exception
	 */
    public int selectPollStaCnt(PollStaVO vo)  throws Exception{
    	return (Integer)selectByPk("pollStaDAO.selectPollStaCnt", vo);
    } 
    
    /**
	 * DAO-method for registering information of new District / Province for Polling Station. <br>
	 * 
	 * @param vo Input item for registering new District / Province for Polling Station(PollStaVO).
	 * @return 
	 * @exception Exception
	 */
    public void insertPollStaDstrPrvic(PollStaVO vo)  throws Exception{
    	insert("pollStaDAO.insertPollStaDstrPrvic", vo);
    	
    }
    
    
    /**
	 * DAO-method for registering information of new Polling Station or Area. <br>
	 * 
	 * @param vo Input item for registering new Polling Station or Area(PollStaVO).
	 * @return 
	 * @exception Exception
	 */
    public void insertPollStaAreaCenter(PollStaVO vo)  throws Exception{
    	insert("pollStaDAO.insertPollStaAreaCenter", vo);
    	
    }
    
    /**
	 * DAO-method for retrieving information of Polling Station. <br>
	 * 
	 * @param vo Input item for retrieving information of Polling Station.(PollStaVO)
	 * @return PollStaVO information of Polling Station.
	 * @exception Exception
	 */
    public PollStaVO selectPollStaInfo(PollStaVO vo)  throws Exception{
		return (PollStaVO)selectByPk("pollStaDAO.selectPollStaInfo", vo);
		
	}
    
    /**
	 * DAO-method for retrieving count for update of Polling Station. <br>
	 * 
	 * @param vo Input item for update count of Polling Station and Address Name.(PollStaVO)
	 * @return int count
	 * @exception Exception
	 */
    public int selectCntForPollStaModify(PollStaVO vo)  throws Exception{
    	return (Integer)selectByPk("pollStaDAO.selectCntForPollStaModify", vo);
    }
    
    /**
	 * DAO-method for modifying information of Polling Station. <br>
	 * 
	 * @param vo Input item for modifying Polling Station(PollStaVO).
	 * @exception Exception
	 */
    public int updatePollSta(PollStaVO vo)  throws Exception{
    	
    	return update("pollStaDAO.updatePollSta", vo);
    }
      
    /**
	 * DAO-method for retrieving information of polling Station Status. <br>
	 * 
	 * @param vo Input item for retrieving information of polling Station Status(PollStaVO).
	 * @exception Exception
	 */
    public int selectPollStaStusForDlt(PollStaVO vo)  throws Exception{
    	return (Integer)selectByPk("pollStaDAO.deletePollSta", vo);
    }
    
    /**
	 * DAO-method for deleting information of polling Station. <br>
	 * 
	 * @param vo Input item for deleting organization(PollStaVO).
	 * @exception Exception
	 */
    public int deletePollSta(PollStaVO vo)  throws Exception{
    	return delete("pollStaDAO.deletePollSta", vo);
    }
    
    /**
	 * DAO-method for retrieving list Information of Polling Station Province. <br>
	 * 
	 * @param vo Input item for retrieving list information of Polling Station Province(VtrListVO).
	 * @return VtrListVO Retrieve list information of Polling Station Province
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<VtrListVO> selectListPoliPrvic(VtrListVO vo) throws Exception{
		return list("pollStaDAO.selectListPoliPrvic", vo);
	}
	
    /**
	 * DAO-method for retrieving list Information of Polling Station District. <br>
	 * 
	 * @param vo Input item for retrieving list information of Polling Station District(VtrListVO).
	 * @return VtrListVO Retrieve list information of Polling Station District
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<VtrListVO> selectListPoliDstr(VtrListVO vo) throws Exception{
		return list("pollStaDAO.selectListPoliDstr", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of Polling Station Area. <br>
	 * 
	 * @param vo Input item for retrieving list information of Polling Station Area(VtrListVO).
	 * @return VtrListVO Retrieve list information of Polling Station Area
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<VtrListVO> selectListPoliAra(VtrListVO vo) throws Exception{
		return list("pollStaDAO.selectListPoliAra", vo);
	}
	
    /**
	 * DAO-method for retrieving list Information of Polling Station Center. <br>
	 * 
	 * @param vo Input item for retrieving list information of Polling Station Province(VtrListVO).
	 * @return VtrListVO Retrieve list information of Polling Station Center
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<VtrListVO> selectListPoliCntr(VtrListVO vo) throws Exception{
		return list("pollStaDAO.selectListPoliCntr", vo);
	}
	
    /**
	 * DAO-method for retrieving  Creation Date of Voter list. <br>
	 * 
	 * @param vo Input item for retrieving list information of Polling Station Province(VtrListVO).
	 * @return VtrListVO Retrieve list information of Polling Station Center
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<VtrListVO> selectListCrnDd(VtrListVO vo) throws Exception{
		return list("pollStaDAO.selectListCrnDd", vo);
	}
	
	/**
	 * DAO-method for retrieving total count of Today Voter List. <br>
	 * 
	 * @param vo Input item for retrieving total count of Today Voter List(VtrListVO).
	 * @return int Total Count of Voter List
	 * @exception Exception
	 */
    public int selectListTodayCnt(VtrListVO vo)  throws Exception{
        return (Integer)selectByPk("pollStaDAO.selectListTodayCnt", vo);
    }
    
    /**
	 * DAO-method for Register information of Voter List. <br>
	 * 
	 * @param vo Input item for Register information of Voter List(VtrListVO).
	 * @exception Exception
	 */
    public void insertVtrList(VtrListVO vo)  throws Exception{
    	insert("pollStaDAO.insertVtrList", vo);
    }
    
    /**
	 * DAO-method for Delete information of Voter List. <br>
	 * 
	 * @param vo Input item for Delete information of Voter List(VtrListVO).
	 * @exception Exception
	 */
    public int deleteVtrListToday(VtrListVO vo)  throws Exception{
    	return delete("pollStaDAO.deleteVtrListToday", vo);
    }
    
    
    /**
	 * DAO-method for retrieving list Information of Voter. <br>
	 * 
	 * @param vo Input item for retrieving list information of Voter(VtrListVO).
	 * @return VtrListVO Retrieve list information of Voter
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<VtrListVO> selecListVtr(VtrListVO vo) throws Exception{				
		return list("pollStaDAO.selecListVtr", vo);
	}
	
	/**
	 * DAO-method for retrieving total count of Voter List. <br>
	 * 
	 * @param vo Input item for retrieving total count of Voter List(VtrListVO).
	 * @return int Total Count of Voter List
	 * @exception Exception
	 */
    public int selectListVtrTotCnt(VtrListVO vo) {
        return (Integer)selectByPk("pollStaDAO.selectListVtrTotCnt", vo);
    }
	
    /**
	 * DAO-method for retrieving Voter List Count for Excel. <br>
	 * 
	 * @param vo Input item for retrieving Voter List Count(VtrListVO).
	 * @return int result count
	 * @exception Exception
	 */
	public int selecListVtrExcelTotCnt(VtrListVO vo) {
        return (Integer)selectByPk("pollStaDAO.selecListVtrExcelTotCnt", vo);
    }
    
    /**
	 * DAO-method for retrieving Voter List for Excel. <br>
	 * 
	 * @param vo Input item for retrieving Voter List(VtrListVO).
	 * @return List<EgovMap> Voter List
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<EgovMap> selecListVtrExcel(VtrListVO vo) {
        return list("pollStaDAO.selecListVtrExcel", vo);
    }
    
	/**
	 * DAO-method for retrieving Polling Station count for Excel. <br>
	 * 
	 * @param vo Input item for retrieving Polling Station count(PollStaVO).
	 * @return int result count
	 * @exception Exception
	 */
	public int selectListPollStaExcelTotCnt(PollStaVO vo) {
        return (Integer)selectByPk("pollStaDAO.selectListPollStaExcelTotCnt", vo);
    }
	
	/**
	 * DAO-method for retrieving Polling Station List for Excel. <br>
	 * 
	 * @param vo Input item for retrieving Polling Station(PollStaVO).
	 * @return List<EgovMap> Voter List
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<EgovMap> selectListPollStaExcel(PollStaVO vo) {
        return list("pollStaDAO.selectListPollStaExcel", vo);
    }
    
    
    
    
    /**
	 * DAO-method for retrieving total count of Today Voter List. <br>
	 * 
	 * @param EgovMap
	 * @return List
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
    public List<EgovMap> selectListVtrRmPoliLcTb(EgovMap vo)  throws Exception{
        return list("pollStaDAO.selectListVtrRmPoliLcTb", vo);
    }
    
    
    /**
	 * DAO-method for retrieving Polling Station count for Excel. <br>
	 * 
	 * @param EgovMap
	 * @return int result count
	 * @exception Exception
	 */
	public int selectRmStsEcptRsdtTb(EgovMap vo) {
        return (Integer)selectByPk("pollStaDAO.selectRmStsEcptRsdtTb", vo);
    }
	
	
	/**
	 * DAO-method for registering information of new District / Province for Polling Station. <br>
	 * 
	 * @param EgovMap
	 * @return 
	 * @exception Exception
	 */
    public void insertRmStsEcptRsdtTb(EgovMap vo)  throws Exception{
    	insert("pollStaDAO.insertRmStsEcptRsdtTb", vo);
    }
    
    
    /**
	 * DAO-method for deleting information of polling Station. <br>
	 * 
	 * @param EgovMap
	 * @return int
	 * @exception Exception
	 */
    public int deleteRmStsEcptRsdtTb(EgovMap vo)  throws Exception{
    	return delete("pollStaDAO.deleteRmStsEcptRsdtTb", vo);
    }
    
    
    /**
	 * DAO-method for retrieving total count of Today Voter List. <br>
	 * 
	 * @param EgovMap
	 * @return List
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
    public List<EgovMap> selectRmVtrTbSign(EgovMap vo)  throws Exception{
        return list("pollStaDAO.selectRmVtrTbSign", vo);
    }
    
    
    /**
	 * DAO-method for modifying information of Polling Station. <br>
	 * 
	 * @param EgovMap
	 * @return int
	 * @exception Exception
	 */
    public int updateRmVtrTbSign(EgovMap vo)  throws Exception{
    	return update("pollStaDAO.updateRmVtrTbSign", vo);
    }
    
    
    /**
	 * DAO-method for retrieving list Information of Voter. <br>
	 * 
	 * @param vo Input item for retrieving list information of Voter(VtrListVO).
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selecListVtrSign(VtrListVO vo) throws Exception{				
		return list("pollStaDAO.selecListVtrSign", vo);
	}
	
	
	/**
	 * DAO-method for modifying information of Polling Station. <br>
	 * 
	 * @param EgovMap
	 * @return int
	 * @exception Exception
	 */
    public int updateRmVtrTbSignFlag(EgovMap vo)  throws Exception{
    	return update("pollStaDAO.updateRmVtrTbSignFlag", vo);
    }
    
    
    
    /**
	 * DAO-method for retrieving Voter List for Excel. <br>
	 * 
	 * @param vo Input item for retrieving Voter List(VtrListVO).
	 * @return List<EgovMap> Voter List
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<EgovMap> selecListVtrExcelSign(VtrListVO vo) {
        return list("pollStaDAO.selecListVtrExcelSign", vo);
    }
    
}
