package afnid.cm.psm.service;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of polling station
 * 
 * @author Afghanistan National ID Card System Application Team Daesung Kim
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.17 		Daesung Kim	      		 		Create
 *
 * </pre>
 */
public class PollStaVO extends ComDefaultVO{
    private static final long serialVersionUID = 1L;
    
    private String poliCntrSeqNo;
    private String cd;
    private String uprCd;
    private String pstLcNm;
    private String drLcNm;
    private String enLcNm;
    private String pstNm;
    private String drNm;
    private String enNm;
    private String tye;  
    private String pstDplyNm;
    private String drDplyNm;
    private String enDplyNm;
    private String dltYn;
    private String fstRgstUserId;
    private String fstRgstDt;
    private String lstUdtUserId;
    private String lstUdtDt;
    private String tyeNm;
    private String dplyNm;
    private String poliAdCd;
    private String errCd;
    private String userId;
    private String uprDplyNm;
    private String rn;
    private String poliAdNm;
    private String srchPoliAdCd;
    private String srchPoliAdNm;
    

	public String getRn() {
		return rn;
	}
	public void setRn(String rn) {
		this.rn = rn;
	}
	public String getUprDplyNm() {
		return uprDplyNm;
	}
	public void setUprDplyNm(String uprDplyNm) {
		this.uprDplyNm = uprDplyNm;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getErrCd() {
		return errCd;
	}
	public void setErrCd(String errCd) {
		this.errCd = errCd;
	}
	public String getPoliAdCd() {
		return poliAdCd;
	}
	public void setPoliAdCd(String poliAdCd) {
		this.poliAdCd = poliAdCd;
	}
	public String getPstNm() {
		return pstNm;
	}
	public void setPstNm(String pstNm) {
		this.pstNm = pstNm;
	}
	public String getDrNm() {
		return drNm;
	}
	public void setDrNm(String drNm) {
		this.drNm = drNm;
	}
	public String getEnNm() {
		return enNm;
	}
	public void setEnNm(String enNm) {
		this.enNm = enNm;
	}
	public String getDplyNm() {
		return dplyNm;
	}
	public void setDplyNm(String dplyNm) {
		this.dplyNm = dplyNm;
	}
	public String getTyeNm() {
		return tyeNm;
	}
	public void setTyeNm(String tyeNm) {
		this.tyeNm = tyeNm;
	}
	public String getPoliCntrSeqNo() {
		return poliCntrSeqNo;
	}
	public void setPoliCntrSeqNo(String poliCntrSeqNo) {
		this.poliCntrSeqNo = poliCntrSeqNo;
	}
	public String getCd() {
		return cd;
	}
	public void setCd(String cd) {
		this.cd = cd;
	}
	public String getUprCd() {
		return uprCd;
	}
	public void setUprCd(String uprCd) {
		this.uprCd = uprCd;
	}
	public String getPstLcNm() {
		return pstLcNm;
	}
	public void setPstLcNm(String pstLcNm) {
		this.pstLcNm = pstLcNm;
	}
	public String getDrLcNm() {
		return drLcNm;
	}
	public void setDrLcNm(String drLcNm) {
		this.drLcNm = drLcNm;
	}
	public String getEnLcNm() {
		return enLcNm;
	}
	public void setEnLcNm(String enLcNm) {
		this.enLcNm = enLcNm;
	}
	public String getTye() {
		return tye;
	}
	public void setTye(String tye) {
		this.tye = tye;
	}
	public String getPstDplyNm() {
		return pstDplyNm;
	}
	public void setPstDplyNm(String pstDplyNm) {
		this.pstDplyNm = pstDplyNm;
	}
	public String getDrDplyNm() {
		return drDplyNm;
	}
	public void setDrDplyNm(String drDplyNm) {
		this.drDplyNm = drDplyNm;
	}
	public String getEnDplyNm() {
		return enDplyNm;
	}
	public void setEnDplyNm(String enDplyNm) {
		this.enDplyNm = enDplyNm;
	}
	public java.lang.String getDltYn() {
		return dltYn;
	}
	public void setDltYn(java.lang.String dltYn) {
		this.dltYn = dltYn;
	}
	public java.lang.String getFstRgstUserId() {
		return fstRgstUserId;
	}
	public void setFstRgstUserId(java.lang.String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}
	public java.lang.String getFstRgstDt() {
		return fstRgstDt;
	}
	public void setFstRgstDt(java.lang.String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}
	public java.lang.String getLstUdtUserId() {
		return lstUdtUserId;
	}
	public void setLstUdtUserId(java.lang.String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}
	public java.lang.String getLstUdtDt() {
		return lstUdtDt;
	}
	public void setLstUdtDt(java.lang.String lstUdtDt) {
		this.lstUdtDt = lstUdtDt;
	}
	public String getPoliAdNm() {
		return poliAdNm;
	}
	public void setPoliAdNm(String poliAdNm) {
		this.poliAdNm = poliAdNm;
	}
	public String getSrchPoliAdCd() {
		return srchPoliAdCd;
	}
	public void setSrchPoliAdCd(String srchPoliAdCd) {
		this.srchPoliAdCd = srchPoliAdCd;
	}
	public String getSrchPoliAdNm() {
		return srchPoliAdNm;
	}
	public void setSrchPoliAdNm(String srchPoliAdNm) {
		this.srchPoliAdNm = srchPoliAdNm;
	}
     
}
