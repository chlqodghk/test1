package afnid.cm.psm.service.impl;

import java.io.Reader;
import java.io.Writer;
import java.util.List;

import javax.annotation.Resource;

import oracle.sql.CLOB;

import org.springframework.stereotype.Service;

import si.osi.dsig.XMLDsigValidate;
import si.osi.dsig.XMLSignerP11;

import afnid.cm.NidMessageSource;
import afnid.cm.psm.service.PollStaService;
import afnid.cm.psm.service.PollStaVO;
import afnid.cm.psm.service.VtrListVO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of Polling Station
 * and implements NidAuthorManageService class.
 * 
 * @author Afghanistan National ID Card System Application Team  Daesung Kim
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2013.05.15    		Daesung Kim          			Create
 *
 * </pre>
 */
@Service("pollStaService")
public class PollStaServiceImpl extends AbstractServiceImpl implements PollStaService{
	
	@Resource(name="pollStaDAO")
    private PollStaDAO pollStaDAO;
	
	@Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtInfrDAO;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /**
	 * Biz-method for retrieving list of Polling Station. <br>
	 * 
	 * @param vo Input item for retrieving list of Polling Station(PollStaVO).
	 * @return List Retrieve list of Polling Station
	 * @exception Exception
	 */
	public List<PollStaVO> searchListPollSta(PollStaVO vo) throws Exception {
		return pollStaDAO.selectListPollSta(vo);
	}
	
	/**
	 * Biz-method for retrieving total count of Polling Station. <br>
	 * 
	 * @param vo Input item for retrieving list of Polling Station(PollStaVO).
	 * @return int Total Count of Polling Station List
	 * @exception Exception
	 */
	public int searchListPollStaTotCnt(PollStaVO vo) throws Exception {
		return pollStaDAO.selectListPollStaTotCnt(vo);
	}

	/**
	 * Biz-method for retrieving information for Registration of Polling Station. <br>
	 * 
	 * @param vo Input item for retrieving information of Polling Station and Address Name.(PollStaVO)
	 * @return PollStaVO information for Registration of Polling Station.
	 * @exception Exception
	 */
	public PollStaVO searchPollSta(PollStaVO vo) throws Exception {
		String tye = vo.getTye();
		String kochiAdCd = String.valueOf(propertiesService.getInt("kochiAdCd"));
			
		if(kochiAdCd.equals(vo.getPoliAdCd())){
			vo.setErrCd("ERR01");
			return  vo;
		}
		
		int selectCnt = pollStaDAO.selectPollStaCnt(vo);
		if(selectCnt > 0){
			vo.setErrCd("ERR02");
			return vo;
		}
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd());
		
		if("1".equals(tye)){
			pollStaDAO.insertPollStaDstrPrvic(vo);
			
		}else{
			pollStaDAO.insertPollStaAreaCenter(vo);
		}

		return  vo;
	}

	/**
	 * Biz-method for retrieving information of Polling Station. <br>
	 * 
	 * @param vo Input item for retrieving information of Polling Station.(PollStaVO)
	 * @return PollStaVO information of Polling Station.
	 * @exception Exception
	 */
	public PollStaVO searchPollStaInfr(PollStaVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		
		return pollStaDAO.selectPollStaInfo(vo);
	}
	
	/**
	 * Biz-method for modifying information of Polling Station. <br>
	 * 
	 * @param vo Input item for modifying Polling Station(PollStaVO).
	 * @exception Exception
	 */
	public PollStaVO modifyPollSta(PollStaVO vo) throws Exception {
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
		
		int selectCnt = pollStaDAO.selectCntForPollStaModify(vo);
		if(selectCnt > 0){
			vo.setErrCd("ERR02");
			return vo;
		}
		
		int result = pollStaDAO.updatePollSta(vo);
		
		if(result != 1){
			throw processException( "udtFail.msg");
		}
		
		return vo;
	}

	/**
	 * Biz-method for deleting information of polling Station. <br>
	 * 
	 * @param vo Input item for deleting organization(PollStaVO).
	 * @exception Exception
	 */
	public int removePollSta(PollStaVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
		
		int result = pollStaDAO.deletePollSta(vo);
		
		if(result > 1){
			throw processException("dltFail.msg");
		}
		
		return result;
	}
	
    /**
	 * Biz-method for retrieving list of Polling Station Province. <br>
	 * 
	 * @param vo Input item for retrieving list of Polling Station Province(VtrListVO).
	 * @return List Retrieve list of Polling Station Province
	 * @exception Exception
	 */
	public List<VtrListVO> searchListPoliProvin(VtrListVO vo) throws Exception {
		return pollStaDAO.selectListPoliPrvic(vo);
	}
	
	 /**
	 * Biz-method for retrieving list of Polling Station District. <br>
	 * 
	 * @param vo Input item for retrieving list of Polling Station District(VtrListVO).
	 * @return List Retrieve list of Polling Station District
	 * @exception Exception
	 */
	public List<VtrListVO> searchListPoliDstr(VtrListVO vo) throws Exception {
		return pollStaDAO.selectListPoliDstr(vo);
	}
	
	 /**
		 * Biz-method for retrieving list of Polling Station Area. <br>
		 * 
		 * @param vo Input item for retrieving list of Polling Station Area(VtrListVO).
		 * @return List Retrieve list of Polling Station Area
		 * @exception Exception
		 */
		public List<VtrListVO> searchListPoliAra(VtrListVO vo) throws Exception {
			return pollStaDAO.selectListPoliAra(vo);
		}
	
	 /**
	 * Biz-method for retrieving  Creation Date of Voter list. <br>
	 * 
	 * @param vo Input item for retrieving list of Polling Station Center(VtrListVO).
	 * @return List Retrieve list of Polling Station Center
	 * @exception Exception
	 */
	public List<VtrListVO> searchListCrnDd(VtrListVO vo) throws Exception {
		return pollStaDAO.selectListCrnDd(vo);
	}
	
	/**
	 * Biz-method for retrieving total count of Voter List. <br>
	 * 
	 * @param vo Input item for retrieving total count of Voter List(VtrListVO).
	 * @return int Total Count of Polling Station List
	 * @exception Exception
	 */
	public int searchListTodayCnt(VtrListVO vo) throws Exception {
		return pollStaDAO.selectListTodayCnt(vo);
	}
    
	
	 /**
	 * Biz-method for retrieving list of Polling Station Center. <br>
	 * 
	 * @param vo Input item for retrieving list of Polling Station Center(VtrListVO).
	 * @return List Retrieve list of Polling Station Center
	 * @exception Exception
	 */
	public List<VtrListVO> searchListPoliCntr(VtrListVO vo) throws Exception {
		return pollStaDAO.selectListPoliCntr(vo);
	}
	
	
	/**
	 * Biz-method for Register information of Voter List. <br>
	 * 
	 * @param vo Input item for Register information of Voter List(VtrListVO).
	 * @exception Exception
	 */
	public int gnrVtrList(VtrListVO vo) throws Exception {

		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
		
		//vo.setGnrDd(vo.getGnrDd().replace("-", ""));
		String delFlag = vo.getDltYn();

		EgovMap ems = new EgovMap();
		ems.put("crnDd", vo.getGnrDd());
		ems.put("gnrDd", vo.getGnrDd());
		ems.put("bsnEcptTypeCd", "2");
		
		if("Y".equals(delFlag)){
			int result= pollStaDAO.deleteVtrListToday(vo);
			if(result <= 0){
				throw processException( "crnFail.msg");
			}
			result = pollStaDAO.selectRmStsEcptRsdtTb(ems);
			if(result > 0){
				pollStaDAO.deleteRmStsEcptRsdtTb(ems);
			}
		}
		
		setRmStsEcptRsdtTb(vo.getGnrDd());
		
		pollStaDAO.insertVtrList(vo);
		int cnt = pollStaDAO.selectListTodayCnt(vo);
		
		List<EgovMap> emList = pollStaDAO.selectRmVtrTbSign(ems);
		if(emList != null && !emList.isEmpty()){
			for(int i = 0 ;i < emList.size(); i++){
				EgovMap em = emList.get(i);
				String emDt = NidStringUtil.nullConvert(em.get("dtMrg"));
				String result = XMLSignerP11.spkiIFRmStringDigitalSignature(emDt);
				String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
				if(result.indexOf(reg) != -1){
					String resultSgnt = getXmlData(result, "ds:Signature");
					if(resultSgnt != null && resultSgnt.length() > 0){
						em.put("sysSgnt", resultSgnt);
						pollStaDAO.updateRmVtrTbSign(em);
					}
				}
			}
		}
		
		
		return cnt;

	}
	
	/**
	 * Biz-method for retrieving Voter List. <br>
	 * 
	 * @param vo Input item for retrieving Voter List(VtrListVO).
	 * @return List<VtrListVO> Voter List.
	 * @exception Exception
	 */
	public List<VtrListVO> searchListVtr(VtrListVO vo) throws Exception {
		List<EgovMap> emLst = pollStaDAO.selecListVtrSign(vo);
		if(emLst != null && !emLst.isEmpty()){
			for(int i = 0; i < emLst.size(); i++){
				EgovMap emp = emLst.get(i);
				String crnDd = NidStringUtil.nullConvert(emp.get("crnDd"));
				String rsdtSeqNo = NidStringUtil.nullConvert(emp.get("rsdtSeqNo"));
				String sysSgnt = null;
				String certResult = "1";
				Object obj = emp.get("sysSgnt");
    			if(obj != null){
					if("oracle.sql.CLOB".equals(obj.getClass().getName()) ){
						CLOB clob = (CLOB)obj;
						sysSgnt = clobToString(clob);
						//log.debug("oracle.sql.CLOB : " + sysSgnt);
					}else if("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB".equals(obj.getClass().getName()) ){
						weblogic.jdbc.vendor.oracle.OracleThinClob clob = (weblogic.jdbc.vendor.oracle.OracleThinClob)obj;
						sysSgnt = clobToString(clob);
						//log.debug("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB : " + sysSgnt);
					}
				}
    			String dtMrg = NidStringUtil.nullConvert(emp.get("dtMrg"));
    			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
				StringBuffer sb = new StringBuffer();
				sb.append(reg);
				sb.append("<root>");
				sb.append("\r\n<RMDSigData><![CDATA[");
				sb.append(dtMrg);
				sb.append("]]></RMDSigData>\r\n");
				sb.append(sysSgnt);
				sb.append("</root>");
				byte [] array = new byte[sb.toString().length()];			
				array = sb.toString().getBytes();
				int certResultFlag = XMLDsigValidate.spkiIFDigitalSignatureValidation(array);
				if(certResultFlag == 0){
					certResult = "0";
				}
				EgovMap emup = new EgovMap();
				emup.put("rsdtSeqNo", rsdtSeqNo);
				emup.put("crnDd", crnDd);
				emup.put("sysSgntInsp", certResult);
				pollStaDAO.updateRmVtrTbSignFlag(emup);
			}
		}
		return pollStaDAO.selecListVtr(vo);
	}
	
	/**
	 * Biz-method for retrieving total count of Voter List. <br>
	 * 
	 * @param vo Input item for retrieving list of Voter(VtrListVO).
	 * @return int Total Count of Voter List
	 * @exception Exception
	 */
	public int searchListVtrTotCnt(VtrListVO vo) throws Exception {
		
		return pollStaDAO.selectListVtrTotCnt(vo);
	}
	
	
	/**
	 * Biz-method for retrieving Voter Total Count to download Excel. <br>
	 * 
	 * @param vo Input item for retrieving count of Voter(VtrListVO).
	 * @return int result count
	 * @exception Exception
	 */
	public int searchListVtrExcelTotCnt(VtrListVO vo) throws Exception{

		return pollStaDAO.selecListVtrExcelTotCnt(vo);
	}
	
	/**
	 * Biz-method for retrieving Voter List to download Excel. <br>
	 * 
	 * @param vo Input item for retrieving list of Voter(VtrListVO).
	 * @return 
	 * @exception Exception
	 */
	public List<EgovMap> searchListVtrExcel(VtrListVO vo) throws Exception{

		return pollStaDAO.selecListVtrExcel(vo);
	
	}
	
	/**
	 * Biz-method for retrieving Polling station Total Count to download Excel. <br>
	 * 
	 * @param vo Input item for retrieving count of Polling station(PollStaVO).
	 * @return int result count
	 * @exception Exception
	 */
	public int searchListPollStaExcelTotCnt(PollStaVO vo) throws Exception{

		return pollStaDAO.selectListPollStaExcelTotCnt(vo);
	}
	
	/**
	 * Biz-method for retrieving Polling station List to download Excel. <br>
	 * 
	 * @param vo Input item for retrieving list of Polling station(PollStaVO).
	 * @return List<EgovMap> retrieving result
	 * @exception Exception
	 */
	public List<EgovMap> searchListPollStaExcel(PollStaVO vo) throws Exception{
		return pollStaDAO.selectListPollStaExcel(vo);
	}
	
	
	
	/**
	 * RM_STS_ECPT_RSDT_TB table select, insert <br>
	 *
	 * @param String
	 * @return void
	 *
	 */
	private void setRmStsEcptRsdtTb(String gYmd) {
		if(gYmd != null){
			try{
				EgovMap ems = new EgovMap();
		        ems.put("crnDd", gYmd);
		        ems.put("bsnEcptTypeCd", "2");
		        int emsCnt = pollStaDAO.selectRmStsEcptRsdtTb(ems);
		        if(emsCnt == 0){
		        	List<EgovMap> emsLst = pollStaDAO.selectListVtrRmPoliLcTb(ems);
		        	if(emsLst != null && !emsLst.isEmpty()){
		        		String emsRsdtSeqNo = null;
		        		EgovMap emRsdtInfr = null;
		        		StringBuffer sb = null;
		        		int certResult = -1;
		        		for(int i = 0; i < emsLst.size(); i++){
		        			EgovMap lstEm = emsLst.get(i);
		        			emsRsdtSeqNo = NidStringUtil.nullConvert(lstEm.get("rsdtSeqNo"));
		        			emRsdtInfr  = rsdtInfrDAO.selectRsdtInfrDat(emsRsdtSeqNo);
		        			sb = new StringBuffer();
		        			String sysSgnt = null;
		        			Object obj = emRsdtInfr.get("sysSgnt");
		        			if(obj != null){
		    					if("oracle.sql.CLOB".equals(obj.getClass().getName()) ){
		    						CLOB clob = (CLOB)obj;
		    						sysSgnt = clobToString(clob);
		    						//log.debug("oracle.sql.CLOB : " + sysSgnt);
		    					}else if("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB".equals(obj.getClass().getName()) ){
		    						weblogic.jdbc.vendor.oracle.OracleThinClob clob = (weblogic.jdbc.vendor.oracle.OracleThinClob)obj;
		    						sysSgnt = clobToString(clob);
		    						//log.debug("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB : " + sysSgnt);
		    					}
		    				}
		        			String rmData = rsdtInfrDAO.setRsdtInfrHashDat(emRsdtInfr);
		        			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		        			sb.append(reg);
		        			sb.append("<root>");
		        			sb.append("\r\n<RMDSigData><![CDATA[");
		        			sb.append(rmData);
		        			sb.append("]]></RMDSigData>\r\n");
		        			sb.append(sysSgnt);
		        			sb.append("</root>");
		        			byte [] array = new byte[sb.toString().length()];			
		        			array = sb.toString().getBytes();
		        			certResult = XMLDsigValidate.spkiIFDigitalSignatureValidation(array);
		        			if(certResult != 0){
								EgovMap emsIn = new EgovMap();
								emsIn.put("crnDd", gYmd);
								emsIn.put("bsnEcptTypeCd", "2");
								emsIn.put("rsdtSeqNo", emsRsdtSeqNo);
								pollStaDAO.insertRmStsEcptRsdtTb(emsIn);
		        			}
		        			emsRsdtSeqNo = null;
		        			emRsdtInfr  = null;
		        			sb = null;
		        			certResult = -1;
		        		}
		        	}
		        }
			}catch(Exception e){
				log.error(e);
			}
		}
	}
	
	
	/**
	 * ClobToString <br>
	 *
	 * @param CLOB
	 * @return String
	 *
	 */
	private String clobToString(CLOB clob) {
		String result = "";
		if(clob != null){
			try{
				Reader reader = clob.getCharacterStream();
				StringBuffer sb = new StringBuffer();
				int size = 0;
				char[] array = new char[10];
				while(( size = reader.read(array)) != -1){
					sb.append(array, 0, size);
				}
				result = sb.toString();
			}catch(Exception e){
				log.error(e);
			}
		}
		return result;
	}
	
	/**
	 * ClobToString <br>
	 *
	 * @param CLOB
	 * @return String
	 *
	 */
	private String clobToString(weblogic.jdbc.vendor.oracle.OracleThinClob clob) {
		String result = "";
		if(clob != null){
			try{
				Writer clobWriter = clob.getCharacterOutputStream();
				log.debug("clobToString : " +clobWriter);
				StringBuffer sb = new StringBuffer();
				if(clobWriter != null){
					char buf [] = new char[clob.getChunkSize()];
					buf[0] = '\0';
					clob.getChars(1, clob.getChunkSize(), buf);
					sb.append(buf);
				}
				result = sb.toString();
			}catch(Exception e){
				log.error(e);
			}
		}
		return result;
	}
	
	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param String, String
   	 * @return String
   	 * @exception Exception
   	 */
   	public String getXmlData(String xml, String tag) throws Exception{
    	String result = "";
    	if(xml != null && tag != null && xml.length() > 0 && tag.length() > 0){
        	result = xml;
        	int str = result.indexOf("<"+tag);
        	int end = result.lastIndexOf("</"+tag+">");
        	result = result.substring(str, end+3+tag.length());
    	}
    	return result;
    }
   	
   	
   	/**
	 * Biz-method for retrieving Voter List to download Excel. <br>
	 * 
	 * @param vo Input item for retrieving list of Voter(VtrListVO).
	 * @return void
	 * @exception Exception
	 */
	public void searchListVtrExcelSign(VtrListVO vo) throws Exception{
		List<EgovMap> emLst = pollStaDAO.selecListVtrExcelSign(vo);
		if(emLst != null && !emLst.isEmpty()){
			for(int i = 0; i < emLst.size(); i++){
				EgovMap emp = emLst.get(i);
				String crnDd = NidStringUtil.nullConvert(emp.get("crnDd"));
				String rsdtSeqNo = NidStringUtil.nullConvert(emp.get("rsdtSeqNo"));
				String sysSgnt = null;
				String certResult = "1";
				Object obj = emp.get("sysSgnt");
    			if(obj != null){
					if("oracle.sql.CLOB".equals(obj.getClass().getName()) ){
						CLOB clob = (CLOB)obj;
						sysSgnt = clobToString(clob);
						//log.debug("oracle.sql.CLOB : " + sysSgnt);
					}else if("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB".equals(obj.getClass().getName()) ){
						weblogic.jdbc.vendor.oracle.OracleThinClob clob = (weblogic.jdbc.vendor.oracle.OracleThinClob)obj;
						sysSgnt = clobToString(clob);
						//log.debug("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB : " + sysSgnt);
					}
				}
    			String dtMrg = NidStringUtil.nullConvert(emp.get("dtMrg"));
    			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
				StringBuffer sb = new StringBuffer();
				sb.append(reg);
				sb.append("<root>");
				sb.append("\r\n<RMDSigData><![CDATA[");
				sb.append(dtMrg);
				sb.append("]]></RMDSigData>\r\n");
				sb.append(sysSgnt);
				sb.append("</root>");
				byte [] array = new byte[sb.toString().length()];			
				array = sb.toString().getBytes();
				int certResultFlag = XMLDsigValidate.spkiIFDigitalSignatureValidation(array);
				if(certResultFlag == 0){
					certResult = "0";
				}
				EgovMap emup = new EgovMap();
				emup.put("rsdtSeqNo", rsdtSeqNo);
				emup.put("crnDd", crnDd);
				emup.put("sysSgntInsp", certResult);
				pollStaDAO.updateRmVtrTbSignFlag(emup);
			}
		}
	}
	
	
}
