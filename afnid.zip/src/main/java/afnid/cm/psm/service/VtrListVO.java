package afnid.cm.psm.service;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of Voter List
 * 
 * @author Afghanistan National ID Card System Application Team Daesung Kim
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.17 		Daesung Kim	      		 		Create
 *
 * </pre>
 */
public class VtrListVO extends ComDefaultVO{
    private static final long serialVersionUID = 1L;
    
    private String sysSgnt;
    private String sysSgntInsp;
    private String poliCntrSeqNo;
    private String poliPrvicCd;   
    private String poliDstrCd;
    private String poliAraCd;
    private String poliCntrCd;
    private String pstPoliPrvicNm;
    private String drPoliPrvicNm;
    private String enPoliPrvicNm;
    private String pstPoliDstrNm;
    private String drPoliDstrNm;
    private String enPoliDstrNm;
    private String pstPoliAraNm;
    private String drPoliAraNm;
    private String enPoliAraNm;
    private String pstPoliLcNm;
    private String drPoliLcNm;
    private String enPoliLcNm;
    private String pstPoliCntrNm;
    private String drPoliCntrNm;
    private String enPoliCntrNm;
     

    private String dltYn;
    private String fstRgstUserId;
    private String fstRgstDt;
    private String lstUdtUserId;
    private String lstUdtDt;
    
    private String poliPrvicNm;
    private String poliDstrNm;
    private String poliAraNm;
    private String poliLcNm;
    private String poliCntrNm;
    private String poliDplyNm;

    private String rsdtSeqNo;
    private String rsdtNo;
    private String rsdtNoDp;
    private String curtAdCd;
    private String curtAdDtlCt;
    private String curtAdCdNm;
    private String curtAdDplyNm;
    private String gdrCd;
    private String gdrCdNm;
    private String poliAdCd;
    private String poliAdNm;
    private String grnDd;
    private String calTye;
    
    /** check flag for searching province */
    private java.lang.Boolean pFlag = false;
   
    /** check flag for searching district */
    private java.lang.Boolean dFlag = false;
   
    /** check flag for searching area */
    private java.lang.Boolean aFlag = false;
    
    /** check flag for searching center */
    private java.lang.Boolean cFlag = false;

    /** Polling Station address Code */
    private java.lang.String adCode;
    
    /** Polling Station address Name */
    private java.lang.String adName;
       
    /** VoterList Generation Date */
    private java.lang.String gnrDd;
 
    private java.lang.String givNm;
    private java.lang.String surnm;
    private java.lang.String fthrNm;
    private java.lang.String bthDd;
 
    private java.lang.String hBthDd;
    private java.lang.String gBthDd; 
    private java.lang.String gGnrDd;
    private java.lang.String hGnrDd;
    private java.lang.String toDay;
    private java.lang.String rn;
    

	public java.lang.String getRn() {
		return rn;
	}

	public void setRn(java.lang.String rn) {
		this.rn = rn;
	}

	public java.lang.String getPoliDplyNm() {
		return poliDplyNm;
	}

	public void setPoliDplyNm(java.lang.String poliDplyNm) {
		this.poliDplyNm = poliDplyNm;
	}

	public java.lang.String getCurtAdDplyNm() {
		return curtAdDplyNm;
	}

	public void setCurtAdDplyNm(java.lang.String curtAdDplyNm) {
		this.curtAdDplyNm = curtAdDplyNm;
	}

	public java.lang.String getPoliAraNm() {
		return poliAraNm;
	}

	public void setPoliAraNm(java.lang.String poliAraNm) {
		this.poliAraNm = poliAraNm;
	}

	public java.lang.Boolean getaFlag() {
		return aFlag;
	}

	public void setaFlag(java.lang.Boolean aFlag) {
		this.aFlag = aFlag;
	}

	public java.lang.String getPoliDstrCd() {
		return poliDstrCd;
	}

	public void setPoliDstrCd(java.lang.String poliDstrCd) {
		this.poliDstrCd = poliDstrCd;
	}

	public java.lang.String getPoliAraCd() {
		return poliAraCd;
	}

	public void setPoliAraCd(java.lang.String poliAraCd) {
		this.poliAraCd = poliAraCd;
	}

	public java.lang.String getPstPoliAraNm() {
		return pstPoliAraNm;
	}

	public void setPstPoliAraNm(java.lang.String pstPoliAraNm) {
		this.pstPoliAraNm = pstPoliAraNm;
	}

	public java.lang.String getDrPoliAraNm() {
		return drPoliAraNm;
	}

	public void setDrPoliAraNm(java.lang.String drPoliAraNm) {
		this.drPoliAraNm = drPoliAraNm;
	}

	public java.lang.String getEnPoliAraNm() {
		return enPoliAraNm;
	}

	public void setEnPoliAraNm(java.lang.String enPoliAraNm) {
		this.enPoliAraNm = enPoliAraNm;
	}

	public java.lang.String getToDay() {
		return toDay;
	}

	public void setToDay(java.lang.String toDay) {
		this.toDay = toDay;
	}

	public java.lang.String getgGnrDd() {
		return gGnrDd;
	}

	public void setgGnrDd(java.lang.String gGnrDd) {
		this.gGnrDd = gGnrDd;
	}

	public java.lang.String gethGnrDd() {
		return hGnrDd;
	}

	public void sethGnrDd(java.lang.String hGnrDd) {
		this.hGnrDd = hGnrDd;
	}

	public java.lang.String getRsdtNoDp() {
		return rsdtNoDp;
	}

	public void setRsdtNoDp(java.lang.String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}

	public java.lang.String getCurtAdCdNm() {
		return curtAdCdNm;
	}

	public void setCurtAdCdNm(java.lang.String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}

	public java.lang.String getGdrCdNm() {
		return gdrCdNm;
	}

	public void setGdrCdNm(java.lang.String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}

	public java.lang.String getRsdtNo() {
		return rsdtNo;
	}

	public void setRsdtNo(java.lang.String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}

	public java.lang.String getGivNm() {
		return givNm;
	}

	public void setGivNm(java.lang.String givNm) {
		this.givNm = givNm;
	}

	public java.lang.String getSurnm() {
		return surnm;
	}

	public void setSurnm(java.lang.String surnm) {
		this.surnm = surnm;
	}

	public java.lang.String getFthrNm() {
		return fthrNm;
	}

	public void setFthrNm(java.lang.String fthrNm) {
		this.fthrNm = fthrNm;
	}

	public java.lang.String getBthDd() {
		return bthDd;
	}

	public void setBthDd(java.lang.String bthDd) {
		this.bthDd = bthDd;
	}

	public java.lang.String getCurtAdCd() {
		return curtAdCd;
	}

	public void setCurtAdCd(java.lang.String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}

	public java.lang.String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}

	public void setCurtAdDtlCt(java.lang.String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}
 
    public java.lang.String getGdrCd() {
		return gdrCd;
	}

	public void setGdrCd(java.lang.String gdrCd) {
		this.gdrCd = gdrCd;
	}

	public java.lang.String getRsdtSeqNo() {
		return rsdtSeqNo;
	}

	public void setRsdtSeqNo(java.lang.String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}

	public java.lang.String getGnrDd() {
		return gnrDd;
	}

	public void setGnrDd(java.lang.String gnrDd) {
		this.gnrDd = gnrDd;
	}

	public java.lang.String getAdCode() {
		return adCode;
	}

	public void setAdCode(java.lang.String adCode) {
		this.adCode = adCode;
	}

	public java.lang.String getAdName() {
		return adName;
	}

	public void setAdName(java.lang.String adName) {
		this.adName = adName;
	}

	public java.lang.Boolean getpFlag() {
		return pFlag;
	}

	public void setpFlag(java.lang.Boolean pFlag) {
		this.pFlag = pFlag;
	}

	public java.lang.Boolean getdFlag() {
		return dFlag;
	}

	public void setdFlag(java.lang.Boolean dFlag) {
		this.dFlag = dFlag;
	}

	public java.lang.Boolean getcFlag() {
		return cFlag;
	}

	public void setcFlag(java.lang.Boolean cFlag) {
		this.cFlag = cFlag;
	}
    

	
	public java.lang.String getPoliPrvicCd() {
		return poliPrvicCd;
	}

	public void setPoliPrvicCd(java.lang.String poliPrvicCd) {
		this.poliPrvicCd = poliPrvicCd;
	}

	public java.lang.String getPoliPrvicNm() {
		return poliPrvicNm;
	}

	public void setPoliPrvicNm(java.lang.String poliPrvicNm) {
		this.poliPrvicNm = poliPrvicNm;
	}

	public java.lang.String getPoliDstrNm() {
		return poliDstrNm;
	}

	public void setPoliDstrNm(java.lang.String poliDstrNm) {
		this.poliDstrNm = poliDstrNm;
	}

	public java.lang.String getPoliLcNm() {
		return poliLcNm;
	}

	public void setPoliLcNm(java.lang.String poliLcNm) {
		this.poliLcNm = poliLcNm;
	}

	public java.lang.String getPoliCntrNm() {
		return poliCntrNm;
	}

	public void setPoliCntrNm(java.lang.String poliCntrNm) {
		this.poliCntrNm = poliCntrNm;
	}

	public java.lang.String getPoliCntrSeqNo() {
		return poliCntrSeqNo;
	}

	public void setPoliCntrSeqNo(java.lang.String poliCntrSeqNo) {
		this.poliCntrSeqNo = poliCntrSeqNo;
	}

	public java.lang.String getPoliCntrCd() {
		return poliCntrCd;
	}

	public void setPoliCntrCd(java.lang.String poliCntrCd) {
		this.poliCntrCd = poliCntrCd;
	}

	public java.lang.String getPstPoliPrvicNm() {
		return pstPoliPrvicNm;
	}

	public void setPstPoliPrvicNm(java.lang.String pstPoliPrvicNm) {
		this.pstPoliPrvicNm = pstPoliPrvicNm;
	}

	public java.lang.String getDrPoliPrvicNm() {
		return drPoliPrvicNm;
	}

	public void setDrPoliPrvicNm(java.lang.String drPoliPrvicNm) {
		this.drPoliPrvicNm = drPoliPrvicNm;
	}

	public java.lang.String getEnPoliPrvicNm() {
		return enPoliPrvicNm;
	}

	public void setEnPoliPrvicNm(java.lang.String enPoliPrvicNm) {
		this.enPoliPrvicNm = enPoliPrvicNm;
	}

	public java.lang.String getPstPoliDstrNm() {
		return pstPoliDstrNm;
	}

	public void setPstPoliDstrNm(java.lang.String pstPoliDstrNm) {
		this.pstPoliDstrNm = pstPoliDstrNm;
	}

	public java.lang.String getDrPoliDstrNm() {
		return drPoliDstrNm;
	}

	public void setDrPoliDstrNm(java.lang.String drPoliDstrNm) {
		this.drPoliDstrNm = drPoliDstrNm;
	}

	public java.lang.String getEnPoliDstrNm() {
		return enPoliDstrNm;
	}

	public void setEnPoliDstrNm(java.lang.String enPoliDstrNm) {
		this.enPoliDstrNm = enPoliDstrNm;
	}

	public java.lang.String getPstPoliLcNm() {
		return pstPoliLcNm;
	}

	public void setPstPoliLcNm(java.lang.String pstPoliLcNm) {
		this.pstPoliLcNm = pstPoliLcNm;
	}

	public java.lang.String getDrPoliLcNm() {
		return drPoliLcNm;
	}

	public void setDrPoliLcNm(java.lang.String drPoliLcNm) {
		this.drPoliLcNm = drPoliLcNm;
	}

	public java.lang.String getEnPoliLcNm() {
		return enPoliLcNm;
	}

	public void setEnPoliLcNm(java.lang.String enPoliLcNm) {
		this.enPoliLcNm = enPoliLcNm;
	}

	public java.lang.String getPstPoliCntrNm() {
		return pstPoliCntrNm;
	}

	public void setPstPoliCntrNm(java.lang.String pstPoliCntrNm) {
		this.pstPoliCntrNm = pstPoliCntrNm;
	}

	public java.lang.String getDrPoliCntrNm() {
		return drPoliCntrNm;
	}

	public void setDrPoliCntrNm(java.lang.String drPoliCntrNm) {
		this.drPoliCntrNm = drPoliCntrNm;
	}

	public java.lang.String getEnPoliCntrNm() {
		return enPoliCntrNm;
	}

	public void setEnPoliCntrNm(java.lang.String enPoliCntrNm) {
		this.enPoliCntrNm = enPoliCntrNm;
	}

	public java.lang.String getDltYn() {
		return dltYn;
	}

	public void setDltYn(java.lang.String dltYn) {
		this.dltYn = dltYn;
	}

	public java.lang.String getFstRgstUserId() {
		return fstRgstUserId;
	}

	public void setFstRgstUserId(java.lang.String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}

	public java.lang.String getFstRgstDt() {
		return fstRgstDt;
	}

	public void setFstRgstDt(java.lang.String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}

	public java.lang.String getLstUdtUserId() {
		return lstUdtUserId;
	}

	public void setLstUdtUserId(java.lang.String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}

	public java.lang.String getLstUdtDt() {
		return lstUdtDt;
	}

	public void setLstUdtDt(java.lang.String lstUdtDt) {
		this.lstUdtDt = lstUdtDt;
	}

	public java.lang.String gethBthDd() {
		return hBthDd;
	}

	public void sethBthDd(java.lang.String hBthDd) {
		this.hBthDd = hBthDd;
	}

	public java.lang.String getgBthDd() {
		return gBthDd;
	}

	public void setgBthDd(java.lang.String gBthDd) {
		this.gBthDd = gBthDd;
	}

	public String getPoliAdCd() {
		return poliAdCd;
	}

	public void setPoliAdCd(String poliAdCd) {
		this.poliAdCd = poliAdCd;
	}

	public String getPoliAdNm() {
		return poliAdNm;
	}

	public void setPoliAdNm(String poliAdNm) {
		this.poliAdNm = poliAdNm;
	}

	public String getGrnDd() {
		return grnDd;
	}

	public void setGrnDd(String grnDd) {
		this.grnDd = grnDd;
	}

	public String getCalTye() {
		return calTye;
	}

	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}

	public String getSysSgntInsp() {
		return sysSgntInsp;
	}

	public void setSysSgntInsp(String sysSgntInsp) {
		this.sysSgntInsp = sysSgntInsp;
	}

	public String getSysSgnt() {
		return sysSgnt;
	}

	public void setSysSgnt(String sysSgnt) {
		this.sysSgnt = sysSgnt;
	}
    
        
}
