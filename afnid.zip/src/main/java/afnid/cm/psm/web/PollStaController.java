package afnid.cm.psm.web;

import java.io.OutputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.psm.service.PollStaService;
import afnid.cm.psm.service.PollStaVO;
import afnid.cm.psm.service.VtrListVO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/** 
 * This Controller class processes request of Polling Station-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Daesung Kim 
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *  2013.05.15    		Daesung Kim          			Create
 *
 * </pre>
 */

@Controller
public class PollStaController {
	
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());
	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /** pollStaService */
	@Resource(name = "pollStaService")
    private PollStaService pollStaService;
	
	/** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
	/** nidCmmService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCmmService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** LgService */
	@Resource(name = "lgService")
    private LgService lgService;
	
    /**
     * Moved to list-screen of polling station. <br>
     * 
     * @param pollStaVO Value-object of polling station to be parsed request(pollStaVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/psm/PollingStationList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/psm/searchListPollStaView.do")
    public String searchListPollStaView(
    		@ModelAttribute("pollStaVO") PollStaVO pollStaVO,
    		ModelMap model)
            throws Exception { 
    	
    	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	        	
    	lgService.addUserWrkLg(user.getUserId(), pollStaVO.getCurMnId());
    	
    	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		cmCmmCd.setGrpCd("69"); //Pollign Station Type Code
		List<CmCmmCdVO> tyeCd = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
		model.addAttribute("tyeCd", tyeCd);
		
      	return "/cm/psm/PoliStatList";

    }
    
    /**
     * Retrieves list of polling station.  <br>
     * 
     * @param pollStaVO Value-object of polling station to be parsed request(pollStaVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/psm/PoliStatList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/psm/searchListPollSta.do")
    public String searchListPollSta(
    		@ModelAttribute("pollStaVO") PollStaVO pollStaVO,
    		ModelMap model)
            throws Exception { 
    	try{
    		
    	
    	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		cmCmmCd.setGrpCd("69"); 
		List<CmCmmCdVO> tyeCd = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
		model.addAttribute("tyeCd", tyeCd); 
    		
		cmCmmCd.setGrpCd("22"); // user language code
		List<CmCmmCdVO> langList = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
		model.addAttribute("langList", langList);  
		
		if("".equals(pollStaVO.getSearchKeyword6())){
			pollStaVO.setSearchKeyword6("1");
		}
    		
    	/**Paging Setting */
    	pollStaVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	pollStaVO.setPageSize(propertiesService.getInt("pageSize"));
    	
    	/** pageing */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(pollStaVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(pollStaVO.getPageUnit());
		paginationInfo.setPageSize(pollStaVO.getPageSize());

		pollStaVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		pollStaVO.setLastIndex(paginationInfo.getLastRecordIndex());
		pollStaVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		
		//Setting user Language
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		pollStaVO.setUseLangCd(user.getUseLangCd());

		//get polling station list
		List<PollStaVO> lstpollSta = pollStaService.searchListPollSta(pollStaVO);
		model.addAttribute("lstpollSta", lstpollSta);
		//get list total count
		int totCnt = pollStaService.searchListPollStaTotCnt(pollStaVO);
		paginationInfo.setTotalRecordCount(totCnt);			
		model.addAttribute("paginationInfo", paginationInfo);

		//pollStaVO.setSrchPoliAdCd(tmpPoliAdCd);
		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/cm/psm/PoliStatList";

    }
    
    /**
     * Moved to registration-screen of polling station. <br>
     * 
     * @param pollStaVO Value-object of polling station to be parsed request(PollStaVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return  Printed out JSP:  "/cm/psm/PoliStatiIns"
     * @exception Exception
     */
    @RequestMapping(value="/cm/psm/addPollStaView.do")
    public String addPollStaView(
    		@ModelAttribute("pollStaVO") PollStaVO pollStaVO,
			ModelMap model)
            throws Exception { 

    	try{  		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();// Common Code Value Object
    		cmCmmCd.setGrpCd("69"); // Setting Area Group Code
    		List<CmCmmCdVO> workKind = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code Interface Call    		
    		model.addAttribute("workKind", workKind);//Area Code List
    		
    		int kochiUprAdCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("kochiUprAdCd", kochiUprAdCd); 
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
 
		return "/cm/psm/PoliStatIns"; 
    }
    
    /**
     * Register information of new polling station. <br>
     * 
     * @param pollStaVO Value-object of polling station to be parsed request(pollStaVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : "/cm/psm/PoliStatList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/psm/addPollSta.do")
    public String addPollSta(
    		@ModelAttribute("pollStaVO") PollStaVO pollStaVO,
			ModelMap model)
            throws Exception {
    		
    	try {			
    			String tye = pollStaVO.getTye();	
    			PollStaVO vo = pollStaService.searchPollSta(pollStaVO);  
    			
    			String errCd = vo.getErrCd();

    			if("ERR01".equals(errCd)){
    				model.addAttribute("resultMsg", nidMessageSource.getMessage("nAddKochi.msg")); // Message Setting
    			}else if("ERR02".equals(errCd)){
    				String worKindNm = "";
    				CmCmmCdVO cmCmmCd = new CmCmmCdVO();// Common Code Value Object
    	    		cmCmmCd.setGrpCd("69"); // Setting Area Group Code
    	    		List<CmCmmCdVO> workKind = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code Interface Call 
    	    		
    	    		for(int i = 0 ; i < workKind.size();i++){
    	    			Object obj = workKind.get(i);
    	    			if(obj instanceof EgovMap){
    	    				EgovMap map =(EgovMap)obj;
    	    				String cmmCd = NidStringUtil.nullConvert(map.get("cmmCd"));
    	    				if(tye.equals(cmmCd)){
        	    				worKindNm = NidStringUtil.nullConvert(map.get("cmmCdNm"));
        	    			}
    	    			}
    	    		} 
    	    		model.addAttribute("resultMsg", nidMessageSource.getMessage("existSameNm.msg", new String[]{worKindNm})); // Message Setting
    			}else{
    				model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); // Message Setting
    			}

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    	return "forward:/cm/psm/searchListPollSta.do";
    	
    }
    
    /**
     * Moved to modification-screen of polling station. <br>
     * 
     * @param pollStaVO Value-object of polling station to be parsed request(PollStaVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/OrgInfoUpd.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/psm/modifyPollStaView.do")
    public String modifyPollStaView(
    		@ModelAttribute("pollStaVO") PollStaVO pollStaVO,
			ModelMap model)
            throws Exception {
    		
    	try {			
    			PollStaVO vo = pollStaService.searchPollStaInfr(pollStaVO);  
    			model.addAttribute("pollStaInfo", vo);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    	return "/cm/psm/PoliStatUdt";
    	
    }
    
    /**
	 * Modifies information of polling Station. <br>
	 * 
	 * @param pollStaVO Value-object of polling Station to be parsed request(PollStaVO)
	 * @param model Object to be parsed http request(ModelMap) 
	 * @return Printed out JSP: "/cm/psm/PoliStatList.jsp"
	 * @exception Exception
	 */
    @RequestMapping(value="/cm/psm/modifyPollSta.do")
    public String modifyPollSta(
    		@ModelAttribute("pollStaVO") PollStaVO pollStaVO,
			ModelMap model)
            throws Exception { 
    	try {
    		
    		PollStaVO result = pollStaService.modifyPollSta(pollStaVO);
    		String errCd = result.getErrCd();
    		if("ERR02".equals(errCd)){
    			String tyeNm = pollStaVO.getTyeNm();
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("existSameNm.msg", new String[]{tyeNm})); // Message Setting
    		}else{
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datUdtScsfl.msg")); // Message Setting
    		}
	    	
	   
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
		return "forward:/cm/psm/searchListPollSta.do"; 
    }
    
    /**
     * Delete information of polling station. <br>
     * 
     * @param pollStaVO Value-object of polling station to be parsed request(PollStaVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/psm/PoliStatList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/psm/dltPollSta.do")
    public String removePollSta(
    		@ModelAttribute("pollStaVO") PollStaVO pollStaVO,
			ModelMap model)
            throws Exception { 
    	
    	try {
    		int result = pollStaService.removePollSta(pollStaVO); 
	    	if(result == 1 ){
	    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datDltScsfl.msg")); // Message Setting
	    	}else{
	    		model.addAttribute("resultMsg", nidMessageSource.getMessage("ndltBychdRow.msg")); // Message Setting
	    		
	    	}
 		  		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "forward:/cm/psm/searchListPollSta.do"; 
    }
           
    /**
     * Retrieves list of polling station region.  <br>
     * 
     * @param regionInfoVO Value-object of region to be parsed request(RegionInfoVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:""
     * @exception Exception
     */
    @RequestMapping(value="/cm/psm/searchListPoliProvin.do")
    public void searchListPoliProvin(
    		@ModelAttribute("vtrListVO") VtrListVO vtrListVO,
			ModelMap model,
			HttpServletResponse response
			)
            throws Exception {
    	try {
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);

    		//Setting user Language
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vtrListVO.setUseLangCd(user.getUseLangCd());
    		Element adCode;
    		Element adName;
    		boolean pflag = vtrListVO.getpFlag();
    		boolean dflag = vtrListVO.getdFlag();
    		boolean aflag = vtrListVO.getaFlag();
    		boolean cflag = vtrListVO.getcFlag();

    		List<VtrListVO> poliAdList = null;
    		if(pflag){
    			poliAdList = pollStaService.searchListPoliProvin(vtrListVO);
    		}else if(dflag){
        		poliAdList = pollStaService.searchListPoliDstr(vtrListVO);
    		}else if(aflag){
    			poliAdList = pollStaService.searchListPoliAra(vtrListVO);
    		}else if(cflag){
    			poliAdList = pollStaService.searchListPoliCntr(vtrListVO);
    		}	
			
    		for(int i=0; i<poliAdList.size(); i++){
    			Element	araInfo = doc.createElement("araInfo");
    			root.appendChild(araInfo);
    			
    			adCode = doc.createElement("adCode");
    			adCode.appendChild(doc.createTextNode(poliAdList.get(i).getAdCode()));
    			
    			adName = doc.createElement("adName");
    			if(null == poliAdList.get(i).getAdName()){
    				adName.appendChild(doc.createTextNode(nidMessageSource.getMessage("none")));
    			}else{
    				adName.appendChild(doc.createTextNode(poliAdList.get(i).getAdName()));
    			}
    			
    			
    			araInfo.appendChild(adCode);
    			araInfo.appendChild(adName);
    		}
        		  
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);  		
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    /**
     * Retrieves Total Count of VoterList. <br>
     * 
     * @param voterLstVO Value-object of VoterList to be parsed request(voterLstVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/cm/psm/searchListTodayCnt.do")
    public void searchListTodayCnt(
    		@ModelAttribute("vtrListVO") VtrListVO vtrListVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {
    		
    	try {			
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		
			int cnt = pollStaService.searchListTodayCnt(vtrListVO);  		
			
    		Element	count = doc.createElement("count");
			root.appendChild(count);
			
			count.appendChild(doc.createTextNode(Integer.toString(cnt)));
				  
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);  		
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    }
    
    /**
     * Generate VoterList. <br>
     * 
     * @param vtrListVO Value-object of VoterList to be parsed request(vtrListVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : "/cm/psm/VoterLst.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/psm/gnrVtrList.do")
    public String gnrVtrList(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("vtrListVO") VtrListVO vtrListVO,
			ModelMap model)
            throws Exception {
    		
    	try {			
    		vtrListVO.setSearchKeyword4("");
    		ComDefaultVO comVo = new ComDefaultVO();
			comVo = nidCmmService.searchGreToDay(comVo);
			vtrListVO.setToDay(comVo.getStartDay().replaceAll("-", ""));
			vtrListVO.setGnrDd(comVo.getStartDay().replaceAll("-", ""));
			
			int cnt = pollStaService.gnrVtrList(vtrListVO);  
			
			if(cnt >0){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("gnrScsfl.msg")); //Message Setting
			} else {
				model.addAttribute("resultMsg", nidMessageSource.getMessage("gnrNoDat.msg"));
			}
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    	return "forward:/cm/psm/searchListVtrView.do";
    	
    }
    
    
    /**
     * Moved to list-screen of polling station. <br>
     * 
     * @param pollStaVO Value-object of polling station to be parsed request(pollStaVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/psm/PoliStatList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/psm/searchListVtrView.do")
    public String searchListVtrView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("vtrListVO") VtrListVO vtrListVO,
    		ModelMap model)
            throws Exception { 
    	try {
    		
        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	        	
        	lgService.addUserWrkLg(user.getUserId(), vtrListVO.getCurMnId());
	    	
	    	//getting today date
	    	ComDefaultVO comVo = new ComDefaultVO();
	    	
			comVo = nidCmmService.searchPerToDay(comVo);
			searchVO.setSearchKeyword(comVo.getStartDay().replaceAll("-", ""));
			searchVO.setSearchKeyword2("j");
			
			comVo = nidCmmService.searchGreToDay(comVo);
			model.addAttribute("greToDay", comVo.getStartDay());
			
	    	List<VtrListVO> lstVrtGnrDd = pollStaService.searchListCrnDd(vtrListVO);
	    	model.addAttribute("lstVrtGnrDd", lstVrtGnrDd);
	    	
			//setting common code
	    	CmCmmCdVO cmCmmCd = new CmCmmCdVO(); //Value Object 
			cmCmmCd.setGrpCd("10"); // Setting Group Gender Code
			List<CmCmmCdVO> gdrCd = cmmCdMngService.searchListCmmCdDesc(cmCmmCd); // Common Code Interface Call
			model.addAttribute("gdrCd", gdrCd);
    	
			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
      	return "/cm/psm/VtrList";

    }
    
    /**
     * Retrieves list of Voter. <br>
     * 
     * @param vtrListVO Value-object of VoterList to be parsed request(vtrListVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : "/cm/psm/VtrList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/psm/searchListVtr.do")
    public String searchListVtr(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("vtrListVO") VtrListVO vtrListVO,
			ModelMap model)
            throws Exception {
    		
    	try {		

    		String poliCntrCdTmp = vtrListVO.getPoliCntrCd();
    		
	    	List<VtrListVO> lstVrtGnrDd = pollStaService.searchListCrnDd(vtrListVO);
	    	model.addAttribute("lstVrtGnrDd", lstVrtGnrDd);
	    	
	    	//getting today date
	    	ComDefaultVO comVo = new ComDefaultVO();
	    	
			if("".equals(searchVO.getSearchKeyword2())){
				searchVO.setSearchKeyword2("j");
			}			
	    	
	    	comVo = nidCmmService.searchGreToDay(comVo);
			model.addAttribute("greToDay", comVo.getStartDay());
	    	
	    	//setting common code
	    	CmCmmCdVO cmCmmCd = new CmCmmCdVO(); //Value Object 
			cmCmmCd.setGrpCd("10"); // Setting Group Code
			List<CmCmmCdVO> gdrCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code Interface Call
			model.addAttribute("gdrCd", gdrCd);
	    	
			//setting common code

    		/** Paging Setting */
    		vtrListVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		vtrListVO.setPageSize(propertiesService.getInt("pageSize"));
    		 		
        	
        	/** pageing */
        	PaginationInfo paginationInfo = new PaginationInfo();
    		paginationInfo.setCurrentPageNo(vtrListVO.getPageIndex());
    		paginationInfo.setRecordCountPerPage(vtrListVO.getPageUnit());
    		paginationInfo.setPageSize(vtrListVO.getPageSize());

    		vtrListVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
    		vtrListVO.setLastIndex(paginationInfo.getLastRecordIndex());
    		vtrListVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
    		
    		//Setting user Language
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vtrListVO.setUseLangCd(user.getUseLangCd());
    		
    		//get polling voter list
    		List<VtrListVO> lstVoter = pollStaService.searchListVtr(vtrListVO);
    		model.addAttribute("lstVoter", lstVoter);
    		
    		//get list total count
    		int totCnt = pollStaService.searchListVtrTotCnt(vtrListVO);
    		paginationInfo.setTotalRecordCount(totCnt);
    		model.addAttribute("paginationInfo", paginationInfo);

    		vtrListVO.setPoliCntrCd(poliCntrCdTmp);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    	return "/cm/psm/VtrList";	
	
    }
    
    
    /**
     * Download Voter List to Excel. <br>
     * 
     * @param vtrListVO Value-object of VoterList to be parsed request(vtrListVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/cm/psm/downVtrListExcel.do")
    public void downVtrListExcel(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("vtrListVO") VtrListVO vtrListVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

    	try {
    		    		
    		vtrListVO.setSearchKeyword(vtrListVO.getSearchKeyword().replace("-", ""));
    		
    		if("j".equals(vtrListVO.getSearchKeyword2())){
    			vtrListVO.setSearchKeyword(NidStringUtil.toNumberConvet(vtrListVO.getSearchKeyword(), "g"));
    		}
        	 		
    		//Setting user Language
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vtrListVO.setUseLangCd(user.getUseLangCd());
    		
    		HSSFWorkbook wb = new HSSFWorkbook();

    		//setting key value for fill cell out in excel
    		List<String> keyId =  new ArrayList<String>();
    		keyId.add("rn");
    		keyId.add("rsdtNoDp");
    		keyId.add("name");
    		keyId.add("fthrNm");
    		keyId.add("curtAdCd");
    		keyId.add("curtAdCdNm");
    		keyId.add("curtAdDtlCt");
    		keyId.add("gdrCdNm");
    		keyId.add("bthDd");
    		keyId.add("poliCntrCd");
    		keyId.add("poliPrvicNm");
    		keyId.add("poliDstrNm");
    		keyId.add("poliAraNm");
    		keyId.add("poliCntrNm");
    		keyId.add("poliLcNm");
    		
    		//get total count of Male and female  
    		String searchKey = vtrListVO.getSearchKeyword3();
    		int reslutCntM = 0;
    		int reslutCntF = 0;
  
    		if("1".equals(searchKey)){
    			vtrListVO.setGdrCd(searchKey);
    			reslutCntM = pollStaService.searchListVtrExcelTotCnt(vtrListVO);
    		}
    		
    		if("2".equals(searchKey)){
    			vtrListVO.setGdrCd(searchKey);
    			reslutCntF = pollStaService.searchListVtrExcelTotCnt(vtrListVO);
    		}
    		
    		if(!"1".equals(searchKey) && !"2".equals(searchKey)){
    			vtrListVO.setGdrCd("1");
    			reslutCntM = pollStaService.searchListVtrExcelTotCnt(vtrListVO);
    			vtrListVO.setGdrCd("2");
    			reslutCntF = pollStaService.searchListVtrExcelTotCnt(vtrListVO);
    			
    		}
    		
    		//setting value in each cell
    		HSSFCell cell = null;
    		String id =null;
    		int totPage = 0;
    		String sheetName = "";
    		HSSFSheet sheet = null;
    		
    		if(reslutCntM > 0){
    			totPage = (int)Math.ceil((double)reslutCntM/1000); 
	
    			//Create Sheet
        		sheetName = nidMessageSource.getMessage("ml");
        		sheet = wb.createSheet(sheetName);	
        		setTitleAndHeaderForVtr(wb, sheet, vtrListVO );
        		vtrListVO.setGdrCd("1");
  
			}		
    		
    		CellStyle valStyleStr = getColumDataStyle(wb, vtrListVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleStrRed = getColumDataStyle(wb, vtrListVO.getUseLangCd(), false, false);
    		
    		for(int m=0; m<2; m++ ){
    			int sheetCnt = 1;
        		int row = 1;
        		
        		if(m == 1){
        			if(reslutCntF == 0){
    					totPage = 0;
    				}else{
    					totPage = (int)Math.ceil((double)reslutCntF/1000);
    					sheetName = nidMessageSource.getMessage("feml");
    	        		sheet = wb.createSheet(sheetName);	
    	        		setTitleAndHeaderForVtr(wb, sheet, vtrListVO );
    	        		vtrListVO.setGdrCd("2");
    				}
        		}
        		
        		for(int k=0;  k < totPage; k++){
        			vtrListVO.setFirstIndex(k*1000);
        			vtrListVO.setLastIndex(k+1);
        			vtrListVO.setRecordCountPerPage(1000);
        			
        			pollStaService.searchListVtrExcelSign(vtrListVO);

        			List<EgovMap> listValue = pollStaService.searchListVtrExcel(vtrListVO);
        			
        			for (int i = 0; i < listValue.size(); i++) {
        				EgovMap rowValue = listValue.get(i);				
        				
        				for(int j = 0; j< keyId.size(); j++){
        					cell = getCell(sheet, row+2, j);
        					id = keyId.get(j);
        					String sysSgntInsp = NidStringUtil.nullConvert(rowValue.get("sysSgntInsp"));
        					if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
        						setText(cell, NidStringUtil.nullConvert(rowValue.get(id)), valStyleStrRed);
        					}else{
        						setText(cell, NidStringUtil.nullConvert(rowValue.get(id)), valStyleStr);
        					}
        				}
        				row++;	
        				
        				if(60000 < row ){
        					
        					//create new sheet
        					sheet = wb.createSheet(sheetName+Integer.toString(sheetCnt+1));	
        					setTitleAndHeaderForVtr(wb, sheet, vtrListVO );
        					sheetCnt++;
        					row = 1;	
        				}
        			}
        			
        			listValue.clear();
        		}	
    		}

    		//setting File Name
    		String searchDate = vtrListVO.getSearchKeyword5();
    		searchDate = searchDate.replace("-", "");
    		String fileNm = vtrListVO.getPoliCntrCd()+"_"+searchDate+"_VoterList";
    		response.setHeader("Content-Disposition", "attachment; filename=" + fileNm+".xls");
    		
    		OutputStream os = response.getOutputStream();
    		wb.write(os);
    		  	 	
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    }
    
    /**
	 * Setting Title and Header on Sheet. <br>
	 * @param wb a HSSFWorkbook object.
	 * @param sheet a sheet object.
	 * @param excelvo the value for setting title and header
	 */
    private void setTitleAndHeaderForVtr(HSSFWorkbook wb, HSSFSheet sheet, VtrListVO vo)throws Exception{
		
		
    	//setting header of column in excel
		List<String> headerInfo =  new ArrayList<String>();
		headerInfo.add( nidMessageSource.getMessage("no"));
		headerInfo.add( nidMessageSource.getMessage("enid"));
		headerInfo.add( nidMessageSource.getMessage("nm"));
		headerInfo.add( nidMessageSource.getMessage("fthrNm"));
		headerInfo.add( nidMessageSource.getMessage("adCd"));
		headerInfo.add( nidMessageSource.getMessage("prsntAd"));
		headerInfo.add( nidMessageSource.getMessage("dtlAd"));
		headerInfo.add( nidMessageSource.getMessage("gdr"));
		headerInfo.add( nidMessageSource.getMessage("bthDd"));
		headerInfo.add( nidMessageSource.getMessage("poliStatCd"));
		headerInfo.add( nidMessageSource.getMessage("prvic"));
		headerInfo.add( nidMessageSource.getMessage("dstr"));
		headerInfo.add( nidMessageSource.getMessage("area"));
		headerInfo.add( nidMessageSource.getMessage("poliStat"));
		headerInfo.add( nidMessageSource.getMessage("lc"));

		//setting Column Width
		List<Integer> columnWidth = new ArrayList<Integer>();
		columnWidth.add(12);
		columnWidth.add(16);
		columnWidth.add(20);
		columnWidth.add(20);
		columnWidth.add(15);
		columnWidth.add(22);
		columnWidth.add(17);
		columnWidth.add(8);
		columnWidth.add(15);
		columnWidth.add(24);
		columnWidth.add(11);
		columnWidth.add(17);
		columnWidth.add(15);
		columnWidth.add(30);
		columnWidth.add(30);
		
		
		sheet.setDefaultColumnWidth(12);
		HSSFCell cell = null;
		//font setting
		HSSFFont font = wb.createFont();
		font.setFontHeightInPoints((short)20);
		font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		
		//style setting
		HSSFCellStyle style = wb.createCellStyle();		
		CellStyle titleStyle = getColumTitleStyle(wb, true, true);		
		style.setFont(font);
				
		// put Title in first cell
		cell = getCell(sheet, 0, 0);
		setText(cell, nidMessageSource.getMessage("vtrList"), titleStyle);		
		cell.setCellStyle(style);
		sheet.addMergedRegion(new CellRangeAddress(0,0,0,headerInfo.size()));
		
		//put polling station name
		if(null != vo.getPoliCntrNm() && !"".equals(vo.getPoliCntrNm())){
			cell = getCell(sheet, 1, 0);
			setText(cell, vo.getPoliCntrNm(), titleStyle);
			sheet.addMergedRegion(new CellRangeAddress(1,1,0,3));
		}
		
		//header font and style setting
		font = wb.createFont();
		style = wb.createCellStyle();
		cell = getCell(sheet, 2, 0);
		font.setFontHeightInPoints((short)12);
		font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		style.setFont(font);
		style.setFillForegroundColor(HSSFColor.AQUA.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		
		// set header information
		for(int i=0; i<headerInfo.size();i++){
			sheet.setColumnWidth(i, columnWidth.get(i)*256);
			cell = getCell(sheet, 2, i);
			cell.setCellStyle(style);
			setText(cell, headerInfo.get(i), titleStyle);
		}
		
	}
    
    /**
     * Download Polling Station List to Excel. <br>
     * 
     * @param pollStaVO Value-object of Polling Station to be parsed request(pollStaVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/cm/psm/downPollStaExcel.do")
    public void downPollStaExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("pollStaVO") PollStaVO pollStaVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

    	try {
    		    				
    		//Setting user Language
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		pollStaVO.setUseLangCd(user.getUseLangCd());
    		
    		
    		HSSFWorkbook wb = new HSSFWorkbook();
    		
    		//Create Sheet
    		String sheetName = nidMessageSource.getMessage("poliStat");
    		HSSFSheet sheet = wb.createSheet(sheetName);	
    		setTitleAndHeaderForPollSta(wb, sheet, pollStaVO );

    		//setting key value for fill cell out in excel
    		List<String> keyId =  new ArrayList<String>();
    		keyId.add("rn");
    		keyId.add("cd");
    		keyId.add("tyeNm");
    		/*
    		keyId.add("uprDplyNm");
    		keyId.add("pstNm");
    		keyId.add("drNm");
    		keyId.add("enNm");
    		keyId.add("pstLcNm");
    		keyId.add("drLcNm");
    		keyId.add("enLcNm");
    		*/
    		keyId.add("pstDplyNm");
    		keyId.add("drDplyNm");
    		keyId.add("enDplyNm");   
    		
    		if("Y".equals(pollStaVO.getSearchKeyword3())){
    			keyId.add("dltYn");
    		}
    		
    		
    		int reslutCnt = pollStaService.searchListPollStaExcelTotCnt(pollStaVO);
    		int totPage = (int)Math.ceil((double)reslutCnt/1000); 
    		
    		//setting value in each cell
    		HSSFCell cell = null;
    		String id =null;
    		String dltYn ="";
    		int sheetCnt = 1;
    		int row = 1;
    		
    		CellStyle valStyleStr = getColumDataStyle(wb, pollStaVO.getUseLangCd(), false, false, false);
    		
    		for(int k=0;  k < totPage; k++){
    			pollStaVO.setFirstIndex(k*1000);
    			pollStaVO.setLastIndex(k+1);
    			pollStaVO.setRecordCountPerPage(1000);
    		
	    		List<EgovMap> listValue = pollStaService.searchListPollStaExcel(pollStaVO);
	    		
	    		for (int i = 0; i < listValue.size(); i++) {
	    			EgovMap rowValue = listValue.get(i);				
	    			
	    			for(int j = 0; j< keyId.size(); j++){
	    				cell = getCell(sheet, row+2, j);
	    				id = keyId.get(j);
	    				if(!"dltYn".equals(id)){
	    					setText(cell, NidStringUtil.nullConvert(rowValue.get(id)), valStyleStr);	
	    				}else{
	    					dltYn = NidStringUtil.nullConvert(rowValue.get(id));
	    					if("N".equals(dltYn)){
	    						setText(cell, nidMessageSource.getMessage("nDlt"), valStyleStr);
	    					}else if("Y".equals(dltYn)){
	    						setText(cell, nidMessageSource.getMessage("Dlt"),valStyleStr);
	    					}
	    				}	
	    			}
	    			row++;	
	    			
	    			if(60000 < row ){
	    				
	    				//create new sheet
	    				sheet = wb.createSheet(sheetName+Integer.toString(sheetCnt+1));	
	    				setTitleAndHeaderForPollSta(wb, sheet, pollStaVO );
	    				sheetCnt++;
	    				row = 1;	
	    			}
	    		}
	    		
	    		listValue.clear();
    		}
    		OutputStream os = response.getOutputStream();
    		String fileNm = "";
    		String fileNm2 = "";
    		fileNm = pollStaVO.getSearchKeyword();
    		fileNm2 = pollStaVO.getSearchKeyword2();
    		if(!"".equals(fileNm2)){
    			fileNm = fileNm2+"_Polling_Station";	
    		}else if(!"".equals(fileNm)){
    			fileNm = fileNm+"_Polling_Station";
    		}else{
    			fileNm = "Polling_Station";
    		}
    		response.setHeader("Content-Disposition", "attachment; filename=" + fileNm+".xls");
    		wb.write(os);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    }
    
    /**
	 * Setting Title and Header on Sheet. <br>
	 * @param wb a HSSFWorkbook object.
	 * @param sheet a sheet object.
	 * @param excelvo the value for setting title and header
	 */
    private void setTitleAndHeaderForPollSta(HSSFWorkbook wb, HSSFSheet sheet, PollStaVO vo)throws Exception{
		
		
    	//setting header of column in excel
		List<String> headerInfo =  new ArrayList<String>();
		headerInfo.add( nidMessageSource.getMessage("no"));
		headerInfo.add( nidMessageSource.getMessage("poliStatCd"));
		headerInfo.add( nidMessageSource.getMessage("type"));
		/*
		headerInfo.add( nidMessageSource.getMessage("rgn"));
		headerInfo.add( nidMessageSource.getMessage("nmPst"));
		headerInfo.add( nidMessageSource.getMessage("nmDr"));
		headerInfo.add( nidMessageSource.getMessage("nmEn"));
		headerInfo.add( nidMessageSource.getMessage("lcPst"));
		headerInfo.add( nidMessageSource.getMessage("lcDr"));
		headerInfo.add( nidMessageSource.getMessage("lcEn"));
		headerInfo.add( nidMessageSource.getMessage("lcPst"));
		headerInfo.add( nidMessageSource.getMessage("lcDr"));
		headerInfo.add( nidMessageSource.getMessage("lcEn"));		
		*/
		headerInfo.add( nidMessageSource.getMessage("poliStatPst"));
		headerInfo.add( nidMessageSource.getMessage("poliStatDr"));
		headerInfo.add( nidMessageSource.getMessage("poliStatEn"));	
		
		if("Y".equals(vo.getSearchKeyword3())){
			headerInfo.add( nidMessageSource.getMessage("stus"));
		}

		//setting Column Width
		List<Integer> columnWidth = new ArrayList<Integer>();
		columnWidth.add(12);
		columnWidth.add(25);
		columnWidth.add(15);
		/*
		columnWidth.add(40);		
		columnWidth.add(30);
		columnWidth.add(30);
		columnWidth.add(30);
		columnWidth.add(30);
		columnWidth.add(30);
		columnWidth.add(30);
		*/
		columnWidth.add(80);
		columnWidth.add(80);
		columnWidth.add(80);
		
		if("Y".equals(vo.getSearchKeyword3())){
			columnWidth.add(12);
		}
		
		sheet.setDefaultColumnWidth(12);
		HSSFCell cell = null;
		//font setting
		HSSFFont font = wb.createFont();
		font.setFontHeightInPoints((short)20);
		font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		
		//style setting
		HSSFCellStyle style = wb.createCellStyle();
		style.setFont(font);
		
		CellStyle titleStyle = getColumTitleStyle(wb, true, true); 
				
		// put Title in first cell
		cell = getCell(sheet, 0, 0);
		setText(cell, nidMessageSource.getMessage("poliStat"), titleStyle);		
		cell.setCellStyle(style);
		sheet.addMergedRegion(new CellRangeAddress(0,0,0,headerInfo.size()-1));
		
		//header font and style setting
		font = wb.createFont();
		style = wb.createCellStyle();
		cell = getCell(sheet, 2, 0);
		font.setFontHeightInPoints((short)12);
		//font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		style.setFont(font);
		style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
   	 
		// set header information
		for(int i=0; i<headerInfo.size();i++){
			sheet.setColumnWidth(i, columnWidth.get(i)*256);
			cell = getCell(sheet, 2, i);
			cell.setCellStyle(style);
			setText(cell, headerInfo.get(i), titleStyle);
		}
		
	}
   
    /**
	 * Convenient method to obtain the cell in the given sheet, row and column.
	 * <p>Creates the row and the cell if they still doesn't already exist.
	 * Thus, the column can be passed as an int, the method making the needed downcasts.
	 * @param sheet a sheet object. The first sheet is usually obtained by workbook.getSheetAt(0)
	 * @param row thr row number
	 * @param col the column number
	 * @return the HSSFCell
	 */
    protected HSSFCell getCell(HSSFSheet sheet, int row, int col) {
		HSSFRow sheetRow = sheet.getRow(row);
		if (sheetRow == null) {
			sheetRow = sheet.createRow(row);
		}
		HSSFCell cell = sheetRow.getCell(col);
		if (cell == null) {
			cell = sheetRow.createCell(col);
		}
		return cell;
	}
    
    /**
	 * Convenient method to set a String as text content in a cell.
	 * @param cell the cell in which the text must be put
	 * @param text the text to put in the cell
	 */
	protected void setText(HSSFCell cell, String text, CellStyle valStyleStr) {
		cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		cell.setCellStyle(valStyleStr);
		cell.setCellValue(text);		
	}
	
    //Get Colum Title Style
    public  HSSFCellStyle getColumTitleStyle(HSSFWorkbook workbook,  boolean isBold, boolean isBG){
    	 HSSFCellStyle style = null;

    	 style = workbook.createCellStyle();

    	 style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
    	 style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
    	 
    	 if (isBG){
    		  style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
    		  style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    	 }
    	  
    	 style.setBorderBottom(CellStyle.BORDER_THIN);
    	 style.setBottomBorderColor(HSSFColor.BLACK.index);
    	 style.setBorderLeft(CellStyle.BORDER_THIN);
    	 style.setLeftBorderColor(HSSFColor.BLACK.index);
    	 style.setBorderRight(CellStyle.BORDER_THIN);
    	 style.setRightBorderColor(HSSFColor.BLACK.index);
    	 style.setBorderTop(CellStyle.BORDER_THIN);
    	 style.setTopBorderColor(HSSFColor.BLACK.index);
    	
    	 return style;    	 
    }
    
    	 
    //Get Colum Data Style
    public  HSSFCellStyle getColumDataStyle(HSSFWorkbook workbook,  String langType, boolean isBold, boolean isBG, boolean isNum){
    	HSSFCellStyle style = null;

    	style = workbook.createCellStyle();

    	style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);		
	 
    	if(isNum){
    		style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
    	} else {
    		if ("3".equals(langType)) {
    			style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
    		} else {
    			style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
    		}
    	}
	 
    	if (isBG){
		  style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
		  style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    	}
	  
    	style.setBorderBottom(CellStyle.BORDER_THIN);
    	style.setBottomBorderColor(HSSFColor.BLACK.index);
    	style.setBorderLeft(CellStyle.BORDER_THIN);
    	style.setLeftBorderColor(HSSFColor.BLACK.index);
    	style.setBorderRight(CellStyle.BORDER_THIN);
    	style.setRightBorderColor(HSSFColor.BLACK.index);
    	style.setBorderTop(CellStyle.BORDER_THIN);
    	style.setTopBorderColor(HSSFColor.BLACK.index);

	  return style;
    }
    
    
  //Get Colum Data Style
    public  HSSFCellStyle getColumDataStyle(HSSFWorkbook workbook,  String langType, boolean isBold, boolean isNum){
    	HSSFCellStyle style = null;

    	style = workbook.createCellStyle();

    	style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);		
	 
    	if(isNum){
    		style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
    	} else {
    		if ("3".equals(langType)) {
    			style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
    		} else {
    			style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
    		}
    	}
	 
    	style.setFillForegroundColor(HSSFColor.RED.index);
    	style.setFillPattern(CellStyle.SOLID_FOREGROUND);
	  
    	style.setBorderBottom(CellStyle.BORDER_THIN);
    	style.setBottomBorderColor(HSSFColor.BLACK.index);
    	style.setBorderLeft(CellStyle.BORDER_THIN);
    	style.setLeftBorderColor(HSSFColor.BLACK.index);
    	style.setBorderRight(CellStyle.BORDER_THIN);
    	style.setRightBorderColor(HSSFColor.BLACK.index);
    	style.setBorderTop(CellStyle.BORDER_THIN);
    	style.setTopBorderColor(HSSFColor.BLACK.index);

	  return style;
    }
    
}
