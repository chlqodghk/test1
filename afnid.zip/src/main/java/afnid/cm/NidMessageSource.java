package afnid.cm;

import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;

/**
 * Message for the use of resources and ReloadableResourceBundleMessageSource class implementation of MessageSource interface
 * @author Common Services team yimunjun
 * @since 2009.06.01
 * @version 1.0
 * @see
 *
 * <pre>
 * << Revision history(Modification Information) >>
 *   
 *   Modified      Modifiers           Modifications
 *  -------    --------    ---------------------------
 *   2009.03.11  Yimunjun         The first generation
 *
 * </pre>
 */

public class NidMessageSource extends ReloadableResourceBundleMessageSource implements MessageSource {

	private ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource;

	/**
	 * getReloadableResourceBundleMessageSource() 
	 * @param reloadableResourceBundleMessageSource - resource MessageSource
	 * @return ReloadableResourceBundleMessageSource
	 */	
	public void setReloadableResourceBundleMessageSource(ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource) {
		this.reloadableResourceBundleMessageSource = reloadableResourceBundleMessageSource;
	}
	
	/**
	 * getReloadableResourceBundleMessageSource() 
	 * @return ReloadableResourceBundleMessageSource
	 */	
	public ReloadableResourceBundleMessageSource getReloadableResourceBundleMessageSource() {
		return reloadableResourceBundleMessageSource;
	}
	
	/**
	 * Views defined messages
	 * @param code - Message Code
	 * @return String
	 */	
	public String getMessage(String code) {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		if("1".equals(user.getUseLangCd())){
			return getReloadableResourceBundleMessageSource().getMessage(code, null, new Locale("ps"));
		}else if("2".equals(user.getUseLangCd())){
			return getReloadableResourceBundleMessageSource().getMessage(code, null, new Locale("dr"));
		}else if("3".equals(user.getUseLangCd())){
			return getReloadableResourceBundleMessageSource().getMessage(code, null, new Locale("en"));
		}else {
			return getReloadableResourceBundleMessageSource().getMessage(code, null, new Locale("ps"));
		}
		
	}
	
	
	/**
	 * Views defined messages
	 * @param code - Message Code
	 * @return String
	 */	
	public String getMessage(String code, Object[] arg) {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		if("1".equals(user.getUseLangCd())){
			return getReloadableResourceBundleMessageSource().getMessage(code, arg, new Locale("ps"));
		}else if("2".equals(user.getUseLangCd())){
			return getReloadableResourceBundleMessageSource().getMessage(code, arg, new Locale("dr"));
		}else if("3".equals(user.getUseLangCd())){
			return getReloadableResourceBundleMessageSource().getMessage(code, arg, new Locale("en"));
		}else {
			return getReloadableResourceBundleMessageSource().getMessage(code, arg, new Locale("ps"));
		}
		
	}
	
	/**
	 * Views defined messages
	 * @param code - Message Code
	 * @return String
	 */	
	public String getMessage(String langCd, String code) {

		if("1".equals(langCd)){
			return getReloadableResourceBundleMessageSource().getMessage(code, null, new Locale("ps"));
		}else if("2".equals(langCd)){
			return getReloadableResourceBundleMessageSource().getMessage(code, null, new Locale("dr"));
		}else if("3".equals(langCd)){
			return getReloadableResourceBundleMessageSource().getMessage(code, null, new Locale("en"));
		}else {
			return getReloadableResourceBundleMessageSource().getMessage(code, null, new Locale("ps"));
		}
		
	}
	
	
	/**
	 * Views defined messages
	 * @param String, String, Object[]
	 * @return String
	 */	
	public String getMessage(String langCd, String code, Object [] arg) {
		if("1".equals(langCd)){
			return getReloadableResourceBundleMessageSource().getMessage(code, arg, new Locale("ps"));
		}else if("2".equals(langCd)){
			return getReloadableResourceBundleMessageSource().getMessage(code, arg, new Locale("dr"));
		}else if("3".equals(langCd)){
			return getReloadableResourceBundleMessageSource().getMessage(code, arg, new Locale("en"));
		}else {
			return getReloadableResourceBundleMessageSource().getMessage(code, arg, new Locale("ps"));
		}
		
	}

}
