package afnid.cm.uss.web;

import java.io.OutputStream;
import java.io.StringWriter;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.security.intercept.web.NidReloadableDefaultFilterInvocationDefinitionSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.error.ErrorHandler;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;

import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.uss.service.UserMngService;
import afnid.cm.uss.service.UserMngVO;
import afnid.cm.util.service.NidFileScrty;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
import afnid.cm.util.service.NidStringUtil;

/** 
 * This Controller class processes request of user-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.04.18
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.04.18  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */
@Controller
public class UserMngController {
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());
	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** userMngService */
	@Resource(name = "userMngService")
    private UserMngService userMngService;
	
	/** NidCommonService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCmmService;
	
    /** lgService */
	@Resource(name = "lgService")
    private LgService lgService;
	

	
	@Resource(name = "databaseObjectDefinitionSource")
	private NidReloadableDefaultFilterInvocationDefinitionSource databaseObjectDefinitionSource;
	
    /**
     * Moved to list-screen of user. <br>
     * 
     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
     * @param UserMngVO Value-object of user to be parsed request(UserMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/uss/UserList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/uss/searchListUserView.do")
    public String searchListUserView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("userMngVO") UserMngVO userMngVO,
    		ModelMap model)
            throws Exception { 

    	try {
    		
    		comDefaultVO.setSearchKeyword("L");
    		
    		//Common Code List
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO(); 

    		List<UserMngVO> lstAuthor = userMngService.searchListAthrView(userMngVO);    		
    		model.addAttribute("lstAuthor", lstAuthor); 
    		
    		//Organization Class Code List.
    		cmCmmCd.setGrpCd("25"); // Setting Group Code
    		List<CmCmmCdVO> lstOrgClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
    		model.addAttribute("lstOrgClsCd", lstOrgClsCd); 
    		
    		//Team List.
    		cmCmmCd.setGrpCd("23"); // Setting Group Code
    		List<CmCmmCdVO> lstTamCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
    		model.addAttribute("lstTamCd", lstTamCd); 
    		
        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();        	
        	lgService.addUserWrkLg(user.getUserId(), userMngVO.getCurMnId());    		
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "/cm/uss/UserList";
    }
    
    /**
     * Retrieves list of user.  <br>
     * 
     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
     * @param UserMngVO Value-object of user to be parsed request(UserMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/uss/UserList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/cm/uss/searchListUser.do")
    public String searchListUser(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("userMngVO") UserMngVO userMngVO,
    		ModelMap model)
            throws Exception { 

    	try {
    		//Common Code List
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO(); 

    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		userMngVO.setUseLangCd(user.getUseLangCd());
    		
    		userMngVO.setUserId(NidStringUtil.toNumberConvet(userMngVO.getSearchKeyword7(),"g"));
    		
    		List<UserMngVO> lstAuthor = userMngService.searchListAthrView(userMngVO);    		
    		model.addAttribute("lstAuthor", lstAuthor); 

		    if(!"".equals(userMngVO.getSrchOrgnzCd()) && "L".equals(userMngVO.getSearchKeyword())){
		    	
	            if( "00".equals(userMngVO.getSrchOrgnzCd().substring(2, 4)) ){
	            	userMngVO.setOficTye("1");
	            } else{
	            	userMngVO.setOficTye("2");
	            }		    	
		    }	

    		//Organization Class Code List.
    		cmCmmCd.setGrpCd("25"); // Setting Group Code
    		List<CmCmmCdVO> lstOrgClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
    		model.addAttribute("lstOrgClsCd", lstOrgClsCd); 
	    	
    		//Team List.
    		cmCmmCd.setGrpCd("23"); // Setting Group Code
    		List<CmCmmCdVO> lstTamCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
    		model.addAttribute("lstTamCd", lstTamCd); 
    		
	    	/** List Paging Setting */
    		userMngVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		userMngVO.setPageSize(propertiesService.getInt("pageSize"));
	
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(userMngVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(userMngVO.getPageUnit());
			paginationInfo.setPageSize(userMngVO.getPageSize());
	
			userMngVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			userMngVO.setLastIndex(paginationInfo.getLastRecordIndex());
			userMngVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
	        List<UserMngVO> lstUser = userMngService.searchListUser(userMngVO);
	        model.addAttribute("lstUser", lstUser);

	        UserMngVO userList =  new UserMngVO();
	        
    		for(int i=0; i<lstUser.size(); i++ ){
    			userList = lstUser.get(i);
    			userMngVO.setUserSeqNo(userList.getUserSeqNo());
    			List<UserMngVO> lstUserAthr = userMngService.searchListUserAthr(userMngVO);
    			userList.setLstUserAthrNm(lstUserAthr);
    			userList.setAthrCnt( String.valueOf(lstUserAthr.size()) );
    		}
    		    		
	        int totCnt = userMngService.searchListUserTotCnt(userMngVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "/cm/uss/UserList";

    }
	
	/**
     * Moved to registration-screen of user. <br>
     * 
     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
     * @param UserMngVO Value-object of user to be parsed request(UserMngVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return  Printed out JSP:  "/cm/uss/UserIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/uss/addUserView.do")
    public String addUserView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefault,
    		@ModelAttribute("userMngVO") UserMngVO userMngVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	try {
    		ComDefaultVO comDefaultVO = comDefault;
	    	//Common Code List
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); 
    		
    		//Organization Class Code List.
    		cmCmmCd.setGrpCd("25"); // Setting Group Code
    		List<CmCmmCdVO> lstOrgClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("lstOrgClsCd", lstOrgClsCd); 
    		
    		//Team List.
    		cmCmmCd.setGrpCd("23"); // Setting Group Code
    		List<CmCmmCdVO> lstTamCd = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("lstTamCd", lstTamCd); 
    		
    		//Gender List.
    		cmCmmCd.setGrpCd("10"); // Setting Gender Code
    		List<CmCmmCdVO> lstGdrCd = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("lstGdrCd", lstGdrCd); 
    		
			comDefaultVO = nidCmmService.searchPerToDay(userMngVO);
			userMngVO.setEtrcDd(comDefaultVO.getStartDay()); 
			model.addAttribute("userMngVO", userMngVO);

			//Roll List
			List<UserMngVO> lstAuthor = userMngService.searchListAthr(userMngVO); 
			model.addAttribute("lstAuthor", lstAuthor);	
		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

		return "/cm/uss/UserIns";      
    }    
    
    
    /**
     * Register information of new user. <br>
     * 
     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
     * @param UserMngVO Value-object of user to be parsed request(UserMngVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/uss/UserList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/uss/addUser.do")
    public String addUser(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("userMngVO") UserMngVO userMngVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception {
    	try {
 
    		UserMngVO vo = new UserMngVO();
    		vo = userMngService.addUser(userMngVO); 	    	
    		log.debug("vo.getLgSeqNo() ====> " + vo.getLgSeqNo());
    		log.debug("vo.getUserId() ====> " + vo.getUserId());
    		log.debug("vo.getEnNm()   ====> "+vo.getEnNm());
    		log.debug("vo.getEml() ====> " + vo.getEml());
    		
    		String pkiResult = userMngService.addUserPkiIf(vo);    		
    		log.debug("pkiResult ====> " + pkiResult);
    		
    		
    		if(!"0".equals(pkiResult)){
    			String helpTelNo = nidMessageSource.getMessage("admTelNo");
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{pkiResult, helpTelNo}));
    		} else {
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}
    		
    		databaseObjectDefinitionSource.reloadRequestMap();    		
	    	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));  
    		databaseObjectDefinitionSource.reloadRequestMap();
    	} 
    	
    	return  "forward:/cm/uss/searchListUser.do";        
    }      
    
    /**
     * Moved to modification-screen of user. <br>
     * 
     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
     * @param progrmManageVO Value-object of user to be parsed request(UserMngVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/uss/UserUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/uss/modifyUserView.do")
    public String modifyUserView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("userMngVO") UserMngVO vo,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	
    	try {
    		//Common Code List
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO(); 

    		//Organization Class Code List.
    		cmCmmCd.setGrpCd("25"); // Setting Group Code
    		List<CmCmmCdVO> lstOrgClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
    		model.addAttribute("lstOrgClsCd", lstOrgClsCd); 
    		
    		//Team List.
    		cmCmmCd.setGrpCd("23"); // Setting Group Code
    		List<CmCmmCdVO> lstTamCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
    		model.addAttribute("lstTamCd", lstTamCd); 
    		
    		//Gender List.
    		//Gender List.
    		cmCmmCd.setGrpCd("10"); // Setting Gender Code
    		List<CmCmmCdVO> lstGdrCd = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("lstGdrCd", lstGdrCd); 
    		
    		UserMngVO userMngVO = userMngService.searchUser(vo);
    		model.addAttribute("userMngVO", userMngVO); 
    		
			//Roll List
			List<UserMngVO> lstAuthor = userMngService.searchListAthr(vo); 
			model.addAttribute("lstAuthor", lstAuthor);		
			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
        return "/cm/uss/UserUdt"; 

    }    
     
    /**
     * Modifies information of user. <br>
     * 
     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
     * @param progrmManageVO Value-object of user to be parsed request(UserMngVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/uss/UserList"
     * @exception Exception
     */
    @RequestMapping(value="/cm/uss/modifyUser.do")
    public String modifyUser(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("userMngVO") UserMngVO userMngVO,
			BindingResult bindingResult,
			ModelMap model) throws Exception {
    	
    	try {
    		
    		UserMngVO vo = new UserMngVO();    		
    		vo = userMngService.modifyUser(userMngVO); 
    		log.debug("vo.getLgSeqNo1() ====> " + vo.getLgSeqNo1());
    		log.debug("vo.getLgSeqNo2() ====> " + vo.getLgSeqNo2());
    		log.debug("vo.getUserId() ====> " + vo.getUserId());
    		log.debug("vo.getEnNm() ====> " + vo.getEnNm()); 
    		log.debug("vo.getEml() ====> " + vo.getEml());    
    		
    		
    		if((vo.getLgSeqNo1() != null && !"".equals(vo.getLgSeqNo1())) || 
    		   (vo.getLgSeqNo2() != null && !"".equals(vo.getLgSeqNo2())) ){
	    		String pkiResult = userMngService.modifyUserPkiIf(vo);
	    		log.debug("pkiResult ====> " + pkiResult);
	    		
	    		if(!"0".equals(pkiResult)){
	    			String helpTelNo = nidMessageSource.getMessage("admTelNo");
	    			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{pkiResult, helpTelNo}));
	    		} else {
	    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
	    		}
	    		
    		} else {
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}

			databaseObjectDefinitionSource.reloadRequestMap();
		
    	} catch (Exception e) {    		
			log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    		databaseObjectDefinitionSource.reloadRequestMap();
    		
    	}
    	
    	return  "forward:/cm/uss/searchListUser.do";       
    }

    /**
     * user retirement. <br>
     * 
     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
     * @param progrmManageVO Value-object of user to be parsed request(UserMngVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/uss/UserList"
     * @exception Exception
     */
    @RequestMapping(value="/cm/uss/modifyUserRtmt.do")
    public String modifyUserRtmt(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("userMngVO") UserMngVO userMngVO,
			BindingResult bindingResult,
			ModelMap model)throws Exception  {
    	
    	try {
    		
    		UserMngVO vo = new UserMngVO();    		
    		vo = userMngService.modifyUserRtmt(userMngVO); 
    		log.debug("vo.getLgSeqNo() ====> " + vo.getLgSeqNo());
    		log.debug("vo.getUserId() ====> " + vo.getUserId());
    		String pkiResult = userMngService.modifyUserRtmtPkiIf(vo);
    		log.debug("pkiResult ====> " + pkiResult);
    		
    		if(!"0".equals(pkiResult)){
    			String helpTelNo = nidMessageSource.getMessage("admTelNo");
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{pkiResult, helpTelNo}));
    		} else {
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}
		
    	} catch (Exception e) {     		
			log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    	return  "forward:/cm/uss/searchListUser.do";       
    }    
    
    /**
     * User PKI Cert hold. <br>
     * 
     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
     * @param progrmManageVO Value-object of user to be parsed request(UserMngVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/uss/UserList"
     * @exception Exception
     */
    @RequestMapping(value="/cm/uss/modifyUserHold.do")
    public String modifyUserHold(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("userMngVO") UserMngVO userMngVO,
			BindingResult bindingResult,
			ModelMap model) throws Exception {

    	try {
    		
    		UserMngVO vo = new UserMngVO();
    		
    		vo = userMngService.modifyUserHold(userMngVO); 
    		log.debug("vo.getLgSeqNo() ====> " + vo.getLgSeqNo());
    		log.debug("vo.getUserId() ====> " + vo.getUserId());
    		String pkiResult = userMngService.modifyUserHoldPkiIf(vo);

    		log.debug("================================================");
    		log.debug("pkiResult ====> " + pkiResult);    		
    		log.debug("================================================");
    		if(!"0".equals(pkiResult)){
    			String helpTelNo = nidMessageSource.getMessage("admTelNo");
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{pkiResult, helpTelNo}));
    		} else {
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}
		
    	} catch (Exception e) {
			log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    	return  "forward:/cm/uss/searchListUser.do";       
    }  
    
    /**
     * User PKI Cert Unhold. <br>
     * 
     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
     * @param progrmManageVO Value-object of user to be parsed request(UserMngVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/uss/UserList"
     * @exception Exception
     */
    @RequestMapping(value="/cm/uss/modifyUserUnhold.do")
    public String modifyUserUnhold(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("userMngVO") UserMngVO userMngVO,
			BindingResult bindingResult,
			ModelMap model) throws Exception {

    	try {
    		UserMngVO vo = new UserMngVO();    		
    		vo = userMngService.modifyUserUnhold(userMngVO); 
    		log.debug("vo.getLgSeqNo() ====> " + vo.getLgSeqNo());
    		log.debug("vo.getUserId() ====> " + vo.getUserId()); 
    		String pkiResult = userMngService.modifyUserUnholdPkiIf(vo);

    		log.debug("================================================");
    		log.debug("pkiResult ====> " + pkiResult);    		
    		log.debug("================================================");
    		if(!"0".equals(pkiResult)){
    			String helpTelNo = nidMessageSource.getMessage("admTelNo");
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{pkiResult, helpTelNo}));
    		} else {
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}
		
    	} catch (Exception e) {
			log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));  
    	}
    	
    	return  "forward:/cm/uss/searchListUser.do";       
    } 

    
    /**
     * Modifies user password <br>
     * 
     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
     * @param progrmManageVO Value-object of user to be parsed request(UserMngVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/uss/p_PwdChng"
     * @exception Exception
     */
    @RequestMapping(value="/cm/uss/modifyPwdChngView.do")
    public String modifyPwdChngView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("userMngVO") UserMngVO userMngVO,
			BindingResult bindingResult,
			ModelMap model) throws Exception {

    	return "/cm/uss/p_PwdChng"; 
    }    
    
    /**
     * Update information of user password. <br>
     * 
     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
     * @param progrmManageVO Value-object of user to be parsed request(UserManageVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/uss/p_PwdChng"
     * @exception Exception
     */
	@RequestMapping(value="/cm/uss/modifyPwdChng.do")
	public String modifyPwdChng(@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("userPasswordVO") UserMngVO userMngVO,
			ModelMap model) {
		try {
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			userMngVO.setUserId(user.getUserId()); 
			userMngVO.setUserSeqNo(user.getUserSeqNo());
			// Encrypt User Password			
    		String enPwd  = NidFileScrty.encryptPassword(userMngVO.getOldPwd());
    		String newPwd = NidFileScrty.encryptPassword(userMngVO.getPwd());
    		String pwd    = userMngService.searchUserPwd(userMngVO).getPwd();

    		if(!enPwd.equals(pwd)) {
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("prePwdEror.msg")); 			
    			return "forward:/cm/uss/modifyPwdChngView.do"; 
    		}

    		List<UserMngVO> lstPwd = userMngService.searchListUserPwdHst(userMngVO);
    		for(UserMngVO userVO:lstPwd){
    			if(newPwd.equals(userVO.getPwd())){
    				model.addAttribute("resultMsg", nidMessageSource.getMessage("pwdChgRecy.msg"));
    				return "forward:/cm/uss/modifyPwdChngView.do"; 
    			}
    		}

    		userMngService.modifyUserPwd(userMngVO);
			
			comDefaultVO.setSearchKeyword("Y");
			model.addAttribute("resultMsg", nidMessageSource.getMessage("pwdSave.msg"));
		} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
		
		return "/cm/uss/p_PwdChng";
	}    
	
	 /**
	 * Moved to list-screen of program. <br>
	 * 
	 * @param progrmManageVO Value-object of program to be parsed request(ProgrmManageVO)
	 * @param model Object to be parsed http request(ModelMap) 
	 * @return Printed out JSP: "/cm/uss/LgnErrUserList"
	 * @exception Exception
	 */
	 @RequestMapping(value="/cm/uss/searchListLgnErorUserView.do")
	 public String searchListLgnErorUserView(
	    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
	    		@ModelAttribute("userMngVO") UserMngVO userMngVO,
	 		    ModelMap model)
	         throws Exception { 
	
	 	try {

	 		/*
	 		userMngVO.setUserId(user.getUserId());
	 		userMngVO.setAthrSeqNo("5");
	 		

	 		int athrCn=userMngService.searchAthrCn(userMngVO);
	 		model.addAttribute("athrCn", athrCn);
	 		*/
	 		
	 		comDefaultVO.setSearchKeyword7("5");	 		
    		comDefaultVO.setSearchKeyword4("L");
    			
    		
	 		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
	 		
    		//Organization Class Code List.
    		cmCmmCd.setGrpCd("25"); // Setting Group Code
    		List<CmCmmCdVO> lstOrgClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("lstOrgClsCd", lstOrgClsCd); 
    		
	 		cmCmmCd.setGrpCd("31"); // login Fail count 
	 		List<CmCmmCdVO> lstCntCd = cmmCdMngService.searchListCmmCd(cmCmmCd);
	 		model.addAttribute("lstCntCd", lstCntCd);
	 		
        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();        	
        	lgService.addUserWrkLg(user.getUserId(), userMngVO.getCurMnId()); 	 		

	 	} catch (Exception e) {
	 		log.error(e.getMessage(), e);
	 		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
	 	}
	
	   	return "/cm/uss/LgnErrUserList";
		
	}
	 
		/**
	     * Retrieves list of program.  <br>
	     * 
	     * @param progrmManageVO Value-object of program to be parsed request(ProgrmManageVO)
	     * @param model Object to be parsed http request(ModelMap) 
	     * @return Printed out JSP: "/cm/uss/LgnErrUserList.jsp"
	     * @exception Exception
	     */
		@RequestMapping(value="/cm/uss/searchListLgnUserEror.do")
	    public String searchListLgnUserEror(
	       		@ModelAttribute("searchVO") ComDefaultVO searchVO,
	       		@ModelAttribute("userMngVO") UserMngVO userMngVO,
	    		ModelMap model)
	            throws Exception { 

	    	try {
    		
			    if(!"".equals(userMngVO.getOrgnzCd()) && "L".equals(userMngVO.getSearchKeyword4())){
			    	
		            if( "00".equals(userMngVO.getOrgnzCd().substring(2, 4)) ){
		            	userMngVO.setOficTye("1");
		            } else{
		            	userMngVO.setOficTye("2");
		            }		    	
			    }	
			    	    		
	    		if("".equals(searchVO.getSearchKeyword6())){
	    			searchVO.setSearchKeyword6("j");    			
	    		}
	    		
	    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();

		 		userMngVO.setUserId(user.getUserId());
		 		userMngVO.setAthrSeqNo("5");
		 		
		 		/*
		 		int athrCn=userMngService.searchAthrCn(userMngVO);
		 		model.addAttribute("athrCn", athrCn);
		 		*/
	    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
	    		
	    		//Organization Class Code List.
	    		cmCmmCd.setGrpCd("25"); // Setting Group Code
	    		List<CmCmmCdVO> lstOrgClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd);
	    		model.addAttribute("lstOrgClsCd", lstOrgClsCd);
	    		
	    		cmCmmCd.setGrpCd("31"); // 
	    		List<CmCmmCdVO> lstCntCd = cmmCdMngService.searchListCmmCd(cmCmmCd);
	    		model.addAttribute("lstCntCd", lstCntCd);

		 		/** List Paging Setting */
		 		userMngVO.setPageUnit(propertiesService.getInt("pageUnit"));
		 		userMngVO.setPageSize(propertiesService.getInt("pageSize"));
		
		    	/** pageing */
		    	PaginationInfo paginationInfo = new PaginationInfo();
				paginationInfo.setCurrentPageNo(userMngVO.getPageIndex());
				paginationInfo.setRecordCountPerPage(userMngVO.getPageUnit());
				paginationInfo.setPageSize(userMngVO.getPageSize());
		
				userMngVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
				userMngVO.setLastIndex(paginationInfo.getLastRecordIndex());
				userMngVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
				
		        List<UserMngVO> lstUserUsage = userMngService.searchListLgnUserEror(userMngVO);
		        model.addAttribute("lstUserUsage", lstUserUsage);
		
		        int totCnt = userMngService.searchListLgnUserErorTotCn(userMngVO);
				paginationInfo.setTotalRecordCount(totCnt);
		        model.addAttribute("paginationInfo", paginationInfo);
		        

	    	} catch (Exception e) {
	    		log.error(e.getMessage(), e);
	    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
	    	}

	      	return "/cm/uss/LgnErrUserList";

	    }
		
		
	    /**
	     * user reactivate.  <br>
	     * 
	     * @param UserMngVO user reactivate 
	     * @param model Object to be parsed http request(ModelMap) 
	     * @return Printed out JSP:"LgnErrUserList.jsp"
	     * @exception Exception
	     */			
		@RequestMapping(value="/cm/uss/modifyuserReatv.do")
	    public String modifyuserReatv(
	       		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
	    		@ModelAttribute("userMngVO") UserMngVO userMngVO,
	    		BindingResult bindingResult,
	    		ModelMap model)
	            throws Exception { 
		 			
	    	try {
	    		
	    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		    		
	    		
	    		userMngVO.setLstUdtUserId(user.getUserId());
	    		
	    		userMngVO.setUserId(userMngVO.getUserId());
	    		
	    		String pwd = NidFileScrty.encryptPassword(userMngVO.getUserId()+"xx");
	    		
	    		userMngVO.setPwd(pwd);
	    		
	    		userMngService.modifyuserReatv(userMngVO);
	    		
	    		model.addAttribute("resultMsg", nidMessageSource.getMessage("userReatv.msg")); 
	    	} catch (Exception e) {
	    		log.error(e.getMessage(), e);
	    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
	    	}
	    	
	    	return "forward:/cm/uss/searchListLgnUserEror.do"; 

	    }
		 
		
	    /**
	     * Retrieves list of organization.  <br>
	     * 
	     * @param regionInfoVO Value-object of region to be parsed request(UserMngVO)
	     * @param model Object to be parsed http request(ModelMap) 
	     * @return Printed out JSP:""
	     * @exception Exception
	     */	
	    @RequestMapping(value="/cm/uss/searchListDstr.do")
	    public void searchListDstr(
	    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
	       		@ModelAttribute("userMngVO") UserMngVO userMngVO,
				ModelMap model,
				HttpServletResponse response
				)
	            throws Exception {
	    	try {
	    		
	    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
	    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
	    		Document doc = docBuilder.newDocument();
	    		Element root = doc.createElement("root");
	    		doc.appendChild(root);
	    		
	    		//Setting user Language
	    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
	    		userMngVO.setUseLangCd(user.getUseLangCd());

	    		Element orgnzCd;
	    		Element orgnzCdNm;

	    		List<UserMngVO> orgnzList = null;
	    		
	    		orgnzList = userMngService.searchListDstr(userMngVO);
	    		
	    		for(int i=0; i<orgnzList.size(); i++){
	    			Element	orgInfo = doc.createElement("orgInfo");
	    			root.appendChild(orgInfo);
	    			
	    			orgnzCd = doc.createElement("orgnzCd");
	    			orgnzCd.appendChild(doc.createTextNode(orgnzList.get(i).getOrgnzCd()));
	    			
	    			orgnzCdNm = doc.createElement("orgnzCdNm");
	    			orgnzCdNm.appendChild(doc.createTextNode(orgnzList.get(i).getOrgnzNm()));
	    			
	    			orgInfo.appendChild(orgnzCd);
	    			orgInfo.appendChild(orgnzCdNm);
	    		}
	    		        		  
	    		Properties output = new Properties();
	    	    output.setProperty(OutputKeys.INDENT, "yes");
	    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
	    	    TransformerFactory tf = TransformerFactory.newInstance();
	    		Transformer t = tf.newTransformer();
	    	    t.setOutputProperties(output);
	    		StringWriter sw = new StringWriter();
	    		StreamResult result = new StreamResult(sw);
	    		DOMSource source = new DOMSource(doc);  		
	    		t.transform(source, result);    		
	    		response.setContentType("text/xml; charset=utf-8");
	    		response.getWriter().write(sw.toString());
	    		
	    	} catch (Exception e) {
	    		log.error(e.getMessage(), e);
	    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
	    	}
	    }    		
	 
	    /**
	     * Moved to list-screen of number of officers. <br>
	     * 
	     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
	     * @param UserMngVO Value-object of user to be parsed request(UserMngVO)
	     * @param model Object to be parsed http request(ModelMap) 
	     * @return Printed out JSP: "/cm/uss/UserList.jsp"
	     * @exception Exception
	     */
	    @RequestMapping(value="/cm/uss/searchListUserNoView.do")
	    public String searchListUserNoView(
	    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
	    		@ModelAttribute("userMngVO") UserMngVO userMngVO,
	    		ModelMap model)
	            throws Exception { 

	    	try {
	    		//Common Code List
	    		CmCmmCdVO cmCmmCd = new CmCmmCdVO(); 

	    		cmCmmCd.setGrpCd("25"); // Setting Group Code
	    		List<CmCmmCdVO> lstOrgClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
	    		model.addAttribute("lstOrgClsCd", lstOrgClsCd);
	    		
	    		List<UserMngVO> lstAuthor = userMngService.searchListAthrView(userMngVO);    		
	    		model.addAttribute("lstAuthor", lstAuthor); 
	    		
	        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();        	
	        	lgService.addUserWrkLg(user.getUserId(), userMngVO.getCurMnId());    		
	    		
	        	comDefaultVO.setSearchKeyword4("L");
	        	
	    	} catch (Exception e) {
	    		log.error(e.getMessage(), e);
	    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
	    	}

	      	return "/cm/uss/UserNoList";
	    }
	    
	    /**
	     * Retrieves number of officers.  <br>
	     * 
	     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
	     * @param UserMngVO Value-object of user to be parsed request(UserMngVO)
	     * @param model Object to be parsed http request(ModelMap) 
	     * @return Printed out JSP: "/cm/uss/UserNoList.jsp"
	     * @exception Exception
	     */
		@RequestMapping(value="/cm/uss/searchListUserNo.do")
	    public String searchListUserNo(
	    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
	    		@ModelAttribute("userMngVO") UserMngVO userMngVO,
	    		ModelMap model)
	            throws Exception { 

	    	try {
	    		//Common Code List
	    		CmCmmCdVO cmCmmCd = new CmCmmCdVO(); 

	    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
	    		userMngVO.setUseLangCd(user.getUseLangCd());
	    		
			    if(!"".equals(userMngVO.getOrgnzCd()) && "L".equals(userMngVO.getSearchKeyword4())){
			    	
		            if( "00".equals(userMngVO.getOrgnzCd().substring(2, 4)) ){
		            	userMngVO.setOficTye("1");
		            } else{
		            	userMngVO.setOficTye("2");
		            }		    	
			    }	    		
	    			    		
	    		cmCmmCd.setGrpCd("25"); // Setting Group Code
	    		List<CmCmmCdVO> lstOrgClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
	    		model.addAttribute("lstOrgClsCd", lstOrgClsCd); 
	    		
	    		List<UserMngVO> lstAuthor = userMngService.searchListAthrView(userMngVO);    		
	    		model.addAttribute("lstAuthor", lstAuthor); 
	    		

		    	
		    	/** List Paging Setting */
	    		userMngVO.setPageUnit(propertiesService.getInt("pageUnit"));
	    		userMngVO.setPageSize(propertiesService.getInt("pageSize"));
		
		    	/** pageing */
		    	PaginationInfo paginationInfo = new PaginationInfo();
				paginationInfo.setCurrentPageNo(userMngVO.getPageIndex());
				paginationInfo.setRecordCountPerPage(userMngVO.getPageUnit());
				paginationInfo.setPageSize(userMngVO.getPageSize());
		
				userMngVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
				userMngVO.setLastIndex(paginationInfo.getLastRecordIndex());
				userMngVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
				
		        List<UserMngVO> lstUser = userMngService.searchListUserNo(userMngVO);
		        model.addAttribute("lstUser", lstUser);

		        int totCnt = userMngService.searchListUserNoTotCnt(userMngVO);
				paginationInfo.setTotalRecordCount(totCnt);
		        model.addAttribute("paginationInfo", paginationInfo);

	    	} catch (Exception e) {
	    		log.error(e.getMessage(), e);
	    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
	    	}

	      	return "/cm/uss/UserNoList";

	    }	  
		
	    /**
	     *  Download Statistic  of Population by Present address to Excel.<br>
	     * 
	     * @param StsPpltPrsAdVO Value-object of Statistic  of Population by Present address to be parsed request(stsSrchVO)
	     * @param model Object to be parsed http request(ModelMap) 
	     * @return Printed out : ""
	     * @exception Exception
	     */
	    @RequestMapping(value="/cm/uss/searchListUserNoDownExcel.do")
	    public void searchListUserNoDownExcel(
	    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
	    		@ModelAttribute("userMngVO") UserMngVO userMngVO,
	    		HttpServletResponse response,
				ModelMap model)
	            throws Exception {

			OutputStream os = null;
			HSSFWorkbook workbook = null;
			HSSFSheet sheet = null;
			HSSFRow row = null;
			HSSFRow row1 = null;
			HSSFCell cell = null;
			
	    	try {
	    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
	    		userMngVO.setUseLangCd(user.getUseLangCd());
	
	    		String stsTitle = "Number of Officers";

			    if(!"".equals(userMngVO.getOrgnzCd()) && "L".equals(userMngVO.getSearchKeyword4())){
			    	
		            if( "00".equals(userMngVO.getOrgnzCd().substring(2, 4)) ){
		            	userMngVO.setOficTye("1");
		            } else{
		            	userMngVO.setOficTye("2");
		            }		    	
			    }	
			    
	    		List<UserMngVO> lstProgram = userMngService.searchListUserNoExcel(userMngVO);		

	    		
	    		workbook = new HSSFWorkbook();
	    		sheet = workbook.createSheet("sheet1");
	    		
	    		sheet.setColumnWidth(0, 14 * 256);
	    		sheet.setColumnWidth(1, 40 * 256);
	    		sheet.setColumnWidth(2, 20 * 256);
	    		sheet.setColumnWidth(3, 30 * 256);
	    		sheet.setColumnWidth(4, 14 * 256);
	    		sheet.setColumnWidth(5, 14 * 256);

	    		row = sheet.createRow((short)0);
	    		row.setHeightInPoints(25);
	    		
	    		sheet.addMergedRegion(new CellRangeAddress(0,0,0,4) );
	    		cell = row.createCell(0);    		
	    		cell.setCellStyle(getTitleStyle(workbook));
	    		cell.setCellValue(stsTitle); 
	    		
	    		row1 = sheet.createRow((short)1);
	    		row1.setHeightInPoints(18);

	    		String[] title = { nidMessageSource.getMessage("sys")
				                  ,nidMessageSource.getMessage("ofic")
	    				          ,nidMessageSource.getMessage("tamNo")
	    				          ,nidMessageSource.getMessage("role")
	    				          ,nidMessageSource.getMessage("ml")
	    				          ,nidMessageSource.getMessage("feml")
	    				          };
	    		
	            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
	    		CellStyle valStyleStr = getColumDataStyle(workbook, userMngVO.getUseLangCd(), false, false, false);
	    		CellStyle valStyleNum = getColumDataStyle(workbook, userMngVO.getUseLangCd(), false, false, true);
				 
	    		for(int i=0; i<title.length; i++){   				 
					 cell = row1.createCell(i);    	
					 cell.setCellStyle(titleStyle);
					 cell.setCellValue(title[i]);    				  			    		
	    		}

	    		//Data Display
	    		for(int k=0; k<lstProgram.size(); k++){
	    			UserMngVO rowData = lstProgram.get(k);
	    			row = sheet.createRow(k+2);   		   
	    		    
	    		    cell  = row.createCell(0);	
	    		    cell.setCellStyle(valStyleStr);
	    		    cell.setCellValue(rowData.getOrgnzClsNm());
	    		    
	    		    cell  = row.createCell(1);	
	    		    cell.setCellStyle(valStyleStr);
	    		    cell.setCellValue(rowData.getOrgnzCdNm());
	    		    
	    		    cell  = row.createCell(2);	
	    		    cell.setCellStyle(valStyleStr);
	    		    cell.setCellValue(rowData.getTamNm());
	    		    
	    		    cell  = row.createCell(3);	
	    		    cell.setCellStyle(valStyleStr);
	    		    cell.setCellValue(rowData.getAthrNm());
	    		    
	    		    cell  = row.createCell(4);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getMlCn());
	    		    
	    		    cell  = row.createCell(5);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getFmlCn());    		    
	    		}
	    		
	   		    
	    		os = response.getOutputStream();
	    			    		
	    		response.setHeader("Content-Disposition", "attachment; filename=Number_of_Officers.xls");
	    		workbook.write(os);
	    		
	    	} catch (Exception e) {
	    		log.error(e.getMessage(), e);
	    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
	    	} 
	    	
	    }  
	    
	    //Get Font
	    public  HSSFFont getFont(HSSFWorkbook workbook, int fontSize, boolean isBold){
	   	      HSSFFont font = null;
	          font = workbook.createFont();
	          font.setFontHeightInPoints((short)fontSize);
	          if(isBold) font.setBoldweight(Font.BOLDWEIGHT_BOLD);
	   	      font.setColor(HSSFColor.BLACK.index);
	   	      return font; 
	   }	    
	    	 
	    //Get Title Style
	    public  HSSFCellStyle getTitleStyle(HSSFWorkbook workbook){
	    	 HSSFCellStyle style = null;
	    	 style = workbook.createCellStyle();
	    	 style.setFont(getFont(workbook, 14, true));
	    	 style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
	    	 style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
	    	 
	    	 return style;
	    }	
	    
	    //Get Colum Title Style
	    public  HSSFCellStyle getColumTitleStyle(HSSFWorkbook workbook,  boolean isBold, boolean isBG){
	    	 HSSFCellStyle style = null;

	    	 style = workbook.createCellStyle();

	    	 style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
	    	 style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
	    	 
	    	  if (isBG){
	    		  style.setFillForegroundColor(HSSFColor.AQUA.index);
	    		  style.setFillPattern(CellStyle.SOLID_FOREGROUND);
	    	  }
	    	  
	    	  style.setBorderBottom(CellStyle.BORDER_THIN);
	    	  style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
	    	  style.setBorderLeft(CellStyle.BORDER_THIN);
	    	  style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
	    	  style.setBorderRight(CellStyle.BORDER_THIN);
	    	  style.setRightBorderColor(IndexedColors.BLACK.getIndex());
	    	  style.setBorderTop(CellStyle.BORDER_THIN);
	    	  style.setTopBorderColor(IndexedColors.BLACK.getIndex());
	    	
	    	 return style;
	    }	    
	    
		 
	    //Get Colum Data Style
	    public  HSSFCellStyle getColumDataStyle(HSSFWorkbook workbook,  String langType, boolean isBold, boolean isBG, boolean isNum){
	    	HSSFCellStyle style = null;

	    	style = workbook.createCellStyle();

	    	style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);		
		 
	    	if(isNum){
	    		style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
	    	} else {
	    		if ("3".equals(langType)) {
	    			style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
	    		} else {
	    			style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
	    		}
	    	}
		 
	    	if (isBG){
			  style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
			  style.setFillPattern(CellStyle.SOLID_FOREGROUND);
	    	}
		  
		
	    	style.setBorderBottom(CellStyle.BORDER_THIN);
	    	style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
	    	style.setBorderLeft(CellStyle.BORDER_THIN);
	    	style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
	    	style.setBorderRight(CellStyle.BORDER_THIN);
	    	style.setRightBorderColor(IndexedColors.BLACK.getIndex());
	    	style.setBorderTop(CellStyle.BORDER_THIN);
	    	style.setTopBorderColor(IndexedColors.BLACK.getIndex());

		  return style;
	    }	
	    
	    /**
	     * Retrieves list of user history.  <br>
	     * 
	     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
	     * @param UserMngVO Value-object of user to be parsed request(UserMngVO)
	     * @param model Object to be parsed http request(ModelMap) 
	     * @return Printed out JSP: "/cm/uss/UserList.jsp"
	     * @exception Exception
	     */
		@RequestMapping(value="/cm/uss/seachListUserHst.do")
	    public String seachListUserHst(
	    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
	    		@ModelAttribute("userMngVO") UserMngVO userMngVO,
	    		ModelMap model)
	            throws Exception { 

	    	try {

	    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
	    		userMngVO.setUseLangCd(user.getUseLangCd());

		    	/** List Paging Setting */
	    		userMngVO.setPageUnit(propertiesService.getInt("pageUnit"));
	    		userMngVO.setPageSize(propertiesService.getInt("pageSize"));
		
		    	/** pageing */
		    	PaginationInfo paginationInfo = new PaginationInfo();
				paginationInfo.setCurrentPageNo(userMngVO.getPageIndex());
				paginationInfo.setRecordCountPerPage(userMngVO.getPageUnit());
				paginationInfo.setPageSize(userMngVO.getPageSize());
		
				userMngVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
				userMngVO.setLastIndex(paginationInfo.getLastRecordIndex());
				userMngVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
				
		        List<UserMngVO> lstUserHst = userMngService.searchListHstUser(userMngVO);
		        model.addAttribute("lstUserHst", lstUserHst);

		        int totCnt = userMngService.searchListUserHstTotCnt(userMngVO);
				paginationInfo.setTotalRecordCount(totCnt);
		        model.addAttribute("paginationInfo", paginationInfo);
		        
		        UserMngVO userHstList =  new UserMngVO();
		        List<UserMngVO> lstUserAthr = null;
		        
	    		for(int i=0; i<lstUserHst.size(); i++ ){
	    			userHstList = lstUserHst.get(i);
	    			userMngVO.setUserSeqNo(userHstList.getUserSeqNo());
	    			userMngVO.setHstSeqNo(userHstList.getHstSeqNo());
	    			if("0".equals(userMngVO.getHstSeqNo())){
	    				lstUserAthr = userMngService.searchListUserAthr(userMngVO);
	    			} else {
	    				lstUserAthr = userMngService.searchListUserAthrHst(userMngVO);
	    			}
	    			
	    			userHstList.setLstUserAthrNm(lstUserAthr);
	    			userHstList.setAthrCnt( String.valueOf(lstUserAthr.size()) );
	    		}	    		    		

		        if("".equals(userMngVO.getSearchKeyword())){
		        	userMngVO.setSearchKeyword("j");
		        }
		        
	    		model.addAttribute("langCd", userMngVO.getUseLangCd()); 
	    		
	    	} catch (Exception e) {
	    		log.error(e.getMessage(), e);
	    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
	    	}

	      	return "/cm/uss/p_UserHstList";

	    }	    
}
