package afnid.cm.uss.service;

import java.util.List;

/** 
 * This service interface is biz-class of user-management. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.04.18
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2011.04.18  		Kyung Hwan HWANG				Create
 *
 * </pre>
 */
public interface UserMngService  {
	
	
	/**
	 * Retrieves role list of Search Condition. <br>
	 * 
	 * @param vo Input item for retrieving role list of Search Condition(UserMngVO).
	 * @return List Retrieve role list of Search Condition
	 * @exception Exception
	 */
	public List<UserMngVO> searchListAthrView(UserMngVO vo) throws Exception;	

	/**
	 * Retrieves list of user. <br>
	 * 
	 * @param vo Input item for retrieving list of user(UserMngVO).
	 * @return List Retrieve list of user
	 * @exception Exception
	 */
	List<UserMngVO> searchListUser(UserMngVO vo) throws Exception;
	
	/**
	 * Retrieves total count of user-list. <br>
	 * @param vo Input item for retrieving total count list of user.(UserMngVO)
	 * @return int Total Count of User List
	 * @exception Exception
	 */
	int searchListUserTotCnt(UserMngVO vo) throws Exception;
	
	
	/**
	 * Retrieves list of user. <br>
	 * 
	 * @param vo Input item retrieving list of user authority(UserMngVO)).
	 * @return List Retrieve list of user authority
	 * @exception Exception
	 */
	List<UserMngVO> searchListUserAthr(UserMngVO vo) throws Exception;
	
	/**
	 * Retrieves list of user. <br>
	 * 
	 * @param vo Input item retrieving list of user authority(UserMngVO)).
	 * @return List Retrieve list of user authority
	 * @exception Exception
	 */
	List<UserMngVO> searchListUserAthrHst(UserMngVO vo) throws Exception;
	
	/**
	 * Retrieves list of authority. <br>
	 * 
	 * @param Input item for retrieving list of authority(UserMngVO).
	 * @return List Retrieve list of authority
	 * @exception Exception
	 */
	List<UserMngVO> searchListAthr(UserMngVO vo) throws Exception;

	
	/**
	 * Register information of new user. <br>
	 * 
	 * @param vo Input item for registering new user(UserMngVO).
	 * @return UserMngVO Primary Key value of registered user
	 * @exception Exception
	 */
	UserMngVO addUser(UserMngVO vo) throws Exception;	
	
	/**
	 * Register information of new user(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for registering new user(UserMngVO).
	 * @return UserMngVO Primary Key value of registered user
	 * @exception Exception
	 */
	String addUserPkiIf(UserMngVO vo) throws Exception;	
	
	/**
	 * Retrieves detail Information of user. <br>
	 * 
	 * @param vo Input item for retrieving detail information of user(UserMngVO).
	 * @return UserMngVO Retrieve detail information of user
	 * @exception Exception
	 */
	UserMngVO searchUser(UserMngVO vo) throws Exception;	
	
	
	/**
	 * Modifies information of user. <br>
	 * 
	 * @param vo Input item for modifying user(UserMngVO).
	 * @exception Exception
	 */
	UserMngVO modifyUser(UserMngVO vo) throws Exception;

	/**
	 * Modifies information of user(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for registering new user(UserMngVO).
	 * @return UserMngVO Primary Key value of registered user
	 * @exception Exception
	 */
	String modifyUserPkiIf(UserMngVO vo) throws Exception;	
	
	/**
	 * user retirement. <br>
	 * 
	 * @param vo Input item for modifying user(UserMngVO).
	 * @exception Exception
	 */
	UserMngVO modifyUserRtmt(UserMngVO vo) throws Exception;
	
	/**
	 * user retirement(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for user retirement(UserMngVO).
	 * @return UserMngVO Primary Key value of user retirement
	 * @exception Exception
	 */
	String modifyUserRtmtPkiIf(UserMngVO vo) throws Exception;	
		
	/**
	 * User PKI Cert hold. <br>
	 * 
	 * @param vo Input item for modifying user(UserMngVO).
	 * @exception Exception
	 */
	UserMngVO modifyUserHold(UserMngVO vo) throws Exception;
	
	
	/**
	 * User PKI Cert hold(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for User PKI Cert hold(UserMngVO).
	 * @return UserMngVO Primary Key value of User PKI Cert hold
	 * @exception Exception
	 */
	String modifyUserHoldPkiIf(UserMngVO vo) throws Exception;

	
	/**
	 * User PKI Cert Unhold. <br>
	 * 
	 * @param vo Input item for modifying user(UserMngVO).
	 * @exception Exception
	 */
	UserMngVO modifyUserUnhold(UserMngVO vo) throws Exception;	
	
	
	/**
	 * PKI Cert Unhold(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for PKI Cert Unhold(UserMngVO).
	 * @return UserMngVO Primary Key value of PKI Cert Unhold
	 * @exception Exception
	 */
	String modifyUserUnholdPkiIf(UserMngVO vo) throws Exception;
	
	/**
	 * Biz-method for PKI Log Insert.<br>
	 * 
	 * @param vo Input item for modifying program(String userId, int msg).
	 * @exception Exception
	 */
	public void addPubKeyIfLg(String userId, String msg, String code)  throws Exception;

	/**
	 * Retrieve user password. <br>
	 * 
	 * @param vo Input item for retrieving id of user password(UserMngVO).
	 * @return List Retrieve list of user password
	 * @exception Exception
	 */
	UserMngVO searchUserPwd(UserMngVO vo) throws Exception;	
	
	/**
	 * Retrieves list of user password history. <br>
	 * 
	 * @param Input item for retrieving list of user password history(UserMngVO).
	 * @return List Retrieve list of user password history
	 * @exception Exception
	 */
	List<UserMngVO> searchListUserPwdHst(UserMngVO vo) throws Exception;
	
	/**
	 * Update user password. <br>
	 * 
	 * @param vo Input item for Updating user password(UserManageVO).
	 * @exception Exception
	 */
	void modifyUserPwd(UserMngVO vo) throws Exception;	

	
	
	
	/**
	 * Retrieve total count of user role. <br>
	 * 
	 * @param vo Input item for retrieving list of user role(UserMngVO).
	 * @return int 
	 * @exception Exception
	 */
    public int searchAthrCn(UserMngVO vo) throws Exception;	
    
	
	/**
	 * Retrieves list of user. <br>
	 * 
	 * @param vo Input item for retrieving list of user(UserManageVO).
	 * @return List Retrieve list of user
	 * @exception Exception
	 */
	List<UserMngVO> searchListLgnUserEror(UserMngVO vo) throws Exception;
	
	/**
	 * Retrieves total count of user-list. <br>
	 * @param vo Input item for retrieving total count list of user.(UserManageVO)
	 * @return int Total Count of User List
	 * @exception Exception
	 */
	int searchListLgnUserErorTotCn(UserMngVO vo) throws Exception;
	
	/**
	 * Retrieves list of organization. <br>
	 * 
	 * @param vo Input item for retrieving approval list of organization(UserMngVO).
	 * @return List Retrieves list of organization
	 * @exception Exception
	 */
	public List<UserMngVO> searchListDstr(UserMngVO vo) throws Exception;
	
	/**
	 * Retrieves list of organization. <br>
	 * 
	 * @param vo Input item for user reactivate (UserMngVO).
	 * @return 
	 * @exception Exception
	 */	
	public void modifyuserReatv(UserMngVO vo) throws Exception;	
	
	/**
	 * Retrieves number of Officers. <br>
	 * 
	 * @param vo Input item for retrieving number of Officers(UserMngVO).
	 * @return List Retrieve number of Officers
	 * @exception Exception
	 */
	List<UserMngVO> searchListUserNo(UserMngVO vo) throws Exception;	
	
	/**
	 * Retrieves total count of number of officers. <br>
	 * 
	 * @param vo Input item for retrieving total count  of number of officers.(UserNoVO).
	 * @return List Retrieve total count  of number of officers
	 * @exception Exception 
	 */
	int searchListUserNoTotCnt(UserMngVO vo) throws Exception;	
	
	/**
	 * Retrieves number of Officers(excel down). <br>
	 * 
	 * @param vo Input item for retrieving number of Officers(UserMngVO).
	 * @return List Retrieve number of Officers
	 * @exception Exception
	 */
	List<UserMngVO> searchListUserNoExcel(UserMngVO vo) throws Exception;
	
	/**
	 * Retrieves list of user history. <br>
	 * 
	 * @param vo Input item for retrieving list of user history(UserMngVO).
	 * @return List Retrieve list of user history
	 * @exception Exception
	 */
	List<UserMngVO> searchListHstUser(UserMngVO vo) throws Exception;
	
	/**
	 * Retrieves total count of user history list. <br>
	 * @param vo Input item for retrieving total count list of user history.(UserMngVO)
	 * @return int Total Count of User history List
	 * @exception Exception
	 */
	int searchListUserHstTotCnt(UserMngVO vo) throws Exception;
	
	/**
	 * get user main role. <br>
	 * 
	 * @param vo Input item for getting user main role(String).
	 * @exception Exception
	 */
	UserMngVO searchUserMainAthr(UserMngVO vo) throws Exception;
	
}