package afnid.cm.uss.service;

import java.util.List;

import afnid.cm.ComDefaultVO;


/** 
 * This class is Value Object of user-management
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.04.18
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.04.18  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */
public class UserMngVO extends ComDefaultVO {

	private static final long serialVersionUID = 1L;
    
    /** USER SEQUENCE NUMBER */
    private String userSeqNo;
    
    /** USER ID */
    private String userId;
    /** Name */
    private String nm;
    private String enNm;
        
	/** Pashto User Name */
    private String pstUserNm;
    
    /** Dari User Name */
    private String drUserNm;
    
    /** Resident  Number */
    private String rsdtNo;
    
    /** Password */
    private String pwd;
    
    /** Password Confirm */
    private String pwdCnfm;

	/** Password Initialization Date */
    private String pwdInitDd;
    
    /** Telephone Number */
    private String telNo;
    
    /** Telephone Number1 */
    private String telNo1;
    
    /** Telephone Number2 */
    private String telNo2;
    
    /** Telephone Number3 */
    private String telNo3;
    
    /** Mobile Telephone Number */
    private String mbilTelNo;
    
    /** Mobile Telephone Number1 */
    private String mbilTelNo1;
    
    /** Mobile Telephone Number2 */
    private String mbilTelNo2;
    
    /** Mobile Telephone Number3 */
    private String mbilTelNo3;
    
    /** Organization Code */
    private String orgnzCd;
    
    /** Organization Code Name */
    private String orgnzCdNm;
    
    /** Offical Person Code */
    private String ofcalPsnCd;
    
    /** Offical Person Code Name */
    private String ofcalPsnCdNm;

	/** Entrance Company Date */
    private String etrcDd;
    
    /** Retrance Date */
    private String rtreDd;
    
    /** Address Code */
    private String adCd;
    
    /** Address Code Name */
    private String adCdNm;

	/** Address Dtail Contents */
    private String adDtlCt;
    
    /** Fax Number */
    private String faxNo;
    
    /** Fax Number1 */
    private String faxNo1;
    
    /** Fax Number2 */
    private String faxNo2;
    
    /** Fax Number3 */
    private String faxNo3;
    
    /** User Language Code */
    private String useLangCd;
    
    /** User Language Code Name*/
    private String useLangCdNm;

	/** User Status Code */
    private String userStusCd;
    
    /** User Status Code Name */
    private String userStusCdNm;
    
    /** Email Address */
    private String eml;
    
    /** First Registration User ID */
    private String fstRgstUserId;
    
    /** First Registration Date */
    private String fstRgstDt;
    
    /** Last Update User ID */
    private String lstUdtUserId;
    
    /** Last Update Date */
    private String lstUdtDt;
    
    /** Authority Sequence No */
    private String athrSeqNo;   
    
    /** Authority Sequence No */
    private String athrGrpCd;      
    
    /** Authority ID */
    private String athrId;
    
    /** Authority Name */
    private String athrNm;
    
    /** userIdMax*/
    private String userIdMax;
    
    /** Authority Process Status Code */
    private String prcssStusCd;
    
    /** Authority Process Status Code Name */
    private String prcssStusCdNm;
    
    /**  Authority Description */
    private String athrDs;
    
    /** User Authority Process Detail Contents */
    private String prcssDtlCt;
    
    /** User Apply YN */
    private String userAplAthrYn;
    
    /** Authority List Count */ 
    private String athrCnt;
    
    /** Authority Apply YN */
    private String aplYn;
    
    /** History Serial Number */
    private String hstSrlNo;
    
    /** Sequence */
    private String seq;

	/** Check YN Array */
    private String[] athrYnArray;
    
	/** Radio YN Array */
    private String[] mainYnArray;
    
    /** User ID Array */
    private String[] userIdArray;
    

	/** Athority ID Array */
    private String[] athrIdArray;
    
	/** Authority Detail Contents */
    private String[] athrDtlCtArray;
    
    /** Authority Status Code Array */
    private String[] stusCdArray;
    
    /** Is Mager YN */
    private String isMgr;
    
    /** Old Password */
    private String oldPwd;
    
    /**  */
    private String isOut;
    
    private String lgnFailCn;
    
    private String chgPwdDd;
    
    private String chgPwdYn;
   
    private String searchKeyword11;
    
    private String calTye;
    
    private String oldOfcalPsnCd;
    
    private String orgnzClsCd;
    private String orgnzClsNm;    
    private int    orgnzSeqNo;
    private String chkYn;
    private String mnNm;    
    private String lvl;
    
    private String mainAthrYn;
    private String athrRgstYn;
    
    private String[] checkboxList;
    
    private String hLgnDt;
    private String gLgnDt;    
    private String enLgnYn;

    private String fmlCn;
    private String mlCn;
    private String gdrCd;
    private String gdrCdNm;
    
    private List<UserMngVO> lstUserAthrNm;
    
    private String lgSeqNo;
    private String lgSeqNo1;
    private String lgSeqNo2;
    
    private String lcaCntr;    
    private String oficTye;
    
    private String srch1;    
    private String srch2;
    
    private String srchOrgnzCd;
    private String srchOrgnzNm;
    
    private String uprOrgnzCd;
    private String uprOrgnzNm;
    private String hstSeqNo;
    private String hstCnt;
    
    private String hLstUdtDt;
    private String gLstUdtDt;
    
    private String rsdtNoDp;

    private String hPwdInitDd;
    private String gPwdInitDd;
    
	public String getSearchKeyword11() {
		return searchKeyword11;
	}

	public void setSearchKeyword11(String searchKeyword11) {
		this.searchKeyword11 = searchKeyword11;
	}



	public String getLgnFailCn() {
		return lgnFailCn;
	}

	public void setLgnFailCn(String lgnFailCn) {
		this.lgnFailCn = lgnFailCn;
	}

	public String getTamCd() {
		return tamCd;
	}

	public void setTamCd(String tamCd) {
		this.tamCd = tamCd;
	}

	public String getIsOut() {
		return isOut;
	}

	public void setIsOut(String isOut) {
		this.isOut = isOut;
	}

	public String getOldPwd() {
		return oldPwd;
	}

	public void setOldPwd(String oldPwd) {
		this.oldPwd = oldPwd;
	}

	public String getUserId() {
        return this.userId;
    }
    
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getPstUserNm() {
        return this.pstUserNm;
    }
    
    public void setPstUserNm(String pstUserNm) {
        this.pstUserNm = pstUserNm;
    }
    
    public String getDrUserNm() {
        return this.drUserNm;
    }
    
    public void setDrUserNm(String drUserNm) {
        this.drUserNm = drUserNm;
    }
    
    public String getRsdtNo() {
        return this.rsdtNo;
    }
    
    public void setRsdtNo(String rsdtNo) {
        this.rsdtNo = rsdtNo;
    }
    
    public String getPwd() {
        return this.pwd;
    }
    
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
    
    public String getPwdInitDd() {
        return this.pwdInitDd;
    }
    
    public void setPwdInitDd(String pwdInitDd) {
        this.pwdInitDd = pwdInitDd;
    }
    
    public String getTelNo() {
        return this.telNo;
    }
    
    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }
    
    public String getMbilTelNo() {
        return this.mbilTelNo;
    }
    
    public void setMbilTelNo(String mbilTelNo) {
        this.mbilTelNo = mbilTelNo;
    }
    
    public String getOrgnzCd() {
        return this.orgnzCd;
    }
    
    public void setOrgnzCd(String orgnzCd) {
        this.orgnzCd = orgnzCd;
    }
    
    public String getOfcalPsnCd() {
        return this.ofcalPsnCd;
    }
    
    public void setOfcalPsnCd(String ofcalPsnCd) {
        this.ofcalPsnCd = ofcalPsnCd;
    }
    

    public String getEtrcDd() {
		return etrcDd;
	}

	public void setEtrcDd(String etrcDd) {
		this.etrcDd = etrcDd;
	}

	public String getRtreDd() {
        return this.rtreDd;
    }
    
    public void setRtreDd(String rtreDd) {
        this.rtreDd = rtreDd;
    }
    
    public String getAdCd() {
        return this.adCd;
    }
    
    public void setAdCd(String adCd) {
        this.adCd = adCd;
    }
    
    public String getAdDtlCt() {
        return this.adDtlCt;
    }
    
    public void setAdDtlCt(String adDtlCt) {
        this.adDtlCt = adDtlCt;
    }
    
    public String getFaxNo() {
        return this.faxNo;
    }
    
    public void setFaxNo(String faxNo) {
        this.faxNo = faxNo;
    }
    
    public String getUseLangCd() {
        return this.useLangCd;
    }
    
    public void setUseLangCd(String useLangCd) {
        this.useLangCd = useLangCd;
    }
    
    public String getUserStusCd() {
        return this.userStusCd;
    }
    
    public void setUserStusCd(String userStusCd) {
        this.userStusCd = userStusCd;
    }
    
    public String getEml() {
        return this.eml;
    }
    
    public void setEml(String eml) {
        this.eml = eml;
    }
    
    public String getFstRgstUserId() {
        return this.fstRgstUserId;
    }
    
    public void setFstRgstUserId(String fstRgstUserId) {
        this.fstRgstUserId = fstRgstUserId;
    }
    
    public String getFstRgstDt() {
        return this.fstRgstDt;
    }
    
    public void setFstRgstDt(String fstRgstDt) {
        this.fstRgstDt = fstRgstDt;
    }
    
    public String getLstUdtUserId() {
        return this.lstUdtUserId;
    }
    
    public void setLstUdtUserId(String lstUdtUserId) {
        this.lstUdtUserId = lstUdtUserId;
    }
    
    public String getLstUdtDt() {
        return this.lstUdtDt;
    }
    
    public void setLstUdtDt(String lstUdtDt) {
        this.lstUdtDt = lstUdtDt;
    }
    

    
    public String getOrgnzCdNm() {
		return orgnzCdNm;
	}

	public void setOrgnzCdNm(String orgnzCdNm) {
		this.orgnzCdNm = orgnzCdNm;
	}

	public String getUserStusCdNm() {
		return userStusCdNm;
	}

	public void setUserStusCdNm(String userStusCdNm) {
		this.userStusCdNm = userStusCdNm;
	}
	

	public String[] getAthrYnArray() {
		return athrYnArray;
	}

	public void setAthrYnArray(String[] athrYnArray) {
		this.athrYnArray = athrYnArray;
	}

	public String[] getMainYnArray() {
		return mainYnArray;
	}

	public void setMainYnArray(String[] mainYnArray) {
		this.mainYnArray = mainYnArray;
	}

	public String[] getAthrDtlCtArray() {
		return athrDtlCtArray;
	}

	public void setAthrDtlCtArray(String[] athrDtlCtArray) {
		this.athrDtlCtArray = athrDtlCtArray;
	}
	
	public String getAthrId() {
		return athrId;
	}

	public void setAthrId(String athrId) {
		this.athrId = athrId;
	}

	public String getAthrNm() {
		return athrNm;
	}

	public void setAthrNm(String athrNm) {
		this.athrNm = athrNm;
	}

	public String getAthrDs() {
		return athrDs;
	}

	public void setAthrDs(String athrDs) {
		this.athrDs = athrDs;
	}
	
	public String getOfcalPsnCdNm() {
		return ofcalPsnCdNm;
	}

	public void setOfcalPsnCdNm(String ofcalPsnCdNm) {
		this.ofcalPsnCdNm = ofcalPsnCdNm;
	}
	

    

	public String getTelNo1() {
		return telNo1;
	}

	public void setTelNo1(String telNo1) {
		this.telNo1 = telNo1;
	}

	public String getTelNo2() {
		return telNo2;
	}

	public void setTelNo2(String telNo2) {
		this.telNo2 = telNo2;
	}

	public String getTelNo3() {
		return telNo3;
	}

	public void setTelNo3(String telNo3) {
		this.telNo3 = telNo3;
	}

	public String getMbilTelNo1() {
		return mbilTelNo1;
	}

	public void setMbilTelNo1(String mbilTelNo1) {
		this.mbilTelNo1 = mbilTelNo1;
	}

	public String getMbilTelNo2() {
		return mbilTelNo2;
	}

	public void setMbilTelNo2(String mbilTelNo2) {
		this.mbilTelNo2 = mbilTelNo2;
	}

	public String getMbilTelNo3() {
		return mbilTelNo3;
	}

	public void setMbilTelNo3(String mbilTelNo3) {
		this.mbilTelNo3 = mbilTelNo3;
	}

	public String getFaxNo1() {
		return faxNo1;
	}

	public void setFaxNo1(String faxNo1) {
		this.faxNo1 = faxNo1;
	}

	public String getFaxNo2() {
		return faxNo2;
	}

	public void setFaxNo2(String faxNo2) {
		this.faxNo2 = faxNo2;
	}

	public String getFaxNo3() {
		return faxNo3;
	}

	public void setFaxNo3(String faxNo3) {
		this.faxNo3 = faxNo3;
	}
	
	public String getAdCdNm() {
		return adCdNm;
	}

	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}
	
	public String getPrcssStusCd() {
		return prcssStusCd;
	}

	public void setPrcssStusCd(String prcssStusCd) {
		this.prcssStusCd = prcssStusCd;
	}

	public String getPrcssStusCdNm() {
		return prcssStusCdNm;
	}

	public void setPrcssStusCdNm(String prcssStusCdNm) {
		this.prcssStusCdNm = prcssStusCdNm;
	}
	
	public String getPrcssDtlCt() {
		return prcssDtlCt;
	}

	public void setPrcssDtlCt(String prcssDtlCt) {
		this.prcssDtlCt = prcssDtlCt;
	}
	
    public String getUseLangCdNm() {
		return useLangCdNm;
	}

	public void setUseLangCdNm(String useLangCdNm) {
		this.useLangCdNm = useLangCdNm;
	}
	
	public String getUserAplAthrYn() {
		return userAplAthrYn;
	}

	public void setUserAplAthrYn(String userAplAthrYn) {
		this.userAplAthrYn = userAplAthrYn;
	}

    public String getPwdCnfm() {
		return pwdCnfm;
	}

	public void setPwdCnfm(String pwdCnfm) {
		this.pwdCnfm = pwdCnfm;
	}

	public String[] getAthrIdArray() {
		return athrIdArray;
	}

	public void setAthrIdArray(String[] athrIdArray) {
		this.athrIdArray = athrIdArray;
	}

	public String getAthrCnt() {
		return athrCnt;
	}

	public void setAthrCnt(String athrCnt) {
		this.athrCnt = athrCnt;
	}

	public String getAplYn() {
		return aplYn;
	}

	public void setAplYn(String aplYn) {
		this.aplYn = aplYn;
	}

	public String[] getStusCdArray() {
		return stusCdArray;
	}

	public void setStusCdArray(String[] stusCdArray) {
		this.stusCdArray = stusCdArray;
	}
	
	public String getHstSrlNo() {
		return hstSrlNo;
	}

	public void setHstSrlNo(String hstSrlNo) {
		this.hstSrlNo = hstSrlNo;
	}

	public String getSeq() {
		return seq;
	}

	public void setSeq(String seq) {
		this.seq = seq;
	}
	
	public String[] getUserIdArray() {
		return userIdArray;
	}

	public void setUserIdArray(String[] userIdArray) {
		this.userIdArray = userIdArray;
	}


	public String getIsMgr() {
		return isMgr;
	}

	public void setIsMgr(String isMgr) {
		this.isMgr = isMgr;
	}

	public String getChgPwdDd() {
		return chgPwdDd;
	}

	public void setChgPwdDd(String chgPwdDd) {
		this.chgPwdDd = chgPwdDd;
	}

	public String getChgPwdYn() {
		return chgPwdYn;
	}

	public void setChgPwdYn(String chgPwdYn) {
		this.chgPwdYn = chgPwdYn;
	}

	public String getCalTye() {
		return calTye;
	}

	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}

	public String getOldOfcalPsnCd() {
		return oldOfcalPsnCd;
	}

	public void setOldOfcalPsnCd(String oldOfcalPsnCd) {
		this.oldOfcalPsnCd = oldOfcalPsnCd;
	}

	public String getUserIdMax() {
		return userIdMax;
	}

	public void setUserIdMax(String userIdMax) {
		this.userIdMax = userIdMax;
	}

    public String getEnNm() {
		return enNm;
	}

	public void setEnNm(String enNm) {
		this.enNm = enNm;
	}

	/*
    public UserManageVO(String pwd){
    		this.pwd = pwd;
    }*/
    public String getNm() {
		return nm;
	}

	public void setNm(String nm) {
		this.nm = nm;
	}
	
	/**TamCd*/
    private String tamCd;
    /**TamNm*/
    private String tamNm;
	public String getTamNm() {
		return tamNm;
	}

	public void setTamNm(String tamNm) {
		this.tamNm = tamNm;
	}

	public String getOrgnzClsCd() {
		return orgnzClsCd;
	}

	public void setOrgnzClsCd(String orgnzClsCd) {
		this.orgnzClsCd = orgnzClsCd;
	}

	public String getOrgnzClsNm() {
		return orgnzClsNm;
	}

	public void setOrgnzClsNm(String orgnzClsNm) {
		this.orgnzClsNm = orgnzClsNm;
	}

	public int getOrgnzSeqNo() {
		return orgnzSeqNo;
	}

	public void setOrgnzSeqNo(int orgnzSeqNo) {
		this.orgnzSeqNo = orgnzSeqNo;
	}

	public String getAthrSeqNo() {
		return athrSeqNo;
	}

	public void setAthrSeqNo(String athrSeqNo) {
		this.athrSeqNo = athrSeqNo;
	}

	public String getAthrGrpCd() {
		return athrGrpCd;
	}

	public void setAthrGrpCd(String athrGrpCd) {
		this.athrGrpCd = athrGrpCd;
	}

	public String[] getCheckboxList() {
		return checkboxList;
	}

	public void setCheckboxList(String[] checkboxList) {
		this.checkboxList = checkboxList;
	}

	public String getUserSeqNo() {
		return userSeqNo;
	}

	public void setUserSeqNo(String userSeqNo) {
		this.userSeqNo = userSeqNo;
	}

	public String getChkYn() {
		return chkYn;
	}

	public void setChkYn(String chkYn) {
		this.chkYn = chkYn;
	}

	public String getMnNm() {
		return mnNm;
	}

	public void setMnNm(String mnNm) {
		this.mnNm = mnNm;
	}

	public String getLvl() {
		return lvl;
	}

	public void setLvl(String lvl) {
		this.lvl = lvl;
	}

	public String getMainAthrYn() {
		return mainAthrYn;
	}

	public void setMainAthrYn(String mainAthrYn) {
		this.mainAthrYn = mainAthrYn;
	}

	public String getAthrRgstYn() {
		return athrRgstYn;
	}

	public void setAthrRgstYn(String athrRgstYn) {
		this.athrRgstYn = athrRgstYn;
	}

	public String gethLgnDt() {
		return hLgnDt;
	}

	public void sethLgnDt(String hLgnDt) {
		this.hLgnDt = hLgnDt;
	}

	public String getgLgnDt() {
		return gLgnDt;
	}

	public void setgLgnDt(String gLgnDt) {
		this.gLgnDt = gLgnDt;
	}

	public String getEnLgnYn() {
		return enLgnYn;
	}

	public void setEnLgnYn(String enLgnYn) {
		this.enLgnYn = enLgnYn;
	}

	public List<UserMngVO> getLstUserAthrNm() {
		return lstUserAthrNm;
	}

	public void setLstUserAthrNm(List<UserMngVO> lstUserAthrNm) {
		this.lstUserAthrNm = lstUserAthrNm;
	}



	public String getFmlCn() {
		return fmlCn;
	}

	public void setFmlCn(String fmlCn) {
		this.fmlCn = fmlCn;
	}



	public String getMlCn() {
		return mlCn;
	}

	public void setMlCn(String mlCn) {
		this.mlCn = mlCn;
	}

	public String getGdrCd() {
		return gdrCd;
	}

	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}

	public String getGdrCdNm() {
		return gdrCdNm;
	}

	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}

	public String getLgSeqNo() {
		return lgSeqNo;
	}

	public void setLgSeqNo(String lgSeqNo) {
		this.lgSeqNo = lgSeqNo;
	}

	public String getLgSeqNo1() {
		return lgSeqNo1;
	}

	public void setLgSeqNo1(String lgSeqNo1) {
		this.lgSeqNo1 = lgSeqNo1;
	}

	public String getLgSeqNo2() {
		return lgSeqNo2;
	}

	public void setLgSeqNo2(String lgSeqNo2) {
		this.lgSeqNo2 = lgSeqNo2;
	}

	public String getLcaCntr() {
		return lcaCntr;
	}

	public void setLcaCntr(String lcaCntr) {
		this.lcaCntr = lcaCntr;
	}

	public String getOficTye() {
		return oficTye;
	}

	public void setOficTye(String oficTye) {
		this.oficTye = oficTye;
	}

	public String getSrch1() {
		return srch1;
	}

	public void setSrch1(String srch1) {
		this.srch1 = srch1;
	}

	public String getSrch2() {
		return srch2;
	}

	public void setSrch2(String srch2) {
		this.srch2 = srch2;
	}

	public String getSrchOrgnzCd() {
		return srchOrgnzCd;
	}

	public void setSrchOrgnzCd(String srchOrgnzCd) {
		this.srchOrgnzCd = srchOrgnzCd;
	}

	public String getUprOrgnzCd() {
		return uprOrgnzCd;
	}

	public void setUprOrgnzCd(String uprOrgnzCd) {
		this.uprOrgnzCd = uprOrgnzCd;
	}

	public String getUprOrgnzNm() {
		return uprOrgnzNm;
	} 

	public void setUprOrgnzNm(String uprOrgnzNm) {
		this.uprOrgnzNm = uprOrgnzNm;
	}

	public String getSrchOrgnzNm() {
		return srchOrgnzNm;
	}

	public void setSrchOrgnzNm(String srchOrgnzNm) {
		this.srchOrgnzNm = srchOrgnzNm;
	}

	public String getHstSeqNo() {
		return hstSeqNo;
	}

	public void setHstSeqNo(String hstSeqNo) {
		this.hstSeqNo = hstSeqNo;
	}

	public String getHstCnt() {
		return hstCnt;
	}

	public void setHstCnt(String hstCnt) {
		this.hstCnt = hstCnt;
	}

	public String gethLstUdtDt() {
		return hLstUdtDt;
	}

	public void sethLstUdtDt(String hLstUdtDt) {
		this.hLstUdtDt = hLstUdtDt;
	}

	public String getgLstUdtDt() {
		return gLstUdtDt;
	}

	public void setgLstUdtDt(String gLstUdtDt) {
		this.gLstUdtDt = gLstUdtDt;
	}

	public String getRsdtNoDp() {
		return rsdtNoDp;
	}

	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}

	public String gethPwdInitDd() {
		return hPwdInitDd;
	}

	public void sethPwdInitDd(String hPwdInitDd) {
		this.hPwdInitDd = hPwdInitDd;
	}

	public String getgPwdInitDd() {
		return gPwdInitDd;
	}

	public void setgPwdInitDd(String gPwdInitDd) {
		this.gPwdInitDd = gPwdInitDd;
	}

}