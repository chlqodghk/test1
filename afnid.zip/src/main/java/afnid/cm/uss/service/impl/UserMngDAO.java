package afnid.cm.uss.service.impl;


import java.util.List;

import org.springframework.stereotype.Repository;

import afnid.cm.code.service.OrgnzVO;
import afnid.cm.uss.service.UserMngVO;
import afnid.cm.util.service.NidFileScrty;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/** 
 * This class is Database Access Object of user-management
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.04.18
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.04.18  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */
@Repository("userMngDAO")
public class UserMngDAO extends EgovAbstractDAO {
	
	/**
	 * DAO-method for retrieving role list of Search Condition. <br>
	 * 
	 * @param vo Input item for retrieving role list of Search Condition(UserMngVO).
	 * @return UserMngVO Retrieve role list of Search Condition
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<UserMngVO> selectListAthrView(UserMngVO vo) throws Exception{
		return list("userMngDAO.selectListAthrView", vo);
	}
	
	
	/**
	 * DAO-method for retrieving list of user. <br>
	 * 
	 * @param vo Input item for retrieving information of user(UserMngVO).
	 * @return UserMngVO Retrieve information of User
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<UserMngVO> selectListUser(UserMngVO vo) throws Exception{
		return list("userMngDAO.selectListUser", vo);
	}
    
	/**
	 * DAO-method for retrieving total count list of user. <br>
	 * 
	 * @param vo Input item for retrieving list of user(UserMngVO).
	 * @return int Total Count of User List
	 * @exception Exception
	 */
    public int selectListUserTotCnt(UserMngVO vo) throws Exception{
        return (Integer)selectByPk("userMngDAO.selectListUserTotCnt", vo);
    }	
    
	/**
	 * DAO-method for retrieving list of user authority. <br>
	 * 
	 * @param vo Input item for retrieving information of user authority(UserMngVO).
	 * @return UserMngVO Retrieve information of userauthority
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<UserMngVO> selectListUserAthr(UserMngVO vo) throws Exception{
		return list("userMngDAO.selectListUserAthr", vo);
	}
	
	/**
	 * DAO-method for retrieving list of user authority history. <br>
	 * 
	 * @param vo Input item for retrieving information of user authority history(UserMngVO).
	 * @return UserMngVO Retrieve information of user authority history
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<UserMngVO> selectListUserAthrHst(UserMngVO vo) throws Exception{
		return list("userMngDAO.selectListUserAthrHst", vo);
	}
	
	/**
	 * DAO-method for retrieving list of authority. <br>
	 * 
	 * @param vo Input item for retrieving information of authority(UserMngVO).
	 * @return UserMngVO Retrieve information of authority
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<UserMngVO> selectListAthr(UserMngVO vo) throws Exception{
		return list("userMngDAO.selectListAthr", vo);
	}

	
	/**
	 * DAO-method for retrieving current userId max value. <br>
	 * 
	 * @param vo Input item for retrieving information of user(UserMngVO).
	 * @return UserMngVO Retrieve information of User
	 * @exception Exception
	 */
	public UserMngVO getUserIdCreation(UserMngVO vo) throws Exception{
		return (UserMngVO)selectByPk("userMngDAO.getUserIdCreation", vo);
	}	
	
	/**
	 * DAO-method for get user sequece number. <br>
	 * 
	 * @param vo Input item for retrieving information of user(UserMngVO).
	 * @return UserMngVO Retrieve information of User
	 * @exception Exception
	 */
	public int getUserSeqNo(UserMngVO vo) throws Exception{
		return (Integer) selectByPk("userMngDAO.selectUserSeqNo", vo);
	}	
	
	/**
	 * DAO-method for registering information of new user. <br>
	 * 
	 * @param vo Input item for registering new user(UserMngVO).
	 * @exception Exception
	 */
	public String insertUser(UserMngVO vo) throws Exception{
		
		
		String userId    = null;
		String pwd       = null;
		String userSeqNo = null;
				
		synchronized(this){
			userSeqNo = (String)selectByPk("userMngDAO.selectUserSeqNo", vo);			
			vo.setUserSeqNo(userSeqNo);
			
			userId    = (String)selectByPk("userMngDAO.selectUserId", vo);
			
			pwd = NidFileScrty.encryptPassword(userId+"xx");//패스워드설정	
			
			vo.setUserId(userId);
			vo.setPwd(pwd);

			insert("userMngDAO.insertUser", vo);
			
			String[] athrYnArray = vo.getAthrYnArray();
			String[] mainYnArray = vo.getMainYnArray();
			
			if(athrYnArray != null) {
				deleteUserAthr(vo);
				
				for(int i=0; i<athrYnArray.length; i++) {
					if(athrYnArray[i].equals("Y")) {	
						vo.setAthrSeqNo(vo.getAthrIdArray()[i]); 
						vo.setMainAthrYn(mainYnArray[i]);
						insertUserAthrRl(vo);
					}
				}
							
			}	
			
		}
		return userId;
	}	
	
	/**
	 * DAO-method for registering process information of new user-authority . <br>
	 * 
	 * @param vo Input item for registering new user-authority(UserMngVO).
	 * @exception Exception
	 */
	public void insertUserAthrRl(UserMngVO vo)throws Exception{
		insert("userMngDAO.insertUserAthrRl", vo);
	}
		
	/**
	 * DAO-method for retrieving detail Information of user. <br>
	 * 
	 * @param vo Input item for retrieving detail information of user(UserMngVO).
	 * @return UserMngVO Retrieve detail information of user
	 * @exception Exception
	 */
	public UserMngVO selectUser(UserMngVO vo)throws Exception{
		return (UserMngVO)selectByPk("userMngDAO.selectUser", vo); 
	}


	/**
	 * DAO-method for registering information of new user history. <br>
	 * 
	 * @param vo Input item for registering new user history(UserMngVO).
	 * @exception Exception
	 */
	public String insertUserHst(UserMngVO vo)throws Exception{
		 
		String hstSeqNo = (String)insert("userMngDAO.insertUserHst", vo);
		return hstSeqNo;
	}

	/**
	 * DAO-method for registering information of  user role history. <br>
	 * 
	 * @param vo Input item for registering user role history(UserMngVO).
	 * @exception Exception
	 */
	public void insertUserAthrHst(UserMngVO vo)throws Exception{
		insert("userMngDAO.insertUserAthrHst", vo);
	}

	
	
	/**
	 * DAO-method for modifying information of user. <br>
	 * 
	 * @param vo Input item for modifying user(UserMngVO).
	 * @exception Exception
	 */
	public int  updateUser(UserMngVO vo) throws Exception {
		return update("userMngDAO.updateUser", vo);
	}
	
	/**
	 * DAO-method for deleteing authority of user. <br>
	 * 
	 * @param vo Input item for modifying authority of user(UserMngVO).
	 * @exception Exception
	 */
	public void deleteUserAthr(UserMngVO vo) throws Exception {
		update("userMngDAO.deleteUserAthr", vo);
	}

	/**
	 * DAO-method for user Onhold.<br>
	 * 
	 * @param vo Input item for user Onhold(UserMngVO).
	 * @exception Exception
	 */
	public int updateUserHold(UserMngVO vo) throws Exception {
		return update("userMngDAO.updateUserHold", vo);
	}
	
	/**
	 * DAO-method for user Unhold.<br>
	 * 
	 * @param vo Input item for user Unhold(UserMngVO).
	 * @exception Exception
	 */
	public int updateUserUnhold(UserMngVO vo) throws Exception {
		return update("userMngDAO.updateUserUnhold", vo);
	}
	
	
	/**
	 * DAO-method for user retirement.<br>
	 * 
	 * @param vo Input item for user retirement(UserMngVO).
	 * @exception Exception
	 */
	public int updateUserRtmt(UserMngVO vo) throws Exception {
		return update("userMngDAO.updateUserRtmt", vo);
	}
	
	
    /**
	 * DAO-method for modifying information of user. <br>
	 * 
	 * @param vo Input item for modifying user(UserMngVO).
	 * @exception Exception
	 */
	public void updateLgnCn(UserMngVO vo) throws Exception {
		update("userMngDAO.updateLgnCn", vo);
	}

	/**
	 * DAO-method for retrieving count of user password. <br>
	 * 
	 * @param vo Input item for retrieving count of user password(UserMngVO).
	 * @return int Count of User password
	 * @exception Exception
	 */
	public UserMngVO selectUserPwd(UserMngVO vo) throws Exception {
		return (UserMngVO)selectByPk("userMngDAO.selectUserPwd", vo);
	}
	
	/**
	 * DAO-method for retrieving list of user password history. <br>
	 * 
	 * @param vo Input item for retrieving information of user password history(UserManageVO).
	 * @return UserManageVO Retrieve information of User password history
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")	
	public List<UserMngVO> selectListUserPwdHst(UserMngVO vo) throws Exception {
		return list("userMngDAO.selectListUserPwdHst", vo);
	}

    /**
	 * DAO-method for updating user password. <br>
	 * 
	 * @param vo Input item for updating user password(UserManageVO).
	 * @exception Exception
	 */
    public void updateUserPwd(UserMngVO vo) {
    	update("userMngDAO.updateUserPwd", vo);
    }
    
    
    
    
	/**
	 * DAO-method for retrieving total count of user role. <br>
	 * 
	 * @param vo Input item for retrieving list of user role(UserMngVO).
	 * @return int 
	 * @exception Exception
	 */
    public int selectAthrCn(UserMngVO vo) throws Exception{
        return (Integer)selectByPk("userMngDAO.selectAthrCn", vo);
    }
    
	/**
	 * DAO-method for retrieving list Information of organization. <br>
	 * 
	 * @param vo Input item for retrieving list information of organization(OrgInfoVO).
	 * @return OrgInfoVO Retrieve list information of organization
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")    
	public List<OrgnzVO> selectListOngnz(OrgnzVO vo) throws Exception{
		return list("userMngDAO.selectListOngnz", vo);
	}
	
	/**
	 * DAO-method for retrieving list of user. <br>
	 * 
	 * @param vo Input item for retrieving information of user(UserManageVO).
	 * @return UserManageVO Retrieve information of User
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked") 	
	public List<UserMngVO> selectListLgnUserEror(UserMngVO vo) throws Exception{
		return list("userMngDAO.selectListLgnUserEror", vo);
	}
	
	/**
	 * DAO-method for retrieving total count list of user. <br>
	 * 
	 * @param vo Input item for retrieving list of user(UserManageVO).
	 * @return int Total Count of User List
	 * @exception Exception
	 */
    public int selectListLgnUserErorTotCn(UserMngVO vo) throws Exception{
        return (Integer)selectByPk("userMngDAO.selectListLgnUserErorTotCn", vo);
    }	
    
    
    /**
	 * DAO-method for user activate. <br>
	 * 
	 * @param vo Input item for user activate(UserMngVO).
	 * @exception Exception
	 */
	public void updateuserReatv(UserMngVO vo) throws Exception {
		update("userMngDAO.updateuserReatv", vo);
	}
	
	/**
	 * DAO-method for retrieving list of organization. <br>
	 * 
	 * @param vo Input item for retrieving information of user(UserMngVO).
	 * @return UserMngVO Retrieve list of organization
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<UserMngVO> selectListDstr(UserMngVO vo) throws Exception{
		return list("userMngDAO.selectListDstr", vo);
	}  
	
	/**
	 * DAO-method for retrieving list of number of Officers. <br>
	 * 
	 * @param vo Input item for retrieving information of number of Officers(UserNoVO).
	 * @return UserNoVO Retrieve information of number of Officers
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<UserMngVO> selectListUserNo(UserMngVO vo) throws Exception{
		return list("userMngDAO.selectListUserNo", vo);
	}
    
	/**
	 * DAO-method for retrieving total count list of number of Officers. <br>
	 * 
	 * @param vo Input item for retrieving list of number of Officers(UserNoVO).
	 * @return int Total Count of number of Officers
	 * @exception Exception
	 */
    public int selectListUserNoTotCnt(UserMngVO vo) throws Exception{
        return (Integer)selectByPk("userMngDAO.selectListUserNoTotCnt", vo);
    }	
    
	/**
	 * DAO-method for retrieving list of number of Officers(excel down). <br>
	 * 
	 * @param vo Input item for retrieving information of number of Officers(UserNoVO).
	 * @return UserNoVO Retrieve information of number of Officers
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<UserMngVO> selectListUserNoExcel(UserMngVO vo) throws Exception{
		return list("userMngDAO.selectListUserNoExcel", vo);
	}  
	
	/**
	 * DAO-method for retrieving list of user history. <br>
	 * 
	 * @param vo Input item for retrieving information of user history(UserMngVO).
	 * @return UserMngVO Retrieve information of User history
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<UserMngVO> selectListHstUser(UserMngVO vo) throws Exception{
		return list("userMngDAO.selectListHstUser", vo);
	}
    
	/**
	 * DAO-method for retrieving total count list of user history. <br>
	 * 
	 * @param vo Input item for retrieving list of user history(UserMngVO).
	 * @return int Total Count of User history List
	 * @exception Exception
	 */
    public int selectListUserHstTotCnt(UserMngVO vo) throws Exception{
        return (Integer)selectByPk("userMngDAO.selectListUserHstTotCnt", vo);
    }	
    
	/**
	 * DAO-method for getting user main role. <br>
	 * 
	 * @param vo Input item for getting user main role(UserMngVO).
	 * @return UserMngVO user main role
	 * @exception Exception
	 */
	public UserMngVO selectUserMainAthr(UserMngVO vo)throws Exception{
		return (UserMngVO)selectByPk("userMngDAO.selectUserMainAthr", vo); 
	}    
    
}