package afnid.cm.uss.service.impl;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.uss.service.UserMngService;
import afnid.cm.uss.service.UserMngVO;
import afnid.cm.util.service.NidFileScrty;
import afnid.pkiif.opki.PkiRsWsResponse;
import afnid.pkiif.opki.OpkiRmWS;
import afnid.pkiif.opki.OpkiRmWSService;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;

/** 
 * This service class is biz-class of user-management
 * and implements NidUserManageService class.
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.04.18
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.04.18  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */
@Service("userMngService")
public class  UserMngServiceImpl extends AbstractServiceImpl implements UserMngService {
	@Resource(name="userMngDAO")
    private UserMngDAO userMngDAO;
	
    /** logDAO */
    @Resource(name="lgDAO")
    private LgDAO lgDAO;

	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
	/**
	 * Biz-method for retrieving role list of Search Condition. <br>
	 * 
	 * @param vo Input item for retrieving role list of Search Condition(UserMngVO).
	 * @return List Retrieve role list of Search Condition
	 * @exception Exception
	 */
	public List<UserMngVO> searchListAthrView(UserMngVO vo) throws Exception {

		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		
		return userMngDAO.selectListAthrView(vo);
	}
	
	/**
	 * Biz-method for retrieving list of user. <br>
	 * 
	 * @param vo Input item for retrieving list of user(UserMngVO).
	 * @return List Retrieve list of user
	 * @exception Exception
	 */
	public List<UserMngVO> searchListUser(UserMngVO vo) throws Exception {
		return userMngDAO.selectListUser(vo);
	}

	/**
	 * Biz-method for retrieving total count list of user. <br>
	 * 
	 * @param vo Input item for retrieving list of user(UserMngVO).
	 * @return int Total Count of User List
	 * @exception Exception
	 */
	public int searchListUserTotCnt(UserMngVO vo) throws Exception {
		return userMngDAO.selectListUserTotCnt(vo);
	}

	/**
	 * Biz-method for retrieving list of user authority. <br>
	 * 
	 * @param vo Input item for retrieving  list of user authority(UserMngVO).
	 * @return List Retrieve list of user
	 * @exception Exception
	 */
	public List<UserMngVO> searchListUserAthr(UserMngVO vo) throws Exception {		
		return userMngDAO.selectListUserAthr(vo);
	}
	
	/**
	 * Biz-method for retrieving list of user authority history. <br>
	 * 
	 * @param vo Input item for retrieving  list of user authority history(UserMngVO).
	 * @return List Retrieve list of user authority history
	 * @exception Exception
	 */
	public List<UserMngVO> searchListUserAthrHst(UserMngVO vo) throws Exception {		
		return userMngDAO.selectListUserAthrHst(vo);
	}
	
	/**
	 * Biz-method for retrieving list of authority. <br>
	 * 
	 * @param vo Input item for retrieving list of authority(UserMngVO).
	 * @return List Retrieve list of authority
	 * @exception Exception
	 */
	public List<UserMngVO> searchListAthr(UserMngVO vo) throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		
		return userMngDAO.selectListAthr(vo);
	}

		
	/**
	 * Biz-method for registering information of new user. <br>
	 * 
	 * @param vo Input item for registering new user(UserMngVO).
	 * @return UserMngVO Primary Key value of registered user
	 * @exception Exception
	 */
	public UserMngVO addUser(UserMngVO vo) throws Exception {

		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd());
		
		String userId = userMngDAO.insertUser(vo);
        vo.setUserId(userId);

        String lgSeqNo = lgDAO.insertPubKeyIfLg(user.getUserId(), vo.getUserId(),"9", "2", "6", "");        
        vo.setLgSeqNo(lgSeqNo);
        
    	return vo;
    	
	}
	
	/**
	 * Biz-method for registering information of new user(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for registering new user(UserMngVO).
	 * @return UserMngVO Primary Key value of registered user
	 * @exception Exception
	 */
	public String addUserPkiIf(UserMngVO vo) throws Exception {
		
		log.debug("==================================================");
		log.debug("vo.getLgSeqNo() : "+vo.getLgSeqNo());
		log.debug("vo.getUserId() : "+vo.getUserId());
		log.debug("vo.getEnNm()   : "+vo.getEnNm());
		log.debug("vo.getEml()    : "+ vo.getEml());
		log.debug("==================================================");
		
		String status = "";
		String erorYn ="Y";

		OpkiRmWSService orws= new OpkiRmWSService();
		OpkiRmWS orw = orws.getOpkiRmWSPort();	
		
		PkiRsWsResponse prwr = orw.opkiIfRegisterAccount(vo.getUserId(), vo.getEnNm(), vo.getEml());
		status= prwr.getStatusCode();

		if("0".equals(status)){
			erorYn ="N";
		}
		
		lgDAO.updatePubKeyIfLg(vo.getLgSeqNo(), status, erorYn);
		
	    log.debug("status ====> " + status);

    	return status;
    	
	}
	
	/**
	 * Biz-method for retrieving detail Information of user. <br>
	 * 
	 * @param vo Input item for retrieving detail information of user(UserMngVO).
	 * @return UserMngVO Retrieve detail information of user
	 * @exception Exception
	 */
	public UserMngVO searchUser(UserMngVO vo) throws Exception{
		/** Loading session information  */	
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(vo.getUserId());
		vo.setUseLangCd(user.getUseLangCd());
		return (UserMngVO)userMngDAO.selectUser(vo);
	}	
	

	
	/**
	 * Biz-method for modifying information of user. <br>
	 * 
	 * @param vo Input item for modifying program(UserMngVO).
	 * @exception Exception
	 */
	public UserMngVO modifyUser(UserMngVO vo) throws Exception {
		/** Loading session information  */
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
		vo.setFstRgstUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd()); //Machine language code
		
		//insert history
		String hstSeqNo = userMngDAO.insertUserHst(vo);
		vo.setHstSeqNo(hstSeqNo);
		
		userMngDAO.insertUserAthrHst(vo);
		
		UserMngVO oldVO = new UserMngVO();
		
		oldVO = userMngDAO.selectUser(vo);
	
		int result = 0;

		String[] athrYnArray = vo.getAthrYnArray();
		String[] mainYnArray = vo.getMainYnArray();
		
		if(athrYnArray != null) {
			userMngDAO.deleteUserAthr(vo);
			
			for(int i=0; i<athrYnArray.length; i++) {
				if(athrYnArray[i].equals("Y")) {	
					vo.setAthrSeqNo(vo.getAthrIdArray()[i]); 
					vo.setMainAthrYn(mainYnArray[i]);
					userMngDAO.insertUserAthrRl(vo);
				}
			}
						
		}

		//update user information
		result = userMngDAO.updateUser(vo);
		
		if (result == 0){
			throw processException("udtFail.msg");
		}

		if (!vo.getEml().equals(oldVO.getEml())){
			log.debug("e-mail change");
			String lgSeqNo1 = lgDAO.insertPubKeyIfLg(user.getUserId(), vo.getUserId(),"14", "2", "6", ""); 
			vo.setLgSeqNo1(lgSeqNo1);
		}		

		if (!vo.getEnNm().equals(oldVO.getEnNm())){
			log.debug("name chage");
			String lgSeqNo2 = lgDAO.insertPubKeyIfLg(user.getUserId(), vo.getUserId(),"13", "2", "6", ""); 
			vo.setLgSeqNo2(lgSeqNo2);
		}

		return vo;
	}

	/**
	 * Biz-method for registering information of new user(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for registering new user(UserMngVO).
	 * @return UserMngVO Primary Key value of registered user
	 * @exception Exception
	 */
	public String modifyUserPkiIf(UserMngVO vo) throws Exception {
		
		log.debug("==================================================");
		log.debug("vo.getLgSeqNo1() : "+vo.getLgSeqNo1());
		log.debug("vo.getLgSeqNo2() : "+vo.getLgSeqNo2());
		log.debug("vo.getUserId() : "+vo.getUserId());
		log.debug("vo.getEnNm()   : "+vo.getEnNm());
		log.debug("vo.getEml()    : "+ vo.getEml());
		log.debug("==================================================");
		
		String status = "";
		String erorYn ="Y";
		
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd());


		OpkiRmWSService orws= new OpkiRmWSService();
		OpkiRmWS orw = orws.getOpkiRmWSPort();
	
		if ( vo.getLgSeqNo1() != null && !"".equals(vo.getLgSeqNo1()) ){
			log.debug("e-mail change");
		    //Officer Account eMail Change
			PkiRsWsResponse prwr = orw.opkiIFmailChange(vo.getUserId(), vo.getEml());
			status= prwr.getStatusCode();
			log.debug("status ====> " + status);
			if("0".equals(status)){
				erorYn ="N";
			}
			lgDAO.updatePubKeyIfLg(vo.getLgSeqNo1(), status, erorYn);
 	
		}		

		if ( vo.getLgSeqNo2() != null && !"".equals(vo.getLgSeqNo2()) ){
			log.debug("name chage");
		    //Officer Account Name Change
			PkiRsWsResponse prwr = orw.opkiIFaccountChange(vo.getUserId(), vo.getEnNm());
			status= prwr.getStatusCode();
			log.debug("status ====> " + status);
			if("0".equals(status)){
				erorYn ="N";
			}
			
			lgDAO.updatePubKeyIfLg(vo.getLgSeqNo2(), status, erorYn);
	
		}

    	return status;
    	
	}
	
	/**
	 * Biz-method for user retirement. <br>
	 * 
	 * @param vo Input item for modifying program(UserMngVO).
	 * @exception Exception
	 */
	public UserMngVO modifyUserRtmt(UserMngVO vo) throws Exception {
		/** Loading session information  */
		
		int result = 0;

		//insert history
		String hstSeqNo = userMngDAO.insertUserHst(vo);
		vo.setHstSeqNo(hstSeqNo);		
		userMngDAO.insertUserAthrHst(vo);
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		
		vo.setLstUdtUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd());

		
		
		result = userMngDAO.updateUserRtmt(vo);
		
		if (result == 0){
			throw processException( "udtFail.msg");
		}

		String lgSeqNo = lgDAO.insertPubKeyIfLg(user.getUserId(), vo.getUserId(), "12", "2", "6", "");
		vo.setLgSeqNo(lgSeqNo);
		
		return vo;
	}	
	
	
	/**
	 * Biz-method for registering information of new user(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for registering new user(UserMngVO).
	 * @return UserMngVO Primary Key value of registered user
	 * @exception Exception
	 */
	public String modifyUserRtmtPkiIf(UserMngVO vo) throws Exception {
		
		log.debug("==================================================");
		log.debug("vo.getLgSeqNo() : " + vo.getLgSeqNo());
		log.debug("vo.getUserId() : "+vo.getUserId());
		log.debug("==================================================");   
		
		String status = "";
		String erorYn ="Y";
		
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd());

		//Officer Account Revocation 
		OpkiRmWSService orws= new OpkiRmWSService();
		OpkiRmWS orw = orws.getOpkiRmWSPort();	
			
		PkiRsWsResponse prwr = orw.opkiIFaccountRevocation(vo.getUserId());
		status= prwr.getStatusCode();
		log.debug("status ====> " + status);
		if("0".equals(status)){
			erorYn ="N";
		}
		
		lgDAO.updatePubKeyIfLg(vo.getLgSeqNo(), status, erorYn);		
		
		
    	return status;
    	
	}	
	
	
	
	/**
	 * Biz-method for User PKI Cert hold.<br>
	 * 
	 * @param vo Input item for modifying program(UserMngVO).
	 * @exception Exception
	 */
	public UserMngVO modifyUserHold(UserMngVO vo) throws Exception {

		int result = 0;

		//insert history
		String hstSeqNo = userMngDAO.insertUserHst(vo);
		vo.setHstSeqNo(hstSeqNo);		
		userMngDAO.insertUserAthrHst(vo);
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd()); //Machine language code

		result = userMngDAO.updateUserHold(vo);
		
		if (result == 0){
			throw processException( "udtFail.msg");
		}
		
		String lgSeqNo = lgDAO.insertPubKeyIfLg(user.getUserId(), vo.getUserId(), "10", "2", "6", "");
		vo.setLgSeqNo(lgSeqNo);
		
		return vo;
	}	
	
	/**
	 * Biz-method for User PKI Cert hold.<br>
	 * 
	 * @param vo Input item for modifying program(UserMngVO).
	 * @exception Exception
	 */
	public String modifyUserHoldPkiIf(UserMngVO vo) throws Exception {

		log.debug("==================================================");
		log.debug("vo.getLgSeqNo() : " + vo.getLgSeqNo());
		log.debug("vo.getUserId() : "+vo.getUserId());
		log.debug("==================================================");
		
		String status = "";
		String erorYn ="Y";

		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd()); //Machine language code

		//Officer PKI Cert Hold 
		OpkiRmWSService orws= new OpkiRmWSService();
		OpkiRmWS orw = orws.getOpkiRmWSPort();		
		PkiRsWsResponse prwr = orw.opkiIFcertHold(vo.getUserId());
		status= prwr.getStatusCode();
		log.debug("status ====> " + status);
		if("0".equals(status)){
			erorYn ="N";
		}
				
		lgDAO.updatePubKeyIfLg(vo.getLgSeqNo(), status, erorYn);
		
	    

    	return status;
	}
	
	
	/**
	 * Biz-method for User PKI Cert Unhold. <br>
	 * 
	 * @param vo Input item for modifying program(UserMngVO).
	 * @exception Exception
	 */
	public UserMngVO modifyUserUnhold(UserMngVO vo) throws Exception {

		int result = 0;

		//insert history
		String hstSeqNo = userMngDAO.insertUserHst(vo);
		vo.setHstSeqNo(hstSeqNo);		
		userMngDAO.insertUserAthrHst(vo);
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd());		

		
		result = userMngDAO.updateUserUnhold(vo);
		
		if (result == 0){
			throw processException( "udtFail.msg");
		}
		
		String lgSeqNo = lgDAO.insertPubKeyIfLg(user.getUserId(), vo.getUserId(), "11", "2", "6", "");		
		vo.setLgSeqNo(lgSeqNo);

		return vo;

	}	
	
	/**
	 * Biz-method for User PKI Cert Unhold. <br>
	 * 
	 * @param vo Input item for modifying program(UserMngVO).
	 * @exception Exception
	 */
	public String modifyUserUnholdPkiIf(UserMngVO vo) throws Exception {
		log.debug("==================================================");
		log.debug("vo.getLgSeqNo() : " + vo.getLgSeqNo());
		log.debug("vo.getUserId() : "+vo.getUserId());
		log.debug("=================================================="); 
		
		String status = "";
		String erorYn ="Y";

		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd());		
		
		//Officer PKI Cert Unhold 
		OpkiRmWSService orws= new OpkiRmWSService();
		OpkiRmWS orw = orws.getOpkiRmWSPort();	
		PkiRsWsResponse prwr = orw.opkiIFcerUnHold(vo.getUserId());
		status= prwr.getStatusCode();
		log.debug("status ====> " + status);
		if("0".equals(status)){
			erorYn ="N";
		}
		
		lgDAO.updatePubKeyIfLg(vo.getLgSeqNo(), status, erorYn);
			    
    	return status;

	}
	
	/**
	 * Biz-method for  PKI Log Insert.<br>
	 * 
	 * @param vo Input item for modifying program(UserMngVO).
	 * @exception Exception
	 */
	public void addPubKeyIfLg(String userId, String msg, String code)  throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		lgDAO.insertPubKeyIfLg(user.getUserId(), userId, msg, code, "2", "");

	}	
	
	/**
	 * Biz-method for finding user password. <br>
	 * 
	 * @param vo Input item for finding user password(UserMngVO).
	 * @return UserManageVO Retrieve information of user password
	 * @exception Exception
	 */
	public UserMngVO searchUserPwd(UserMngVO vo) throws Exception {
		return userMngDAO.selectUserPwd(vo);
	}
	
	/**
	 * Biz-method for retrieving list of user password history. <br>
	 * 
	 * @param vo Input item for retrieving list of user password history(UserManageVO).
	 * @return List Retrieve list of user password history
	 * @exception Exception
	 */
	public List<UserMngVO> searchListUserPwdHst(UserMngVO vo) throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		
		return userMngDAO.selectListUserPwdHst(vo);
	}	
	
	/**
	 * Biz-method for updating user password. <br>
	 * 
	 * @param vo Input item for updating user password.(UserManageVO).
	 * @return UserManageVO updating user password.
	 * @exception Exception
	 */
	public void modifyUserPwd(UserMngVO vo) throws Exception {
		// Encrypt User Password
		if(vo.getPwd() != null && !vo.getPwd().equals("")) {
			String pwd = NidFileScrty.encryptPassword(vo.getPwd());
			vo.setPwd(pwd);
		}
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();

		//insert history
		String hstSeqNo = userMngDAO.insertUserHst(vo);
		vo.setHstSeqNo(hstSeqNo);		
		userMngDAO.insertUserAthrHst(vo);
		
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
		
		userMngDAO.updateUserPwd(vo);

	}

	/**
	 * Biz-method for retrieving total count of user role. <br>
	 * 
	 * @param vo Input item for retrieving list of user role(UserMngVO).
	 * @return int 
	 * @exception Exception
	 */
    public int searchAthrCn(UserMngVO vo) throws Exception{
        return userMngDAO.selectAthrCn(vo);
    }
    
	
	/**
	 * Biz-method for retrieving list of user. <br>
	 * 
	 * @param vo Input item for retrieving list of user(UserManageVO).
	 * @return List Retrieve list of user
	 * @exception Exception*/
	public List<UserMngVO> searchListLgnUserEror(UserMngVO vo) throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		
		return userMngDAO.selectListLgnUserEror(vo);
	}
	
	/**
	 * Biz-method for retrieving total count list of user. <br>
	 * 
	 * @param vo Input item for retrieving list of user(UserManageVO).
	 * @return int Total Count of User List
	 * @exception Exception
	 */
	public int searchListLgnUserErorTotCn(UserMngVO vo) throws Exception {
		return userMngDAO.selectListLgnUserErorTotCn(vo);
	}
	
	/**
	 * Biz-method for user reactivate. <br>
	 * 
	 * @param vo Input item for user reactivate(UserMngVO).
	 * @return 
	 * @exception Exception
	 */
	
	public void modifyuserReatv(UserMngVO vo) throws Exception {

		//insert history
		String hstSeqNo = userMngDAO.insertUserHst(vo);
		vo.setHstSeqNo(hstSeqNo);
		
		userMngDAO.insertUserAthrHst(vo);		
		
		userMngDAO.updateuserReatv(vo);  //Update User

	}
	
	/**
	 * Biz-method for Retrieves list of organization. <br>
	 * 
	 * @param vo Input item for retrieving  list of organization(OrgnzVO).
	 * @return List Retrieves list of organization
	 * @exception Exception
	 */
	public List<UserMngVO> searchListDstr(UserMngVO vo) throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		
		return userMngDAO.selectListDstr(vo);
	}	
	
	
	/**
	 * Biz-method for retrieving list of number of Officers. <br>
	 * 
	 * @param vo Input item for retrieving list of number of Officers(UserMngVO).
	 * @return List Retrieve list of user
	 * @exception Exception
	 */
	public List<UserMngVO> searchListUserNo(UserMngVO vo) throws Exception {
		return userMngDAO.selectListUserNo(vo);
	}

	/**
	 * Biz-method for retrieving total count list of number of Officers. <br>
	 * 
	 * @param vo Input item for retrieving list of number of Officers(UserMngVO).
	 * @return int Total Count of number of Officers
	 * @exception Exception
	 */
	public int searchListUserNoTotCnt(UserMngVO vo) throws Exception {
		return userMngDAO.selectListUserNoTotCnt(vo);
	}
	
	/**
	 * Biz-method for retrieving list of number of Officers(excel down). <br>
	 * 
	 * @param vo Input item for retrieving list of number of Officers(UserMngVO).
	 * @return List Retrieve list of user
	 * @exception Exception
	 */
	public List<UserMngVO> searchListUserNoExcel(UserMngVO vo) throws Exception {
		return userMngDAO.selectListUserNoExcel(vo);
	}
	
	/**
	 * Biz-method for retrieving list of user history. <br>
	 * 
	 * @param vo Input item for retrieving list of user history(UserMngVO).
	 * @return List Retrieve list of user history
	 * @exception Exception
	 */
	public List<UserMngVO> searchListHstUser(UserMngVO vo) throws Exception {
		return userMngDAO.selectListHstUser(vo);
	}

	/**
	 * Biz-method for retrieving total count list of user history. <br>
	 * 
	 * @param vo Input item for retrieving list of user(historyUserMngVO).
	 * @return int Total Count of User history List
	 * @exception Exception
	 */
	public int searchListUserHstTotCnt(UserMngVO vo) throws Exception {
		return userMngDAO.selectListUserHstTotCnt(vo);
	}	
	
	/**
	 * Biz-method for getting user main role. <br>
	 * 
	 * @param vo Input item for getting user main role(UserMngVO).
	 * @return UserMngVO user main role
	 * @exception Exception
	 */
	public UserMngVO searchUserMainAthr(UserMngVO vo) throws Exception{
		/** Loading session information  */	
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(vo.getUserId());
		vo.setUseLangCd(user.getUseLangCd());
		return (UserMngVO)userMngDAO.selectUserMainAthr(vo);
	}		
}