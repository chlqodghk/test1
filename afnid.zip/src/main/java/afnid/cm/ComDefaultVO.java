package afnid.cm;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

/** 
 * This class is default Value Object of common-management
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.04.10
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.04.10  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */
public class ComDefaultVO implements Serializable {

	private static final long serialVersionUID = 1L;

	/** Search condition */
    private String searchCondition = "";
    
    /** Search keyword */
    private String searchKeyword = "";
    
    /** Search Keyword */
    private String searchKeyword2 = "";
    
    /** Search Keyword */
    private String searchKeyword3 = "";
    
    /** Search Keyword */
    private String searchKeyword4 = "";
    
    /** Search Keyword */
    private String searchKeyword5 = "";
    
    /** Search Keyword */
    private String searchKeyword6 = "";
    
    /** Search Keyword */
    private String searchKeyword7 = "";
    
    /** Search Keyword */
    private String searchKeyword8 = "";
    
    /** Search Keyword */
    private String searchKeyword9 = "";
    
    /** Search Keyword */
    private String searchKeyword10 = "";
    
    /** Search Keyword */
    private String searchKeyword11 = "";
    
    /** Search Keyword */
    private String searchKeyword12 = "";

    /** level */
    private String level = "";
    
    /** name */
    private String nm = "";  

	/** Whether to use search */

    private String searchUseYn = "";
    
    /** Current page index */
    private int pageIndex = 1;
    
    
    /** Current page index2 */
    private int pageIndex2 = 1;
    
  

	/** Page unit */
    private int pageUnit = 10;
    
    /** Page size */
    private int pageSize = 10;

    /** First index */
    private int firstIndex = 0;

    /** Last Index */
    private int lastIndex = 1;

    /** Record count per page */
    private int recordCountPerPage = 10;
    
    /** Search keyword from */
    private String searchKeywordFrom = "";    

	/** Search keyword to */
    private String searchKeywordTo = "";  
    
    /** Organization Name */
    private String orgnzNm;
    
    /** User Name */
    private String userNm;
    
    /** Total count */
    private int totCnt;
    
    /** Add a number of days (to subtract Minus) */
    private String addDay;
    
    /** Start Date */
    private String startDay;
    
    /** End Date */
    private String endDay;
    
    /** Language */
    private String useLangCd;
    
    /** menu id */
    private String curMnId;
    
    private String nidGoPage;

	public int getFirstIndex() {
		return firstIndex;
	}

	public void setFirstIndex(int firstIndex) {
		this.firstIndex = firstIndex;
	}

	public int getLastIndex() {
		return lastIndex;
	}

	public void setLastIndex(int lastIndex) {
		this.lastIndex = lastIndex;
	}

	public int getRecordCountPerPage() {
		return recordCountPerPage;
	}

	public void setRecordCountPerPage(int recordCountPerPage) {
		this.recordCountPerPage = recordCountPerPage;
	}

	public String getSearchCondition() {
        return searchCondition;
    }

    public void setSearchCondition(String searchCondition) {
        this.searchCondition = searchCondition;
    }

    public String getSearchKeyword() {
        return searchKeyword;
    }

    public void setSearchKeyword(String searchKeyword) {
        this.searchKeyword = searchKeyword;
    }

    public String getSearchKeyword2() {
		return searchKeyword2;
	}

	public void setSearchKeyword2(String searchKeyword2) {
		this.searchKeyword2 = searchKeyword2;
	}

	public String getSearchKeyword3() {
		return searchKeyword3;
	}

	public void setSearchKeyword3(String searchKeyword3) {
		this.searchKeyword3 = searchKeyword3;
	}

	public String getSearchKeyword4() {
		return searchKeyword4;
	}

	public void setSearchKeyword4(String searchKeyword4) {
		this.searchKeyword4 = searchKeyword4;
	}

	public String getSearchKeyword5() {
		return searchKeyword5;
	}

	public void setSearchKeyword5(String searchKeyword5) {
		this.searchKeyword5 = searchKeyword5;
	}

	public String getSearchUseYn() {
        return searchUseYn;
    }

    public void setSearchUseYn(String searchUseYn) {
        this.searchUseYn = searchUseYn;
    }

    public int getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public int getPageUnit() {
        return pageUnit;
    }

    public void setPageUnit(int pageUnit) {
        this.pageUnit = pageUnit;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    
    /**
	 * searchKeywordFrom attribute를 리턴한다.
	 * @return String
	 */
	public String getSearchKeywordFrom() {
		return searchKeywordFrom;
	}

	/**
	 * searchKeywordFrom attribute 값을 설정한다.
	 * @param searchKeywordFrom String
	 */
	public void setSearchKeywordFrom(String searchKeywordFrom) {
		this.searchKeywordFrom = searchKeywordFrom;
	}

	/**
	 * searchKeywordTo attribute를 리턴한다.
	 * @return String
	 */
	public String getSearchKeywordTo() {
		return searchKeywordTo;
	}

	/**
	 * searchKeywordTo attribute 값을 설정한다.
	 * @param searchKeywordTo String
	 */
	public void setSearchKeywordTo(String searchKeywordTo) {
		this.searchKeywordTo = searchKeywordTo;
	}
	
	public String getOrgnzNm() {
		return orgnzNm;
	}

	public void setOrgnzNm(String orgnzNm) {
		this.orgnzNm = orgnzNm;
	}

	public String getUserNm() {
		return userNm;
	}

	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
    
    
	public int getTotCnt() {
		return totCnt;
	}

	public void setTotCnt(int totCnt) {
		this.totCnt = totCnt;
	}

	public String getAddDay() {
		return addDay;
	}

	public void setAddDay(String addDay) {
		this.addDay = addDay;
	}

	public String getStartDay() {
		return startDay;
	}

	public void setStartDay(String startDay) {
		this.startDay = startDay;
	}

	public String getEndDay() {
		return endDay;
	}

	public void setEndDay(String endDay) {
		this.endDay = endDay;
	}
	
	public String getSearchKeyword6() {
		return searchKeyword6;
	}

	public void setSearchKeyword6(String searchKeyword6) {
		this.searchKeyword6 = searchKeyword6;
	}

	public String getSearchKeyword7() {
		return searchKeyword7;
	}

	public void setSearchKeyword7(String searchKeyword7) {
		this.searchKeyword7 = searchKeyword7;
	}

	public String getSearchKeyword8() {
		return searchKeyword8;
	}

	public void setSearchKeyword8(String searchKeyword8) {
		this.searchKeyword8 = searchKeyword8;
	}

	public String getSearchKeyword9() {
		return searchKeyword9;
	}

	public void setSearchKeyword9(String searchKeyword9) {
		this.searchKeyword9 = searchKeyword9;
	}

	public String getSearchKeyword10() {
		return searchKeyword10;
	}

	public void setSearchKeyword10(String searchKeyword10) {
		this.searchKeyword10 = searchKeyword10;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}
	
	public String getNm() {
		return nm;
	}

	public void setNm(String nm) {
		this.nm = nm;
	}

	public String getUseLangCd() {
		return useLangCd;
	}

	public void setUseLangCd(String useLangCd) {
		this.useLangCd = useLangCd;
	}
    public int getPageIndex2() {
		return pageIndex2;
	}

	public void setPageIndex2(int pageIndex2) {
		this.pageIndex2 = pageIndex2;
	}

	public String getCurMnId() {
		return curMnId;
	}

	public void setCurMnId(String curMnId) {
		this.curMnId = curMnId;
	}

	public String getNidGoPage() {
		return nidGoPage;
	}

	public void setNidGoPage(String nidGoPage) {
		this.nidGoPage = nidGoPage;
	}

	public String getSearchKeyword11() {
		return searchKeyword11;
	}

	public void setSearchKeyword11(String searchKeyword11) {
		this.searchKeyword11 = searchKeyword11;
	}

	public String getSearchKeyword12() {
		return searchKeyword12;
	}

	public void setSearchKeyword12(String searchKeyword12) {
		this.searchKeyword12 = searchKeyword12;
	}

	
		
}
