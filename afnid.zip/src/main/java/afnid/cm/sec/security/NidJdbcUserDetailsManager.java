package afnid.cm.sec.security;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContextException;
import org.springframework.dao.DataAccessException;
import org.springframework.security.GrantedAuthority;
import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.userdetails.UsernameNotFoundException;
import org.springframework.security.userdetails.hierarchicalroles.RoleHierarchy;
import org.springframework.security.userdetails.jdbc.JdbcUserDetailsManager;

import egovframework.rte.fdl.string.EgovObjectUtil;

/**
 * JdbcUserDetailsManager 클래스 재정의
 * 
 * @author sjyoon
 * @since 2009.06.01
 * @version 1.0
 * @see
 *
 * <pre>
 * << 개정이력(Modification Information) >>
 *   
 *   수정일      수정자           수정내용
 *  -------    -------------    ----------------------
 *   2009.03.10  sjyoon    최초 생성
 *
 * </pre>
 */

public class NidJdbcUserDetailsManager extends JdbcUserDetailsManager {
	
	private NidUserDetails userDetails = null;
    private NidUsersByUsernameMapping usersByUsernameMapping;
	
    private String mapClass;
    @SuppressWarnings("unused")
	private RoleHierarchy roleHierarchy = null;
    
    /**
     * Status column of the user table with a query in a user session, VO and specifies the class to be mapped.
     * @param mapClass String
     */
    public void setMapClass(String mapClass) {
    	this.mapClass = mapClass;
    }
    
    /**
     * Role Hierarchy Supports.
     * (org.springframework.security.userdetails.hierarchicalroles.RoleHierarchyImpl)
     * @param roleHierarchy RoleHierarchy
     */
    public void setRoleHierarchy(RoleHierarchy roleHierarchy) {
    	this.roleHierarchy = roleHierarchy;
    }
    
    /*
     * (non-Javadoc)
     * @see org.springframework.security.userdetails.jdbc.JdbcUserDetailsManager#initDao()
     */
    @Override
    protected void initDao() throws ApplicationContextException {
    	super.initDao();

    	try {
    		initMappingSqlQueries();
    	} catch (ClassNotFoundException e) {
    		logger.error("NidJdbcUserDetailsManager.initDao.ClassNotFoundException : " + e.toString(), e);
    	} catch (NoSuchMethodException e) {
    		logger.error("NidJdbcUserDetailsManager.initDao.NoSuchMethodException : " + e.toString(), e);
    	} catch (InstantiationException e) {
    		logger.error("NidJdbcUserDetailsManager.initDao.InstantiationException : " + e.toString(), e);
    	} catch (IllegalAccessException e) {
    		logger.error("NidJdbcUserDetailsManager.initDao.IllegalAccessException : " + e.toString(), e);
    	} catch (InvocationTargetException e) {
    		logger.error("NidJdbcUserDetailsManager.initDao.InvocationTargetException : " + e.toString(), e);
    	} catch (Exception e) {
    		logger.error("NidJdbcUserDetailsManager.initDao.Exception : " + e.toString(), e);
    	}

    }
    
	/**
	 * jdbc-user-service의 usersByUsernameQuery User queries and query
	 * authoritiesByUsernameQuery By permission lookup queries store information.
	 */
	private void initMappingSqlQueries()
		throws InvocationTargetException, IllegalAccessException, InstantiationException, NoSuchMethodException, ClassNotFoundException, Exception {

		logger.debug("## NidJdbcUserDetailsManager query : " + getUsersByUsernameQuery());
		setUsersByUsernameQuery(getUsersByUsernameQuery());
		
		Class <?> clazz = EgovObjectUtil.loadClass(this.mapClass);
		Constructor <?> constructor = clazz.getConstructor(new Class []{DataSource.class, String.class});
		Object [] params = new Object []{getDataSource(), getUsersByUsernameQuery()};

		this.usersByUsernameMapping = (NidUsersByUsernameMapping) constructor.newInstance(params);
    }

	/**
	 * JdbcDaoImpl Of the class loadUsersByUsername Methods of financial
	 * Username(OR ID) NidUserDetails Status information is stored in the form of a list.
	 * 	 */
	@SuppressWarnings("unchecked")
	@Override
	protected List<String> loadUsersByUsername(String username) {
        return usersByUsernameMapping.execute(username);
    }

	/**
	 * JdbcDaoImpl Of the class loadUsersByUsername Methods of financial
	 * Username(OR ID) NidUserDetails To look up information.
	 * @param username String
	 * @return NidUserDetails
	 * @throws UsernameNotFoundException
	 * @throws DataAccessException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NidUserDetails loadUserByUsername(String username) throws UsernameNotFoundException, DataAccessException {
		
        List<?> users = loadUsersByUsername(username);

        if (users.size() == 0) {
            throw new UsernameNotFoundException(
                    messages.getMessage("JdbcDaoImpl.notFound", new Object[]{username}, "Username {0} not found"), username);
        }

        Object obj = users.get(0);
        this.userDetails = (NidUserDetails) obj;

        Set<String> dbAuthsSet = new HashSet<String>();

        //if (enableAuthorities) {
            dbAuthsSet.addAll(loadUserAuthorities(this.userDetails.getUsername()));
        //}
        
        List<String> dbAuths = new ArrayList<String>(dbAuthsSet);

        addCustomAuthorities(this.userDetails.getUsername(), dbAuths);

        if (dbAuths.size() == 0) {
            throw new UsernameNotFoundException(
                    messages.getMessage("NidJdbcUserDetailsManager.noAuthority",
                            new Object[] {username}, "User {0} has no GrantedAuthority"), username);
		}

        GrantedAuthority[] authorities = (GrantedAuthority[]) dbAuths.toArray(new GrantedAuthority[dbAuths.size()]);
        
        // Stored in RoleHierarchyImpl Role Hierarchy Information is stored.
        //GrantedAuthority[] authorities = roleHierarchy.getReachableGrantedAuthorities(arrayAuths);
        
        // JdbcDaoImpl of the class createUserDetails Methods of financial
        return new NidUserDetails(this.userDetails.getUsername(), this.userDetails.getPassword(), this.userDetails.isEnabled(), 
                true, true, true, authorities, this.userDetails.getEgovUserVO());
    }

	/**
	 * Authenticated username of the user information(NidUserDetails) brings. 
	 * @return NidUserDetails
	 * @throws UsernameNotFoundException
	 * @throws DataAccessException
	 */
	public NidUserDetails getAuthenticatedUser() throws UsernameNotFoundException, DataAccessException {

		return loadUserByUsername(SecurityContextHolder.getContext().getAuthentication().getName());
    }

}
