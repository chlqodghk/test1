package afnid.cm.sec.security;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.MappingSqlQuery;

/**
 * MappingSqlQuery Class of financial
 * 
 * @author sjyoon
 * @since 2009.06.01
 * @version 1.0
 * @see
 *
 * <pre>
 * << Revision history(Modification Information) >>
 *   
 *   Modified      Modifiers           Modifications
 *  -------    -------------    ----------------------
 *   2009.03.10  sjyoon     The first generation
 *
 * </pre>
 */

public abstract class NidUsersByUsernameMapping  extends MappingSqlQuery {

	/**
	 * The user can query the information in the table is mapped to the user object.
	 * @param ds DataSource
	 * @param usersByUsernameQuery String
	 */
	public NidUsersByUsernameMapping(DataSource ds, String usersByUsernameQuery) {
        super(ds, usersByUsernameQuery);
        declareParameter(new SqlParameter(Types.VARCHAR));
        compile();
    }

	/* (non-Javadoc)
	 * @see org.springframework.jdbc.object.MappingSqlQuery#mapRow(java.sql.ResultSet, int)
	 */
	/**
	 * mapRow Abstract class
	 * jdbc-user-service Specified in users-by-username-query To query the query statement
	 * Is mapped to a ResultSet.
	 * 
	 * Example)
	 * protected Object mapRow(ResultSet rs, int rownum) throws SQLException; {
	 * 	 String userid = rs.getString(0);
	 *   String password = rs.getString(1);
     *   boolean enabled = rs.getBoolean(2);
     *
     *   EgovUserVO userVO = new EgovUserVO();
     *   userVO.setUserId(userid);
     *   userVO.setPassWord(password);
     *
     *   return new EgovUser(userid, password, enabled, userVO);
     * }
	 */
	@Override
    protected abstract Object mapRow(ResultSet rs, int rownum) throws SQLException;
}
