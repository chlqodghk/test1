package afnid.cm.sec.security;

import org.springframework.security.GrantedAuthority;
import org.springframework.security.GrantedAuthorityImpl;
import org.springframework.security.userdetails.User;

/**
 * Extension classes of the User class
 * 
 * @author ByungHun Woo
 * @since 2009.06.01
 * @version 1.0
 * @see
 *
 * <pre>
 *
 *   
 *
 *  -------    -------------    ----------------------
 *   2009.03.10  ByungHun Woo    The first generation
 *
 * </pre>
 */

public class NidUserDetails extends User {

	private static final long serialVersionUID = 1L;

	/**
	 * User The constructor of the class Override
	 * @param username User Account
	 * @param password User Password
	 * @param enabled Whether to use a user account
	 * @param accountNonExpired boolean
	 * @param credentialsNonExpired boolean
	 * @param accountNonLocked boolean
	 * @param authorities GrantedAuthority[]
	 * @param egovVO User VO Object
	 * @throws IllegalArgumentException 
	 */
	public NidUserDetails(String username, String password, boolean enabled,
			boolean accountNonExpired, boolean credentialsNonExpired,
			boolean accountNonLocked, GrantedAuthority[] authorities, Object egovVO)
			throws IllegalArgumentException {
    	
		super(username, password, enabled, accountNonExpired, credentialsNonExpired,
				accountNonLocked, authorities);

		this.egovVO = egovVO;
	}
	
	/**
	 * NidUserDetails Constructors
	 * @param username String
	 * @param password String
	 * @param enabled boolean
	 * @param egovVO User VO Object
	 * @throws IllegalArgumentException
	 */
	public NidUserDetails(String username, String password, boolean enabled, Object egovVO)
	    throws IllegalArgumentException {
		this(username, password, enabled, true, true, true, new GrantedAuthority[] {new GrantedAuthorityImpl("HOLDER")}, egovVO);
	}

	private Object egovVO;	

	/**
	 * getEgovUserVO
	 * @return UserVO Object
	 */
	public Object getEgovUserVO() {
		return egovVO;
	}

	/**
	 * setEgovUserVO
	 * @param egovVO UserVOObject
	 */
	public void setEgovUserVO(Object egovVO) {
		this.egovVO = egovVO;
	}
}
