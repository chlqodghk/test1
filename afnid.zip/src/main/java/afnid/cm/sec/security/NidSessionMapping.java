package afnid.cm.sec.security;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import afnid.cm.uat.service.LgnVO;

/**
 * mapRow NidUserDetails Object are defined in your results.
 * 
 * @author ByungHun Woo
 * @since 2009.06.01
 * @version 1.0
 * @see
 *
 * <pre>
 * 
 *   
 *   
 *  -------    -------------    ----------------------
 *   2009.03.10  ByungHun Woo  
 *   
 *
 * </pre>
 */

public class NidSessionMapping extends NidUsersByUsernameMapping {
	
	/**
	 * The user can query the information in the table is mapped to EgovUsersByUsernameMapping.
	 * @param ds DataSource
	 * @param usersByUsernameQuery String
	 */
	public NidSessionMapping(DataSource ds, String usersByUsernameQuery) {
        super(ds, usersByUsernameQuery);
    }

	/**
	 * mapRow Override
	 * @param rs ResultSet Result
	 * @param rownum row num
	 * @return Object NidUserDetails
	 * @exception SQLException
	 */
	@Override
    protected Object mapRow(ResultSet rs, int rownum) throws SQLException {
		logger.debug("## NidUsersByUsernameMapping mapRow ##");
		
		String strUserSeqNo = rs.getString("USER_SEQ_NO");
		String strUserId = rs.getString("USER_ID");											//User ID
		String strPassWord = "";
		boolean strEnabled = true;
		
		String strOrgnzCd 		= rs.getString("ORGNZ_CD");			//Organization code
		String strPstOrgnzNm 	= rs.getString("PST_ORGNZ_NM");		//Pst Organization Name
		String strDrOrgnzNm 	= rs.getString("DR_ORGNZ_NM");		//Dr Organization Name
		String strEnOrgnzNm 	= rs.getString("EN_ORGNZ_NM");		//EN Organization Name
		
		String strOfcalPsnCd	= rs.getString("OFCAL_PSN_CD");
		String strPstOfcalPsnCd	= rs.getString("PST_OFCAL_PSN_NM");
		String strDrOfcalPsnCd	= rs.getString("DR_OFCAL_PSN_NM");
		String strEnOfcalPsnCd	= rs.getString("EN_OFCAL_PSN_NM");

		String name			    = rs.getString("NM");
		String teamCd		    = rs.getString("TAM_CD");
		String teamCdNm		    = rs.getString("TAM_CD_NM");
		
		
		String orgnzClsCd      = rs.getString("ORGNZ_CLS_CD");
		String pstOrgnzClsCdNm = rs.getString("PST_ORGNZ_CLS_CD_NM");
		String drOrgnzClsCdNm  = rs.getString("DR_ORGNZ_CLS_CD_NM");
		String enOrgnzClsCdNm  = rs.getString("EN_ORGNZ_CLS_CD_NM");
        
        String strCurSystem = ""; //The current system
        if(rs.getString("ORGNZ_CLS_CD") != null && "1".equals(rs.getString("ORGNZ_CLS_CD")))
        	strCurSystem = "cm";
        else if(rs.getString("ORGNZ_CLS_CD") != null && "2".equals(rs.getString("ORGNZ_CLS_CD")))
        	strCurSystem = "rm";
        
        String nticYn = rs.getString("NTIC_YN");
        String enLgnYn = rs.getString("EN_LGN_YN");	
        
        // Set the session item
		LgnVO lgnVO = new LgnVO();
      
		lgnVO.setUserSeqNo(strUserSeqNo);
		lgnVO.setUserId(strUserId);	
		lgnVO.setOrgnzCd(strOrgnzCd);
		lgnVO.setPstOrgnzNm(strPstOrgnzNm);
		lgnVO.setDrOrgnzNm(strDrOrgnzNm);
		lgnVO.setEnOrgnzNm(strEnOrgnzNm);
	    lgnVO.setOfcalPsnCd(strOfcalPsnCd);
		lgnVO.setPstOfcalPsnNm(strPstOfcalPsnCd);
		lgnVO.setDrOfcalPsnNm(strDrOfcalPsnCd);
		lgnVO.setEnOfcalPsnNm(strEnOfcalPsnCd);
		lgnVO.setCurSystemCd(strCurSystem);	      
		lgnVO.setNm(name);
		lgnVO.setTamCd(teamCd);
	    
	    if(teamCdNm == null){
	      teamCdNm = "";
	    }
	    
	    lgnVO.setTamCdNm(teamCdNm);
	      
	    lgnVO.setOrgnzClsCd(orgnzClsCd);
	    lgnVO.setPstOrgnzClsCdNm(pstOrgnzClsCdNm);
	    lgnVO.setDrOrgnzClsCdNm(drOrgnzClsCdNm);
	    lgnVO.setEnOrgnzClsCdNm(enOrgnzClsCdNm);
	    lgnVO.setNticYn(nticYn);
	    lgnVO.setCert("");
	    lgnVO.setEnLgnYn(enLgnYn);
	    
	    return new NidUserDetails(strUserId, strPassWord, strEnabled, lgnVO);
        
        
    }
}
