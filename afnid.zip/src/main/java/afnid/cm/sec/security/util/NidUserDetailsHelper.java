package afnid.cm.sec.security.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.Authentication;
import org.springframework.security.GrantedAuthority;
import org.springframework.security.context.SecurityContext;
import org.springframework.security.context.SecurityContextHolder;

import afnid.cm.sec.security.NidUserDetails;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.fdl.string.EgovObjectUtil;

/**
 * NidUserDetailsHelper 클래스
 * 
 * @author sjyoon
 * @since 2009.06.01
 * @version 1.0
 * @see
 *
 * <pre>
 *<< Revision history(Modification Information) >>
 *   
 *   Modified      Modifiers           Modifications
 *  -------    -------------    ----------------------
 *   2009.03.10  sjyoon   The first generation
 *
 * </pre>
 */

public class NidUserDetailsHelper {
	
		/**
		 * Authenticated user in the form of an object brings VO.
		 * @return Object - User ValueObject
		 */
		public static Object getAuthenticatedUser() {
			SecurityContext context = SecurityContextHolder.getContext();
			Authentication authentication = context.getAuthentication();
			
			if (EgovObjectUtil.isNull(authentication)) {
				// log.debug("## authentication object is null!!");
				return null;
			}
			
			if (authentication.getPrincipal() instanceof String) {
				
				return authentication.getPrincipal();
				
			}
			NidUserDetails details = (NidUserDetails) authentication.getPrincipal();
			
			// log.debug("## NidUserDetailsHelper.getAuthenticatedUser : AuthenticatedUser is " + details.getUsername());
			return details.getEgovUserVO();
		}

		/**
		 * Brings the credentials of the authenticated user.
		 * Example) [ROLE_ADMIN, ROLE_USER, ROLE_A, ROLE_B, ROLE_RESTRICTED, IS_AUTHENTICATED_FULLY, IS_AUTHENTICATED_REMEMBERED, IS_AUTHENTICATED_ANONYMOUSLY]
		 * @return List - List of user rights information
		 */
		public static List<String> getAuthorities() {
			List<String> listAuth = new ArrayList<String>();
			
			SecurityContext context = SecurityContextHolder.getContext();
			Authentication authentication = context.getAuthentication();
			
			if (EgovObjectUtil.isNull(authentication)) {
				//log.debug("## authentication object is null!!");
				return null;
			}
			
			GrantedAuthority[] authorities = authentication.getAuthorities();

			for (int i = 0; i < authorities.length; i++) {
				listAuth.add(authorities[i].getAuthority());

				// log.debug("## NidUserDetailsHelper.getAuthorities : Authority is " + authorities[i].getAuthority());
			}

			return listAuth;
		}
		
		/**
		 * Check whether the user is authenticated.
		 * @return Boolean - Whether an authenticated user(TRUE / FALSE)	
		 */
		public static Boolean isAuthenticated() {
			SecurityContext context = SecurityContextHolder.getContext();
			Authentication authentication = context.getAuthentication();
			
			if (EgovObjectUtil.isNull(authentication)) {
				// log.debug("## authentication object is null!!");
				return Boolean.FALSE;
			}
			
			String username = authentication.getName();
			if ("roleAnonymous".equals(username)) {
				// log.debug("## username is " + username);
				return Boolean.FALSE;
			}

			Object principal = authentication.getPrincipal();
			
			return Boolean.valueOf(!EgovObjectUtil.isNull(principal));
		}
		
		/**
		 * Authenticated users to change the system language is set.
		 * @return Object - User ValueObject
		 */
		public static void changeUserLangSet(String language) {
			SecurityContext context = SecurityContextHolder.getContext();
			Authentication authentication = context.getAuthentication();

			NidUserDetails details = (NidUserDetails) authentication.getPrincipal();
			LgnVO user = (LgnVO)details.getEgovUserVO();
			
			user.setUseLangCd(language);
			
			details.setEgovUserVO(user);
		}
		
		/**
		 * Authenticated users to change the system language is set.
		 * @return Object - User ValueObject
		 */
		public static void changeUserCurSystem(String system) {
			SecurityContext context = SecurityContextHolder.getContext();
			Authentication authentication = context.getAuthentication();

			NidUserDetails details = (NidUserDetails) authentication.getPrincipal();
			LgnVO user = (LgnVO)details.getEgovUserVO();
			
			user.setCurSystemCd(system);
			
			details.setEgovUserVO(user);
		}
		
		public static boolean isAuthor(String athrId) {
			boolean isAuthor = false;
			List<String> listAuth = new ArrayList<String>();
			
			SecurityContext context = SecurityContextHolder.getContext();
			Authentication authentication = context.getAuthentication();
			
			if (EgovObjectUtil.isNull(authentication)) {
				//log.debug("## authentication object is null!!");
				return false;
			}
			
			GrantedAuthority[] authorities = authentication.getAuthorities();

			for (int i = 0; i < authorities.length; i++) {
				listAuth.add(authorities[i].getAuthority());
				
				if(authorities[i].getAuthority().equals(athrId))
					isAuthor = true;

				// log.debug("## NidUserDetailsHelper.getAuthorities : Authority is " + authorities[i].getAuthority());
			}
			
			return isAuthor;

		}
		
		public static boolean isManagerAuthor() {
			//String mgrAthrId = "SUPER_SYS_MGR";
			boolean isAuthor = false;
			List<String> listAuth = new ArrayList<String>();
			
			SecurityContext context = SecurityContextHolder.getContext();
			Authentication authentication = context.getAuthentication();
			
			if (EgovObjectUtil.isNull(authentication)) {
				//log.debug("## authentication object is null!!");
				return false;
			}
			
			GrantedAuthority[] authorities = authentication.getAuthorities();

			for (int i = 0; i < authorities.length; i++) {
				listAuth.add(authorities[i].getAuthority());
				
				if(authorities[i].getAuthority().indexOf("_MG")>0)
					isAuthor = true;

				// log.debug("## NidUserDetailsHelper.getAuthorities : Authority is " + authorities[i].getAuthority());
			}
			
			return isAuthor;

		}
		
		
		/**
		 * Authenticated users to change the system language is set.
		 * @return Object - User ValueObject
		 */
		public static void changeNticYnSet(String nticYn) {
			SecurityContext context = SecurityContextHolder.getContext();
			Authentication authentication = context.getAuthentication();

			NidUserDetails details = (NidUserDetails) authentication.getPrincipal();
			LgnVO user = (LgnVO)details.getEgovUserVO();
			
			user.setNticYn(nticYn);
			
			details.setEgovUserVO(user);
		}
		
}
