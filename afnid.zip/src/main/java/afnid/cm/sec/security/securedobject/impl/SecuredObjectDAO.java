package afnid.cm.sec.security.securedobject.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.security.ConfigAttributeDefinition;
import org.springframework.security.SecurityConfig;
import org.springframework.security.intercept.web.RequestKey;

import afnid.cm.sec.security.securedobject.SecuredObjectService;

/**
 *Secured Object DB-based information to provide the default query with DAO
 * Which provides for each type of user in the DB is reset DB queries.
 * namedParameterJdbcTemplate DB queries using the handles.
 * 
 * @author ByungHun Woo
 * @since 2009.06.01
 * @version 1.0
 * @see
 *
 * <pre>
* << Revision history(Modification Information) >>
 *   
 *   Modified      Modifiers           Modifications
 *  -------    -------------    ----------------------
 *   2009.03.10  ByungHun Woo     The first generation
 *   2009.03.20  MoonJun Lee          UPDATE
 *
 * </pre>
 */
public class SecuredObjectDAO {

    /**
     * url format is a protected resource - Role mapping information is to query the default query.
     */
//    public static final String DEF_ROLES_AND_URL_QUERY =                                 
//     "SELECT a.ROLE_PTN url, b.AUTHOR_CODE authority     "
//    +"  FROM COMTNROLEINFO a, COMTNAUTHORROLERELATE b    "
//    +" WHERE a.ROLE_CODE = b.ROLE_CODE                   "
//    +"   AND a.ROLE_TYP = 'url'  ORDER BY a.ROLE_SORT    ";
    
    
    public static final String DEF_ROLES_AND_URL_QUERY =                                 
    	"	SELECT DISTINCT D.ACES_TYE_CT URL,	"
    	+"		 A.ATHR_SEQ_NO AUTHORITY	"
    	+"		FROM   CM_MN_ATHR_RL_TB A,	"
    	+"		CM_MN_TB B,	"
    	+"		 CM_MN_ACES_CTL_RL_TB C,	"
    	+"		 CM_ACES_CTL_TB D	"
    	+"		WHERE  A.MN_SEQ_NO = B.MN_SEQ_NO	"
    	+"		AND    B.MN_SEQ_NO = C.MN_SEQ_NO	"
    	+"		AND    C.ACES_SEQ_NO = D.ACES_SEQ_NO	"
    	+"		AND    ACES_TYE_CD = 1	"
    	+"		ORDER BY D.ACES_TYE_CT	";

    /**
     * type of method protected resource - Role mapping information is to query default query.
     */
//    public static final String DEF_ROLES_AND_METHOD_QUERY =
//        "SELECT a.ROLE_PTN \"method\", b.AUTHOR_CODE authority   "
//        +"  FROM COMTNROLEINFO a, COMTNAUTHORROLERELATE b    "
//        +" WHERE a.ROLE_CODE = b.ROLE_CODE                   "
//        +"   AND a.ROLE_TYP = 'method'  ORDER BY a.ROLE_SORT ";    
    
    public static final String DEF_ROLES_AND_METHOD_QUERY =
    	"	SELECT DISTINCT D.ACES_TYE_CT URL,	"
    	+"		 A.ATHR_SEQ_NO AUTHORITY	"
    	+"		FROM   CM_MN_ATHR_RL_TB A,	"
    	+"		CM_MN_TB B,	"
    	+"		 CM_MN_ACES_CTL_RL_TB C,	"
    	+"		 CM_ACES_CTL_TB D	"
    	+"		WHERE  A.MN_SEQ_NO = B.MN_SEQ_NO	"
    	+"		AND    B.MN_SEQ_NO = C.MN_SEQ_NO	"
    	+"		AND    C.ACES_SEQ_NO = D.ACES_SEQ_NO	"
    	+"		AND    ACES_TYE_CD = 2	"
    	+"		ORDER BY D.ACES_TYE_CT	";
        /*"SELECT T1.ROL_TYE_CT METHOD,   "
        +"  T2.ATHR_ID    AUTHORITY    "
        +" FROM CM_ROL_TB T1, CM_ROL_ATHR_RL_TB T2                   "
        +"   WHERE T1.ROL_ID=T2.ROL_ID "
        +"   AND T1.ROL_TYE_CD='0002' "
        +"   ORDER BY T1.ROL_SOT_NO ";*/
    	
    /**
     * pointcut type of protected resource - Role mapping information to look up default
     * Is a query.
     */
//    public static final String DEF_ROLES_AND_POINTCUT_QUERY =
//        "SELECT a.ROLE_PTN pointcut, b.AUTHOR_CODE authority   "
//        +"  FROM COMTNROLEINFO a, COMTNAUTHORROLERELATE b    "
//        +" WHERE a.ROLE_CODE = b.ROLE_CODE                   "
//        +"   AND a.ROLE_TYP = 'pointcut'  ORDER BY a.ROLE_SORT ";    
    
    public static final String DEF_ROLES_AND_POINTCUT_QUERY =
    	"	SELECT DISTINCT D.ACES_TYE_CT URL,	"
    	+"		 A.ATHR_SEQ_NO AUTHORITY	"
    	+"		FROM   CM_MN_ATHR_RL_TB A,	"
    	+"		CM_MN_TB B,	"
    	+"		 CM_MN_ACES_CTL_RL_TB C,	"
    	+"		 CM_ACES_CTL_TB D	"
    	+"		WHERE  A.MN_SEQ_NO = B.MN_SEQ_NO	"
    	+"		AND    B.MN_SEQ_NO = C.MN_SEQ_NO	"
    	+"		AND    C.ACES_SEQ_NO = D.ACES_SEQ_NO	"
    	+"		AND    ACES_TYE_CD = 3	"
    	+"		ORDER BY D.ACES_TYE_CT	";
    	/*"SELECT T1.ROL_TYE_CT POINTCUT,   "
        +"  T2.ATHR_ID    AUTHORITY    "
        +" FROM CM_ROL_TB T1, CM_ROL_ATHR_RL_TB T2                   "
        +"   WHERE T1.ROL_ID=T2.ROL_ID "
        +"   AND T1.ROL_TYE_CD='0003' "
        +"   ORDER BY T1.ROL_SOT_NO ";*/
    
    /**
     * Best matching url every request for each protected resource - Role mapping information
     * Is to get the default query. (Oracle 10g specific)
     */
    public static final String DEF_REGEX_MATCHED_REQUEST_MAPPING_QUERY_ORACLE10G =
        "SELECT a.resource_pattern uri, b.authority authority   "
        + " FROM COMTNSECURED_RESOURCES a, COMTNSECURED_RESOURCES_ROLE b   "
        + " WHERE a.resource_id = b.resource_id   "
        + " AND a.resource_type = 'url' ";
    
    
    
    
    /*****************************************************************
	    "SELECT a.resource_pattern uri, b.authority authority "
	    + "FROM secured_resources a, secured_resources_role b "
	    + "WHERE a.resource_id = b.resource_id "
	    + "AND a.resource_id =  "
	    + " ( SELECT resource_id FROM "
	    + "    ( SELECT resource_id, ROW_NUMBER() OVER (ORDER BY sort_order) resource_order FROM secured_resources c "
	    + "      WHERE REGEXP_LIKE ( :url, c.resource_pattern ) "
	    + "      AND c.resource_type = 'url' "
	    + "      ORDER BY c.sort_order ) "
	    + "   WHERE resource_order = 1 ) ";
    */
    
    
    /**
     *Role of the hierarchy (Hierarchy) is the relationship between a query to query the default.
     */
//    public static final String DEF_HIERARCHICAL_ROLES_QUERY =
//        "SELECT a.child_role child, a.parent_role parent "
//        + "FROM COMTNROLES_HIERARCHY a LEFT JOIN COMTNROLES_HIERARCHY b on (a.child_role = b.parent_role) ";
    
    public static final String DEF_HIERARCHICAL_ROLES_QUERY =
        "SELECT '9' child, '99' parent "
        + " FROM DUAL ";

    private String sqlRolesAndUrl;

    private String sqlRolesAndMethod;

    private String sqlRolesAndPointcut;

    private String sqlRegexMatchedRequestMapping;

    private String sqlHierarchicalRoles;
    
	/**
	 * SecuredObjectDAO Constructors
	 */
    public SecuredObjectDAO() {
        this.sqlRolesAndUrl = DEF_ROLES_AND_URL_QUERY;
        this.sqlRolesAndMethod = DEF_ROLES_AND_METHOD_QUERY;
        this.sqlRolesAndPointcut = DEF_ROLES_AND_POINTCUT_QUERY;
        this.sqlRegexMatchedRequestMapping = DEF_REGEX_MATCHED_REQUEST_MAPPING_QUERY_ORACLE10G;
        this.sqlHierarchicalRoles = DEF_HIERARCHICAL_ROLES_QUERY;
    }

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
    
	/**
	 * setDataSource
	 * @param dataSource DataSource
	 */
    public void setDataSource(DataSource dataSource) {
        this.namedParameterJdbcTemplate =
            new NamedParameterJdbcTemplate(dataSource);
    }

	/**
	 * getSqlRolesAndUrl
	 * @return String
	 */
    public String getSqlRolesAndUrl() {
        return sqlRolesAndUrl;
    }

	/**
	 * setSqlRolesAndUrl
	 * @param sqlRolesAndUrl String
	 */
    public void setSqlRolesAndUrl(String sqlRolesAndUrl) {
        this.sqlRolesAndUrl = sqlRolesAndUrl;
    }

	/**
	 * getSqlRolesAndMethod
	 * @return String
	 */
    public String getSqlRolesAndMethod() {
        return sqlRolesAndMethod;
    }

	/**
	 * setSqlRolesAndMethod
	 * @param sqlRolesAndMethod String
	 */
    public void setSqlRolesAndMethod(String sqlRolesAndMethod) {
        this.sqlRolesAndMethod = sqlRolesAndMethod;
    }

	/**
	 * getSqlRolesAndPointcut
	 * @return String
	 */
    public String getSqlRolesAndPointcut() {
        return sqlRolesAndPointcut;
    }

	/**
	 * setSqlRolesAndPointcut
	 * @param sqlRolesAndPointcut String
	 */
    public void setSqlRolesAndPointcut(String sqlRolesAndPointcut) {
        this.sqlRolesAndPointcut = sqlRolesAndPointcut;
    }

	/**
	 * getSqlRegexMatchedRequestMapping
	 * @return String
	 */
    public String getSqlRegexMatchedRequestMapping() {
        return sqlRegexMatchedRequestMapping;
    }

	/**
	 * setSqlRegexMatchedRequestMapping
	 * @param sqlRegexMatchedRequestMapping String
	 */
    public void setSqlRegexMatchedRequestMapping(
            String sqlRegexMatchedRequestMapping) {
        this.sqlRegexMatchedRequestMapping = sqlRegexMatchedRequestMapping;
    }

	/**
	 * getSqlHierarchicalRoles
	 * @return String
	 */
    public String getSqlHierarchicalRoles() {
        return sqlHierarchicalRoles;
    }

	/**
	 * setSqlHierarchicalRoles
	 * @param sqlHierarchicalRoles String
	 */
    public void setSqlHierarchicalRoles(String sqlHierarchicalRoles) {
        this.sqlHierarchicalRoles = sqlHierarchicalRoles;
    }
    
	/**
	 * getRolesAndResources
	 * @param resourceType String
	 * @return LinkedHashMap
	 * @exception Exception
	 */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public LinkedHashMap getRolesAndResources(String resourceType)
            throws Exception {

        LinkedHashMap resourcesMap = new LinkedHashMap();

        String sqlRolesAndResources;
        boolean isResourcesUrl = true;
        if ("method".equals(resourceType)) {
            sqlRolesAndResources = getSqlRolesAndMethod();
            isResourcesUrl = false;
        } else if ("pointcut".equals(resourceType)) {
            sqlRolesAndResources = getSqlRolesAndPointcut();
            isResourcesUrl = false;
        } else {
            sqlRolesAndResources = getSqlRolesAndUrl();
        }

        List resultList = this.namedParameterJdbcTemplate.queryForList(sqlRolesAndResources,new HashMap());

        Iterator itr = resultList.iterator();
        Map tempMap;
        String preResource = null;
        String presentResourceStr;
        Object presentResource;
        while (itr.hasNext()) {
            tempMap = (Map) itr.next();

            presentResourceStr = (String) tempMap.get(resourceType);
            // url if RequestKey format should be kept in the key of a Map
            presentResource = isResourcesUrl ? new RequestKey(presentResourceStr): (Object) presentResourceStr;
            List configList = new LinkedList();

            // Already on requestMap Role for the Resource If you had more than one mapped, sort_order 는
            // sort_order a resource (Resource) numbered so as to Role Mapping for Resource Lookup in a row AM.
            // Mapping the Role List (SecurityConfig) data, the data in the newly established recycling
            if (preResource != null && presentResourceStr.equals(preResource)) {
                List preAuthList = (List)((ConfigAttributeDefinition) resourcesMap.get(presentResource)).getConfigAttributes();
                Iterator preAuthItr = preAuthList.iterator();
                while (preAuthItr.hasNext()) {
                    SecurityConfig tempConfig = (SecurityConfig) preAuthItr.next();
                    configList.add(tempConfig);
                }
            }

            configList.add(new SecurityConfig(((BigDecimal) tempMap.get("authority")).toString()));
            ConfigAttributeDefinition cad =
                new ConfigAttributeDefinition(configList);

            // If more than one for the same Resource Role mapping is added to the previous resourceKey Role Mapping newly calculated current list Saved overwritten.
            resourcesMap.put(presentResource, cad);

            // Previously stored for comparison resource
            preResource = presentResourceStr;
        }

        return resourcesMap;
    }
    
	/**
	 * getRolesAndUrl
	 * @return LinkedHashMap
	 * @exception Exception
	 */
    @SuppressWarnings("rawtypes")
	public LinkedHashMap getRolesAndUrl() throws Exception {
        return getRolesAndResources("url");
    }
    
	/**
	 * getRolesAndMethod
	 * @return LinkedHashMap
	 * @exception Exception
	 */
    @SuppressWarnings("rawtypes")
	public LinkedHashMap getRolesAndMethod() throws Exception {
        return getRolesAndResources("method");
    }
    
	/**
	 * getRolesAndPointcut
	 * @return LinkedHashMap
	 * @exception Exception
	 */
    @SuppressWarnings("rawtypes")
	public LinkedHashMap getRolesAndPointcut() throws Exception {
        return getRolesAndResources("pointcut");
    }
    
	/**
	 * getRegexMatchedRequestMapping
	 * @param url String
	 * @return ConfigAttributeDefinition
	 * @exception Exception
	 */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public ConfigAttributeDefinition getRegexMatchedRequestMapping(String url)
            throws Exception {

        ConfigAttributeDefinition attributes = null;

        //best matched by Uri Role List Views, DB, if the level of support using a regular expression
        //(ex. hsqldb custom function, Oracle 10g regexp_like etc.)
        // 
        Map paramMap = new HashMap();
        paramMap.put("url", url);
        List resultList = this.namedParameterJdbcTemplate.queryForList(getSqlRegexMatchedRequestMapping(), paramMap);

        Iterator itr = resultList.iterator();
        Map tempMap;
        List configList = new LinkedList();
        // Role mapping for the Uri, so add that to the unconditional configList
        while (itr.hasNext()) {
            tempMap = (Map) itr.next();
            configList.add(new SecurityConfig(((BigDecimal) tempMap.get("authority")).toString()));
        }

        if (configList.size() > 0) {
            attributes = new ConfigAttributeDefinition(configList);
            SecuredObjectService.LOGGER.debug("Request Uri : " + url
                + ", matched Uri : " + ((Map) resultList.get(0)).get("uri")
                + ", mapping Roles : " + attributes);
        }

        return attributes;
    }
    
	/**
	 * getHierarchicalRoles
	 * @return String
	 * @exception Exception
	 */
    @SuppressWarnings("rawtypes")
	public String getHierarchicalRoles() throws Exception {

        List resultList =
            this.namedParameterJdbcTemplate.queryForList(
                getSqlHierarchicalRoles(), new HashMap());

        Iterator itr = resultList.iterator();
        StringBuffer concatedRoles = new StringBuffer();
        Map tempMap;
        while (itr.hasNext()) {
            tempMap = (Map) itr.next();
            concatedRoles.append(tempMap.get("child"));
            concatedRoles.append(" > ");
            concatedRoles.append(tempMap.get("parent"));
            concatedRoles.append("\n");
        }

        return concatedRoles.toString();
    }
}
