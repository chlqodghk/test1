package afnid.cm.sec.security;

import org.springframework.beans.factory.FactoryBean;
import afnid.cm.sec.security.securedobject.SecuredObjectService;

/**
 * 
 * 
 * 
 * @author ByungHun Woo
 * @since 2009.06.01
 * @version 1.0
 * @see
 *
 * <pre>
 * 
 *   
 * 
 *  -------    -------------    ----------------------
 *   2009.03.10  ByungHun Woo    
 *
 * </pre>
 */

public class HierarchyStringsFactoryBean implements FactoryBean {
	
    private SecuredObjectService securedObjectService;
    private String hierarchyStrings;
    
	/**
	 * setSecuredObjectService
	 * @param securedObjectService ISecuredObjectService
	 */
    public void setSecuredObjectService(
    		SecuredObjectService securedObjectService) {
        this.securedObjectService = securedObjectService;
    }
    
	/**
	 * init
	 * @exception Exception
	 */
    public void init() throws Exception {
        hierarchyStrings = (String) securedObjectService.getHierarchicalRoles();
    }
    
	/**
	 * getObject
	 * @return Object
	 * @exception Exception
	 */
    public Object getObject() throws Exception {
        if (hierarchyStrings == null) {
            init();
        }
        return hierarchyStrings;
    }
    
	/**
	 * getObjectType
	 * @return Class
	 */
    public Class <String> getObjectType() {
        return String.class;
    }

	/**
	 * isSingleton
	 * @return boolean
	 */
    public boolean isSingleton() {
        return true;
    }
}
