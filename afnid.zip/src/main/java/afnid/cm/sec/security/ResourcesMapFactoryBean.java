package afnid.cm.sec.security;

import java.util.LinkedHashMap;

import org.springframework.beans.factory.FactoryBean;

import afnid.cm.sec.security.securedobject.SecuredObjectService;

/**
 * DB-based reference to the protected resource mapping information obtained by the Bean provides initialization data.
 * 
 * @author ByungHun Woo
 * @since 2009.06.01
 * @version 1.0
 * @see
 *
 * <pre>
 * << Revision history(Modification Information) >>
 *   
 *   Modified      Modifiers           Modifications
 *  -------    -------------    ----------------------
 *   2009.03.20  ByungHun Woo    The first generation
 *
 * </pre>
 */

public class ResourcesMapFactoryBean implements FactoryBean {
	
    private String resourceType;
    @SuppressWarnings("rawtypes")
	private LinkedHashMap resourcesMap;
    private SecuredObjectService securedObjectService;

	/**
	 * setResourceType
	 * @param resourceType
	 * @exception Exception
	 */
    public void setResourceType(String resourceType) {
        this.resourceType = resourceType;
    }
    
	/**
	 * setSecuredObjectService
	 * @param securedObjectService
	 * @exception Exception
	 */
    public void setSecuredObjectService(
    		SecuredObjectService securedObjectService) {
        this.securedObjectService = securedObjectService;
    }
    
	/**
	 * init
	 * @exception Exception
	 */
    public void init() throws Exception {
        if ("method".equals(resourceType)) {
            resourcesMap = securedObjectService.getRolesAndMethod();
        } else if ("pointcut".equals(resourceType)) {
            resourcesMap = securedObjectService.getRolesAndPointcut();
        } else {
            resourcesMap = securedObjectService.getRolesAndUrl();
        }
    }
    
	/**
	 * getObject
	 * @return Object resourcesMap
	 * @exception Exception
	 */
    public Object getObject() throws Exception {
        if (resourcesMap == null) {
            init();
        }
        return resourcesMap;
    }
    
	/**
	 * getObjectType
	 * @return Class LinkedHashMap.class
	 */
    @SuppressWarnings("rawtypes")
	public Class getObjectType() {
        return LinkedHashMap.class;
    }
    
	/**
	 * isSingleton
	 * @return boolean
	 */
    public boolean isSingleton() {
        return true;
    }
}
