package afnid.cm.sec.service;

import java.util.List;

/** 
 * This service interface is biz-class of author-management. <br>
 * 
 * @author Afghanistan National ID Card System Application Team  Eun Hee Kim
 * @since 2011.05.03
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.03 		Eun Hee Kim	      		 		Create
 *
 * </pre>
 */

public interface AthrMngService {
	
	/**
	 * Retrieves list of author. <br>
	 * 
	 * @param vo Input item for retrieving list of author(AthrMngVO).
	 * @return List Retrieve list of author
	 * @exception Exception
	 */
	List <AthrMngVO> searchLIstAthr(AthrMngVO vo) throws Exception;
	
	/**
	 * Retrieves total count of author-list. <br>
	 * @param vo Input item for retrieving total count list of author.(AthrMngVO)
	 * @return int Total Count of author List
	 * @exception Exception
	 */
	int searchLIstAthrTotCnt(AthrMngVO vo) throws Exception;
	

	/**
	 * Register information of new author. <br>
	 * 
	 * @param vo Input item for registering new author(AthrMngVO).
	 * @return AthrMngVO Primary Key value of registered author
	 * @exception Exception
	 */
	AthrMngVO addAthr(AthrMngVO vo) throws Exception;
	
	
	
	/**
	 * Retrieves detail Information of author. <br>
	 * 
	 * @param vo Input item for retrieving detail information of author(AthrMngVO).
	 * @return AthrMngVO Retrieve detail information of author
	 * @exception Exception
	 */
	AthrMngVO searchAthr(AthrMngVO vo) throws Exception;
	
	/**
	 * Modifies information of author. <br>
	 * 
	 * @param vo Input item for modifying author(AthrMngVO).
	 * @exception Exception
	 */
	void modifyAthr(AthrMngVO vo) throws Exception;
	
	/**
	 * Retrieves list of author menu mapping. <br>
	 * 
	 * @param vo Input item for retrieving list of  menu mapping(AthrMngVO).
	 * @return List Retrieve list of author
	 * @exception Exception
	 */
	List <AthrMngVO> searchListAthrMnRl(AthrMngVO vo) throws Exception;

	/**
	 * Retrieves user count of allowed roll <br>
	 * @param vo Input item for retrieving user count of allowed roll(AthrMngVO)
	 * @return int 
	 * @exception Exception
	 */
	int searchListExistAthrUserCnt(AthrMngVO vo) throws Exception;	
	
}

