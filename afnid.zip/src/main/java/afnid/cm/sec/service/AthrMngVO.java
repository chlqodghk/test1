package afnid.cm.sec.service;

import java.util.List;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of author-management
 * 
 * @author Afghanistan National ID Card System Application Team Eun Hee Kim
 * @since 2011.05.03
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.03 		Eun Hee Kim	      		 		Create
 *
 * </pre>
 */
public class AthrMngVO extends ComDefaultVO{
    private static final long serialVersionUID = 1L;

    /** ATHR_ID */
    private java.lang.String athrId;
    
    /** PST_ATHR_NM */
    private java.lang.String pstAthrNm;
    
    /** DR_ATHR_NM */
    private java.lang.String drAthrNm;
    
    /** EN_ATHR_NM */
    private java.lang.String enAthrNm;    
    
    /** PST_ATHR_DS */
    private java.lang.String pstAthrDs;
    
    /** DR_ATHR_DS */
    private java.lang.String drAthrDs;
    
    /** USER_APL_ATHR_YN */
    private java.lang.String userAplAthrYn;
    
    /** FST_RGST_USER_ID */
    private java.lang.String fstRgstUserId;
    
    /** FST_RGST_DT */
    private java.lang.String fstRgstDt;
    
    /** LST_UDT_USER_ID */
    private java.lang.String lstUdtUserId;
    
    /** LST_UDT_DT */
    private java.lang.String lstUdtDt;
    
    /** User ID */
    private java.lang.String userId;
    
    /**Process Status Code  */
    private java.lang.String prcssStusCd;
    
    /** Process Status Code Name */
    private java.lang.String prcssStusCdNm;
    
    /** Process Detail Contents */
    private java.lang.String prcssDtlCt;
    
    /**Apply YN */
    private java.lang.String aplYn;
    
    /** Is Manager */
    private java.lang.String isMgr;
    
    /** User Language Code */
    private java.lang.String useLangCd;
    
    /** Authority approval Yn */
    private java.lang.String approvalYn;
    
    /** Authority return Yn */
    private java.lang.String returnYn;
    
    /** Process Event Type(Approval/Return) */
    private java.lang.String prcssEvntTye;
    
    /** Authority ID Array */
    private java.lang.String[] athrIdArray;
    
    /** Process Status Code Array */
    private java.lang.String[] prcssStusCdArray;
    
    /** Checkbox checked YN Array */
    private java.lang.String[] chkYnArray;
    
    /** User ID Array */
    private java.lang.String[] userIdArray;
    
    /** Organization Cd */
    private java.lang.String orgnzCd;
    

    /** MN_ID */
    private java.lang.String mnId;
    
    /** Menu Name */
    private java.lang.String mnNm;
    
    /** UPR_MN_NO */
    private java.lang.String uprMnId;
    
    /** Upper Menu Name */
    private java.lang.String uprMnNm;
    
    /** PST_MN_NM */
    private java.lang.String pstMnNm;
    
    /** DR_MN_NM */
    private java.lang.String drMnNm;
    
    /** MN_SOT_NO */
    private java.lang.String mnSotNo;
    
    /** PST_MN_DS */
    private java.lang.String pstMnDs;
    
    /** DR_MN_DS */
    private java.lang.String drMnDs;
    
    /** PGM_ID */
    private java.lang.String pgmId;
    
    /** Menu Description */
    private java.lang.String mnDs;
    
    /** Program File Name */
    private java.lang.String pgmNm;

    /** Authority Name */
    private java.lang.String athrNm;
    
    
    /** Authority Description */
    private java.lang.String athrDs;
    
    /** Registration YN */
    private java.lang.String rgstYn;
    
    /** Menu Level */
    private java.lang.String lvl;
    
    /** Page Url */
    private java.lang.String pageUrl;
    
    /** Make Query */
    private List<String> makeQuery;
    
    
    /** Program YN */
    private java.lang.String pgmYn;
    
    /** Icon File */
    private java.lang.String iconFile;
    
    /** Menu Path */
    private java.lang.String mnPath;
    
    /** Sequence */
    private java.lang.String rnum;
    
    /** Map ID */
    private java.lang.String mpId;
    
    /** Map File Name */
    private java.lang.String mpFleNm;
    
    /** Map File Path Contents */
    private java.lang.String mpFlePthCt;
    
    /** Menu ID Array */
    private java.lang.String[] mnIdArray;
    
    /** Top Menu Id */
    private java.lang.String topMnId;   
  
    private java.lang.String uprMnId1;

    
    /** Athority Group Code*/
    private java.lang.String athrGrpCd;   
  
    
    /** TAthority Group Code Name */
    private java.lang.String athrGrpCdNm;   
  
    
    
	public java.lang.String getOrgnzCd() {
		return orgnzCd;
	}

	public void setOrgnzCd(java.lang.String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}

	public java.lang.String getPrcssEvntTye() {
		return prcssEvntTye;
	}

	public void setPrcssEvntTye(java.lang.String prcssEvntTye) {
		this.prcssEvntTye = prcssEvntTye;
	}

	public java.lang.String getUseLangCd() {
		return useLangCd;
	}

	public void setUseLangCd(java.lang.String useLangCd) {
		this.useLangCd = useLangCd;
	}

	public java.lang.String getIsMgr() {
		return isMgr;
	}

	public void setIsMgr(java.lang.String isMgr) {
		this.isMgr = isMgr;
	}

	public java.lang.String getAthrId() {
        return this.athrId;
    }
    
    public void setAthrId(java.lang.String athrId) {
        this.athrId = athrId;
    }
    
    public java.lang.String getPstAthrNm() {
        return this.pstAthrNm;
    }
    
    public void setPstAthrNm(java.lang.String pstAthrNm) {
        this.pstAthrNm = pstAthrNm;
    }
    
    public java.lang.String getDrAthrNm() {
        return this.drAthrNm;
    }
    
    public void setDrAthrNm(java.lang.String drAthrNm) {
        this.drAthrNm = drAthrNm;
    }
    
    public java.lang.String getPstAthrDs() {
        return this.pstAthrDs;
    }
    
    public void setPstAthrDs(java.lang.String pstAthrDs) {
        this.pstAthrDs = pstAthrDs;
    }
    
    public java.lang.String getDrAthrDs() {
        return this.drAthrDs;
    }
    
    public void setDrAthrDs(java.lang.String drAthrDs) {
        this.drAthrDs = drAthrDs;
    }
    
    public java.lang.String getUserAplAthrYn() {
        return this.userAplAthrYn;
    }
    
    public void setUserAplAthrYn(java.lang.String userAplAthrYn) {
        this.userAplAthrYn = userAplAthrYn;
    }
    
    public java.lang.String getFstRgstUserId() {
        return this.fstRgstUserId;
    }
    
    public void setFstRgstUserId(java.lang.String fstRgstUserId) {
        this.fstRgstUserId = fstRgstUserId;
    }
    
    public java.lang.String getFstRgstDt() {
        return this.fstRgstDt;
    }
    
    public void setFstRgstDt(java.lang.String fstRgstDt) {
        this.fstRgstDt = fstRgstDt;
    }
    
    public java.lang.String getLstUdtUserId() {
        return this.lstUdtUserId;
    }
    
    public void setLstUdtUserId(java.lang.String lstUdtUserId) {
        this.lstUdtUserId = lstUdtUserId;
    }
    
    public java.lang.String getLstUdtDt() {
        return this.lstUdtDt;
    }
    
    public void setLstUdtDt(java.lang.String lstUdtDt) {
        this.lstUdtDt = lstUdtDt;
    }
    
    public java.lang.String getUserId() {
		return userId;
	}

	public void setUserId(java.lang.String userId) {
		this.userId = userId;
	}

	public java.lang.String getPrcssStusCd() {
		return prcssStusCd;
	}

	public void setPrcssStusCd(java.lang.String prcssStusCd) {
		this.prcssStusCd = prcssStusCd;
	}

	public java.lang.String getPrcssStusCdNm() {
		return prcssStusCdNm;
	}

	public void setPrcssStusCdNm(java.lang.String prcssStusCdNm) {
		this.prcssStusCdNm = prcssStusCdNm;
	}

	public java.lang.String getPrcssDtlCt() {
		return prcssDtlCt;
	}

	public void setPrcssDtlCt(java.lang.String prcssDtlCt) {
		this.prcssDtlCt = prcssDtlCt;
	}

	public java.lang.String getAplYn() {
		return aplYn;
	}

	public void setAplYn(java.lang.String aplYn) {
		this.aplYn = aplYn;
	}
	
	public java.lang.String getApprovalYn() {
		return approvalYn;
	}

	public void setApprovalYn(java.lang.String approvalYn) {
		this.approvalYn = approvalYn;
	}

	public java.lang.String getReturnYn() {
		return returnYn;
	}

	public void setReturnYn(java.lang.String returnYn) {
		this.returnYn = returnYn;
	}

	public java.lang.String[] getAthrIdArray() {
		return athrIdArray;
	}

	public void setAthrIdArray(java.lang.String[] athrIdArray) {
		this.athrIdArray = athrIdArray;
	}

	public java.lang.String[] getPrcssStusCdArray() {
		return prcssStusCdArray;
	}

	public void setPrcssStusCdArray(java.lang.String[] prcssStusCdArray) {
		this.prcssStusCdArray = prcssStusCdArray;
	}

	public java.lang.String[] getChkYnArray() {
		return chkYnArray;
	}

	public void setChkYnArray(java.lang.String[] chkYnArray) {
		this.chkYnArray = chkYnArray;
	}
	
	public java.lang.String[] getUserIdArray() {
		return userIdArray;
	}

	public void setUserIdArray(java.lang.String[] userIdArray) {
		this.userIdArray = userIdArray;
	}

	public java.lang.String getMnId() {
		return mnId;
	}

	public void setMnId(java.lang.String mnId) {
		this.mnId = mnId;
	}

	public java.lang.String getMnNm() {
		return mnNm;
	}

	public void setMnNm(java.lang.String mnNm) {
		this.mnNm = mnNm;
	}

	public java.lang.String getUprMnId() {
		return uprMnId;
	}

	public void setUprMnId(java.lang.String uprMnId) {
		this.uprMnId = uprMnId;
	}

	public java.lang.String getUprMnNm() {
		return uprMnNm;
	}

	public void setUprMnNm(java.lang.String uprMnNm) {
		this.uprMnNm = uprMnNm;
	}

	public java.lang.String getPstMnNm() {
		return pstMnNm;
	}

	public void setPstMnNm(java.lang.String pstMnNm) {
		this.pstMnNm = pstMnNm;
	}

	public java.lang.String getDrMnNm() {
		return drMnNm;
	}

	public void setDrMnNm(java.lang.String drMnNm) {
		this.drMnNm = drMnNm;
	}

	public java.lang.String getMnSotNo() {
		return mnSotNo;
	}

	public void setMnSotNo(java.lang.String mnSotNo) {
		this.mnSotNo = mnSotNo;
	}

	public java.lang.String getPstMnDs() {
		return pstMnDs;
	}

	public void setPstMnDs(java.lang.String pstMnDs) {
		this.pstMnDs = pstMnDs;
	}

	public java.lang.String getDrMnDs() {
		return drMnDs;
	}

	public void setDrMnDs(java.lang.String drMnDs) {
		this.drMnDs = drMnDs;
	}

	public java.lang.String getPgmId() {
		return pgmId;
	}

	public void setPgmId(java.lang.String pgmId) {
		this.pgmId = pgmId;
	}

	public java.lang.String getMnDs() {
		return mnDs;
	}

	public void setMnDs(java.lang.String mnDs) {
		this.mnDs = mnDs;
	}

	public java.lang.String getPgmNm() {
		return pgmNm;
	}

	public void setPgmNm(java.lang.String pgmNm) {
		this.pgmNm = pgmNm;
	}

	public java.lang.String getAthrNm() {
		return athrNm;
	}

	public void setAthrNm(java.lang.String athrNm) {
		this.athrNm = athrNm;
	}

	public java.lang.String getAthrDs() {
		return athrDs;
	}

	public void setAthrDs(java.lang.String athrDs) {
		this.athrDs = athrDs;
	}

	public java.lang.String getRgstYn() {
		return rgstYn;
	}

	public void setRgstYn(java.lang.String rgstYn) {
		this.rgstYn = rgstYn;
	}

	public java.lang.String getLvl() {
		return lvl;
	}

	public void setLvl(java.lang.String lvl) {
		this.lvl = lvl;
	}

	public java.lang.String getPageUrl() {
		return pageUrl;
	}

	public void setPageUrl(java.lang.String pageUrl) {
		this.pageUrl = pageUrl;
	}

	public List<String> getMakeQuery() {
		return makeQuery;
	}

	public void setMakeQuery(List<String> makeQuery) {
		this.makeQuery = makeQuery;
	}

	public java.lang.String getPgmYn() {
		return pgmYn;
	}

	public void setPgmYn(java.lang.String pgmYn) {
		this.pgmYn = pgmYn;
	}

	public java.lang.String getIconFile() {
		return iconFile;
	}

	public void setIconFile(java.lang.String iconFile) {
		this.iconFile = iconFile;
	}

	public java.lang.String getMnPath() {
		return mnPath;
	}

	public void setMnPath(java.lang.String mnPath) {
		this.mnPath = mnPath;
	}

	public java.lang.String getRnum() {
		return rnum;
	}

	public void setRnum(java.lang.String rnum) {
		this.rnum = rnum;
	}

	public java.lang.String getMpId() {
		return mpId;
	}

	public void setMpId(java.lang.String mpId) {
		this.mpId = mpId;
	}

	public java.lang.String getMpFleNm() {
		return mpFleNm;
	}

	public void setMpFleNm(java.lang.String mpFleNm) {
		this.mpFleNm = mpFleNm;
	}

	public java.lang.String getMpFlePthCt() {
		return mpFlePthCt;
	}

	public void setMpFlePthCt(java.lang.String mpFlePthCt) {
		this.mpFlePthCt = mpFlePthCt;
	}

	public java.lang.String[] getMnIdArray() {
		return mnIdArray;
	}

	public void setMnIdArray(java.lang.String[] mnIdArray) {
		this.mnIdArray = mnIdArray;
	}

	public java.lang.String getUprMnId1() {
		return uprMnId1;
	}

	public void setUprMnId1(java.lang.String uprMnId1) {
		this.uprMnId1 = uprMnId1;
	}

	public java.lang.String getEnAthrNm() {
		return enAthrNm;
	}

	public void setEnAthrNm(java.lang.String enAthrNm) {
		this.enAthrNm = enAthrNm;
	}

	public java.lang.String getTopMnId() {
		return topMnId;
	}

	public void setTopMnId(java.lang.String topMnId) {
		this.topMnId = topMnId;
	}

	public java.lang.String getAthrGrpCd() {
		return athrGrpCd;
	}

	public void setAthrGrpCd(java.lang.String athrGrpCd) {
		this.athrGrpCd = athrGrpCd;
	}

	public java.lang.String getAthrGrpCdNm() {
		return athrGrpCdNm;
	}

	public void setAthrGrpCdNm(java.lang.String athrGrpCdNm) {
		this.athrGrpCdNm = athrGrpCdNm;
	}

	
}
