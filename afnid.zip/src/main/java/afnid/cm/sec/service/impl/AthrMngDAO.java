package afnid.cm.sec.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import afnid.cm.sec.service.AthrMngVO;

/** 
 * This class is Database Access Object of author-management
 * 
 * @author Afghanistan National ID Card System Application Team Eun Hee Kim
 * @since 2011.05.03
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.03 		Eun Hee Kim	      		 		Create
 *
 * </pre>
 */
@Repository("athrMngDAO")
public class AthrMngDAO extends EgovAbstractDAO{
	
	/**
	 * DAO-method for retrieving list Information of author. <br>
	 * 
	 * @param vo Input item for retrieving list information of author(AthrMngVO).
	 * @return AthrMngVO Retrieve list information of author
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<AthrMngVO> selectLIstAthr(AthrMngVO vo) throws Exception{
		return list("athrMngDAO.selectLIstAthr", vo);
	}
	
	/**
	 * DAO-method for retrieving total count list of author. <br>
	 * 
	 * @param vo Input item for retrieving list of author(AthrMngVO).
	 * @return int Total Count of author List
	 * @exception Exception
	 */
    public int selectListAthrTotCnt(AthrMngVO vo) {
        return (Integer)selectByPk("athrMngDAO.selectListAthrTotCnt", vo);
    }

	/**
	 * DAO-method for registering information of new author. <br>
	 * 
	 * @param vo Input item for registering new author(AthrMngVO).
	 * @return AthrMngVO Primary Key value of registered author
	 * @exception Exception
	 */
	public void insertAthr(AthrMngVO vo){
		insert("athrMngDAO.insertAthr", vo);
	}
	
    /**
	 * DAO-method for retrieving detail Information of author. <br>
	 * 
	 * @param vo Input item for retrieving detail information of author(AuthorManageVO).
	 * @return AuthorManageVO Retrieve detail information of author
	 * @exception Exception
	 */
	public AthrMngVO selectAthr(AthrMngVO vo)throws Exception{
		return (AthrMngVO)selectByPk("athrMngDAO.selectAthr", vo); 
	}
	
	/**
	 * DAO-method for modifying information of author. <br>
	 * 
	 * @param vo Input item for modifying author(AthrMngVO).
	 * @exception Exception
	 */
	public void updateAthr(AthrMngVO vo){
		update("athrMngDAO.updateAthr", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of author menu mapping. <br>
	 * 
	 * @param vo Input item for retrieving list information of author(AthrMngVO).
	 * @return AthrMngVO Retrieve list information of author menu mapping
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<AthrMngVO> selecthListAthrMnRl(AthrMngVO vo) throws Exception{
		return list("athrMngDAO.selecthListAthrMnRl", vo);
	}
	
	/**
	 * DAO-method for deleting information of author menu. <br>
	 * 
	 * @param vo Input item for deleting author menu(AuthorMenuManageVO).
	 * @exception Exception
	 */
	public void deleteAthrMn(AthrMngVO vo){
		delete("athrMngDAO.deleteAthrMn", vo);
	}	
	
	/**
	 * DAO-method for registering information of author menu. <br>
	 * 
	 * @param vo Input item for registering author menu(AuthorMenuManageVO).
	 * @exception Exception
	 */
	public void insertAthrMn(AthrMngVO vo){
		insert("athrMngDAO.insertAthrMn", vo);
	}

	/**
	 * DAO-method for checking duplication name of author variable <br>
	 * 
	 * @param vo Input item for checking duplication name of author variable(AthrMngVO).
	 * @return AthrMngVO checking duplication name of author variable
	 * @exception Exception
	 */
	public int selectAthrVarNmPk(AthrMngVO vo) {
		return (Integer)selectByPk("athrMngDAO.selectAthrVarNmPk", vo);
	}
	
	/**
	 * DAO-method for retrieving user count of allowed roll. <br>
	 * 
	 * @param vo Input item for retrieving user count of allowed roll(AthrMngVO).
	 * @return int 
	 * @exception Exception
	 */
    public int selectListExistAthrUserCnt(AthrMngVO vo) {
        return (Integer)selectByPk("athrMngDAO.selectListExistAthrUserCnt", vo);
    }	
}
