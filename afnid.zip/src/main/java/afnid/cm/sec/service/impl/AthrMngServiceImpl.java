package afnid.cm.sec.service.impl;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.AbstractServiceImpl;

import afnid.cm.NidMessageSource;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.sec.service.AthrMngVO;
import afnid.cm.sec.service.AthrMngService;


/** 
 * This service class is biz-class of author-management
 * and implements NidAuthorManageService class.
 * 
 * @author Afghanistan National ID Card System Application Team  Eun Hee Kim
 * @since 2011.05.03
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.03 		Eun Hee Kim	      		 		Create
 *
 * </pre>
 */
@Service("athrMngService")
public  class AthrMngServiceImpl extends AbstractServiceImpl implements AthrMngService{
	
	@Resource(name="athrMngDAO")
    private AthrMngDAO athrMngDAO;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /**
	 * Biz-method for retrieving list of author. <br>
	 * 
	 * @param vo Input item for retrieving list of author(AthrMngVO).
	 * @return List Retrieve list of author
	 * @exception Exception
	 */
	public List<AthrMngVO> searchLIstAthr(AthrMngVO vo) throws Exception {
   		return athrMngDAO.selectLIstAthr(vo);
	}
	/**
	 * Biz-method for retrieving total count list of author. <br>
	 * 
	 * @param vo Input item for retrieving list of author(AthrMngVO).
	 * @return int Total Count of author List
	 * @exception Exception
	 */
    public int searchLIstAthrTotCnt(AthrMngVO vo) throws Exception {
    	return athrMngDAO.selectListAthrTotCnt(vo);
	}

	
	/**
	 * Biz-method for registering information of new author. <br>
	 * 
	 * @param vo Input item for registering new author(AthrMngVO).
	 * @return AthrMngVO Primary Key value of registered author
	 * @exception Exception
	 */
	public AthrMngVO addAthr(AthrMngVO vo) throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
		
		int pk = athrMngDAO.selectAthrVarNmPk(vo);
            
		vo.setAthrId(String.valueOf(pk));
		
		athrMngDAO.insertAthr(vo);
    	
		String[] array = vo.getChkYnArray();
		
		if(array != null) {
			// Delete CM_MN_ATHR_RL_TB
			athrMngDAO.deleteAthrMn(vo);
			
			for(int i=0; i<array.length; i++) {
				if(array[i].equals("Y")) {	
					// Insert CM_MN_ATHR_RL_TB
					vo.setMnId(vo.getMnIdArray()[i]); 
					athrMngDAO.insertAthrMn(vo);
				}
			}
		}
		
    	return vo;
	}
	
    /**
	 * Biz-method for retrieving detail Information of author. <br>
	 * 
	 * @param vo Input item for retrieving detail information of author(AthrMngVO).
	 * @return AthrMngVO Retrieve detail information of author
	 * @exception Exception
	 */
	public AthrMngVO searchAthr(AthrMngVO vo) throws Exception{
    	return (AthrMngVO)athrMngDAO.selectAthr(vo);
	}
	
	/**
	 * Biz-method for modifying information of author. <br>
	 * 
	 * @param vo Input item for modifying author(AthrMngVO).
	 * @exception Exception
	 */
	public void modifyAthr(AthrMngVO vo) throws Exception {
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
		
		athrMngDAO.updateAthr(vo);
		
		String[] array = vo.getChkYnArray();
		if(array != null) {
			// Delete CM_MN_ATHR_RL_TB
			athrMngDAO.deleteAthrMn(vo);
			
			for(int i=0; i<array.length; i++) {
				if(array[i].equals("Y")) {	
					// Insert CM_MN_ATHR_RL_TB
					vo.setMnId(vo.getMnIdArray()[i]); 
					athrMngDAO.insertAthrMn(vo);
				}
			}
		}
		
	}

	/**
	 * Biz-method for retrieving list of author menu mapping. <br>
	 * 
	 * @param vo Input item for retrieving list of author menu mapping(AthrMngVO).
	 * @return List Retrieve list of author
	 * @exception Exception
	 */
	public List<AthrMngVO> searchListAthrMnRl(AthrMngVO vo)
			throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		
		return athrMngDAO.selecthListAthrMnRl(vo);
	}	

	
	/**
	 * Retrieves user count of allowed roll <br>
	 * @param vo Input item for retrieving user count of allowed roll(AthrMngVO)
	 * @return int 
	 * @exception Exception
	 */	
    public int searchListExistAthrUserCnt(AthrMngVO vo) throws Exception {
    	return athrMngDAO.selectListExistAthrUserCnt(vo);
	}	
}
