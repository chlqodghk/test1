/**
 * 
 */
package afnid.cm.sec.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;

/**
 * @author asd
 *
 */
public class PkiCertFilter implements Filter{

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest)request;
		Object obj = NidUserDetailsHelper.getAuthenticatedUser();
		if(obj instanceof LgnVO){
			HttpSession session = req.getSession(false);
			String lgnPlcy = "";
			if(session != null){
				Object lgnPlcyAfnid = session.getAttribute("lgnPlcy.afnid");
				if(lgnPlcyAfnid instanceof String){
					lgnPlcy = (String)lgnPlcyAfnid;
				}
			}
			LgnVO user = (LgnVO)obj;
			log.debug("lgnPlcy : " + lgnPlcy);
			if(!"".equals(lgnPlcy) && !"pwd".equals(lgnPlcy)){
				if(user != null){
					NidStringUtil nsu = new NidStringUtil();
		    		String cert = nsu.getReqCertName(req);
		    		if(user != null && user.getCert() != null && !"".equals(user.getCert()) && cert != null){
		    			log.debug("session : " + user.getCert());
		    			log.debug("cartcert : " + cert);
		    			if(!user.getCert().equals(cert)){
		    				RequestDispatcher rd = req.getRequestDispatcher("/cm/uat/LgnUser.do?authorFail=3");
		    				rd.forward(request, response);
		    				return;
		    			}
		    		}
				}
			}
		}
		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

}
