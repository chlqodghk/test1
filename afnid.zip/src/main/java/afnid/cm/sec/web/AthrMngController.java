package afnid.cm.sec.web;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.intercept.web.NidReloadableDefaultFilterInvocationDefinitionSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.sec.service.AthrMngVO;
import afnid.cm.sec.service.AthrMngService;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/** 
 * This Controller class processes request of author-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Eun Hee Kim
 * @since 2011.05.03
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.03 		Eun Hee Kim	      		 		Create
 *
 * </pre>
 */
@Controller
public class AthrMngController {
	
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());
	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /** CmmCdManagerServiceImpl */
	//@Resource(name = "cmmCdMngService")
    //private CmmCdMngService cmmCdMngService;
	
    /** athrMngService */
	@Resource(name = "athrMngService")
    private AthrMngService athrMngService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
	
    /** lgService */
	@Resource(name = "lgService")
    private LgService lgService;	
	
	@Resource(name = "databaseObjectDefinitionSource")
	private NidReloadableDefaultFilterInvocationDefinitionSource databaseObjectDefinitionSource;
	
    /**
     * Moved to list-screen of author. <br>
     * 
     * @param comDefaultVO Value-object of author to be parsed request(ComDefaultVO)
     * @param AthrMngCo Value-object of author to be parsed request(AthrMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/sec/AthrList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/sec/searchListAthrView.do")
    public String searchListAthrView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("athrMngVO") AthrMngVO athrMngVO,
    		ModelMap model)
            throws Exception { 
    	    
    	try{
    		    		
        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();        	
        	lgService.addUserWrkLg(user.getUserId(), athrMngVO.getCurMnId());
        	
        	
        	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
      	return "/cm/sec/AthrList";

    }
    
    /**
     * Retrieves list of author.  <br>
     * 
     * @param athrMngVO Value-object of author to be parsed request(athrMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/sec/AthrList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/sec/searchListAthr.do")
    public String searchListAthr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("athrMngVO") AthrMngVO athrMngVO,
    		ModelMap model)
            throws Exception { 

    	try {
	    	/** 목록 Paging Setting */
    		athrMngVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		athrMngVO.setPageSize(propertiesService.getInt("pageSize"));
	
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(athrMngVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(athrMngVO.getPageUnit());
			paginationInfo.setPageSize(athrMngVO.getPageSize());
	
			athrMngVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			athrMngVO.setLastIndex(paginationInfo.getLastRecordIndex());
			athrMngVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
	        List<AthrMngVO> lstAuthor = athrMngService.searchLIstAthr(athrMngVO);
	        model.addAttribute("lstAuthor", lstAuthor);
	
	        int totCnt = athrMngService.searchLIstAthrTotCnt(athrMngVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "/cm/sec/AthrList";
    }
    
    /**
     * Moved to registration-screen of author. <br>
     * 
     * @param AthrMngVO Value-object of author to be parsed request(AthrMngVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return  Printed out JSP:  "/cm/sec/AuthorIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/sec/addAthrView.do")
    public String addAthrView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("athrMngVO") AthrMngVO athrMngVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
           try{
        	   /*
           	   CmCmmCdVO cmCmmCd = new CmCmmCdVO();     	
        	
       		   cmCmmCd.setGrpCd("45"); // Setting Group Code
       		   List<CmCmmCdVO> lstAthrGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd); 
       		   model.addAttribute("lstAthrGrpCd", lstAthrGrpCd);  
       		   */
        	   
        	   List<AthrMngVO> lstAthrMnRl = athrMngService.searchListAthrMnRl(athrMngVO);
        	   model.addAttribute("lstAthrMnRl", lstAthrMnRl);    	   
        	} catch (Exception e) {
        		log.error(e.getMessage(), e);
        		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
        	}    	
           
           return "/cm/sec/AthrIns";  
    }
    
    
    /**
     * Register information of new author. <br>
     * 
     * @param AthrMngVO Value-object of author to be parsed request(AthrMngVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "cm/sec/AuthorDtl.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/sec/addAthr.do")
    public String addAthr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("athrMngVO") AthrMngVO athrMngVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception {
    		
    	try {
    		athrMngService.addAthr(athrMngVO);  
    		databaseObjectDefinitionSource.reloadRequestMap();
	    	model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); 
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    	return "forward:/cm/sec/searchListAthr.do";
    }
    
    /**
     * Moved to modification-screen of author. <br>
     * 
     * @param AthrMngVO Value-object of author to be parsed request(AthrMngVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/sec/AuthorUpt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/sec/modifyAthrView.do")
    public String modifyAthrView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("athrMngVO") AthrMngVO athrMngVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	
    	try {
        	/*    		
        	CmCmmCdVO cmCmmCd = new CmCmmCdVO();     	
    		cmCmmCd.setGrpCd("45"); // Setting Group Code
    		List<CmCmmCdVO> lstAthrGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd); 
    		model.addAttribute("lstAthrGrpCd", lstAthrGrpCd);  
    		*/
    		model.addAttribute("athrMngVO", athrMngService.searchAthr(athrMngVO));  
    		
     	    List<AthrMngVO> lstAthrMnRl = athrMngService.searchListAthrMnRl(athrMngVO);
     	    model.addAttribute("lstAthrMnRl", lstAthrMnRl);   
     	    
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/cm/sec/AthrUdt";
    }
    
	/**
	 * Modifies information of author. <br>
	 * 
	 * @param AthrMngVO Value-object of author to be parsed request(AthrMngVO)
	 * @param bindingResult  validate Input Item(BindingResult)
	 * @param model Object to be parsed http request(ModelMap) 
	 * @return Printed out JSP: "cm/sec/AuthorDtl.do"
	 * @exception Exception
	 */
    @RequestMapping(value="/cm/sec/modifyAthr.do")
    public String modifyAthr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("athrMngVO") AthrMngVO athrMngVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	try {
    		
    		if("N".equals(athrMngVO.getUserAplAthrYn()) ){
    		    if( athrMngService.searchListExistAthrUserCnt(athrMngVO) > 0){
    		    	model.addAttribute("resultMsg", nidMessageSource.getMessage("existRollUser.msg")); 
    		    } else {
    		    	athrMngService.modifyAthr(athrMngVO); 
    		    	model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		    }
    	    }else {
	    		athrMngService.modifyAthr(athrMngVO);  	
	    		databaseObjectDefinitionSource.reloadRequestMap();
		    	model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); 
    		}
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
		return "forward:/cm/sec/searchListAthr.do"; 
    }


    
}
