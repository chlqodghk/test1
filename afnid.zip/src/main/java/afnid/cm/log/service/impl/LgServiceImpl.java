package afnid.cm.log.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.log.service.LgVO;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.uss.service.UserMngVO;
import afnid.pkiif.ccm.CardKillRequestInput;
import afnid.pkiif.ccm.CardKillRequestOutput;
import afnid.pkiif.ccm.RMCCM;
import afnid.pkiif.ccm.RMCCM_Service;
import afnid.pkiif.opki.OpkiRmWS;
import afnid.pkiif.opki.OpkiRmWSService;
import afnid.pkiif.opki.PkiRsWsResponse;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;


/** 
 * This service class is biz-class of monitoring.
 * and implements CrdDitbService class.
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2013.09.26
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           		Revisions
 *  2013.09.26  		MS Kim         		Create
 *
 * </pre>
 */

@Service("lgService")
public class LgServiceImpl extends AbstractServiceImpl implements LgService{
	/** logDAO */
    @Resource(name="lgDAO")
    private LgDAO dao;
    
    
    /**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return List Retrieve list of program
	 * @exception Exception 
	 */
	public List<LgVO> searchListUserLgnLg(LgVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
   		return dao.selectListUserLgnLg(vo);
	}
	
	/**
	 * Biz-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return int Total Count of Program List
	 * @exception Exception 
	 */
    public int searchListUserLgnLgTotCnt(LgVO vo) throws Exception {
        return dao.selectListUserLgnLgTotCnt(vo);
	}
    
    /**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return List Retrieve list of program
	 * @exception Exception 
	 */
	public List<LgVO> searchListUserWrkLg(LgVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
   		return dao.selectListUserWrkLg(vo);
	}
	
	/**
	 * Biz-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return int Total Count of Program List
	 * @exception Exception 
	 */
    public int searchListUserWrkLgTotCnt(LgVO vo) throws Exception {
        return dao.selectListUserWrkLgTotCnt(vo);
	}
    /**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<EgovMap> searchListDppFleLg(LgVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
   		return dao.selectListDppFleLg(vo);
	}
	
	/**
	 * Biz-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int searchListDppFleLgTotCnt(LgVO vo) throws Exception {
        return dao.selectListDppFleLgTotCnt(vo);
	}
    
    
    /**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<EgovMap> searchListDppSndRcivLg(LgVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
   		return dao.selectListDppSndRcivLg(vo);
	}
	
	/**
	 * Biz-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int searchListDppSndRcivLgTotCnt(LgVO vo) throws Exception {
        return dao.selectListDppSndRcivLgTotCnt(vo);
	}
    
    /**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<LgVO> searchListBachJobLg(LgVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
   		return dao.selectListBachJobLg(vo);
	}
	
	/**
	 * Biz-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int searchListBachJobLgTotCnt(LgVO vo) throws Exception {
        return dao.selectListBachJobLgTotCnt(vo);
	}

    
    /**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(LgVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */    
    public List<EgovMap> searchListBioIfLg(LgVO vo) throws Exception{
    	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
    	return dao.selectListBioIfLg(vo);
    }
	/**
	 * Biz-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int searchListBioIfLgTotCnt(LgVO vo) throws Exception{
    	return dao.selectListBioIfLgTotCnt(vo);
    }
    
	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(LgVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */    
    public List<EgovMap> searchListPkiIfLg(LgVO vo) throws Exception{
    	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
    	return dao.selectListPkiIfLg(vo);
    }
	/**
	 * Biz-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LogPkiVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int searchListPkiIfLgTotCnt(LgVO vo) throws Exception{
    	return dao.selectListPkiIfLgTotCnt(vo);
    }
    
    
    /**
	 * Biz-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(String, String).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public void addUserWrkLg(String userId, String mnId) throws Exception{
    	if(userId != null && mnId != null && !"".equals(userId) && !"".equals(mnId)){
    		LgVO vos = new LgVO();
	    	vos.setUserId(userId);
	    	vos.setMnId(mnId);
	    	dao.insertUserWrkLg(vos);	
    	}
    }

    
    /**
	 * Biz-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(String, String, String, String).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public void addBioIfLg(String userId, String rqstRpseCd, String erorYn, String msg, String bioKey) throws Exception{
    	dao.insertBioIfLg(userId, rqstRpseCd, erorYn, msg, bioKey);
    }
    
    
	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(LgVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */    
    public List<EgovMap> searchListCmsEror(LgVO vo) throws Exception{
    	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
    	return dao.selectListCmsEror(vo);
    }
	/**
	 * Biz-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LogPkiVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int searchListCmsErorTotCnt(LgVO vo) throws Exception{
    	return dao.selectListCmsErorTotCnt(vo);
    }
    
	/**
	 * Biz-method for RM-CMS interface error processing <br>
	 * 
	 * @param vo Input item for RM-CMS interface error processing(LgVO).
	 * @return 
	 * @exception Exception
	 */
	public void modifyCmsEror(LgVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		
		vo.setErorPrcssUserId(user.getUserId());
		
		String [] array = vo.getCheckboxList();

		if (array != null) {
			for(int i=0; i<array.length; i++){
				vo.setLgSeqNo(array[i]);
				dao.updateCmsEror(vo);
			}										
        }
	}  
	
	/**
	 * Re-send webServide(Officer Account Registration) <br>
	 * 
	 * @param vo Input item for Re-send webServide(LgVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyOficrErorResnd(LgVO vo) throws Exception {

		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		
		vo.setErorPrcssUserId(user.getUserId());
		vo.setErorPrcssSide("1");
		
		dao.updateCmsEror(vo);

		UserMngVO oficr = dao.selectUserInfr(vo);
		
		//log insert
		String lgSeqNo = dao.insertPubKeyIfLg(user.getUserId(), oficr.getUserId(),"9", "2", "18", "");

		return lgSeqNo;

	}  
	
	/**
	 * PKI interface Call (Officer Account Registration) <br>
	 * 
	 * @param vo Input item for PKI interface Call(LgVO).
	 * @return String
	 * @exception Exception
	 */
	public String modifyOficrErorResndPkiIf(LgVO vo) throws Exception {
		
		String status = "";
		String erorYn ="Y";
				

		//Officer Info search
		UserMngVO oficr = dao.selectUserInfr(vo);
		
		//Officer Account Registration		
		OpkiRmWSService orws= new OpkiRmWSService();
		OpkiRmWS orw = orws.getOpkiRmWSPort();	
		
		log.debug("==================================================");
		log.debug("oficr.getUserId() : "+oficr.getUserId());
		log.debug("oficr.getEnNm()   : "+oficr.getEnNm());
		log.debug("oficr.getEml()    : "+ oficr.getEml());
		log.debug("==================================================");
		
		PkiRsWsResponse prwr = orw.opkiIfRegisterAccount(oficr.getUserId(), oficr.getEnNm(), oficr.getEml());
		status= prwr.getStatusCode();

		if("0".equals(status)){
			dao.updateCmsEror(vo);
			erorYn ="N";
		} 

		//log update
		dao.updatePubKeyIfLg(vo.getLgSeqNo1(), status, erorYn);

		return status;

	} 
	
	/**
	 * Re-send webServide(Write of  eNID Card Chip) <br>
	 * 
	 * @param vo Input item for Re-send webServide(LgVO).
	 * @return String
	 * @exception Exception
	 */
	public String modifyCrdChipWrtErorResnd(LgVO vo) throws Exception {
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		
		vo.setErorPrcssUserId(user.getUserId());
		vo.setErorPrcssSide("1");
		
		dao.updateCmsEror(vo);
		
		LgVO rqstData = dao.selctRqstDat(vo);	
		
		//log insert
		String lgSeqNo = dao.insertPubKeyIfLg(user.getUserId(),rqstData.getRsdtNo(),"20", "1", "22", rqstData.getRqstDat());

		return lgSeqNo;
	}	
	
	/**
	 * PKI interface Call (Write of  eNID Card Chip) <br>
	 * 
	 * @param vo Input item for PKI interface Call(LgVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyCrdChipWrtErorResndPkiIf(LgVO vo) throws Exception {

		String erorYn ="N";
		
		LgVO rqstData = dao.selctRqstDat(vo);
		
		RMCCM_Service ccmse= new RMCCM_Service();
		RMCCM ccm = ccmse.getRMCCMPort();
		
		log.debug("==================================================");
		log.debug("vo.getLgSeqNo() : "+vo.getLgSeqNo());
		log.debug("rqstData.getRqstDat() ========== " + rqstData.getRqstDat());
		log.debug("================================================== ");

		String ccmResult = ccm.registerCardChanges(rqstData.getRqstDat());		
		log.debug("ccm.registerCardChanges(chipResult)");
		
		if(ccmResult != null && !"OK".equals(ccmResult)){
			erorYn ="Y";
		}
		log.debug("==================================================");
		log.debug("ccmResult ==========> " + ccmResult);
		log.debug("==================================================");
		//log update
		dao.updatePubKeyIfLg(vo.getLgSeqNo1(), ccmResult, erorYn);

		return ccmResult;

	} 
	
	/**
	 * Re-send webServide(Request Read of eNID Card Chip) <br>
	 * 
	 * @param vo Input item for Re-send webServide(LgVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyCrdChipReadRqstErorResnd(LgVO vo) throws Exception {
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		
		vo.setErorPrcssUserId(user.getUserId());
		vo.setErorPrcssSide("1");
		
		dao.updateCmsEror(vo);
		
		LgVO rqstData = dao.selctRqstDat(vo);
		
		//log insert
		String lgSeqNo = dao.insertPubKeyIfLg(user.getUserId(), rqstData.getRsdtNo(), "21", "1", "22", rqstData.getRqstDat());
		
		return lgSeqNo;
	}
	
	/**
	 * PKI interface Call (Request Read of eNID Card Chip) <br>
	 * 
	 * @param vo Input item for PKI interface Call(LgVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyCrdChipReadRqstErorResndPkiIf(LgVO vo) throws Exception {
		
		String status = "";
		String erorYn ="Y";
				
		LgVO rqstData = dao.selctRqstDat(vo);
		String[] rqstDataTmp = rqstData.getRqstDat().split(":");
		
		CardKillRequestInput data = new CardKillRequestInput();
		
		data.setRequestType(Integer.parseInt(rqstDataTmp[0]));
		data.setCardIssuanceDate(rqstDataTmp[1]);
		data.setENID(rqstDataTmp[2]);
		data.setReportNumber(rqstDataTmp[3]);
		data.setLastIssuanceSequenceNo(Integer.parseInt(rqstDataTmp[4]));
		data.setPrintedIssuanceSequenceNo(Integer.parseInt(rqstDataTmp[5]));
		
		log.debug("==================================================");
		log.debug("vo.getLgSeqNo() : "+vo.getLgSeqNo());
		log.debug("rqstData.getRqstDat() ==========" + rqstData.getRqstDat());
		log.debug("==================================================");
		
		log.debug("rqstTye-rqstDataTmp[0] : "     + rqstDataTmp[0]);
		log.debug("hCrdIsuceDd-rqstDataTmp[3] : " + rqstDataTmp[1]);		
		log.debug("rsdtNo-rqstDataTmp[2] : "      + rqstDataTmp[2]);
		log.debug("reportNo-rqstDataTmp[1] : "    + rqstDataTmp[3]);		
		log.debug("LastIssuanceSequenceNo-rqstDataTmp[4] : "    + rqstDataTmp[4]);
		log.debug("PrintedIssuanceSequenceNo-rqstDataTmp[5] : " + rqstDataTmp[5]);
		

		RMCCM_Service rmCcmWs= new RMCCM_Service();
		RMCCM rmCcm = rmCcmWs.getRMCCMPort();	
			
		CardKillRequestOutput ckro = rmCcm.cardKillRequest(data);
		
		int ccmResult = ckro.getResult(); // 1: OK 2:ERROR 
		
		status = String.valueOf(ccmResult);

		
		if("1".equals(status)){//OK
			dao.updateCmsEror(vo);
			erorYn ="N";
		} else {
			if(ckro.getFailCode()!= null && "".equals(ckro.getFailCode())){
				status = ckro.getFailCode();
			} else {
				status ="None";
			}
			
		}
		log.debug("==================================================");
		log.debug("ccmResult ==========> " + ccmResult);
		log.debug("status ==========> " + status);
		log.debug("==================================================");
		//log update
		dao.updatePubKeyIfLg(vo.getLgSeqNo1(), status, erorYn);

		return status;

	} 
	
	/**
	 * Re-send webServide(Request Kill of eNID Card) <br>
	 * 
	 * @param vo Input item for Re-send webServide(LgVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyCrdKillErorResnd(LgVO vo) throws Exception {

		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		
		vo.setErorPrcssUserId(user.getUserId());
		vo.setErorPrcssSide("1");
		
		dao.updateCmsEror(vo);
		
		LgVO rqstData = dao.selctRqstDat(vo);
		
		//log insert
		String lgSeqNo=dao.insertPubKeyIfLg(user.getUserId(), rqstData.getRsdtNo(), "23", "1", "22", rqstData.getRqstDat());


		return lgSeqNo;
	}
	
	/**
	 * PKI Interface Call(Request Kill of eNID Card) <br>
	 * 
	 * @param vo Input item for PKI Interface Call(LgVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyCrdKillErorResndPkiIf(LgVO vo) throws Exception {
		String status = "";
		String erorYn ="Y";

		LgVO rqstData = dao.selctRqstDat(vo);
		String[] rqstDataTmp = rqstData.getRqstDat().split(":");
		
		CardKillRequestInput data = new CardKillRequestInput();
		
		data.setRequestType(Integer.parseInt(rqstDataTmp[0]));
		data.setCardIssuanceDate(rqstDataTmp[1]);
		data.setENID(rqstDataTmp[2]);
		data.setReportNumber(rqstDataTmp[3]);
		data.setLastIssuanceSequenceNo(Integer.parseInt(rqstDataTmp[4]));
		data.setPrintedIssuanceSequenceNo(Integer.parseInt(rqstDataTmp[5]));
		
		log.debug("==================================================");
		log.debug("vo.getLgSeqNo() : "+vo.getLgSeqNo());
		log.debug("rqstData.getRqstDat() ==========" + rqstData.getRqstDat());
		log.debug("==================================================");
		
		log.debug("rqstTye-rqstDataTmp[0] : "     + rqstDataTmp[0]);
		log.debug("hCrdIsuceDd-rqstDataTmp[3] : " + rqstDataTmp[1]);		
		log.debug("rsdtNo-rqstDataTmp[2] : "      + rqstDataTmp[2]);
		log.debug("reportNo-rqstDataTmp[1] : "    + rqstDataTmp[3]);		
		log.debug("LastIssuanceSequenceNo-rqstDataTmp[4] : "    + rqstDataTmp[4]);
		log.debug("PrintedIssuanceSequenceNo-rqstDataTmp[5] : " + rqstDataTmp[5]);


		RMCCM_Service rmCcmWs= new RMCCM_Service();
		RMCCM rmCcm = rmCcmWs.getRMCCMPort();	
			
		CardKillRequestOutput ckro = rmCcm.cardKillRequest(data);
		
		int ccmResult = ckro.getResult(); // 1: OK 2:ERROR 
		
		status = String.valueOf(ccmResult);

		
		if("1".equals(status)){//OK
			dao.updateCmsEror(vo);
			erorYn ="N";
		} else {
			if(ckro.getFailCode()!= null && "".equals(ckro.getFailCode())){
				status = ckro.getFailCode();
			} else {
				status ="None";
			}
			
		}
		log.debug("==================================================");
		log.debug("ccmResult ==========> " + ccmResult);
		log.debug("status ==========> " + status);
		log.debug("==================================================");
		//log update
		dao.updatePubKeyIfLg(vo.getLgSeqNo1(), status, erorYn);
		
		return status;
	}
	
    /**
	 * Biz-method for retrieving list of web service interface name. <br>
	 * 
	 * @param vo Input item for retrieving list of web service interface name(LgVO).
	 * @return List Retrieve list of web service interface name
	 * @exception Exception 
	 */
	public List<LgVO> searchListWebSrvcIfNm(LgVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());		
   		return dao.selectListWebSrvcIfNm(vo);
	}	
}
