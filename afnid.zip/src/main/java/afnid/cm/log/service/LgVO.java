package afnid.cm.log.service;

import afnid.cm.ComDefaultVO;

public class LgVO extends ComDefaultVO{
	private static final long serialVersionUID = 1L;
	
	/** LG_ID */
	private String lgId;	
	/** WRK_STT_DT */
	private String wrkSttDt;	
	/** WRK_ED_DT */
	private String wrkEdDt;	
	/** WRK_SYS_CD */
	private String wrkSysCd;	
	/** WRK_CD */
	private String wrkCd;	
	/** TGT_CN */
	private String tgtCn;	
	/** SCS_CN */
	private String scsCn;	
	/** EROR_CN */
	private String erorCn;	
	/** EROR_YN */
	private String erorYn;	
	/** MSG */
	private String msg;	
	/** USER_ID */
	private String userId;
	
	private String wrkDt;	
	private String rqstRpseCd;		
	private String nm;
	private String pubKeyDivCd;	
	private String rsdtNo;


	private String lgnDt;
	private String orgnzCd;
	private String orgnzCdNm;
	private String name;
	private String useLc;
	private String mnId;
	private String mnNm;

	private String hWrkSttDt;
	private String gWrkSttDt;
	private String hWrkEdDt;
	private String gWrkEdDt;
	private String hWrkDt;
	private String gWrkDt;
	private String hLgnDt;
	private String gLgnDt;
	private String bioKey;
	private String lgSeqNo;
	private String lgSeqNo1;
	private String lgSeqNo2;
	
	private String hErorPrcssDd;
	private String gErorPrcssDd;
	private String erorPrcssYn;	
	private String erorPrcssDd;
	private String erorPrcssUserId;	
	private String erorPrcssSide;
	
	private String[] checkboxList;
	
	private String bsnCd;
	private String bsnCdNm;
	private String rqstDat;
	private String rqstRpseCdNm;
	
    private java.lang.String cmmCd;
    private java.lang.String cmmCdNm;
    private java.lang.String grpCd;
	
    private java.lang.String srchOrgnzCd;
    private java.lang.String srchOrgnzNm;
    private java.lang.String oficTye;
    
	public String getLgId() {
		return lgId;
	}
	public void setLgId(String lgId) {
		this.lgId = lgId;
	}
	public String getWrkSttDt() {
		return wrkSttDt;
	}
	public void setWrkSttDt(String wrkSttDt) {
		this.wrkSttDt = wrkSttDt;
	}
	public String getWrkEdDt() {
		return wrkEdDt;
	}
	public void setWrkEdDt(String wrkEdDt) {
		this.wrkEdDt = wrkEdDt;
	}
	public String getWrkSysCd() {
		return wrkSysCd;
	}
	public void setWrkSysCd(String wrkSysCd) {
		this.wrkSysCd = wrkSysCd;
	}
	public String getWrkCd() {
		return wrkCd;
	}
	public void setWrkCd(String wrkCd) {
		this.wrkCd = wrkCd;
	}
	public String getTgtCn() {
		return tgtCn;
	}
	public void setTgtCn(String tgtCn) {
		this.tgtCn = tgtCn;
	}
	public String getScsCn() {
		return scsCn;
	}
	public void setScsCn(String scsCn) {
		this.scsCn = scsCn;
	}
	public String getErorCn() {
		return erorCn;
	}
	public void setErorCn(String erorCn) {
		this.erorCn = erorCn;
	}
	public String getErorYn() {
		return erorYn;
	}
	public void setErorYn(String erorYn) {
		this.erorYn = erorYn;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getWrkDt() {
		return wrkDt;
	}
	public void setWrkDt(String wrkDt) {
		this.wrkDt = wrkDt;
	}
	public String getRqstRpseCd() {
		return rqstRpseCd;
	}
	public void setRqstRpseCd(String rqstRpseCd) {
		this.rqstRpseCd = rqstRpseCd;
	}
	public String getNm() {
		return nm;
	}
	public void setNm(String nm) {
		this.nm = nm;
	}
	public String getPubKeyDivCd() {
		return pubKeyDivCd;
	}
	public void setPubKeyDivCd(String pubKeyDivCd) {
		this.pubKeyDivCd = pubKeyDivCd;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getLgnDt() {
		return lgnDt;
	}
	public void setLgnDt(String lgnDt) {
		this.lgnDt = lgnDt;
	}
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String getOrgnzCdNm() {
		return orgnzCdNm;
	}
	public void setOrgnzCdNm(String orgnzCdNm) {
		this.orgnzCdNm = orgnzCdNm;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUseLc() {
		return useLc;
	}
	public void setUseLc(String useLc) {
		this.useLc = useLc;
	}
	public String getMnId() {
		return mnId;
	}
	public void setMnId(String mnId) {
		this.mnId = mnId;
	}
	public String getMnNm() {
		return mnNm;
	}
	public void setMnNm(String mnNm) {
		this.mnNm = mnNm;
	}
	public String gethWrkSttDt() {
		return hWrkSttDt;
	}
	public void sethWrkSttDt(String hWrkSttDt) {
		this.hWrkSttDt = hWrkSttDt;
	}
	public String getgWrkSttDt() {
		return gWrkSttDt;
	}
	public void setgWrkSttDt(String gWrkSttDt) {
		this.gWrkSttDt = gWrkSttDt;
	}
	public String gethWrkEdDt() {
		return hWrkEdDt;
	}
	public void sethWrkEdDt(String hWrkEdDt) {
		this.hWrkEdDt = hWrkEdDt;
	}
	public String getgWrkEdDt() {
		return gWrkEdDt;
	}
	public void setgWrkEdDt(String gWrkEdDt) {
		this.gWrkEdDt = gWrkEdDt;
	}
	public String gethWrkDt() {
		return hWrkDt;
	}
	public void sethWrkDt(String hWrkDt) {
		this.hWrkDt = hWrkDt;
	}
	public String getgWrkDt() {
		return gWrkDt;
	}
	public void setgWrkDt(String gWrkDt) {
		this.gWrkDt = gWrkDt;
	}
	public String gethLgnDt() {
		return hLgnDt;
	}
	public void sethLgnDt(String hLgnDt) {
		this.hLgnDt = hLgnDt;
	}
	public String getgLgnDt() {
		return gLgnDt;
	}
	public void setgLgnDt(String gLgnDt) {
		this.gLgnDt = gLgnDt;
	}
	public String getBioKey() {
		return bioKey;
	}
	public void setBioKey(String bioKey) {
		this.bioKey = bioKey;
	}
	public String getLgSeqNo() {
		return lgSeqNo;
	}
	public void setLgSeqNo(String lgSeqNo) {
		this.lgSeqNo = lgSeqNo;
	}
	public String getLgSeqNo1() {
		return lgSeqNo1;
	}
	public void setLgSeqNo1(String lgSeqNo1) {
		this.lgSeqNo1 = lgSeqNo1;
	}
	public String getLgSeqNo2() {
		return lgSeqNo2;
	}
	public void setLgSeqNo2(String lgSeqNo2) {
		this.lgSeqNo2 = lgSeqNo2;
	}
	public String gethErorPrcssDd() {
		return hErorPrcssDd;
	}
	public void sethErorPrcssDd(String hErorPrcssDd) {
		this.hErorPrcssDd = hErorPrcssDd;
	}
	public String getgErorPrcssDd() {
		return gErorPrcssDd;
	}
	public void setgErorPrcssDd(String gErorPrcssDd) {
		this.gErorPrcssDd = gErorPrcssDd;
	}
	public String getErorPrcssYn() {
		return erorPrcssYn;
	}
	public void setErorPrcssYn(String erorPrcssYn) {
		this.erorPrcssYn = erorPrcssYn;
	}
	public String getErorPrcssDd() {
		return erorPrcssDd;
	}
	public void setErorPrcssDd(String erorPrcssDd) {
		this.erorPrcssDd = erorPrcssDd;
	}
	public String getErorPrcssUserId() {
		return erorPrcssUserId;
	}
	public void setErorPrcssUserId(String erorPrcssUserId) {
		this.erorPrcssUserId = erorPrcssUserId;
	}
	public String getErorPrcssSide() {
		return erorPrcssSide;
	}
	public void setErorPrcssSide(String erorPrcssSide) {
		this.erorPrcssSide = erorPrcssSide;
	}
	public String[] getCheckboxList() {
		return checkboxList;
	}
	public void setCheckboxList(String[] checkboxList) {
		this.checkboxList = checkboxList;
	}
	public String getBsnCd() {
		return bsnCd;
	}
	public void setBsnCd(String bsnCd) {
		this.bsnCd = bsnCd;
	}
	public String getBsnCdNm() {
		return bsnCdNm;
	}
	public void setBsnCdNm(String bsnCdNm) {
		this.bsnCdNm = bsnCdNm;
	}
	public String getRqstDat() {
		return rqstDat;
	}
	public void setRqstDat(String rqstDat) {
		this.rqstDat = rqstDat;
	}
	public String getRqstRpseCdNm() {
		return rqstRpseCdNm;
	}
	public void setRqstRpseCdNm(String rqstRpseCdNm) {
		this.rqstRpseCdNm = rqstRpseCdNm;
	}
	public java.lang.String getCmmCd() {
		return cmmCd;
	}
	public void setCmmCd(java.lang.String cmmCd) {
		this.cmmCd = cmmCd;
	}
	public java.lang.String getCmmCdNm() {
		return cmmCdNm;
	}
	public void setCmmCdNm(java.lang.String cmmCdNm) {
		this.cmmCdNm = cmmCdNm;
	}
	public java.lang.String getGrpCd() {
		return grpCd;
	}
	public void setGrpCd(java.lang.String grpCd) {
		this.grpCd = grpCd;
	}
	public java.lang.String getSrchOrgnzCd() {
		return srchOrgnzCd;
	}
	public void setSrchOrgnzCd(java.lang.String srchOrgnzCd) {
		this.srchOrgnzCd = srchOrgnzCd;
	}
	public java.lang.String getSrchOrgnzNm() {
		return srchOrgnzNm;
	}
	public void setSrchOrgnzNm(java.lang.String srchOrgnzNm) {
		this.srchOrgnzNm = srchOrgnzNm;
	}
	public java.lang.String getOficTye() {
		return oficTye;
	}
	public void setOficTye(java.lang.String oficTye) {
		this.oficTye = oficTye;
	}


		
}
