package afnid.cm.log.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;




public interface LgService {
	/**
	 * Retrieves list of officer. <br>
	 * 
	 * @param vo Input item for retrieving list of officer(LgVO).
	 * @return List Retrieve list of officer
	 * @exception Exception 
	 */
	List<LgVO> searchListUserLgnLg(LgVO vo) throws Exception;
	/**
	 * Retrieves total count of officer list. <br>
	 * @param vo Input item for retrieving total count list of officer.(LgVO)
	 * @return int Total Count of officer List
	 * @exception Exception  
	 */
	int searchListUserLgnLgTotCnt(LgVO vo) throws Exception;
	/**
	 * Retrieves list of user work log. <br>
	 * 
	 * @param vo Input item for retrieving list of user work log(LgVO).
	 * @return List Retrieve list of user work log
	 * @exception Exception 
	 */
	List<LgVO> searchListUserWrkLg(LgVO vo) throws Exception;
	/**
	 * Retrieves total count of user work log list. <br>
	 * @param vo Input item for retrieving total count list of user work log.(LgVO)
	 * @return int Total Count of user work log List
	 * @exception Exception  
	 */
	int searchListUserWrkLgTotCnt(LgVO vo) throws Exception;
	
	/**
	 * Retrieves list of CMS xml generation log. <br>
	 * 
	 * @param vo Input item for retrieving list of CMS xml generation log(LgVO).
	 * @return List Retrieve list of CMS xml generation log
	 * @exception Exception
	 */
	List<EgovMap> searchListDppFleLg(LgVO vo) throws Exception;
	
	/**
	 * Retrieves total count of CMS xml generation log list. <br>
	 * @param vo Input item for retrieving total count list of CMS xml generation log.(LgVO)
	 * @return int Total Count of CMS xml generation log List
	 * @exception Exception
	 */
	int searchListDppFleLgTotCnt(LgVO vo) throws Exception;
	
	
	
	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchListDppSndRcivLg(LgVO vo) throws Exception;
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(LgVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListDppSndRcivLgTotCnt(LgVO vo) throws Exception;
	
	/**
	 * Retrieves list of Batch Process log. <br>
	 * 
	 * @param vo Input item for retrieving list of Batch Process log(LogDppVO).
	 * @return List Retrieve list of Batch Process log
	 * @exception Exception
	 */
	List<LgVO> searchListBachJobLg(LgVO vo) throws Exception;
	
	/**
	 * Retrieves total count of Batch Process log list. <br>
	 * @param vo Input item for retrieving total count list of Batch Process log.(LgVO)
	 * @return int Total Count of Batch Process log List
	 * @exception Exception
	 */
	int searchListBachJobLgTotCnt(LgVO vo) throws Exception;
	
	/**
	 * Retrieves list of bio interface log. <br>
	 *
	 * @param vo Input item for retrieving list of bio interface log(LgVO).
	 * @return List Retrieve list of bio interface log
	 * @exception Exception
	 */
	List<EgovMap> searchListBioIfLg(LgVO vo) throws Exception;
	/**
	 * Retrieves total count of bio interface log list. <br>
	 * @param vo Input item for retrieving total count list of bio interface log.(LgVO)
	 * @return int Total Count of bio interface log List
	 * @exception Exception
	 */
	int searchListBioIfLgTotCnt(LgVO vo) throws Exception;
	
	/**
	 * Retrieves list of CMS interface log. <br>
	 *
	 * @param vo Input item for retrieving list of CMS interface log(LgVO).
	 * @return List Retrieve list of CMS interface log
	 * @exception Exception
	 */
	List<EgovMap> searchListPkiIfLg(LgVO vo) throws Exception;
	/**
	 * Retrieves total count of CMS interface log list. <br>
	 * @param vo Input item for retrieving total count list of CMS interface log.(LgVO)
	 * @return int Total Count of CMS interface log List
	 * @exception Exception
	 */
	int searchListPkiIfLgTotCnt(LgVO vo) throws Exception;

	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(String, String)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	void addUserWrkLg(String userId, String mnId) throws Exception;
	

	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(String, String, String, String)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	void addBioIfLg(String userId, String rqstRpseCd, String erorYn, String msg, String bioKey) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchListCmsEror(LgVO vo) throws Exception;
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(LgVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListCmsErorTotCnt(LgVO vo) throws Exception;	
	
	/**
	 * RM-CMS interface error processing <br>
	 * 
	 * @param vo Input item for RM-CMS interface error processing (LgVO).
	 * @return 
	 * @exception Exception
	 */
	public void modifyCmsEror(LgVO vo) throws Exception;
	
	/**
	 * Re-send webServide(Officer Account Registration) <br>
	 * 
	 * @param vo Input item for Resend webServide (LgVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyOficrErorResnd(LgVO vo) throws Exception;
	
	/**
	 * PKI Interface call(Officer Account Registration) <br>
	 * 
	 * @param vo Input item for PKI Interface call (LgVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyOficrErorResndPkiIf(LgVO vo) throws Exception;
	
	/**
	 * Re-send webServide(Write of  eNID Card Chip) <br>
	 * 
	 * @param vo Input item for Resend webServide (LgVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyCrdChipWrtErorResnd(LgVO vo) throws Exception;
	
	/**
	 * PKI Interface call(Write of  eNID Card Chip) <br>
	 * 
	 * @param vo Input item for PKI Interface call (LgVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyCrdChipWrtErorResndPkiIf(LgVO vo) throws Exception;
	
	/**
	 * Re-send webServide(Request Read of eNID Card Chip) <br>
	 * 
	 * @param vo Input item for Resend webServide (LgVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyCrdChipReadRqstErorResnd(LgVO vo) throws Exception;
	
	/**
	 * PKI Interface call(Request Read of eNID Card Chip) <br>
	 * 
	 * @param vo Input item for PKI Interface call (LgVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyCrdChipReadRqstErorResndPkiIf(LgVO vo) throws Exception;
	
	
	/**
	 * Re-send webServide(Request Kill of eNID Card) <br>
	 * 
	 * @param vo Input item for Re-send webServide(LgVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyCrdKillErorResnd(LgVO vo) throws Exception;	
	
	/**
	 * PKI Interface call(Request Kill of eNID Card) <br>
	 * 
	 * @param vo Input item for PKI Interface call (LgVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyCrdKillErorResndPkiIf(LgVO vo) throws Exception;	
	
	
	/**
	 * Retrieves list of web service interface name. <br>
	 * 
	 * @param vo Input item for retrieving list of web service interface name.(LgVO).
	 * @return List Retrieve list of web service interface name
	 * @exception Exception
	 */
	List<LgVO> searchListWebSrvcIfNm(LgVO vo) throws Exception;	
}	
