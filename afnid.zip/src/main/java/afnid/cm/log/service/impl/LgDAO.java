package afnid.cm.log.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.cm.NidMessageSource;
import afnid.cm.log.service.LgVO;
import afnid.cm.uss.service.UserMngVO;
import afnid.cm.util.service.NidStringUtil;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This class is Database Access Object of monitoring
 * 
 * @author Afghanistan National ID Card System Application Team  MS Kim 
 * @since 2013.09.26
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           	    Revisions
 *   2013.09.26    		MS Kim          			Create
 *
 * </pre>
 */

@Repository("lgDAO")
public class LgDAO extends EgovAbstractDAO{

	
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
	
	
	/**
	 * DAO-method for retrieving list of program.<br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return List Retrieve list of program
	 * @exception Exception 
	 */		
	@SuppressWarnings("unchecked")
	public List<LgVO> selectListUserLgnLg(LgVO vo) throws Exception{
		vo.setSearchKeyword5(NidStringUtil.toNumberConvet(vo.getSearchKeyword5(), "g"));
		return list("logDAO.selectListUserLgnLg", vo);
	}
	
	/**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return int Total Count of Program List
	 * @exception Exception 
	 */
    public int selectListUserLgnLgTotCnt(LgVO vo) {
    	vo.setSearchKeyword5(NidStringUtil.toNumberConvet(vo.getSearchKeyword5(), "g"));
        return (Integer)selectByPk("logDAO.selectListUserLgnLgTotCnt", vo);
    }
    /**
	 * DAO-method for retrieving list of program.<br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return List Retrieve list of program
	 * @exception Exception 
	 */		
	@SuppressWarnings("unchecked")
	public List<LgVO> selectListUserWrkLg(LgVO vo) throws Exception{
		vo.setSearchKeyword5(NidStringUtil.toNumberConvet(vo.getSearchKeyword5(), "g"));
		return list("logDAO.selectListUserWrkLg", vo);
	}
	
	/**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return int Total Count of Program List
	 * @exception Exception 
	 */
    public int selectListUserWrkLgTotCnt(LgVO vo) {
    	vo.setSearchKeyword5(NidStringUtil.toNumberConvet(vo.getSearchKeyword5(), "g"));
        return (Integer)selectByPk("logDAO.selectListUserWrkLgTotCnt", vo);
    }
    
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param vo Input item for retrieving detail information of program(LgVO).
	 * @return FmlyInfoVO Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListDppFleLg(LgVO vo) throws Exception{
		return list("logDAO.selectListDppFleLg", vo);
	}

    /**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(DppLgVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListDppFleLgTotCnt(LgVO vo) {
        return (Integer)selectByPk("logDAO.selectListDppFleLgTotCnt", vo);
    }
    
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param vo Input item for retrieving detail information of program(LgVO).
	 * @return FmlyInfoVO Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListDppSndRcivLg(LgVO vo) throws Exception{
		return list("logDAO.selectListDppSndRcivLg", vo);
	}

    /**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListDppSndRcivLgTotCnt(LgVO vo) {
        return (Integer)selectByPk("logDAO.selectListDppSndRcivLgTotCnt", vo);
    }
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param vo Input item for retrieving detail information of program(LgVO).
	 * @return LogBatchJobVO Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<LgVO> selectListBachJobLg(LgVO vo) throws Exception{
		return list("logDAO.selectListBachJobLg", vo);
	}

    /**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListBachJobLgTotCnt(LgVO vo) {
        return (Integer)selectByPk("logDAO.logDAO.selectListBachJobLgTotCnt", vo);
    }
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(LgVO).
	 * @return list Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListBioIfLg(LgVO vo) throws Exception{
		vo.setSearchKeyword4(NidStringUtil.toNumberConvet(vo.getSearchKeyword4(), "g"));
		return list("logDAO.selectListBioIfLg", vo);		
	}
    /**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	public int selectListBioIfLgTotCnt(LgVO vo ){
		vo.setSearchKeyword4(NidStringUtil.toNumberConvet(vo.getSearchKeyword4(), "g"));
		return (Integer)selectByPk("logDAO.selectListBioIfLgTotCnt",vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(LgVO).
	 * @return list Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListPkiIfLg(LgVO vo) throws Exception{
		vo.setSearchKeyword6(NidStringUtil.toNumberConvet(vo.getSearchKeyword6(), "g"));
		return list("logDAO.selectListPkiIfLg", vo);		
	}
    /**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	public int selectListPkiIfLgTotCnt(LgVO vo ){
		vo.setSearchKeyword6(NidStringUtil.toNumberConvet(vo.getSearchKeyword6(), "g"));
		return (Integer)selectByPk("logDAO.selectListPkiIfLgTotCnt",vo);
	}
	
	
	
	
	/**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	public void insertUserWrkLg(LgVO vo ) throws Exception{
		insert("logDAO.insertUserWrkLg",vo);
	}
	
	
	/**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(String, String, int, String, String, String).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	/*
	public void insertPubKeyIfLg(String userId, String rsdtNo, String erorCn, String rqstRpseCd, String pubKeyDivCd) throws Exception{
		if(userId != null){
			LgVO vo = new LgVO();
    		vo.setUserId(userId);
    		vo.setRsdtNo(rsdtNo);
    		String erorYn = "N";
    		if(!"0".equals(erorCn)){
    			erorYn = "Y";
    		}
    		vo.setErorYn(erorYn);
    		String msg = String.valueOf(erorCn);
    		StringBuffer sb = new StringBuffer();
    		sb.append("pki.msg.").append(msg);
    		vo.setMsg(nidMessageSource.getMessage(sb.toString()));
    		vo.setRqstRpseCd(rqstRpseCd);
    		vo.setPubKeyDivCd(pubKeyDivCd);
			insert("logDAO.insertPubKeyIfLg",vo);
		}
	}
	*/
	/**
	 * DAO-method for registration of PKI log. <br>
	 * 
	 * @param vo Input item for registration of PKI log(String, String, String, String, String, String, String).
	 * @return String  Log Sequence Number
	 * @exception Exception
	 */

	public String insertPubKeyIfLg(String userId, String rsdtNo, String rqstRpseCd, String pubKeyDivCd, String bsnCd, String rqstDat) throws Exception{
		String lgSeqNo ="";
		if(userId != null){
			LgVO vo = new LgVO();
    		vo.setUserId(userId);
    		vo.setRsdtNo(rsdtNo);
    		vo.setErorYn("Y");
    		vo.setRqstRpseCd(rqstRpseCd);
    		vo.setPubKeyDivCd(pubKeyDivCd);
    		vo.setBsnCd(bsnCd);
    		vo.setRqstDat(rqstDat);
			lgSeqNo = (String)insert("logDAO.insertPubKeyIfLg",vo);
		}
		
		return lgSeqNo;
	}

	/**
	 * DAO-method for modify  PKI log. <br>
	 * 
	 * @param vo Input item for modify  PKI log(String, String, String, String, String).
	 * @return 
	 * @exception Exception
	 */
	public void updatePubKeyIfLg(String lgSeqNo, String erorMsg, String erorYn) throws Exception{
		if(lgSeqNo != null){
			LgVO vo = new LgVO();
    		vo.setLgSeqNo(lgSeqNo);
    		vo.setMsg(erorMsg);
    		vo.setErorYn(erorYn);
    		update("logDAO.updatePubKeyIfLg",vo);
		}
	}
	
	/**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(String, String, String, String).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	public void insertBioIfLg(String userId, String rqstRpseCd, String erorYn, String msg, String bioKey) throws Exception{
		if(userId != null){
			LgVO vo = new LgVO();
    		vo.setUserId(userId);
    		vo.setRqstRpseCd(rqstRpseCd);
    		vo.setErorYn(erorYn);
    		vo.setMsg(msg);
    		vo.setBioKey(bioKey);
			insert("logDAO.insertBioIfLg",vo);
		}
		
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(LgVO).
	 * @return list Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListCmsEror(LgVO vo) throws Exception{
		vo.setSearchKeyword6(NidStringUtil.toNumberConvet(vo.getSearchKeyword6(), "g"));
		return list("logDAO.selectListCmsEror", vo);		
	}
    /**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(LgVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	public int selectListCmsErorTotCnt(LgVO vo ){
		vo.setSearchKeyword6(NidStringUtil.toNumberConvet(vo.getSearchKeyword6(), "g"));
		return (Integer)selectByPk("logDAO.selectListCmsErorTotCnt",vo);
	}	
	
	/**
	 * DAO-method for RM-CMS interface error processing. <br>
	 * 
	 * @param vo Input item for RM-CMS interface error processing(LgVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	public void updateCmsEror(LgVO vo) throws Exception{
		update("logDAO.updateCmsEror",vo);
	}
	
	/**
	 * DAO-method for retrieving detail Information of user(Officer Account Registration). <br>
	 * 
	 * @param vo Input item for retrieving detail Information of user(UserMngVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	public UserMngVO selectUserInfr(LgVO vo) throws Exception{
		return (UserMngVO)selectByPk("logDAO.selectUserInfr", vo);
	}
	
	/**
	 * DAO-method for retrieving detail Information of user(Officer Account Registration). <br>
	 * 
	 * @param vo Input item for retrieving detail Information of user(UserMngVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	public LgVO selctRqstDat(LgVO vo) throws Exception{
		return (LgVO)selectByPk("logDAO.selctRqstDat", vo);
	}
	
	
	/**
	 * DAO-method for retrieving list of web service interface name.<br>
	 * 
	 * @param vo Input item for retrieving list of web service interface name(LgVO).
	 * @return List Retrieve list of web service interface name
	 * @exception Exception 
	 */		
	@SuppressWarnings("unchecked")
	public List<LgVO> selectListWebSrvcIfNm(LgVO vo) throws Exception{
		return list("logDAO.selectListWebSrvcIfNm", vo);
	}	
}
