package afnid.cm.log.web;

import java.io.StringWriter;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgVO;
import afnid.cm.log.service.LgService;

import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/**
 * @Class Name : LogUserController.java
 * @Description : Access controller classes for managing log information.
 * @Modification Information
 *
 *    Modified.       Modifier.         Modifications.
 *    -------        -------     -------------------
 *   2013.09.09    Si Kyung Yang          Create
 *
 * @author Si Kyung Yang
 * @since 2013. 9. 09.
 * @version
 * @see
 *
 */
@Controller
public class LgController {
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /** LgService */
	@Resource(name = "lgService")
    private LgService lgService;

    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;

	/** nidCmmService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCmmService;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;

    /**
     * Moved to list-screen of Log User Login. <br>
     * 
     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
     * @param userLgnLgVO Value-object of user to be parsed request(UserLgnLgVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/log/UserLgnLgList.jsp"
     * @exception Exception
     */
	  @RequestMapping(value="/cm/log/searchListUserLgnLgView.do")
	    public String searchListUserLgnLgView(
	    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
	    		@ModelAttribute("userLgnLgVO") LgVO userLgnLgVO,
	    		ModelMap model)
	            throws Exception { 

	    	try {
	    		
	        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	        	
	        	lgService.addUserWrkLg(user.getUserId(), userLgnLgVO.getCurMnId());
	        	
	    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
	    		
	    		//Organization Class Code List.
	    		cmCmmCd.setGrpCd("25"); // Setting Group Code
	    		List<CmCmmCdVO> lstOrgClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
	    		model.addAttribute("lstOrgClsCd", lstOrgClsCd); 
	    			    		
	    		ComDefaultVO comVo = new ComDefaultVO();
	    		comVo.setAddDay("-6");
	    		comVo = nidCmmService.searchGreAddingInputDay(comVo);	    		
	    		comDefaultVO.setSearchKeyword(comVo.getStartDay().replaceAll("-", ""));
	    		
	    		comVo = nidCmmService.searchGreToDay(comVo);	    			    			    		
	    		comDefaultVO.setSearchKeyword2(comVo.getStartDay().replaceAll("-", ""));
	    		comDefaultVO.setSearchKeyword7("2");
	    	} catch (Exception e) {
	    		log.error(e.getMessage(), e);
	    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
	    	}

	      	return "/cm/log/UserLgnLgList";
	    }
	  
	    /**
	     * Moved to list-screen of Log User Login. <br>
	     * 
	     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
	     * @param userLgnLgVO Value-object of user to be parsed request(UserLgnLgVO)
	     * @param model Object to be parsed http request(ModelMap) 
	     * @return Printed out JSP: "/cm/log/UserLgnLgList.jsp"
	     * @exception Exception
	     */
		  @RequestMapping(value="/cm/log/searchListUserLgnLg.do")
		    public String searchListUserLgnLg(
		    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
		    		@ModelAttribute("userLgnLgVO") LgVO userLgnLgVO,
		    		ModelMap model)
		            throws Exception { 

		    	try {
		    		/** Paging Setting */
		    		userLgnLgVO.setPageUnit(propertiesService.getInt("pageUnit"));
		    		userLgnLgVO.setPageSize(propertiesService.getInt("pageSize"));
			
			    	/** pageing */
			    	PaginationInfo paginationInfo = new PaginationInfo();
					paginationInfo.setCurrentPageNo(userLgnLgVO.getPageIndex());
					paginationInfo.setRecordCountPerPage(userLgnLgVO.getPageUnit());
					paginationInfo.setPageSize(userLgnLgVO.getPageSize());
			
					userLgnLgVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
					userLgnLgVO.setLastIndex(paginationInfo.getLastRecordIndex());
					userLgnLgVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
					model.addAttribute("paginationInfo", paginationInfo);   
		    		
		    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();

				    if(!"".equals(userLgnLgVO.getSrchOrgnzCd())){
				    	
			            if( "00".equals(userLgnLgVO.getSrchOrgnzCd().substring(2, 4)) ){
			            	userLgnLgVO.setOficTye("1");
			            } else{
			            	userLgnLgVO.setOficTye("2");
			            }		    	
				    }
				    
		    		//Organization Class Code List.
		    		cmCmmCd.setGrpCd("25"); // Setting Group Code
		    		List<CmCmmCdVO> lstOrgClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
		    		model.addAttribute("lstOrgClsCd", lstOrgClsCd); 
		    		
		    		List<LgVO> lstLogUser = lgService.searchListUserLgnLg(userLgnLgVO);
		    		model.addAttribute("lstLogUser", lstLogUser); // Main Service Code  
	    		    int totCnt = lgService.searchListUserLgnLgTotCnt(userLgnLgVO);
	  				paginationInfo.setTotalRecordCount(totCnt);
		    		
		    	} catch (Exception e) {
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}

		      	return "/cm/log/UserLgnLgList";
		    }
	    /**
	     * Moved to list-screen of Log User Work. <br>
	     * 
	     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
	     * @param userWrkLgVO Value-object of user to be parsed request(UserWrkLgVO)
	     * @param model Object to be parsed http request(ModelMap) 
	     * @return Printed out JSP: "/cm/log/UserWrkLgList.jsp"
	     * @exception Exception
	     */
	  @RequestMapping(value="/cm/log/searchListUserWrkLgView.do")
	    public String searchListUserWrkLgView(
	    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
	    		@ModelAttribute("userWrkLgVO") LgVO userWrkLgVO,
	    		ModelMap model)
	            throws Exception { 

	    	try {
	    		
	        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	        	
	        	lgService.addUserWrkLg(user.getUserId(), userWrkLgVO.getCurMnId());
	        	
	    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
	    		List<CmCmmCdVO> mnId = cmmCdMngService.searchListMn(cmCmmCd);     		
	    		model.addAttribute("mnId", mnId);
	    		
	    		ComDefaultVO comVo = new ComDefaultVO();
	    		
	    		comVo.setAddDay("-6");
	    		comVo = nidCmmService.searchGreAddingInputDay(comVo);	    		
	    		comDefaultVO.setSearchKeyword(comVo.getStartDay().replaceAll("-", ""));
	    		
	    		comVo = nidCmmService.searchGreToDay(comVo);	    			    			    		
	    		comDefaultVO.setSearchKeyword2(comVo.getStartDay().replaceAll("-", ""));
	    		
	    	} catch (Exception e) {
	    		log.error(e.getMessage(), e);
	    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
	    	}

	      	return "/cm/log/UserWrkLgList";
	    }
	  /**
	     * Moved to list-screen of Log User Work. <br>
	     * 
	     * @param comDefaultVO Value-object of user to be parsed request(ComDefaultVO)
	     * @param userWrkLgVO Value-object of user to be parsed request(UserWrkLgVO)
	     * @param model Object to be parsed http request(ModelMap) 
	     * @return Printed out JSP: "/cm/log/UserWrkLgList.jsp"
	     * @exception Exception
	     */
		  @RequestMapping(value="/cm/log/searchListUserWrkLg.do")
		    public String searchListUserWrkLg(
		    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
		    		@ModelAttribute("userWrkLgVO") LgVO userWrkLgVO,
		    		ModelMap model)
		            throws Exception { 

		    	try {
		    		/** Paging Setting */
		    		userWrkLgVO.setPageUnit(propertiesService.getInt("pageUnit"));
		    		userWrkLgVO.setPageSize(propertiesService.getInt("pageSize"));
			
			    	/** pageing */
			    	PaginationInfo paginationInfo = new PaginationInfo();
					paginationInfo.setCurrentPageNo(userWrkLgVO.getPageIndex());
					paginationInfo.setRecordCountPerPage(userWrkLgVO.getPageUnit());
					paginationInfo.setPageSize(userWrkLgVO.getPageSize());
			
					userWrkLgVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
					userWrkLgVO.setLastIndex(paginationInfo.getLastRecordIndex());
					userWrkLgVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
					model.addAttribute("paginationInfo", paginationInfo);   
		    		
					CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		    		List<CmCmmCdVO> mnId = cmmCdMngService.searchListMn(cmCmmCd);     		
		    		model.addAttribute("mnId", mnId);
		    		
		    		List<LgVO> lstLogUser = lgService.searchListUserWrkLg(userWrkLgVO);
		    		model.addAttribute("lstLogUser", lstLogUser); // Main Service Code  
	    		    int totCnt = lgService.searchListUserWrkLgTotCnt(userWrkLgVO);
	  				paginationInfo.setTotalRecordCount(totCnt);
		    		
		    	} catch (Exception e) {
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}

		      	return "/cm/log/UserWrkLgList";
		    }
		  
		  /**
		     * Dpp and the resulting log file creation screen to inquire.
		     * 
		     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
		     * @param vo Value-object of program to be parsed request(DppLgVO)
		     * @param model Object to be parsed http request(ModelMap) 
		     * @return Printed out JSP: "/cm/log/DppFleLgList.jsp"
		     * @exception Exception
		     */
			@RequestMapping(value="/cm/log/searchListDppFleLgView.do")
			public String searchListDppFleLgView(
					@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
		    		@ModelAttribute("logDppVO") LgVO logDppVO,
					ModelMap model) throws Exception{
				try {
		    		
		        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	        	
		        	lgService.addUserWrkLg(user.getUserId(), logDppVO.getCurMnId());
		        	
		        	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		    		//Organization Class Code List.
		    		cmCmmCd.setGrpCd("25"); // Setting Group Code
		    		List<CmCmmCdVO> lstOrgClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
		    		model.addAttribute("lstOrgClsCd", lstOrgClsCd); 
					
		    		cmCmmCd.setGrpCd("63"); // Setting Group Code
		    		List<CmCmmCdVO> lstPrcssDivCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
		    		model.addAttribute("lstPrcssDivCd", lstPrcssDivCd); 

					ComDefaultVO comVo = new ComDefaultVO();
		    		comVo.setAddDay("-6");
		    		comVo = nidCmmService.searchGreAddingInputDay(comVo);	    		
		    		comDefaultVO.setSearchKeyword(comVo.getStartDay().replaceAll("-", ""));
		    		
		    		comVo = nidCmmService.searchGreToDay(comVo);	    			    			    		
		    		comDefaultVO.setSearchKeyword2(comVo.getStartDay().replaceAll("-", ""));
					
		    		comDefaultVO.setSearchKeyword8("2");
		    	} catch (Exception e) {
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}
		      	return "/cm/log/DppFleLgList";
			}
			
			/**
		     * Dpp and the resulting log file creation screen to inquire.
		     * 
		     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
		     * @param vo Value-object of program to be parsed request(DppLgVO)
		     * @param model Object to be parsed http request(ModelMap) 
		     * @return Printed out JSP: "/cm/log/DppFleLgList.jsp"
		     * @exception Exception
		     */
			@RequestMapping(value="/cm/log/searchListDppFleLg.do")
			public String searchListDppFleLg(
					@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
		    		@ModelAttribute("logDppVO") LgVO logDppVO,
					ModelMap model) throws Exception{
				try {
		    		
		        	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		    		//Organization Class Code List.
		    		cmCmmCd.setGrpCd("25"); // Setting Group Code
		    		List<CmCmmCdVO> lstOrgClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
		    		model.addAttribute("lstOrgClsCd", lstOrgClsCd); 
					
		    		cmCmmCd.setGrpCd("63"); // Setting Group Code
		    		List<CmCmmCdVO> lstPrcssDivCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
		    		model.addAttribute("lstPrcssDivCd", lstPrcssDivCd); 
		    		
				    if(!"".equals(logDppVO.getSrchOrgnzCd())){
				    	
			            if( "00".equals(logDppVO.getSrchOrgnzCd().substring(2, 4)) ){
			            	logDppVO.setOficTye("1");
			            } else{
			            	logDppVO.setOficTye("2");
			            }		    	
				    }		    		

				    logDppVO.setPageUnit(propertiesService.getInt("pageUnit"));
				    logDppVO.setPageSize(propertiesService.getInt("pageSize"));
			    	/** pageing */
			    	PaginationInfo paginationInfo = new PaginationInfo();
					paginationInfo.setCurrentPageNo(logDppVO.getPageIndex());
					paginationInfo.setRecordCountPerPage(logDppVO.getPageUnit());
					paginationInfo.setPageSize(logDppVO.getPageSize());
					logDppVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
					logDppVO.setLastIndex(paginationInfo.getLastRecordIndex());
					logDppVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
					
			        List<EgovMap> lstProgram = lgService.searchListDppFleLg(logDppVO);
			        model.addAttribute("lstProgram", lstProgram);
			        
			        int totCnt = lgService.searchListDppFleLgTotCnt(logDppVO);
					paginationInfo.setTotalRecordCount(totCnt);
			        model.addAttribute("paginationInfo", paginationInfo);
					
		    	} catch (Exception e) {
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}
		      	return "/cm/log/DppFleLgList";
			}
			
			/**
		     * Dpp file transmission / reception results to inquire.
		     * 
		     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
		     * @param vo Value-object of program to be parsed request(DppLgVO)
		     * @param model Object to be parsed http request(ModelMap) 
		     * @return Printed out JSP: "/cm/log/DppSndRcivLgList.jsp"
		     * @exception Exception
		     */
			@RequestMapping(value="/cm/log/searchListDppSndRcivLgView.do")
			public String searchListDppSndRcivLgView(
					@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
		    		@ModelAttribute("dppLgVO") LgVO dppLgVO,
					ModelMap model) throws Exception{
				try {
		    		
		        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	        	
		        	lgService.addUserWrkLg(user.getUserId(), dppLgVO.getCurMnId());
		        	
		        	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		    		//Organization Class Code List.
		    		cmCmmCd.setGrpCd("25"); // Setting Group Code
		    		List<CmCmmCdVO> lstOrgClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
		    		model.addAttribute("lstOrgClsCd", lstOrgClsCd); 
					
					ComDefaultVO comVo = new ComDefaultVO();
		    		comVo.setAddDay("-6");
		    		comVo = nidCmmService.searchGreAddingInputDay(comVo);	    		
		    		comDefaultVO.setSearchKeyword(comVo.getStartDay().replaceAll("-", ""));
		    		
		    		comVo = nidCmmService.searchGreToDay(comVo);	    			    			    		
		    		comDefaultVO.setSearchKeyword2(comVo.getStartDay().replaceAll("-", ""));
					
		    	} catch (Exception e) {
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}
		      	return "/cm/log/DppSndRcivLgList";
			}
			
			/**
		     * Dpp file transmission / reception results to inquire.
		     * 
		     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
		     * @param vo Value-object of program to be parsed request(DppLgVO)
		     * @param model Object to be parsed http request(ModelMap) 
		     * @return Printed out JSP: "/cm/log/DppSndRcivLgList.jsp"
		     * @exception Exception
		     */
			@RequestMapping(value="/cm/log/searchListDppSndRcivLg.do")
			public String searchListDppSndRcivLg(
					@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
		    		@ModelAttribute("dppLgVO") LgVO vo,
					ModelMap model) throws Exception{
				try {
					CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		    		//Organization Class Code List.
		    		cmCmmCd.setGrpCd("25"); // Setting Group Code
		    		List<CmCmmCdVO> lstOrgClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
		    		model.addAttribute("lstOrgClsCd", lstOrgClsCd); 					
					
					vo.setPageUnit(propertiesService.getInt("pageUnit"));
		    		vo.setPageSize(propertiesService.getInt("pageSize"));
			    	/** pageing */
			    	PaginationInfo paginationInfo = new PaginationInfo();
					paginationInfo.setCurrentPageNo(vo.getPageIndex());
					paginationInfo.setRecordCountPerPage(vo.getPageUnit());
					paginationInfo.setPageSize(vo.getPageSize());
					vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
					vo.setLastIndex(paginationInfo.getLastRecordIndex());
					vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
					
			        List<EgovMap> lstProgram = lgService.searchListDppSndRcivLg(vo);
			        model.addAttribute("lstProgram", lstProgram);
			        
			        int totCnt = lgService.searchListDppSndRcivLgTotCnt(vo);
					paginationInfo.setTotalRecordCount(totCnt);
			        model.addAttribute("paginationInfo", paginationInfo);
					
		    	} catch (Exception e) {
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}
		      	return "/cm/log/DppSndRcivLgList";
			}
	
			 /**
		     * Moved to list-screen of Batch Job Log. <br>
		     * 
		     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
		     * @param BachJobLgVO Value-object of program to be parsed request(BachJobLgVO)
		     * @param model Object to be parsed http request(ModelMap) 
		     * @return Printed out JSP: "/cm/log/BachJobLgList.jsp
		     * @exception Exception
		     */
		  @RequestMapping(value="/cm/log/searchListBachJobLgView.do")
		    public String searchListBachJobLgView(
		    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
		    		@ModelAttribute("bachJobLgVO") LgVO bachJobLgVO,
		    		ModelMap model)
		            throws Exception { 

		    	try {
		    		
		        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	        	
		        	lgService.addUserWrkLg(user.getUserId(), bachJobLgVO.getCurMnId());
		        	
					ComDefaultVO comVo = new ComDefaultVO();
		    		comVo.setAddDay("-6");
		    		comVo = nidCmmService.searchGreAddingInputDay(comVo);	    		
		    		comDefaultVO.setSearchKeyword(comVo.getStartDay().replaceAll("-", ""));
		    		
		    		comVo = nidCmmService.searchGreToDay(comVo);	    			    			    		
		    		comDefaultVO.setSearchKeyword2(comVo.getStartDay().replaceAll("-", ""));
		    		
		    		comDefaultVO.setSearchKeyword5("2");
			    	//setting Common Code
		    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		    		cmCmmCd.setGrpCd("43"); 
		    		List<CmCmmCdVO> batchJob = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
		    		model.addAttribute("batchJob", batchJob);
		    		
		    		
		    	} catch (Exception e) {
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}

		      	return "/cm/log/BachJobLgList";
		    }
			  
	    /**
	     * Moved to list-screen of Batch Job Log. <br>
	     * 
	     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
	     * @param bachJobLgVO Value-object of program to be parsed request(BachJobLgVO)
	     * @param model Object to be parsed http request(ModelMap) 
	     * @return Printed out JSP: "/cm/log/BachJobLgList"
	     * @exception Exception
	     */
		  @RequestMapping(value="/cm/log/searchListBachJobLg.do")
		    public String searchListBachJobLg(
		    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
		    		@ModelAttribute("bachJobLgVO") LgVO bachJobLgVO,
		    		ModelMap model)
		            throws Exception { 

		    	try {

		    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		    		cmCmmCd.setGrpCd("43"); 
		    		List<CmCmmCdVO> batchJob = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
		    		model.addAttribute("batchJob", batchJob);
		    		
					bachJobLgVO.setPageUnit(propertiesService.getInt("pageUnit"));
					bachJobLgVO.setPageSize(propertiesService.getInt("pageSize"));
			    	/** pageing */
			    	PaginationInfo paginationInfo = new PaginationInfo();
					paginationInfo.setCurrentPageNo(bachJobLgVO.getPageIndex());
					paginationInfo.setRecordCountPerPage(bachJobLgVO.getPageUnit());
					paginationInfo.setPageSize(bachJobLgVO.getPageSize());
					
					bachJobLgVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
					bachJobLgVO.setLastIndex(paginationInfo.getLastRecordIndex());
					bachJobLgVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
					
					List<LgVO> lstProgram = lgService.searchListBachJobLg(bachJobLgVO);
			        model.addAttribute("lstProgram", lstProgram);
			        int totCnt = lgService.searchListBachJobLgTotCnt(bachJobLgVO);
					paginationInfo.setTotalRecordCount(totCnt);
			        model.addAttribute("paginationInfo", paginationInfo);
		    		
		    	} catch (Exception e) {
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}

		      	return "/cm/log/BachJobLgList";
		    }
		  /**
		     * Moved to list-screen of PKI Info Log. <br>
		     * 
		     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
		     * @param pkiLgVO Value-object of program to be parsed request(PkiLgVO)
		     * @param model Object to be parsed http request(ModelMap) 
		     * @return Printed out JSP: "/cm/log/PkiIfLgList.jsp
		     * @exception Exception
		     */
		  @RequestMapping(value="/cm/log/searchListPkiIfLgView.do")
			public String searchListPkiIfLgView(
					@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
					@ModelAttribute("pkiLgVO") LgVO pkiLgVO,
					ModelMap model)throws Exception{
				try{
					
		        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	        	
		        	lgService.addUserWrkLg(user.getUserId(), pkiLgVO.getCurMnId());
		        	
					ComDefaultVO comVo = new ComDefaultVO();
		    		comVo.setAddDay("-6");
		    		comVo = nidCmmService.searchGreAddingInputDay(comVo);	    		
		    		comDefaultVO.setSearchKeyword(comVo.getStartDay().replaceAll("-", ""));
		    		
		    		comVo = nidCmmService.searchGreToDay(comVo);	    			    			    		
		    		comDefaultVO.setSearchKeyword2(comVo.getStartDay().replaceAll("-", ""));
					
					CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		    		cmCmmCd.setGrpCd("26"); 
		    		List<CmCmmCdVO> erorYn = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
		    		model.addAttribute("erorYn", erorYn);   
		    		
		    		cmCmmCd.setGrpCd("48"); 
		    		List<CmCmmCdVO> lstIfNm = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
		    		model.addAttribute("lstIfNm", lstIfNm);   
		    		
		    		cmCmmCd.setGrpCd("49"); 
		    		List<CmCmmCdVO> lstDIv = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
		    		model.addAttribute("lstDIv", lstDIv);   		    		
					
		    		comDefaultVO.setSearchKeyword8("2");
		    		
				}catch(Exception e){
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}
		        return "/cm/log/PkiIfLgList";
			}
		  /**
		     * Moved to list-screen of PKI Info Log. <br>
		     * 
		     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
		     * @param pkiLgVO Value-object of program to be parsed request(PkiLgVO)
		     * @param model Object to be parsed http request(ModelMap) 
		     * @return Printed out JSP: "/cm/log/PkiIfLgList.jsp"
		     * @exception Exception
		     */
			@RequestMapping(value="/cm/log/searchListPkiIfLg.do")
			public String searchListPkiIfLg(
					@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
					@ModelAttribute("pkiLgVO") LgVO vo,
					ModelMap model)throws Exception{
				try{
					
					vo.setPageUnit(propertiesService.getInt("pageUnit"));
		    		vo.setPageSize(propertiesService.getInt("pageSize"));

			    	PaginationInfo paginationInfo = new PaginationInfo();
					paginationInfo.setCurrentPageNo(vo.getPageIndex());
					paginationInfo.setRecordCountPerPage(vo.getPageUnit());
					paginationInfo.setPageSize(vo.getPageSize());
					
					vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
					vo.setLastIndex(paginationInfo.getLastRecordIndex());
					vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
					
					List<EgovMap> lstProgram = lgService.searchListPkiIfLg(vo);
					model.addAttribute("lstProgram", lstProgram);
					int totCnt = lgService.searchListPkiIfLgTotCnt(vo);
					paginationInfo.setTotalRecordCount(totCnt);
			        model.addAttribute("paginationInfo", paginationInfo);
					
					CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		    		cmCmmCd.setGrpCd("26"); 
		    		List<CmCmmCdVO> erorYn = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
		    		model.addAttribute("erorYn", erorYn);  
		    		
		    		cmCmmCd.setGrpCd("48"); 
		    		List<CmCmmCdVO> lstIfNm = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
		    		model.addAttribute("lstIfNm", lstIfNm);   
		    		
		    		cmCmmCd.setGrpCd("49"); 
		    		List<CmCmmCdVO> lstDIv = cmmCdMngService.searchListCmmCd(cmCmmCd);  
		    		model.addAttribute("lstDIv", lstDIv);   
					
				}catch(Exception e){
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}
		        return "/cm/log/PkiIfLgList";
			}
			
			/**
		     * Moved to list-screen of BIO Info Log. <br>
		     * 
		     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
		     * @param bioLgVo Value-object of program to be parsed request(BioLgVo)
		     * @param model Object to be parsed http request(ModelMap) 
		     * @return Printed out JSP: "/cm/log/BioIfLgList.jsp
		     * @exception Exception
		     */		
			@RequestMapping(value="/cm/log/searchListBioIfLgView.do")
			public String searchListBioIfLgView(
					@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
					@ModelAttribute("bioLgVo") LgVO bioLgVo,
					ModelMap model)throws Exception{
				try{
					
		        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	        	
		        	lgService.addUserWrkLg(user.getUserId(), bioLgVo.getCurMnId());
		        	
					ComDefaultVO comVo = new ComDefaultVO();
		    		comVo.setAddDay("-6");
		    		comVo = nidCmmService.searchGreAddingInputDay(comVo);	    		
		    		comDefaultVO.setSearchKeyword(comVo.getStartDay().replaceAll("-", ""));
		    		
		    		comVo = nidCmmService.searchGreToDay(comVo);	    			    			    		
		    		comDefaultVO.setSearchKeyword2(comVo.getStartDay().replaceAll("-", ""));
					
					CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		    		cmCmmCd.setGrpCd("26"); 
		    		List<CmCmmCdVO> erorYn = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
		    		model.addAttribute("erorYn", erorYn);   
					
		    		comDefaultVO.setSearchKeyword6("2");
		    		
				}catch(Exception e){
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}
		        return "/cm/log/BioIfLgList";
			}
			/**
		     * Moved to list-screen of BIO Info Log. <br>
		     * 
		     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
		     * @param bioLgVO Value-object of program to be parsed request(BioLgVO)
		     * @param model Object to be parsed http request(ModelMap) 
		     * @return Printed out JSP: "/cm/log/BioIfLgList.jsp"
		     * @exception Exception
		     */
			@RequestMapping(value="/cm/log/searchListBioIfLg.do")
			public String searchListBioIfLg(
					@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
					@ModelAttribute("bioLgVO") LgVO vo,
					ModelMap model)throws Exception{
				try{
					
					vo.setPageUnit(propertiesService.getInt("pageUnit"));
		    		vo.setPageSize(propertiesService.getInt("pageSize"));

			    	PaginationInfo paginationInfo = new PaginationInfo();
					paginationInfo.setCurrentPageNo(vo.getPageIndex());
					paginationInfo.setRecordCountPerPage(vo.getPageUnit());
					paginationInfo.setPageSize(vo.getPageSize());
					
					vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
					vo.setLastIndex(paginationInfo.getLastRecordIndex());
					vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
					
					List<EgovMap> lstProgram = lgService.searchListBioIfLg(vo);
					model.addAttribute("lstProgram", lstProgram);
					int totCnt = lgService.searchListBioIfLgTotCnt(vo);
					paginationInfo.setTotalRecordCount(totCnt);
			        model.addAttribute("paginationInfo", paginationInfo);
					
					CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		    		cmCmmCd.setGrpCd("26"); 
		    		List<CmCmmCdVO> erorYn = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
		    		model.addAttribute("erorYn", erorYn);  
					
				}catch(Exception e){
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}
		        return "/cm/log/BioIfLgList";
			}
			
			
			  /**
		     * Dpp and the resulting log file creation screen to inquire.
		     * 
		     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
		     * @param vo Value-object of program to be parsed request(DppLgVO)
		     * @param model Object to be parsed http request(ModelMap) 
		     * @return Printed out JSP: "/cm/log/DppFleLgList.jsp"
		     * @exception Exception
		     */
			@RequestMapping(value="/cm/log/searchListCmsErorView.do")
			public String searchListCmsErorView(
					@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
		    		@ModelAttribute("cmsErorVO") LgVO vo,
					ModelMap model) throws Exception{
				try {
		    		
		        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	        	
		        	lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
		        	
					ComDefaultVO comVo = new ComDefaultVO();
		    		comVo.setAddDay("-6");
		    		comVo = nidCmmService.searchGreAddingInputDay(comVo);	    		
		    		comDefaultVO.setSearchKeyword(comVo.getStartDay().replaceAll("-", ""));
		    		
		    		comVo = nidCmmService.searchGreToDay(comVo);	    			    			    		
		    		comDefaultVO.setSearchKeyword2(comVo.getStartDay().replaceAll("-", ""));
					
					CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		    		cmCmmCd.setGrpCd("26"); 
		    		List<CmCmmCdVO> prcsdYn = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
		    		model.addAttribute("prcsdYn", prcsdYn);   
		    		
		    		vo.setSearchKeyword4("1");
		    		
		    		List<LgVO> lstIfNm = lgService.searchListWebSrvcIfNm(vo);     		
		    		model.addAttribute("lstIfNm", lstIfNm);   
		    		
		    		cmCmmCd.setGrpCd("49"); 
		    		List<CmCmmCdVO> lstDIv = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
		    		model.addAttribute("lstDIv", lstDIv); 
					
		    		comDefaultVO.setSearchKeyword7("2");
		    		comDefaultVO.setSearchKeyword4("1");
		    		
		    	} catch (Exception e) {
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}
		      	return "/cm/log/CmsErorList";
			}
			
			/**
		     * Dpp and the resulting log file creation screen to inquire.
		     * 
		     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
		     * @param vo Value-object of program to be parsed request(DppLgVO)
		     * @param model Object to be parsed http request(ModelMap) 
		     * @return Printed out JSP: "/cm/log/DppFleLgList.jsp"
		     * @exception Exception
		     */
			@RequestMapping(value="/cm/log/searchListCmsEror.do")
			public String searchListCmsEror(
					@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
		    		@ModelAttribute("cmsErorVO") LgVO vo,
					ModelMap model) throws Exception{
				try {
					
					CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		    		cmCmmCd.setGrpCd("26"); 
		    		List<CmCmmCdVO> prcsdYn = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
		    		model.addAttribute("prcsdYn", prcsdYn);   
		    		
		    		
		    		List<LgVO> lstIfNm = lgService.searchListWebSrvcIfNm(vo);     		
		    		model.addAttribute("lstIfNm", lstIfNm);   
		    		
		    		
		    		cmCmmCd.setGrpCd("49"); 
		    		List<CmCmmCdVO> lstDIv = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
		    		model.addAttribute("lstDIv", lstDIv); 
					
					vo.setPageUnit(propertiesService.getInt("pageUnit"));
		    		vo.setPageSize(propertiesService.getInt("pageSize"));
			    	/** pageing */
			    	PaginationInfo paginationInfo = new PaginationInfo();
					paginationInfo.setCurrentPageNo(vo.getPageIndex());
					paginationInfo.setRecordCountPerPage(vo.getPageUnit());
					paginationInfo.setPageSize(vo.getPageSize());
					vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
					vo.setLastIndex(paginationInfo.getLastRecordIndex());
					vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
					
			        List<EgovMap> lstProgram = lgService.searchListCmsEror(vo);
			        model.addAttribute("lstProgram", lstProgram);
			        
			        int totCnt = lgService.searchListCmsErorTotCnt(vo);
					paginationInfo.setTotalRecordCount(totCnt);
					
			        model.addAttribute("paginationInfo", paginationInfo);
					
		    	} catch (Exception e) {
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}
		      	return "/cm/log/CmsErorList";
			}
			
			/**
		     * RM-CMS interface error processing.  <br>
		     * 
		     * @param ComDefaultVO Value-object of Resident Information to be parsed request(ComDefaultVO)
		     * @param model Object to be parsed http request(ModelMap) 
		     * @return Printed out JSP: "/cm/log/CmsErorList.jsp"
		     * @exception Exception
		     */
			@RequestMapping(value="/cm/log/modifyCmsEror.do")
		    public String modifyCmsEror (
		    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
		    		@ModelAttribute("cmsErorVO") LgVO vo,
		    		ModelMap model)
		            throws Exception {
				
				try{            
					lgService.modifyCmsEror(vo);    		
					model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
					
				}catch(Exception e){
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}
		   		return "forward:/cm/log/searchListCmsEror.do";
		    }
			
			/**
		     * RM-CMS interface error processing.  <br>
		     * 
		     * @param ComDefaultVO Value-object of Resident Information to be parsed request(ComDefaultVO)
		     * @param LgVO Value-object of modify Information to be parsed request(vo)
		     * @param model Object to be parsed http request(ModelMap) 
		     * @return Printed out JSP: "/cm/log/CmsErorList.jsp"
		     * @exception Exception
		     */
			@RequestMapping(value="/cm/log/modifyCmsErorResnd.do")
		    public String modifyCmsErorResnd (
		    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
		    		@ModelAttribute("cmsErorVO") LgVO vo,
		    		ModelMap model)
		            throws Exception {

				String result ="";
				String lgSeqNo ="";
				
				try{  
					
					if("9".equals(vo.getRqstRpseCd())){//Officer Account Registration 
						lgSeqNo = lgService.modifyOficrErorResnd(vo);
						vo.setLgSeqNo1(lgSeqNo);
						result  = lgService.modifyOficrErorResndPkiIf(vo);
						
			    		if(!"0".equals(result)){
			    			String helpTelNo = nidMessageSource.getMessage("admTelNo");
			    			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{result, helpTelNo}));
			    		} else {
			    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
			    		}
			    		 
					} else if ("20".equals(vo.getRqstRpseCd())){//Write of  eNID Card Chip
						lgSeqNo = lgService.modifyCrdChipWrtErorResnd(vo);
						vo.setLgSeqNo1(lgSeqNo);
						result  = lgService.modifyCrdChipWrtErorResndPkiIf(vo);
						
			    		if(!"OK".equals(result)){
			    			String helpTelNo = nidMessageSource.getMessage("admTelNo");
			    			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{result, helpTelNo}));
			    		} else {
			    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
			    		}						
						
					} else if("21".equals(vo.getRqstRpseCd())){//Request Read of eNID Card Chip
						lgSeqNo = lgService.modifyCrdChipReadRqstErorResnd(vo);						
						vo.setLgSeqNo1(lgSeqNo);
						result  = lgService.modifyCrdChipReadRqstErorResndPkiIf(vo);
						
			    		if(!"1".equals(result)){
			    			String helpTelNo = nidMessageSource.getMessage("admTelNo");
			    			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{result, helpTelNo}));
			    		} else {
			    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
			    		}
			    		
					} else if("23".equals(vo.getRqstRpseCd())){//Request Kill of eNID Card
						lgSeqNo = lgService.modifyCrdKillErorResnd(vo);
						vo.setLgSeqNo1(lgSeqNo);
						result  = lgService.modifyCrdKillErorResndPkiIf(vo);
						
			    		if(!"1".equals(result)){
			    			String helpTelNo = nidMessageSource.getMessage("admTelNo");
			    			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{result, helpTelNo}));
			    		} else {
			    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
			    		}						
					} 
					


					
				}catch(Exception e){
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}
		   		return "forward:/cm/log/searchListCmsEror.do";
		    }	
			
			
		    /**
		     * Retrieves list of web service interface name.  <br>
		     * 
		     * @param regionInfoVO Value-object of web service interface name(LgVO)
		     * @param model Object to be parsed http request(ModelMap) 
		     * @return Printed out JSP:""
		     * @exception Exception
		     */
		    @RequestMapping(value="/cm/code/searchListWebSrvcIfNmAjx.do")
		    public void searchListWebSrvcIfNmAjx(
		    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
		    		@ModelAttribute("cmsErorVO") LgVO vo,
					ModelMap model,
					HttpServletResponse response
					)
		            throws Exception {
		    	try {
		    		
		    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
		    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
		    		Document doc = docBuilder.newDocument();
		    		Element root = doc.createElement("root");
		    		doc.appendChild(root);
		    		
		    		Element cmmCd;
		    		Element cmmCdNm;

		    		List<LgVO> lstIfNm = lgService.searchListWebSrvcIfNm(vo);  
		    		
		    		//orgnzList = orgnzService.searchListOrgnzAjax(orgInfoVO);
		    		
		    		for(int i=0; i<lstIfNm.size(); i++){
		    			Element	webSrvcIf = doc.createElement("webSrvcIf");
		    			root.appendChild(webSrvcIf);
		    			
		    			cmmCd = doc.createElement("cmmCd");
		    			cmmCd.appendChild(doc.createTextNode(lstIfNm.get(i).getCmmCd()));
		    			
		    			cmmCdNm = doc.createElement("cmmCdNm");
		    			cmmCdNm.appendChild(doc.createTextNode(lstIfNm.get(i).getCmmCdNm()));
		    			
		    			webSrvcIf.appendChild(cmmCd);
		    			webSrvcIf.appendChild(cmmCdNm);
		    		}
		    		        		  
		    		Properties output = new Properties();
		    	    output.setProperty(OutputKeys.INDENT, "yes");
		    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
		    	    TransformerFactory tf = TransformerFactory.newInstance();
		    		Transformer t = tf.newTransformer();
		    	    t.setOutputProperties(output);
		    		StringWriter sw = new StringWriter();
		    		StreamResult result = new StreamResult(sw);
		    		DOMSource source = new DOMSource(doc);  		
		    		t.transform(source, result);    		
		    		response.setContentType("text/xml; charset=utf-8");
		    		response.getWriter().write(sw.toString());
		    		
		    	} catch (Exception e) {
		    		log.error(e.getMessage(), e);
		    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		    	}
		    } 			
			
}
