package afnid.cm.board.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.board.service.BrdService;
import afnid.cm.board.service.BrdVO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;


/** 
 * This service class is biz-class of board-management
 * and implements NidProgrmManageService class.
 * 
 * @author Afghanistan National ID Card System Application Team 
 * @since 2011.04.10
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers				Revisions
 *   2011.04.10  		MH ChoungGg         		Create
 *
 * </pre>
 */
@Service("brdService")
public class BrdServiceImpl extends AbstractServiceImpl implements BrdService {

	@Resource(name="brdDAO")
    private BrdDAO brdDAO;
	
    /** NidMessboard */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
	
	
	/**
	 * Biz-method for retrieving list of board. <br>
	 * 
	 * @param vo Input item for retrieving list of board(BrdVO).
	 * @return List Retrieve list of board
	 * @exception Exception
	 */
	public List<BrdVO> searchListBrd(BrdVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLangCd(user.getUseLangCd());
   		return brdDAO.selectListBrd(vo);
	}
	/**
	 * Biz-method for retrieving total count list of board. <br>
	 * 
	 * @param vo Input item for retrieving list of board(BrdVO).
	 * @return int Total Count of board List
	 * @exception Exception
	 */
    public int searchListBrdTotCnt(BrdVO vo) throws Exception {
        return brdDAO.selectListBrdTotCnt(vo);
	}
    
	/**
	 * Biz-method for registering information of new board. <br>
	 * 
	 * @param vo Input item for registering new board(BrdVO).
	 * @return BrdVO Primary Key value of registered board
	 * @exception Exception
	 */
	public BrdVO addBrd(BrdVO vo) throws Exception {

		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
					
    	brdDAO.insertBrd(vo);
    	
    	return vo;
	}
	
	/**
	 * Biz-method for delete information. <br>
	 * 
	 * @param vo Input item for delete Reply(BrdVO).
	 * @return void
	 * @exception Exception
	 */
	public void removeBrd(BrdVO vo) throws Exception {

		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());		
		brdDAO.deleteBrd(vo);
		
		
	}
	
	/**
	 * Biz-method for retrieving detail Information of board. <br>
	 * 
	 * @param vo Input item for retrieving detail information of board(BrdVO).
	 * @return BrdVO Retrieve detail information of board
	 * @exception Exception
	 */
	public BrdVO searchBrd(BrdVO vo) throws Exception{
			
         	return (BrdVO)brdDAO.selectBrd(vo);
	}
	
	/**
	 * Biz-method for modifying information of board. <br>
	 * 
	 * @param vo Input item for modifying board(BrdVO).
	 * @exception Exception
	 */
	public void modifyBrd(BrdVO vo) throws Exception {
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd());
    	brdDAO.updateBrd(vo);
	}
	
	/**
	 * Biz-method for retrieving recent notice. <br>
	 * 
	 * @param vo Input item for retrieving recent notice(int).
	 * @return String Retrieve recent notice
	 * @exception Exception
	 */
	public int searchNticYn(int newNticRng) throws Exception{
			
       return brdDAO.selectNticYn(newNticRng);
	}

}