package afnid.cm.board.service.impl;

import java.util.List;
 
import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import afnid.cm.board.service.BrdVO;


/** 
 * This class is Database Access Object of Board 
 * 
 * @author Afghanistan National ID Card System Application Team 
 * @since 2011.04.10
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers      			Revisions
 *   2011.04.10  		MH Choung         		Create
 *
 * </pre>
 */
@Repository("brdDAO")
public class BrdDAO extends EgovAbstractDAO {

	/**
	 * DAO-method for retrieving detail Information of board * 
	 * @param vo Input item for retrieving detail information of board(BrdVO).
	 * @return BrdVO Retrieve detail information of board
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<BrdVO> selectListBrd(BrdVO vo) throws Exception{
		return list("brdDAO.selectListBrd", vo);
	}

    /**
	 * DAO-method for retrieving total count list of board. <br>
	 * 
	 * @param vo Input item for retrieving list of board(BrdVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListBrdTotCnt(BrdVO vo) {
        return (Integer)selectByPk("brdDAO.selectListBrdTotCnt", vo);
    }	
	
	/**
	 * DAO-method for registering information of new board. <br>
	 * 
	 * @param vo Input item for registering new board(BrdVO).
	 * @return BrdVO Primary Key value of registered board
	 * @exception Exception
	 */
	public void insertBrd(BrdVO vo){
		insert("brdDAO.insertBrd", vo);
	}
	
	
	/**
	 * DAO-method for delete information of board. <br>
	 * 
	 * @param vo Input item for modifying pBrdVOanageVO).
	 * @exception Exception
	 */
	public void deleteBrd(BrdVO vo){
		update("brdDAO.deleteBrd", vo);
	}
	
	
	/**
	 * DAO-method for retrieving detail Information of board. <br>
	 * 
	 * @param vo Input item for retrieving detail information of board(BrdVO).
	 * @return BrdVO Retrieve detail information of board
	 * @exception Exception
	 */
	public BrdVO selectBrd(BrdVO vo)throws Exception{
		return (BrdVO)selectByPk("brdDAO.selectBrd", vo); 
	}

	/**
	 * DAO-method for modifying information of board. <br>
	 * 
	 * @param vo Input item for modifying pBrdVOanageVO).
	 * @exception Exception
	 */
	public void updateBrd(BrdVO vo){
		update("brdDAO.updateBrd", vo);
	}

	
	/**
	 * DAO-method for retrieving recent notice. <br>
	 * 
	 * @param vo Input item for retrieving recent notice(int).
	 * @return String Retrieve recent notice
	 * @exception Exception
	 */
	public int selectNticYn(int  newNticRng)throws Exception{
		return (Integer)selectByPk("brdDAO.selectNticYn", newNticRng); 
	}	

}