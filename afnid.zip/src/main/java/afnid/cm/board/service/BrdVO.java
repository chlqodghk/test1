package afnid.cm.board.service;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of board information
 * 
 * @author Afghanistan National ID Card System Application Team 
 * @since 2011.04.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers         	Revisions
 *   2011.04.21  		MH Choung         		Create
 *
 * </pre>
 */
public class BrdVO extends ComDefaultVO { 

	private static final long serialVersionUID = 1L;	

    
	private String flePrptSeqNo; 
	
    private String brdSeqNo;
    
    private String wrtSeqNo;
    
	/**BOARD ID*/	         
	private  String    brdId;	//1	BRD_ID
    /**WRITE ID*/	         
	private  String    wrtId;	//2	WRT_ID
    /**WRITE NO*/	         
	private  String    wrtNo;	//3	WRT_NO
    /**PASHTO TITLE NAME*/	         
	private  String    ttlNm;	//4	TTL_NM
    /**PASHTO CONTENTS*/	         
	private  String    brdCt;	//5	BRD_CT
    /**REPLY YN*/	         
	private  String    rplYn;	//6	RPL_YN
    /**REPLY POSITION NO*/	         
	private  String    rplPsnNo;	//7	RPL_PSN_NO
    /**HITS COUNT*/	         
	private  String    htsCn;	//8	HTS_CN
    /**USE YN*/	         
	private  String    useYn;	//9	USE_YN
    /**NOTICE START DATE*/	         
	private  String    nticSttDd;	//10	NTIC_STT_DD
    /**NOTICE END DATE*/	         
	private  String    nticEdDd;	//11	NTIC_ED_DD
    /**FIRST REGISTRATION USER ID*/	         
	private  String    fstRgstUserId;	//12	FST_RGST_USER_ID
    /**FIRST REGISTRATION DATETIME*/	         
	private  String    fstRgstDt;	//13	FST_RGST_DT
    /**LAST UPDATE USER ID*/	         
	private  String    lstUdtUserId;	//14	LST_UDT_USER_ID
    /**LAST UPDATE DATETIME*/	         
	private  String    lstUdtDt;	//15	LST_UDT_DT
    /**ATTACHMENT FILE ID*/	         
	private  String    atachFleId;	//16	ATACH_FLE_ID

	/**user's user language code*/	
    private  String    langCd;
    //Previous Page wrt_id 
    private String minNum;
    //Next Page wrt_id
    private String maxNum;
    
    private String    wrtNoDp;	//3	WRT_NO    
    private String calTye;    
    private String recntYn;
    
    private String hLstUdtDt;
    private String gLstUdtDt;
    
    public String getFlePrptSeqNo() {
		return flePrptSeqNo;
	}

	public void setFlePrptSeqNo(String flePrptSeqNo) {
		this.flePrptSeqNo = flePrptSeqNo;
	}

	public String getBrdSeqNo() {
		return brdSeqNo;
	}

	public void setBrdSeqNo(String brdSeqNo) {
		this.brdSeqNo = brdSeqNo;
	}

	public String getWrtSeqNo() {
		return wrtSeqNo;
	}

	public void setWrtSeqNo(String wrtSeqNo) {
		this.wrtSeqNo = wrtSeqNo;
	}

	public String getMinNum() {
		return minNum;
	}

	public void setMinNum(String minNum) {
		this.minNum = minNum;
	}

	public String getMaxNum() {
		return maxNum;
	}

	public void setMaxNum(String maxNum) {
		this.maxNum = maxNum;
	}

	public String getBrdId() {
		return brdId;
	}

	public void setBrdId(String brdId) {
		this.brdId = brdId;
	}

	public String getWrtId() {
		return wrtId;
	}

	public void setWrtId(String wrtId) {
		this.wrtId = wrtId;
	}

	public String getWrtNo() {
		return wrtNo;
	}

	public void setWrtNo(String wrtNo) {
		this.wrtNo = wrtNo;
	}

	public String getTtlNm() {
		return ttlNm;
	}

	public void setTtlNm(String ttlNm) {
		this.ttlNm = ttlNm;
	}

	public String getBrdCt() {
		return brdCt;
	}

	public void setBrdCt(String brdCt) {
		this.brdCt = brdCt;
	}

	public String getRplYn() {
		return rplYn;
	}

	public void setRplYn(String rplYn) {
		this.rplYn = rplYn;
	}

	public String getRplPsnNo() {
		return rplPsnNo;
	}

	public void setRplPsnNo(String rplPsnNo) {
		this.rplPsnNo = rplPsnNo;
	}

	public String getHtsCn() {
		return htsCn;
	}

	public void setHtsCn(String htsCn) {
		this.htsCn = htsCn;
	}

	public String getUseYn() {
		return useYn;
	}

	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	public String getNticSttDd() {
		return nticSttDd;
	}

	public void setNticSttDd(String nticSttDd) {
		this.nticSttDd = nticSttDd;
	}

	public String getNticEdDd() {
		return nticEdDd;
	}

	public void setNticEdDd(String nticEdDd) {
		this.nticEdDd = nticEdDd;
	}

	public String getFstRgstUserId() {
		return fstRgstUserId;
	}

	public void setFstRgstUserId(String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}

	public String getFstRgstDt() {
		return fstRgstDt;
	}

	public void setFstRgstDt(String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}

	public String getLstUdtUserId() {
		return lstUdtUserId;
	}

	public void setLstUdtUserId(String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}

	public String getLstUdtDt() {
		return lstUdtDt;
	}

	public void setLstUdtDt(String lstUdtDt) {
		this.lstUdtDt = lstUdtDt;
	}

	public String getAtachFleId() {
		return atachFleId;
	}

	public void setAtachFleId(String atachFleId) {
		this.atachFleId = atachFleId;
	}

	public String getLangCd() {
		return langCd;
	}

	public void setLangCd(String langCd) {
		this.langCd = langCd;
	}

	public String getWrtNoDp() {
		return wrtNoDp;
	}

	public void setWrtNoDp(String wrtNoDp) {
		this.wrtNoDp = wrtNoDp;
	}

	public String getCalTye() {
		return calTye;
	}

	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}

	public String getRecntYn() {
		return recntYn;
	}

	public void setRecntYn(String recntYn) {
		this.recntYn = recntYn;
	}

	public String gethLstUdtDt() {
		return hLstUdtDt;
	}

	public void sethLstUdtDt(String hLstUdtDt) {
		this.hLstUdtDt = hLstUdtDt;
	}

	public String getgLstUdtDt() {
		return gLstUdtDt;
	}

	public void setgLstUdtDt(String gLstUdtDt) {
		this.gLstUdtDt = gLstUdtDt;
	}

	  
}