package afnid.cm.board.service;

import java.util.List;

/** 
 * This service interface is biz-class of board-management. <br>
 * 
 * @author Afghanistan National ID Card System Application Team 
 * @since 2011.05.30
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers				Revisions
 *   ---------			---------				----------
 *   2011.05.30  		MH Choung				Create
 *
 * </pre>
 */
public interface BrdService {
	
	
	/**
	 * Retrieves list of board. <br>
	 * 
	 * @param vo Input item for retrieving list of board(BrdVO).
	 * @return List Retrieve list of board
	 * @exception Exception
	 */
	List<BrdVO> searchListBrd(BrdVO vo) throws Exception;
	
	/**
	 * Retrieves total count of board-list. <br>
	 * @param vo Input item for retrieving total count list of board.(BrdVO)
	 * @return int Total Count of board List
	 * @exception Exception
	 */
	int searchListBrdTotCnt(BrdVO vo) throws Exception;	
	
	/**
	 * Register information of new board. <br>
	 * 
	 * @param vo Input item for registering new board(BrdVO).
	 * @return BrdVO Primary Key value of registered board
	 * @exception Exception
	 */
	BrdVO addBrd(BrdVO vo) throws Exception;	

	
	/**
	 * delete information of board. <br> but update  as 'N' for use_yn's value 
	 * 
	 * @param vo Input item for delete board(BrdVO).
	 * @exception Exception
	 */
	void removeBrd(BrdVO vo) throws Exception;
	
	
	/**
	 * Retrieves detail Information of board. <br>
	 * 
	 * @param vo Input item for retrieving detail information of board(BrdVO).
	 * @return BrdVO Retrieve detail information of board
	 * @exception Exception
	 */
	BrdVO searchBrd(BrdVO vo) throws Exception;

	/**
	 * Modifies information of board. <br>
	 * 
	 * @param vo Input item for modifying board(BrdVO).
	 * @exception Exception
	 */
	void modifyBrd(BrdVO vo) throws Exception;
	
	/**
	 * Retrieves recent notice . <br>
	 * 
	 * @param vo Input item for retrieving recent notice(int).
	 * @return String Retrieve recent notice
	 * @exception Exception
	 */
	int searchNticYn(int newNticRng) throws Exception;
	
	
}