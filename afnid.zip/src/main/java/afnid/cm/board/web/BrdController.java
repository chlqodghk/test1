package afnid.cm.board.web;
/** 
 * This Controller class processes request of code-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team 
 * @since 2011.04.10
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers         		Revisions
 *   2011.05.04  		MH Choung         		Create
 *
 * </pre>
 */
/* java API */
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;
import org.springmodules.validation.commons.DefaultBeanValidator;

import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.board.service.BrdService;
import afnid.cm.board.service.BrdVO;
import afnid.cm.cmm.service.FleMngService;
import afnid.cm.cmm.service.FleMngUtil;
import afnid.cm.cmm.service.FleVO;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;


@Controller
public class BrdController implements HandlerExceptionResolver{

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** Validator */
	@Autowired
	private DefaultBeanValidator beanValidator;
	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /** brdService */
	@Resource(name = "brdService")
    private BrdService brdService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
       
    @Resource(name = "FleMngService")
    private FleMngService fileMngService;

    @Resource(name = "fleMngUtil")
    private FleMngUtil fileUtil;
    
    /** lgService */
	@Resource(name = "lgService")
    private LgService lgService;
	
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object obj, Exception exception) 
    {
      return new ModelAndView("");
    }
  
    /**
     * Moved to list-screen of board. <br>
     * 
     * @param BrdVO Value-object of board to be parsed request(BrdVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/board/BrdList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/board/searchListBrdView.do")
    public String searchListBrdView(
    		@RequestParam(value="id" ,required=false) String id,
    		@ModelAttribute("brdVO") BrdVO brdVO,
    		ModelMap model)
            throws Exception { 

    	try {
        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
        	
        	lgService.addUserWrkLg(user.getUserId(), brdVO.getCurMnId());
        	
    		brdVO.setBrdSeqNo(id);
      		
    		model.addAttribute("isManager",   NidUserDetailsHelper.isManagerAuthor());
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "/cm/board/BrdList";

    }

    
    /**
     * Border list to inquire.. <br>
     * @param BrdVO Value-object of Board to be parsed request(BrdVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/board/BrdList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/board/searchListBrd.do")
    public String searchListBrd(    		
    		@ModelAttribute("brdVO") BrdVO brdVO,
    		ModelMap model)
            throws Exception { 

    	try {
    			
    		if("".equals(brdVO.getSearchKeyword6())){
    			brdVO.setSearchKeyword6("j");    			
    		}
    		
	    	// Retrieve
	    	/** list Paging Setting */
    		brdVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		brdVO.setPageSize(propertiesService.getInt("pageSize"));
	
	    	/** paging */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(brdVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(brdVO.getPageUnit());
			paginationInfo.setPageSize(brdVO.getPageSize());
	
			brdVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			brdVO.setLastIndex(paginationInfo.getLastRecordIndex());
			brdVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();    	    
    		model.addAttribute("langcd",user.getUseLangCd());
			
	        List<BrdVO> lstBoard = brdService.searchListBrd(brdVO);
	        model.addAttribute("lstBoard", lstBoard);
	
	        int totCnt = brdService.searchListBrdTotCnt(brdVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        model.addAttribute("isManager",   NidUserDetailsHelper.isManagerAuthor());
      
    	} catch (Exception e) {
			model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

        return "/cm/board/BrdList";    	

    }
    

    /**
     * Moved to registration-screen of Board. <br>
     * 
     * @param BrdVO Value-object of Board to be parsed request(BrdVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return  Printed out JSP:  "/cm/board/BrdIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/board/addBrdView.do")
    public String addBrdView(  
    		@ModelAttribute("brdVO") BrdVO brdVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
	    try{
	    	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();  
	
			model.addAttribute("UserNm",user.getNm());
			 

			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}		
    	
		return "/cm/board/BrdIns"; 	
		
    }    
    
    /**
     * Register information of new Board. <br>
     * @param BrdVOs Value-object of Board to be parsed request(BrdVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/board/BrdDtl.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/board/addBrd.do")
    public String addBrd(    	
    		final MultipartHttpServletRequest multiRequest, 
    		@ModelAttribute("brdVOs") BrdVO brdVOs,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception {
    		
    	try {
    		BrdVO brdVO = brdVOs;
    		beanValidator.validate(brdVO, bindingResult); // Input Items Validation Check
    		
			if (bindingResult.hasErrors()){ // Validation Check err
				return "forward:/cm/board/addBrdView.do";  //Occurrence  Error  goto insert view.
			}
			
			 @SuppressWarnings("unchecked")
			final Map<String, MultipartFile> files = multiRequest.getFileMap();
			 
		    if (!files.isEmpty()) {
		    	List<FleVO> result = fileUtil.parseFileInfr(files, "BBS_",  brdVO.getBrdSeqNo());
		    	String flePrptSeqNo = fileMngService.addFileInfr(result); // file insert
		    	brdVO.setFlePrptSeqNo(flePrptSeqNo);
		    }
		    
		    brdService.addBrd(brdVO); // insert Interface call	     

	    	model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); //if save success then Message Setting
    	} catch (Exception e) {
    	
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    	return "forward:/cm/board/searchListBrd.do";
    	
    }    
    
    
    /**
     * Delete  infromation of Board  <br>
     * 
     * @param BrdVO Value-object of board to be parsed request(BrdVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/board/BrdList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/board/removeBrd.do")
    String removeBrd(
    		@ModelAttribute("brdVO") BrdVO brdVO,			
			ModelMap model)
            throws Exception { 
    	try {
	    				
	    	brdService.removeBrd(brdVO); // update Interface Call    	
	    	model.addAttribute("resultMsg", nidMessageSource.getMessage("datDltScsfl.msg")); //If succeed to save Message Setting
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
		return "forward:/cm/board/searchListBrd.do" ; 
    } 
    
    
    /**
     * Moved to modification-screen of Board. <br>
     * @param BrdVO Value-object of Board to be parsed request(BrdVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/board/BrdUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/board/modifyBrdView.do")
    public String modifyBrdView(
    		@ModelAttribute("brdVO") BrdVO brdVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	
    	try {
    		
    		BrdVO vo = brdService.searchBrd(brdVO);
    		
    		int num = fileMngService.searchListFileInfrTotCnt(vo.getFlePrptSeqNo());
    		
    		vo.setSearchKeyword5(String.valueOf(num));    		
	        model.addAttribute("VO", vo); 
			    		    	
    		if( (vo != null && vo.getFlePrptSeqNo() !=null) || (vo != null && vo.getFlePrptSeqNo() != null && !"".equals(vo.getFlePrptSeqNo()) )){
    			FleVO fvo = new FleVO();
	    		fvo.setFlePrptSeqNo(vo.getFlePrptSeqNo());
	    		model.addAttribute("fileList",  fileMngService.searchFileList(fvo));    		
    		}
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
        return "/cm/board/BrdUdt"; 

    }  
    
    /**
     * Modifies information of Board. <br>
     * @param BrdVO Value-object of Board to be parsed request(BrdVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/board/BrdList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/board/modifyBrd.do")
    public String modifyBrd(
    		final MultipartHttpServletRequest multiRequest, 
    		@ModelAttribute("brdVO") BrdVO brdVO,
    		@ModelAttribute("fileVO") FleVO fvo,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	try {
	    	beanValidator.validate(brdVO, bindingResult); // Input Items Validation Check
			if (bindingResult.hasErrors()){ // Validation Check error
	            return "/cm/board/BrdUdt"; //Error move upd interface.
			}
			@SuppressWarnings("unchecked")
			final Map<String, MultipartFile> files = multiRequest.getFileMap();
			
			fileMngService.removeFileInfr(brdVO);
			
			if (!files.isEmpty()) {
				List<FleVO> result = fileUtil.parseFileInfr(files, "BBS_",  brdVO.getBrdSeqNo(), brdVO.getFlePrptSeqNo());
				
				String flePrptSeqNo = fileMngService.addFileInfr(result);
				brdVO.setFlePrptSeqNo(flePrptSeqNo);
		    }

	    	brdService.modifyBrd(brdVO); // update Interface Call    	
	    	model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); //If succeed to save Message Setting
	    	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
		return "forward:/cm/board/searchListBrd.do"; 
    }  
    
    /**
     * this function is able to download attached files.
     * 
     * @param commandMap
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/cm/board/FileDown.do")
    public void FileDownload(Map<String, Object> commandMap, HttpServletResponse response) throws Exception {

		String flePrptSeqNo = (String)commandMap.get("flePrptSeqNo");
		String fleSeqNo = (String)commandMap.get("fleSeqNo");

		FleVO fileVO = new FleVO();
	    fileVO.setFlePrptSeqNo(flePrptSeqNo);
	    fileVO.setFleSeqNo(fleSeqNo);
	    FleVO fvo = fileMngService.searchDownFileInfr(fileVO);

	    File uFile = new File(fvo.getFlePthCt(), fvo.getFleNm());
	    int fSize = (int)uFile.length();

	    if (fSize > 0) {
			BufferedInputStream in = new BufferedInputStream(new FileInputStream(uFile));
	
			String mimetype = "application/x-msdownload";
	
			response.setBufferSize(fSize);
			response.setContentType(mimetype);
			
			response.setCharacterEncoding("UTF-8");
			response.setHeader("Content-Disposition", "attachment; filename=\"" + new String(fvo.getOrgnlFleNm().getBytes("EUC-KR"), "8859_1") + "\"");
			response.setContentLength(fSize);
	
			FileCopyUtils.copy(in, response.getOutputStream());
			in.close();
			response.getOutputStream().flush();
			response.getOutputStream().close();
		    } else {
			response.setContentType("application/x-msdownload");
			PrintWriter printwriter = response.getWriter();
			printwriter.println("<html>");
			printwriter.println("<script>"  );
			printwriter.println("alert( 'You can't download the Attached File ["+ fvo.getOrgnlFleNm() );
			printwriter.println(" ].  \n Ask System Administrator about This Situation!!');");
			printwriter.println("</scrpt>");
			printwriter.println("</html>");
			printwriter.flush();
			printwriter.close();
	    }	
    }



    /**
     * Notice the pop-up list to inquire. <br>
     * @param BrdVO Value-object of Board to be parsed request(BrdVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/board/p_BrdList"
     * @exception Exception
     */
    @RequestMapping(value="/cm/board/p_searchListBrd.do")
    public String p_searchListBrd(    		
    		@ModelAttribute("brdVO") BrdVO brdVO,
    		ModelMap model)
            throws Exception { 

    	try {
    	
    		if("".equals(brdVO.getSearchKeyword6())){
    			brdVO.setSearchKeyword6("j");    			
    		}
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();  
    		NidUserDetailsHelper.changeNticYnSet("N");
	    	// Retrieve
	    	/** list Paging Setting */
    		brdVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		brdVO.setPageSize(propertiesService.getInt("pageSize"));
	
	    	/** paging */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(brdVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(brdVO.getPageUnit());
			paginationInfo.setPageSize(brdVO.getPageSize());
			
			brdVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			brdVO.setLastIndex(paginationInfo.getLastRecordIndex());
			brdVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
   	    
    		model.addAttribute("langCd",user.getUseLangCd());
    		
    		brdVO.setSearchKeyword4("popupNotice");
    		if("".equals(brdVO.getSearchKeyword3())){
    			brdVO.setSearchKeyword3("2");
    		}
    		
    		List<BrdVO> lstBoard = brdService.searchListBrd(brdVO);
	        model.addAttribute("lstBoard", lstBoard);
			
	        int totCnt = brdService.searchListBrdTotCnt(brdVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        model.addAttribute("isManager",   NidUserDetailsHelper.isManagerAuthor());

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "/cm/board/p_BrdList";

    }
    
    /**
     * Retrieves detail Information of Board. <br>
     * 
     * @param BrdVO Value-object of Board to be parsed request(BrdVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:  "/cm/board/p_BrdDtl.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/board/p_searchBrdDtl.do")
    public String p_searchBoard(    		
    		@ModelAttribute("brdVO") BrdVO brdVO,
    		ModelMap model) 
            throws Exception {
    	try {
    		
    		BrdVO vo = brdService.searchBrd(brdVO);
    		
    		model.addAttribute("VO",vo ); // Retrieving data is Setting in the  ModelMap
			
    		if( (vo != null && vo.getFlePrptSeqNo() !=null) || (vo != null && vo.getFlePrptSeqNo() != null && !"".equals(vo.getFlePrptSeqNo()) )){
    			FleVO fvo = new FleVO();
	    		fvo.setFlePrptSeqNo(vo.getFlePrptSeqNo());
	    		model.addAttribute("fileList",  fileMngService.searchFileList(fvo));
    		
    		}
    		
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();    	    
    		model.addAttribute("langCd",user.getUseLangCd());
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/cm/board/p_BrdDtl";
    }


}