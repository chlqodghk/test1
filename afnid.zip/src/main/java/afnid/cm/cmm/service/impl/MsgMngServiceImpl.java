package afnid.cm.cmm.service.impl;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

import java.util.Calendar;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;

import afnid.cm.NidMessageSource;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidFleTool;
import afnid.cm.cmm.service.MsgMngService;
import afnid.cm.cmm.service.MsgMngVO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;




/** 
 * This service class is biz-class of message and label management
 * and implements NidAuthorManageService class.
 * 
 * @author Afghanistan National ID Card System Application Team  Moon Soo Kim
 * @since 2014.12.03
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2014.12.03 		Moon Soo Kim	      	 		Create
 *
 * </pre>
 */
@Service("msgMngService")
public  class MsgMngServiceImpl extends AbstractServiceImpl implements MsgMngService{
	
	@Resource(name="msgMngDAO")
    private MsgMngDAO msgMngDAO;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
	
    // File size 1K
    static final long BUFFER_SIZE     = 1024L;	
    // File separator
    static final char FILE_SEPARATOR     = File.separatorChar;
    
    /**
	 * Biz-method for retrieving list of message and label. <br>
	 * 
	 * @param vo Input item for retrieving list of message and label(MsgMngVO).
	 * @return List Retrieve list of message and label
	 * @exception Exception
	 */
	public List<MsgMngVO> searchListMsg(MsgMngVO vo) throws Exception {
   		return msgMngDAO.selectListMsg(vo);
	}
	/**
	 * Biz-method for retrieving total count list of message and label. <br>
	 * 
	 * @param vo Input item for retrieving list of message and label(MsgMngVO).
	 * @return int Total Count list of message and label
	 * @exception Exception
	 */
    public int searchListMsgTotCnt(MsgMngVO vo) throws Exception {
    	return msgMngDAO.selectListMsgTotCnt(vo);
	}


	
    /**
	 * Biz-method for retrieving detail Information of message and label. <br>
	 * 
	 * @param vo Input item for retrieving detail information of message and label(MsgMngVO).
	 * @return AthrMngVO Retrieve detail information of message and label
	 * @exception Exception
	 */
	public MsgMngVO searchMsg(MsgMngVO vo) throws Exception{
    	return (MsgMngVO)msgMngDAO.selectMsg(vo);
	}
	
	/**
	 * Biz-method for modifying information of message and label. <br>
	 * 
	 * @param vo Input item for modifying message and label(MsgMngVO).
	 * @exception Exception
	 */
	public void modifyMsg(MsgMngVO vo) throws Exception {
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUserId(user.getUserId());
		
		msgMngDAO.updateMsg(vo);
	}

	/**
	 * Biz-method for generate information of message and label. <br>
	 * 
	 * @param vo Input item for generate message and label(MsgMngVO).
	 * @exception Exception
	 */
	public void addMsg(MsgMngVO vo) throws Exception {

		Calendar cal=Calendar.getInstance();
		
		String y= Integer.toString(cal.get(Calendar.YEAR));
		String m= Integer.toString(cal.get(Calendar.MONTH)+1);
		String d= Integer.toString(cal.get(Calendar.DATE));
		String h= Integer.toString(cal.get(Calendar.HOUR));
		String mi= Integer.toString(cal.get(Calendar.MINUTE));
		String s= Integer.toString(cal.get(Calendar.SECOND));
		String currentDate = y+"_"+m+"_"+d+"_"+h+"_"+mi+"_"+s;

		String msgDir=propertiesService.getString("msgDir");
		String msgDirBak=propertiesService.getString("msgDirBak");
		
		String source="";
		String target="";
		String fleNm1="message-afnid_ps.properties";
		String fleNm2="message-afnid_dr.properties";
		String fleNm3="message-afnid_en.properties";
		String rpotFleNm1="message-report_ps.properties";
		String rpotFleNm2="message-report_dr.properties";
		String rpotFleNm3="message-report_en.properties";
		
		/*
		FileOutputStream fos1 = null;
		FileOutputStream fos2 = null;
		FileOutputStream fos3 = null;
		
		FileOutputStream fos4 = null;
		FileOutputStream fos5 = null;
		FileOutputStream fos6 = null;
		*/
		BufferedWriter writer1=null;
		BufferedWriter writer2=null;
		BufferedWriter writer3=null;
		
		BufferedWriter writer4=null;
		BufferedWriter writer5=null;
		BufferedWriter writer6=null;
		
		try{

			source=msgDir+File.separator+fleNm1;
			target=msgDirBak+File.separator+fleNm1+"_"+currentDate;
			log.debug("===========================================================");
			log.debug("source1 : " + source);
			log.debug("target1 : " + target);
			log.debug("===========================================================");
			NidFleTool.copyFile(source, target);
			
			source=msgDir+File.separator+fleNm2;
			target=msgDirBak+File.separator+fleNm2+"_"+currentDate;
			log.debug("===========================================================");
			log.debug("source2 : " + source);
			log.debug("target2 : " + target);
			log.debug("===========================================================");
			copyFile(source, target);
			
			source=msgDir+File.separator+fleNm3;
			target=msgDirBak+File.separator+fleNm3+"_"+currentDate;
			log.debug("===========================================================");
			log.debug("source3 : " + source);
			log.debug("target3 : " + target);
			log.debug("===========================================================");
			copyFile(source, target);		
			
			source=msgDir+File.separator+rpotFleNm1;
			target=msgDirBak+File.separator+rpotFleNm1+"_"+currentDate;
			log.debug("===========================================================");
			log.debug("source4 : " + source);
			log.debug("target4 : " + target);
			log.debug("===========================================================");
			copyFile(source, target);
			
			source=msgDir+File.separator+rpotFleNm2;
			target=msgDirBak+File.separator+rpotFleNm2+"_"+currentDate;
			log.debug("===========================================================");
			log.debug("source5 : " + source);
			log.debug("target5 : " + target);
			log.debug("===========================================================");
			copyFile(source, target);
			
			source=msgDir+File.separator+rpotFleNm3;
			target=msgDirBak+File.separator+rpotFleNm3+"_"+currentDate;
			log.debug("===========================================================");
			log.debug("source6 : " + source);
			log.debug("target6 : " + target);
			log.debug("===========================================================");
			copyFile(source, target);

			
			//generate message file
			List <MsgMngVO>  lstMsg = msgMngDAO.selectListMsgAll(vo);
			
			
			File file1 = new File(msgDir+File.separator+fleNm1);
			File file2 = new File(msgDir+File.separator+fleNm2);
			File file3 = new File(msgDir+File.separator+fleNm3);
			
			File file4 = new File(msgDir+File.separator+rpotFleNm1);
			File file5 = new File(msgDir+File.separator+rpotFleNm2);
			File file6 = new File(msgDir+File.separator+rpotFleNm3);			


			writer1 = new BufferedWriter(new FileWriter(file1));			
			writer2 = new BufferedWriter(new FileWriter(file2));
			writer3 = new BufferedWriter(new FileWriter(file3));
			
			writer4 = new BufferedWriter(new FileWriter(file4));			
			writer5 = new BufferedWriter(new FileWriter(file5));
			writer6 = new BufferedWriter(new FileWriter(file6));
			
			MsgMngVO  msgMngVO = new MsgMngVO();
			String psMsgTlt = "";
			String psMsg = "";
			String drMsgTlt = "";
			String drMsg  = "";
			String enMsgTlt = "";
			String enMsg  = "";

			String psMsgRpotTlt = "";
			String psMsgRpot = "";
			String drMsgRpotTlt = "";
			String drMsgRpot  = "";
			String enMsgRpotTlt = "";
			String enMsgRopt  = "";
			

			StringBuffer psMsgBuf = new StringBuffer();
			StringBuffer drMsgBuf = new StringBuffer();
			StringBuffer enMsgBuf = new StringBuffer();
			
			StringBuffer psMsgRoptBuf = new StringBuffer();
			StringBuffer drMsgRoptBuf = new StringBuffer();
			StringBuffer enMsgRoptBuf = new StringBuffer();
			
			String psMsgStr  = "";
			String drMsgStr  = "";
			String enMsgStr  = "";
			
			String psMsgRpotStr  = "";
			String drMsgRpotStr  = "";
			String enMsgRoptStr  = "";
			
			int lstCnt = lstMsg.size();
			
			char chr = 0;
			String cvrtStr="";

			log.debug("==========================================================================");
			log.debug("message count : " + lstCnt);
			log.debug("==========================================================================");
			for(int i=0; i<lstCnt; i++){
				msgMngVO = lstMsg.get(i);				
				log.debug("==========================================================================");
				log.debug("processing  no : " + msgMngVO.getMsgSeqNo() + " message id :  " + msgMngVO.getMsgId());
				log.debug("==========================================================================");				
				if( "1".equals(msgMngVO.getMsgFleCd()) ){
					psMsgTlt = msgMngVO.getMsgId() + "=";					
					psMsg = msgMngVO.getPstMsg();
					if (psMsg == null){psMsg="";}
					
					drMsgTlt = msgMngVO.getMsgId() + "=";
					drMsg = msgMngVO.getDrMsg();
					if (drMsg == null){drMsg="";}
					
					enMsgTlt = msgMngVO.getMsgId() + "=";
					enMsg = msgMngVO.getEnMsg();
					if (enMsg == null){enMsg="";}

					log.debug("===========================================================");
					log.debug("pstMsgTlt : " + psMsgTlt + "  ---  pstMsg : " + psMsg + "length : " + psMsg.length());
					log.debug("drMsgTlt  : " + drMsgTlt + "  ---  pstMsg : " + drMsg + "length : " + drMsg.length());
					log.debug("enMsgTlt  : " + enMsgTlt + "  ---  pstMsg : " + enMsg + "length : " + enMsg.length());
					log.debug("===========================================================");

					for(int j =0; j< psMsg.length() ; j++){
						chr = psMsg.charAt(j);
						cvrtStr = String.valueOf(chr);
					
					    if(31 < chr  && chr< 127){
					    	psMsgBuf.append(cvrtStr);
					    } else {					    	
					    	psMsgBuf.append("\\u"+String.format("%04X" , cvrtStr.codePointAt(0)).toString() );
					    }
				    }

					for(int j =0; j< drMsg.length() ; j++){
						chr = drMsg.charAt(j);
						cvrtStr = String.valueOf(chr);	
					    
						if(31 < chr  && chr< 127){
					    	drMsgBuf.append(cvrtStr);
					    } else {					    	
					    	drMsgBuf.append("\\u"+String.format("%04X" , cvrtStr.codePointAt(0)).toString() );
					    }
				    }
				
					for(int j =0; j< enMsg.length() ; j++){						
						chr = enMsg.charAt(j);
						cvrtStr = String.valueOf(chr);	
					  
					    if(31 < chr  && chr< 127){
					    	enMsgBuf.append(cvrtStr);
					    } else {					    	
					    	enMsgBuf.append( "\\u"+String.format("%04X" , cvrtStr.codePointAt(0)).toString() );
					    }	
				    }					

					psMsgStr = psMsgBuf.toString();
					drMsgStr = drMsgBuf.toString();
					enMsgStr = enMsgBuf.toString();
					
					log.debug("===========================================================");
					log.debug("psMsgStr : " + psMsgStr);
					log.debug("drMsgStr : " + drMsgStr);
					log.debug("enMsgStr : " + enMsgStr);
					log.debug("===========================================================");
					
					psMsgBuf.setLength(0);
					drMsgBuf.setLength(0);
					enMsgBuf.setLength(0);
														
					writer1.write(psMsgTlt+psMsgStr);
					writer1.newLine();
					
					writer2.write(drMsgTlt+drMsgStr);
					writer2.newLine();
					
					writer3.write(enMsgTlt+enMsgStr);
					writer3.newLine();					
					
					writer1.flush();
					writer2.flush();
					writer3.flush();
					
					psMsgStr = "";
					drMsgStr = "";
					enMsgStr = "";
					
				} else if( "2".equals(msgMngVO.getMsgFleCd()) ){

					psMsgRpotTlt = msgMngVO.getMsgId() + "=";
					psMsgRpot = msgMngVO.getPstMsg();
					if (psMsgRpot == null){psMsgRpot="";}
					
					drMsgRpotTlt = msgMngVO.getMsgId() + "=";
					drMsgRpot = msgMngVO.getDrMsg();
					if (drMsgRpot == null){drMsgRpot="";}
					
					enMsgRpotTlt = msgMngVO.getMsgId() + "=";
					enMsgRopt = msgMngVO.getEnMsg();
					if (enMsgRopt == null){enMsgRopt="";}
					
					log.debug("===========================================================");
					log.debug("psMsgRpotTlt  : " + psMsgRpotTlt + "  ---  psMsgRpot : " + psMsgRpot);
					log.debug("drMsgRpotTlt  : " + drMsgRpotTlt + "  ---  drMsgRpot : " + drMsgRpot);
					log.debug("enMsgRpotTlt  : " + enMsgRpotTlt + "  ---  enMsgRopt : " + enMsgRopt);
					log.debug("===========================================================");

					for(int j =0; j< psMsgRpot.length() ; j++){
						chr = psMsgRpot.charAt(j);
						cvrtStr = String.valueOf(chr);	
					    
						if(31 < chr  && chr< 127){
					    	psMsgRoptBuf.append(cvrtStr);
					    } else {					    	
					    	psMsgRoptBuf.append("\\u"+String.format("%04X" , cvrtStr.codePointAt(0)).toString() );
					    }
				    }
					
					for(int j =0; j< drMsgRpot.length() ; j++){
						chr = drMsgRpot.charAt(j);
						cvrtStr = String.valueOf(chr);	
					    
						if(31 < chr  && chr< 127){
					    	drMsgRoptBuf.append(cvrtStr);
					    } else {					    	
					    	drMsgRoptBuf.append("\\u"+String.format("%04X" , cvrtStr.codePointAt(0)).toString() );
					    }						
				    }
						
					for(int j =0; j< enMsgRopt.length() ; j++){
						chr = enMsgRopt.charAt(j);
						cvrtStr = String.valueOf(chr);	
					    
					    if(31 < chr  && chr< 127){
					    	enMsgRoptBuf.append(cvrtStr);
					    } else {					    	
					    	enMsgRoptBuf.append( "\\u"+String.format("%04X" , cvrtStr.codePointAt(0)).toString() );
					    }						
				    }

					psMsgRpotStr = psMsgRoptBuf.toString();
					drMsgRpotStr = drMsgRoptBuf.toString();
					enMsgRoptStr = enMsgRoptBuf.toString();
			
					
					log.debug("===========================================================");
					log.debug("psMsgRpotStr : " + psMsgRpotStr);
					log.debug("drMsgRpotStr : " + drMsgRpotStr);
					log.debug("enMsgRoptStr : " + enMsgRoptStr);
					log.debug("===========================================================");
					
					psMsgRoptBuf.setLength(0);
					drMsgRoptBuf.setLength(0);
					enMsgRoptBuf.setLength(0);

					writer4.write(psMsgRpotTlt+psMsgRpotStr);
					writer4.newLine();
					
					writer5.write(drMsgRpotTlt+drMsgRpotStr);
					writer5.newLine();
					
					writer6.write(enMsgRpotTlt+enMsgRoptStr);
					writer6.newLine();
					
					writer4.flush();
					writer5.flush();
					writer6.flush();
					
					psMsgRpotStr = "";
					drMsgRpotStr = "";
					enMsgRoptStr = "";					
				}				
				
			}

		} catch(Exception e){
			log.debug(e.getMessage());
		} finally{
			writer1.close();
			writer2.close();
			writer3.close();
			writer4.close();
			writer5.close();
			writer6.close();		
		}
	}

	
    public static boolean copyFile(String source, String target) throws Exception {
        
        // Copy Status
        boolean result = false;        
        
        // The original file
        String src = source.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File srcFile = new File(src);
        
        // Target file
        String tar = target.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        
        try {
            // Make sure the original file exists.
            if (srcFile.exists()) {                
                
                // Create the target file to be copied.
                tar = createNewFile(tar);
                //log.debug("tar:"+tar);
                File tarFile = new File(tar);
                //log.debug("tarFile:"+tarFile.getAbsolutePath());
                // Radiation
                result = execCopyFile(srcFile, tarFile);
                
            }
            
        } catch (IOException ex){
        	ex.getMessage();
        }
        
        return result;
    }	
    
    
    /**
     * <pre>
     * Comment : File is created.
     * </pre>
     * @param String fileName 
     * @param String content   ex) c:/test/test1/test44.txt
     *
     */
    public  static String createNewFile(String filePath){
      
        // Argument is invalid, return blank.
        if (filePath==null || filePath.equals("")){
            return "";
        }
        
        File file = new File(filePath);
        String result = "";
        try{
            if(file.exists()){
                   result = filePath;
            }else{
                // That does not exist, create.
                new File(file.getParent()).mkdirs();
                if(file.createNewFile()){
                    result = file.getAbsolutePath();
                }
            }
        }catch (Exception e){
        	e.getMessage();
        }
       
        return result;
    }
    
    /**
     * The ability to perform the copy.
     * @param File srcFile The original file
     * @param File tarFile The target file
     * @return boolean result Copy Status True / False
     * @exception Exception
    */
    /*
   public static boolean execCopyFile(File srcFile, File tarFile) throws Exception {
        
        // result
        boolean result = false;
        BufferedReader fis =null;
        BufferedWriter fos =null;
        try {
            // Copy Status
            fis = new BufferedReader(new InputStreamReader(new FileInputStream(srcFile))); 
            
            File tarFile1 = tarFile;
            if(tarFile1.isDirectory()){
            	tarFile1 = new File(tarFile1.getAbsolutePath()+"/"+srcFile.getName());
            }
            
            fos = new BufferedWriter(new FileWriter(tarFile1));

            int i =0;
            
            if (fis != null && fos != null) {
            	while ((i=fis.read()) != -1) {
            		fos.write(i);
                }
            }

            result = true;
        } catch (Exception ex) {
        	ex.getMessage();
        } finally {
        	if (fis != null) fis.close();
            if (fos != null) fos.close();
        }
        
        
        return result;
    }
   
   */

    public static boolean execCopyFile(File srcFile, File tarFile) throws Exception {
        
        // result
        boolean result = false;
        FileInputStream fis = null;
        FileOutputStream fos = null;
        try {
            // Copy Status
            fis = new FileInputStream(srcFile); 
            
            //Added by exception processing. -> If you master tarFile this directory beneath the directory and copy the newly created file.. like DOS
            File tarFile1 = tarFile;
            if(tarFile1.isDirectory()){
            	tarFile1 = new File(tarFile1.getAbsolutePath()+"/"+srcFile.getName());
            }
            fos = new FileOutputStream(tarFile1); 
            byte [] buffer = new byte[(int)BUFFER_SIZE];
            int i = 0;
            if (fis != null && fos != null) {
            	while ((i = fis.read(buffer)) != -1) {
                    fos.write(buffer, 0, i);
                }
            }
            
            result = true;
        } catch (Exception ex) {
        	ex.getMessage();
        } finally {
        	if (fis != null) fis.close();
            if (fos != null) fos.close();
        }
        
        
        return result;
    }    
}
