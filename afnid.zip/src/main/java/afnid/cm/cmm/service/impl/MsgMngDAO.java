package afnid.cm.cmm.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import afnid.cm.cmm.service.MsgMngVO;


/** 
 * This class is Database Access Object of message and label management
 * 
 * @author Afghanistan National ID Card System Application Team Moon Soo Kim
 * @since 2014.12.23
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2014.12.23 		Moon Soo Kim      		 		Create
 *
 * </pre>
 */
@Repository("msgMngDAO")
public class MsgMngDAO extends EgovAbstractDAO{
	
	/**
	 * DAO-method for retrieving list Information of message and label. <br>
	 * 
	 * @param vo Input item for retrieving list information of message and label(MsgMngVO).
	 * @return AthrMngVO Retrieve list information of message and label
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<MsgMngVO> selectListMsg(MsgMngVO vo) throws Exception{
		return list("msgMngDAO.selectListMsg", vo);
	}
	
	/**
	 * DAO-method for retrieving total count list of message and label. <br>
	 * 
	 * @param vo Input item for retrieving list of message and label(MsgMngVO).
	 * @return int Total Count list of message and label
	 * @exception Exception
	 */
    public int selectListMsgTotCnt(MsgMngVO vo) {
        return (Integer)selectByPk("msgMngDAO.selectListMsgTotCnt", vo);
    }

	
    /**
	 * DAO-method for retrieving detail Information of message and label. <br>
	 * 
	 * @param vo Input item for retrieving detail information of message and label(MsgMngVO).
	 * @return AuthorManageVO Retrieve detail information of message and label
	 * @exception Exception
	 */
	public MsgMngVO selectMsg(MsgMngVO vo)throws Exception{
		return (MsgMngVO)selectByPk("msgMngDAO.selectMsg", vo); 
	}
	
	/**
	 * DAO-method for modifying information of message and label. <br>
	 * 
	 * @param vo Input item for modifying information of message and label(MsgMngVO).
	 * @exception Exception
	 */
	public void updateMsg(MsgMngVO vo){
		update("msgMngDAO.updateMsg", vo);
	}
	
	/**
	 * DAO-method for retrieving total list Information of message and label. <br>
	 * 
	 * @param vo Input item for retrieving list information of message and label(MsgMngVO).
	 * @return AthrMngVO Retrieve list information of message and label
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<MsgMngVO> selectListMsgAll(MsgMngVO vo) throws Exception{
		return list("msgMngDAO.selectListMsgAll", vo);
	}	
}
