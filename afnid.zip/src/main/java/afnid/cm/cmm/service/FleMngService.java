package afnid.cm.cmm.service;

import java.util.List;

import afnid.cm.board.service.BrdVO;
import afnid.cm.uat.service.LgnVO;

/**
 * @Class Name : NidFileMngService.java
 * @Description : File information for the management of service interfaces
 * @Modification Information
 *
 *    Modified       Modifiers         Revisions
 *    -------        -------     -------------------
 *    2009. 3. 25.     Yisamseop    The first generation
 *
 * @author Common Services team yisamseop
 * @since 2009. 3. 25.
 * @version
 * @see
 *
 */
public interface FleMngService {

	
    /**
     * get file  sequence number.
     * 
     * 
     */
    public int getFlePrptSeqNo(LgnVO key) throws Exception;
    

    /**
     * Information on multiple files (attributes and details) registers.
     * 
     * @param fvoList
     * @throws Exception
     */
    @SuppressWarnings("rawtypes")
	public String addFileInfr(List fvoList) throws Exception;    
    
    /**
     * retrieving total count of attached file
     * 
     * @param atachFleId
     * @return
     * @throws Exception
     */
    public int searchListFileInfrTotCnt(String atachFleId) throws Exception;   
    
    /**
     * Retrieves a list of attached files.
     * 
     * @param fvo
     * @return
     * @throws Exception
     */
    public List<FleVO> searchFileList(FleVO fvo) throws Exception;
    
    
    /**
     * download attached file.
     * 
     * @param fvo
     * @return
     * @throws Exception
     */
    public FleVO searchDownFileInfr(FleVO fvo) throws Exception;    
    
    
    
    /**
     * delete information of attached file
     * 
     * @param fvo
     * @return
     * @throws Exception    
     */    
    public void removeFileInfr(BrdVO fvo) throws Exception;
    


}
