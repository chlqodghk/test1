package afnid.cm.cmm.service.impl;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import afnid.cm.cmm.service.FleVO;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/**
 * @Class Name : FileManageDAO.java
 * @Description : Data processing class for Information Management
 * @Modification Information
 *
 *    Modified       Modifiers         Modifications
 *    -------        -------     -------------------
 *    2009. 3. 25.     Yisamseop    The first generation
 *
 * @author Common Services team yisamseop
 * @since 2009. 3. 25.
 * @version
 * @see
 *
 */
@Repository("FleMngDAO")
public class FleMngDAO extends EgovAbstractDAO {

    Logger log = Logger.getLogger(this.getClass());

    
    /**
     * get file  sequence number
     * 
     * @param fvo
     * @throws Exception
     */
    public int  getFlePrptSeqNo(LgnVO key) throws Exception {
    	 return (Integer)selectByPk("FleMngDAO.getFlePrptSeqNo", key);
    }
    
    /**
     * Information on multiple files (attributes and details) registers.
     * 
     * @param fileList
     * @return
     * @throws Exception
     */
    @SuppressWarnings("rawtypes")
	public String insertFileInfr(List fileList) throws Exception {
    	FleVO vo = (FleVO)fileList.get(0);
		String flePrptSeqNo = vo.getFlePrptSeqNo();
		
		int fvo = (Integer)selectByPk("FleMngDAO.selectFileListTotCnt", vo);
		 
		if (fvo == 0){
			 insert("FleMngDAO.insertFileMaster", vo);
		}
		 
		Iterator iter = fileList.iterator();
		
		while (iter.hasNext()) {
		    vo = (FleVO)iter.next();
		    
		    insert("FleMngDAO.insertFileDetail", vo);
		}
		
		return flePrptSeqNo;
    }
    
    /**
	 * DAO-method for total count of attached file <br>
	 * 
	 * @param vo Input item for retrieving list of board(BoardVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListFileInfrTotCnt(String flePrptSeqNo) {
        return (Integer)selectByPk("FleMngDAO.selectListFileInfrTotCnt", flePrptSeqNo);
    }
    
    /**
     * Retrieves a list of attached files.
     * 
     * @param vo
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    public List<FleVO> selectFileList(FleVO vo) throws Exception {
    	return list("FleMngDAO.selectFileList", vo);
    }
    
    /**
     * download attached file.
     * 
     * @param fvo
     * @return
     * @throws Exception
     */
    public FleVO selectDownFileInfr(FleVO fvo) throws Exception {
    	return (FleVO)selectByPk("FleMngDAO.selectDownFileInfr", fvo);
    }    
    
    /**
     *delete information of attached file
     * 
     * @param fvo
     * @throws Exception
     */
    public void deleteFileInfr(FleVO fvo) throws Exception {
    	update("FleMngDAO.deleteFileDetail", fvo);
    }
       
 

}
