package afnid.cm.cmm.service;

import afnid.cm.ComDefaultVO;

/** 
 * This service interface is biz-class of common. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.04.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2011.04.21  		Kyung Hwan HWANG				Create
 *
 * </pre>
 */
public interface NidCmmService {

	/**
	 * Add the days to current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	ComDefaultVO searchAddToDay(ComDefaultVO vo ) throws Exception;
	
	/**
	 * Add the days to current days(Gregorian). <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	ComDefaultVO searchAddToDay1(ComDefaultVO vo ) throws Exception;
	
	/**
	 * Add the days to current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	ComDefaultVO searchPerToDay(ComDefaultVO vo ) throws Exception;
	
	/**
	 * Add the days to current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	ComDefaultVO searchGreToDay(ComDefaultVO vo ) throws Exception;
	
	/**
	 * Add the days to current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	ComDefaultVO searchGreToDay1(ComDefaultVO vo ) throws Exception;
	
	/**
	 * Add the days to current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return String
	 * @exception Exception
	 */
	String searchDateTime(ComDefaultVO vo ) throws Exception;
	
	
	/**
	 * Add the days to Gregorian first days in month. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian first days in month(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to Gregorian first days in month
	 * @exception Exception
	 */
	ComDefaultVO searchGreMonFstDay(ComDefaultVO vo ) throws Exception;
	
	/**
	 * Add the days to Gregorian last days in month. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian last days in month(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to Gregorian last days in month
	 * @exception Exception
	 */
	ComDefaultVO searchGreMonLastDay(ComDefaultVO vo ) throws Exception;
	
	/**
	 * Add the days to persian first days in month. <br>
	 * 
	 * @param vo Input item for adding the days to persian first days in month(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to persian first days in month
	 * @exception Exception
	 */
	ComDefaultVO searchPreMonFstDay(ComDefaultVO vo ) throws Exception;
	
	/**
	 * Add the days to persian last days in month. <br>
	 * 
	 * @param vo Input item for adding the days to persian last days in month(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to persian last days in month
	 * @exception Exception
	 */
	ComDefaultVO searchPreMonLastDay(ComDefaultVO vo ) throws Exception;
	
	
	
	
	/**
	 * Add the days to Gregorian first days in week. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian first days in week(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to Gregorian first days in week
	 * @exception Exception
	 */
	ComDefaultVO searchGreWeekFstDay(ComDefaultVO vo ) throws Exception;
	
	/**
	 * Add the days to Gregorian last days in week. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian last days in week(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to Gregorian last days in week
	 * @exception Exception
	 */
	ComDefaultVO searchGreWeekLastDay(ComDefaultVO vo ) throws Exception;
	
	/**
	 * Add the days to persian first days in week. <br>
	 * 
	 * @param vo Input item for adding the days to persian first days in week(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to persian first days in week
	 * @exception Exception
	 */
	ComDefaultVO searchPreWeekFstDay(ComDefaultVO vo ) throws Exception;
	
	/**
	 * Add the days to persian last days in week. <br>
	 * 
	 * @param vo Input item for adding the days to persian last days in week(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to persian last days in week
	 * @exception Exception
	 */
	ComDefaultVO searchPreWeekLastDay(ComDefaultVO vo ) throws Exception;
	
	/**
	 * Add the Input days to current days. <br>
	 * 
	 * @param vo Input item for adding the Input days to current days.(ComDefaultVO).
	 * @return ComDefaultVO Adding the Input days to current days.
	 * @exception Exception
	 */
	ComDefaultVO searchGreAddingInputDay(ComDefaultVO vo ) throws Exception;
	
	/**
	 * 
	 * 
	 * @param string
	 * @return ComDefaultVO 
	 * @exception Exception
	 */
	ComDefaultVO searchPreBfAfMonDay(String mnth) throws Exception;
	
	/**
	 * 
	 * 
	 * @param string
	 * @return ComDefaultVO 
	 * @exception Exception
	 */
	ComDefaultVO searchGreBfAfMonDay(String mnth ) throws Exception;
	
	/**
	 * get current day and before/after any month day(Gregorian). <br>
	 * 
	 * @param vo Input item for get current day and before/after any month day(ComDefaultVO).
	 * @return ComDefaultVO 
	 * @exception Exception
	 */
	ComDefaultVO searchGreAddToDay(String mnth ) throws Exception;
	
	/**
	 * get current day and before/after any month day(Gregorian). <br>
	 * 
	 * @param vo Input item for get current day and before/after any month day(ComDefaultVO).
	 * @return ComDefaultVO 
	 * @exception Exception
	 */
	ComDefaultVO searchGreAddToDay1(String mnth ) throws Exception;
	
	/**
	 * get current day and before/after any month day(Perisian). <br>
	 * 
	 * @param vo Input item for get current day and before/after any month day(ComDefaultVO).
	 * @return ComDefaultVO 
	 * @exception Exception
	 */
	ComDefaultVO searchPreAddToDay(String mnth) throws Exception;	
	
	/**
	 *  get first day in year(Perisian). <br>
	 * 
	 * @param vo Input item for  get first day in year(ComDefaultVO).
	 * @return ComDefaultVO  first day in year
	 * @exception Exception
	 */
	ComDefaultVO searchPreYearFstDay(ComDefaultVO vo ) throws Exception;
	
	/**
	 *  get first day in year(Gregorian). <br>
	 * 
	 * @param vo Input item for  get first day in year(ComDefaultVO).
	 * @return ComDefaultVO  first day in year
	 * @exception Exception
	 */
	ComDefaultVO searchGreYearFstDay(ComDefaultVO vo ) throws Exception;
	
}
