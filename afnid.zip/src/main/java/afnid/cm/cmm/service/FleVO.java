package afnid.cm.cmm.service;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;



/**
 * @Class Name : FileVO.java
 * @Description : File information management 
  @author Afghanistan National ID Card System Application Team 
 * @since 2011.04.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers         	Revisions
 *   2011.04.21  		MH Choung         		Create
 *
 * </pre>
 *
 */
@SuppressWarnings("serial")
public class FleVO implements Serializable {

     
	
    /**ATTACHMENT FILE ID*/	         
	private  String    atachFleId;	
	
	private  String    wrtId;
	private  String    brdId;
	
	/**FILE NO*/	         
	private  String    fleNo;	
    /**ORIGINAL FILE NAME*/	         
	private  String    orgnlFleNm;	
    /**FILE PATH CONTENTS*/	         
	private  String    flePthCt;	
    /**FILE NAME*/	         
	private  String    fleNm;	
    /**FILE EXTENTION NAME*/	         
	private  String    fleExtnNm;	
    /**FILE DESCRIPTION*/	         
	private  String    fleDs;	
    /**FILE SIZE*/	         
	private  String    fleSz;	
	/**FST_RGST_DT*/	         
	private  String    fstRgstDt;	
	/**USE_YN*/	         
	private  String    useYn;	
	
	private	String userId;
	
	private String flePrptSeqNo;
	
	private String fleSeqNo;
	
	private String calTye;	
	
    /**
     * replaces the toString method.
     */
    public String toString() {
    	
	return ToStringBuilder.reflectionToString(this);
    }
    public String getAtachFleId() {
		return atachFleId;
	}

	public void setAtachFleId(String atachFleId) {
		this.atachFleId = atachFleId;
	}

	public String getFleNo() {
		return fleNo;
	}

	public void setFleNo(String fleNo) {
		this.fleNo = fleNo;
	}

	public String getOrgnlFleNm() {
		return orgnlFleNm;
	}

	public void setOrgnlFleNm(String orgnlFleNm) {
		this.orgnlFleNm = orgnlFleNm;
	}

	public String getFlePthCt() {
		return flePthCt;
	}

	public void setFlePthCt(String flePthCt) {
		this.flePthCt = flePthCt;
	}

	public String getFleNm() {
		return fleNm;
	}

	public void setFleNm(String fleNm) {
		this.fleNm = fleNm;
	}

	public String getFleExtnNm() {
		return fleExtnNm;
	}

	public void setFleExtnNm(String fleExtnNm) {
		this.fleExtnNm = fleExtnNm;
	}

	public String getFleDs() {
		return fleDs;
	}

	public void setFleDs(String fleDs) {
		this.fleDs = fleDs;
	}

	public String getFleSz() {
		return fleSz;
	}

	public void setFleSz(String fleSz) {
		this.fleSz = fleSz;
	}
	  public String getFstRgstDt() {
			return fstRgstDt;
	}
	public void setFstRgstDt(String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getWrtId() {
		return wrtId;
	}
	public void setWrtId(String wrtId) {
		this.wrtId = wrtId;
	}
	public String getBrdId() {
		return brdId;
	}
	public void setBrdId(String brdId) {
		this.brdId = brdId;
	}
	
	public String getFlePrptSeqNo() {
		return flePrptSeqNo;
	}
	public void setFlePrptSeqNo(String flePrptSeqNo) {
		this.flePrptSeqNo = flePrptSeqNo;
	}
	public String getFleSeqNo() {
		return fleSeqNo;
	}
	public void setFleSeqNo(String fleSeqNo) {
		this.fleSeqNo = fleSeqNo;
	}
	public String getCalTye() {
		return calTye;
	}
	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}
	
	
}
