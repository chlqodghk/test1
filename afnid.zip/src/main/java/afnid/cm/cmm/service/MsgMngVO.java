package afnid.cm.cmm.service;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of message and label
 * 
 * @author Afghanistan National ID Card System Application Team Moon Soo Kim
 * @since 2014.12.23
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2014.12.23 		Moon Soo Kim	  		 		Create
 *
 * </pre>
 */
public class MsgMngVO extends ComDefaultVO{
    private static final long serialVersionUID = 1L;

    private String msgSeqNo;
    private String msgFleCd;
    private String msgId;
    private String pstMsg;
    private String drMsg;
    private String enMsg;
    private String userId;
    
    
	public String getMsgSeqNo() {
		return msgSeqNo;
	}
	public void setMsgSeqNo(String msgSeqNo) {
		this.msgSeqNo = msgSeqNo;
	}
	public String getMsgFleCd() {
		return msgFleCd;
	}
	public void setMsgFleCd(String msgFleCd) {
		this.msgFleCd = msgFleCd;
	}
	public String getMsgId() {
		return msgId;
	}
	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}
	public String getPstMsg() {
		return pstMsg;
	}
	public void setPstMsg(String pstMsg) {
		this.pstMsg = pstMsg;
	}
	public String getDrMsg() {
		return drMsg;
	}
	public void setDrMsg(String drMsg) {
		this.drMsg = drMsg;
	}
	public String getEnMsg() {
		return enMsg;
	}
	public void setEnMsg(String enMsg) {
		this.enMsg = enMsg;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}

    
	
}
