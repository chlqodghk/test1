package afnid.cm.cmm.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Resource;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import egovframework.rte.fdl.property.EgovPropertyService;

/**
 * @Class Name  : EgovFileMngUtil.java
 * @Description : AttachFile Manage Utility
* @since 2011.04.10
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers         		Revisions
 *   2011.05.04  		MH Choung         		Create
 *
 * 
 */
@Component("fleMngUtil")
public class FleMngUtil {

    public static final int BUFF_SIZE = 2048;

    @Resource(name = "propertiesService")
    protected EgovPropertyService propertyService;

    @Resource(name = "FleMngService")
    private FleMngService fleMngService;
    
    Logger log = Logger.getLogger(this.getClass());
    
    /**
     * get information of attach Files.
     * 
     * @param files
     * @return
     * @throws Exception
     */
    public List<FleVO> parseFileInfr(Map<String, MultipartFile> files, String KeyStr,  String storePath) throws Exception {
      return	parseFileInfr(files, KeyStr,  storePath,"");
    }
    	
    public List<FleVO> parseFileInfr(Map<String, MultipartFile> files, String KeyStr,  String storePath, String fleId) throws Exception {
		
		String flePthCt = "";
		String flePrptSeqNo ;
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		if("".equals(fleId)){
			flePrptSeqNo = String.valueOf(fleMngService.getFlePrptSeqNo(user));
		}else{
			flePrptSeqNo = fleId;
		}

		if ("".equals(storePath) || storePath == null) {
			flePthCt = propertyService.getString("filepath");
		} else {
		    //storePathString = propertyService.getString(storePath);
			flePthCt= propertyService.getString("filepath")+"/"+storePath;
		}
	
		File saveFolder = new File(flePthCt);
		
		if (!saveFolder.exists() || saveFolder.isFile()) {
		    saveFolder.mkdirs();
		}
	
		Iterator<Entry<String, MultipartFile>> itr = files.entrySet().iterator();
		MultipartFile file;
		
		List<FleVO> result  = new ArrayList<FleVO>();
		FleVO fvo;
		int fileKey= 0;
		while (itr.hasNext()) {
		    Entry<String, MultipartFile> entry = itr.next();
	
		    file = entry.getValue();
		    String orgnlFleNm = file.getOriginalFilename();
		    
		    //--------------------------------------
		    // case: no original file names
		    // (don't attached file from input file type)
		    //--------------------------------------
		    if ("".equals(orgnlFleNm)) {
			continue;
		    }
		    ////------------------------------------
	
		    int index = orgnlFleNm.lastIndexOf(".");
		    //String fileName = orginFileName.substring(0, index);
		    String fleExtnNm = orgnlFleNm.substring(index + 1);
		    String fleNm = KeyStr + NidStringUtil.getTimeStamp() + fileKey;
		    long _size = file.getSize();
	
		   
			
			//file.transferTo(new File(flePthCt));
		    
		    fvo = getObjectVO();
		    fvo.setFleExtnNm(fleExtnNm);
		    fvo.setFlePthCt(flePthCt);
		    fvo.setFleSz(Long.toString(_size));
		    fvo.setOrgnlFleNm(orgnlFleNm);
		    fvo.setFleNm(fleNm);
		    fvo.setFlePrptSeqNo(flePrptSeqNo);
		    fvo.setUserId(user.getUserId());
	
		    writeFile(file, fleNm, flePthCt);
		    result.add(fvo);
		    
		    fileKey++;
		}
	
		return result;
    }

    /**
     * create real path for put the attached files.
     * 
     * @param file
     * @param newName
     * @param stordFilePath
     * @throws Exception
     */
    protected static void writeFile(MultipartFile file, String newName, String stordFilePath) throws Exception {
		InputStream stream = null;
		OutputStream bos = null;
		
		try {
		    stream = file.getInputStream();
		    File cFile = new File(stordFilePath);
	
		    if (!cFile.isDirectory()){
		    	cFile.mkdir();
		    }
		    bos = new FileOutputStream(stordFilePath + File.separator + newName);
	
		    int bytesRead = 0;
		    byte[] buffer = new byte[BUFF_SIZE];
	
		    while (bytesRead != -1) {
		    	bytesRead = stream.read(buffer, 0, BUFF_SIZE);
		    	if(bytesRead != -1){
		    		bos.write(buffer, 0, bytesRead);
		        }
		    }
		} catch (FileNotFoundException fnfe) {
			debug(fnfe);
		} catch (IOException ioe) {
			debug(ioe);
		} catch (Exception e) {
			debug(e);
		} finally {
		    if (bos != null) {
				try {
				    bos.close();
				} catch (Exception ignore) {
				    Logger.getLogger(FleMngUtil.class).debug("IGNORED: " + ignore.getMessage());
				}
		    }
		    if (stream != null) {
				try {
				    stream.close();
				} catch (Exception ignore) {
				    Logger.getLogger(FleMngUtil.class).debug("IGNORED: " + ignore.getMessage());
				}
		    }
		}
    }

    
    /**
     * VO object files generated.
     * 
     * @param void
     * @return FileVO Object
     */
    private FleVO getObjectVO(){
    	return new FleVO();
    }
    
    /**
	 * 시스템 로그를 출력한다.
	 * @param obj Object
	 */	
	private static void debug(Object obj) {
		if (obj instanceof java.lang.Exception) {
			((Exception)obj).printStackTrace();
		}
	}
	
}
