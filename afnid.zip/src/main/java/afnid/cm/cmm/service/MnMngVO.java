package afnid.cm.cmm.service;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of Menu Name
 * 
 * @author Afghanistan National ID Card System Application Team Moon Soo Kim
 * @since 2015.01.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2015.01.19 		Moon Soo Kim	  		 		Create
 *
 * </pre>
 */
public class MnMngVO extends ComDefaultVO{
    private static final long serialVersionUID = 1L;

    private String mnSeqNo;
    private String msgId;
    private String pstMnNm;
    private String drMnNm;
    private String enMnNm;
    private String userId;
	public String getMnSeqNo() {
		return mnSeqNo;
	}
	public void setMnSeqNo(String mnSeqNo) {
		this.mnSeqNo = mnSeqNo;
	}
	public String getMsgId() {
		return msgId;
	}
	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}
	public String getPstMnNm() {
		return pstMnNm;
	}
	public void setPstMnNm(String pstMnNm) {
		this.pstMnNm = pstMnNm;
	}
	public String getDrMnNm() {
		return drMnNm;
	}
	public void setDrMnNm(String drMnNm) {
		this.drMnNm = drMnNm;
	}
	public String getEnMnNm() {
		return enMnNm;
	}
	public void setEnMnNm(String enMnNm) {
		this.enMnNm = enMnNm;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
    
  
	
}
