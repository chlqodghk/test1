package afnid.cm.cmm.service;

import java.util.List;

/** 
 * This service interface is biz-class of screen management. <br>
 * 
 * @author Afghanistan National ID Card System Application Team  Moon Soo Kim
 * @since 2014.12.23
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2014.12.23 		Moon Soo Kim	      	 		Create
 *
 * </pre>
 */

public interface ScrnMngService {
	
	/**
	 * Retrieves list of screen. <br>
	 * 
	 * @param vo Input item for retrieving list of screen(ScrnMngVO).
	 * @return List Retrieve list of author
	 * @exception Exception
	 */
	List <ScrnMngVO> searchListScrn(ScrnMngVO scrnMngVO) throws Exception;
	
	/**
	 * Retrieves total count of screen list. <br>
	 * @param vo Input item for retrieving total count list of screen.(ScrnMngVO)
	 * @return int Total Count of screen list
	 * @exception Exception
	 */
	int searchListScrnTotCnt(ScrnMngVO scrnMngVO) throws Exception;
	
		
	
	/**
	 * Retrieves detail Information of screen. <br>
	 * 
	 * @param vo Input item for retrieving detail information of screen(ScrnMngVO).
	 * @return AthrMngVO Retrieve detail information of screen
	 * @exception Exception
	 */
	ScrnMngVO searchScrn(ScrnMngVO scrnMngVO) throws Exception;
	
	/**
	 * Modifies information of screen. <br>
	 * 
	 * @param vo Input item for modifying information of screen(ScrnMngVO).
	 * @exception Exception
	 */
	void modifyScrn(ScrnMngVO scrnMngVO) throws Exception;

}

