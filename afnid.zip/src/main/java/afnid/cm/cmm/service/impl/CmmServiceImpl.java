package afnid.cm.cmm.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.ComDefaultVO;
import afnid.cm.cmm.service.NidCmmService;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;

/** 
 * This service class is biz-class of common
 * and implements NidCommonService class.
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.04.20
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.04.10  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */
@Service("nidCmmService")
public class CmmServiceImpl extends AbstractServiceImpl implements NidCmmService {
	
	@Resource(name="cmmDAO")
    private CmmDAO cmmDAO;
	
	/**
	 * Biz-method for adding the days to current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	public ComDefaultVO searchAddToDay(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectAddToDay(vo);
	}
	
	/**
	 * Biz-method for adding the days to current days(Gregorian). <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	public ComDefaultVO searchAddToDay1(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectAddToDay1(vo);
	}
	
	/**
	 * Biz-method for adding the days to current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	public ComDefaultVO searchPerToDay(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectPerToDay(vo);
	}
	
	/**
	 * Biz-method for adding the days to current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	public ComDefaultVO searchGreToDay(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectGreToDay(vo);
	}
	
	/**
	 * Biz-method for adding the days to current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	public ComDefaultVO searchGreToDay1(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectGreToDay1(vo);
	}
	
	/**
	 * Biz-method for adding the days to current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return String
	 * @exception Exception
	 */
	public String searchDateTime(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectDateTime(vo);
	}

	/**
	 * Biz-method for adding the days to current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return String
	 * @exception Exception
	 */
	public String searchProdDate(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectProdDate(vo);
	}	
	
	/**
	 * Biz-method for adding the days to Gregorian first days in month. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian first days in monthComDefaultVO).
	 * @return ComDefaultVO Adding the days to Gregorian first days in month
	 * @exception Exception
	 */
	public ComDefaultVO searchGreMonFstDay(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectGreMonFstDay(vo);
	}
	
	/**
	 * Biz-method for adding the days to Gregorian last days in month. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian last days in month(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to Gregorian last days in month
	 * @exception Exception
	 */
	public ComDefaultVO searchGreMonLastDay(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectGreMonLastDay(vo);
	}
	
	
	/**
	 * Biz-method for adding the days to persian first days in month. <br>
	 * 
	 * @param vo Input item for adding the days to persian first days in month(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to persian first days in month
	 * @exception Exception
	 */
	public ComDefaultVO searchPreMonFstDay(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectPreMonFstDay(vo);
	}
	
	/**
	 * Biz-method for adding the days to persian last days in month. <br>
	 * 
	 * @param vo Input item for adding the days to persian last days in month(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to persian last days in month
	 * @exception Exception
	 */
	public ComDefaultVO searchPreMonLastDay(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectPreMonLastDay(vo);
	}	

	/**
	 * Biz-method for adding the days to Gregorian first days in week. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian first days in week(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to Gregorian first days in month
	 * @exception Exception
	 */
	public ComDefaultVO searchGreWeekFstDay(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectGreWeekFstDay(vo);
	}
	
	/**
	 * Biz-method for adding the days to Gregorian last days in month. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian last days in week(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to Gregorian last days in month
	 * @exception Exception
	 */
	public ComDefaultVO searchGreWeekLastDay(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectGreWeekLastDay(vo);
	}
	
	
	/**
	 * Biz-method for adding the days to persian first days in month. <br>
	 * 
	 * @param vo Input item for adding the days to persian first days in week(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to persian first days in month
	 * @exception Exception
	 */
	public ComDefaultVO searchPreWeekFstDay(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectPreWeekFstDay(vo);
	}
	
	/**
	 * Biz-method for adding the days to persian last days in month. <br>
	 * 
	 * @param vo Input item for adding the days to persian last days in week(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to persian last days in month
	 * @exception Exception
	 */
	public ComDefaultVO searchPreWeekLastDay(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectPreWeekLastDay(vo);
	}
	
	/**
	 * Biz-method for adding the Input days to current days. <br>
	 * 
	 * @param vo Input item for adding the Input days to current days.(ComDefaultVO).
	 * @return ComDefaultVO Adding the Input days to current days.
	 * @exception Exception
	 */
	public ComDefaultVO searchGreAddingInputDay(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectGreAddingInputDay(vo);
	}
	
	/**
	 * Biz-method <br>
	 * 
	 * @param string.
	 * @return vo
	 * @exception Exception
	 */
	public ComDefaultVO searchPreBfAfMonDay(String mnth) throws Exception {
		return cmmDAO.selectPreBfAfMonDay(mnth);
	}
	
	/**
	 * Biz-method <br>
	 * 
	 * @param string.
	 * @return vo
	 * @exception Exception
	 */
	public ComDefaultVO searchGreBfAfMonDay(String mnth) throws Exception {
		return cmmDAO.selectGreBfAfMonDay(mnth);
	}
		
	/**
	 * Biz-method for get current day and before/after any month day(Gregorian). <br>
	 * 
	 * @param vo Input item for get current day and before/after any month day(ComDefaultVO).
	 * @return ComDefaultVO 
	 * @exception Exception
	 */
	public ComDefaultVO searchGreAddToDay(String mnth) throws Exception {
		return cmmDAO.selectGreAddToDay(mnth);
	}
	
	/**
	 * Biz-method for get current day and before/after any month day(Gregorian). <br>
	 * 
	 * @param vo Input item for get current day and before/after any month day(ComDefaultVO).
	 * @return ComDefaultVO 
	 * @exception Exception
	 */
	public ComDefaultVO searchGreAddToDay1(String mnth) throws Exception {
		return cmmDAO.selectGreAddToDay1(mnth);
	}
	
	/**
	 * Biz-method for get current day and before/after any month day(Persian). <br>
	 * 
	 * @param vo Input item for get current day and before/after any month day(ComDefaultVO).
	 * @return ComDefaultVO 
	 * @exception Exception
	 */
	public ComDefaultVO searchPreAddToDay(String mnth) throws Exception {
		return cmmDAO.selectPreAddToDay(mnth);
	}
	
	/**
	 * Biz-method for get first day in year(Persian) <br>
	 * 
	 * @param vo Input item for get first day in year(ComDefaultVO).
	 * @return ComDefaultVO first day in year
	 * @exception Exception
	 */
	public ComDefaultVO searchPreYearFstDay(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectPreYearFstDay(vo);
	}
	
	/**
	 * Biz-method for get first day in year(Gregorian) <br>
	 * 
	 * @param vo Input item for get first day in year(ComDefaultVO).
	 * @return ComDefaultVO first day in year
	 * @exception Exception
	 */
	public ComDefaultVO searchGreYearFstDay(ComDefaultVO vo) throws Exception {
		return cmmDAO.selectGreYearFstDay(vo);
	}	
	
}
