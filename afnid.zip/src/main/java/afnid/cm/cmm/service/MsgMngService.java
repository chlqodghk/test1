package afnid.cm.cmm.service;

import java.util.List;

/** 
 * This service interface is biz-class of message and label management. <br>
 * 
 * @author Afghanistan National ID Card System Application Team  Moon Soo Kim
 * @since 2014.12.23
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2014.12.23 		Moon Soo Kim	      	 		Create
 *
 * </pre>
 */

public interface MsgMngService {
	
	/**
	 * Retrieves list of message and label. <br>
	 * 
	 * @param vo Input item for retrieving list of message and label(MsgMngVO).
	 * @return List Retrieve list of message and label(
	 * @exception Exception
	 */
	List <MsgMngVO> searchListMsg(MsgMngVO vo) throws Exception;
	
	/**
	 * Retrieves total count of author-list. <br>
	 * @param vo Input item for retrieving total count list of message and label.(MsgMngVO)
	 * @return int Total Count of message and label(
	 * @exception Exception
	 */
	int searchListMsgTotCnt(MsgMngVO vo) throws Exception;
	
		
	
	/**
	 * Retrieves detail Information of message and label. <br>
	 * 
	 * @param vo Input item for retrieving detail information of message and label(MsgMngVO).
	 * @return AthrMngVO Retrieve detail information of message and label
	 * @exception Exception
	 */
	MsgMngVO searchMsg(MsgMngVO vo) throws Exception;
	
	/**
	 * Modifies information of message and label. <br>
	 * 
	 * @param vo Input item for modifying message and label(MsgMngVO).
	 * @exception Exception
	 */
	void modifyMsg(MsgMngVO vo) throws Exception;

	
	/**
	 * Generate information of message and label. <br>
	 * 
	 * @param vo Input item for generate message and label(MsgMngVO).
	 * @exception Exception
	 */
	void addMsg(MsgMngVO vo) throws Exception;
	
}

