package afnid.cm.cmm.service;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of message and label
 * 
 * @author Afghanistan National ID Card System Application Team Moon Soo Kim
 * @since 2015.01.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2015.01.19 		Moon Soo Kim	  		 		Create
 *
 * </pre>
 */
public class ScrnMngVO extends ComDefaultVO{
    private static final long serialVersionUID = 1L;

    private String scrnSeqNo;
    private String pstScrnNm;
    private String drScrnNm;
    private String enScrnNm;
    private String userId;
	public String getScrnSeqNo() {
		return scrnSeqNo;
	}
	public void setScrnSeqNo(String scrnSeqNo) {
		this.scrnSeqNo = scrnSeqNo;
	}
	public String getPstScrnNm() {
		return pstScrnNm;
	}
	public void setPstScrnNm(String pstScrnNm) {
		this.pstScrnNm = pstScrnNm;
	}
	public String getDrScrnNm() {
		return drScrnNm;
	}
	public void setDrScrnNm(String drScrnNm) {
		this.drScrnNm = drScrnNm;
	}
	public String getEnScrnNm() {
		return enScrnNm;
	}
	public void setEnScrnNm(String enScrnNm) {
		this.enScrnNm = enScrnNm;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
    
  
	
}
