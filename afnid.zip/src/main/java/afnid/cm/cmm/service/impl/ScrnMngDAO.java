package afnid.cm.cmm.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import afnid.cm.cmm.service.ScrnMngVO;


/** 
 * This class is Database Access Object of screen management
 * 
 * @author Afghanistan National ID Card System Application Team Moon Soo Kim
 * @since 2015.01.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2015.01.19 		Moon Soo Kim      		 		Create
 *
 * </pre>
 */
@Repository("scrnMngDAO")
public class ScrnMngDAO extends EgovAbstractDAO{
	
	/**
	 * DAO-method for retrieving list of screen. <br>
	 * 
	 * @param vo Input item for retrieving list of screen(ScrnMngVO).
	 * @return ScrnMngVO Retrieve list of screen
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<ScrnMngVO> selectListScrn(ScrnMngVO scrnMngVO) throws Exception{
		return list("scrnMngDAO.selectListScrn", scrnMngVO);
	}
	
	/**
	 * DAO-method for retrieving total count of screen. <br>
	 * 
	 * @param vo Input item for retrieving list of screen(ScrnMngVO).
	 * @return int Total Count list of screen
	 * @exception Exception
	 */
    public int selectListScrnTotCnt(ScrnMngVO scrnMngVO) {
        return (Integer)selectByPk("scrnMngDAO.selectListScrnTotCnt", scrnMngVO);
    }

	
    /**
	 * DAO-method for retrieving detail Information of screen. <br>
	 * 
	 * @param vo Input item for retrieving detail information of screen(ScrnMngVO).
	 * @return ScrnMngVO Retrieve detail information of screen
	 * @exception Exception
	 */
	public ScrnMngVO selectScrn(ScrnMngVO scrnMngVO)throws Exception{
		return (ScrnMngVO)selectByPk("scrnMngDAO.selectScrn", scrnMngVO); 
	}
	
	/**
	 * DAO-method for modifying information of screen. <br>
	 * 
	 * @param vo Input item for modifying information of screen(ScrnMngVO).
	 * @exception Exception
	 */
	public void updateScrn(ScrnMngVO scrnMngVO){
		update("scrnMngDAO.updateScrn", scrnMngVO);
	}

}
