package afnid.cm.cmm.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import afnid.cm.cmm.service.MnMngVO;

/** 
 * This class is Database Access Object of message and label management
 * 
 * @author Afghanistan National ID Card System Application Team Moon Soo Kim
 * @since 2015.01.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2015.01.19 		Moon Soo Kim      		 		Create
 *
 * </pre>
 */
@Repository("mnMngDAO")
public class MnMngDAO extends EgovAbstractDAO{
	
	/**
	 * DAO-method for retrieving list of menu. <br>
	 * 
	 * @param vo Input item for retrieving list of menu(MnMngVO).
	 * @return AthrMngVO Retrieve list of menu
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<MnMngVO> selectListMn(MnMngVO mnMngVo) throws Exception{
		return list("mnMngDAO.selectListMn", mnMngVo);
	}
	
	/**
	 * DAO-method for retrieving total count list of menu. <br>
	 * 
	 * @param vo Input item for retrieving list of menu(MnMngVO).
	 * @return int Total Count list of message and label
	 * @exception Exception
	 */
    public int selectListMnTotCnt(MnMngVO mnMngVo) {
        return (Integer)selectByPk("mnMngDAO.selectListMnTotCnt", mnMngVo);
    }

	
    /**
	 * DAO-method for retrieving detail information of menu. <br>
	 * 
	 * @param vo Input item for retrieving detail information of menu(MnMngVO).
	 * @return AuthorManageVO Retrieve detail information of menu
	 * @exception Exception
	 */
	public MnMngVO selectMn(MnMngVO mnMngVo)throws Exception{
		return (MnMngVO)selectByPk("mnMngDAO.selectMn", mnMngVo); 
	}
	
	/**
	 * DAO-method for modifying information of menu. <br>
	 * 
	 * @param vo Input item for modifying information of menu(MnMngVO).
	 * @exception Exception
	 */
	public void updateMn(MnMngVO mnMngVo){
		update("mnMngDAO.updateMn", mnMngVo);
	}
	
	
}
