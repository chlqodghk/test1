package afnid.cm.cmm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import afnid.cm.board.service.BrdVO;
import afnid.cm.cmm.service.FleVO;
import afnid.cm.cmm.service.FleMngService;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;

/**
 * @Class Name : EgovFileMngServiceImpl.java
 * @Description : File information management class
 * @since 2011.04.10
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers         		Revisions
 *   2011.05.04  		MH Choung         		Create
 *
 *
 */
@Service("FleMngService")
public class FleMngServiceImpl extends AbstractServiceImpl implements FleMngService {

    @Resource(name = "FleMngDAO")
    private FleMngDAO fleMngDAO;

    Logger log = Logger.getLogger(this.getClass());

    /**
     * get file  sequence number.
     * 
     * 
     */
    public int getFlePrptSeqNo(LgnVO key) throws Exception {
	
    	return fleMngDAO.getFlePrptSeqNo(key);

    }
    
    /**
     * Information on multiple files (attributes and details) registers.
     * 
     * @see afnid.cm.cmm.service.EgovFileMngService#insertFileInfs(java.util.List)
     */
    @SuppressWarnings("rawtypes")
	public String addFileInfr(List fvoList) throws Exception {
		String flePrptSeqNo = "";
		
		if (!fvoList.isEmpty()) {
			flePrptSeqNo = fleMngDAO.insertFileInfr(fvoList);
		}
		
		return flePrptSeqNo;
    }
    
    /**
     *retrieving total count of attached file
     * 
     */
    public int searchListFileInfrTotCnt(String flePrptSeqNo) throws Exception {
    	return fleMngDAO.selectListFileInfrTotCnt(flePrptSeqNo);
    }
        
    /**
     * Retrieves a list of attached files.
     * 

     */
    public List<FleVO> searchFileList(FleVO fvo) throws Exception {
    	return fleMngDAO.selectFileList(fvo);
    }    
    
    
    /**
     *  download attached file.
     * 
     */
    public FleVO searchDownFileInfr(FleVO fvo) throws Exception {
    	return fleMngDAO.selectDownFileInfr(fvo);
    }
  
    
    /**
     * delete information of attached file
     *   
     */      
    public void removeFileInfr(BrdVO fvo) throws Exception {
    	String[] delFileNo = 	fvo.getSearchKeyword3().split(",");
		for(int i = 0; i <delFileNo.length;i++){
			FleVO vo = getObjectVO();
			vo.setFlePrptSeqNo(fvo.getFlePrptSeqNo());
			vo.setFleSeqNo(delFileNo[i]);
			fleMngDAO.deleteFileInfr(vo);
		}	
    }
        
    
    /**
     * VO object files generated.
     * 
     * @param void
     * @return FileVO Object
     */
    private FleVO getObjectVO(){
    	return new FleVO();
    }
}
