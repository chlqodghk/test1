package afnid.cm.cmm.service.impl;



import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;

import afnid.cm.NidMessageSource;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.cmm.service.MnMngService;
import afnid.cm.cmm.service.MnMngVO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;




/** 
 * This service class is biz-class of menu management
 * and implements NidAuthorManageService class.
 * 
 * @author Afghanistan National ID Card System Application Team  Moon Soo Kim
 * @since 2015.01.09
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2015.01.09 		Moon Soo Kim	      	 		Create
 *
 * </pre>
 */
@Service("mnMngService")
public  class MnMngServiceImpl extends AbstractServiceImpl implements MnMngService{
	
	@Resource(name="mnMngDAO")
    private MnMngDAO mnMngDAO;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    
    /**
	 * Biz-method for retrieving list of menu. <br>
	 * 
	 * @param vo Input item for retrieving list of menu(MnMngVO).
	 * @return List Retrieve list of menu
	 * @exception Exception
	 */
	public List<MnMngVO> searchListMn(MnMngVO mnMngVo) throws Exception {
   		return mnMngDAO.selectListMn(mnMngVo);
	}
	/**
	 * Biz-method for retrieving total count list of menu. <br>
	 * 
	 * @param vo Input item for retrieving list of menu(MnMngVO).
	 * @return int Total Count list of menu
	 * @exception Exception
	 */
    public int searchListMnTotCnt(MnMngVO mnMngVo) throws Exception {
    	return mnMngDAO.selectListMnTotCnt(mnMngVo);
	}


	
    /**
	 * Biz-method for retrieving detail Information of menu. <br>
	 * 
	 * @param vo Input item for retrieving detail information of menu(MnMngVO).
	 * @return MnMngVO Retrieve detail information of menu
	 * @exception Exception
	 */
	public MnMngVO searchMn(MnMngVO mnMngVo) throws Exception{
    	return (MnMngVO)mnMngDAO.selectMn(mnMngVo);
	}
	
	/**
	 * Biz-method for modifying information of menu. <br>
	 * 
	 * @param vo Input item for modifying information of menu(MnMngVO).
	 * @exception Exception
	 */
	public void modifyMn(MnMngVO mnMngVo) throws Exception {
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		mnMngVo.setUserId(user.getUserId());
		
		mnMngDAO.updateMn(mnMngVo);
	}

}
