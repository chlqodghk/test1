package afnid.cm.cmm.service.impl;

import org.springframework.stereotype.Repository;

import afnid.cm.ComDefaultVO;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/** 
 * This class is Database Access Object of common
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.04.20
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.04.20  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */
@Repository("cmmDAO")
public class CmmDAO extends EgovAbstractDAO {

	/**
	 * DAO-method for adding the days to current days(persian). <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	public ComDefaultVO selectAddToDay(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectAddToDay", vo); 
	}
	
	/**
	 * DAO-method for adding the days to current days(Gregorian). <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	public ComDefaultVO selectAddToDay1(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectAddToDay1", vo); 
	}
	
	/**
	 * DAO-method for adding the days to persian  current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	public ComDefaultVO selectPerToDay(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectPerToDay", vo); 
	}
	
	/**
	 * DAO-method for adding the days to Gregorian 	 current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	public ComDefaultVO selectGreToDay(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectGreToDay", vo); 
	}
	
	/**
	 * DAO-method for adding the days to Gregorian 	 current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	public ComDefaultVO selectGreToDay1(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectGreToDay1", vo); 
	}	
	/**
	 * DAO-method for adding the days to persin current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return String
	 * @exception Exception
	 */
	public String selectDateTime(ComDefaultVO vo)throws Exception {
		return (String)selectByPk("cmmDAO.selectDateTime", vo);
	}

	/**
	 * DAO-method for adding the days to persian current days. <br>
	 * 
	 * @param vo Input item for adding the days to current days(ComDefaultVO).
	 * @return String
	 * @exception Exception
	 */
	public String selectProdDate(ComDefaultVO vo)throws Exception {
		return (String)selectByPk("cmmDAO.selectProdDate", vo);
	}	
	
	
	/**
	 * DAO-method for adding the days to Gregorian first days in month. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian first days in months(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to Gregorian first days in month
	 * @exception Exception
	 */
	public ComDefaultVO selectGreMonFstDay(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectGreMonFstDay", vo); 
	}	
	
	
	/**
	 * DAO-method for adding the days to Gregorian last days in month. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian last days in months(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to Gregorian last days in month
	 * @exception Exception
	 */
	public ComDefaultVO selectGreMonLastDay(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectGreMonLastDay", vo); 
	}	
	
	
	/**
	 * DAO-method for adding the days to persian first days in month. <br>
	 * 
	 * @param vo Input item for adding the days to persian first days in months(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to persian first days in month
	 * @exception Exception
	 */
	public ComDefaultVO selectPreMonFstDay(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectPreMonFstDay", vo); 
	}
	
	/**
	 * DAO-method for adding the days to persian last days in month. <br>
	 * 
	 * @param vo Input item for adding the days to persian last days in months(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to persian last days in month
	 * @exception Exception
	 */
	public ComDefaultVO selectPreMonLastDay(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectPreMonLastDay", vo); 
	}	

	
	/**
	 * DAO-method for adding the days to Gregorian first days in week. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian first days in week(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to Gregorian first days in week
	 * @exception Exception
	 */
	public ComDefaultVO selectGreWeekFstDay(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectGreWeekFstDay", vo); 
	}
	
	/**
	 * DAO-method for adding the days to Gregorian last days in week. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian last days in week(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to Gregorian last days in week
	 * @exception Exception
	 */
	public ComDefaultVO selectGreWeekLastDay(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectGreWeekLastDay", vo); 
	}	
	
	/**
	 * DAO-method for adding the days to persian first days in week. <br>
	 * 
	 * @param vo Input item for adding the days to persian first days in week(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to persian first days in week
	 * @exception Exception
	 */
	public ComDefaultVO selectPreWeekFstDay(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectPreWeekFstDay", vo); 
	}

	/**
	 * DAO-method for adding the days to persian last days in week. <br>
	 * 
	 * @param vo Input item for adding the days to persian last days in week(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to persian last days in week
	 * @exception Exception
	 */
	public ComDefaultVO selectPreWeekLastDay(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectPreWeekLastDay", vo); 
	}

	/**
	 * DAO-method for adding the Input days to current days. <br>
	 * 
	 * @param vo Input item for adding the Input days to current days.(ComDefaultVO).
	 * @return ComDefaultVO Adding the Input days to current days.
	 * @exception Exception
	 */
	public ComDefaultVO selectGreAddingInputDay(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectGreAddingInputDay", vo); 
	}
	
	/**
	 * DAO-method <br>
	 * 
	 * @param sting 
	 * @return ComDefaultVO 
	 * @exception Exception
	 */
	public ComDefaultVO selectPreBfAfMonDay(String mnth)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.cmmDAO.selectPreBfAfMonDay", mnth); 
	}	
	
	
	/**
	 * DAO-method <br>
	 * 
	 * @param sting 
	 * @return ComDefaultVO 
	 * @exception Exception
	 */
	public ComDefaultVO selectGreBfAfMonDay(String  mnth)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectGreBfAfMonDay", mnth); 
	}	
	
	/**
	 * DAO-method for get current day and before/after any month day(Gregorian). <br>
	 * 
	 * @param vo Input item for get current day and before/after any month day(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	public ComDefaultVO selectGreAddToDay(String mnth)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectGreAddToDay", mnth); 
	}
	
	/**
	 * DAO-method for get current day and before/after any month day(Gregorian). <br>
	 * 
	 * @param vo Input item for get current day and before/after any month day(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	public ComDefaultVO selectGreAddToDay1(String mnth)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectGreAddToDay1", mnth); 
	}
	
	
	/**
	 * DAO-method for get current day and before/after any month day(Persian). <br>
	 * 
	 * @param vo Input item for get current day and before/after any month day(ComDefaultVO).
	 * @return ComDefaultVO Adding the days to current days
	 * @exception Exception
	 */
	public ComDefaultVO selectPreAddToDay(String mnth)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectPreAddToDay", mnth); 
	}
	
	/**
	 * DAO-method for get first day in year(persian). <br>
	 * 
	 * @param vo Input item for get first day in year(ComDefaultVO).
	 * @return ComDefaultVO first day in year
	 * @exception Exception
	 */
	public ComDefaultVO selectPreYearFstDay(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectPreYearFstDay", vo); 
	}
	
	/**
	 * DAO-method for get first day in year(Gregorian). <br>
	 * 
	 * @param vo Input item for get first day in year(ComDefaultVO).
	 * @return ComDefaultVO first day in year
	 * @exception Exception
	 */
	public ComDefaultVO selectGreYearFstDay(ComDefaultVO vo)throws Exception {
		return (ComDefaultVO)selectByPk("cmmDAO.selectGreYearFstDay", vo); 
	}	
	
}
