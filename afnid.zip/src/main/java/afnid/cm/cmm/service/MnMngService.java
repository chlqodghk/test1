package afnid.cm.cmm.service;

import java.util.List;

/** 
 * This service interface is biz-class of menu management. <br>
 * 
 * @author Afghanistan National ID Card System Application Team  Moon Soo Kim
 * @since 2015.01.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2015.01.19 		Moon Soo Kim	      	 		Create
 *
 * </pre>
 */

public interface MnMngService {
	
	/**
	 * Retrieves list of Menu . <br>
	 * 
	 * @param vo Input item for retrieving list of menu(MnMngVO).
	 * @return List Retrieve list of menu
	 * @exception Exception
	 */
	List <MnMngVO> searchListMn(MnMngVO mnMngVo) throws Exception;
	
	/**
	 * Retrieves total count of menu list. <br>
	 * @param vo Input item for retrieving total count list of menu.(MnMngVO)
	 * @return int Total Count of menu list
	 * @exception Exception
	 */
	int searchListMnTotCnt(MnMngVO mnMngVo) throws Exception;
	
		
	
	/**
	 * Retrieves detail Information of menu. <br>
	 * 
	 * @param vo Input item for retrieving detail information of menu(MnMngVO).
	 * @return MnMngVO Retrieve detail information of menu
	 * @exception Exception
	 */
	MnMngVO searchMn(MnMngVO mnMngVo) throws Exception;
	
	/**
	 * Modifies information of menu. <br>
	 * 
	 * @param vo Input item for modifying menu(MnMngVO).
	 * @exception Exception
	 */
	void modifyMn(MnMngVO mnMngVo) throws Exception;

}

