package afnid.cm.cmm.web;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.MsgMngService;
import afnid.cm.cmm.service.MsgMngVO;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/** 
 * This Controller class processes request of massage and label management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Moon Soo Kim
 * @since 2014.12.23
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2014.12.23 		Moon Soo Kim	      		 	Create
 *
 * </pre>
 */
@Controller
public class MsgMngController {
	
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());
	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /** CmmCdManagerServiceImpl */
	//@Resource(name = "cmmCdMngService")
    //private CmmCdMngService cmmCdMngService;
	
    /** msgMngService */
	@Resource(name = "msgMngService")
    private MsgMngService msgMngService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
	
    /** lgService */
	@Resource(name = "lgService")
    private LgService lgService;	
	
	/** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
    /**
     * Moved to list-screen of message and label. <br>
     * 
     * @param comDefaultVO Value-object of message to be parsed request(ComDefaultVO)
     * @param MsgMngVO Value-object of message to be parsed request(MsgMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/cmm/MsgList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/cmm/searchListMsgView.do")
    public String searchListMsgView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("msgMngVO") MsgMngVO msgMngVO,
    		ModelMap model)
            throws Exception { 
    	    
    	try{
    		   			
        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();        	
        	lgService.addUserWrkLg(user.getUserId(), msgMngVO.getCurMnId());
        	
	    	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("22"); // Setting Group Code
			List<CmCmmCdVO> langList = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
			model.addAttribute("langList", langList);
			
			searchVO.setSearchKeyword("1");
        	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
      	return "/cm/cmm/MsgList";

    }
    
    /**
     * Retrieves list of author.  <br>
     * 
     * @param MsgMngVO Value-object of Message to be parsed request(MsgMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/cmm/MsgList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/cmm/searchListMsg.do")
    public String searchListMsg(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("msgMngVO") MsgMngVO msgMngVO,
    		ModelMap model)
            throws Exception { 

    	try {
    		
	    	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("22"); // Setting Group Code
			List<CmCmmCdVO> langList = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
			model.addAttribute("langList", langList);
			
	    	/** 목록 Paging Setting */
    		msgMngVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		msgMngVO.setPageSize(propertiesService.getInt("pageSize"));
	
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(msgMngVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(msgMngVO.getPageUnit());
			paginationInfo.setPageSize(msgMngVO.getPageSize());
	
			msgMngVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			msgMngVO.setLastIndex(paginationInfo.getLastRecordIndex());
			msgMngVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
	        List<MsgMngVO> lstMsg = msgMngService.searchListMsg(msgMngVO);
	        model.addAttribute("lstMsg", lstMsg);
	
	        int totCnt = msgMngService.searchListMsgTotCnt(msgMngVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "/cm/cmm/MsgList";
    }
    

    /**
     * Moved to modification-screen of message. <br>
     * 
     * @param MsgMngVO Value-object of message to be parsed request(MsgMngVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/cmm/MsgUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/cmm/modifyMsgView.do")
    public String modifyMsgView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("msgMngVO") MsgMngVO msgMngVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	
    	try {
    		model.addAttribute("msgMngVO", msgMngService.searchMsg(msgMngVO));    
     	    
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/cm/cmm/MsgUdt";
    }
    
	/**
	 * Modifies information of message. <br>
	 * 
	 * @param MsgMngVO Value-object of message to be parsed request(MsgMngVO)
	 * @param bindingResult  validate Input Item(BindingResult)
	 * @param model Object to be parsed http request(ModelMap) 
	 * @return Printed out JSP: "cm/cmm/MsgList.jsp"
	 * @exception Exception
	 */
    @RequestMapping(value="/cm/cmm/modifyMsg.do")
    public String modifyMsg(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("msgMngVO") MsgMngVO msgMngVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	try {
    		
    		msgMngService.modifyMsg(msgMngVO); 
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); 
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
		return "forward:/cm/cmm/searchListMsg.do"; 
    }

    
	/**
	 * Generate information of message and label. <br>
	 * 
	 * @param MsgMngVO Value-object of message to be parsed request(MsgMngVO)
	 * @param bindingResult  validate Input Item(BindingResult)
	 * @param model Object to be parsed http request(ModelMap) 
	 * @return Printed out JSP: "cm/cmm/MsgList.jsp"
	 * @exception Exception
	 */
    @RequestMapping(value="/cm/cmm/addMsg.do")
    public String addMsg(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("msgMngVO") MsgMngVO msgMngVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	try {
    		
    		msgMngService.addMsg(msgMngVO); 
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); 
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
		return "forward:/cm/cmm/searchListMsg.do"; 
    }
    
}
