package afnid.cm.cmm.web;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.MnMngService;
import afnid.cm.cmm.service.MnMngVO;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/** 
 * This Controller class processes request of menu management. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Moon Soo Kim
 * @since 2015.01.09
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2015.01.09 		Moon Soo Kim	      		 	Create
 *
 * </pre>
 */
@Controller
public class MnMngController {
	
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());
	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /** CmmCdManagerServiceImpl */
	//@Resource(name = "cmmCdMngService")
    //private CmmCdMngService cmmCdMngService;
	
    /** msgMngService */
	@Resource(name = "mnMngService")
    private MnMngService mnMngService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
	
    /** lgService */
	@Resource(name = "lgService")
    private LgService lgService;	
	
	/** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;

    /**
     * Moved to list-screen of message and label. <br>
     * 
     * @param comDefaultVO Value-object of menu to be parsed request(ComDefaultVO)
     * @param MnMngVO Value-object of menu to be parsed request(MnMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/cmm/MnList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/cmm/searchListMnView.do")
    public String searchListMnView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("mnMngVo") MnMngVO mnMngVo,
    		ModelMap model)
            throws Exception { 
    	    
    	try{
    		   			
        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();        	
        	lgService.addUserWrkLg(user.getUserId(), mnMngVo.getCurMnId());
        	
	    	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("22"); // Setting Group Code
			List<CmCmmCdVO> langList = cmmCdMngService.searchListCmmCd(cmCmmCd);
			model.addAttribute("langList", langList);
			
			searchVO.setSearchKeyword("1");
        	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
      	return "/cm/cmm/MnList";

    }
    
    /**
     * Retrieves list of menu.  <br>
     * 
     * @param MnMngVO Value-object of menu to be parsed request(MnMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/cmm/MnList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/cmm/searchListMn.do")
    public String searchListMn(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("mnMngVO") MnMngVO mnMngVO,
    		ModelMap model)
            throws Exception { 

    	try {
    		
	    	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("22"); // Setting Group Code
			List<CmCmmCdVO> langList = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
			model.addAttribute("langList", langList);
			
	    	/** 목록 Paging Setting */
    		mnMngVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		mnMngVO.setPageSize(propertiesService.getInt("pageSize"));
	
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(mnMngVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(mnMngVO.getPageUnit());
			paginationInfo.setPageSize(mnMngVO.getPageSize());
	
			mnMngVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			mnMngVO.setLastIndex(paginationInfo.getLastRecordIndex());
			mnMngVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
	        List<MnMngVO> lstMnNm = mnMngService.searchListMn(mnMngVO);
	        model.addAttribute("lstMnNm", lstMnNm);
	
	        int totCnt = mnMngService.searchListMnTotCnt(mnMngVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "/cm/cmm/MnList";
    }
    

    /**
     * Moved to modification-screen of menu. <br>
     * 
     * @param MnMngVO Value-object of menu to be parsed request(MnMngVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/cmm/MnUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/cmm/modifyMnView.do")
    public String modifyMnView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("mnMngVO") MnMngVO mnMngVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	
    	try {
    		model.addAttribute("mnMngVO", mnMngService.searchMn(mnMngVO));    
     	    
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/cm/cmm/MnUdt";
    }
    
	/**
	 * Modifies information of message. <br>
	 * 
	 * @param MnMngVO Value-object of menu to be parsed request(MnMngVO)
	 * @param bindingResult  validate Input Item(BindingResult)
	 * @param model Object to be parsed http request(ModelMap) 
	 * @return Printed out JSP: "cm/cmm/MnList.jsp"
	 * @exception Exception
	 */
    @RequestMapping(value="/cm/cmm/modifyMn.do")
    public String modifyMn(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("mnMngVO") MnMngVO mnMngVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	try {
    		
    		mnMngService.modifyMn(mnMngVO); 
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); 
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
		return "forward:/cm/cmm/searchListMn.do"; 
    }

    
}
