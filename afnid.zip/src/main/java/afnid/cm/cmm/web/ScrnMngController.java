package afnid.cm.cmm.web;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.ScrnMngVO;
import afnid.cm.cmm.service.ScrnMngService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/** 
 * This Controller class processes request of screen management. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Moon Soo Kim
 * @since 2015.01.09
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2015.01.09 		Moon Soo Kim	      		 	Create
 *
 * </pre>
 */
@Controller
public class ScrnMngController {
	
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());
	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /** CmmCdManagerServiceImpl */
	//@Resource(name = "cmmCdMngService")
    //private CmmCdMngService cmmCdMngService;
	
    /** msgMngService */
	@Resource(name = "scrnMngService")
    private ScrnMngService scrnMngService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
	
    /** lgService */
	@Resource(name = "lgService")
    private LgService lgService;	
	
	/** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
    /**
     * Moved to list-screen of message and label. <br>
     * 
     * @param comDefaultVO Value-object of screen to be parsed request(ComDefaultVO)
     * @param ScrnMngVO Value-object of screen to be parsed request(ScrnMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/cmm/ScrnList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/cmm/searchListScrnView.do")
    public String searchListScrnView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("scrnMngVO") ScrnMngVO scrnMngVO,
    		ModelMap model)
            throws Exception { 
    	    
    	try{
    		   			
        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();        	
        	lgService.addUserWrkLg(user.getUserId(), scrnMngVO.getCurMnId());
        	
	    	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("22"); // Setting Group Code
			List<CmCmmCdVO> langList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("langList", langList);
			
			searchVO.setSearchKeyword("1");
        	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
      	return "/cm/cmm/ScrnList";

    }
    
    /**
     * Retrieves list of author.  <br>
     * 
     * @param ScrnMngVO Value-object of screen to be parsed request(ScrnMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/cmm/ScrnList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/cmm/searchListScrn.do")
    public String searchListScrn(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("scrnMngVO") ScrnMngVO scrnMngVO,
    		ModelMap model)
            throws Exception { 

    	try {
    		
	    	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("22"); // Setting Group Code
			List<CmCmmCdVO> langList = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
			model.addAttribute("langList", langList);
			
	    	/** 목록 Paging Setting */
    		scrnMngVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		scrnMngVO.setPageSize(propertiesService.getInt("pageSize"));
	
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(scrnMngVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(scrnMngVO.getPageUnit());
			paginationInfo.setPageSize(scrnMngVO.getPageSize());
	
			scrnMngVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			scrnMngVO.setLastIndex(paginationInfo.getLastRecordIndex());
			scrnMngVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
	        List<ScrnMngVO> lstScrnNm = scrnMngService.searchListScrn(scrnMngVO);
	        model.addAttribute("lstScrnNm", lstScrnNm);
	
	        int totCnt = scrnMngService.searchListScrnTotCnt(scrnMngVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "/cm/cmm/ScrnList";
    }
    

    /**
     * Moved to modification-screen of screen name. <br>
     * 
     * @param ScrnMngVO Value-object of screen to be parsed request(ScrnMngVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/cmm/ScrnUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/cmm/modifyScrnView.do")
    public String modifyScrnView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("scrnMngVO") ScrnMngVO scrnMngVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	
    	try {
    		model.addAttribute("scrnMngVO", scrnMngService.searchScrn(scrnMngVO));    
     	    
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/cm/cmm/ScrnUdt";
    }
    
	/**
	 * Modifies information of message. <br>
	 * 
	 * @param ScrnMngVO Value-object of screen to be parsed request(ScrnMngVO)
	 * @param bindingResult  validate Input Item(BindingResult)
	 * @param model Object to be parsed http request(ModelMap) 
	 * @return Printed out JSP: "cm/cmm/ScrnList.jsp"
	 * @exception Exception
	 */
    @RequestMapping(value="/cm/cmm/modifyScrn.do")
    public String modifyScrn(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("scrnMngVO") ScrnMngVO scrnMngVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	try {
    		
    		scrnMngService.modifyScrn(scrnMngVO); 
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); 
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
		return "forward:/cm/cmm/searchListScrn.do"; 
    }

    
}
