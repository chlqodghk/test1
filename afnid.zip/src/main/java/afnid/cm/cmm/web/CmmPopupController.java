package afnid.cm.cmm.web;


import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.NidMessageSource;
import egovframework.rte.fdl.property.EgovPropertyService;
/** 
 * This Controller class processes request of  each program call pop-up view. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.04.10
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers         		Revisions
 *   2011.04.10  		MH Choung         		Create
 *
 * </pre>
 */
@Controller
public class CmmPopupController {
	
	
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());
	 /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;


	
	/** cmmCdMngService */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
	/**
	 * calling normal pop-up delupd reason .
	 * @param model
	 * @return "/cm/cmm/cal/p_DelUpdReason"
	 * @throws Exception
	 */
	
	@RequestMapping(value="/cm/cmm/showDelupd.do")
 	public String showReason (
 			@RequestParam(value="kind" ,required=false) String kind,
 			@RequestParam(value="cdform" ,required=false) String cdform,
 			@RequestParam(value="cdinput" ,required=false) String cdinput,
 			@RequestParam(value="contform" ,required=false) String contform,
 			@RequestParam(value="continput" ,required=false) String continput,
 			@RequestParam(value="func" ,required=false) String func,
 			@RequestParam(value="gbn" ,required=false) String gbn,
 			@RequestParam(value="cd" ,required=false) String cd,
 			ModelMap model
 			
 			) throws Exception {
		
		try{
		//System update reason Code select		
		CmCmmCdVO cmCmmCdVO =new  CmCmmCdVO();
		cmCmmCdVO.setGrpCd("24");
		List<CmCmmCdVO> lstReasonCd = cmmCdMngService.searchListCmmCd(cmCmmCdVO); // Common Code retrieve Interface Call
		
		model.addAttribute("lstReasonCd", lstReasonCd); // common code for update reason
		model.addAttribute("kind",kind);
		model.addAttribute("cdform",cdform);
		model.addAttribute("cdinput",cdinput);
		model.addAttribute("contform",contform);
		model.addAttribute("continput",continput); 
		model.addAttribute("func",func);
		model.addAttribute("gbn",gbn);
		model.addAttribute("cd",cd);
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	    		   		
		model.addAttribute("langCd", user.getUseLangCd()); 				
		
		} catch(Exception e){
			log.error(e.getMessage(), e);
			model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		}
		
		return "/cm/cmm/p_DelUpdRsn";
	}    

}
