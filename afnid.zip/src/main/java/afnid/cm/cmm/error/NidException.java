package afnid.cm.cmm.error;

/** 
 * This NidException class. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.04.14
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.04.14  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */
public class NidException extends Exception {

	private static final long serialVersionUID = 1L;
	
	private final String message;
	
	public NidException(String message) {
       this.message = message;
    }
	
	public String getMessage() {
		return message;
	}
}
