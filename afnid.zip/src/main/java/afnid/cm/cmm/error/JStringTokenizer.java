package afnid.cm.cmm.error;

/**
 * improve java.util.StringTokenizer one class
 * -------------------------------------------------------------
 * 1. Improvements
 *	Token does not allow length to get a null value is.
 *  Through an ArrayList you can use multiple delimiter.
 *
 * @author  Justin Lee (solacer@hanmail.net) , original source from rookey94@hanmail.net
 * @version 1.00, 08/01/2002
 * @since 1.0
 */
//package usrCom;

import java.util.ArrayList;
import java.util.NoSuchElementException;

public class JStringTokenizer {
	private int currentPosition;
    private int newPosition;
    private int maxPosition;
    private String str;
    private ArrayList<String> delimiters;
    private boolean retDelims;
    private boolean delimsChanged;
    private boolean allowZeroLength;

    public JStringTokenizer(String str, ArrayList<String> delim, boolean returnDelims, boolean allowZeroLength) {
        currentPosition = 0;
        newPosition = -1;
        delimsChanged = false;
        this.str = str;
        maxPosition = str.length();
        delimiters = delim;
        retDelims = returnDelims;
        this.allowZeroLength = allowZeroLength;
    }

    public JStringTokenizer(String str, String delim, boolean returnDelims, boolean allowZeroLength) {
        currentPosition = 0;
        newPosition = -1;
        delimsChanged = false;
        this.str = str;
        maxPosition = str.length();
        delimiters = new ArrayList<String>();
        delimiters.add(delim);
        retDelims = returnDelims;
        this.allowZeroLength = allowZeroLength;
    }

    public JStringTokenizer(String str, ArrayList<String> delim, boolean returnDelims) {
        this(str, delim, returnDelims, false);
    }

    public JStringTokenizer(String str, String delim, boolean returnDelims) {
        this(str, delim, returnDelims, false);
    }

    public JStringTokenizer(String str, ArrayList<String> delim) {
        this(str, delim, false, false);
    }

    public JStringTokenizer(String str, String delim) {
        this(str, delim, false, false);
    }

    private String findToken(int position) {
        for (int i = 0; i < delimiters.size(); i++) {
            String delim = (String) delimiters.get(i);
            if (str.startsWith(delim, position)) {
                return delim;
            }
        }
        return null;
    }

    private int skipDelimiters(int startPos) {
        //if (delimiters == null) {
            //throw new NullPointerException();
        //}

        String delim;
        int position = startPos;
        while (!retDelims && position < maxPosition) {
        	delim = findToken(position);
            if ( delim == null) {
                break;
            }
            position += delim.length();
            if (allowZeroLength) {
                break;
            }
        }
        return position;
    }

    private int scanToken(int startPos) {
        String delim;
        int position = startPos;
        while (position < maxPosition) {
        	delim = findToken(position);
            if ( delim != null) {
                break;
            }
            position++;
        }
        if (retDelims && (startPos == position)) {
        	delim = findToken(position);
            if ( delim != null) {
                position += delim.length();
            }
        }
        return position;
    }

    public boolean hasMoreTokens() {
        newPosition = skipDelimiters(currentPosition);
        return (newPosition < maxPosition);
    }

    public String nextToken() {
        currentPosition = (newPosition >= 0 && !delimsChanged) ? newPosition : skipDelimiters(currentPosition);

        delimsChanged = false;
        newPosition = -1;

        if (currentPosition >= maxPosition) {
            throw new NoSuchElementException();
        }
        int start = currentPosition;
        currentPosition = scanToken(currentPosition);
        return str.substring(start, currentPosition);
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
	public String nextToken(ArrayList delim) {
        delimiters = delim;
        delimsChanged = true;

        return nextToken();
    }

    public boolean hasMoreElements() {
        return hasMoreTokens();
    }

    public Object nextElement() {
        return nextToken();
    }

    public int countTokens() {
        int count = 0;
        int currpos = currentPosition;
        while (currpos < maxPosition) {
            currpos = skipDelimiters(currpos);
            if (currpos >= maxPosition) {
                break;
            }
            currpos = scanToken(currpos);
            count++;
        }
        return count;
    }

    
}
