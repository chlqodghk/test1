package afnid.cm.cmm.error;

import java.util.NoSuchElementException;

import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;

import com.ibatis.common.jdbc.exception.NestedSQLException;

public class ErrorHandler {
	private final static String DELIMITER = "<||>";	//String delimiter
	
	private final static String UNDELIMITER = " \\n ";	//String delimiter
	
	@SuppressWarnings("unused")
    private final static String DELIMITER_WITH_SPACE = "<||>     ";	//A string with a space separator
    
    private final static String ERROR_DELIMITER = "Cause:";

    /** Length of characters per line for each show */
    private final static int WRAP_LENGTH = 30;

    /** Special characters, spaces 9 */
    public final static String SPACE = "　　　　　　　　 ";
	
	/** Type of error */
	private String errorType;
	
	/** Error Message */
	@SuppressWarnings("unused")
	private String errorMsg;
	
	/** Debug messages */
	private String debugMsg;
	
	/** Your message */
	private String userMsg;
	
	
    public ErrorHandler() {
    	super();
    }
	
	/**
	 * Constructor error handling
	 * 
	 * @param model
	 * @param errorMsg
	 */
	public ErrorHandler(String errorMsg) {
		errorType = ErrorType.USR;
		this.debugMsg = errorMsg;
    }
	
	/**
	 * Constructor error handling
	 * @param model
	 * @param errorMsgs
	 * @param debugMsg
	 */
	public ErrorHandler(String errorMsgs, String debugMsg) {
		errorType = ErrorType.EAI;
		this.errorMsg = errorMsgs;
		this.debugMsg = debugMsg;
    }
	
	public ErrorHandler(Exception ex) {
		if(ex instanceof org.springframework.jdbc.BadSqlGrammarException){
			unmarshalOra(ex.getMessage());
		}else if(ex instanceof NidException){
			unmarshalNid(ex.getMessage());
		}else if(ex instanceof Exception){
			unmarshal(ex.toString());
		}else{
			unmarshalEtc(ex.getMessage());
		}
    }
	
	public ErrorHandler(NestedSQLException se) {
		errorType = ErrorType.ORA;
		debugMsg = se.getMessage();
    }
	
	/**
     * Get an error type.
     * 
     * @return String
     */
    public String getType() {
        return this.errorType;
    }

    /**
     * The user gets an error message.
     * 
     * @return String
     */
    public String getUserMessage() {
        return this.userMsg;
    }

    /**
     * Get debug messages related to the error.
     * 
     * @return String
     */
    public String getDebugMessage() {
        return this.debugMsg;
    }
    
	
    /**
     * String received the error message in the error handler property is set.
     */
    private void unmarshal(String message) {
        JStringTokenizer jst = new JStringTokenizer(message, DELIMITER, false, true);
        try {
        	errorType = ErrorType.GEN;        	
        	userMsg = jst.nextToken();
        	debugMsg = jst.nextToken();
        	
        	if(jst.hasMoreElements()){
        		debugMsg = jst.nextToken();
            } else {
            	debugMsg = "";
            }

        } catch (NoSuchElementException nsee) {
        	errorType = ErrorType.GEN;
        	debugMsg = message;
        }
    }
    
    /**
     * String received the error message in the error handler property is set.
     */
    private void unmarshalEtc(String message) {
        JStringTokenizer jst = new JStringTokenizer(message, ERROR_DELIMITER, false, true);
        try {
        	errorType = ErrorType.GEN;        	
        	userMsg = jst.nextToken();
        	debugMsg = jst.nextToken();

        } catch (NoSuchElementException nsee) {
        	errorType = ErrorType.ORA;
        	debugMsg = message;
        }
    }
    
    /**
     * String received the error message in the error handler property is set.
     */
    private void unmarshalOra(String message) {
        JStringTokenizer jst = new JStringTokenizer(message, ERROR_DELIMITER, false, true);
        try {
        	errorType = ErrorType.ORA;        	
        	userMsg = jst.nextToken();
        	debugMsg = jst.nextToken();

        } catch (NoSuchElementException nsee) {
        	errorType = ErrorType.ORA;
        	debugMsg = message;
        }
    }
    
    private void unmarshalNid(String message) {
    	errorType = ErrorType.USR;
    	debugMsg = message;
    }
    
    /**
     * The error message to load the defined classes.
     */
    @SuppressWarnings("static-access")
	public String getLoadMessage() {
    	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    	String useLangCd= user.getUseLangCd();

        String returnValue = "";
        String alertMsg = "";
        
        if(this.errorType.equals("GEN")) {
        	alertMsg=getModiMessage(this.debugMsg);
        } else if(this.errorType.equals("ORA")) {
        	alertMsg=getModiMessage(this.debugMsg);
        } else if(this.errorType.equals("USR")){
        	alertMsg=this.debugMsg;
        } else {
        	alertMsg=this.debugMsg;
        }
        
        ErrorPropertyLoader propLoader = ErrorPropertyLoader.getInstance();
        propLoader.loadMessageList();
        
        if("".equals(useLangCd) || "1".equals(useLangCd)) { //Pashto use
        	returnValue = "─────────────────────────────────　　"
                + UNDELIMITER + "　◎ "+propLoader.getProperty("Globals.ErrType.Pst.Label")+" : " + this.errorType 
                + UNDELIMITER + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━　　"
                + UNDELIMITER + "　◎ "+propLoader.getProperty("Globals.ErrMsg.Pst.Label")+" : " + alertMsg;
        	
        } else if("".equals(useLangCd) || "1".equals(useLangCd)){ //Use Dari
        	returnValue = "─────────────────────────────────　　"
                + UNDELIMITER + "　◎ "+propLoader.getProperty("Globals.ErrType.Dr.Label")+" : " + this.errorType 
                + UNDELIMITER + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━　　"
                + UNDELIMITER + "　◎ "+propLoader.getProperty("Globals.ErrMsg.Dr.Label")+" : " + alertMsg;
        } else {
        	returnValue = "─────────────────────────────────　　"
                + UNDELIMITER + "　◎ "+propLoader.getProperty("Globals.ErrType.En.Label")+" : " + this.errorType 
                + UNDELIMITER + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━　　"
                + UNDELIMITER + "　◎ "+propLoader.getProperty("Globals.ErrMsg.En.Label")+" : " + alertMsg;        	
        }

        return returnValue;

    }
    
    /**
     * 
     * @param debugMessage
     * @return String
     */
    private String getModiMessage(String debugMessage) {
        String orgString = debugMessage.replace('\n', ' ').replace('"', ' ').replace('\'', '_');
        StringBuffer returnString = new StringBuffer();
        boolean isFirst = true;
        int position = WRAP_LENGTH;
        for (; orgString.length() > position ;) {

            returnString.append(preSpace(isFirst)).append(orgString.substring(position - WRAP_LENGTH, position)).append(UNDELIMITER);
            isFirst = false;
            position += WRAP_LENGTH;
        }

        returnString.append(preSpace(isFirst)).append(orgString.substring(position - WRAP_LENGTH));

        return returnString.toString();
    }
    
    private String preSpace(boolean isFirst) {
        return isFirst ? "" : SPACE;
    }

    
    /**
     *  Type of error for the inner class
     */
    static public class ErrorType {
        /** User error */
        public static final String USR = "USR";

        /** EAI server error */
        public static final String EAI = "EAI";

        /** Oracle error */
        public static final String ORA = "ORA";

        /** Other error */
        public static final String APP = "APP";

        /** Typically, the error */
        public static final String GEN = "GEN";

        /** Framework error */
        public static final String FRA = "FRA";

    }
	

}
