package afnid.cm.cmm.error;

import java.util.HashMap;


import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ErrorPropertyLoader {
	
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());
	
	protected static HashMap<String, String> messageMap = new HashMap<String, String>();
	
    private static final String FILE_PATH = "/afnid/cm/cmm/error/error.properties";
    
    @SuppressWarnings("static-access")
	public static ErrorPropertyLoader getInstance() {
        return (ErrorPropertyLoader) SingletonRegistry.registry.getInstance("afnid.cm.cmm.error.ErrorPropertyLoader");
    }

    protected ErrorPropertyLoader() {
        loadMessageList();
    }

    public void loadMessageList() {
        // Write your code here
        try {
            URL configURL = ErrorPropertyLoader.class.getResource(FILE_PATH);
            Properties prop = new Properties();
            prop.load(configURL.openStream());
            String str = null;
            Enumeration<?> enu = prop.propertyNames();
            while (enu.hasMoreElements()) {
                str = (String) enu.nextElement();
                ErrorPropertyLoader.messageMap.put(str, prop.getProperty(str));
            }
        } catch (IOException e) {
            log.error(e);
        }
    }

    public static String getProperty(String code) {
        return messageMap.get(code) == null ? "" : messageMap.get(code);
    }


}
