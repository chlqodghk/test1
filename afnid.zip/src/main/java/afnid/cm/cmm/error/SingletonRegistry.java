package afnid.cm.cmm.error;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class SingletonRegistry {
	private static transient org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(SingletonRegistry.class);
    public static SingletonRegistry registry = new SingletonRegistry();
	private static Map<String, Object> map = Collections.synchronizedMap(new HashMap<String, Object>());

    protected SingletonRegistry() {
        // Exists to defeat instantiation
    }

    public static Object getInstance(String classname) {
    	
    	synchronized(registry){
	        Object singleton = map.get(classname);
	
	        if (singleton != null) {
	            log.debug("return Singleton =" + classname);
	            return singleton;
	        }
	        try {
	            singleton = Class.forName(classname).newInstance();
	            map.put(classname, singleton);
	            log.debug("created Singleton =" + singleton + " classname =" + classname);
	        } catch (ClassNotFoundException cnf) {
	            log.fatal("Couldn't find class " + classname);
	        } catch (InstantiationException ie) {
	            log.fatal("Couldn't instantiate an object of type " +
	                      classname);
	        } catch (IllegalAccessException ia) {
	            log.fatal("Couldn't access class " + classname);
	        }
	
	        return singleton;
    	}
    }
}
