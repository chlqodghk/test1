package afnid.cm;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.transaction.TransactionException;

import egovframework.rte.fdl.cmmn.exception.EgovBizException;

/**
 * Message for the use of resources and ReloadableResourceBundleMessageSource class implementation of MessageSource interface
 * @author Common Services team yimunjun
 * @since 2009.06.01
 * @version 1.0
 * @see
 *
 * <pre>
 * << Revision history(Modification Information) >>
 *   
 *   Modified      Modifiers           Modifications
 *  -------    --------    ---------------------------
 *   2009.03.11  Yimunjun         The first generation
 *
 * </pre>
 */

public class NidEcptMsgHndlr  {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());
	/**
	 * Views defined messages
	 * @param code - Message Code
	 * @return String
	 */	
	public String exceptionProcess(Exception e, NidMessageSource nidMessageSource) {
		String msg ="";
		
		if(nidMessageSource != null){
			String telNo = nidMessageSource.getMessage("admTelNo");
			if (e instanceof DataAccessException) {
					msg = nidMessageSource.getMessage("datAcesEcpt.msg", new String[]{telNo});
			} else if (e instanceof TransactionException) {
					msg = nidMessageSource.getMessage("trstEcpt.msg", new String[]{telNo});
			} else if (e instanceof EgovBizException) {
				String msgKey = ((EgovBizException) e).getMessageKey();
				if(msgKey.startsWith("pki")){
					msg = e.getMessage();
					if(msg == null || msg.equals("")){
			   			String helpTelNo = nidMessageSource.getMessage("admTelNo");					
						msg =nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{"none", helpTelNo});
					}

				}else{
					msg = nidMessageSource.getMessage("bsnEcpt.msg", new String[]{telNo});
				}
			} else{
				msg = nidMessageSource.getMessage("othrEcpt.msg", new String[]{telNo});
			}
		}else{
			msg = "";
		}
	
		return msg;
	}
	
	/**
	 * Views defined messages
	 * @param code - Message Code
	 * @return String
	 */	
	public String exceptionProcess(String lanCd ,Exception e, NidMessageSource nidMessageSource) {
		String msg ="";

		if(nidMessageSource != null){
			String telNo = nidMessageSource.getMessage(lanCd,"admTelNo");
			if (e instanceof DataAccessException) {
					msg = nidMessageSource.getMessage(lanCd, "datAcesEcpt.msg", new String[]{telNo});
			} else if (e instanceof TransactionException) {
					msg = nidMessageSource.getMessage(lanCd, "trstEcpt.msg", new String[]{telNo});
			} else if (e instanceof EgovBizException) {
				String msgKey = ((EgovBizException) e).getMessageKey();
				if(msgKey.startsWith("pki")){
					msg = e.getMessage();
				}else{
					msg = nidMessageSource.getMessage(lanCd, "bsnEcpt.msg", new String[]{telNo});
				}
			} else{
				msg = nidMessageSource.getMessage(lanCd, "othrEcpt.msg", new String[]{telNo});
			}
		}else{
			msg = "";
		}
	
		return msg;
	}
	
}
