package afnid.cm.mms.service;

import java.util.List;


/** 
 * This service interface is biz-class of main menu-management. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.05.16
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2011.05.16  		Kyung Hwan HWANG				Create
 *
 * </pre>
 */
public interface MainMnMngService {
	
	/**
	 * Retrieves list of top menu. <br>
	 * 
	 * @param vo Input item for retrieving list of top menu(MenuManageVO).
	 * @return List Retrieve list of top menu
	 * @exception Exception
	 */
	List<MainMnMngVO> searchListTopMenu(MainMnMngVO vo) throws Exception;
	
	/**
	 * Retrieves list of right menu. <br>
	 * 
	 * @param vo Input item for retrieving list of right menu(MenuManageVO).
	 * @return List Retrieve list of top menu
	 * @exception Exception
	 */
	List<MainMnMngVO> searchListRightMenu(MainMnMngVO vo) throws Exception;
	
	/**
	 * Retrieves list of right menu. <br>
	 * 
	 * @param vo Input item for retrieving list of screen title(MainMnMngVO).
	 * @return MainMnMngVO Retrieve information of screen title
	 * @exception Exception
	 */
	MainMnMngVO searchScreenTitle(MainMnMngVO vo) throws Exception;
	
	/**
	 * Retrieves program name. <br>
	 * 
	 * @param vo Input item for retrieving list of screen title(MainMnMngVO).
	 * @return MainMnMngVO Retrieve information of screen title
	 * @exception Exception
	 */
	MainMnMngVO searchScreenPopTitle(MainMnMngVO vo) throws Exception;
	
	
	/**
	 * Retrieves program name. <br>
	 * 
	 * @param vo Input item for retrieving list of screen title(MainMnMngVO).
	 * @return MainMnMngVO Retrieve information of screen title
	 * @exception Exception
	 */
	String searchLastLoginInfo(MainMnMngVO vo) throws Exception;
	
	/**
	 * Retrieves list of user role. <br>
	 * 
	 * @param vo Input item for retrieving list of user role(MenuManageVO).
	 * @return List Retrieve list of user role
	 * @exception Exception
	 */
	List<MainMnMngVO> searchListUserAthr(MainMnMngVO vo) throws Exception;	
}
