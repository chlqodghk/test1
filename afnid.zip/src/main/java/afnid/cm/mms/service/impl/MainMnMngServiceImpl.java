package afnid.cm.mms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.mms.service.MainMnMngVO;
import afnid.cm.mms.service.MainMnMngService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;

import egovframework.rte.fdl.cmmn.AbstractServiceImpl;

/** 
 * This service class is biz-class of main menu-management
 * and implements NidMainMenuManageService class.
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.05.16
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.05.16  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */

@Service("mainMnMngService")
public class MainMnMngServiceImpl extends AbstractServiceImpl implements MainMnMngService {
	@Resource(name="mainMnMngDAO")
    private MainMnMngDAO mainMnMngDAO;
	
	/**
	 * Biz-method for retrieving list of top menu. <br>
	 * 
	 * @param vo Input item for retrieving list of top menu(MainMnMngVO).
	 * @return List Retrieve list of menu
	 * @exception Exception
	 */
	public List<MainMnMngVO> searchListTopMenu(MainMnMngVO vo) throws Exception {
		
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		List<String> authorList = NidUserDetailsHelper.getAuthorities();
		
		vo.setUserSeqNo(user.getUserSeqNo());
		vo.setUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd());
		vo.setMakeQuery(authorList);
		
   		return mainMnMngDAO.selectListTopMenu(vo);
	}
	
	/**
	 * Biz-method for retrieving list of right menu. <br>
	 * 
	 * @param vo Input item for retrieving list of right menu(MainMnMngVO).
	 * @return List Retrieve list of menu
	 * @exception Exception
	 */
	public List<MainMnMngVO> searchListRightMenu(MainMnMngVO vo) throws Exception {
		
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		List<String> authorList = NidUserDetailsHelper.getAuthorities();

		vo.setUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd());
		vo.setMakeQuery(authorList);

   		return mainMnMngDAO.selectListRightMenu(vo);
	}
	
	/**
	 * Biz-method for retrieving information of screen title <br>
	 * 
	 * @param vo Input item for retrieving information of screen title(MainMnMngVO).
	 * @return List Retrieve list of menu
	 * @exception Exception
	 */
	public MainMnMngVO searchScreenTitle(MainMnMngVO vo) throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		
   		return mainMnMngDAO.selectScreenTitle(vo);
	}
	
	/**
	 * Biz-method for retrieving information of popup screen title <br>
	 * 
	 * @param vo Input item for retrieving information of screen title(MainMnMngVO).
	 * @return List Retrieve list of menu
	 * @exception Exception
	 */
	public MainMnMngVO searchScreenPopTitle(MainMnMngVO vo) throws Exception {
		if(vo.getLogoutYn() == null || vo.getLogoutYn().equals("")) { // 로그인 화면에서
			/** Loading session information  */
			//LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			//vo.setUseLangCd(user.getUseLangCd());
			Object obj = NidUserDetailsHelper.getAuthenticatedUser();
			if (obj instanceof String) {
				return mainMnMngDAO.selectScreenPopTitle(vo);
			}
			if(obj != null){
				LgnVO user = (LgnVO)obj;
				vo.setUseLangCd(user.getUseLangCd());
			}
		} 

		
   		return mainMnMngDAO.selectScreenPopTitle(vo);
	}
	

	/**
	 * Biz-method for retrieving information of popup screen title <br>
	 * 
	 * @param vo Input item for retrieving information of screen title(MainMnMngVO).
	 * @return List Retrieve list of menu
	 * @exception Exception
	 */
	public String searchLastLoginInfo(MainMnMngVO vo) throws Exception {		
		
		return (String)mainMnMngDAO.selectLastLoginInfo(vo);
	}
	
	/**
	 * Biz-method for retrieving list of user role. <br>
	 * 
	 * @param vo Input item for retrieving list of user role(MainMnMngVO).
	 * @return List Retrieve list of user role
	 * @exception Exception
	 */
	public List<MainMnMngVO> searchListUserAthr(MainMnMngVO vo) throws Exception {
		
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd());

   		return mainMnMngDAO.selectListUserAthr(vo);
	}	
}
