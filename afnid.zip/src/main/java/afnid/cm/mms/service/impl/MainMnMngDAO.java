package afnid.cm.mms.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

import afnid.cm.mms.service.MainMnMngVO;

/** 
 * This class is Database Access Object of main menu-management
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.05.16
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.05.16  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */

@Repository("mainMnMngDAO")
public class MainMnMngDAO extends EgovAbstractDAO {
	/**
	 * DAO-method for retrieving detail Information of top menu. <br>
	 * 
	 * @param vo Input item for retrieving detail information of top menu(MainMnMngVO).
	 * @return ProgrmManageVO Retrieve detail information of top menu
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")	
	public List<MainMnMngVO> selectListTopMenu(MainMnMngVO vo) throws Exception{
		return list("mainMnMngDAO.selectListTopMenu", vo);
	}
	
	/**
	 * DAO-method for retrieving detail Information of right menu. <br>
	 * 
	 * @param vo Input item for retrieving detail information of right menu(MainMnMngVO).
	 * @return ProgrmManageVO Retrieve detail information of right menu
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")	
	public List<MainMnMngVO> selectListRightMenu(MainMnMngVO vo) throws Exception{
		return list("mainMnMngDAO.selectListRightMenu", vo);
	}
	
	/**
	 * DAO-method for retrieving detail Information of screen title. <br>
	 * 
	 * @param vo Input item for retrieving detail information of screen title(MainMnMngVO).
	 * @return ProgrmManageVO Retrieve detail information of screen title
	 * @exception Exception
	 */
	public MainMnMngVO selectScreenTitle(MainMnMngVO vo) throws Exception{
		return (MainMnMngVO)selectByPk("mainMnMngDAO.selectScreenTitle", vo);
	}
	
	/**
	 * DAO-method for retrieving detail Information of popup screen title. <br>
	 * 
	 * @param vo Input item for retrieving detail information of screen title(MainMnMngVO).
	 * @return ProgrmManageVO Retrieve detail information of screen title
	 * @exception Exception
	 */
	public MainMnMngVO selectScreenPopTitle(MainMnMngVO vo) throws Exception{
		return (MainMnMngVO)selectByPk("mainMnMngDAO.selectScreenPopTitle", vo);
	}

	
	/**
	 * DAO-method for retrieving detail Information of popup screen title. <br>
	 * 
	 * @param vo Input item for retrieving detail information of screen title(MainMnMngVO).
	 * @return ProgrmManageVO Retrieve detail information of screen title
	 * @exception Exception
	 */
	public String selectLastLoginInfo(MainMnMngVO vo) throws Exception {
		return (String)selectByPk("mainMnMngDAO.selectLastLoginInfo", vo);
	}
	
	/**
	 * DAO-method for retrieving list of user role. <br>
	 * 
	 * @param vo Input item for retrieving list of user role(MainMnMngVO).
	 * @return ProgrmManageVO Retrieve list of user role
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")	
	public List<MainMnMngVO> selectListUserAthr(MainMnMngVO vo) throws Exception{
		return list("mainMnMngDAO.selectListUserAthr", vo);
	}	
}
