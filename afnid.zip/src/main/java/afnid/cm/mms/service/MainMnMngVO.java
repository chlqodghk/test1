package afnid.cm.mms.service;

import java.util.List;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of main menu-management
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.05.16
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.05.16  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */
public class MainMnMngVO extends ComDefaultVO  {
	private static final long serialVersionUID = 1L;
    
	/** User Seq No */
	private java.lang.String userSeqNo;
	
	/** User ID */
    private java.lang.String userId;
    
    
    /** MN_ID */
    private java.lang.String mnId;
    
    /** UPR_MN_NO */
    private java.lang.String uprMnId;
    
    /** Upper Menu Name */
    private java.lang.String uprMnNm;
    
    /** PST_MN_NM */
    private java.lang.String pstMnNm;
    
    /** DR_MN_NM */
    private java.lang.String drMnNm;
    
    /** Menu Name */
    private java.lang.String mnNm;
    
    /** MN_SOT_NO */
    private java.lang.String mnSotNo;
    
    /** PST_MN_DS */
    private java.lang.String pstMnDs;
    
    /** DR_MN_DS */
    private java.lang.String drMnDs;
    
    /** PGM_ID */
    private java.lang.String pgmId;
    
    /** FST_RGST_ID */
    private java.lang.String fstRgstId;
    
    /** FST_RGST_DT */
    private java.lang.String fstRgstDt;
    
    /** LST_UDT_ID */
    private java.lang.String lstUdtId;
    
    /** LST_UDT_DT */
    private java.lang.String lstUdtDt;
    
    /** Menu Description */
    private java.lang.String mnDs;
    
    /** Use Language Code */
    private java.lang.String useLangCd;
    
    /** Program File Name */
    private java.lang.String pgmNm;
    
    /**Menu Path */
    private java.lang.String mnPath;
    
    /**Menu Level */
    private java.lang.String mnLvl;
    
    /** Page Url */
    private java.lang.String pageUrl;
    
    /** Request Program ID */
    private java.lang.String reqPgmId;
    
    /** Sub Menu ID */
    private java.lang.String subMnId;
    
    /** Make Query */
	private List<String> makeQuery;
	
	/** Navigation Bar */
	private String naviBar;
	
	/** Navigation Bar */
	private String naviBar1;
	
	/** Navigation Bar */
	private String naviBar2;
	
	/** Current Menu Name */
	private String curMnId;
	
	/** Current Menu Name */
	private String curMnNm;
	
	/** Program File Name */
	private String pgmFleNm;
	
	/** Current System Code */
    private String curSystemCd;
    
    /** Top Menu ID */
    private String topMnId;
    
    /* Top Menu Name */
    private String topMnNm;
    
    /* Board ID */
    private String id;
    
    
    /** Current Language Code */
    private String curLangCd;
    
    private String logoutYn;
    
    
	private String trxID;
	private String bsnMsg;
	private String bsnMsgNo;
	private String rsdtNo;
	private String rsdtNoDp;
	private String athrNm;
	private String mnYn;
	
	public String getLogoutYn() {
		return logoutYn;
	}

	public void setLogoutYn(String logoutYn) {
		this.logoutYn = logoutYn;
	}

	public String getCurLangCd() {
		return curLangCd;
	}

	public void setCurLangCd(String curLangCd) {
		this.curLangCd = curLangCd;
	}

	public java.lang.String getUserId() {
		return userId;
	}

	public void setUserId(java.lang.String userId) {
		this.userId = userId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTopMnId() {
		return topMnId;
	}

	public void setTopMnId(String topMnId) {
		this.topMnId = topMnId;
	}

	public String getTopMnNm() {
		return topMnNm;
	}

	public void setTopMnNm(String topMnNm) {
		this.topMnNm = topMnNm;
	}

	public String getCurSystemCd() {
		return curSystemCd;
	}

	public void setCurSystemCd(String curSystemCd) {
		this.curSystemCd = curSystemCd;
	}

	public String getPgmFleNm() {
		return pgmFleNm;
	}

	public void setPgmFleNm(String pgmFleNm) {
		this.pgmFleNm = pgmFleNm;
	}

	public String getCurMnId() {
		return curMnId;
	}

	public void setCurMnId(String curMnId) {
		this.curMnId = curMnId;
	}

	public String getCurMnNm() {
		return curMnNm;
	}

	public void setCurMnNm(String curMnNm) {
		this.curMnNm = curMnNm;
	}

	public String getNaviBar() {
		return naviBar;
	}

	public void setNaviBar(String naviBar) {
		this.naviBar = naviBar;
	}

	public java.lang.String getSubMnId() {
		return subMnId;
	}

	public void setSubMnId(java.lang.String subMnId) {
		this.subMnId = subMnId;
	}

	public java.lang.String getReqPgmId() {
		return reqPgmId;
	}

	public void setReqPgmId(java.lang.String reqPgmId) {
		this.reqPgmId = reqPgmId;
	}

	public java.lang.String getPageUrl() {
		return pageUrl;
	}

	public void setPageUrl(java.lang.String pageUrl) {
		this.pageUrl = pageUrl;
	}


	public java.lang.String getMnId() {
		return mnId;
	}

	public void setMnId(java.lang.String mnId) {
		this.mnId = mnId;
	}

	public java.lang.String getUprMnId() {
		return uprMnId;
	}

	public void setUprMnId(java.lang.String uprMnId) {
		this.uprMnId = uprMnId;
	}

	public java.lang.String getUprMnNm() {
		return uprMnNm;
	}

	public void setUprMnNm(java.lang.String uprMnNm) {
		this.uprMnNm = uprMnNm;
	}

	public java.lang.String getPstMnNm() {
		return pstMnNm;
	}

	public void setPstMnNm(java.lang.String pstMnNm) {
		this.pstMnNm = pstMnNm;
	}

	public java.lang.String getDrMnNm() {
		return drMnNm;
	}

	public void setDrMnNm(java.lang.String drMnNm) {
		this.drMnNm = drMnNm;
	}

	public java.lang.String getMnSotNo() {
		return mnSotNo;
	}

	public void setMnSotNo(java.lang.String mnSotNo) {
		this.mnSotNo = mnSotNo;
	}

	public java.lang.String getPstMnDs() {
		return pstMnDs;
	}

	public void setPstMnDs(java.lang.String pstMnDs) {
		this.pstMnDs = pstMnDs;
	}

	public java.lang.String getDrMnDs() {
		return drMnDs;
	}

	public void setDrMnDs(java.lang.String drMnDs) {
		this.drMnDs = drMnDs;
	}

	public java.lang.String getPgmId() {
		return pgmId;
	}

	public void setPgmId(java.lang.String pgmId) {
		this.pgmId = pgmId;
	}

	public java.lang.String getFstRgstId() {
		return fstRgstId;
	}

	public void setFstRgstId(java.lang.String fstRgstId) {
		this.fstRgstId = fstRgstId;
	}

	public java.lang.String getFstRgstDt() {
		return fstRgstDt;
	}

	public void setFstRgstDt(java.lang.String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}

	public java.lang.String getLstUdtId() {
		return lstUdtId;
	}

	public void setLstUdtId(java.lang.String lstUdtId) {
		this.lstUdtId = lstUdtId;
	}

	public java.lang.String getLstUdtDt() {
		return lstUdtDt;
	}

	public void setLstUdtDt(java.lang.String lstUdtDt) {
		this.lstUdtDt = lstUdtDt;
	}

	public java.lang.String getMnDs() {
		return mnDs;
	}

	public void setMnDs(java.lang.String mnDs) {
		this.mnDs = mnDs;
	}

	public java.lang.String getUseLangCd() {
		return useLangCd;
	}

	public void setUseLangCd(java.lang.String useLangCd) {
		this.useLangCd = useLangCd;
	}

	public java.lang.String getPgmNm() {
		return pgmNm;
	}

	public void setPgmNm(java.lang.String pgmNm) {
		this.pgmNm = pgmNm;
	}

	public List<String> getMakeQuery() {
		return makeQuery;
	}
	

	public java.lang.String getMnPath() {
		return mnPath;
	}

	public void setMnPath(java.lang.String mnPath) {
		this.mnPath = mnPath;
	}

	public void setMakeQuery(List<String> makeQuery) {
		this.makeQuery = makeQuery;
	}

	public java.lang.String getMnNm() {
		return mnNm;
	}

	public void setMnNm(java.lang.String mnNm) {
		this.mnNm = mnNm;
	}

	public java.lang.String getMnLvl() {
		return mnLvl;
	}

	public void setMnLvl(java.lang.String mnLvl) {
		this.mnLvl = mnLvl;
	}

	public String getNaviBar1() {
		return naviBar1;
	}

	public void setNaviBar1(String naviBar1) {
		this.naviBar1 = naviBar1;
	}

	public String getNaviBar2() {
		return naviBar2;
	}

	public void setNaviBar2(String naviBar2) {
		this.naviBar2 = naviBar2;
	}

	public java.lang.String getUserSeqNo() {
		return userSeqNo;
	}

	public void setUserSeqNo(java.lang.String userSeqNo) {
		this.userSeqNo = userSeqNo;
	}

	public String getTrxID() {
		return trxID;
	}

	public void setTrxID(String trxID) {
		this.trxID = trxID;
	}

	public String getBsnMsg() {
		return bsnMsg;
	}

	public void setBsnMsg(String bsnMsg) {
		this.bsnMsg = bsnMsg;
	}

	public String getBsnMsgNo() {
		return bsnMsgNo;
	}

	public void setBsnMsgNo(String bsnMsgNo) {
		this.bsnMsgNo = bsnMsgNo;
	}

	public String getRsdtNo() {
		return rsdtNo;
	}

	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}

	public String getRsdtNoDp() {
		return rsdtNoDp;
	}

	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}

	public String getAthrNm() {
		return athrNm;
	}

	public void setAthrNm(String athrNm) {
		this.athrNm = athrNm;
	}

	public String getMnYn() {
		return mnYn;
	}

	public void setMnYn(String mnYn) {
		this.mnYn = mnYn;
	}
	
	
    
}
