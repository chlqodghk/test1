package afnid.cm.mms.web;

import java.io.StringWriter;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.board.service.BrdService;
import afnid.cm.cmm.error.ErrorHandler;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.mms.service.MainMnMngVO;
import afnid.cm.mms.service.MainMnMngService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.fdl.property.EgovPropertyService;

/** 
 * This Controller class processes request of main menu management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.05.16
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.05.16  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */

@Controller
public class MainMnMngController {
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
	/** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** NidMainMenuManageService */
	@Resource(name = "mainMnMngService")
    private MainMnMngService mainMnMngService;

    /** brdService */
	@Resource(name = "brdService")
    private BrdService brdService;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /**
     * Retrieves list of top menu.  <br>
     * 
     * @param MainMenuManageVO Value-object of top menu to be parsed request(MainMnMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/NidTopMenu.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/NidTopMenu.do")
    public String NidTopMenu(
    		@ModelAttribute("mainMenuManageVO") MainMnMngVO mainMnMngVO,
    		HttpServletRequest request,
    		ModelMap model)
            throws Exception { 
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();

    		//resent massage yn
    		
    		if(!"N".equals(user.getNticYn())){
        		int newNticRng = propertiesService.getInt("newNticRng");    		
        		int nticCnt=  brdService.searchNticYn(newNticRng);    			
	    		if(nticCnt > 0){
	    			NidUserDetailsHelper.changeNticYnSet("Y");
	    		} else{
	    			NidUserDetailsHelper.changeNticYnSet("N");
	    		}
    		}
    		
    		int  brdNewCn = brdService.searchNticYn(0);
    		model.addAttribute("brdNewCn", brdNewCn);
    		
    		MainMnMngVO mainMenuManageVO = mainMnMngVO;
    		List<MainMnMngVO> lstTopMenu = mainMnMngService.searchListTopMenu(mainMenuManageVO);
    		
    		model.addAttribute("lstTopMenu", lstTopMenu);
    		
    		//메뉴추가
    		if(mainMenuManageVO.getTopMnId() == null || mainMenuManageVO.getTopMnId().equals("")) { //Top Menu Id 세션 정보에서 가져옴
    			mainMenuManageVO	 = (MainMnMngVO)request.getSession().getAttribute("mainMenuManageVO");
    		} else { // Menu Id 세션 정보에 저장
    			request.getSession().removeAttribute("mainMenuManageVO"); // 기존 메뉴세션정보 Remove
    			request.getSession().setAttribute("mainMenuManageVO", mainMenuManageVO);
    		}
	    	List<MainMnMngVO> lstRighMenu = mainMnMngService.searchListRightMenu(mainMenuManageVO);
	    	model.addAttribute("mainMenuManageVO", mainMenuManageVO);
	    	model.addAttribute("lstRighMenu", lstRighMenu);
	    	model.addAttribute("userNm", user.getNm());
	    	model.addAttribute("userId", user.getUserId());
	    	model.addAttribute("nticYn", user.getNticYn());	
	    	model.addAttribute("useLangCd", user.getUseLangCd());	
	    	model.addAttribute("tamNm", user.getTamCdNm());
	    	model.addAttribute("lstRighMenuCnt", lstRighMenu.size());
	    	
	    	MainMnMngVO rowDat = new MainMnMngVO();
	    	int roleCnt = 0;
	    	if(lstRighMenu != null && !lstRighMenu.isEmpty()){
	    		for(int i=0; i< lstRighMenu.size();i++){
	    			rowDat = lstRighMenu.get(i);
	    			if("N".equals(rowDat.getMnYn())){
	    				roleCnt = roleCnt + 1;
	    			}
	    		}
	    	}
	    	
	    	model.addAttribute("roleCnt", roleCnt);
	    	
			if(user.getUseLangCd().equals("1") ){
			     model.addAttribute("useOrgzNm", user.getPstOrgnzNm());
			     model.addAttribute("useOfcalPsnNm", user.getPstOfcalPsnNm());
			} else if (user.getUseLangCd().equals("2")) {
				model.addAttribute("useOrgzNm", user.getDrOrgnzNm());		
				model.addAttribute("useOfcalPsnNm", user.getDrOfcalPsnNm());
			} else if ( user.getUseLangCd().equals("3")) {
				model.addAttribute("useOrgzNm", user.getEnOrgnzNm());		
				model.addAttribute("useOfcalPsnNm", user.getEnOfcalPsnNm());				
			} else {
			     model.addAttribute("useOrgzNm", user.getPstOrgnzNm());
			     model.addAttribute("useOfcalPsnNm", user.getPstOfcalPsnNm());				
			}
				
			List<MainMnMngVO> lstRole = mainMnMngService.searchListUserAthr(mainMenuManageVO);
			model.addAttribute("lstRole", lstRole);	
			
			StringBuffer lstRoleStr = new StringBuffer();
			MainMnMngVO rowData = new MainMnMngVO();
			for(int i=0; i< lstRole.size(); i++){
				rowData = lstRole.get(i);
				lstRoleStr.append(rowData.getAthrNm());
				if(i != lstRole.size()){
					lstRoleStr.append("\n");
				}
			}
			model.addAttribute("lstRoleCnt", lstRole.size());
			model.addAttribute("lstRole", lstRoleStr);
			
			MainMnMngVO vo = new MainMnMngVO();
			vo.setUserId(user.getUserId());
			vo.setCurLangCd(user.getUseLangCd());
			model.addAttribute("langcd", user.getUseLangCd());		
			String loginInfo = (String)mainMnMngService.searchLastLoginInfo(vo);
			model.addAttribute("loginInfo", loginInfo);
    		
			int sesonChkTm = propertiesService.getInt("sesonChkTm");
			model.addAttribute("sesonChkTm", sesonChkTm);
    		
    		int sesonEstnTm = propertiesService.getInt("sesonEstnTm");
			model.addAttribute("sesonEstnTm", sesonEstnTm);
			
			model.addAttribute("enLgnYn", user.getEnLgnYn());
			model.addAttribute("useLangCd", user.getUseLangCd());
			
	    	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("22"); // Setting Group Code
			List<CmCmmCdVO> langList = cmmCdMngService.searchListCmmCdDesc(cmCmmCd); // Common Code List Interface Call
			model.addAttribute("langList", langList);
			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
    	
        return "/NidTopMenu";
    }

    
    /**
     * Move to link header screen.  <br>
     * 
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/NidLinkHeader.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/NidLinkHeader.do")
    public String NidLinkHeader(ModelMap model) throws Exception { 
    	try {
	    	/** Loading session information */
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			//model.addAttribute("curSystem", user.getCurSystemCd().toLowerCase());
			
			if("1".equals(user.getUseLangCd())){
				model.addAttribute("useLangCd", "ps");
			}else if("2".equals(user.getUseLangCd())){
				model.addAttribute("useLangCd", "dr");
			}else if("3".equals(user.getUseLangCd())){
				model.addAttribute("useLangCd", "en");
			}else{ 
				model.addAttribute("useLangCd", "ps");
			}
    	} catch(Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
		
       	return "/NidLinkHeader";
    }    

    /**
     * Move to header screen.  <br>
     * 
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/NidHeader.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/NidHeader.do")
    public String NidHeader(ModelMap model) throws Exception { 
    	/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		model.addAttribute("curSystem", user.getCurSystemCd().toLowerCase());
		model.addAttribute("userId", user.getUserId());
		
		model.addAttribute("userNm", user.getNm());
		
		if(user.getUseLangCd().equals("1")){
		     model.addAttribute("useOrgzNm", user.getPstOrgnzNm());
		} else {
			model.addAttribute("useOrgzNm", user.getDrOrgnzNm());		
		}
		
       	return "/NidHeader";
    }    
    
    /**
     * Move to footer screen.  <br>
     * 
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/NidFooter.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/NidFooter.do")
    public String NidFooter(ModelMap model) throws Exception { 
    	try {
	    	/** Loading session information */
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			model.addAttribute("curSystem", user.getCurSystemCd().toLowerCase());
			
			if("1".equals(user.getUseLangCd())){
				model.addAttribute("useLangCd", "ps");
			}else if("2".equals(user.getUseLangCd())){
				model.addAttribute("useLangCd", "dr");
			}else if("3".equals(user.getUseLangCd())){
				model.addAttribute("useLangCd", "en");
			}else{ 
				model.addAttribute("useLangCd", "ps");
			}
    	} catch(Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
    	
       	return "/NidFooter";
    }    
    
    /**
     * Move to screen title screen.  <br>
     * 
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/NidScreenTitle.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/NidScreenTitle.do")
    public String NidScreenTitle(
    		@ModelAttribute("menuManageVO") MainMnMngVO mainMnMngVO, 
    		HttpServletRequest request, 
    		ModelMap model) throws Exception {
    	
    	try {
    		StringBuffer jspUri = new StringBuffer();
    		MainMnMngVO mainMenuManageVO = mainMnMngVO;
    		if(mainMenuManageVO.getTopMnId() == null || mainMenuManageVO.getTopMnId().equals("")) { //Top Menu Id 세션 정보에서 가져옴
    			mainMenuManageVO	 = (MainMnMngVO)request.getSession().getAttribute("mainMenuManageVO");
    		}  else {
    			request.getSession().removeAttribute("mainMenuManageVO"); // 기존 메뉴세션정보 Remove
    			request.getSession().setAttribute("mainMenuManageVO", mainMenuManageVO);
    		}
    		
    		// Board
    		String brdId = mainMenuManageVO.getId();
 
    		//
    		String pgmFleNm = request.getRequestURI();
    		if(pgmFleNm != null && !pgmFleNm.equals("")) {
    			jspUri.append(pgmFleNm.substring(18));
    			if(brdId != null && !"".equals(brdId)) {
    				jspUri.append("?id=");
    				jspUri.append(brdId);
        		}
    		}
    			
    		mainMenuManageVO.setPgmFleNm(jspUri.toString());
    		
    		// 네비게이션 바 및 화면명 가져옴.
    		mainMenuManageVO = mainMnMngService.searchScreenTitle(mainMenuManageVO);
    		
    		// 시스템 코드
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		mainMenuManageVO.setCurSystemCd(user.getCurSystemCd().toLowerCase());
    		
    		model.addAttribute("mainMenuManageVO", mainMenuManageVO);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
    	return "/NidScreenTitle";
    }
    
    /**
     * Move to screen title popup-screen.  <br>
     * 
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/NidScreenPopTitle.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/NidScreenPopTitle.do")
    public String NidScreenPopTitle(Map<String, String> commandMap, 
    		@ModelAttribute("menuManageVO") MainMnMngVO mainMnMngVO, 
    		HttpServletRequest request, 
    		ModelMap model) throws Exception {
    	String jspUri = null;
    	try {
    		MainMnMngVO mainMenuManageVO = mainMnMngVO;
    		String langCd = (String)commandMap.get("langcd");
    		
    		MainMnMngVO mainMenu	 = (MainMnMngVO)request.getSession().getAttribute("mainMenuManageVO");
    		
    		if(langCd != null && !langCd.equals("")) {
    			mainMenuManageVO.setLogoutYn("Y");
    			mainMenuManageVO.setUseLangCd(langCd);
    			//mainMenuManageVO.setCurSystemCd("cm");
    		} 
    		
    		
    		String pgmFleNm = request.getRequestURI();
    		if(pgmFleNm != null && !pgmFleNm.equals("")){
    			jspUri = pgmFleNm.substring(18);
    		}
    		if(mainMenu != null) { 
    			mainMenuManageVO.setPgmFleNm(jspUri);
    		} else { 
    			mainMenuManageVO.setPgmFleNm(jspUri);
    		}
    		
    		mainMenuManageVO = mainMnMngService.searchScreenPopTitle(mainMenuManageVO);

    		if(langCd != null && !langCd.equals("")) {
    			mainMenuManageVO.setCurSystemCd("cm");
    		} else {
    			if (NidUserDetailsHelper.getAuthenticatedUser() instanceof String) {
    				mainMenuManageVO.setCurSystemCd("cm");
    			}else{
    				LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    				mainMenuManageVO.setCurSystemCd(user.getCurSystemCd().toLowerCase());
    			}
    		}
    		
    		model.addAttribute("mainMenuManageVO", mainMenuManageVO);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
    	return "/NidScreenPopTitle";
    }
    
    
 
    
 
    
	@RequestMapping(value="/cm/cmm/accessDenied.do")
    public String accessDenied(
    		HttpServletRequest request,
    		Model model) throws Exception {
		log.debug("================= Access Denied ======================");
    	return "redirect:/cm/uat/actionMain.do?flag=L";
    }

	/**
     * Move to address screen.  <br>
     * 
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/NidAddress.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/NidAddress.do")
    public String NidAddress(Model model) throws Exception { 
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("nidAdLang", user.getUseLangCd());
	    } catch (Exception e) {
			log.error(e.getMessage(), e);
			model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
		}
       	return "/NidAddress";
    } 
    
    
	/**
     * Move to address screen.  <br>
     * 
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/NidOrgnz.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/NidOrgnz.do")
    public String NidOrgnz(Model model) throws Exception { 
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("nidAdLang", user.getUseLangCd());
	    } catch (Exception e) {
			log.error(e.getMessage(), e);
			model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
		}
       	return "/NidOrgnz";
    } 
    
    
	/**
     * Move to address screen.  <br>
     * 
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/NidAddress.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/NidSesonTmEtsn.do")
    public String NidSesonTmEtsn(Model model) throws Exception { 

       	return "/NidSesonTmEtsn";
    } 

    /**
     * Check out the pop-up screen time.  <br>
     * 
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/NidScreenPopSesonTm.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/getSesonTm.do")
    public void getSesonTm(Model model, HttpServletResponse response) throws Exception { 
    	try{
    		int sesonChkTm = propertiesService.getInt("sesonChkTm");
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);			
    		Element sesonTm ;
    		
    		sesonTm = doc.createElement("sesonTm");
    		sesonTm.appendChild(doc.createTextNode( String.valueOf(sesonChkTm) ));
    		
    		root.appendChild(sesonTm);
    		
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    		
	    } catch (Exception e) {
			log.error(e.getMessage(), e);
			model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
		}

    }
    
    
    /**
     * Check out the pop-up screen time.  <br>
     * 
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/NidScreenPopSesonTm.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/NidScreenPopSesonTm.do")
    public String NidScreenPopSesonTm(Model model) throws Exception { 
    	try{
    		int sesonChkTm = propertiesService.getInt("sesonChkTm");
			model.addAttribute("sesonChkTm", sesonChkTm);
			
    		int sesonEstnTm = propertiesService.getInt("sesonEstnTm");
			model.addAttribute("sesonEstnTm", sesonEstnTm);

	    } catch (Exception e) {
			log.error(e.getMessage(), e);
			model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
		}
       	return "/NidScreenPopSesonTm";
    } 
    
    
    
    /**
     * Move to office digital signatures screen.  <br>
     * 
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/NidSignApplet.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/NidSignApplet.do")
    public String NidSignApplet(Model model) throws Exception {
    	try{
    		
    		String dsSignAppletCode = propertiesService.getString("off.dsSignApplet.code");
    		model.addAttribute("dsSignAppletCode", dsSignAppletCode);
    		
    		String dsSignAppletArc = propertiesService.getString("off.dsSignApplet.archive");
    		model.addAttribute("dsSignAppletArc", dsSignAppletArc);
    		
    		String dsSignAppletCodebase = propertiesService.getString("off.dsSignApplet.url");
    		model.addAttribute("dsSignAppletCodebase", dsSignAppletCodebase);
    		
    		
    	} catch (Exception e) {
			log.error(e.getMessage(), e);
			model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
		}
       	return "/NidSignApplet";
    } 
    

    /**
     * get officer signature.  <br>
     * 
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/p_NidSignApplet.jsp"
     * @exception Exception
     */	
	@RequestMapping(value="/getOficSgnt.do")		
    public String getOficSgnt (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("mainMenuManageVO") MainMnMngVO mainMnMngVO,
    		ModelMap model)
            throws Exception {
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		model.addAttribute("langCd", user.getUseLangCd());
		
		String dsSignAppletCode = propertiesService.getString("off.dsSignApplet.code");
		model.addAttribute("dsSignAppletCode", dsSignAppletCode);
		
		String dsSignAppletArc = propertiesService.getString("off.dsSignApplet.archive");
		model.addAttribute("dsSignAppletArc", dsSignAppletArc);
		
		String dsSignAppletCodebase = propertiesService.getString("off.dsSignApplet.url");
		model.addAttribute("dsSignAppletCodebase", dsSignAppletCodebase);
		
   		return "/p_NidSignApplet";
    }	
	
	
    /**
     * Change system Language Set.  <br>
     *
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "/NidMainHome.do"
     * @exception Exception
     */
    @RequestMapping(value="/NidChangeLang.do")
    public String NidChangeLanguage(Map<String, String> commandMap,
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		HttpServletRequest request,
    		Model model) throws Exception {
    	
    	String language = "";
    	String pageUrl = "";
    	
    	try{
    		
			String langCd  = (String)commandMap.get("useLangCd");
			pageUrl = (String)commandMap.get("pageUrl");
			
			if("1".equals(langCd)) {
				language="ps";
				NidUserDetailsHelper.changeUserLangSet(langCd);
			} else if("2".equals(langCd)) {
				language="dr";
				NidUserDetailsHelper.changeUserLangSet(langCd);
			} else if("3".equals(langCd)) {
				language="en";
				NidUserDetailsHelper.changeUserLangSet(langCd);
			} else {
				language="ps";
				NidUserDetailsHelper.changeUserLangSet("3");
			}
			
			MainMnMngVO mainVO  = new MainMnMngVO();
			int idx = pageUrl.indexOf("?");
			
	    	if(idx > 0) { //If there are any parameters when calling the screen.
	    		String brdParam = pageUrl.substring(idx+4);
	    		mainVO.setId(brdParam); //Board ID Setting
	    		pageUrl=pageUrl+"&language="+language;
	    	} else {
	    		pageUrl=pageUrl+"?language="+language;
	    	}
	    	
	    	log.debug("=========================================================");
	    	log.debug("pageUrl : " + pageUrl);
	    	log.debug("=========================================================");
	    	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    	return "forward:"+pageUrl;
    	

    }
}	
