
package afnid.cm.util.web;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import afnid.cm.NidMessageSource;
import afnid.cm.util.service.ExcelVO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This class is View Object of Download Excel File.
 * 
 * @author Afghanistan National ID Card System Application Team Daesung Kim
 * @since 2013.06.12
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2013.06.12    		Daesung Kim          			Create
 *
 * </pre>
 */
public class ExcelDownloadView extends AbstractExcelView {
	
	/**
	 * create to excel file.
	 * @param model
	 * @param wb
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
	
	@SuppressWarnings("rawtypes")
	@Override
	protected void buildExcelDocument(Map model,
			HSSFWorkbook wb, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		//setting File Name
		ExcelVO excelvo = (ExcelVO)model.get("excelResult");
		response.setHeader("Content-Disposition", "attachment; filename=" + excelvo.getFileName()+".xls"); 
		
		//select way for create sheet about only one kind of sheet or several kinds of sheet
		String flag = excelvo.getSheetFlagId();
		if(flag != null && flag.length()>0){
			setValue(wb, excelvo);
		}else{
			setValueSingle(wb, excelvo);
		}
	}
	
	private void setTitleAndHeader(HSSFWorkbook wb, HSSFSheet sheet, ExcelVO excelvo  )throws Exception{
		
		List<String> headerInfo = excelvo.getHeaderInfo();
		List<Integer> columnWidth = excelvo.getColumnWidth();
		sheet.setDefaultColumnWidth(12);
		HSSFCell cell = null;
		//font setting
		HSSFFont font = wb.createFont();
		font.setFontHeightInPoints((short)20);
		font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		
		//style setting
		HSSFCellStyle style = wb.createCellStyle();
		style.setFont(font);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
				
		// put Title in first cell
		
		cell = getCell(sheet, 0, 0);
		setText(cell, excelvo.getTitle());		
		cell.setCellStyle(style);
		sheet.addMergedRegion(new CellRangeAddress(0,0,0,headerInfo.size()));
		
		//put polling station name
		if(null != excelvo.getPoliStaNm() && !"".equals(excelvo.getPoliStaNm())){
			cell = getCell(sheet, 1, 0);
			setText(cell, excelvo.getPoliStaNm());
			sheet.addMergedRegion(new CellRangeAddress(1,1,0,3));
		}
		//header font and style setting
		font = wb.createFont();
		style = wb.createCellStyle();
		cell = getCell(sheet, 2, 0);
		font.setFontHeightInPoints((short)12);
		font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		style.setFont(font);
		style.setFillForegroundColor(HSSFColor.AQUA.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		
		sheet.setColumnWidth(0, 6*256);
		cell.setCellStyle(style);
		setText(cell, "No.");
		
		// set header information
		for(int i=0; i<headerInfo.size();i++){
			
			sheet.setColumnWidth(i+1, columnWidth.get(i)*256);
			cell = getCell(sheet, 2, i+1);
			cell.setCellStyle(style);
			setText(cell, headerInfo.get(i));

		}
		
	}
	
	
	
	private void setValue(HSSFWorkbook wb, ExcelVO excelvo )throws Exception{
		
		//Create Sheet
		List<String> sheetName = excelvo.getSheetName();
		
		//Male Sheet
		HSSFSheet mSheet = wb.createSheet(sheetName.get(0));	
		setTitleAndHeader(wb, mSheet, excelvo ); 
		
		//Female Sheet
		HSSFSheet wSheet = wb.createSheet(sheetName.get(1));	
		setTitleAndHeader(wb, wSheet, excelvo ); 
				
		List<String> keyId = excelvo.getKeyId();
		List<EgovMap> listValue = excelvo.getListValue();
		String flag = excelvo.getSheetFlagId();
		HSSFCell cell = null;
		String id =null;
		
		int mSheetCnt = 1;
		int wSheetCnt = 1;
		int mRowCnt = 1;
		int wRowCnt = 1;
		int mRow = 1; 
		int wRow = 1; 
		
		//setting value in each cell
		for (int i = 0; i < listValue.size(); i++) {
			
			EgovMap rowValue = listValue.get(i);
			
			//check value about Male or Female(1:Male 2:Female) 		
			if( "1".equals(String.valueOf(rowValue.get(flag))) ){
				
				cell = getCell(mSheet, mRow+2, 0);
				setText(cell, Integer.toString(mRowCnt++));
				
				for(int j = 0; j< keyId.size(); j++){
					cell = getCell(mSheet, mRow+2, j+1);
					id = keyId.get(j);
					setText(cell, (String)rowValue.get(id));	
				}
				mRow++;
				
				//setting max size of a sheet 
				if(60000 < mRow ){
						
					//create new sheet
					mSheet = wb.createSheet(sheetName.get(0)+Integer.toString(mSheetCnt+1));	
					setTitleAndHeader(wb, mSheet, excelvo );
					mSheetCnt++;
					mRow = 1;	
				}
			}else{
				
				cell = getCell(wSheet, wRow+2, 0);
				setText(cell, Integer.toString(wRowCnt++));
				
				for(int j = 0; j< keyId.size(); j++){
					cell = getCell(wSheet, wRow+2, j+1);
					id = keyId.get(j);
					setText(cell, (String)rowValue.get(id));	
				}
				wRow++;
				//setting max size of a sheet 
				if(60000 < wRow ){
				
					//create new sheet
					wSheet = wb.createSheet(sheetName.get(1)+Integer.toString(wSheetCnt+1));	
					setTitleAndHeader(wb, wSheet, excelvo );
					wSheetCnt++;
					wRow = 1;	
				}
			}
							
		}
		
	}
	
	private void setValueSingle(HSSFWorkbook wb, ExcelVO excelvo )throws Exception{
		
		//Create Sheet
		List<String> sheetName = excelvo.getSheetName();
		HSSFSheet sheet = wb.createSheet(sheetName.get(0));	
		setTitleAndHeader(wb, sheet, excelvo );
		
		List<String> keyId = excelvo.getKeyId();
		List<EgovMap> listValue = excelvo.getListValue();
		
		//setting value in each cell
		HSSFCell cell = null;
		String id =null;
		int sheetCnt = 1;
		int rowCnt = 1;
		int row = 1;  
		for (int i = 0; i < listValue.size(); i++) {
			
			EgovMap rowValue = listValue.get(i);				
			cell = getCell(sheet, row+2, 0);
			setText(cell, Integer.toString(rowCnt++));
			
			for(int j = 0; j< keyId.size(); j++){
				cell = getCell(sheet, row+2, j+1);
				id = keyId.get(j);
				setText(cell, (String)rowValue.get(id));	
			}
			row++;	
			
			if(60000 < row ){
				
				//create new sheet
				sheet = wb.createSheet(sheetName.get(0)+Integer.toString(sheetCnt+1));	
				setTitleAndHeader(wb, sheet, excelvo );
				sheetCnt++;
				row = 1;	
			}
		}
		
	}

}
