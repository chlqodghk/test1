/**
 *  Class Name : EgovFileMntrg.java
 *  Description : Check the network information system that provides Business class.
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   -------    --------    ---------------------------
 *   2009.01.13    Jaeyoung Jo          CREATE
 *
 *  @author Jaeyoung Jo
 *  @since 2009. 01. 13
 *  @version 1.0
 *  @see 
 * 
 *  Copyright (C) 2009 by EGOV  All right reserved.
 */
package afnid.cm.util.service;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.StringReader;
import java.io.File;
import java.util.ArrayList;

import org.apache.log4j.Logger;

public class NidFleMntrg extends Thread {
	Logger log = Logger.getLogger(this.getClass());
    /**
     * <p>
     * Change the status of the file to check for Default second static final variables, the default value of 60 seconds is applied
     * </p>
     */
    //static final public long DEFAULT_DELAY = 60000; // 60 sec
    static final public long DEFAULT_DELAY = 30000; // 30 sec
    
    /**
     * The maximum character length
     **/
    static final int MAX_STR_LEN = 1024;
    
    /**
     * <p>
     * Have to check for file changes the file name variable.
     * </p>
     */
    protected String filename;

    /**
     * <p>
     * Change the status of the file to check for Default second static final variables, the default value of 60 seconds is applied{@link
     * #DEFAULT_DELAY}.
     * </p>
     */
    protected long delay = DEFAULT_DELAY;

    File file;      // Target (monitored) directory
    File logFile;   // Monitoring log files for information storage.
    long lastModif = 0;
    boolean warnedAlready = false;
    boolean interrupted = false;
    @SuppressWarnings("rawtypes")
	ArrayList realOriginalList = new ArrayList(); // The first source list.
    @SuppressWarnings("rawtypes")
	ArrayList originalList = new ArrayList();     // Before the list is updated regularly with information before the list.
    @SuppressWarnings("rawtypes")
	ArrayList currentList  = new ArrayList();     // Compared with the present list before the list.
    @SuppressWarnings("rawtypes")
	ArrayList changedList  = new ArrayList();     // Compared with before the list of changes that occurred at the time of listing.
    @SuppressWarnings("rawtypes")
	ArrayList totalChangedList = new ArrayList(); // Changes compared with the initial list of lists.
                                                  // totalChangedList when necessary checkAndConfigure uncommented in the function and use (considering load use).
    int cnt = 0;

    /**
     * <p>
     * Receives as a parameter the name of the file you want to monitor the primary constructor (Constructor).
     * </p>
     *
     * @param filename
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
	protected NidFleMntrg(String filename ,File logFile) {
    	//log.debug("EgovFileMntrg start");
        this.logFile = logFile;
    	this.filename = filename;
        file = new File(filename);
        // 1. The first child of the current directory when creating the information should be stored in an ArrayList. Storage Information ==> absolute path + "," + Last Modified time + "," + size
        File [] fList = file.listFiles();
        for(int i = 0; i<fList.length; i++ ){
            realOriginalList.add(fList[i].getAbsolutePath() + "$"
            		+ getLastModifiedTime(fList[i]) + "$"
            		+ ((fList[i].length()/1024)>0?(fList[i].length()/1024):1) + "KB");
            writeLog("ORI_"+fList[i].getAbsolutePath() + "$" 
            		+ getLastModifiedTime(fList[i]) + "$" 
            		+ ((fList[i].length()/1024)>0?(fList[i].length()/1024):1) + "KB");
        }
        originalList = new ArrayList(realOriginalList);
        writeLog("START");
        setDaemon(true);
        chkAndConfigure();
        //log.debug("EgovFileMntrg end");
    }

    /**
     * <p>
     * Monitoring changes in the file that you want to check whether you want to delay the second set.
     * </p>
     *
     * @param delay Second monitoring period
     */
    public void setDelay(long delay) {
        this.delay = delay;
    }

    /**
     * <p>
     * Change the contents of the file you want to work with the technical abstract method.
     * </p>
     */
    //abstract protected void doOnChange();
    @SuppressWarnings({ "rawtypes", "unchecked" })
	protected void doOnChange(ArrayList changedList){
    	//log.debug("doOnChange() start");
    	for(int i = 0; i<changedList.size(); i++ ){
    		writeLog((String)changedList.get(i));
        }
    	changedList.clear();                         
    	originalList = new ArrayList(currentList);   
        cnt++;
        
        //log.debug("doOnChange() end"); 
    }

    /**
     * <p>
     * Methods to check files for changes.
     * </p>
     */
    @SuppressWarnings({ "unchecked" })
	protected void chkAndConfigure() {
    	//log.debug("chkAndConfigure start");
        try {
        	currentList.clear();
            file = new File(filename);
        	// ArrayList and put on the current information.
            File[] fList = file.listFiles();
            for(int i = 0; i<fList.length; i++ ){
                currentList.add(fList[i].getAbsolutePath() + "$"
                		+ getLastModifiedTime(fList[i]) + "$"
                		+ ((fList[i].length()/1024)>0?(fList[i].length()/1024):1) + "KB");
            }
            /*
            for(int i = 0; i<originalList.size(); i++ ){
                //log.debug("in chkAndConfigure() ::: originalList:" + originalList.get(i));
            }
        	for(int i = 0; i<currentList.size(); i++ ){
                //log.debug("in chkAndConfigure() ::: currentList:" + currentList.get(i));
            }
        	*/
            boolean isSame = false;
            boolean isNew  = true;
            boolean isDel = true;
            String  str1   = "";
            String  str2   = "";
            
            // The current sub-directory information is compared with the second lowest directory information. Should determine if deleted.
            for(int i = 0; i < originalList.size() ; i++){
            	for(int j = 0; j < currentList.size(); j++){
                    str1 = (String)originalList.get(i);
                    str2 = (String)currentList.get(j);
                    if(str1.substring(0, str1.indexOf("$")).equals( str2.substring(0, str2.indexOf("$"))) ){
                    	isDel = false;
                    }
                }
                if(isDel){
                	changedList.add("DEL$"+originalList.get(i));
                }
                isDel = true;  // Initialization
            }
            
            // The current sub-directory information is compared with the first sub-directory information (if newly created or modified should determine)
            for(int i = 0; i < currentList.size() ; i++){
            	for(int j = 0; j < originalList.size(); j++){
                    if(((String)currentList.get(i)).equals((String)originalList.get(j))){
                    	isSame    = true;
                    }
                    str1 = (String)currentList.get(i);
                    str2 = (String)originalList.get(j);
                    if(str1.substring(0, str1.indexOf("$")).equals( str2.substring(0, str2.indexOf("$"))) ){
                    	isNew = false;
                    }
                }
                if(!isSame){
                    if(isNew){
                    	changedList.add("NEW$"+currentList.get(i));
                        //totalChangedList.add("NEW$"+currentList.get(i));	
                    }else{
                    	changedList.add("MODI$"+currentList.get(i));
                        //totalChangedList.add("MODI$"+currentList.get(i));
                    }
                }
                isSame = false; // Initialization
                isNew  = true;  // Initialization
            }
            
        } catch (Exception e) {
            //interrupted = true; // there is no point in continuing
            log.error(e);
            //return;
        }

        if (changedList.size()>0) {
        	//log.debug("change occur , changed file check count:"+cnt+ " , changed file count:"+changedList.size());
        	doOnChange(changedList);
        }
        
        if (isEnd()){
        	//log.debug("Thread Process END !!! (CNT :"+cnt+")");
            interrupted = true;
        }
        //log.debug("chkAndConfigure end"+changedList.size());
    }

    /**
     * <p>
     * Change the status of the file, in seconds, to keep a check of the method to execute
     * </p>
     */
    public void run() {
        while (!interrupted) {
            try {
                Thread.sleep(delay);
            } catch (InterruptedException e) {
                // no interruption expected
            }
            chkAndConfigure();
        }
        if(interrupted){
        	//log.debug(filename+" Monitering Thread is interrupted");
        	this.interrupt();
        }
    }
    
    /**
     * <pre>
     * Comment : Directory (file) check the last modification of the amount of time (based on the default locale java.util.Locale.KOREA)
     * </pre>
     * @param File f determine the target file modification date
     * @return String result Last modification date is returned as a string.
     */
    public static String getLastModifiedTime(File f){
		long date  = f.lastModified();
		java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyyMMdd:HH:mm:ss",
																			    java.util.Locale.KOREA);
		return dateFormat.format(new java.util.Date(date));
	}
    
    /**
     * <pre>
     * Comment : Directory (file) record log information.
     * </pre>
     * @param String  logStr  To add log information (line-by-line)
     * @return boolean result  Add a Log success 
     */
    public  boolean writeLog(String logStr){
		boolean result = false;
		
		try{	
			FileWriter fWriter = new FileWriter(logFile, true);
			BufferedWriter bWriter = new BufferedWriter(fWriter);
			BufferedReader br = new BufferedReader(new StringReader(logStr));
	        String line = "";
	        while((line = br.readLine()) != null){
	        	if (line.length() <= MAX_STR_LEN){
	        	    bWriter.write(line+"\n", 0 , line.length()+1);
	        	}
	        }
	        br.close();
			bWriter.close();
			fWriter.close();
			result = true;
		}catch(IOException ioe){
			log.error(ioe);
		}catch(Exception e){
			log.error(e);
		}
	
		return result;
	}
    
 
    
    /**
     * <pre>
     * Comment : Check whether the directory monitor shutdown. The log file for the directory is deleted if the monitor is terminated.
     * </pre>
     * @return boolean isEnd To stop monitoring for the end returns true, return false to continue.
     */
    public  boolean isEnd(){
    	//log.debug("isEnd start");
    	boolean isEnd = false;
    	String lastStr = "";
    	
		try{	
			if(logFile.exists()){
				//END at the end of the log file, if you have read the last will shut down
				
				FileReader fr = new FileReader(logFile);
				BufferedReader br = new BufferedReader (fr);
	        	
	        	String line = "";
	        	while((line = br.readLine()) != null){
	        		if (line.length() <= MAX_STR_LEN){
	        		    lastStr = line;
	        		}
	        	}
	            if("END".equals(lastStr)){
	            	isEnd=true;
	            }
			}else{
				//If you do not have the log file (if deleted) also terminates.
				isEnd = true;
			}
		}catch(Exception e){
			log.error(e);

		}
		//log.debug("isEnd end"+isEnd);
		return isEnd;
	}
}

