/**
 * @Class Name  : EgovNumberUtil.java
 * @Description : Number of treatment-related utility data.
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *     -------          --------        ---------------------------
 *   2009.02.13       Samsup Lee                  CREATE
 *
 * @author  Samsup Lee 
 * @since 2009. 02. 13
 * @version 1.0
 * @see 
 * 
 */

package afnid.cm.util.service;

import 	java.security.SecureRandom;
import	java.util.*;
import  java.text.*;

public class NidNoUtil {

    /**
     * Obtain a certain number of functions from a set of random numbers between the numbers obtained from the starting number and the ending will return a random number.
     * 
     * @param startNum 
     * @param endNum 
     * @return Random number
     * @exception MyException
     * @see
     */
    public static int getRandomNum(int startNum, int endNum) {
	int randomNum = 0;

	try {
	    // Generate random objects.
	    SecureRandom rnd = new SecureRandom();

	    do {
		// In the end the number generates a random number.
		randomNum = rnd.nextInt(endNum + 1);
	    } while (randomNum < startNum); 
	} catch (Exception e) {
		e.getMessage();
	}

	return randomNum;
    }

    /**
     * In a set of numbers, the ability to check whether a particular number 12345678-7 provide the ability to check whether or not two.
     * 
     * @param sourceInt - A set of numbers
     * @param searchInt - Search a number
     * @return Presence.
     * @exception MyException
     * @see
     */
    public static Boolean getNumSearchCheck(int sourceInt, int searchInt) {
	String sourceStr = String.valueOf(sourceInt);
	String searchStr = String.valueOf(searchInt);

	//The existence of a certain number of the position value is returned. -1 If not.
	if (sourceStr.indexOf(searchStr) == -1) {
	    return false;
	} else {
	    return true;
	}
    }

    /**
     * The ability to convert a number to a string type to a string number 20081212 '20081212 'ability to convert.
     * 
     * @param srcNumber
     *            - Number
     * @return String
     * @exception MyException
     * @see
     */
    public static String getNumToStrCnvr(int srcNumber) {
	String rtnStr = null;

	try {
	    rtnStr = String.valueOf(srcNumber);
	} catch (Exception e) {
		e.getMessage();
	}

	return rtnStr;
    }
	
	
    /**
     * Numeric type, the ability to convert them to date.
     * Number 20081212 dating type '2008-12-12 ', the ability to convert.
     * @param srcNumber - Number
     * @return String
     * @exception MyException 
     * @see  
     */
    public static String getNumToDateCnvr(int srcNumber) {

	String pattern = null;
	String cnvrStr = null;

	String srcStr = String.valueOf(srcNumber);

	// Date form 8-digit and 14-digit, but normal processing.
	if (srcStr.length() != 8 && srcStr.length() != 14) {
	    throw new IllegalArgumentException("Invalid Number: " + srcStr + " Length=" + srcStr.trim().length());
	}

	if (srcStr.length() == 8) {
	    pattern = "yyyyMMdd";
	} else if (srcStr.length() == 14) {
	    pattern = "yyyyMMddhhmmss";
	}

	SimpleDateFormat dateFormatter = new SimpleDateFormat(pattern, Locale.KOREA);

	Date cnvrDate = null;

	try {
	    cnvrDate = dateFormatter.parse(srcStr);
	} catch (ParseException e) {
		e.getMessage();
	}

	cnvrStr = String.format("%1$tY-%1$tm-%1$td", cnvrDate);

	return cnvrStr;

    }

    /**
     * Check whether or not the number of digits to check the function.
     *If the number of True, or False is returned.
     * @param checkStr - Check the string
     * @return For the number.
     * @exception MyException 
     * @see  
     */	
	public static Boolean getNumberValidCheck(String checkStr) {

	int i;
	//String sourceStr = String.valueOf(sourceInt);

	int checkStrLt = checkStr.length();

	try {
	    for (i = 0; i < checkStrLt; i++) {

		// ASCII value ('0 '-> 48, '9' -> 57)
		if (checkStr.charAt(i) > 47 && checkStr.charAt(i) < 58) {
		    continue;
		} else {
		    return false;
		}
	    }
	} catch (Exception e) {
		e.getMessage();
	}

	return true;
    }

    /**
     * Replaced by another number that features a number 12345678-123 provides the ability to convert to a 999 (99945678).
     * 
     * @param srcNumber - Set of numbers.
     * @param cnvrSrcNumber - The original number.
     * @param cnvrTrgtNumber - Number of substitutions.
     * @return Number of substitutions.
     * @exception MyException
     * @see
     */

    public static int getNumberCnvr(int srcNumber, int cnvrSrcNumber, int cnvrTrgtNumber) {

	// Convert a number to a string inputted.
	String source = String.valueOf(srcNumber);
	String subject = String.valueOf(cnvrSrcNumber);
	String object = String.valueOf(cnvrTrgtNumber);

	StringBuffer rtnStr = new StringBuffer();
	String preStr = "";
	String nextStr = source;

	try {

	    // Number of digits to be converted from the source to find the location.
	    while (source.indexOf(subject) >= 0) {
		preStr = source.substring(0, source.indexOf(subject)); // To convert a number to the location, cut the number.
		nextStr = source.substring(source.indexOf(subject) + subject.length(), source.length());
		source = nextStr;
		rtnStr.append(preStr).append(object); // Convert a number to convert to the target location will insert a number.
	    }
	    rtnStr.append(nextStr); // Gives the number to be converted later to paste the number.
	} catch (Exception e) {
		e.getMessage();
	}

	return Integer.parseInt(rtnStr.toString());
    }

    /**
     * Is a real number, an integer is negative, the ability to check whether the 123 is a mistake, is an integer, providing the ability to check is negative.
     * 
     * @param srcNumber - Set of numbers.
     * @return -1 (Negative), 0 (integer), one (actual number)
     * @exception MyException
     * @see
     */
    public static int checkRlnoInteger(double srcNumber) {

		// byte 1byte 		▶As a number without a decimal point, the range -2 ^ 7-2 ^ 7-1
		// short 2byte		▶As a number without a decimal point, the range -2 ^ 15 to 2 ^ 15-1
		// int 4byte 		▶As a number without a decimal point, the range -2 ^ 31 to 2 ^ 31-1
		// long 8byte		▶As a number without a decimal point, the range -2 ^ 63 to 2 ^ 63-1
	
		// float 4byte		▶As a number with a decimal point, at the end of the F or f The number (for example, 3.14f)
		// double 8byte	▶As a number with a decimal point, and the end is nothing non-stick numbers (for example, 3.14)
		//			▶As a number with a decimal point, a D or d The number at the end (for example, 3.14d)

		String cnvrString = null;
	
		if (srcNumber < 0) {
		    return -1;
		} else {
		    cnvrString = String.valueOf(srcNumber);
	
		    if (cnvrString.indexOf(".") == -1) {
			return 0;
		    } else {
			return 1;
		    }
		}
    }
    
    /**
     * Localized change the number in Arabic numerals.  <br>
     * 
     * @param String 
     * @return String
     * @exception Exception
     */	
    public static String toPerConvetNum(String number){
     		String [] persianNumberArray = new String[]{"۰","۱","۲","۳","۴","۵","۶","۷","۸","۹"};
     		StringBuffer sb = new StringBuffer();
     		if(number != null){
     			boolean flag = false;
  	   		for(int i = 0;  i < number.length(); i++){
  	   			String numChat = number.substring(i,i+1);
  	   			for(int j = 0; j < persianNumberArray.length; j++){
  	   				if(numChat.equals(persianNumberArray[j])){
  	   					sb.append(String.valueOf(j));
  	   					flag = true;
  	   					break;
  	   				}
  	   			}
  	   			if(!flag){
  	   				sb.append(numChat);
  	   			}
  	   			flag = false;
  	   		}
     	}
     	return sb.toString();
    } 
  	
}
