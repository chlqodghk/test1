/**
 * @Class Name  : EgovStringUtil.java
 * @Description : String data processing related utilities.
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *     -------          --------        ---------------------------
 *   2009.01.13     Jungkyu Pask         CREATE
 *   2009.02.13     Samsup Lee         UPDATE
 *
 * @author Jungkyu Pask  
 * @since 2009. 01. 13
 * @version 1.0
 * @see 
 * 
 */

package afnid.cm.util.service;

/*
 * Copyright 2001-2006 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the ";License&quot;);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS"; BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import afnid.cm.code.service.CmCmmCdVO;

public class NidStringUtil {
    /**
     * Empty string <code>""</code>.
     */
    public static final String EMPTY = "";
    
    /**
     * <p>Padding to the maximum value.</p>
     */
    // private static final int PAD_LIMIT = 8192;
    
    /**
     * <p>An array of <code>String</code>s used for padding.</p>
     * <p>Used for efficient space padding. The length of each String expands as needed.</p>
     */
    /*
	private static final String[] PADDING = new String[Character.MAX_VALUE];

	static {
		// space padding is most common, start with 64 chars
		PADDING[32] = "                                                                ";
	}	
     */	
	
    /**
     * When you specify the length of the string exceeds the specified length of the string attached edaga a method.
     * @param source Original string array.
     * @param output Add a string.
     * @param slength Specifies the length.
     * @return Ten combined molecule specifies the length of the string to add to the cut.
     */
    public static String cutString(String source, String output, int slength) {
        String returnVal = null;
        if (source != null) {
            if (source.length() > slength) {
                returnVal = source.substring(0, slength) + output;
            } else
                returnVal = source;
        }
        return returnVal;
    }

    /**
     * Exceed the length of the string when the specified method to delete the string
     * @param source Original string array.
     * @param slength Specifies the length.
     * @return Ten combined molecule specifies the length of the string to add to the cut.
     */
    public static String cutString(String source, int slength) {
        String result = null;
        if (source != null) {
            if (source.length() > slength) {
                result = source.substring(0, slength);
            } else
                result = source;
        }
        return result;
    }    
    
    /**
     * <p>
     *String or empty ("") or null or is verified.
     * </p>
     * 
     * <pre>
     *  StringUtil.isEmpty(null)      = true
     *  StringUtil.isEmpty("")        = true
     *  StringUtil.isEmpty(" ")       = false
     *  StringUtil.isEmpty("bob")     = false
     *  StringUtil.isEmpty("  bob  ") = false
     * </pre>
     * 
     * @param str - Allow to check that a string is an object null.
     * @return <code>true</code> - Received input String is null or an empty string.
     */
    public static boolean isEmpty(String str) {
        return str == null || str.length() == 0;
    }

    
    /**
     * <p>All standards contained in the target character string (char) is removed.</p>
     *
     * <pre>
     * StringUtil.remove(null, *)       = null
     * StringUtil.remove("", *)         = ""
     * StringUtil.remove("queued", 'u') = "qeed"
     * StringUtil.remove("queued", 'z') = "queued"
     * </pre>
     *
     * @param str  That receives the reference string.
     * @param remove  That receives the string to be removed from the destination string.
     * @return Remove the input string, the target string is removed. If the input string is null, the output string is null.
     */
    public static String remove(String str, char remove) {
        if (isEmpty(str) || str.indexOf(remove) == -1) {
            return str;
        }
        char[] chars = str.toCharArray();
        int pos = 0;
        for (int i = 0; i < chars.length; i++) {
            if (chars[i] != remove) {
                chars[pos++] = chars[i];
            }
        }
        return new String(chars, 0, pos);
    }
    
    /**
     * <p>String inside the comma character (,) and all will be removed.</p>
     *
     * <pre>
     * StringUtil.removeCommaChar(null)       = null
     * StringUtil.removeCommaChar("")         = ""
     * StringUtil.removeCommaChar("asdfg,qweqe") = "asdfgqweqe"
     * </pre>
     *
     * @param str That receives the reference string.
     * @return "," The input string has been removed.
     *  If the input string is null, the output string is null.
     */
    public static String removeCommaChar(String str) {
        return remove(str, ',');
    }
    
    /**
     * <p>Inside the string of negative character (-) to remove all.</p>
     *
     * <pre>
     * StringUtil.removeMinusChar(null)       = null
     * StringUtil.removeMinusChar("")         = ""
     * StringUtil.removeMinusChar("a-sdfg-qweqe") = "asdfgqweqe"
     * </pre>
     *
     * @param str  That receives the reference string.
     * @return "-" Input string was removed.
     *  If the input string is null, the output string is null.
     */
    public static String removeMinusChar(String str) {
        return remove(str, '-');
    }
        
    
    /**
     * Contained in Original string to convert a string to a new string method.
     * @param source Original string
     * @param subject Specific strings contained in Original string.
     * @param object The string to convert.
     * @return sb.toString() The converted string in a new string.
     */
    public static String replace(String source, String subject, String object) {
        StringBuffer rtnStr = new StringBuffer();
        String preStr = "";
        String nextStr = source;
        String srcStr  = source;
        
        while (srcStr.indexOf(subject) >= 0) {
            preStr = srcStr.substring(0, srcStr.indexOf(subject));
            nextStr = srcStr.substring(srcStr.indexOf(subject) + subject.length(), srcStr.length());
            srcStr = nextStr;
            rtnStr.append(preStr).append(object);
        }
        rtnStr.append(nextStr);
        return rtnStr.toString();
    }

    /**
     * A string that contains Original string, but the first one with a new method that converts a string
     * @param source Original string.
     * @param subject Specific strings contained in Original string.
     * @param object The string to convert.
     * @return sb.toString() New string converted string / source does not have a specific string, the original string.
     */
    public static String replaceOnce(String source, String subject, String object) {
        StringBuffer rtnStr = new StringBuffer();
        String preStr = "";
        String nextStr = source;
        if (source.indexOf(subject) >= 0) {
            preStr = source.substring(0, source.indexOf(subject));
            nextStr = source.substring(source.indexOf(subject) + subject.length(), source.length());
            rtnStr.append(preStr).append(object).append(nextStr);
            return rtnStr.toString();
        } else {
            return source;
        }
    }

    /**
     * <code> subject </ code> object that is included with each character is converted to.
     * 
     * @param source Original string.
     * @param subject Specific strings contained in Original string.
     * @param object The string to convert.
     * @return sb.toString() The converted string in a new string.
     */
    public static String replaceChar(String source, String subject, String object) {
        StringBuffer rtnStr = new StringBuffer();
        String preStr = "";
        String nextStr = source;
        String srcStr  = source;
        
        char chA;

        for (int i = 0; i < subject.length(); i++) {
            chA = subject.charAt(i);

            if (srcStr.indexOf(chA) >= 0) {
                preStr = srcStr.substring(0, srcStr.indexOf(chA));
                nextStr = srcStr.substring(srcStr.indexOf(chA) + 1, srcStr.length());
                srcStr = rtnStr.append(preStr).append(object).append(nextStr).toString();
            }
        }
        
        return srcStr;
    }  
    
    /**
     * <p> <code> str </ code> of the <code> searchStr </ code> the start (index) returns the position. </ p>
     *
     * <p>Of the input values ​​<code> null </ code> if there is <code> -1 </ code> returns.</p>
     *
     * <pre>
     * StringUtil.indexOf(null, *)          = -1
     * StringUtil.indexOf(*, null)          = -1
     * StringUtil.indexOf("", "")           = 0
     * StringUtil.indexOf("aabaabaa", "a")  = 0
     * StringUtil.indexOf("aabaabaa", "b")  = 2
     * StringUtil.indexOf("aabaabaa", "ab") = 1
     * StringUtil.indexOf("aabaabaa", "")   = 0
     * </pre>
     *
     * @param str Search string.
     * @param searchStr  Search for a string.
     * @return Search of the search string in the target string, the starting position with the Search string is null or -1.
     */
    public static int indexOf(String str, String searchStr) {
        if (str == null || searchStr == null) {
            return -1;
        }
        return str.indexOf(searchStr);
    }    
    
    
    /**
     * <p>Oracle's decode function is a method that has the same functionality as.
     * <code>sourStr</code> and <code> compareStr </ code> equal to the value of
     * <code>returStr</ code> is returned, different <code> defaultStr </ code> is returned.
     * </p>
     * 
     * <pre>
     * StringUtil.decode(null, null, "foo", "bar")= "foo"
     * StringUtil.decode("", null, "foo", "bar") = "bar"
     * StringUtil.decode(null, "", "foo", "bar") = "bar"
     * StringUtil.decode("hi", "hi", null, "bar") = null
     * StringUtil.decode("hi", "hi  ", "foo", null) = null
     * StringUtil.decode("hi", "hi", "foo", "bar") = "foo"
     * StringUtil.decode("hi", "hi", "foo", "bar") = "bar"
     * </pre>
     * 
     * @param sourceStr String to compare.
     * @param compareStr String to be compared.
     * @param returnStr compareStr sourceStr and to be returned when the value of the same string.
     * @param defaultStr compareStr sourceStr and the value of the string to be returned is not the same.
     * @return compareStr sourceStr and have the same value (equal) returnStr when returned,
     *        <br/> different defaultStr returns.
     */
    public static String decode(String sourceStr, String compareStr, String returnStr, String defaultStr) {
        if (sourceStr == null && compareStr == null) {
            return returnStr;
        }
        
        if (sourceStr == null && compareStr != null) {
            return defaultStr;
        }

        if (sourceStr.trim().equals(compareStr)) {
            return returnStr;
        }

        return defaultStr;
    }

    /**
     * <p>Oracle's decode function is a method that has the same functionality as.
     * <code>sourStr</ code> and <code> compareStr </ code> equal to the value of
     * <code>returStr</ code> is returned, different <code> sourceStr </ code> is returned.
     * </p>
     * 
     * <pre>
     * StringUtil.decode(null, null, "foo") = "foo"
     * StringUtil.decode("", null, "foo") = ""
     * StringUtil.decode(null, "", "foo") = null
     * StringUtil.decode("hi", "hi", "foo") = "foo"
     * StringUtil.decode("hi", "hi ", "foo") = "hi"
     * StringUtil.decode("hi", "hi", "foo") = "hi"
     * </pre>
     * 
     * @param sourceStr String to compare.
     * @param compareStr String to be compared.
     * @param returnStrcompareStr sourceStr and to be returned when the value of the same string.
     * @return compareStr sourceStr and have the same value (equal) returnStr when returned,
     *         <br/> different sourceStr returns.
     */
    public static String decode(String sourceStr, String compareStr, String returnStr) {
        return decode(sourceStr, compareStr, returnStr, sourceStr);
    }    
    
    /**
     * To determine if the object is null null "to" change the method.
     * @param object the original object.
     * @return resultVal Sting
     */
    public static String isNullToString(Object object) {
        String string = "";
        
        if (object != null) {
            string = object.toString().trim();
        }
        
        return string;
    }
    
    /**
     *<pre>
     * String is null if the passed-in "" is returned.
     * &#064;param src String values ​​that are likely null value.
     * &#064;return If the value of the String is null &quot;&quot; String Value.
     *</pre>
     */
    public static String nullConvert(Object src) {
	//if (src != null && src.getClass().getName().equals("java.math.BigDecimal")) {
	if (src != null && src instanceof java.math.BigDecimal) {
	    return ((BigDecimal)src).toString();
	}

	if (src == null || src.equals("null")) {
	    return "";
	} else {
	    return ((String)src).trim();
	}
    }
    
    /**
     *<pre>
     * String is null if the passed-in  &quot;&quot;is returned.
     * &#064;param src null value String value that likely.
     * &#064;return If the value of the String is null  &quot;&quot;String Value.
     *</pre>
     */
    public static String nullConvert(String src) {

	if (src == null || src.equals("null") || "".equals(src) || " ".equals(src)) {
	    return "";
	} else {
	    return src.trim();
	}
    }	
	
    /**
     *<pre>
     * String received as argument is null, the &quot;0&quot; is returned.
     * &#064;param src String values ​​that are likely null value.
     * &#064;return If the String is a null value  &quot;0&quot; is changed to a String value.
     *</pre>
     */
    public static int zeroConvert(Object src) {

	if (src == null || src.equals("null")) {
	    return 0;
	} else {
	    return Integer.parseInt(((String)src).trim());
	}
    }

    /**
     *<pre>
     * String is null if the passed-in  &quot;&quot; is returned.
     * &#064;param src String values ​​that are likely null value.
     * &#064;return 만약 If null, the String value &quot;&quot; String Value.
     *</pre>
     */
    public static int zeroConvert(String src) {

	if (src == null || src.equals("null") || "".equals(src) || " ".equals(src)) {
	    return 0;
	} else {
	    return Integer.parseInt(src.trim());
	}
    }
	
    /**
     * <p>In the string {@ link Character # isWhitespace (char)} defined in
     * All whitespace characters are removed.</p>
     *
     * <pre>
     * StringUtil.removeWhitespace(null)         = null
     * StringUtil.removeWhitespace("")           = ""
     * StringUtil.removeWhitespace("abc")        = "abc"
     * StringUtil.removeWhitespace("   ab  c  ") = "abc"
     * </pre>
     *
     * @param str  Blank character string to be removed.
     * @return the Remove the space character string, null is entered <code> null </ code> is returned.
     */
    public static String removeWhitespace(String str) {
        if (isEmpty(str)) {
            return str;
        }
        int sz = str.length();
        char[] chs = new char[sz];
        int count = 0;
        for (int i = 0; i < sz; i++) {
            if (!Character.isWhitespace(str.charAt(i))) {
                chs[count++] = str.charAt(i);
            }
        }
        if (count == sz) {
            return str;
        }
        
        return new String(chs, 0, count);
    }
    	
    /**
     * Html code to display the document containing the tag for methods without compromising on looks.
     * 
     * @param strString
     * @return HTML tags and the string substitution
     */
    public static String checkHtmlView(String strString) {
	String strNew = "";

	try {
	    StringBuffer strTxt = new StringBuffer("");

	    char chrBuff;
	    int len = strString.length();

	    for (int i = 0; i < len; i++) {
		chrBuff = (char)strString.charAt(i);

		switch (chrBuff) {
		case '<':
		    strTxt.append("&lt;");
		    break;
		case '>':
		    strTxt.append("&gt;");
		    break;
		case '"':
		    strTxt.append("&quot;");
		    break;
		case 10:
		    strTxt.append("<br>");
		    break;
		case ' ':
		    strTxt.append("&nbsp;");
		    break;
		//case '&' :
		    //strTxt.append("&amp;");
		    //break;
		default:
		    strTxt.append(chrBuff);
		}
	    }

	    strNew = strTxt.toString();

	} catch (Exception ex) {
	    return null;
	}

	return strNew;
    }
	
	
    /**
     * By the specified separator string into an array of methods that return.
     * @param source Original string.
     * @param separator Separator
     * @return result A string array as a separator divided.
     */
    public static String[] split(String source, String separator) throws NullPointerException {
        String[] returnVal = null;
        int cnt = 1;

        int index = source.indexOf(separator);
        int index0 = 0;
        while (index >= 0) {
            cnt++;
            index = source.indexOf(separator, index + 1);
        }
        returnVal = new String[cnt];
        cnt = 0;
        index = source.indexOf(separator);
        while (index >= 0) {
            returnVal[cnt] = source.substring(index0, index);
            index0 = index + 1;
            index = source.indexOf(separator, index + 1);
            cnt++;
        }
        returnVal[cnt] = source.substring(index0);
        
        return returnVal;
    }
    
    /**
     * <p>{@ link String # toLowerCase ()} should be converted to lowercase using.</p>
     *
     * <pre>
     * StringUtil.lowerCase(null)  = null
     * StringUtil.lowerCase("")    = ""
     * StringUtil.lowerCase("aBc") = "abc"
     * </pre>
     *
     * @param str The string to be converted to lowercase.
     * @return Converted to lowercase string, null is entered <code> null </ code> returns.
     */
    public static String lowerCase(String str) {
        if (str == null) {
            return null;
        }
        
        return str.toLowerCase();
    }
    
    /**
     * <p>{@ link String # toUpperCase ()} is converted to uppercase using.</p>
     *
     * <pre>
     * StringUtil.upperCase(null)  = null
     * StringUtil.upperCase("")    = ""
     * StringUtil.upperCase("aBc") = "ABC"
     * </pre>
     *
     * @param str The string to be converted to uppercase.
     * @return Converted to uppercase string, null is entered <code> null </ code> returns.
     */
    public static String upperCase(String str) {
        if (str == null) {
            return null;
        }
        
        return str.toUpperCase();
    }
    
    /**
     * <p>String of input characters that are passed as the second argument in the front (stripChars) Remove all.</p>
     *
     * <pre>
     * StringUtil.stripStart(null, *)          = null
     * StringUtil.stripStart("", *)            = ""
     * StringUtil.stripStart("abc", "")        = "abc"
     * StringUtil.stripStart("abc", null)      = "abc"
     * StringUtil.stripStart("  abc", null)    = "abc"
     * StringUtil.stripStart("abc  ", null)    = "abc  "
     * StringUtil.stripStart(" abc ", null)    = "abc "
     * StringUtil.stripStart("yxabc  ", "xyz") = "abc  "
     * </pre>
     *
     * @param str Specified character string to be removed.
     * @param stripChars Remove the destination string.
     * @return Remove the specified character string, null is entered <code> null </ code> returns.
     */
    public static String stripStart(String str, String stripChars) {
        int strLen;
        if (str == null || (strLen = str.length()) == 0) {
            return str;
        }
        int start = 0;
        if (stripChars == null) {
            while ((start != strLen) && Character.isWhitespace(str.charAt(start))) {
                start++;
            }
        } else if (stripChars.length() == 0) {
            return str;
        } else {
            while ((start != strLen) && (stripChars.indexOf(str.charAt(start)) != -1)) {
                start++;
            }
        }
        
        return str.substring(start);
    }


    /**
     * <p>String of input characters that are passed as the second argument in the back (stripChars) Remove all. </ P>
     *
     * <pre>
     * StringUtil.stripEnd(null, *)          = null
     * StringUtil.stripEnd("", *)            = ""
     * StringUtil.stripEnd("abc", "")        = "abc"
     * StringUtil.stripEnd("abc", null)      = "abc"
     * StringUtil.stripEnd("  abc", null)    = "  abc"
     * StringUtil.stripEnd("abc  ", null)    = "abc"
     * StringUtil.stripEnd(" abc ", null)    = " abc"
     * StringUtil.stripEnd("  abcyx", "xyz") = "  abc"
     * </pre>
     *
     * @param str Specified character string to be removed.
     * @param stripChars Remove the destination string.
     * @return Remove the specified character string, null is entered <code> null </ code> returns.
     */
    public static String stripEnd(String str, String stripChars) {
        int end;
        if (str == null || (end = str.length()) == 0) {
            return str;
        }

        if (stripChars == null) {
            while ((end != 0) && Character.isWhitespace(str.charAt(end - 1))) {
                end--;
            }
        } else if (stripChars.length() == 0) {
            return str;
        } else {
            while ((end != 0) && (stripChars.indexOf(str.charAt(end - 1)) != -1)) {
                end--;
            }
        }
        
        return str.substring(0, end);
    }

    /**
     * <p>String of input front, behind the character passed as the second argument (stripChars) Remove all. </ P>
     * 
     * <pre>
     * StringUtil.strip(null, *)          = null
     * StringUtil.strip("", *)            = ""
     * StringUtil.strip("abc", null)      = "abc"
     * StringUtil.strip("  abc", null)    = "abc"
     * StringUtil.strip("abc  ", null)    = "abc"
     * StringUtil.strip(" abc ", null)    = "abc"
     * StringUtil.strip("  abcyx", "xyz") = "  abc"
     * </pre>
     *
     * @param str Specified character string to be removed.
     * @param stripChars Remove the destination string.
     * @return Remove the specified character string, null is entered <code> null </ code> returns.
     */
    public static String strip(String str, String stripChars) {
	if (isEmpty(str)) {
	    return str;
	}

	String srcStr = str;
	srcStr = stripStart(srcStr, stripChars);
	
	return stripEnd(srcStr, stripChars);
    }

    /**
     * The specified separator string into an array returned by a method of the specified length.
     * @param source Original string
     * @param separator Separator
     * @param arraylength The length of the array
     * @return A string array as a separator divided.
     */
    public static String[] split(String source, String separator, int arraylength) throws NullPointerException {
        String[] returnVal = new String[arraylength];
        int cnt = 0;
        int index0 = 0;
        int index = source.indexOf(separator);
        while (index >= 0 && cnt < (arraylength - 1)) {
            returnVal[cnt] = source.substring(index0, index);
            index0 = index + 1;
            index = source.indexOf(separator, index + 1);
            cnt++;
        }
        returnVal[cnt] = source.substring(index0);
        if (cnt < (arraylength - 1)) {
            for (int i = cnt + 1; i < arraylength; i++) {
                returnVal[i] = "";
            }
        }
        
        return returnVal;
    }

    /**
     * A to Z of a random string between start string, the string provides the ability to obtain and the end to obtain a string from a string of random functions.
     * 
     * @param startChr
     *            - The first character.
     * @param endChr
     *            - The last character.
     * @return Random characters.
     * @exception MyException
     * @see
     */
    public static String getRandomStr(char startChr, char endChr) {

	int randomInt;
	String randomStr = null;

	// Start and end character ASCII character is converted to a number.
	int startInt = Integer.valueOf(startChr);
	int endInt = Integer.valueOf(endChr);

	// The end of the string if the string starts big boy.
	if (startInt > endInt) {
	    throw new IllegalArgumentException("Start String: " + startChr + " End String: " + endChr);
	}

	try {
	    // Generate random objects.
	    SecureRandom rnd = new SecureRandom();

	    do {
		//Start character and end of the character generates a random number.
		randomInt = rnd.nextInt(endInt + 1);
	    } while (randomInt < startInt); // The received character 'A' (65) is less than the re-generated random numbers.

	    // Random numbers into characters and then converted back to a string.
	    randomStr = (char)randomInt + "";
	} catch (Exception e) {
		e.getMessage();
	}

	// Random Strings return.
	return randomStr;
    }

    /**
     * Variety of string character set (EUC-KR [KSC5601], UTF-8 ..) encoded using a decoding function to reverse the string of the original
     * Providing the ability to restore String temp = new String (string. GetBytes ("before changing the encoding"), "change the encoding");
     * String temp = new String(String.getBytes("8859_1"),"KSC5601"); => UTF-8 In the
     * EUC-KR
     * 
     * @param srcString
     *            - String
     * @param srcCharsetNm
     *            - Originally CharsetNm
     * @param charsetNm
     *            - CharsetNm
     * @return 인코딩,디코딩 문자열
     * @exception MyException
     * @see
     */
    public static String getEncdDcd(String srcString, String srcCharsetNm, String cnvrCharsetNm) {

	String rtnStr = null;

	if (srcString == null)
	    return null;

	try {
	    rtnStr = new String(srcString.getBytes(srcCharsetNm), cnvrCharsetNm);
	} catch (UnsupportedEncodingException e) {
	    rtnStr = null;
	}

	return rtnStr;
    }

/**
     * Encoding and decoding strings with special characters in your Web browser to properly handle special characters show ('<' -> & lT) is a function
     * @param 	srcString 		- '<' 
     * @return Convert a string ('<' -> "<"
     * @exception MyException 
     * @see  
     */
    public static String getSpclStrCnvr(String srcString) {

	String rtnStr = null;

	try {
	    StringBuffer strTxt = new StringBuffer("");

	    char chrBuff;
	    int len = srcString.length();

	    for (int i = 0; i < len; i++) {
		chrBuff = (char)srcString.charAt(i);

		switch (chrBuff) {
		case '<':
		    strTxt.append("&lt;");
		    break;
		case '>':
		    strTxt.append("&gt;");
		    break;
		case '&':
		    strTxt.append("&amp;");
		    break;
		default:
		    strTxt.append(chrBuff);
		}
	    }

	    rtnStr = strTxt.toString();

	} catch (Exception e) {
		e.getMessage();
	}

	return rtnStr;
    }

    /**
     * Using an application-specific value for the system to obtain a 17-digit TIMESTAMP value function.
     * 
     * @param
     * @return Timestamp Value
     * @exception MyException
     * @see
     */
    public static String getTimeStamp() {

	String rtnStr = null;

	//Converted to a string for a pattern set (year-month-day hours: minutes: seconds: seconds (seconds since midnight))
	String pattern = "yyyyMMddhhmmssSSS";

	try {
	    SimpleDateFormat sdfCurrent = new SimpleDateFormat(pattern, Locale.KOREA);
	    Timestamp ts = new Timestamp(System.currentTimeMillis());

	    rtnStr = sdfCurrent.format(ts.getTime());
	} catch (Exception e) {
		e.getMessage();
	}

	return rtnStr;
    }
    
    /**
     * html special characters to represent.
     * 
     * @param srcString
     * @return String
     * @exception Exception
     * @see
     */    
    public static String getHtmlStrCnvr(String srcString) {
    	
    	String tmpString = srcString;
    	
		try 
		{
			tmpString = tmpString.replaceAll("&lt;", "<");
			tmpString = tmpString.replaceAll("&gt;", ">");
			tmpString = tmpString.replaceAll("&amp;", "&");
			tmpString = tmpString.replaceAll("&nbsp;", " ");
			tmpString = tmpString.replaceAll("&apos;", "\'");
			tmpString = tmpString.replaceAll("&quot;", "\"");
		}
		catch (Exception ex)
		{
			ex.getMessage();
		}

		return  tmpString;
	
	}    
    
    /**
     * <p>Inside a character string in a date format minus character (-) is added. </ P>
     *
     * <pre>
     *   StringUtil.addMinusChar("20100901") = "2010-09-01"
     * </pre>
     *
     * @param date That receives the string.
     * @return "-" Input string was added.
     */
	public static String addMinusChar(String date) {
		if(date.length() == 8) 	
		    return date.substring(0,4).concat("-").concat(date.substring(4,6)).concat("-").concat(date.substring(6,8));
		else return "";
	}
	
	/**
     * A string, the value of a specific length from the left by chewo is returned. However, the input value is null, all with a certain string is returned, and the characters are to be converted. Trim () is used to.
     * Example) getLPAD(" 12 ", 4,"0") -> 0012 return
     * @param     String param :To convert character
     * @param     int size     :Returns the size
     * @param     String defaultString :Cheul character (but only one digit string recognition) default: 0
     * @return    String
     */
    public static String getLPAD(final String param, final int size, final String defaultString) {
        String retValue;
        if (param == null) {
            retValue = "";
        }
        else {
            retValue = param.trim();
        }
        int length = retValue.length();
        for (int i = 0; i < size - length; i++) {
            retValue = defaultString + retValue;
        }
        return retValue;
    }

    /**
     * A string, the value of a specific length from the right by chewo is returned. However, the input value is null, all with a certain string is returned, and the characters are to be converted. Trim () is used to.
     * Example) getLPAD ("12", 4, "0") -> 1200 return
     * @param     String param :To convert character
     * @param     int size     :Returns the size
     * @param     String defaultString :Cheul character (but only one digit string recognition) default: 0
     * @return    String
     */
    public static String getRPAD(final String param, final int size, final String defaultString) {
        String retValue;
        if (param == null) {
            retValue = "";
        }
        else {
            retValue = param.trim();
        }
        int length = retValue.length();
        for (int i = 0; i < size - length; i++) {
            retValue += defaultString;
        }
        return retValue;
    }
    
    /**
     * Arabic numerals and Arabic numeric string to the same number
     * Example) toNumberConvet("123","j") -> ۱۲۴ , toNumberConvet("۱۲۴","g") -> 123 return
     * @param     String param :To convert character
     * @param     String flag j = Arabic, g = Arabic numerals (j is not in Arabic numerals AM)
     * @return    String
     */
    public static String toNumberConvet(String param, String flag) {
        String retValue = "";
        String [] persianNumberArray = new String[]{"۰","۱","۲","۳","۴","۵","۶","۷","۸","۹"};
   		StringBuffer sb = new StringBuffer();
        if(param != null && param.length() > 0){
        	if(flag != null){
        		if(flag.toUpperCase().equals("J")){
    		   		for(int i = 0;  i < param.length(); i++){
    		   			String numChat = param.substring(i,i+1);
    		   			if(Pattern.matches("^[0-9]*$", numChat)){
    		   				sb.append(persianNumberArray[Integer.parseInt(numChat)]);
    		   			}else{
    		   				sb.append(numChat);
    		   			}
    		   		}
    		   		retValue = sb.toString();
        		}else{
        			boolean flags = false;
        	   		for(int i = 0;  i < param.length(); i++){
        	   			String numChat = param.substring(i,i+1);
        	   			for(int j = 0; j < persianNumberArray.length; j++){
        	   				if(numChat.equals(persianNumberArray[j])){
        	   					sb.append(String.valueOf(j));
        	   					flags = true;
        	   					break;
        	   				}
        	   			}
        	   			if(!flags){
        	   				sb.append(numChat);
        	   			}
        	   			flags = false;
        	   		}
        	   		retValue = sb.toString();
        		}
        	}
        }
        return retValue; 
    }
    
    
    
    /**
     *  office card cert
     * @param     HttpServletRequest request
     * @return    String
     */
    public String getReqCertName(final HttpServletRequest req) {
        String retValue = null;
        if (req == null) {
            retValue = "";
        }else {
        	X509Certificate[] certificate = (X509Certificate []) req.getAttribute("javax.servlet.request.X509Certificate");
			if(certificate != null){
    			if(certificate[0] != null && certificate[0].getSubjectDN() != null && certificate[0].getSubjectDN().getName() != null){
    				if(!"".equals(certificate[0].getSubjectDN().getName())){
    					retValue = certificate[0].getSubjectDN().getName();
    				}
    			}
			}
        }
        return retValue;
    }
    
    
    /**
     *  list data reverse
     * @param     java.util.List<CmCmmCdVO>
     * @return    java.util.List<CmCmmCdVO>
     */
    public static java.util.List<CmCmmCdVO> setListReverse(java.util.List<CmCmmCdVO> data) {
    	java.util.List<CmCmmCdVO> retValue = null;
    	try{
	        if (data == null) {
	        	retValue = new ArrayList<CmCmmCdVO>();
	        }else {
	        	retValue = data;
	        	Collections.reverse(retValue);
	        }
    	}catch(Exception e){
    		retValue = new ArrayList<CmCmmCdVO>();
    	}
        return retValue;
    }
    
    /**
     * make one space between word and word
     * @param     String value :To convert character
     * @return    String
     */
    public static String makeOneSpace(String value) {
        String retValue = "";

        String[] arr = value.split(" ");
        int lastCnt = arr.length-1;        
        for(int i=0; i< arr.length; i++){
        	
        	if( !"".equals(arr[i]) ){
        		if(i != lastCnt ){
        			retValue = retValue + arr[i].replace(" ", "") +" ";
        		} else {
        			retValue = retValue + arr[i].replace(" ", "");
        		}        		
        	}       	
        }
        
        return retValue; 
    }    
}
