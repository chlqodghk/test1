package afnid.cm.util.service;

import java.security.SecureRandom;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.ibm.icu.util.ChineseCalendar;

/**
 * 
 * Date for the Util class. 
 * @author Chunghao Lee
 * @since 2009.02.01
 * @version 1.0
 * @see
 *
 * <pre>
 *<< Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *  -------    --------    ---------------------------
 *   2009.02.01  Chunghao Lee          CREATE
 *
 * </pre>
 */
public class NidDdUtil {
	
    /**
     * <p>yyyyMMdd or yyyy-MM-dd formatted date string as input the year, month, and day will decrease.
     * Month, day, and year to modify the means to sense when you enter a negative number.</p>
     * 
     * <pre>
     * DateUtil.addYearMonthDay("19810828", 0, 0, 19)  = "19810916"
     * DateUtil.addYearMonthDay("20060228", 0, 0, -10) = "20060218"
     * DateUtil.addYearMonthDay("20060228", 0, 0, 10)  = "20060310"
     * DateUtil.addYearMonthDay("20060228", 0, 0, 32)  = "20060401"
     * DateUtil.addYearMonthDay("20050331", 0, -1, 0)  = "20050228"
     * DateUtil.addYearMonthDay("20050301", 0, 2, 30)  = "20050531"
     * DateUtil.addYearMonthDay("20050301", 1, 2, 30)  = "20060531"
     * DateUtil.addYearMonthDay("20040301", 2, 0, 0)   = "20060301"
     * DateUtil.addYearMonthDay("20040229", 2, 0, 0)   = "20060228"
     * DateUtil.addYearMonthDay("20040229", 2, 0, 1)   = "20060301"
     * </pre>
     * 
     * @param  dateStr date string (yyyyMMdd, yyyy-MM-dd format)
     * @param  year to year acceleration. If 0 is entered, there is no acceleration.
     * @param  month to month acceleration. If 0 is entered, there is no acceleration.
     * @param  one day you want to modify. If 0 is entered, there is no acceleration.
     * @return  yyyyMMdd formatted date string.
     * @throws IllegalArgumentException if the date format is different from those specified. 
     *         Enter the value <code> null </ code> if it is.
     */
    public static String addYearMonthDay(String sDate, int year, int month, int day) {

    	String dateStr = validChkDate(sDate);
        
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd", Locale.getDefault());
        try {
            cal.setTime(sdf.parse(dateStr));
        } catch (ParseException e) {
            throw new IllegalArgumentException("Invalid date format: " + dateStr);
        }
        
        if (year != 0) 
            cal.add(Calendar.YEAR, year);
        if (month != 0) 
            cal.add(Calendar.MONTH, month);
        if (day != 0) 
            cal.add(Calendar.DATE, day);
        return sdf.format(cal.getTime());
    }
    
    /**
     * <p>yyyyMMdd or yyyy-MM-dd formatted date string as input to increase or decrease the year.
     * <code>year</code>To the mean acceleration, and if you enter a negative number, subtract.</p>
     * 
     * <pre>
     * DateUtil.addYear("20000201", 62)  = "20620201"
     * DateUtil.addYear("20620201", -62) = "20000201"
     * DateUtil.addYear("20040229", 2)   = "20060228"
     * DateUtil.addYear("20060228", -2)  = "20040228"
     * DateUtil.addYear("19000101", 200) = "21000101"
     * </pre>
     * 
     * @param  dateStr date string (yyyyMMdd, yyyy-MM-dd format)
     * @param  year to year acceleration. If 0 is entered, there is no acceleration.
     * @return  yyyyMMdd formatted date string
     * @throws IllegalArgumentException If the date format is different from those specified.
     *        Enter the value <code> null </ code> if it is.
     */
    public static String addYear(String dateStr, int year) {
        return addYearMonthDay(dateStr, year, 0, 0);
    }
    
    /**
     * <p>yyyyMMdd or yyyy-MM-dd formatted date string as input to increase or decrease the month.
     * <code> month </ code> refers to the acceleration can be, shall be deducted when you enter a negative number. </ p>
     * 
     * <pre>
     * DateUtil.addMonth("20010201", 12)  = "20020201"
     * DateUtil.addMonth("19800229", 12)  = "19810228"
     * DateUtil.addMonth("20040229", 12)  = "20050228"
     * DateUtil.addMonth("20050228", -12) = "20040228"
     * DateUtil.addMonth("20060131", 1)   = "20060228"
     * DateUtil.addMonth("20060228", -1)  = "20060128"
     * </pre>
     * 
     * @param  dateStr date string (yyyyMMdd, yyyy-MM-dd format)
     * @param  month to month acceleration. If 0 is entered, there is no acceleration.
     * @return  yyyyMMdd formatted date string
     * @throws IllegalArgumentException if the date format is different from those specified.
     *        Enter the value <code> null </ code> if it is.
     */
    public static String addMonth(String dateStr, int month) {
        return addYearMonthDay(dateStr, 0, month, 0);
    }
    
    /**
     * <p>yyyyMMdd or yyyy-MM-dd formatted date string as input one (day) will increase or decrease.
     * <code> day </ code> refers to the acceleration can be, shall be deducted when you enter a negative number.
     * <br/><br/>
     * AddDays method defined on the user the need to handle the ParseException because of the inconvenience of the method is added.
     * </p>
     * 
     * <pre>
     * DateUtil.addDay("19991201", 62) = "20000201"
     * DateUtil.addDay("20000201", -62) = "19991201"
     * DateUtil.addDay("20050831", 3) = "20050903"
     * DateUtil.addDay("20050831", 3) = "20050903"
     * DateUtil.addDay("20060631", 1) = "20060702"
     * </pre>
     * 
     * @param  dateStr date string (yyyyMMdd, yyyy-MM-dd format)
     * @param  one day you want to modify. If 0 is entered, there is no acceleration.
     * @return  yyyyMMdd formatted date string
     * @throws IllegalArgumentException if the date format is different from those specified.
     *        Enter the value <code> null </ code> if it is.
     */
    public static String addDay(String dateStr, int day) {
        return addYearMonthDay(dateStr, 0, 0, day);
    }
    
    /**
     * <p>yyyyMMdd or yyyy-MM-dd formatted date string <code> dateStr1 </ code> and <code>
     * dateStr2</code> Calculate the number of days between.<br>
     * <code>dateStr2</code>가 <code>dateStr1</code> If more than one date in the past, returns a negative number.
     *  Returns 0 if the same.</p>
     * 
     * <pre>
     * DateUtil.getDaysDiff("20060228","20060310") = 10
     * DateUtil.getDaysDiff("20060101","20070101") = 365
     * DateUtil.getDaysDiff("19990228","19990131") = -28
     * DateUtil.getDaysDiff("20060801","20060802") = 1
     * DateUtil.getDaysDiff("20060801","20060801") = 0
     * </pre>
     * 
     * @param  dateStr1 date string (yyyyMMdd, yyyy-MM-dd format)
     * @param  dateStr2 date string (yyyyMMdd, yyyy-MM-dd format)
     * @return  Be a difference.
     * @throws IllegalArgumentException if the date format is different from those specified.
     *        Enter the value <code> null </ code> if it is.
     */
    public static int getDaysDiff(String sDate1, String sDate2) {
    	String dateStr1 = validChkDate(sDate1);
    	String dateStr2 = validChkDate(sDate2);
    	
        if (!checkDate(sDate1) || !checkDate(sDate2)) {
            throw new IllegalArgumentException("Invalid date format: args[0]=" + sDate1 + " args[1]=" + sDate2);
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd", Locale.getDefault());
        
        Date date1 = null;
        Date date2 = null;
        try {
            date1 = sdf.parse(dateStr1);
            date2 = sdf.parse(dateStr2);
        } catch (ParseException e) {
            throw new IllegalArgumentException("Invalid date format: args[0]=" + dateStr1 + " args[1]=" + dateStr2);
        }
        int days1 = (int)((date1.getTime()/3600000)/24);
        int days2 = (int)((date2.getTime()/3600000)/24);
        
        return days2 - days1;
    }
        
    /**
     * <p>yyyyMMdd or yyyy-MM-dd formatted date string as input checks for a valid date.</p>
     * 
     * <pre>
     * DateUtil.checkDate("1999-02-35") = false
     * DateUtil.checkDate("2000-13-31") = false
     * DateUtil.checkDate("2006-11-31") = false
     * DateUtil.checkDate("2006-2-28")  = false
     * DateUtil.checkDate("2006-2-8")   = false
     * DateUtil.checkDate("20060228")   = true
     * DateUtil.checkDate("2006-02-28") = true
     * </pre>
     * 
     * @param  dateStr date string (yyyyMMdd, yyyy-MM-dd format)
     * @return  Whether it is a valid date.
     */
    public static boolean checkDate(String sDate) {
    	String dateStr = validChkDate(sDate);

        String year  = dateStr.substring(0,4);
        String month = dateStr.substring(4,6);
        String day   = dateStr.substring(6);
   
        return checkDate(year, month, day);
    }   

    /**
     * <p>Enter the year, month, and day to validate.</p>
     * 
     * @param  year 
     * @param  month 
     * @param  day 
     * @return  Whether it is a valid date.
     */
    public static boolean checkDate(String year, String month, String day) {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy.MM.dd", Locale.getDefault());
            
            Date result = formatter.parse(year + "." + month + "." + day);
            String resultStr = formatter.format(result);
            if (resultStr.equalsIgnoreCase(year + "." + month + "." + day))
                return true;
            else
                return false;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Date in the form of String methods to change the date format and TimeZone
     *
     * @param  strSource       Change the date String
     * @param  fromDateFormat  Existing date format
     * @param  toDateFormat    The desired date format
     * @param  strTimeZone     Change TimeZone ("" is not changed)
     * @return  Change the date format of the source String and string.
     */
    public static String convertDate(String strSource, String fromDateFormat, 
            String toDateFormat, String strTimeZone) {
        SimpleDateFormat simpledateformat = null;
        Date date = null;
        String _fromDateFormat = "";
        String _toDateFormat = "";
        
        if(NidStringUtil.isNullToString(strSource).trim().equals("")) {
            return "";
        }
        if(NidStringUtil.isNullToString(fromDateFormat).trim().equals(""))
        	_fromDateFormat = "yyyyMMddHHmmss";                    // default Value
        if(NidStringUtil.isNullToString(toDateFormat).trim().equals(""))
        	_toDateFormat = "yyyy-MM-dd HH:mm:ss";                 // default Value

        try {
        	simpledateformat = new SimpleDateFormat(_fromDateFormat, Locale.getDefault());
            date = simpledateformat.parse(strSource);
            if (!NidStringUtil.isNullToString(strTimeZone).trim().equals("")) {
                simpledateformat.setTimeZone(TimeZone.getTimeZone(strTimeZone));
            }
            simpledateformat = new SimpleDateFormat(_toDateFormat, Locale.getDefault());
        }
        catch(Exception e) {
        	e.getMessage();
        	
        }        
        return simpledateformat.format(date);
        
    }    
    
    
    /**
     * yyyyMMdd type of character you want to date a string (ch) returns to the split.<br/>
    * <pre>
    * ex) 20030405, ch(.) -> 2003.04.05
    * ex) 200304, ch(.) -> 2003.04
    * ex) 20040101,ch(/) --> returned to
    * </pre>
    * 
    * @param date yyyyMMdd formatted date string
    * @param ch Separator
    * @return The converted string
     */
    public static String formatDate(String sDate, String ch) {
    	String dateStr = validChkDate(sDate);

        String str = dateStr.trim();
        String yyyy = "";
        String mm = "";
        String dd = "";

        if (str.length() == 8) {
            yyyy = str.substring(0, 4);
            if ("0000".equals(yyyy))
                return "";

            mm = str.substring(4, 6);
            if ("00".equals(mm))
                return yyyy;

            dd = str.substring(6, 8);
            if ("00".equals(dd))
                return yyyy + ch + mm;

            return yyyy + ch + mm + ch + dd;
        } else if (str.length() == 6) {
            yyyy = str.substring(0, 4);
            if ("0000".equals(yyyy))
                return "";

            mm = str.substring(4, 6);
            if ("00".equals(mm))
                return yyyy;

            return yyyy + ch + mm;
        } else if (str.length() == 4) {
            yyyy = str.substring(0, 4);
            if ("0000".equals(yyyy))
                return "";
            else
                return yyyy;
        } else
            return "";
    }    
    
    /**
     *HH24MISS the time in the format desired character string (ch) returns to the split. <br>
     * <pre>
     *     ex) 151241, ch(/) -> 15/12/31
     * </pre>
     *
     * @param str HH24MISS time string of the form
     * @param ch Separator
     * @return The converted string
     */
     public static String formatTime(String sTime, String ch) {
     	String timeStr = validChkTime(sTime);
        return timeStr.substring(0, 2) + ch + timeStr.substring(2, 4) + ch + timeStr.substring(4, 6);
     }    
    
     /**
      * Enter the year of the last day of February of the year received (in days) is returned as a string.
      * 
      * @param year
      * @return The last day of February of the year (days).
      */
     public String leapYear(int year) {
         if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0) {
             return "29";
         }

         return "28";
     }    
    
     /**
      * <p>Who entered year is a leap year or not is checked.</p>
      * 
      * <pre>
      * DateUtil.isLeapYear(2004) = false
      * DateUtil.isLeapYear(2005) = true
      * DateUtil.isLeapYear(2006) = true
      * </pre>
      * 
      * @param  year 
      * @return  For leap year
      */
     public static boolean isLeapYear(int year) {
         if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0) {
             return false;
         }
         return true;
     }     
     
     
     /**
      * Current (Korea Standard) gets date information.                   <BR>
      * The notation is yyyy-mm-dd                                 <BR>
      * @return  String     this time in the form of yyyymmdd Korea.   <BR>
      */
     public static String getToday(){
         return getCurrentDate("");
     }

     /**
      * Current (Korea Standard) gets date information.                     <BR>
      * The notation is yyyy-mm-dd                               <BR>
      * @return  String     this time in the form of yyyymmdd Korea.   <BR>
      */
     public static String getCurrentDate(String dateType) {
         Calendar aCalendar = Calendar.getInstance();

         int year = aCalendar.get(Calendar.YEAR);
         int month = aCalendar.get(Calendar.MONTH) + 1;
         int date = aCalendar.get(Calendar.DATE);
         String strDate = Integer.toString(year) +
                 ((month<10) ? "0" + Integer.toString(month) : Integer.toString(month)) +
                 ((date<10) ? "0" + Integer.toString(date) : Integer.toString(date));
         
         if(!"".equals(dateType)) strDate = convertDate(strDate, "yyyyMMdd", dateType);

         return  strDate;
     }
     
     /**                                                                                                     
      * TimeStamp Returns a string.                                                                        
      */                                                                                                     
     public static String getCurrentTime() {                                                             
         java.text.SimpleDateFormat formatter =                                                              
             new java.text.SimpleDateFormat("yyyyMMddHHmmss", java.util.Locale.getDefault());              
         return formatter.format(new java.util.Date());                                                      
     }          
     
	/**
	 * Date only change the date format in the form of a method of the String.
	 * @param sDate Date
	 * @param sTime Time
	 * @param sFormatStr Format string
	 * @return The specified date / time output to the specified format
	 * @See Letter  Date or Time Component  Presentation  Examples  
	           G  Era designator  Text  AD  
	           y  Year  Year  1996; 96  
	           M  Month in year  Month  July; Jul; 07  
	           w  Week in year  Number  27  
	           W  Week in month  Number  2  
	           D  Day in year  Number  189  
	           d  Day in month  Number  10  
	           F  Day of week in month  Number  2  
	           E  Day in week  Text  Tuesday; Tue  
	           a  Am/pm marker  Text  PM  
	           H  Hour in day (0-23)  Number  0  
	           k  Hour in day (1-24)  Number  24  
	           K  Hour in am/pm (0-11)  Number  0  
	           h  Hour in am/pm (1-12)  Number  12  
	           m  Minute in hour  Number  30  
	           s  Second in minute  Number  55  
	           S  Millisecond  Number  978  
	           z  Time zone  General time zone  Pacific Standard Time; PST; GMT-08:00  
	           Z  Time zone  RFC 822 time zone  -0800  
	           
	            
	           
	           Date and Time Pattern  Result  
	           "yyyy.MM.dd G 'at' HH:mm:ss z"  2001.07.04 AD at 12:08:56 PDT  
	           "EEE, MMM d, ''yy"  Wed, Jul 4, '01  
	           "h:mm a"  12:08 PM  
	           "hh 'o''clock' a, zzzz"  12 o'clock PM, Pacific Daylight Time  
	           "K:mm a, z"  0:08 PM, PDT  
	           "yyyyy.MMMMM.dd GGG hh:mm aaa"  02001.July.04 AD 12:08 PM  
	           "EEE, d MMM yyyy HH:mm:ss Z"  Wed, 4 Jul 2001 12:08:56 -0700  
	           "yyMMddHHmmssZ"  010704120856-0700  
	
	 */
    public static String convertDate(String sDate, String sTime, String sFormatStr) {
    	String dateStr = validChkDate(sDate);
    	String timeStr = validChkTime(sTime);
    	
    	Calendar cal = null;
    	cal = Calendar.getInstance() ;
    	
    	cal.set(Calendar.YEAR        , Integer.parseInt(dateStr.substring(0,4)));
    	cal.set(Calendar.MONTH       , Integer.parseInt(dateStr.substring(4,6))-1 );
    	cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dateStr.substring(6,8)));
    	cal.set(Calendar.HOUR_OF_DAY , Integer.parseInt(timeStr.substring(0,2)));
    	cal.set(Calendar.MINUTE      , Integer.parseInt(timeStr.substring(2,4)));
    	
    	SimpleDateFormat sdf = new SimpleDateFormat(sFormatStr,Locale.ENGLISH);
    	
    	return sdf.format(cal.getTime());
    }   

    /**
     * Entered between the date of receipt of any return date.
     * @param sDate1 Start Date
     * @param sDate2 Ends
     * @return Any Date
     */
    public static String getRandomDate(String sDate1, String sDate2) {    
    	String dateStr1 = validChkDate(sDate1);
    	String dateStr2 = validChkDate(sDate2);

    	String randomDate   = null;
    	
    	int sYear, sMonth, sDay;
    	int eYear, eMonth, eDay;
    	
    	sYear  = Integer.parseInt(dateStr1.substring(0, 4));
    	sMonth = Integer.parseInt(dateStr1.substring(4, 6));
    	sDay   = Integer.parseInt(dateStr1.substring(6, 8));
    	
    	eYear  = Integer.parseInt(dateStr2.substring(0, 4));
    	eMonth = Integer.parseInt(dateStr2.substring(4, 6));
    	eDay   = Integer.parseInt(dateStr2.substring(6, 8));
    	
    	GregorianCalendar beginDate = new GregorianCalendar(sYear, sMonth-1, sDay,    0, 0);
    	GregorianCalendar endDate   = new GregorianCalendar(eYear, eMonth-1, eDay,   23,59);
    	
    	if (endDate.getTimeInMillis() < beginDate.getTimeInMillis()) {
    	    throw new IllegalArgumentException("Invalid input date : " + sDate1 + "~" + sDate2);
    	}
    	
    	SecureRandom r = new SecureRandom();

    	long rand = ((r.nextLong()>>>1)%( endDate.getTimeInMillis()-beginDate.getTimeInMillis() + 1)) + beginDate.getTimeInMillis();
    	
    	GregorianCalendar cal = new GregorianCalendar();
    	//SimpleDateFormat calformat = new SimpleDateFormat("yyyy-MM-dd");
    	SimpleDateFormat calformat = new SimpleDateFormat("yyyyMMdd",Locale.ENGLISH);
    	cal.setTimeInMillis(rand);
    	randomDate = calformat.format(cal.getTime()); 
    	
    	// Random Strings return
    	return  randomDate;
    }
          
    /**
     * Who entered Convert Gregorian date return as of the lunar calendar.
     * @param sDate Gregorian dates
     * @return Lunar Date
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static HashMap toLunar(String sDate) {
    	String dateStr = validChkDate(sDate);

		HashMap hm = new HashMap();
		hm.put("day", "");
		hm.put("leap", 0);

		if(dateStr.length() != 8) {
			return hm;
		}

		Calendar cal ;
		ChineseCalendar lcal ;
		
		cal = Calendar.getInstance() ;
		lcal = new ChineseCalendar();
		
		cal.set(Calendar.YEAR        , Integer.parseInt(dateStr.substring(0,4)));
		cal.set(Calendar.MONTH       , Integer.parseInt(dateStr.substring(4,6))-1 );
		cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dateStr.substring(6,8)));
		
		lcal.setTimeInMillis(cal.getTimeInMillis());
		
		String year  = String.valueOf(lcal.get(ChineseCalendar.EXTENDED_YEAR) - 2637);
		String month = String.valueOf(lcal.get(ChineseCalendar.MONTH        ) + 1   );
		String day   = String.valueOf(lcal.get(ChineseCalendar.DAY_OF_MONTH )       );
		String leap  = String.valueOf(lcal.get(ChineseCalendar.IS_LEAP_MONTH)       );
		
		String pad4Str = "0000";
		String pad2Str = "00";
		
		String retYear  = (pad4Str + year ) .substring(year .length());    
		String retMonth = (pad2Str + month) .substring(month.length());    
		String retDay   = (pad2Str + day  ) .substring(day  .length());    
		
		String SDay = retYear+retMonth+retDay;
		
		hm.put("day", SDay);
		hm.put("leap", leap);
		
		return hm;
	}

    /**
     * Convert the received date of the lunar calendar to the Gregorian date of the return. 
     * @param sDate Lunar Date
     * @param iLeapMonth Whether the lunar leap month(IS_LEAP_MONTH)
     * @return Gregorian dates
     */
	public static String toSolar(String sDate, int iLeapMonth) {
    	String dateStr = validChkDate(sDate);

    	Calendar cal ;
		ChineseCalendar lcal ;
		
		cal = Calendar.getInstance() ;
		lcal = new ChineseCalendar();
		
      
		lcal.set(ChineseCalendar.EXTENDED_YEAR, Integer.parseInt(dateStr.substring(0,4)) + 2637);
		lcal.set(ChineseCalendar.MONTH        , Integer.parseInt(dateStr.substring(4,6)) - 1);
		lcal.set(ChineseCalendar.DAY_OF_MONTH , Integer.parseInt(dateStr.substring(6,8)));
		lcal.set(ChineseCalendar.IS_LEAP_MONTH, iLeapMonth);
		
		cal.setTimeInMillis(lcal.getTimeInMillis());
		
		String year  = String.valueOf(cal.get(Calendar.YEAR        )    );
		String month = String.valueOf(cal.get(Calendar.MONTH       ) + 1);
		String day   = String.valueOf(cal.get(Calendar.DAY_OF_MONTH)    );
		
		String pad4Str = "0000";
		String pad2Str = "00";
		
		String retYear  = (pad4Str + year ).substring(year .length());    
		String retMonth = (pad2Str + month).substring(month.length());    
		String retDay   = (pad2Str + day  ).substring(day  .length());    
		
		return retYear+retMonth+retDay;
	}


    /**
     * English name of the Korean people who entered the day as the day of the week return.
     * @param sWeek English day names
     * @return Korean day names
     */
	public static String convertWeek(String sWeek) {
		String retStr = null;
		
		if        ("SUN".equals(sWeek)   ) { retStr = "Sunday";
		} else if ("MON".equals(sWeek)   ) { retStr = "Monday";
		} else if ("TUE".equals(sWeek)   ) { retStr = "Tuesday";
		} else if ("WED".equals(sWeek)   ) { retStr = "Wednsday";
		} else if ("THR".equals(sWeek)   ) { retStr = "Thursday";
		} else if ("FRI".equals(sWeek)   ) { retStr = "Friday";
		} else if ("SAT".equals(sWeek)   ) { retStr = "Saturday";
		}
		   
		return retStr;
	}

    /**
     * Check the validity of the date entered.
     * @param sDate Date
     * @return Validity
     */
    public static boolean validDate(String sDate) {
    	String dateStr = validChkDate(sDate);

		Calendar cal ;
		boolean ret  = false;
		
		cal = Calendar.getInstance() ;
		
		cal.set(Calendar.YEAR        , Integer.parseInt(dateStr.substring(0,4)));
		cal.set(Calendar.MONTH       , Integer.parseInt(dateStr.substring(4,6))-1 );
		cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dateStr.substring(6,8)));
		
		String year  = String.valueOf(cal.get(Calendar.YEAR        )    );
		String month = String.valueOf(cal.get(Calendar.MONTH       ) + 1);
		String day   = String.valueOf(cal.get(Calendar.DAY_OF_MONTH)    );
		
		String pad4Str = "0000";
		String pad2Str = "00";
		
		String retYear  = (pad4Str + year ).substring(year .length());
		String retMonth = (pad2Str + month).substring(month.length());
		String retDay   = (pad2Str + day  ).substring(day  .length());
		
		String retYMD = retYear+retMonth+retDay;
		
		if(sDate.equals(retYMD)) {
			ret  = true;
		}
		
		return ret;
	}
    
    /**
     * Enter the date, day of the week to determine whether effective.
     * @param     sDate Date
     * @param     sWeek Day of the week (DAY_OF_WEEK)
     * @return    Validity
     */
    public static boolean validDate(String sDate, int sWeek) {
    	String dateStr = validChkDate(sDate);

		Calendar cal ;
		boolean ret  = false;
		
		cal = Calendar.getInstance() ;
		
		cal.set(Calendar.YEAR        , Integer.parseInt(dateStr.substring(0,4)));
		cal.set(Calendar.MONTH       , Integer.parseInt(dateStr.substring(4,6))-1 );
		cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dateStr.substring(6,8)));
		
		int    Week  =                cal.get(Calendar.DAY_OF_WEEK      );
		
		if (validDate(sDate)) {
			if (sWeek == Week) {
				ret = true;
			}
		}
		
		return ret;
	}

    /**
     * Check the validity of input time.
     * @param     sTime Enter the hour
     * @return    Validity
     */
    public static boolean validTime(String sTime) {
    	String timeStr = validChkTime(sTime);

		Calendar cal ;
		boolean ret = false;
		
		cal = Calendar.getInstance() ;
		
		cal.set(Calendar.HOUR_OF_DAY  , Integer.parseInt(timeStr.substring(0,2)));
		cal.set(Calendar.MINUTE       , Integer.parseInt(timeStr.substring(2,4)));
		
		String HH     = String.valueOf(cal.get(Calendar.HOUR_OF_DAY  ));
		String MM     = String.valueOf(cal.get(Calendar.MINUTE       ));
		
		String pad2Str = "00";
		
		String retHH = (pad2Str + HH).substring(HH.length());
		String retMM = (pad2Str + MM).substring(MM.length());
		
		String retTime = retHH + retMM;
		
		if(sTime.equals(retTime)) {
			ret  = true;
		}
		
		return ret;
	}
    
    /**
     * Was entered on the date of the year, month, day, day of the week for the date of the return acceleration.
     * @param sDate Date
     * @param year 
     * @param month 
     * @param day 
     * @return The date on which the calculation of the day(DAY_OF_WEEK)
     */
    public static String addYMDtoWeek(String sDate, int year, int month, int day) {
    	String dateStr = validChkDate(sDate);
    	
		dateStr = addYearMonthDay(dateStr, year, month, day);
		
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd",Locale.ENGLISH);
		try {
			cal.setTime(sdf.parse(dateStr));
		} catch (ParseException e) {
			throw new IllegalArgumentException("Invalid date format: " + dateStr);
		}
		
		SimpleDateFormat rsdf = new SimpleDateFormat("E",Locale.ENGLISH);
		
		return rsdf.format(cal.getTime());
	}

    /**
     * Was entered on the date of the year, month, day, hour, minute, one subtracts the date and time format string format return.
     * @param sDate Date
     * @param sTime Time
     * @param year 
     * @param month 
     * @param day 
     * @param hour 
     * @param minute 
     * @param formatStr Format string
     * @return
     */
    public static String addYMDtoDayTime(String sDate, String sTime, int year, int month, int day, int hour, int minute, String formatStr) {
    	String dateStr = validChkDate(sDate);
    	String timeStr = validChkTime(sTime);
    	
		dateStr = addYearMonthDay(dateStr, year, month, day);
		
		dateStr = convertDate(dateStr, timeStr, "yyyyMMddHHmm");      
		
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm",Locale.ENGLISH);

        try {
    		cal.setTime(sdf.parse(dateStr));
        } catch (ParseException e) {
            throw new IllegalArgumentException("Invalid date format: " + dateStr);
        }
		
		if (hour != 0) {
			cal.add(Calendar.HOUR, hour);
		}

		if (minute != 0) {
			cal.add(Calendar.MINUTE, minute);
		}
		
		SimpleDateFormat rsdf = new SimpleDateFormat(formatStr,Locale.ENGLISH);
		
		return rsdf.format(cal.getTime());
	}
 
    /**
     * Enter the date on which the return of the int type.
     * @param sDate Date
     * @return int(Date)
     */
    public static int datetoInt(String sDate) {
    	return Integer.parseInt(convertDate(sDate, "0000", "yyyyMMdd"));
    }
    
    /**
     * The time to return to the input of type int.
     * @param sTime Time
     * @return int(Time)
     */
    public static int timetoInt(String sTime) {
        return Integer.parseInt(convertDate("00000101", sTime, "HHmm"));
    }

    /**
     * Check the date on which the input string and 8-digit returns.   
     * @param sDate
     * @return
     */
    public static String validChkDate(String dateStr) {
    	String _dateStr = dateStr;
    	
        if (dateStr == null || !(dateStr.trim().length() == 8 || dateStr.trim().length() == 10)) {
            throw new IllegalArgumentException("Invalid date format: " + dateStr);
        }
        if (dateStr.length() == 10) {
        	_dateStr = NidStringUtil.removeMinusChar(dateStr);
        }
        return _dateStr;
    }
 
    /**
     * Check the date on which the input string and 8-digit returns. 
     * @param sDate
     * @return
     */
    public static String validChkTime(String timeStr) {
    	String _timeStr = timeStr;
    	
    	if (_timeStr.length() == 5) {
    		_timeStr = NidStringUtil.remove(_timeStr,':');
    	}
    	if (_timeStr == null || !(_timeStr.trim().length() == 4)) {
    	    throw new IllegalArgumentException("Invalid time format: " + _timeStr);
    	}

    	return _timeStr;
    }
    
    /**
     * convert date/time string to XMLGregorianCalendar
     * @param date value
     * @param date format (eg yyyyMMdd)
     * @param time zone set status
     * @return
     */
    public static XMLGregorianCalendar 
    convertStringDateToXmlGregorianCalendar( String dateStr, String dateFormat, boolean noTimezone ) throws Exception{

	    try
	    {
	        // this may throw DatatypeConfigurationException
	        DatatypeFactory datatypeFactory = DatatypeFactory.newInstance();
	        GregorianCalendar calendar = new GregorianCalendar();
	        // reset all fields
	        calendar.clear();
	
	        Calendar parsedCalendar = Calendar.getInstance();
	        // eg "yyyy-MM-dd"
	        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.getDefault());
	        // this may throw ParseException
	        Date rawDate = sdf.parse( dateStr );
	        parsedCalendar.setTime( rawDate );
	
	        // set date from parameter and leave time as default calendar values
	        calendar.set( parsedCalendar.get( Calendar.YEAR ), 
	                        parsedCalendar.get( Calendar.MONTH ),
	                        parsedCalendar.get( Calendar.DATE ) );
	
	        XMLGregorianCalendar xmlCalendar = datatypeFactory.newXMLGregorianCalendar( calendar );
	        // clears default timezone
	        if ( noTimezone )
	        {
	            xmlCalendar.setTimezone( DatatypeConstants.FIELD_UNDEFINED );
	        }
	
	        return xmlCalendar;
	    	
	    } catch (Exception e){
	    	throw e;
	    }
	}

    /**  
     * Converts a the Date to a string in the following format : yyyy/MM/dd   
     * @param inputeDate  
     * @return String - date in the following format: yyyy/MM/dd  
     */  
    public static String convertXMLGregorianCalendarToString(XMLGregorianCalendar xmlGregorianCalendar, String dateFormat){   
    	Date carDate =  null;
        if(xmlGregorianCalendar!=null){   
            XMLGregorianCalendar calendar = xmlGregorianCalendar;   
            carDate = new Date(calendar.toGregorianCalendar().getTimeInMillis());   
        }  
    	
    	if (carDate == null){   
    		carDate = new Date();   
        }   
        //String DATE_FORMAT = "yyyy/MM/dd";   
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.getDefault());   
        return sdf.format(carDate);   
    }
}

