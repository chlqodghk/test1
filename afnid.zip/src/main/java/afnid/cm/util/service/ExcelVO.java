package afnid.cm.util.service;

import java.util.List;

import afnid.cm.ComDefaultVO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This class is Value Object to Excel download 
 * 
 * @author Afghanistan National ID Card System Application Team Daesung Kim
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.06.11 		Daesung Kim	      		 		Create
 *
 * </pre>
 */
public class ExcelVO extends ComDefaultVO{
    private static final long serialVersionUID = 1L;
    
    /** Excel File Name */
    private java.lang.String fileName;
    
    /** Title */
    private java.lang.String title;
    
    /** Excel sheet name List Value ID */
    private java.util.List<String> sheetName;
    
    /** Excel sheetFlag Value ID */
    private java.lang.String sheetFlagId;
    
    /** Excel Header Information */
    private java.util.List<String> headerInfo;
    
    /** Excel Header Information */
    private java.util.List<Integer> columnWidth;
    
    /** Key ID  for get EgovMap Value*/
    private java.util.List<String> keyId;
    
    /** Excel Polling Station Name*/
    private java.lang.String poliStaNm;
    
    /** Excel File Value list*/
    private List<EgovMap> listValue;
    

	public java.util.List<Integer> getColumnWidth() {
		return columnWidth;
	}

	public void setColumnWidth(java.util.List<Integer> columnWidth) {
		this.columnWidth = columnWidth;
	}

	public java.lang.String getPoliStaNm() {
		return poliStaNm;
	}

	public void setPoliStaNm(java.lang.String poliStaNm) {
		this.poliStaNm = poliStaNm;
	}

	public java.lang.String getFileName() {
		return fileName;
	}

	public void setFileName(java.lang.String fileName) {
		this.fileName = fileName;
	}

	public java.lang.String getTitle() {
		return title;
	}

	public void setTitle(java.lang.String title) {
		this.title = title;
	}

	public java.util.List<String> getSheetName() {
		return sheetName;
	}

	public void setSheetName(java.util.List<String> sheetName) {
		this.sheetName = sheetName;
	}

	public java.lang.String getSheetFlagId() {
		return sheetFlagId;
	}

	public void setSheetFlagId(java.lang.String sheetFlagId) {
		this.sheetFlagId = sheetFlagId;
	}

	public java.util.List<String> getHeaderInfo() {
		return headerInfo;
	}

	public void setHeaderInfo(java.util.List<String> headerInfo) {
		this.headerInfo = headerInfo;
	}

	public java.util.List<String> getKeyId() {
		return keyId;
	}

	public void setKeyId(java.util.List<String> keyId) {
		this.keyId = keyId;
	}

	public java.util.List<EgovMap> getListValue() {
		return listValue;
	}

	public void setListValue(java.util.List<EgovMap> listValue) {
		this.listValue = listValue;
	}
   	    
    
}
