/**
 *  Class Name : EgovFileTool.java
 *  Description : Verify the information provided by the system directory Business class.
 *  << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   -------    --------    ---------------------------
 *   2009.01.13    Jaeyoung Jo       CREATE
 *
 *  @author Jaeyoung Jo, Jiwook Pake
 *  @since 2009. 01. 13
 *  @version 1.0
 *  @see 
 * 
 *  Copyright (C) 2009 by MOPAS  All right reserved.
 */
package afnid.cm.util.service;
import java.io.BufferedReader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Vector;

public class NidFleTool {
    
    // File size 1K
    static final long BUFFER_SIZE     = 1024L;
    // File separator
    static final char FILE_SEPARATOR     = File.separatorChar;
    // Windows System File Restrictions
    static final char ACCESS_READ     = 'R';    // Read-only
    static final char ACCESS_SYS     = 'S';    // System	
    static final char ACCESS_HIDE     = 'H';    // Hiding
    // The maximum character length
    static final int MAX_STR_LEN = 1024;
  
    // Log
    //protected static final Log log = LogFactory.getLog(EgovFileTool.class);
    
    /**
     * <pre>
     * Comment : Check whether the directory exists. (For confirmation of a single directory)
     * </pre>
     * @param String targetDirPath  The absolute path of the directory to check for the presence
     * @return String result   Returns the directory path that exists.
     */
    public static boolean getExistDirectory(String targetDirPath) throws Exception {
        
        // An invalid argument returns a space.
        if (targetDirPath==null || targetDirPath.equals("")){
            return false;
        }
        
        boolean result = false;
        File f = null;
        try
        {   
            f = new File (targetDirPath);
            if(f.exists() && f.isDirectory()){
                result = true;
            }
            
        }catch(Exception e){
        	e.getMessage();
        }
        
        return result;
    }
    
    /**
     * <pre>
     * Comment : Check whether the directory exists. (Sub-directory for confirmation)
     * </pre>
     * @param String baseDirPath  Criteria to determine the presence of the directory path name
     * @param String targetDirPath  Check the target directory. baseDirPath confirm the presence in the sub.
     * @param int cnt           Check the directory number (0 should be greater than the input. -1 To seek input supports up to 21474846)
     * @return String result   Returns the directory path that exists.
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList getExistDirectory(String baseDirPath, String targetDirPath, int cnt) throws Exception {
       
        // Argument is invalid, return an empty ArrayList
        if (baseDirPath==null || baseDirPath.equals("") || targetDirPath==null || targetDirPath.equals("") || cnt==0){
            return new ArrayList();
        }
        int dirCnt = 0;
        if(cnt < 0 ) dirCnt = 21474846;
        else dirCnt = cnt;
        
        // ArrayList deliver the results found
        ArrayList result = new ArrayList();
        // Temporarily storing the results of the sub ArrayList.
        ArrayList subResult = new ArrayList();
        // Current Path (baseDir Path) found in the number of targetDir Path.
        int dirFindCnt = 0;
        boolean isExist = false;
        String[] dirList = null; 
        String subDirPath = "";
        File f = null;
        
        try
        {   
            f = new File (baseDirPath);
            isExist = f.exists();
            
            if(isExist){
                dirList = f.list();
            }
            for (int i = 0; dirList != null && i < dirList.length; i++) {
                //log.debug("dirList["+i+"]:"+dirList[i] +"--->"+baseDirPath+"/"+dirList[i]);
                subDirPath = baseDirPath+"/"+dirList[i];
                //log.debug("_"+targetDirPath+"_");
                //log.debug("_"+dirList[i]+"_");
                
                f = new File(subDirPath);
                
                //Current path (baseDirPath) search in.
                if(targetDirPath.equals(dirList[i])){
                    // If you find out in the middle of the iteration is terminated. (Results only if the number of requests has been reached) - Here is terminated after the child does not need to be checked on.
                    if(new File(baseDirPath+"/"+dirList[i]).isDirectory()){
                        dirFindCnt++;
                        result.add(baseDirPath+"/"+dirList[i]);
                        if(dirFindCnt == dirCnt)
                            break;
                    }
                }
                
                //Current path (baseDirPath) found in the sub-path search recursively repeated.
                int subCnt = dirCnt-dirFindCnt;
                if(f.isDirectory()){
                    //log.debug("f.isDirectory():"+f.isDirectory());
                    subResult = getExistDirectory(subDirPath,targetDirPath, subCnt);
                    // The number of sub-directories found in the current directory to find the number is added to.
                    dirFindCnt = dirFindCnt + subResult.size();
                    // Repeat the check is found to lower both the ends.
                    if(dirCnt<=dirFindCnt){ 
                        for(int j =0; j< subResult.size(); j++){
                            result.add((String)subResult.get(j));
                        }
                        
                        break;
                    }else{
                        for(int j =0; j< subResult.size(); j++){
                            result.add((String)subResult.get(j));
                        }
                    }
                }
            }
        }catch(Exception e){
        	e.getMessage();
        }
        
        return result;
    }
    
    /**
     * <pre>
     * Comment :Check whether the directory exists. (Date of creation is subject to the conditions contained in section check).
     * </pre>
     * @param String targetDirPath  The absolute path of the directory to check for the presence.
     * @param String fromDate  Conditions are true, the start date for the date of creation (YYYYMMDD form input).
     * @param String toDate    End date that corresponds to the date of creation conditions (YYYYMMDD form input).
     * @return String result   Returns the directory path that exists.
     */
    public static boolean getExistDirectory(String targetDirPath, String fromDate, String toDate) throws Exception {
        
        // An invalid argument returns a space.
        if (targetDirPath==null || targetDirPath.equals("") || fromDate==null || fromDate.equals("") || toDate==null || toDate.equals("")){
            return false;
        }
        
        boolean result = false;
        String lastModifyedDate = "";        
        File f = null;
        
        try
        {
            f = new File (targetDirPath);
            lastModifyedDate = getLastModifiedDateFromFile(f);
            //log.debug("getLastModifiedDateFromFile(f):"+lastModifyedDate);
            if(Integer.parseInt(lastModifyedDate) >= Integer.parseInt(fromDate) 
                    && Integer.parseInt(lastModifyedDate) <= Integer.parseInt(toDate) ){
                result = true;
            }
            
        }catch(Exception e){
        	e.getMessage();
        }
        
        return result;
    }

    
    /**
     * <pre>
     * Comment : Directory (file) will determine the last modification date.(Based on the default locale java.util.Locale.KOREA)
     * </pre>
     * @param File f Determine the destination file modification date.
     * @return String result Last modification date is returned as a string.
     */
    public static String getLastModifiedDateFromFile(File f){
       
        String result = "";
        try{
            if(f.exists()){
                long date  = f.lastModified();
                java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.KOREA);
                result = dateFormat.format(new java.util.Date(date));
            }else{
                result = "";
            }
        }catch(Exception e){
        	e.getMessage();
        }
        
        return result;
    }
    
    /**
     * <pre>
     * Comment : Directory (file) will determine the last modification date. (Based on the default locale java.util.Locale.KOREA)
     * </pre>
     * @param String filePath Determine the path to the destination file modification date.
     * @return String result Last modification date is returned as a string.
     */
    public static String getLastModifiedDateFromFile(String filePath){
        
        File f = null;
        String result = "";
        try
        {
            f = new File(filePath);
            result = getLastModifiedDateFromFile(f);
        }catch (Exception e ){
        	e.getMessage();
        }
        
        return result;
    }
    
    /**
     * <pre>
     * Comment : Conditions in the region will display a list of the directory you created.
     * </pre>
     * @param String filePath Determine the path to the subdirectory
     * @param String fromDate Started conditions
     * @param String toDate   End conditions
     * @return ArrayList result Conditions in the region will return a list of the directory you created.
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList getLastDirectoryForModifiedDate(String baseDirPath , String fromDate, String toDate){
        
        // Argument is invalid, return an empty ArrayList.
        if (baseDirPath==null || baseDirPath.equals("") || fromDate==null || fromDate.equals("") || toDate==null || toDate.equals("")){
            return new ArrayList();
        }
        
        File f = null;
        File childFile = null;
        String[] subDirList;
        String subDirPath = "";
        ArrayList childResult = null;
        ArrayList result = new ArrayList();
        
        try
        {
            f = new File(baseDirPath);
            subDirList  = f.list();
            for(int i=0; i<subDirList.length; i++){
                
                subDirPath = baseDirPath+"/"+subDirList[i];
                childFile = new File(subDirPath); 
                if(childFile.isDirectory()){
                    //childResult = getLastDirectoryForModifiedDate(subDirPath , fromDate, toDate);
                    String lastModifyedDate = getLastModifiedDateFromFile(childFile);
                    if(Integer.parseInt(lastModifyedDate) >= Integer.parseInt(fromDate)
                            && Integer.parseInt(lastModifyedDate) <= Integer.parseInt(toDate) ){
                        result.add(baseDirPath+"/"+subDirList[i]);
                    }
                    childResult = getLastDirectoryForModifiedDate(baseDirPath+"/"+subDirList[i] , fromDate, toDate);
                    // Add the results of sub-directories.
                    for(int j =0; j< childResult.size(); j++){
                        result.add((String)childResult.get(j));
                    }
                }
            }
        }catch (Exception e ){
        	e.getMessage();
        }
        
        return result;
    }
    
    /**
     * <pre>
     * Comment : Directory (file) Make sure the Read permission.
     * </pre>
     * @param String filePath Check the read destination file path.
     * @return boolean result Returns true if readable. If the file does not exist, do not have the authority to return false.
     */
    public static boolean canRead(String filePath){
        
        //An invalid argument returns false if empty.
        if (filePath==null || filePath.equals("") ){
            return false;
        }
        
        File f = null;
        boolean result = false;
        try
        {
            f = new File(filePath);
            if(f.exists()){
                result = f.canRead();    
            }
        }catch (Exception e ){
        	e.getMessage();
        }
        
        return result;
    }
    
    /**
     * <pre>
     * Comment : Directory (file) check write permissions. (Destination path for a file, but the information is valid).
     * </pre>
     * @param String filePath Determine the path to the target file writable.
     * @return boolean result Returns true if writable. If the file does not exist, do not have the authority to return false.
     */
    public static boolean canWrite(String filePath){
        
        // An invalid argument returns false if empty.
        if (filePath==null || filePath.equals("") ){
            return false;
        }
        
        File f = null;
        boolean result = false;
        try
        {
            f = new File(filePath);
            if(f.exists()){
                result = f.canWrite();    
            }
        }catch (Exception e ){
        	e.getMessage();
        }
        
        return result;
    }
    
    /**
     * <pre>
     * Comment : Directory (file) to determine the name of the.
     * </pre>
     * @param String filePath Resolve the name of the target path.
     * @return String result Returns the name. If it does not exist, a blank is returned.
     */
    public static String getName(String filePath){
        
        // An invalid argument returns false if empty.
        if (filePath==null || filePath.equals("") ){
            return "";
        }
        
        File f = null;
        String result = "";
        try
        {
            f = new File(filePath);
            if(f.exists()){
                result = f.getName();    
            }
        }catch (Exception e ){
        	e.getMessage();
        }
        
        return result;
    }
    
    /**
     * <pre>
     * Comment : Directory (file) will be deleted. (Files, directories, regardless if there is an unconditional delete)
     * </pre>
     * @param filePathToBeDeleted The absolute path of the file you want to delete + file
     * @return If successful, the absolute path is deleted or blank.
     */

    public  static String deletePath(String filePath){
        File file = new File(filePath);
        String result = "";
        try{

           if(file.exists()){
                result = file.getAbsolutePath();
                if(!file.delete()){
                    result="";
                }
            }
        }catch (Exception e){
        	e.getMessage();
        }
        return result;
    }
    
    /**
     * <pre>
     * Comment : Create a directory.
     * </pre>
     * @param dirPath Absolute path in which you want to create.
     * @return If successful saeseong absolute path, or a blank.
     */

    public  static String createDirectory(String dirPath){
        File file = new File(dirPath);
        String result = "";
        try{
//            if(file.exists()){
//            	//log.debug("File Exist..");
//            }else{
//                file.createNewFile();
//                file.getAbsolutePath();
//            }


        if(!file.exists()){
            file.createNewFile();
            file.getAbsolutePath();
        }
            
        }catch (Exception e){
        	e.getMessage();
        }
        return result;
    }
     
     /**
     * Check that the file exists in the directory to function.
     * @param String dir directory
     * @param String file file
     * @return boolean result The presence True / False
     * @exception Exception
    */
    @SuppressWarnings("rawtypes")
	public static boolean checkFileExstByName(String dir, String file) throws Exception {
        
        // Whether the file exists
        boolean result = false;
        
        // Open Directory
        String drctry = dir.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File srcDrctry = new File(drctry);
        
        // While the directory, if present.
        if (srcDrctry.exists() && srcDrctry.isDirectory()) {
            
            // Lookup Directory is not a list. (Filename)
            File [] fileArray = srcDrctry.listFiles();
            ArrayList list = getSubFilesByName(fileArray, file);
            if (list != null && list.size() > 0) {
                result = true;
            }
        }
        
        return result;
    }
    
    /**
     * By extension, to check that the file exists in the directory function.
     * @param String dir directory
     * @param String eventn Extension(.txt Form input)
     * @return boolean result The presence True / False
     * @exception Exception
    */
    @SuppressWarnings("rawtypes")
	public static boolean checkFileExstByExtnt(String dir, String eventn) throws Exception {
        
        // Whether the file exists
        boolean result = false;
        
        // Open Directory
        String drctry = dir.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File srcDrctry = new File(drctry);
        
        // While the directory, if present
        if (srcDrctry.exists() && srcDrctry.isDirectory()) {
            
            // Lookup Directory is not a list. (By extension)
            File [] fileArray = srcDrctry.listFiles();
            ArrayList list = getSubFilesByExtnt(fileArray, eventn);
            if (list != null && list.size() > 0) {
                result = true;
            }
        }
        
        return result;
    }

    
    /**
     * Modified from time to time to check that the file exists in the directory function.
     * @param String dir Directory
     * @param String updtFrom Edited Date From (YYYYMMDD form input)
     * @param String updtTo Modification date To (YYYYMMDD form input)
     * @return boolean result The presence True / False
     * @exception Exception
    */
    @SuppressWarnings("rawtypes")
	public static boolean checkFileExstByUpdtPd(String dir, String updtFrom, String updtTo) throws Exception {
        
        // Whether the file exists
        boolean result = false;
        
        // Open Directory
        String drctry = dir.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File srcDrctry = new File(drctry);
        
        // While the directory, if present.
        if (srcDrctry.exists() && srcDrctry.isDirectory()) {
            
            // Lookup Directory is not a list. (Modified by period)
            File [] fileArray = srcDrctry.listFiles();
            ArrayList list = getSubFilesByUpdtPd(fileArray, updtFrom, updtTo);
            if (list != null && list.size() > 0) {
                result = true;
            }
        }
        
        return result;
    }
    
    /**
     * By size to check if the file exists in the directory function.
     * @param String dir Directory
     * @param long sizeFrom From the size (KB)
     * @param long sizeTo Size To (KB)
     * @return boolean result The presence True / False
     * @exception Exception
    */
    @SuppressWarnings("rawtypes")
	public static boolean checkFileExstBySize(String dir, long sizeFrom, long sizeTo) throws Exception {
        
        // Whether the file exists
        boolean result = false;
        
        // Open Directory
        String drctry = dir.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File srcDrctry = new File(drctry);
        
        //While the directory, if present.
        if (srcDrctry.exists() && srcDrctry.isDirectory()) {
            
            // Lookup Directory is not a list. (By size)
            File [] fileArray = srcDrctry.listFiles();
            ArrayList list = getSubFilesBySize(fileArray, sizeFrom, sizeTo);
            if (list != null && list.size() > 0) {
                result = true;
            }
        }
        
        return result;
    }
    
    /**
     * Inside the sub-list of directories looking for files of functions (all list views)
     * @param File[] fileArray List of files
     * @return ArrayList list File list (absolute path)
     * @exception Exception
    */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList getSubFilesByAll(File[] fileArray) throws Exception {
        
        ArrayList list = new ArrayList();
        
        for (int i = 0; i < fileArray.length; i++) {
            // If the list of files within the directory in the directory to look in the recursive call.
            if (fileArray[i].isDirectory()) {
                File [] tmpArray = fileArray[i].listFiles();
                list.addAll(getSubFilesByAll(tmpArray));
            // If the file damneunda.
            } else {
                list.add(fileArray[i].getAbsolutePath());
            }
        }
        
        return list;
    }
    
    /**
     * Among the list of directories looking for files inside the sub function (file)
     * @param File[] fileArray List of files
     * @param String file File Name
     * @return ArrayList list File list (absolute path)
     * @exception Exception
    */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList getSubFilesByName(File[] fileArray, String file) throws Exception {
        
        ArrayList list = new ArrayList();
        
        for (int i = 0; i < fileArray.length; i++) {
            // If the list of files within the directory in the directory to look in the recursive call.
            if (fileArray[i].isDirectory()) {
                File [] tmpArray = fileArray[i].listFiles();
                list.addAll(getSubFilesByName(tmpArray, file));
            // File, the file is compared for equality.
            } else {
                if (fileArray[i].getName().equals(file)) {
                    list.add(fileArray[i].getAbsolutePath());
                }
            }
        }
        
        return list;
    }
    
    /**
     * Inside the sub-list of directories looking for files of functions (by extension)
     * @param File[] fileArray List of files
     * @param String extnt Extension
     * @return ArrayList list File list (absolute path)
     * @exception Exception
    */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList getSubFilesByExtnt(File[] fileArray, String extnt) throws Exception {
        
        ArrayList list = new ArrayList();
        
        for (int i = 0; i < fileArray.length; i++) {
            // If the list of files within the directory in the directory to look in the recursive call.
            if (fileArray[i].isDirectory()) {
                File [] tmpArray = fileArray[i].listFiles();
                list.addAll(getSubFilesByExtnt(tmpArray, extnt));
            // If the file extension for people that are compared.
            } else {
                if (fileArray[i].getName().indexOf(extnt) != -1) {
                    list.add(fileArray[i].getAbsolutePath());
                }
            }
        }
        
        return list;
    }
    
    /**
     * Inside the sub-list of directories looking for files of functions (Last edited by period)
     * @param File[] fileArray List of files
     * @param String updtFrom Edited Date From (YYYYMMDD form input)
     * @param String updtTo Modification date To (YYYYMMDD form input)
     * @return ArrayList list File list (absolute path)
     * @exception Exception
    */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList getSubFilesByUpdtPd(File[] fileArray, String updtFrom, String updtTo) throws Exception {
        
        ArrayList list = new ArrayList();
        
        for (int i = 0; i < fileArray.length; i++) {
            // If the list of files within the directory in the directory to look in the recursive call.
            if (fileArray[i].isDirectory()) {
                File [] tmpArray = fileArray[i].listFiles();
                list.addAll(getSubFilesByUpdtPd(tmpArray, updtFrom, updtTo));
            // If the file exists on compares the modification period.
            } else {
                // Last modification date of a file lookup.
                long date  = fileArray[i].lastModified();
                java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.KOREA);
                String lastUpdtDate = dateFormat.format(new java.util.Date(date));
                // Verify that there is modification period.
                if(Integer.parseInt(lastUpdtDate) >= Integer.parseInt(updtFrom) 
                        && Integer.parseInt(lastUpdtDate) <= Integer.parseInt(updtTo) ){
                    list.add(fileArray[i].getAbsolutePath());
                }
            }
        }
        
        return list;
    }
    
    /**
     * Inside the sub-list of directories looking for files of functions (by size)
     * @param File[] fileArray List of files
     * @param long sizeFrom Size From (KB)
     * @param long sizeTo Size To (KB)
     * @return ArrayList list File list (absolute path)
     * @exception Exception
    */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList getSubFilesBySize(File[] fileArray, long sizeFrom, long sizeTo) throws Exception {
        
        ArrayList list = new ArrayList();
        
        for (int i = 0; i < fileArray.length; i++) {
            // If the list of files within the directory in the directory to look in the recursive call.
            if (fileArray[i].isDirectory()) {
                File [] tmpArray = fileArray[i].listFiles();
                list.addAll(getSubFilesBySize(tmpArray, sizeFrom, sizeTo));
            //If the file size is compared in the presence of.
            } else {
                // The size of the file lookup
                long size  = fileArray[i].length();
                // Size confirm that exist within
                if(size >= (sizeFrom*BUFFER_SIZE) && size <= (sizeTo*BUFFER_SIZE)){
                    list.add(fileArray[i].getAbsolutePath());
                }
            }
        }
        
        return list;
    }
    

    
    /**
     * <pre>
     * Comment : Create a directory.
     * </pre>
     * @param dirPathAbsolute path in which you want to create.
     * @return If successful saeseong absolute path, or a blank.
     */

    public  static String createNewDirectory(String dirPath){
       
        // Argument is invalid, return blank.
        if (dirPath==null || dirPath.equals("")){
            return "";
        }
        
        File file = new File(dirPath);
        String result = "";
        try{
            // If you do not create.
            if(file.exists()){
                // If you create a file even exists - is not generated (in practice does not proceed below)
                if(file.isFile()){
                    //new File(file.getParent()).mkdirs();
                    if (file.mkdirs()){
                        result = file.getAbsolutePath();    
                    }
                }else{
                    result = file.getAbsolutePath(); 
                }
            }else{
                // If you do not infringe existing generation.
                if (file.mkdirs()){
                    result = file.getAbsolutePath();
                }
            }
        }catch (Exception e){
        	e.getMessage();
        }
       
        return result;
    }
    
    /**
     * <pre>
     * Comment : File is created.
     * </pre>
     * @param String fileName 
     * @param String content   ex) c:/test/test1/test44.txt
     *
     */
    public  static String createNewFile(String filePath){
      
        // Argument is invalid, return blank.
        if (filePath==null || filePath.equals("")){
            return "";
        }
        
        File file = new File(filePath);
        String result = "";
        try{
            if(file.exists()){
                   result = filePath;
            }else{
                // That does not exist, create.
                new File(file.getParent()).mkdirs();
                if(file.createNewFile()){
                    result = file.getAbsolutePath();
                }
            }
        }catch (Exception e){
        	e.getMessage();
        }
       
        return result;
    }
    

    /**
     * <pre>
     * Comment : Files are deleted. 
     * </pre>
     * @param fileDeletePath The absolute path of the file you want to delete.
     * @return If successful, the absolute path of a file that has been deleted, or blank.
     */

    public  static String deleteFile(String fileDeletePath){
        
        // Argument is invalid, return blank.
        if (fileDeletePath==null || fileDeletePath.equals("")){
            return "";
        }
        String result="";
        File file = new File(fileDeletePath);
        if(file.isFile()){
            result = deletePath(fileDeletePath);
        }else{
            result = "";
        }
        
        return result;
    }
    
    /**
     * Check the permissions of the file read.
     * @param String file (file)
     * @return boolean result Read. True / False
     * @exception Exception
    */
    public static boolean checkReadAuth(String file) throws Exception {
        
        // Read availability
        boolean result = false;            
        
        try
        {   
            // Passed through the path to the file to create an instance.
            String file1 = file.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
            File srcFile = new File(file1);
            
            // Make exists.
            if (srcFile.exists()) {
                // Check whether it is read.
                result = srcFile.canRead();
            }
            
        } catch (Exception ex){
        	ex.getMessage();
        } 
        
        return result;
    }
    
    /**
     * Check the write permission of the file.
     * @param String file (file)
     * @return boolean result Permission to write True / False
     * @exception Exception
    */
    public static boolean checkWriteAuth(String file) throws Exception {
        
        // Availability write
        boolean result = false;            
        
        try
        {   
            // Passed through the path to the file to create an instance.
            String file1 = file.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
            File srcFile = new File(file1);
            
            // Make exists.
            if (srcFile.exists()) {
                //Check writable..
                result = srcFile.canWrite();
            }
        } catch (Exception ex){
        	ex.getMessage();
        } 
        
        return result;
    }
    
    /**
     * Views by date last modified of the file to the file list function.
     * @param String drctry Directory
     * @param String updtDate Last modification date (YYYYMMDD form input)
     * @return ArrayList list List of files 
     * @exception Exception
    */
    @SuppressWarnings("rawtypes")
	public static ArrayList getFileListByDate(String drctry, String updtDate) throws Exception {
        
        // The list of results
        ArrayList list = null;
        
        // Open Directory
        String drctry1 = drctry.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File file = new File(drctry1);
        
        // Directory, and the file list, such as self-presence Last Modified Start Query.
        if (file.exists() && file.isDirectory()) {
            File [] fileArray = file.listFiles();
            list = getSubFilesByDate(fileArray, updtDate);
        }
        
        return list;
    }
    
    /**
     * Period of the last modification of the file to query the file list function.
     * @param String drctry Directory
     * @param String updtFrom Last modification date From (YYYYMMDD form input)
     * @param String updtTo Last modification date To (YYYYMMDD form input)
     * @return ArrayList list List of files 
     * @exception Exception
    */
    @SuppressWarnings("rawtypes")
	public static ArrayList getFileListByUpdtPd(String drctry, String updtFrom, String updtTo) throws Exception {
        
        // The list of results
        ArrayList list = null;
        
        // Open Directory
        String drctry1 = drctry.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File file = new File(drctry1);
        
        //Directory, and a list of files that exist query period last modified start.
        if (file.exists() && file.isDirectory()) {
            File [] fileArray = file.listFiles();
            list = getSubFilesByUpdtPd(fileArray, updtFrom, updtTo);
        }
        
        return list;
    }
    
    /**
     * Last Modified subdirectory contains a list of files, such as self-seeking function.
     * @param File fileArray List of files
     * @param String updtDate Last modification date (YYYYMMDD form input)
     * @return ArrayList list List of files
     * @exception Exception
    */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static ArrayList getSubFilesByDate(File [] fileArray, String updtDate) throws Exception {
        
        ArrayList list = new ArrayList();
        
        for (int i = 0; i < fileArray.length; i++) {
            // If the list of files within the directory in the directory to look in the recursive call.
            if (fileArray[i].isDirectory()) {
                File [] tmpArray = fileArray[i].listFiles();
                list.addAll(getSubFilesByDate(tmpArray, updtDate));
            // File, the file is compared for equality.
            } else {
                // File last modification date views.
                long date  = fileArray[i].lastModified();
                java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.KOREA);
                String lastUpdtDate = dateFormat.format(new java.util.Date(date));
                if(Integer.parseInt(lastUpdtDate) == Integer.parseInt(updtDate)){
                    list.add(fileArray[i].getAbsolutePath());
                }
            }
        }
        
        return list;
    }
    
    /**
     * Specific file separator (',', '|', 'TAB') with the ability to parse.
     * @param String parFile File
     * @param String parChar Separator (',', '|', 'TAB')
     * @param int parField Number of fields
     * @return Vector parResult Structure parsing results
     * @exception Exception
    */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static Vector parsFileByChar(String parFile, String parChar, int parField) throws Exception {
        
        // Structure parsing results
        Vector parResult = new Vector();

        // File Open
        String parFile1 = parFile.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File file = new File(parFile1);
        BufferedReader br = null;
        try {
        	// File and start parsing exists.
            if (file.exists() && file.isFile()) {
                
                // 1. StringBuffer text file to read the contents of laps.
                br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
                StringBuffer strBuff = new StringBuffer();
                String line = "";
                while ((line = br.readLine()) != null) {
                	if (line.length() < MAX_STR_LEN) strBuff.append(line);
                }
                
                // 2. Information gained by parsing the String array as a separator get into.
                String[] strArr = NidStringUtil.split(strBuff.toString(), parChar);
                
                // 3. Vector <ArrayList> number of fields in the form are made rotate.
                int filedCnt = 1;
                ArrayList arr = null;
                for (int i = 0; i < strArr.length; i++) {
                    
                    if (parField != 1) {
                        if ((filedCnt%parField) == 1) {
                            arr = new ArrayList();
                            if (strArr[i] != null) arr.add(strArr[i]);
                            if (i == (strArr.length - 1)) {
                                parResult.add(arr);
                            }
                        } else if ((filedCnt%parField) == 0) {
                        	if (strArr[i] != null) arr.add(strArr[i]);
                            parResult.add(arr);
                        } else {
                        	if (strArr[i] != null) arr.add(strArr[i]);
                            if (i == (strArr.length - 1)) {
                                parResult.add(arr);
                            }
                        }
                    } else {
                        arr = new ArrayList();
                        if (strArr[i] != null) arr.add(strArr[i]);
                        parResult.add(arr);
                    }
                    
                    filedCnt++;
                }
            }
        } catch(Exception ex) {
        	ex.getMessage();
    	} finally {
			if (br != null) br.close();
		}
		
        return parResult;
    }
    
    /**
     * The ability to parse a file with a certain length.
     * @param String parFile File
     * @param int[] parLen The length of each field
     * @param int parLine The number of lines to read.
     * @return Vector parResult The structure parsed results.
     * @exception Exception
    */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static Vector parsFileBySize(String parFile, int[] parLen, int parLine) throws Exception {
        
        //The structure parsed results.
        Vector parResult = new Vector();

        // File Open
        String parFile1 = parFile.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File file = new File(parFile1);
        BufferedReader br = null;
        try {
        	// File and start parsing exists.
            if (file.exists() && file.isFile()) {
                
                // 1. Enter the number of lines by reading the contents of a text file, String [] Banks to.
                br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
                String [] strArr = new String [parLine];
                String line = "";
                int readCnt = 0;
                while ((line = br.readLine()) != null && readCnt < parLine) {
                	if (line.length() <= MAX_STR_LEN) strArr[readCnt++] = line;
                }
                
                // 2. Vector <ArrayList> made ​​in the form.
                for (int i = 0; i < strArr.length; i++) {
                    String text = strArr[i];
                    ArrayList arr = new ArrayList();
                    int idx = 0;
                    boolean result = false;
                    for (int j = 0; j < parLen.length; j++) {
                    	if(!result){ //if(result != true){
                    	        String split = "";
                        	if (text.length() < (idx + parLen[j])) {
                        		split = text.substring(idx, text.length());
                        		result = true;
                        	} else {
                        		split = text.substring(idx, idx + parLen[j]);
                        	}
                                arr.add(split);
                                idx = idx + parLen[j];
                    	}
                    }
                    parResult.add(arr);
                }
            }
        }catch(Exception e){
        	e.getMessage();
		}finally{
			if(br!=null) br.close();
		}
        
        return parResult;
    }
    
    /**
     * The ability to compare two file size (KB-wise comparison).
     * @param String cmprFile1 File 1
     * @param String cmprFile2 File 2
     * @return boolean result For the same True / False
     * @exception Exception
    */
    public static boolean cmprFilesBySize(String cmprFile1, String cmprFile2) throws Exception {
        
        // For the same file.
        boolean result = false;
        
        // File Open
        String cmprFile11 = cmprFile1.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        String cmprFile22 = cmprFile2.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File file1 = new File(cmprFile11);
        File file2 = new File(cmprFile22);
        
        // Is the file exists, the file size comparison.
        if (file1.exists() && file2.exists()
            && file1.isFile() && file2.isFile()) {
            
            // Files 1 Size
            long size1 = file1.length();
            
            // Files 2 Size
            long size2 = file2.length();
            
            // Size comparison
            if (size1 == size2) {
                result = true;
            }
            
        }
        
        return result;
    }
    
    /**
     * The ability to compare file modification date.
     * @param String cmprFile1 File 1
     * @param String cmprFile2 File 2
     * @return boolean result For the same True / False
     * @exception Exception
    */
    public static boolean cmprFilesByUpdtPd(String cmprFile1, String cmprFile2) throws Exception {
        
        // Whether the same file
        boolean result = false;
        
        // File Open
        String cmprFile11 = cmprFile1.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        String cmprFile22 = cmprFile2.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File file1 = new File(cmprFile11);
        File file2 = new File(cmprFile22);
        
        // Is the file exists, the file modification date comparison.
        if (file1.exists() && file2.exists()
            && file1.isFile() && file2.isFile()) {
            
            //1 file modification date
            long date1  = file1.lastModified();
            java.text.SimpleDateFormat dateFormat1 = new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.KOREA);
            String lastUpdtDate1 = dateFormat1.format(new java.util.Date(date1));
            
            // 2 file modification date
            long date2  = file2.lastModified();
            java.text.SimpleDateFormat dateFormat2 = new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.KOREA);
            String lastUpdtDate2 = dateFormat2.format(new java.util.Date(date2));

            // Compare modification date.
            if (lastUpdtDate1.equals(lastUpdtDate2)) {
                result = true;
            }
        }
        
        return result;
    }
    
    /**
     * The ability to compare the contents of two files (TEXT files only).
     * @param String cmprFile1 File 1
     * @param String cmprFile2 File 2
     * @return boolean result For the same True / False
     * @exception Exception
    */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static boolean cmprFilesByContent(String cmprFile1, String cmprFile2) throws Exception {
        
        // Whether the same file
        boolean result = false;
        
        // File Open
        String cmprFile11 = cmprFile1.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        String cmprFile22 = cmprFile2.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File file1 = new File(cmprFile11);
        File file2 = new File(cmprFile22);
        
        BufferedReader br1 = null;
        try {
        	// Is the file exists, the file content comparison.
            if (file1.exists() && file2.exists()
                && file1.isFile() && file2.isFile()) {
                
                ArrayList cmprText1 = new ArrayList();
                ArrayList cmprText2 = new ArrayList();
                
                // For one text file.
                br1 = new BufferedReader(new InputStreamReader(new FileInputStream(file1)));
                String line1 = "";
                while ((line1 = br1.readLine()) != null) {
                	if (line1.length() < MAX_STR_LEN) cmprText1.add(line1);
                }
                
                // For two text files.
                BufferedReader br2 = new BufferedReader(new InputStreamReader(new FileInputStream(file2)));
                String line2 = "";
                while ((line2 = br2.readLine()) != null) {
                	if (line2.length() <= MAX_STR_LEN) cmprText2.add(line2);
                }
                
                // Compare
                boolean isWrong = false;
                for (int i = 0; i < cmprText1.size(); i++) {
                    if(!isWrong){ //   if(isWrong != true){
                        String text1 = (String)cmprText1.get(i);
                        String text2 = (String)cmprText2.get(i);
                        
                        if (!text1.equals(text2)) {
                            isWrong = true;
                        }
                    }
                }
                
                if (!isWrong) {
                    result = true;
                }
            }
        } catch(Exception ex) {
        	ex.getMessage();
		} finally {
			if (br1 != null) br1.close();
		}
        
        return result;
    }
    

    
    /**
     * Copy a single file to another file (Copy) is.
     * @param String source Source files.
     * @param String target The target file.
     * @return boolean result Copy Status True / False
     * @exception Exception
    */
    public static boolean copyFile(String source, String target) throws Exception {
        
        // Copy Status
        boolean result = false;        
        
        // The original file
        String src = source.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File srcFile = new File(src);
        
        // Target file
        String tar = target.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        
        try {
            // Make sure the original file exists.
            if (srcFile.exists()) {                
                
                // Create the target file to be copied.
                tar = createNewFile(tar);
                //log.debug("tar:"+tar);
                File tarFile = new File(tar);
                //log.debug("tarFile:"+tarFile.getAbsolutePath());
                // Radiation
                result = execCopyFile(srcFile, tarFile);
                
            }
            
        } catch (IOException ex){
        	ex.getMessage();
        }
        
        return result;
    }
    
    /**
     * Copy multiple files in different directories (Copy) is.
     * @param String source the original files
     * @param String target Target directory
     * @return boolean result Copy Status True / False
     * @exception Exception
    */
    public static boolean copyFiles(String [] source, String target) throws Exception {
        
        // Copy Status
        boolean result = true;        
        
        // opy of the file to be copied before the path is correct.
        for (int i = 0; i < source.length; i++) {
            String src = source[i].replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
            File chkFile = new File(src);
            if (!chkFile.exists()) {
               
                return result;
            }
        }
        
        String tar = target.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        
        // Copying begins.
        for (int j = 0; j < source.length; j++) {
            
            if(result){ //result != false
            
                // Naming the target file.
                File chkFile = new File(source[j]);
                String tarTemp = tar + FILE_SEPARATOR + chkFile.getName();
                
                try
                {   
                    // Create the target file to be copied.
                    tarTemp = createNewFile(tarTemp);
                    File tarFile = new File(tarTemp);
                    
                    // Radiation
                    result = execCopyFile(chkFile, tarFile);
                    
                } catch (IOException ex){
                	ex.getMessage();
                }
            
            }
            
        } // end for
        
        return result;
    }
    
    /**
     * By extension files in a different directory, copy (Copy) is.
     * @param String source the original directory.
     * @param String extnt Extension(.txt Form input)
     * @param String target Target directory
     * @return boolean result Copy Status True / False
     * @exception Exception
    */
    @SuppressWarnings("rawtypes")
	public static boolean copyFilesByExtnt(String source, String extnt, String target) throws Exception {
        
        // Copy Status
        boolean result = true;        
        
        //The original file
        String src = source.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File srcFile = new File(src);
        
        // Ensure that the original directory exists.
        if (srcFile.exists() && srcFile.isDirectory()) {
            
            String tar = target.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
            
            // the original list of files in a directory with a matching extension brings.
            File [] fileArray = srcFile.listFiles();
            ArrayList list = getSubFilesByExtnt(fileArray, extnt);
            
            // Copying begins.
            for (int i = 0; i < list.size(); i++) {
                if(result){ //f(result != false){
                    // Absolute path to The original file.
                    String abspath = (String)list.get(i);
                    
                    // Naming the target file
                    File chkFile = new File(abspath);
                    String tarTemp = tar + FILE_SEPARATOR + chkFile.getName();
                    
                    try
                    {   
                        // Create the target file to be copied.
                        tarTemp = createNewFile(tarTemp);
                        File tarFile = new File(tarTemp);
                        
                        // Radiation
                        result = execCopyFile(chkFile, tarFile);
                        
                    } catch (IOException ex){
                    	ex.getMessage();
                    }
                }
                
            } // end for
            
        }
        
        return result;
    }
    
    /**
     * Copy the files to another directory, modify the period (Copy) is.
     * @param String source original directory
     * @param String updtFrom Modify the start date (YYYYMMDD form input)
     * @param String updtTo Modify the termination date (YYYYMMDD form input)
     * @param String target Copy Status
     * @return boolean result Copy Status True / False
     * @exception Exception
    */
    @SuppressWarnings("rawtypes")
	public static boolean copyFilesByUpdtPd(String source, String updtFrom, String updtTo, String target) throws Exception {
        
        // Copy Status
        boolean result = true;        
        
        // The original file
        String src = source.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File srcFile = new File(src);
        
        // Check original directory exists.
        if (srcFile.exists() && srcFile.isDirectory()) {
            
            String tar = target.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
            
            // Modify original directory in the file list, brings the present period.
            File [] fileArray = srcFile.listFiles();
            ArrayList list = getSubFilesByUpdtPd(fileArray, updtFrom, updtTo);
            
            // Copying begins.
            for (int i = 0; i < list.size() ; i++) {
                
                if(result){ //f(result != false){
                
                    // Absolute path to The original file
                    String abspath = (String)list.get(i);
                    
                    // Naming the target file
                    File chkFile = new File(abspath);
                    String tarTemp = tar + FILE_SEPARATOR + chkFile.getName();
                    
                    try
                    {   
                        // Create the target file to be copied.
                        tarTemp = createNewFile(tarTemp);
                        File tarFile = new File(tarTemp);
                        
                        // Radiation
                        result = execCopyFile(chkFile, tarFile);
                        
                    } catch (IOException ex){
                    	ex.getMessage();
                    }
                
                }
                
            } // end for
            
        } 
        return result;
    }
    
    /**
     * The size of my files to another directory, copy (Copy) is.
     * @param String source original directory
     * @param Long sizeFrom The minimum size (KB)
     * @param Long sizeTo Maximum size (KB)
     * @param String target Target directory
     * @return boolean result Copy Status True / False
     * @exception Exception
    */
    @SuppressWarnings("rawtypes")
	public static boolean copyFilesBySize(String source, long sizeFrom, long sizeTo, String target) throws Exception {
        
        // Copy Status
        boolean result = true;        
        
        // The original file
        String src = source.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        File srcFile = new File(src);
        
        // Check original directory exists.
        if (srcFile.exists() && srcFile.isDirectory()) {
            
            String tar = target.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
            
            // Present in original list of files in a directory brings size.
            File [] fileArray = srcFile.listFiles();
            ArrayList list = getSubFilesBySize(fileArray, sizeFrom, sizeTo);
            
            // Copying begins.
            for (int i = 0; i < list.size(); i++) {
                
                if(result){ //result != false
                    // Absolute path to The original file
                    String abspath = (String)list.get(i);
                    
                    // Naming the target file
                    File chkFile = new File(abspath);
                    String tarTemp = tar + FILE_SEPARATOR + chkFile.getName();
                    
                    try
                    {   
                        // Create the target file to be copied.
                        tarTemp = createNewFile(tarTemp);
                        File tarFile = new File(tarTemp);
                        
                        // Radiation
                        result = execCopyFile(chkFile, tarFile);
                        if(result){break;}
                        
                    } catch (IOException ex){
                    	ex.getMessage();
                    }
                
                }
                
            } // end for
            
        }
        
        return result;
    }
    
    /**
     * The ability to perform the copy.
     * @param File srcFile The original file
     * @param File tarFile The target file
     * @return boolean result Copy Status True / False
     * @exception Exception
    */
    public static boolean execCopyFile(File srcFile, File tarFile) throws Exception {
        
        // result
        boolean result = false;
        FileInputStream fis = null;
        FileOutputStream fos = null;
        try {
            // Copy Status
            fis = new FileInputStream(srcFile); 
            
            //Added by exception processing. -> If you master tarFile this directory beneath the directory and copy the newly created file.. like DOS
            File tarFile1 = tarFile;
            if(tarFile1.isDirectory()){
            	tarFile1 = new File(tarFile1.getAbsolutePath()+"/"+srcFile.getName());
            }
            fos = new FileOutputStream(tarFile1); 
            byte [] buffer = new byte[(int)BUFFER_SIZE];
            int i = 0;
            if (fis != null && fos != null) {
            	while ((i = fis.read(buffer)) != -1) {
                    fos.write(buffer, 0, i);
                }
            }
            
            result = true;
        } catch (Exception ex) {
        	ex.getMessage();
        } finally {
        	if (fis != null) fis.close();
            if (fos != null) fos.close();
        }
        
        
        return result;
    }
    

    
    /**
     * <pre>
     * Comment : Directory is deleted.
     * </pre>
     * @param dirDeletePath The absolute path of the directory to be deleted (if the incoming path of the file is not deleted).
     * @return If successful, the absolute path is deleted or blank.
     */

    public  static String deleteDirectory(String dirDeletePath){
        
        // Argument is invalid, return blank.
        if (dirDeletePath==null || dirDeletePath.equals("")){
            return "";
        }
        String result="";
        File file = new File(dirDeletePath);
        if(file.isDirectory()){
            String[] fileList = file.list();
            //Delete all the files belonging.
            for(int i =0 ; i<fileList.length; i++){
                
                //log.debug("fileList["+i+"] : "+ dirDeletePath +"/"+fileList[i]);
                File f = new File(dirDeletePath+"/"+fileList[i]) ;
                if(f.isFile()){
                    //Delete all the files in the directory belong.
                    f.delete();
                }else{
                    //Belonging to the sub-directories in the directory Delete command makes recursive calls.
                    deleteDirectory(dirDeletePath+"/"+fileList[i]);
                }
            }
            //The files in the directory and sub-directory has been deleted, delete the directory itself.
            result = deletePath(dirDeletePath);
        }else{
            result = "";
        }
        
        return result;
    }
    
    /**
     * <pre>
     * Comment : Directory is deleted. (Remove the date of creation of conditions)
     * </pre>
     * @param dirDeletePath The absolute path of the directory you want to delete (the path to the file is not deleted when the incoming)
     * @param fromDate      The start date of the deleted directory condition.
     * @param toDate        The end date of the deleted directory condition.
     * @return If successful, the absolute path is deleted or blank.
     */
    public  static String deleteDirectory(String dirDeletePath, String fromDate, String toDate){
        
        // Argument is invalid, return blank.
        if (dirDeletePath==null || dirDeletePath.equals("")||fromDate==null || fromDate.equals("")||toDate==null || toDate.equals("")){
            return "";
        }
        
        // Deliver the results found ArrayList.
        String result = "";
        File file = new File(dirDeletePath);
                
        // Terms delete option has been added to ensure that reasonable.
        boolean isInCondition = false;
        String lastModifyedDate = getLastModifiedDateFromFile(file);
        //log.debug("lastModifyedDate:"+lastModifyedDate);
        try{
            if(Integer.parseInt(lastModifyedDate) >= Integer.parseInt(fromDate) 
                    && Integer.parseInt(lastModifyedDate) <= Integer.parseInt(toDate) ){
                isInCondition = true;
            }
            
            // Delete action deletes the directory that conditions are met.
            if(file.isDirectory() && isInCondition){      
                result = deleteDirectory(dirDeletePath);
            }
        }catch(Exception e){
        	e.getMessage();
        }
        
        return result;
    }

 
    /**
     * File (directory) directory exists (Parent) Function to search.
     * @param String file File (directory)
     * @return String drctryName Directory
     * @exception Exception
    */
    public static String getDrctryName(String file) throws Exception {
        
        String drctryName = "";
        String src = file.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        
        try
        {   
            File srcFile = new File(src);
            if (srcFile.exists()) {
                drctryName = srcFile.getParent();
            }
            
        } catch (Exception ex){
        	ex.getMessage();
        } 
        
        return drctryName;
    }
    
    /**
     * File (directory) the ability to query the file exists.
     * @param String file File (directory)
     * @return String fileName File Name
     * @exception Exception
    */
    public static String getFileName(String file) throws Exception {
        
        String fileName = "";
        String src = file.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        
        try
        {   
            File srcFile = new File(src);
            if (srcFile.exists()) {
                fileName = srcFile.getName();
            }
        } catch (Exception ex){
        	ex.getMessage();
        } 
        
        return fileName;
    }
    
    /**
     * File (directory) function to retrieve the last modification date.
     * @param String file File (directory)
     * @return String updtDate Last modification date (YYYYMMDD format)
     * @exception Exception
    */
    public static String getUpdtDate(String file) throws Exception {
        
        String updtDate = "";
        String src = file.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        
        try
        {   
            File srcFile = new File(src);
            if (srcFile.exists()) {
                long date  = srcFile.lastModified();
                java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.KOREA);
                updtDate = dateFormat.format(new java.util.Date(date));
            }
            
        } catch (Exception ex){
        	ex.getMessage();
        } 
        
        return updtDate;
    }
    

    /**
     * File (directory) to query the size of the function.
     * @param String file File (directory)
     * @return Long size size(Byte)
     * @exception Exception
    */
    public static long getSize(String file) throws Exception {
        
        long size = 0L;
        String src = file.replace('\\', FILE_SEPARATOR).replace('/', FILE_SEPARATOR);
        
        try
        {   
            File srcFile = new File(src);
            if (srcFile.exists()) {
                size = srcFile.length();
            }
        } catch (Exception ex){
            ex.getMessage();
        } 
        
        return size;
    }
    
    /**
     * <pre>
     * Comment :Copy the directory.
     * </pre>
     * @param String originalDirPath  The absolute path of original directory.
     * @param String targetDirPath  The absolute path of the target directory.
     * @return boolean result If the copy succeeds true, returns false if it fails.
     */
    public static boolean copyDirectory(String originalDirPath, String targetDirPath) throws Exception {
        
        // An invalid argument returns a space.
        if (originalDirPath==null || originalDirPath.equals("") || targetDirPath==null || targetDirPath.equals("")){
            return false;
        }
        boolean result = false;
        File f = null;
        try
        {   
            f = new File (originalDirPath);
            // The source must be available to proceed.
            if(f.exists() && f.isDirectory()){
                
                //Have targeted path is valid (in the middle of the path if it contains the file name is not valid because it does not proceed.)
                String targetDirPath1 = createNewDirectory(targetDirPath);
                if("".equals(targetDirPath1)){
                    result = false;
                }else{
                    File targetDir = new File(targetDirPath1);
                    targetDir.mkdirs();
                    // Copy the files in the directory belong.
                    String [] originalFileList = f.list();
                    if(originalFileList.length>0){
	                    for(int i = 0; i<originalFileList.length ; i++){
	                        File subF = new File (originalDirPath+FILE_SEPARATOR+originalFileList[i]);
	                        if(subF.isFile()){
	                            //This file is a list of sub-file copy running-> failed to stop the copy to occur.
	                            result = copyFile(originalDirPath+FILE_SEPARATOR+originalFileList[i],
	                                    targetDir.getAbsolutePath()+FILE_SEPARATOR+originalFileList[i]);
	                        }else{
	                            //Sub-list is a directory, recursively copy is called.
	                            result = copyDirectory(originalDirPath+"/"+originalFileList[i], targetDirPath1+"/"+originalFileList[i]);
	                        }
	                    }
                    }else{
                    	result = true;
                    }
                }
            }else{
                // Source itself is invalid, returns a false and exit.
                result = false;
            }
        }catch(Exception e){
        	e.getMessage();
        }
        
        return result;
    }
    
    /**
     * <pre>
     * Comment : Copy the directory. (Date of creation of conditions copy)
     * </pre>
     * @param String originalDirPath  The absolute path of original directory.
     * @param String targetDirPath  The absolute path of the target directory.
     * @param fromDate      The start date of the directory for copying conditions.
     * @param toDate        The termination date of the directory for copying conditions.
     * @return boolean result   복사가 성공함변 true, 실패하면  false를  리턴한다.
     */
    public static boolean copyDirectory(String originalDirPath, String targetDirPath, String fromDate, String toDate) throws Exception {
        
        // An invalid argument returns a space.
        if (originalDirPath==null || originalDirPath.equals("") || targetDirPath==null || targetDirPath.equals("")
                || fromDate==null || fromDate.equals("")|| toDate==null || toDate.equals("")){
            return false;
        }
        boolean result = false;
        File f = null;
        try
        {              
            f = new File (originalDirPath);            
            boolean isInCondition = false;
            String lastModifyedDate = getLastModifiedDateFromFile(f);
            if(Integer.parseInt(lastModifyedDate) >= Integer.parseInt(fromDate) 
                    && Integer.parseInt(lastModifyedDate) <= Integer.parseInt(toDate) ){
                isInCondition = true;
            }
            
            // Is valid and should be in accordance with the original conditions to continue.
            if(f.exists() && f.isDirectory() && isInCondition){
                
                //Have targeted path is valid (in the middle of the path if it contains the file name is not valid because it does not proceed.)
                String targetDirPath1 = createNewDirectory(targetDirPath);
                if("".equals(targetDirPath1)){
                    result = false;
                }else{
                    File targetDir = new File(targetDirPath1);
                    targetDir.mkdirs();
                    // Copy the files in the directory belong.
                    String [] originalFileList = f.list();
                    if(originalFileList.length>0){
                    	for(int i = 0; i<originalFileList.length ; i++){
	                        File subF = new File (originalDirPath+FILE_SEPARATOR+originalFileList[i]);
	                        if(subF.isFile()){
	                            //This file is a list of sub-file copy running-> failed to stop the copy to occur.
	                            result = copyFile(originalDirPath+FILE_SEPARATOR+originalFileList[i],
	                                    targetDir.getAbsolutePath()+FILE_SEPARATOR+originalFileList[i]);
	                        }else{
	                            //Sub-list is a directory, recursively copy is called.
	                            //To the list of sub-folders that do not check for the date of creation (the copy destination is the current folder of the current folder, copy that no child is excluded.)
	                            result = copyDirectory(originalDirPath+"/"+originalFileList[i], targetDirPath1+"/"+originalFileList[i]);
	                        }
	                    }
                    }else{
                    	result=true;
                    }
                }

            }else{
                // Source itself is invalid, returns a false and exit.
                result = false;
            }
        }catch(Exception e){
        	e.getMessage();
        }
        
        return result;
    }
    

    /**
     * Retrieves the size of the directory.
     * @param  String targetDirPath  Directory
     * @return long   size       Directory Size
     * @exception Exception
    */
    public static long getDirectorySize(String targetDirPath) throws Exception {
        
        File f =  new File (targetDirPath);
        if(!f.exists()){
            return 0;
        }
        if(f.isFile()) {
            return f.length();
        }
        
        File[] list = f.listFiles();
        long size = 0;
        long fileSize = 0;
        
        for (int i = 0; i < list.length; i++) {
            
            if (list[i].isDirectory()) {
                // If the list of files within the directory in the directory to look in the recursive call.
                fileSize = getDirectorySize(list[i].getAbsolutePath());
            } else {
                //The size of the file lookup.
                fileSize = list[i].length();
            }
            size = size + fileSize;
        }
        return size;
    }

}
