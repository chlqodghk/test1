package afnid.cm.code.web;

import java.io.StringWriter;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.OrgnzService;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.code.service.OrgnzVO;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/** 
 * This Controller class processes request of organization-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Eun Hee Kim
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.17			Eun Hee Kim	      		 		Create
 *
 * </pre>
 */
@Controller
public class OrgnzController {
	
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());
	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /** orgnzService */
	@Resource(name = "orgnzService")
    private OrgnzService orgnzService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
	
    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
    /** lgService */
	@Resource(name = "lgService")
    private LgService lgService;
	
	
    /**
     * Moved to list-screen of organization. <br>
     * 
     * @param comDefaultVO Value-object of organization to be parsed request(ComDefaultVO)
     * @param orgInfoVO Value-object of organization to be parsed request(OrgnzVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/OrgnzList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchListOrgnzView.do")
    public String searchListOrgnzView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("orgInfoVO") OrgnzVO orgInfoVO,
    		ModelMap model)
            throws Exception { 
    	try {
	    	CmCmmCdVO cmCmmCd = new CmCmmCdVO();    	
	    	
	    	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
	    	
	    	lgService.addUserWrkLg(user.getUserId(), orgInfoVO.getCurMnId());
	    	
			cmCmmCd.setGrpCd("25"); // System Section Code
			List<CmCmmCdVO> lstOrgnzClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
			model.addAttribute("lstOrgnzClsCd", lstOrgnzClsCd); // Main Service Code	   
		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
      	return "/cm/code/OrgnzList";

    }
    
    /**
     * Retrieves list of organization.  <br>
     * 
     * @param orgInfoVO Value-object of organization to be parsed request(OrgnzVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/OrgnzList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchListOrgnz.do")
    public String searchListOrgnz(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("orgInfoVO") OrgnzVO orgInfoVO,
    		ModelMap model)
            throws Exception { 

    	try {
	        		    
        	CmCmmCdVO cmCmmCd = new CmCmmCdVO();     	
        	
    		cmCmmCd.setGrpCd("25"); // Setting Group Code
    		List<CmCmmCdVO> lstOrgnzClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
    		model.addAttribute("lstOrgnzClsCd", lstOrgnzClsCd); // Main Service Code	  
    		
	    	/** Paging Setting */
    		orgInfoVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		orgInfoVO.setPageSize(propertiesService.getInt("pageSize"));
	
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(orgInfoVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(orgInfoVO.getPageUnit());
			paginationInfo.setPageSize(orgInfoVO.getPageSize());
	
			orgInfoVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			orgInfoVO.setLastIndex(paginationInfo.getLastRecordIndex());
			orgInfoVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
	        List<OrgnzVO> lstOrgInfo = orgnzService.searchListOrgnz(orgInfoVO);
	        model.addAttribute("lstOrgInfo", lstOrgInfo);
    		int lstLowOrgSize = orgnzService.searchLowOrgCnt(orgInfoVO);  	
    		model.addAttribute("lstLowOrgSize", lstLowOrgSize);
	        orgInfoVO.setOrgnzCd(orgInfoVO.getOrgnzCd());
	       
	        model.addAttribute("VO", orgnzService.searchOrgnz(orgInfoVO));
	        model.addAttribute("paginationInfo", paginationInfo);
	        int totCnt = orgnzService.searchListOrgnzTotCnt(orgInfoVO);
			paginationInfo.setTotalRecordCount(totCnt);	

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "/cm/code/OrgnzList";
    }
    
    /**
     * Retrieves detail Information of organization. <br>
     * 
     * @param comDefaultVO Value-object of organization to be parsed request(ComDefaultVO)
     * @param orgInfoVO Value-object of organization to be parsed request(OrgnzVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:  "/cm/code/OrgnzDtl.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchOrgnz.do")
    public String searchOrgnz(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("orgInfoVO") OrgnzVO orgInfoVO,
    		ModelMap model) 
            throws Exception {
    	try {
    		orgInfoVO.setOrgnzCd(orgInfoVO.getOrgnzCd());

	        model.addAttribute("orgInfoVO", orgnzService.searchOrgnz(orgInfoVO)); 
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "forward:/cm/code/modifyOrgnzView.do";
    }
    
    /**
     * Moved to registration-screen of organization. <br>
     * 
     * @param orgInfoVO Value-object of organization to be parsed request(OrgnzVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return  Printed out JSP:  "/cm/code/OrgInfoIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/addOrgnzView.do")
    public String addOrgnzView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("orgInfoVO") OrgnzVO orgInfoVO,
			ModelMap model)
            throws Exception { 
    	try {
    		
        	CmCmmCdVO cmCmmCd = new CmCmmCdVO();     	        	
    		cmCmmCd.setGrpCd("25"); // Setting Group Code
    		List<CmCmmCdVO> lstOrgnzClsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code List Interface Call
    		model.addAttribute("lstOrgnzClsCd", lstOrgnzClsCd); // Main Service Code	 

    	}catch (Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
		return "/cm/code/OrgnzIns"; 
    }
    
    /**
     * Register information of new organization. <br>
     * 
     * @param orgInfoVO Value-object of organization to be parsed request(OrgnzVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "cm/code/OrgnzList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/addOrgnz.do")
    public String addOrgnz(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("orgInfoVO") OrgnzVO orgInfoVO,
			ModelMap model)
            throws Exception {
    		
    	try {
    		
    		if ( !"".equals(orgInfoVO.getOrgnzCd())) {//local office
    			int dstrOrgnzCn = orgnzService.searchDstrOrgnzCnt(orgInfoVO);
    			
    			if (dstrOrgnzCn < 1) {//local
    				if( "00".equals(orgInfoVO.getOrgnzCd().substring(2,4)) ){//province
    					orgInfoVO.setUprOrgnzCd("0000"); 					
    				} else{//district
    					orgInfoVO.setUprOrgnzCd(orgInfoVO.getOrgnzCd().substring(0, 2) + "00");	
    				}
    				orgInfoVO.setOrgnzCd(orgInfoVO.getOrgnzCd());
    				orgnzService.addOrgnz(orgInfoVO);
    				model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); // Message Setting;
    			} else {    				
    				model.addAttribute("resultMsg", nidMessageSource.getMessage("oficCdRgst.msg")); // Message Setting;
    			}
    		} else {//center office
    			int ctOrgnzCn =orgnzService.searchCtOrgnzCnt(orgInfoVO);
    			if (ctOrgnzCn < 99){    			
    			   orgInfoVO.setUprOrgnzCd("0000");
    			   orgnzService.addOrgnz(orgInfoVO);
    			   model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); // Message Setting;
    			} else {
    				model.addAttribute("resultMsg", nidMessageSource.getMessage("govmtBdyEror.msg")); // Message Setting;
    			}
    		}
    		
    		
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    	return "forward:/cm/code/searchListOrgnz.do";
    	
    }
    
    /**
     * Moved to modification-screen of organization. <br>
     * 
     * @param orgInfoVO Value-object of organization to be parsed request(OrgnzVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/OrgnzUpd.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/modifyOrgnzView.do")
    public String modifyOrgnzView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("orgInfoVO") OrgnzVO orgInfoVO,
			ModelMap model)
            throws Exception { 
    	
    	try {

    		model.addAttribute("orgInfoVO", orgnzService.searchOrgnz(orgInfoVO));

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/cm/code/OrgnzUdt";
    }
    
    /**
	 * Modifies information of organization. <br>
	 * 
	 * @param orgInfoVO Value-object of organization to be parsed request(OrgnzVO)
	 * @param model Object to be parsed http request(ModelMap) 
	 * @return Printed out JSP: "cm/code/OrgnzList.jsp"
	 * @exception Exception
	 */
    @RequestMapping(value="/cm/code/modifyOrgnz.do")
    public String modifyOrgnz(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("orgInfoVO") OrgnzVO orgInfoVO,
			ModelMap model)
            throws Exception { 
    	try {
    		orgnzService.modifyOrgnz(orgInfoVO); 	
	    	model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); //Message Setting
	   
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
		return "forward:/cm/code/searchListOrgnz.do"; 
    }
    
    /**
     * Delete information of organization. <br>
     * 
     * @param orgInfoVO Value-object of organization to be parsed request(OrgnzVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/OrgnzList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/removeOrgnz.do")
    public String removeOrgnz(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("orgInfoVO") OrgnzVO orgInfoVO,
			ModelMap model)
            throws Exception { 
    	
    	try {
    		orgInfoVO.setOrgnzCd(orgInfoVO.getOrgnzCd());
    		
    		int lstLowOrgSize = orgnzService.searchLowOrgCnt(orgInfoVO);  	
    		if(lstLowOrgSize >0){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("dltLwrCd.msg")); 
    			return "forward:/cm/code/searchListOrgnz.do";
    		}else{
    			int oficrCnt = orgnzService.searchOficrCnt(orgInfoVO); 
    			if(oficrCnt > 0){
    				model.addAttribute("resultMsg", nidMessageSource.getMessage("existOficr.msg")); //Message Setting
    			} else {
		    		orgnzService.removeOrgnz(orgInfoVO);
		    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datDltScsfl.msg")); //Message Setting
    			}
    		}
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "forward:/cm/code/searchListOrgnz.do"; 
    }
    
    /**
     * Retrieves list of organization.  <br>
     * 
     * @param regionInfoVO Value-object of region to be parsed request(UserMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:""
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchListOrgnzAjx.do")
    public void searchListOrgnzAjx(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("orgInfoVO") OrgnzVO orgInfoVO,
			ModelMap model,
			HttpServletResponse response
			)
            throws Exception {
    	try {
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		
    		//Setting user Language
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		orgInfoVO.setUseLangCd(user.getUseLangCd());

    		Element orgnzCd;
    		Element orgnzCdNm;

    		List<OrgnzVO> orgnzList = null;
    		
    		orgnzList = orgnzService.searchListOrgnzAjax(orgInfoVO);
    		
    		for(int i=0; i<orgnzList.size(); i++){
    			Element	orgInfo = doc.createElement("orgInfo");
    			root.appendChild(orgInfo);
    			
    			orgnzCd = doc.createElement("orgnzCd");
    			orgnzCd.appendChild(doc.createTextNode(orgnzList.get(i).getOrgnzCd()));
    			
    			orgnzCdNm = doc.createElement("orgnzCdNm");
    			orgnzCdNm.appendChild(doc.createTextNode(orgnzList.get(i).getOrgnzNm()));
    			
    			orgInfo.appendChild(orgnzCd);
    			orgInfo.appendChild(orgnzCdNm);
    		}
    		        		  
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);  		
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }    
 
    
    /**
     * Retrieves list of organization.  <br>
     * 
     * @param regionInfoVO Value-object of region to be parsed request(UserMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:""
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchListUprOfic.do")
    public void searchListUprOfic(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("orgInfoVO") OrgnzVO orgInfoVO,
			ModelMap model,
			HttpServletResponse response
			)
            throws Exception {
    	try {
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		
    		//Setting user Language
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		orgInfoVO.setUseLangCd(user.getUseLangCd());

    		Element orgnzCd;
    		Element orgnzCdNm;

    		List<OrgnzVO> orgnzList = null;
    		
    		orgnzList = orgnzService.searchListUprOfic(orgInfoVO);
    		
    		for(int i=0; i<orgnzList.size(); i++){
    			Element	orgInfo = doc.createElement("orgInfo");
    			root.appendChild(orgInfo);
    			
    			orgnzCd = doc.createElement("orgnzCd");
    			orgnzCd.appendChild(doc.createTextNode(orgnzList.get(i).getOrgnzCd()));
    			
    			orgnzCdNm = doc.createElement("orgnzCdNm");
    			orgnzCdNm.appendChild(doc.createTextNode(orgnzList.get(i).getOrgnzNm()));
    			
    			orgInfo.appendChild(orgnzCd);
    			orgInfo.appendChild(orgnzCdNm);
    		}
    		        		  
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);  		
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    /**
     * Retrieves list of organization.  <br>
     * 
     * @param regionInfoVO Value-object of region to be parsed request(UserMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:""
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchListOfic.do")
    public void searchListOfic(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("orgInfoVO") OrgnzVO orgInfoVO,
			ModelMap model,
			HttpServletResponse response
			)
            throws Exception {
    	try {
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		
    		//Setting user Language
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		orgInfoVO.setUseLangCd(user.getUseLangCd());

    		Element orgnzCd;
    		Element orgnzCdNm;

    		List<OrgnzVO> orgnzList = null;

			orgnzList = orgnzService.searchListOfic(orgInfoVO);
    		
    		for(int i=0; i<orgnzList.size(); i++){
    			Element	orgInfo = doc.createElement("orgInfo");
    			root.appendChild(orgInfo);
    			
    			orgnzCd = doc.createElement("orgnzCd");
    			orgnzCd.appendChild(doc.createTextNode(orgnzList.get(i).getOrgnzCd()));
    			
    			orgnzCdNm = doc.createElement("orgnzCdNm");
    			orgnzCdNm.appendChild(doc.createTextNode(orgnzList.get(i).getOrgnzNm()));
    			
    			orgInfo.appendChild(orgnzCd);
    			orgInfo.appendChild(orgnzCdNm);
    		}
    		        		  
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);  		
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    } 
    
    /**
     * Retrieves list of organization(Tree).  <br>
     * 
     * @param orgInfoVO Value-object of organization to be parsed request(OrgnzVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchListOrgnzCdTree.do")
    public void searchListOrgnzCdTree(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("orgInfoVO") OrgnzVO orgInfoVO,
			ModelMap model,
			HttpServletResponse response
    		)
            throws Exception { 

    	try {
    		
    		List<OrgnzVO> list = orgnzService.searchListOrgnzCdTree(orgInfoVO);
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		
    		Element eleInfo = null;
    		Element ele = null;
    		
    		OrgnzVO vo = new OrgnzVO();
    		
    		for(int i=0; i<list.size(); i++){
    			vo= list.get(i);
    			if(vo != null){
	    			eleInfo = doc.createElement("orgnzcd_info");
	    			root.appendChild(eleInfo);
	    			ele = doc.createElement("orgnzcd");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)vo.getOrgnzCd()) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("uprOrgnzcd");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)vo.getUprOrgnzCd()) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("orgnznm");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)vo.getOrgnzNm()) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("uprOrgnzNm");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)vo.getUprOrgnzNm()) ));
	    			eleInfo.appendChild(ele);	    			
	    			ele = doc.createElement("orgnzClsCd");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)vo.getOrgnzClsCd()) ));
	    			ele = doc.createElement("orgnzClsCdNm");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)vo.getOrgnzClsCdNm()) ));	    			
	    			eleInfo.appendChild(ele);
    			}
	    	}
    		
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    }
    
}
