package afnid.cm.code.web;

/* java API */
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springmodules.validation.commons.DefaultBeanValidator;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.code.service.CdGrpVO;
import afnid.cm.code.service.CmmCdService;
import afnid.cm.code.service.CmmCdVO;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/** 
 * This Controller class processes request of code-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team 
 * @since 2011.04.10
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers         		Revisions
 *   2011.05.04  		MH Choung         		Create
 *
 * </pre>
 */
@Controller
public class CmmCdController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** Validator */
	@Autowired
	private DefaultBeanValidator beanValidator;
	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /** cmmCdService */
	@Resource(name = "cmmCdService")
    private CmmCdService cmmCdService;
	
    

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
	
    /** lgService */
	@Resource(name = "lgService")
    private LgService lgService;
	
    /**
     * Moved to list-screen of codeGroup. <br>
     * 
     * @param cdGrpVO Value-object of codeGroup to be parsed request(cdGrpVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/CommonCodeLst.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchListCdGrpView.do")
    public String searchListCdGrpView(
    		@ModelAttribute("cdGrpVO") CdGrpVO cdGrpVO,
    		ModelMap model)
            throws Exception { 

    	try{
	    	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
	    	
	    	lgService.addUserWrkLg(user.getUserId(), cdGrpVO.getCurMnId());
    	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}    	
      	return "/cm/code/CdGrpList";

    }

    /**
     * Retrieves list of codeGroup.  <br>
     * 
     * @param cdGrpVO Value-object of codeGroup to be parsed request(CdGrpVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/CommonCodeLst.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/cm/code/searchListCdGrp.do")
    public String searchListCdGrp(    		
    		@ModelAttribute("cdGrpVO") CdGrpVO cdGrpVO,
    		ModelMap model)
            throws Exception { 

    	try {
    		    		
	    	// Retrieve
	    	/** list Paging Setting */
    		cdGrpVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		cdGrpVO.setPageSize(propertiesService.getInt("pageSize"));
	
	    	/** paging */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(cdGrpVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(cdGrpVO.getPageUnit());
			paginationInfo.setPageSize(cdGrpVO.getPageSize());
	
			cdGrpVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			cdGrpVO.setLastIndex(paginationInfo.getLastRecordIndex());
			cdGrpVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
			
	        List<CdGrpVO> lstCodeGroup = cmmCdService.searchListCdGrp(cdGrpVO);
	        model.addAttribute("lstCodeGroup", lstCodeGroup);
	
	        int totCnt = cmmCdService.searchListCdGrpTotCnt(cdGrpVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "/cm/code/CdGrpList";

    }

    /**
     * Retrieves detail Information of CodeGroup. <br>
     * 
     * @param cdGrpVO Value-object of CodeGroup to be parsed request(CdGrpVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:  "/cm/code/CmmCdDtl.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/modifyCdGrpView.do")
    public String modifyCdGrpView(    		
    		@ModelAttribute("cdGrpVO") CdGrpVO cdGrpVO,
    		@ModelAttribute("cmmCdVO") CmmCdVO cmmCdVO,
    		ModelMap model) 
            throws Exception {
    	try {
    		// Retrieve
	    	/** list Paging Setting */
    		cmmCdVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		cmmCdVO.setPageSize(propertiesService.getInt("pageSize"));
	
	    	/** paging */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(cmmCdVO.getPageIndex2());
			paginationInfo.setRecordCountPerPage(cmmCdVO.getPageUnit());
			paginationInfo.setPageSize(cmmCdVO.getPageSize());
	
			cmmCdVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			cmmCdVO.setLastIndex(paginationInfo.getLastRecordIndex());
			cmmCdVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
    		
			if (cmmCdVO.getSortCd() == null || "".equals(cmmCdVO.getSortCd()) ){
				cmmCdVO.setSortCd("1");
			}
			log.debug("==========================================================================");
			log.debug("cmmCdVO.getSortCd() : "+cmmCdVO.getSortCd());
			log.debug("==========================================================================");

    		CdGrpVO vo = cmmCdService.searchCdGrp(cdGrpVO);
    		model.addAttribute("VO",vo ); // Retrieving data is Setting in the  ModelMap
    		
    		cmmCdVO.setGrpCd(vo.getGrpCd());
    		cmmCdVO.setDltYn(cmmCdVO.getSearchKeyword9());
    		
	        List<CmmCdVO> lstCommonCode = cmmCdService.searchListCmmCd(cmmCdVO);
	        model.addAttribute("lstCommonCode", lstCommonCode);
	        
	        int totCnt = cmmCdService.searchListCmmCdCnt(cmmCdVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
    		    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/cm/code/CdGrpDtl";
    } 

    /**
     * Modifies information of CodeGroup. <br>
     * @param cdGrpVO Value-object of CodeGroup to be parsed request(CdGrpVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/CmmCdDtl.do"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/modifyCdGrp.do")
    public String modifyCdGrp(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("cdGrpVO") CdGrpVO cdGrpVO,
    		CdGrpVO vo,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	try {
	    	beanValidator.validate(cdGrpVO, bindingResult); // Input Items Validation Check
			if (bindingResult.hasErrors()){ // Validation Check error
	            return "/cm/code/CdGrpDtl"; //Error move upd interface.
			}
			
	    	cmmCdService.modifyCdGrp(cdGrpVO); // update Interface Call    	
	    	model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); //If succeed to save Message Setting
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
		return "forward:/cm/code/searchListCdGrp.do"; 
    }    

 
    
    /**
     * Moved to registration-screen of CommonCode. <br>
     * 
     * @param cdGrpVO Value-object of CodeGroup to be parsed request(CdGrpVO)
     * @param cmmCdVO Value-object of CommonCode to be parsed request(cmmCdVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return  Printed out JSP:  "/cm/code/CmmCdIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/addCmmCdView.do")
    public String addCmmCdView(  
    		@ModelAttribute("cdGrpVO") CdGrpVO cdGrpVO,
    		@ModelAttribute("cmmCdVO") CmmCdVO cmmCdVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception {
    	try{
	    	cdGrpVO.setGrpCd(cmmCdVO.getGrpCd());
	    	CdGrpVO vo = cmmCdService.searchCdGrp(cdGrpVO);
			model.addAttribute("VO",vo ); // Retrieving data is Setting in the  ModelMap
		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}		
		return "/cm/code/CmmCdIns"; 
    }    
    
    /**
     * Register information of new CommonCode. <br>
     * 
     * @param cdGrpVO Value-object of CodeGroup to be parsed request(CdGrpVO)
     * @param cmmCdVO Value-object of CommonCode to be parsed request(cmmCdVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/CmmCdDtl.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/addCmmCd.do")
    public String addCmmCd(    		
    		@ModelAttribute("cdGrpVO") CdGrpVO cdGrpVO,
    		@ModelAttribute("cmmCdVO") CmmCdVO cmmCdVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception {
    		
    	try {
	    	beanValidator.validate(cmmCdVO, bindingResult); // Input Items Validation Check
			if (bindingResult.hasErrors()){ // Validation Check err
				return "forward:/cm/code/addCmmCdView.do";  //Occurrence  Error  goto insert view.
			}
			
			CmmCdVO vo = new CmmCdVO();
			
			vo = cmmCdService.addCmmCd(cmmCdVO); 	
			
			cdGrpVO.setGrpCd(vo.getGrpCd());
	    	model.addAttribute("VO", cmmCdService.searchCdGrp(cdGrpVO)); 
	    	
	    	List<CmmCdVO> lstCommonCode = cmmCdService.searchListCmmCd(cmmCdVO);
	        model.addAttribute("lstCommonCode", lstCommonCode);
	        model.addAttribute("cmmCdVO", cmmCdVO);
	    	model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); //if save success then Message Setting
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    	return "forward:/cm/code/modifyCdGrpView.do";
    }    
   
    /**
     * Moved to modification-screen of CommonCode. <br>
     * 
     * @param cdGrpVO Value-object of CodeGroup to be parsed request(CdGrpVO)
     * @param cmmCdVO Value-object of CommonCode to be parsed request(cmmCdVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/CmmCdUpd.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/modifyCmmCdView.do")
    public String modifyCmmCdView(
    		@ModelAttribute("cdGrpVO") CdGrpVO cdGrpVO,
    		@ModelAttribute("cmmCdVO") CmmCdVO cmmCdVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	
    	try {	
    		cmmCdVO.setGrpCd(cdGrpVO.getGrpCd());

    		CmmCdVO vo = cmmCdService.searchCmmCd(cmmCdVO);
    		model.addAttribute("VO",vo ); // Retrieving data is Setting in the  ModelMap
    		CdGrpVO gvo = cmmCdService.searchCdGrp(cdGrpVO);
    		model.addAttribute("GVO",gvo ); // Retrieving data is Setting in the  ModelMap
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
        return "/cm/code/CmmCdUdt"; 

    }    
    
    /**
     * Modifies information of CommonCode. <br>
     * 
     * @param cdGrpVO Value-object of CodeGroup to be parsed request(CdGrpVO)
     * @param cmmCdVO Value-object of CommonCode to be parsed request(cmmCdVO)
     * @param bindingResult  validate Input Item(BindingResult)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/CommonCodeDtl.do"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/modifyCmmCd.do")
    public String modifyCmmCd(
    		@ModelAttribute("cdGrpVO") CdGrpVO cdGrpVO,
    		@ModelAttribute("cmmCdVO") CmmCdVO cmmCdVO,
    		CmmCdVO vo,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	try {
	    	beanValidator.validate(cmmCdVO, bindingResult); // Input Items Validation Check
			if (bindingResult.hasErrors()){ // Validation Check error
	            return "/cm/code/CmmCdUpd"; //Error move upd interface.
			}
			cmmCdVO.setGrpCd(cdGrpVO.getGrpCd());
	    	cmmCdService.modifyCmmCd(cmmCdVO); // update Interface Call    	
	    	model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); //If succeed to save Message Setting
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
		return "forward:/cm/code/modifyCdGrpView.do"; 
    }    

    
    /**
     * Delete information of CommonCode. <br>
     * 
     * @param cdGrpVO Value-object of CodeGroup to be parsed request(CdGrpVO)
     * @param cmmCdVO Value-object of CommonCode to be parsed request(cmmCdVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "forward:/cm/code/CommonCodeLst.jsp" 
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/removeCmmCd.do")
    public String removeCmmCd(
    		@ModelAttribute("cdGrpVO") CdGrpVO cdGrpVO,
    		@ModelAttribute("cmmCdVO") CmmCdVO cmmCdVO,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		cmmCdVO.setGrpCd(cdGrpVO.getGrpCd());
	    	cmmCdService.removeCmmCd(cmmCdVO); // calling Common Code delete Interface 
	    	cdGrpVO.setGrpCd(cmmCdVO.getGrpCd());
	    	model.addAttribute("resultMsg", nidMessageSource.getMessage("datDltScsfl.msg")); //If succeed to delete Message Setting
	    	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
        return "forward:/cm/code/modifyCdGrpView.do";
    } 

    /**
     * Retrieves list of overflowed code<br>
     * @param CmmCdVO Value-object of list of overflowed code(CmmCdVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/p_CdLnthChkList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/p_searchListCdLnthChk.do")
    public String p_searchListCdLnthChk(    		
    		@ModelAttribute("cmmCdVO") CmmCdVO cmmCdVO,
    		ModelMap model)
            throws Exception { 

    	try {    	
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();    		
    		cmmCdVO.setUseLangCd(user.getUseLangCd());
    		
	    	PaginationInfo paginationInfo = new PaginationInfo();

    		List<CmmCdVO> lstLnthChk = cmmCdService.searchListCdLnthChk(cmmCdVO);
	        model.addAttribute("lstLnthChk", lstLnthChk);

	        int totCnt = cmmCdService.searchListCdLnthChkTotCnt(cmmCdVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "/cm/code/p_CdLnthChkList";
    }    
}