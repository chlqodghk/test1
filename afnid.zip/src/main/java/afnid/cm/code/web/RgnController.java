package afnid.cm.code.web;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.code.service.RgnService;
import afnid.cm.code.service.RgnVO;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/** 
 * This Controller class processes request of region-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Eun Hee Kim
 * @since 2011.05.24
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.24			Eun Hee Kim	      		 		Create
 *
 * </pre>
 */
@Controller
public class RgnController {
	
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());
	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    /** rgnService */
	@Resource(name = "rgnService")
    private RgnService rgnService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
	
    /** lgService */
	@Resource(name = "lgService")
    private LgService lgService;
	
    /**
     * Moved to list-screen of region. <br>
     * 
     * @param comDefaultVO Value-object of region to be parsed request(ComDefaultVO)
     * @param regionInfoVO Value-object of region to be parsed request(RegionInfoVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/RgnList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchListRgnView.do")
    public String searchListRgnView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("regionInfoVO") RgnVO regionInfoVO,
    		ModelMap model)
            throws Exception { 
    	
    	try{
	    	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
	    	
	    	lgService.addUserWrkLg(user.getUserId(), regionInfoVO.getCurMnId());
    	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
      	return "/cm/code/RgnList";
    }
    
    /**
     * Retrieves list of region.  <br>
     * 
     * @param regionInfoVO Value-object of region to be parsed request(RegionInfoVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/RgnList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchListRgn.do")
    public String searchListRgn(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("regionInfoVO") RgnVO regionInfoVO,
    		ModelMap model)
            throws Exception { 

    	try {
	    	/**Paging Setting */
    		regionInfoVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		regionInfoVO.setPageSize(propertiesService.getInt("pageSize"));
	
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(regionInfoVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(regionInfoVO.getPageUnit());
			paginationInfo.setPageSize(regionInfoVO.getPageSize());
	
			regionInfoVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			regionInfoVO.setLastIndex(paginationInfo.getLastRecordIndex());
			regionInfoVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
	        List<RgnVO> lstRegionInfo = rgnService.searchListRgn(regionInfoVO);
	       
	        model.addAttribute("lstRegionInfo", lstRegionInfo);
	
	        int totCnt = rgnService.searchListRgnTotCnt(regionInfoVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "/cm/code/RgnList";
    }
    
    /**
     * Moved to registration-screen of region. <br>
     * 
     * @param regionInfoVO Value-object of region to be parsed request(RegionInfoVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return  Printed out JSP:  "/cm/code/RgnIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/addRgnView.do")
    public String addRgnView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("regionInfoVO") RgnVO regionInfoVO,
			ModelMap model)
            throws Exception { 
    	
    	try {
    		//Region Ara List
    		RgnVO regionInfo = new RgnVO();
    		List<RgnVO> lstRegionInfo = rgnService.searchListRgnAra(regionInfo);
    		model.addAttribute("lstRegionInfo", lstRegionInfo);     		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

		return "/cm/code/RgnIns"; 
    }
    
    /**
     * Register information of new region. <br>
     * 
     * @param regionInfoVO Value-object of region to be parsed request(RegionInfoVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "cm/code/RgnDtl.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/addRgn.do")
    public String addRgn(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("regionInfoVO") RgnVO regionInfo,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception {
    		
    	try {
    		RgnVO regionInfoVO = regionInfo;
    		regionInfoVO = rgnService.addRgn(regionInfoVO);	    	 
	    	model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); //Message Setting
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    	return "forward:/cm/code/searchListRgn.do";
    }
        
    /**
     * Moved to modification-screen of region. <br>
     * 
     * @param regionInfoVO Value-object of region to be parsed request(RegionInfoVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/RgnUdp.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/modifyRgnView.do")
    public String modifyRgnView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("regionInfoVO") RgnVO regionInfoVO,
			ModelMap model)
            throws Exception { 
    	
    	try {
    		model.addAttribute("regionInfoVO",rgnService.searchRgn(regionInfoVO));
 		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/cm/code/RgnUdt";
    }
    
    /**
	 * Modifies information of region. <br>
	 * 
	 * @param regionInfoVO Value-object of region to be parsed request(RegionInfoVO)
	 * @param model Object to be parsed http request(ModelMap) 
	 * @return Printed out JSP: "/cm/code/RgnDtl.do"
	 * @exception Exception
	 */
    @RequestMapping(value="/cm/code/modifyRgn.do")
    public String modifyRgn(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("regionInfoVO") RgnVO regionInfoVO,
			BindingResult bindingResult,
			ModelMap model)
            throws Exception { 
    	try {
    		rgnService.modifyRgn(regionInfoVO); 	
	    	model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); // Message Setting

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
		return "forward:/cm/code/searchListRgn.do"; 
    }
    
    /**
     * Delete information of region. <br>
     * 
     * @param regionInfoVO Value-object of region to be parsed request(RegionInfoVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/RgnList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/removeRgn.do")
    public String removeRgn(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("regionInfoVO") RgnVO regionInfoVO,
			ModelMap model)
            throws Exception { 
    	
    	try {
    		rgnService.removeRgn(regionInfoVO);
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datDltScsfl.msg")); // Message Setting
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "forward:/cm/code/searchListRgn.do"; 
    }
    
    /**
     * Retrieves list of region.  <br>
     * 
     * @param regionInfoVO Value-object of region to be parsed request(RegionInfoVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:""
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchListRgnAra.do")
    public void searchListRgnAra(
    		@ModelAttribute("rgnVO") RgnVO rgnVO,
			ModelMap model,
			HttpServletResponse response
			)
            throws Exception {
    	try {
    		List<RgnVO> regionInfoVOList = rgnService.searchListRgnAra(rgnVO); 
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element araInfo;
    		Element adCd;
    		Element araNm;
    		
    		for(int i=0; i<regionInfoVOList.size(); i++){
    			araInfo = doc.createElement("araInfo");
    			root.appendChild(araInfo);
    			
    			adCd = doc.createElement("adCd");
    			adCd.appendChild(doc.createTextNode(regionInfoVOList.get(i).getAdCd()));
    			
    			araNm = doc.createElement("araNm");
    			araNm.appendChild(doc.createTextNode(regionInfoVOList.get(i).getAraNm()));
    			araInfo.appendChild(adCd);
    			araInfo.appendChild(araNm);
    		}
    		    
    		if("Y".equals(rgnVO.getFrgnFlag())){
    			araInfo = doc.createElement("araInfo");
    			root.appendChild(araInfo);
    			
    			adCd = doc.createElement("adCd");
    			adCd.appendChild(doc.createTextNode("xxxx"));
    			
    			araNm = doc.createElement("araNm");
    			araNm.appendChild(doc.createTextNode(nidMessageSource.getMessage("frgn")));
    			araInfo.appendChild(adCd);
    			araInfo.appendChild(araNm);    			
    		}
    		
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    		
    	} catch (Exception e) {
    		
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
  
    
    /**
     * Retrieves list of region.  <br>
     * 
     * @param regionInfoVO Value-object of region to be parsed request(RegionInfoVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:""
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchListRgnNm.do")
    public void searchListRgnNm(
    		@ModelAttribute("regionInfoVO") RgnVO regionInfoVO,
			ModelMap model,
			HttpServletResponse response
			)
            throws Exception {
    		
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		String useLangCd = "" + user.getUseLangCd();
    		regionInfoVO.setUseLangCd(useLangCd);
    		List<RgnVO> regionInfoVOList = null;
    		if(regionInfoVO.getUprAdCd() != null && !"".equals(regionInfoVO.getUprAdCd())){
    			regionInfoVOList = rgnService.searchListRgnNmByPrt(regionInfoVO); 	   
    		} else if(regionInfoVO.getAdCd() != null && !"".equals(regionInfoVO.getAdCd())){
    			regionInfoVOList = rgnService.searchListRgnNmByChd(regionInfoVO); 	   
    		} else {
    			log.error("uprAdCd or adCd is required");
    		}
    		if (regionInfoVOList == null){
    			regionInfoVOList = new ArrayList<RgnVO>();
    		}
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element dstrInfo;
    		Element adCd ;
    		Element dstrNm;
    		for(int i=0; i<regionInfoVOList.size(); i++){
    			dstrInfo = doc.createElement("dstrInfo");
    			root.appendChild(dstrInfo);
    			
    			adCd = doc.createElement("adCd");
    			adCd.appendChild(doc.createTextNode(regionInfoVOList.get(i).getAdCd()));
    			
    			dstrNm = doc.createElement("dstrNm");
    			dstrNm.appendChild(doc.createTextNode(regionInfoVOList.get(i).getDstrNm()));
    			
    			dstrInfo.appendChild(adCd);
    			dstrInfo.appendChild(dstrNm);
    		}
    		
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
   
    
    /**
     * Retrieves list of region.  <br>
     * 
     * @param regionInfoVO Value-object of region to be parsed request(RegionInfoVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:""
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchListAdCd.do")
    public void searchListAdCd(
	    		@ModelAttribute("regionInfoVO") RgnVO regionInfoVO,
				ModelMap model,
				HttpServletResponse response
			) throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		String useLangCd = user.getUseLangCd();
    		regionInfoVO.setUseLangCd(useLangCd);
    		List<EgovMap> list = null;
    		list = rgnService.searchListAdCd(regionInfoVO); 	   
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element eleInfo = null;
    		Element ele = null;
    		for(int i=0; i<list.size(); i++){
    			EgovMap em = list.get(i);
    			if(em != null){
	    			eleInfo = doc.createElement("adcd_info");
	    			root.appendChild(eleInfo);
	    			ele = doc.createElement("adcd");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)em.get("adCd")) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("upr_adcd");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)em.get("uprAdCd")) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("full_nm");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)em.get("fullNm")) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("ara_full_nm");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)em.get("araFullNm")) ));
	    			eleInfo.appendChild(ele);
    			}
	    	}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    /**
     * Retrieves list of overflowed province <br>
     * @param CmmCdVO Value-object of list of overflowed code(CmmCdVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/cm/code/p_RgnLnthChkList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/p_searchListRgnLnthChk.do")
    public String p_searchListCdLnthChk(    		
    		@ModelAttribute("regionInfoVO") RgnVO regionInfoVO,
    		ModelMap model)
            throws Exception { 

    	try {    	
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();    		
    		regionInfoVO.setUseLangCd(user.getUseLangCd());
    		
	    	PaginationInfo paginationInfo = new PaginationInfo();

    		List<RgnVO> lstLnthChk = rgnService.searchListRgnLnthChk(regionInfoVO);
	        model.addAttribute("lstLnthChk", lstLnthChk);

	        int totCnt = rgnService.searchListRgnLnthChkTotCnt(regionInfoVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "/cm/code/p_RgnLnthChkList";
    }        
    
}
