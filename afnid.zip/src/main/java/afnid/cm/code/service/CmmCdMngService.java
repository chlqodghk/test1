package afnid.cm.code.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz_class for common code search.
 * @author 
 * @since 2011.04.10
 * @version 1.0
 * @see
 *
 * <pre>
 * << (Modification Information) >>
 *   
 *   Modified      Modifiers           Revisions
 *  ---------      ---------    ---------------------------
 *   2011.04.10                       Create
 *
 * </pre>
 */
public interface CmmCdMngService {

	/**
	 * Retrieves list of common in business application.
	 * 
	 * @param cmCmmCd Common Code Value Object(CmCmmCdVO)
	 * @return Common Code List
	 * @throws Exception
	 */	
	public List<CmCmmCdVO> searchListCmmCd(CmCmmCdVO cmCmmCd) throws Exception;
	
	/**
	 * Retrieves list of common in business application.
	 * 
	 * @param cmCmmCd Common Code Value Object(CmCmmCdVO)
	 * @return Common Code List
	 * @throws Exception
	 */	
	public List<CmCmmCdVO> searchListCmmCdDesc(CmCmmCdVO cmCmmCd) throws Exception;
	
	/**
	 * Retrieves list of common in business application.
	 * 
	 * @param cmCmmCd Common Code Value Object(CmCmmCdVO)
	 * @return Common Code List
	 * @throws Exception
	 */	
	public List<CmCmmCdVO> searchListCmmCd(CmCmmCdVO cmCmmCd, boolean flag, String codeValue) throws Exception;

	/**
	 * Retrieves menu sequence number.
	 * 
	 * @param cmCmmCd Common Code Value Object(CmCmmCdVO)
	 * @return List
	 * @throws Exception
	 */
	public List<CmCmmCdVO> searchListMn(CmCmmCdVO cmCmmCd) throws Exception;
	
	
	/**
	 * Retrieves list of common in business application.
	 * 
	 * @param cmCmmCd Common Code Value Object(CmCmmCdVO)
	 * @return Common Code List
	 * @throws Exception
	 */	
	public List<CmCmmCdVO> searchListNoSesonCmmCd(CmCmmCdVO cmCmmCd, String userLangCd) throws Exception;
	
	/**
	 * Retrieves Address Code Name in CM_ARA_TB
	 * 
	 * @param cmCmmCd Common Code Value Object(CmCmmCdVO)
	 * @return Address Code Name
	 * @throws Exception
	 */	
	public EgovMap searchAdCdNm(CmCmmCdVO cmCmmCd) throws Exception;
	
	
	/**
	 * Retrieves common code in business application.
	 * 
	 * @param cmCmmCd Common Code Value Object(CmCmmCdVO)
	 * @return Common Code 
	 * @throws Exception
	 */
	public CmCmmCdVO searchCmmCd(CmCmmCdVO vo) throws Exception;
}
