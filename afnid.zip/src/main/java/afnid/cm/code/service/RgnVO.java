package afnid.cm.code.service;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of region-management
 * 
 * @author Afghanistan National ID Card System Application Team Eun Hee Kim
 * @since 2011.05.24
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.24 		Eun Hee Kim	      		 		Create
 *
 * </pre>
 */
public class RgnVO extends ComDefaultVO{
    private static final long serialVersionUID = 1L;
    
    /** AD_CD */
    private java.lang.String adCd;
    
    /** UPR_AD_CD */
    private java.lang.String uprAdCd;
    
    /** UPR_AD_CD name */
    private java.lang.String uprAdNm;
    
    /** PST_ARA_NM */
    private java.lang.String pstAraNm;
    
    /** PST_ARA_ABRVN_NM */
    private java.lang.String pstAraAbrvnNm;
    
    /** DR_ARA_NM */
    private java.lang.String drAraNm;
    
    /** DR_ARA_ABRVN_NM */
    private java.lang.String drAraAbrvnNm;
    
    /** PROR_RNK_NO */
    private java.lang.String prorRnkNo;
    
    /** ARA_KND_CD */
    private java.lang.String cityYn;
    
    /** ARA_KND_CD name */
    private java.lang.String cityYnNm;
    
    /** FST_RGST_USER_ID */
    private java.lang.String fstRgstUserId;
    
    /** FST_RGST_DT */
    private java.lang.String fstRgstDt;
    
    /** LST_UDT_USER_ID */
    private java.lang.String lstUdtUserId;
    
    /** LST_UDT_DT */
    private java.lang.String lstUdtDt;
    
    /** UPR_ARA_CD Pashto Name */
    private java.lang.String uprPstAraNm;
    
    /** UPR_ARA_CD Dari Name */
    private java.lang.String uprDrAraNm;
    
    /** DLT_YN */
    private java.lang.String dltYn;
    
    /** DLT_RSN_DTL_CT */
    private java.lang.String dltRsnDtlCt;

    /** User Language Code */
    private java.lang.String useLangCd;
    /** ENGLISH CODE NAME */
    private String enAraNm;
    /**PST_DSTR_NM*/
    private String pstDstrNm;
    /**DR_DSTR_NM*/
    private String drDstrNm;
    /**DR_DSTR_NM*/
    private String enDstrNm;
    
    /**ARA_CODE*/
    private String araCode;
    
    /**DSTR_CODE*/
    private String dstrCode;
    
    /**ARA_NM*/
    private String araNm;
    
    /**DSTR_NM*/
    private String dstrNm;

    private String frgnFlag;
    
    
    private String pstAraNm1;
    private String drAraNm1;
    private String enAraNm1;
    
    private String pstLnth;
    private String drLnth;
    private String enLnth;
    private String lcaNmMaxLnth;
    private String enMaxLnth;
    
	public String getDstrCode() {
		return dstrCode;
	}

	public void setDstrCode(String dstrCode) {
		this.dstrCode = dstrCode;
	}

	public String getAraNm() {
		return araNm;
	}

	public void setAraNm(String araNm) {
		this.araNm = araNm;
	}

	public String getDstrNm() {
		return dstrNm;
	}

	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}

	public String getAraCode() {
		return araCode;
	}

	public void setAraCode(String araCode) {
		this.araCode = araCode;
	}

	public String getPstDstrNm() {
		return pstDstrNm;
	}

	public void setPstDstrNm(String pstDstrNm) {
		this.pstDstrNm = pstDstrNm;
	}

	public String getDrDstrNm() {
		return drDstrNm;
	}

	public void setDrDstrNm(String drDstrNm) {
		this.drDstrNm = drDstrNm;
	}

	public String getEnDstrNm() {
		return enDstrNm;
	}

	public void setEnDstrNm(String enDstrNm) {
		this.enDstrNm = enDstrNm;
	}

	public String getEnAraNm() {
		return enAraNm;
	}

	public void setEnAraNm(String enAraNm) {
		this.enAraNm = enAraNm;
	}

	public java.lang.String getAdCd() {
		return adCd;
	}

	public void setAdCd(java.lang.String adCd) {
		this.adCd = adCd;
	}

	public java.lang.String getUprAdCd() {
		return uprAdCd;
	}

	public void setUprAdCd(java.lang.String uprAdCd) {
		this.uprAdCd = uprAdCd;
	}

	public java.lang.String getUprAdNm() {
		return uprAdNm;
	}

	public void setUprAdNm(java.lang.String uprAdNm) {
		this.uprAdNm = uprAdNm;
	}

	public java.lang.String getPstAraNm() {
		return pstAraNm;
	}

	public void setPstAraNm(java.lang.String pstAraNm) {
		this.pstAraNm = pstAraNm;
	}

	public java.lang.String getPstAraAbrvnNm() {
		return pstAraAbrvnNm;
	}

	public void setPstAraAbrvnNm(java.lang.String pstAraAbrvnNm) {
		this.pstAraAbrvnNm = pstAraAbrvnNm;
	}

	public java.lang.String getDrAraNm() {
		return drAraNm;
	}

	public void setDrAraNm(java.lang.String drAraNm) {
		this.drAraNm = drAraNm;
	}

	public java.lang.String getDrAraAbrvnNm() {
		return drAraAbrvnNm;
	}

	public void setDrAraAbrvnNm(java.lang.String drAraAbrvnNm) {
		this.drAraAbrvnNm = drAraAbrvnNm;
	}

	public java.lang.String getProrRnkNo() {
		return prorRnkNo;
	}

	public void setProrRnkNo(java.lang.String prorRnkNo) {
		this.prorRnkNo = prorRnkNo;
	}

	public java.lang.String getCityYn() {
		return cityYn;
	}

	public void setCityYn(java.lang.String cityYn) {
		this.cityYn = cityYn;
	}

	public java.lang.String getCityYnNm() {
		return cityYnNm;
	}

	public void setCityYnNm(java.lang.String cityYnNm) {
		this.cityYnNm = cityYnNm;
	}

	public java.lang.String getFstRgstUserId() {
		return fstRgstUserId;
	}

	public void setFstRgstUserId(java.lang.String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}

	public java.lang.String getFstRgstDt() {
		return fstRgstDt;
	}

	public void setFstRgstDt(java.lang.String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}

	public java.lang.String getLstUdtUserId() {
		return lstUdtUserId;
	}

	public void setLstUdtUserId(java.lang.String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}

	public java.lang.String getLstUdtDt() {
		return lstUdtDt;
	}

	public void setLstUdtDt(java.lang.String lstUdtDt) {
		this.lstUdtDt = lstUdtDt;
	}

	public java.lang.String getUprPstAraNm() {
		return uprPstAraNm;
	}

	public void setUprPstAraNm(java.lang.String uprPstAraNm) {
		this.uprPstAraNm = uprPstAraNm;
	}

	public java.lang.String getUprDrAraNm() {
		return uprDrAraNm;
	}

	public void setUprDrAraNm(java.lang.String uprDrAraNm) {
		this.uprDrAraNm = uprDrAraNm;
	}

	public java.lang.String getDltYn() {
		return dltYn;
	}

	public void setDltYn(java.lang.String dltYn) {
		this.dltYn = dltYn;
	}

	public java.lang.String getDltRsnDtlCt() {
		return dltRsnDtlCt;
	}

	public void setDltRsnDtlCt(java.lang.String dltRsnDtlCt) {
		this.dltRsnDtlCt = dltRsnDtlCt;
	}

	public java.lang.String getUseLangCd() {
		return useLangCd;
	}

	public void setUseLangCd(java.lang.String useLangCd) {
		this.useLangCd = useLangCd;
	}

	public String getFrgnFlag() {
		return frgnFlag;
	}

	public void setFrgnFlag(String frgnFlag) {
		this.frgnFlag = frgnFlag;
	}

	public String getPstAraNm1() {
		return pstAraNm1;
	}

	public void setPstAraNm1(String pstAraNm1) {
		this.pstAraNm1 = pstAraNm1;
	}

	public String getDrAraNm1() {
		return drAraNm1;
	}

	public void setDrAraNm1(String drAraNm1) {
		this.drAraNm1 = drAraNm1;
	}

	public String getEnAraNm1() {
		return enAraNm1;
	}

	public void setEnAraNm1(String enAraNm1) {
		this.enAraNm1 = enAraNm1;
	}

	public String getPstLnth() {
		return pstLnth;
	}

	public void setPstLnth(String pstLnth) {
		this.pstLnth = pstLnth;
	}

	public String getDrLnth() {
		return drLnth;
	}

	public void setDrLnth(String drLnth) {
		this.drLnth = drLnth;
	}

	public String getEnLnth() {
		return enLnth;
	}

	public void setEnLnth(String enLnth) {
		this.enLnth = enLnth;
	}

	public String getLcaNmMaxLnth() {
		return lcaNmMaxLnth;
	}

	public void setLcaNmMaxLnth(String lcaNmMaxLnth) {
		this.lcaNmMaxLnth = lcaNmMaxLnth;
	}

	public String getEnMaxLnth() {
		return enMaxLnth;
	}

	public void setEnMaxLnth(String enMaxLnth) {
		this.enMaxLnth = enMaxLnth;
	}

	  
}
