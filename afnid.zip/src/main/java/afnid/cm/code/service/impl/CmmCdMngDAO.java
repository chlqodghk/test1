package afnid.cm.code.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import afnid.cm.code.service.CmCmmCdVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This class is Database Access Common Code of organization..
 * @author 
 * @since 2011.04.10
 * @version 1.0
 * @see
 *
 * <pre>
 * << (Modification Information) >>
 *   
 *   Modified      Modifiers           Revisions
 *  ---------      ---------    ---------------------------
 *   2011.04.10                       Create
 *
 * </pre>
 */
@Repository("cmmCdMngDAO")
public class CmmCdMngDAO extends EgovAbstractDAO {

	/**
	 * DAO-method for retrieving list information of common code in business application . <br>
	 * 
	 * @param vo Input item for retrieving list information of common code(CmCmmCdVO).
	 * @return CmCmmCdVO Retrieve list information of common code
	 * @exception Exception
	 */	
	@SuppressWarnings("unchecked")	
	public List<CmCmmCdVO> selectListCmmCd(CmCmmCdVO vo)
			throws Exception {
		return list("CmmCdManagerDAO.selectListCmmCd", vo);
	}
	
	/**
	 * DAO-method for retrieving list information of common code in business application . <br>
	 * 
	 * @param vo Input item for retrieving list information of common code(CmCmmCdVO).
	 * @return CmCmmCdVO Retrieve list information of common code
	 * @exception Exception
	 */	
	@SuppressWarnings("unchecked")	
	public List<CmCmmCdVO> selectListCmmCdDesc(CmCmmCdVO vo)
			throws Exception {
		return list("CmmCdManagerDAO.selectListCmmCdDesc", vo);
	}
	
	
	/**
	 * DAO-method for retrieving list information of common code in business application . <br>
	 * 
	 * @param vo Input item for retrieving list information of common code(CmCmmCdVO).
	 * @return CmCmmCdVO Retrieve list information of common code(
	 * @exception Exception
	 */	
	@SuppressWarnings("unchecked")	
	public List<CmCmmCdVO> selectListCmmCd(CmCmmCdVO vo, boolean flag)
			throws Exception {
		return list("CmmCdManagerDAO.selectListCmmCdVal", vo);
	}
	
	/**
	 * DAO-method for retrieving list information of common code in business application . <br>
	 * 
	 * @param vo Input item for retrieving list information of common code(CmCmmCdVO).
	 * @return CmCmmCdVO Retrieve list information of common code(
	 * @exception Exception
	 */	
	@SuppressWarnings("unchecked")	
	public List<CmCmmCdVO> selectListMn(CmCmmCdVO vo)
			throws Exception {
		return list("CmmCdManagerDAO.selectListMn", vo);
	}
	
	/**
	 * DAO-method for retrieving information of Address Code Name in CM_ARA_TB. <br>
	 * 
	 * @param vo Input item for retrieving list information of common code(CmCmmCdVO).
	 * @return CmCmmCdVO Retrieve  information of Address code(CmCmmCdVO)
	 * @exception Exception
	 */		
	public EgovMap selectAdCdNm(CmCmmCdVO vo)
			throws Exception {
		return (EgovMap)selectByPk("CmmCdManagerDAO.selectAdCdNm", vo);
	}
	
	/**
	 * DAO-method for retrieving common code in business application. <br>
	 * 
	 * @param cmCmmCd Common Code Value Object(CmCmmCdVO)
	 * @return Common Code 
	 * @throws Exception
	 */		
	public CmCmmCdVO selectCmmCd(CmCmmCdVO vo)
			throws Exception {
		return (CmCmmCdVO)selectByPk("CmmCdManagerDAO.selectCmmCd", vo);
	}
	
}
