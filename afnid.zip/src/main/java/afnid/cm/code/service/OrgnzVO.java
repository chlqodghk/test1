package afnid.cm.code.service;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of role-management
 * 
 * @author Afghanistan National ID Card System Application Team Eun Hee Kim
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.17 		Eun Hee Kim	      		 		Create
 *
 * </pre>
 */
public class OrgnzVO extends ComDefaultVO{
    private static final long serialVersionUID = 1L;
    
    /** ORGNZ_CD */
    private java.lang.String orgnzCd;
    
    /** orgnzClsCd */
    private java.lang.String orgnzClsCd;    
    
    /** orgnzClsCdNm */
    private java.lang.String orgnzClsCdNm;     
    
    /** organization name */
    private java.lang.String orgnzNm;
    
    /** PST_ORGNZ_NM */
    private java.lang.String pstOrgnzNm;
    
    /** PST_ORGNZ_ABRVN_NM */
    private java.lang.String pstOrgnzAbrvnNm;
    
    /** DR_ORGNZ_NM */
    private java.lang.String drOrgnzNm;
    
    /** DR_ORGNZ_ABRVN_NM */
    private java.lang.String drOrgnzAbrvnNm;
    
    /** UPR_ORGNZ_CD Pashto Name */
    private java.lang.String uprPstOrgnzNm;
    
    /** UPR_ORGNZ_CD Dari Name */
    private java.lang.String uprDrOrgnzNm;
    
    /** UPR_ORGNZ_CD */
    private java.lang.String uprOrgnzCd;
    
    /** UPR_ORGNZ_CD name */
    private java.lang.String uprOrgnzNm;
    
    /** RPRTN_TEL_NO */
    private java.lang.String rprtnTelNo;
    
    /** Telephone Number1 */
    private java.lang.String rprtnTelNo1;
    
    /** Telephone Number2 */
    private java.lang.String rprtnTelNo2;
    
    /** Telephone Number3 */
    private java.lang.String rprtnTelNo3;
    
    /** RPRTN_FX_NO */
    private java.lang.String rprtnFxNo;
    
    /** Fax Number1 */
    private java.lang.String rprtnFxNo1;
    
    /** Fax Number2 */
    private java.lang.String rprtnFxNo2;
    
    /** Fax Number3 */
    private java.lang.String rprtnFxNo3;
    
    /** RPRTN_HMPG_AD */
    private java.lang.String rprtnHmpgAd;
    
    /** RPRTN_AD_CD */
    private java.lang.String rprtnAdCd;
    
    /** Address name*/
    private java.lang.String rprtnAdNm;
    
    /** RPRTN_AD_DTL_CT */
    private java.lang.String rprtnAdDtlCt;
    
    /** PROR_RNK_NO */
    private java.lang.String prorRnkNo;
    
    /** DLT_YN */
    private java.lang.String dltYn;
    
    /** DLT_RSN_DTL_CT */
    private java.lang.String dltRsnDtlCt;
    
    /** FST_RGST_USER_ID */
    private java.lang.String fstRgstUserId;
    
    /** FST_RGST_DT */
    private java.lang.String fstRgstDt;
    
    /** LST_UDT_USER_ID */
    private java.lang.String lstUdtUserId;
    
    /** LST_UDT_DT */
    private java.lang.String lstUdtDt;
    
    /** LST_UDT_DT */
    private java.lang.String status;
    
    /** AD_CD */
    private java.lang.String adCd;
    
    /** ARA_NM */
    private java.lang.String araNm;
    
    /** User Language Code */
    private java.lang.String useLangCd;
    
    /** upper organization count */
    private int uprCnt;
    
    /** cptc count */
    private int cptcCnt;
    
    /** User Language Code */
    private String enOrgnzNm;
    
    /** lower organization code */
    private int lwrCnt;
    
    /** region code */
    private String rgnCd;
    
    /** region name */
    private String rgnCdNm;        
    private String oficTye;    
    private String lcaCntr;
    private String srch1;
    private String srch2;
    
	public String getEnOrgnzNm() {
		return enOrgnzNm;
	}

	public void setEnOrgnzNm(String enOrgnzNm) {
		this.enOrgnzNm = enOrgnzNm;
	}

	public int getUprCnt() {
		return uprCnt;
	}

	public void setUprCnt(int uprCnt) {
		this.uprCnt = uprCnt;
	}

	public int getCptcCnt() {
		return cptcCnt;
	}

	public void setCptcCnt(int cptcCnt) {
		this.cptcCnt = cptcCnt;
	}

	public java.lang.String getOrgnzCd() {
		return orgnzCd;
	}

	public void setOrgnzCd(java.lang.String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	
	public java.lang.String getOrgnzNm() {
		return orgnzNm;
	}

	public void setOrgnzNm(java.lang.String orgnzNm) {
		this.orgnzNm = orgnzNm;
	}	

	public java.lang.String getPstOrgnzNm() {
		return pstOrgnzNm;
	}

	public void setPstOrgnzNm(java.lang.String pstOrgnzNm) {
		this.pstOrgnzNm = pstOrgnzNm;
	}

	public java.lang.String getDrOrgnzNm() {
		return drOrgnzNm;
	}

	public void setDrOrgnzNm(java.lang.String drOrgnzNm) {
		this.drOrgnzNm = drOrgnzNm;
	}

	public java.lang.String getUprPstOrgnzNm() {
		return uprPstOrgnzNm;
	}

	public void setUprPstOrgnzNm(java.lang.String uprPstOrgnzNm) {
		this.uprPstOrgnzNm = uprPstOrgnzNm;
	}

	public java.lang.String getUprDrOrgnzNm() {
		return uprDrOrgnzNm;
	}

	public void setUprDrOrgnzNm(java.lang.String uprDrOrgnzNm) {
		this.uprDrOrgnzNm = uprDrOrgnzNm;
	}

	public java.lang.String getPstOrgnzAbrvnNm() {
		return pstOrgnzAbrvnNm;
	}

	public void setPstOrgnzAbrvnNm(java.lang.String pstOrgnzAbrvnNm) {
		this.pstOrgnzAbrvnNm = pstOrgnzAbrvnNm;
	}

	public java.lang.String getDrOrgnzAbrvnNm() {
		return drOrgnzAbrvnNm;
	}

	public void setDrOrgnzAbrvnNm(java.lang.String drOrgnzAbrvnNm) {
		this.drOrgnzAbrvnNm = drOrgnzAbrvnNm;
	}

	public java.lang.String getUprOrgnzCd() {
		return uprOrgnzCd;
	}

	public void setUprOrgnzCd(java.lang.String uprOrgnzCd) {
		this.uprOrgnzCd = uprOrgnzCd;
	}

	public java.lang.String getUprOrgnzNm() {
		return uprOrgnzNm;
	}

	public void setUprOrgnzNm(java.lang.String uprOrgnzNm) {
		this.uprOrgnzNm = uprOrgnzNm;
	}

	public java.lang.String getRprtnTelNo() {
		return rprtnTelNo;
	}

	public void setRprtnTelNo(java.lang.String rprtnTelNo) {
		this.rprtnTelNo = rprtnTelNo;
	}

	public java.lang.String getRprtnTelNo1() {
		return rprtnTelNo1;
	}

	public void setRprtnTelNo1(java.lang.String rprtnTelNo1) {
		this.rprtnTelNo1 = rprtnTelNo1;
	}

	public java.lang.String getRprtnTelNo2() {
		return rprtnTelNo2;
	}

	public void setRprtnTelNo2(java.lang.String rprtnTelNo2) {
		this.rprtnTelNo2 = rprtnTelNo2;
	}

	public java.lang.String getRprtnTelNo3() {
		return rprtnTelNo3;
	}

	public void setRprtnTelNo3(java.lang.String rprtnTelNo3) {
		this.rprtnTelNo3 = rprtnTelNo3;
	}

	public java.lang.String getRprtnFxNo() {
		return rprtnFxNo;
	}

	public void setRprtnFxNo(java.lang.String rprtnFxNo) {
		this.rprtnFxNo = rprtnFxNo;
	}

	public java.lang.String getRprtnFxNo1() {
		return rprtnFxNo1;
	}

	public void setRprtnFxNo1(java.lang.String rprtnFxNo1) {
		this.rprtnFxNo1 = rprtnFxNo1;
	}

	public java.lang.String getRprtnFxNo2() {
		return rprtnFxNo2;
	}

	public void setRprtnFxNo2(java.lang.String rprtnFxNo2) {
		this.rprtnFxNo2 = rprtnFxNo2;
	}

	public java.lang.String getRprtnFxNo3() {
		return rprtnFxNo3;
	}

	public void setRprtnFxNo3(java.lang.String rprtnFxNo3) {
		this.rprtnFxNo3 = rprtnFxNo3;
	}

	public java.lang.String getRprtnHmpgAd() {
		return rprtnHmpgAd;
	}

	public void setRprtnHmpgAd(java.lang.String rprtnHmpgAd) {
		this.rprtnHmpgAd = rprtnHmpgAd;
	}

	public java.lang.String getRprtnAdCd() {
		return rprtnAdCd;
	}

	public void setRprtnAdCd(java.lang.String rprtnAdCd) {
		this.rprtnAdCd = rprtnAdCd;
	}

	public java.lang.String getRprtnAdNm() {
		return rprtnAdNm;
	}

	public void setRprtnAdNm(java.lang.String rprtnAdNm) {
		this.rprtnAdNm = rprtnAdNm;
	}

	public java.lang.String getRprtnAdDtlCt() {
		return rprtnAdDtlCt;
	}

	public void setRprtnAdDtlCt(java.lang.String rprtnAdDtlCt) {
		this.rprtnAdDtlCt = rprtnAdDtlCt;
	}

	public java.lang.String getProrRnkNo() {
		return prorRnkNo;
	}

	public void setProrRnkNo(java.lang.String prorRnkNo) {
		this.prorRnkNo = prorRnkNo;
	}

	public java.lang.String getDltYn() {
		return dltYn;
	}

	public void setDltYn(java.lang.String dltYn) {
		this.dltYn = dltYn;
	}

	public java.lang.String getDltRsnDtlCt() {
		return dltRsnDtlCt;
	}

	public void setDltRsnDtlCt(java.lang.String dltRsnDtlCt) {
		this.dltRsnDtlCt = dltRsnDtlCt;
	}

	public java.lang.String getFstRgstUserId() {
		return fstRgstUserId;
	}

	public void setFstRgstUserId(java.lang.String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}

	public java.lang.String getFstRgstDt() {
		return fstRgstDt;
	}

	public void setFstRgstDt(java.lang.String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}

	public java.lang.String getLstUdtUserId() {
		return lstUdtUserId;
	}

	public void setLstUdtUserId(java.lang.String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}

	public java.lang.String getLstUdtDt() {
		return lstUdtDt;
	}

	public void setLstUdtDt(java.lang.String lstUdtDt) {
		this.lstUdtDt = lstUdtDt;
	}

	public java.lang.String getStatus() {
		return status;
	}

	public void setStatus(java.lang.String status) {
		this.status = status;
	}

	public java.lang.String getAdCd() {
		return adCd;
	}

	public void setAdCd(java.lang.String adCd) {
		this.adCd = adCd;
	}

	public java.lang.String getAraNm() {
		return araNm;
	}

	public void setAraNm(java.lang.String araNm) {
		this.araNm = araNm;
	}

	public java.lang.String getUseLangCd() {
		return useLangCd;
	}

	public void setUseLangCd(java.lang.String useLangCd) {
		this.useLangCd = useLangCd;
	}

	public java.lang.String getOrgnzClsCd() {
		return orgnzClsCd;
	}

	public void setOrgnzClsCd(java.lang.String orgnzClsCd) {
		this.orgnzClsCd = orgnzClsCd;
	}

	public java.lang.String getOrgnzClsCdNm() {
		return orgnzClsCdNm;
	}

	public void setOrgnzClsCdNm(java.lang.String orgnzClsCdNm) {
		this.orgnzClsCdNm = orgnzClsCdNm;
	}

	public int getLwrCnt() {
		return lwrCnt;
	}

	public void setLwrCnt(int lwrCnt) {
		this.lwrCnt = lwrCnt;
	}

	public String getRgnCd() {
		return rgnCd;
	}

	public void setRgnCd(String rgnCd) {
		this.rgnCd = rgnCd;
	}

	public String getRgnCdNm() {
		return rgnCdNm;
	}

	public void setRgnCdNm(String rgnCdNm) {
		this.rgnCdNm = rgnCdNm;
	}

	public String getOficTye() {
		return oficTye;
	}

	public void setOficTye(String oficTye) {
		this.oficTye = oficTye;
	}

	public String getSrch1() {
		return srch1;
	}

	public void setSrch1(String srch1) {
		this.srch1 = srch1;
	}

	public String getSrch2() {
		return srch2;
	}

	public void setSrch2(String srch2) {
		this.srch2 = srch2;
	}

	public String getLcaCntr() {
		return lcaCntr;
	}

	public void setLcaCntr(String lcaCntr) {
		this.lcaCntr = lcaCntr;
	}

}
