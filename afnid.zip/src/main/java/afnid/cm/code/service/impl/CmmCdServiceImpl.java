package afnid.cm.code.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.code.service.CmmCdService;
import afnid.cm.code.service.CmmCdVO;
import afnid.cm.code.service.CdGrpVO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;

/** 
 * This service class is biz-class of code group-management
 * and implements NidProgrmManageService class.
 * 
 * @author Afghanistan National ID Card System Application Team 
 * @since 2011.04.10
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers				Revisions
 *   2011.04.10  		MH ChoungGg         		Create
 *
 * </pre>
 */
@Service("cmmCdService")
public class CmmCdServiceImpl extends AbstractServiceImpl implements CmmCdService {

	@Resource(name="cmmCdDAO")
    private CmmCdDAO cmmCdDAO;

        
    /** NidMesscode group */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
	
	/**
	 * Biz-method for retrieving detail Information of code group. <br>
	 * 
	 * @param vo Input item for retrieving detail information of code group(CdGrpVO).
	 * @return CdGrpVO Retrieve detail information of code group
	 * @exception Exception
	 */
	public CdGrpVO searchCdGrp(CdGrpVO vo) throws Exception{
         	return (CdGrpVO)cmmCdDAO.selectCdGrp(vo);
	}
	
	/**
	 * Biz-method for retrieving list of code group. <br>
	 * 
	 * @param vo Input item for retrieving list of code group(CdGrpVO).
	 * @return List Retrieve list of code group
	 * @exception Exception
	 */
	public List<CdGrpVO> searchListCdGrp(CdGrpVO vo) throws Exception {
		
		return cmmCdDAO.selectListCdGrp(vo);
	}
	/**
	 * Biz-method for retrieving total count list of code group. <br>
	 * 
	 * @param vo Input item for retrieving list of code group(CdGrpVO).
	 * @return int Total Count of code group List
	 * @exception Exception
	 */
    public int searchListCdGrpTotCnt(CdGrpVO vo) throws Exception {
        return cmmCdDAO.selectListCdGrpTotCnt(vo);
	}
	/**
	 * Biz-method for registering information of new code group. <br>
	 * 
	 * @param vo Input item for registering new code group(CdGrpVO).
	 * @return CdGrpVO Primary Key value of registered code group
	 * @exception Exception
	 */
	public CdGrpVO addCdGrp(CdGrpVO vo) throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setGrpCd(vo.getGrpCd());
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
		
    	cmmCdDAO.insertCdGrp(vo);

		
    	return vo;
	}

	/**
	 * Biz-method for modifying information of code group. <br>
	 * 
	 * @param vo Input item for modifying code group(CdGrpVO).
	 * @exception Exception
	 */
	public void modifyCdGrp(CdGrpVO vo) throws Exception {
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
    	cmmCdDAO.updateCdGrp(vo);
	}


	/**
	 * Biz-method for retrieving detail Information of code group. <br>
	 * 
	 * @param vo Input item for retrieving detail information of code group(CdGrpVO).
	 * @return CdGrpVO Retrieve detail information of code group
	 * @exception Exception
	 */
	public CmmCdVO searchCmmCd(CmmCdVO vo) throws Exception{
         	return (CmmCdVO)cmmCdDAO.selectCmmCd(vo);
	}
	/**
	 * Biz-method for retrieving list of code group. <br>
	 * 
	 * @param vo Input item for retrieving list of code group(CmmCdVO).
	 * @return List Retrieve list of code group
	 * @exception Exception
	 */
	public List<CmmCdVO> searchListCmmCd(CmmCdVO vo) throws Exception {
   		return cmmCdDAO.selectListCmmCd(vo);
	}
	
	/**
	 * Biz-method for registering information of new code group. <br>
	 * 
	 * @param vo Input item for registering new code group(CmmCdVO).
	 * @return CmmCdVO Primary Key value of registered code group
	 * @exception Exception
	 */
	public CmmCdVO addCmmCd(CmmCdVO vo) throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
		

    	cmmCdDAO.insertCmmCd(vo);
    	
    	return vo;
	}

	/**
	 * Biz-method for modifying information of code group. <br>
	 * 
	 * @param vo Input item for modifying code group(CmmCdVO).
	 * @exception Exception
	 */
	public void modifyCmmCd(CmmCdVO vo) throws Exception {
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
    	cmmCdDAO.updateCmmCd(vo);
	}
	/**
	 * Biz-method for deleting information of code . <br>
	 * 
	 * @param vo Input item for deleting code group(CdGrpVO).
	 * @exception Exception
	 */
	public void removeCmmCd(CmmCdVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());		
    	cmmCdDAO.deleteCmmCd(vo);   	
    	
	}

    /**
	 * Biz-method for retrieving total count list of code group. <br>
	 * 
	 * @param vo Input item for retrieving list of code group(CdGrpVO).
	 * @return int Total Count of code group List
	 * @exception Exception
	 */
    public int searchListCmmCdCnt(CmmCdVO vo) throws Exception {
        return cmmCdDAO.selectListCmmCdCnt(vo);
	}
	
	/**
	 * Biz-method for Retrieves list of overflowed code. <br>
	 * 
	 * @param vo Input item for retrieving  list of overflowed code(CmmCdVO).
	 * @return List Retrieves list of overflowed code
	 * @exception Exception
	 */	
	public List<CmmCdVO> searchListCdLnthChk(CmmCdVO vo) throws Exception{
         	return cmmCdDAO.selectListCdLnthChk(vo);
	}    
	
	/**
	 * Biz-method for Retrieves total count of overflowed code <br>
	 * 
	 * @param vo Input item for retrieving  total count of overflowed code(CmmCdVO).
	 * @return List Retrieves total count of overflowed code
	 * @exception Exception
	 */	
	public int searchListCdLnthChkTotCnt(CmmCdVO vo) throws Exception{
         	return cmmCdDAO.selectListCdLnthChkTotCnt(vo);
	} 
	
	
}