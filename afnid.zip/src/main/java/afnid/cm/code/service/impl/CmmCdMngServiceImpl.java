package afnid.cm.code.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 *  This service class is biz_class for common code search.
 * @author 
 * @since 2011.04.10
 * @version 1.0
 * @see
 *
 * <pre>
 * << (Modification Information) >>
 *   
 *   Modified      Modifiers           Revisions
 *  ---------      ---------    ---------------------------
 *   2011.04.10                       Create
 *
 * </pre>
 */
@Service("cmmCdMngService")
public class CmmCdMngServiceImpl extends AbstractServiceImpl implements CmmCdMngService {
	@Resource(name="cmmCdMngDAO")
    private CmmCdMngDAO cmmCdMngDAO;

	/**
	 * Retrieves list of common in business application.
	 * 
	 * @param cmCmmCd Common Code Value Object(CmCmmCdVO)
	 * @return Common Code List
	 * @throws Exception
	 */
	public List<CmCmmCdVO> searchListCmmCd(CmCmmCdVO cmCmmCd)
			throws Exception {

		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		cmCmmCd.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		
		return cmmCdMngDAO.selectListCmmCd(cmCmmCd);
	}
	
	/**
	 * Retrieves list of common in business application.
	 * 
	 * @param cmCmmCd Common Code Value Object(CmCmmCdVO)
	 * @return Common Code List
	 * @throws Exception
	 */
	public List<CmCmmCdVO> searchListCmmCdDesc(CmCmmCdVO cmCmmCd)
			throws Exception {

		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		cmCmmCd.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		
		return cmmCdMngDAO.selectListCmmCdDesc(cmCmmCd);
	}
	
	
	/**
	 * Retrieves list of common in business application.
	 * 
	 * @param cmCmmCd Common Code Value Object(CmCmmCdVO)
	 * @return Common Code List
	 * @throws Exception
	 */
	public List<CmCmmCdVO> searchListNoSesonCmmCd(CmCmmCdVO cmCmmCd, String userLangCd)
			throws Exception {
		cmCmmCd.setUseLangCd(userLangCd);// Setting Use Language Code
		return cmmCdMngDAO.selectListCmmCdDesc(cmCmmCd);
	}
	
	
	/**
	 * Retrieves list of common in business application.
	 * 
	 * @param cmCmmCd Common Code Value Object(CmCmmCdVO)
	 * @return Common Code List
	 * @throws Exception
	 */	
	public List<CmCmmCdVO> searchListCmmCd(CmCmmCdVO cmCmmCd, boolean flag, String codeValue)
			throws Exception {

		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		cmCmmCd.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		if(flag){
			cmCmmCd.setCmmCdNm("Y");
		}else{
			cmCmmCd.setCmmCdNm("N");
		}
		cmCmmCd.setProrRnkNo(codeValue);
		if(codeValue == null || codeValue.length()  == 0 || (codeValue != null && !codeValue.equals("desc"))){
			cmCmmCd.setProrRnkNo("asc");
		}
		return cmmCdMngDAO.selectListCmmCd(cmCmmCd, flag);
	}
	
	/**
	 * Retrieves menu sequence number.
	 * 
	 * @param cmCmmCd Common Code Value Object(CmCmmCdVO)
	 * @return List
	 * @throws Exception
	 */
	public List<CmCmmCdVO> searchListMn(CmCmmCdVO cmCmmCd)
		throws Exception {

		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		cmCmmCd.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		return cmmCdMngDAO.selectListMn(cmCmmCd);
	}
	
	/**
	 * Retrieves Address Code Name in CM_ARA_TB.
	 * 
	 * @param cmCmmCd Common Code Value Object(CmCmmCdVO)
	 * @return Address Code Name
	 * @throws Exception
	 */
	public EgovMap searchAdCdNm(CmCmmCdVO cmCmmCd) 
			throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		cmCmmCd.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		
		return cmmCdMngDAO.selectAdCdNm(cmCmmCd);
	}
	
	/**
	 * Retrieves list of common in business application.
	 * 
	 * @param cmCmmCd Common Code Value Object(CmCmmCdVO)
	 * @return Common Code List
	 * @throws Exception
	 */
	public CmCmmCdVO searchCmmCd(CmCmmCdVO vo)
			throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code		
		return cmmCdMngDAO.selectCmmCd(vo);
	}	
}
