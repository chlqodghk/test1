package afnid.cm.code.service;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of common code -management
 * 
 * @author Afghanistan National ID Card System Application Team 
 * @since 2011.04.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers         	Revisions
 *   2011.04.21  		MH Choung         		Create
 *
 * </pre>
 */
public class CdGrpVO extends ComDefaultVO { 

	private static final long serialVersionUID = 1L;
    /**GROUP CODE*/	         
	private  String    grpCd;
    /**PASHTO GROUP CODE NAME*/	         
	private  String    pstGrpCdNm;
    /**DARI GROUP CODE NAME*/	         
	private  String    drGrpCdNm;
    /**PASHTO GROUP CODE DESCRIPTION*/	         
	private  String    pstGrpCdDs;
    /**DARI GROUP CODE DESCRIPTION*/	         
	private  String    drGrpCdDs;
    /**DELETE YN*/	         
	private  String    dltYn;
    /**DELETE REASON DETAIL CONTENTS*/	         
	private  String    dltRsnDtlCt;
    /**FIRST REGISTRATION USER ID*/	         
	private  String    fstRgstUserId;
    /**FIRST REGISTRATION DATETIME*/	         
	private  String    fstRgstDt;
    /**LAST UPDATE USER ID*/	         
	private  String    lstUdtUserId;
    /**LAST UPDATE DATETIME*/	         
	private  String    lstUdtDt;
	
	private String enGrpCdNm;
	private String cmmCd;
	private String cdTye;
	private String lcaCmmCdNmMaxLnth;
	private String enCmmCdNmMaxLnth;
    private String sortCd;
    private String cmmCdTye; 
    private String cdSotNo;
    
    public String getCdTye() {
		return cdTye;
	}
	public void setCdTye(String cdTye) {
		this.cdTye = cdTye;
	}
	public String getCmmCd() {
		return cmmCd;
	}
	public void setCmmCd(String cmmCd) {
		this.cmmCd = cmmCd;
	}
	public String getEnGrpCdNm() {
		return enGrpCdNm;
	}
	public void setEnGrpCdNm(String enGrpCdNm) {
		this.enGrpCdNm = enGrpCdNm;
	}
	public String getGrpCd() {
		return grpCd;
	}
	public void setGrpCd(String grpCd) {
		this.grpCd = grpCd;
	}
	public String getPstGrpCdNm() {
		return pstGrpCdNm;
	}
	public void setPstGrpCdNm(String pstGrpCdNm) {
		this.pstGrpCdNm = pstGrpCdNm;
	}
	public String getDrGrpCdNm() {
		return drGrpCdNm;
	}
	public void setDrGrpCdNm(String drGrpCdNm) {
		this.drGrpCdNm = drGrpCdNm;
	}
	public String getPstGrpCdDs() {
		return pstGrpCdDs;
	}
	public void setPstGrpCdDs(String pstGrpCdDs) {
		this.pstGrpCdDs = pstGrpCdDs;
	}
	public String getDrGrpCdDs() {
		return drGrpCdDs;
	}
	public void setDrGrpCdDs(String drGrpCdDs) {
		this.drGrpCdDs = drGrpCdDs;
	}
	public String getDltYn() {
		return dltYn;
	}
	public void setDltYn(String dltYn) {
		this.dltYn = dltYn;
	}
	public String getDltRsnDtlCt() {
		return dltRsnDtlCt;
	}
	public void setDltRsnDtlCt(String dltRsnDtlCt) {
		this.dltRsnDtlCt = dltRsnDtlCt;
	}
	public String getFstRgstUserId() {
		return fstRgstUserId;
	}
	public void setFstRgstUserId(String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}
	public String getFstRgstDt() {
		return fstRgstDt;
	}
	public void setFstRgstDt(String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}
	public String getLstUdtUserId() {
		return lstUdtUserId;
	}
	public void setLstUdtUserId(String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}
	public String getLstUdtDt() {
		return lstUdtDt;
	}
	public void setLstUdtDt(String lstUdtDt) {
		this.lstUdtDt = lstUdtDt;
	}

	public String getLcaCmmCdNmMaxLnth() {
		return lcaCmmCdNmMaxLnth;
	}
	public void setLcaCmmCdNmMaxLnth(String lcaCmmCdNmMaxLnth) {
		this.lcaCmmCdNmMaxLnth = lcaCmmCdNmMaxLnth;
	}
	public String getEnCmmCdNmMaxLnth() {
		return enCmmCdNmMaxLnth;
	}
	public void setEnCmmCdNmMaxLnth(String enCmmCdNmMaxLnth) {
		this.enCmmCdNmMaxLnth = enCmmCdNmMaxLnth;
	}
	public String getSortCd() {
		return sortCd;
	}
	public void setSortCd(String sortCd) {
		this.sortCd = sortCd;
	}
	public String getCmmCdTye() {
		return cmmCdTye;
	}
	public void setCmmCdTye(String cmmCdTye) {
		this.cmmCdTye = cmmCdTye;
	}
	public String getCdSotNo() {
		return cdSotNo;
	}
	public void setCdSotNo(String cdSotNo) {
		this.cdSotNo = cdSotNo;
	}

	  
}