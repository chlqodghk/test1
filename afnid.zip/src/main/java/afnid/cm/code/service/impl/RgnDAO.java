package afnid.cm.code.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import afnid.cm.code.service.RgnVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This class is Database Access Object of region.
 * 
 * @author Afghanistan National ID Card System Application Team Eun Hee Kim
 * @since 2011.05.24
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.24 		Eun Hee Kim	      		 		Create
 *
 * </pre>
 */
@Repository("rgnDAO")
public class RgnDAO extends EgovAbstractDAO{
	
	/**
	 * DAO-method for retrieving list Information of region. <br>
	 * 
	 * @param vo Input item for retrieving list information of region(RegionInfoVO).
	 * @return RegionInfoVO Retrieve list information of region
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")	
	public List<RgnVO> selectListRgn(RgnVO vo) throws Exception{
		return list("rgnDAO.selectListRgn", vo);
	}
	
	/**
	 * DAO-method for retrieving total count list of region. <br>
	 * 
	 * @param vo Input item for retrieving list of region(RegionInfoVO).
	 * @return int Total Count of region List
	 * @exception Exception
	 */
    public int selectListRgnTotCnt(RgnVO vo) {
        return (Integer)selectByPk("rgnDAO.selectListRgnTotCnt", vo);
    }
    
    /**
	 * DAO-method for registering information of new region. <br>
	 * 
	 * @param vo Input item for registering new region(RegionInfoVO).
	 * @return RegionInfoVO Primary Key value of registered region
	 * @exception Exception
	 */
	public void insertRgn(RgnVO vo){
		insert("rgnDAO.insertRgn", vo);
	}
	
    /**
	 * DAO-method for retrieving detail Information of region. <br>
	 * 
	 * @param vo Input item for retrieving detail information of region(RegionInfoVO).
	 * @return RegionInfoVO Retrieve detail information of region
	 * @exception Exception
	 */
	public RgnVO selectRgn(RgnVO vo)throws Exception{
		return (RgnVO)selectByPk("rgnDAO.selectRgn", vo); 
	}
	
	/**
	 * DAO-method for retrieving total count list of lower region. <br>
	 * 
	 * @param vo Input item for retrieving list of lower region(RegionInfoVO).
	 * @return int Total Count of lower region List
	 * @exception Exception
	 */
    public int lstLowRegSize(RgnVO vo) {
        return (Integer)selectByPk("rgnDAO.lstLowRegSize", vo);
    }
	
	/**
	 * DAO-method for modifying information of region. <br>
	 * 
	 * @param vo Input item for modifying region(RegionInfoVO).
	 * @exception Exception
	 */
	public void updateRgn(RgnVO vo){
		update("rgnDAO.updateRgn", vo);
	}
	
	/**
	 * DAO-method for modifying information of region. <br>
	 * 
	 * @param vo Input item for modifying region(RegionInfoVO).
	 * @exception Exception
	 */
	public void updateRgnNm(RgnVO vo){
		update("rgnDAO.updateRgnNm", vo);
	}
	
	/**
	 * DAO-method for deleting information of region. <br>
	 * 
	 * @param vo Input item for deleting region(RegionInfoVO).
	 * @exception Exception
	 */
	public void deleteRgn(RgnVO vo){
		delete("rgnDAO.deleteRgn", vo);
	}
    
	/**
	 * DAO-method for retrieving list Information of region. <br>
	 * 
	 * @param vo Input item for retrieving list information of region(RegionInfoVO).
	 * @return RegionInfoVO Retrieve list information of region
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")	
	public List<RgnVO> selectListRgnAra(RgnVO vo) throws Exception{
		return list("rgnDAO.selectListRgnAra", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of region. <br>
	 * 
	 * @param vo Input item for retrieving list information of region(RegionInfoVO).
	 * @return RegionInfoVO Retrieve list information of region
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")	
	public List<RgnVO> selectListRgnDstr(RgnVO vo) throws Exception{
		return list("rgnDAO.selectListRgnDstr", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of region. <br>
	 * 
	 * @param vo Input item for retrieving list information of region(RegionInfoVO).
	 * @return RegionInfoVO Retrieve list information of region
	 * @exception Exception
	 */
	public RgnVO selectRgnAraInfr(RgnVO vo) throws Exception{
		return (RgnVO)selectByPk("rgnDAO.selectRgnAraInfr", vo); 
	}
	
	
	/**
	 * DAO-method for retrieving list Information of region. <br>
	 * 
	 * @param vo Input item for retrieving list information of region(RegionInfoVO).
	 * @return RegionInfoVO Retrieve list information of region
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")	
	public List<RgnVO> selectListRgnNmByPrt(RgnVO vo) throws Exception{
		return list("rgnDAO.selectListRgnNmByPrt", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of region. <br>
	 * 
	 * @param vo Input item for retrieving list information of region(RegionInfoVO).
	 * @return RegionInfoVO Retrieve list information of region
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")	
	public List<RgnVO> selectListRgnNmByChd(RgnVO vo) throws Exception{
		return list("rgnDAO.selectListRgnNmByChd", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of region. <br>
	 * 
	 * @param vo Input item for retrieving list information of region(RgnVO).
	 * @return RegionInfoVO Retrieve list information of region
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListAdCd(RgnVO vo) throws Exception{
		return list("regionInfoDAO.selectListAdCd", vo);
	}

	/**
	 * DAO-method for Retrieves list of overflowed province. * 
	 * 
	 * @param vo Input item for retrieving  list of overflowed province(RgnVO).
	 * @return List Retrieves list of overflowed province
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<RgnVO> selecthListRgnLnthChk(RgnVO vo) throws Exception{
		return list("regionInfoDAO.selecthListRgnLnthChk", vo);
	}   
	
    /**
	 * DAO-method for retrieving total count of overflowed province. <br>
	 * 
	 * @param vo Input item for retrieving total count of overflowed province(RgnVO).
	 * @return int Total Count of overflowed province
	 * @exception Exception
	 */
    public int selecthListRgnLnthChkTotCnt(RgnVO vo) {
        return (Integer)selectByPk("regionInfoDAO.selecthListRgnLnthChkTotCnt", vo);
    }	
}
