package afnid.cm.code.service.impl;

import java.util.List;
 
import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import afnid.cm.code.service.CdGrpVO;
import afnid.cm.code.service.CmmCdVO;

/** 
 * This class is Database Access Object of common code 
 * 
 * @author Afghanistan National ID Card System Application Team 
 * @since 2011.04.10
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers      			Revisions
 *   2011.04.10  		MH Choung         		Create
 *
 * </pre>
 */
@Repository("cmmCdDAO")
public class CmmCdDAO extends EgovAbstractDAO {

	/**
	 * DAO-method for retrieving detail Information of code group * 
	 * @param vo Input item for retrieving detail information of code group(CdGrpVO).
	 * @return CdGrpVO Retrieve detail information of code group
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<CdGrpVO> selectListCdGrp(CdGrpVO vo) throws Exception{
		return list("cmmCdDAO.selectListCdGrp", vo);
	}


    /**
	 * DAO-method for retrieving total count list of code group. <br>
	 * 
	 * @param vo Input item for retrieving list of code group(CdGrpVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListCdGrpTotCnt(CdGrpVO vo) {
        return (Integer)selectByPk("cmmCdDAO.selectListCdGrpTotCnt", vo);
    }	
	
	/**
	 * DAO-method for retrieving detail Information of code group. <br>
	 * 
	 * @param vo Input item for retrieving detail information of code group(CdGrpVO).
	 * @return CdGrpVO Retrieve detail information of code group
	 * @exception Exception
	 */
	public CdGrpVO selectCdGrp(CdGrpVO vo)throws Exception{
		return (CdGrpVO)selectByPk("cmmCdDAO.selectCdGrp", vo); 
	}

	/**
	 * DAO-method for registering information of new code group. <br>
	 * 
	 * @param vo Input item for registering new code group(CdGrpVO).
	 * @return CdGrpVO Primary Key value of registered code group
	 * @exception Exception
	 */
	public void insertCdGrp(CdGrpVO vo){
		insert("cmmCdDAO.insertCdGrp", vo);
	}

	/**
	 * DAO-method for modifying information of code group. <br>
	 * 
	 * @param vo Input item for modifying pCdGrpVOanageVO).
	 * @exception Exception
	 */
	public void updateCdGrp(CdGrpVO vo){
		update("cmmCdDAO.updateCdGrp", vo);
	}


	/**
	 * DAO-method for retrieving detail Information of code * 
	 * @param vo Input item for retrieving detail information of code group(CdGrpVO).
	 * @return CdGrpVO Retrieve detail information of code group
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<CmmCdVO> selectListCmmCd(CmmCdVO vo) throws Exception{
		return list("cmmCdDAO.selectListCmmCd", vo);
	}

   
	
	/**
	 * DAO-method for retrieving detail Information of code. <br>
	 * 
	 * @param vo Input item for retrieving detail information of code(CmmCdVO).
	 * @return CmmCdVO Retrieve detail information of code
	 * @exception Exception
	 */
	public CmmCdVO selectCmmCd(CmmCdVO vo)throws Exception{
		return (CmmCdVO)selectByPk("cmmCdDAO.selectCmmCd", vo); 
	}

	/**
	 * DAO-method for registering information of new code. <br>
	 * 
	 * @param vo Input item for registering new code(CmmCdVO).
	 * @return CmmCdVO Primary Key value of registered code
	 * @exception Exception
	 */
	public void insertCmmCd(CmmCdVO vo){
		insert("cmmCdDAO.insertCmmCd", vo);
	}

	/**
	 * DAO-method for modifying information of code. <br>
	 * 
	 * @param vo Input item for modifying pCmmCdVOanageVO).
	 * @exception Exception
	 */
	public void updateCmmCd(CmmCdVO vo){
		update("cmmCdDAO.updateCmmCd", vo);
	}

	/**
	 * DAO-method for deleting information of code. <br>
	 * 
	 * @param vo Input item for deleting code(CmmCdVO).
	 * @exception Exception
	 */
	public void deleteCmmCd(CmmCdVO vo){
		delete("cmmCdDAO.deleteCmmCd", vo);
	}

    
    /**
	 * DAO-method for retrieving total count list of code group. <br>
	 * 
	 * @param vo Input item for retrieving list of code group(CdGrpVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListCmmCdCnt(CmmCdVO vo) {
        return (Integer)selectByPk("cmmCdDAO.selectListCmmCdCnt", vo);
    }
	
	/**
	 * DAO-method for Retrieves list of overflowed code. * 
	 * 
	 * @param vo Input item for retrieving  list of overflowed code(CmmCdVO).
	 * @return List Retrieves list of overflowed code
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<CmmCdVO> selectListCdLnthChk(CmmCdVO vo) throws Exception{
		return list("cmmCdDAO.selectListCdLnthChk", vo);
	}   
	
    /**
	 * DAO-method for retrieving total count of overflowed code. <br>
	 * 
	 * @param vo Input item for retrieving total count of overflowed code(CdGrpVO).
	 * @return int Total Count of coverflowed code
	 * @exception Exception
	 */
    public int selectListCdLnthChkTotCnt(CmmCdVO vo) {
        return (Integer)selectByPk("cmmCdDAO.selectListCdLnthChkTotCnt", vo);
    }	
}