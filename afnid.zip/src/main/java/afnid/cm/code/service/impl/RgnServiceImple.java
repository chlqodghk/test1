package afnid.cm.code.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.code.service.RgnService;
import afnid.cm.code.service.RgnVO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of region
 * and implements region class.
 * 
 * @author Afghanistan National ID Card System Application Team  Eun Hee Kim
 * @since 2011.05.24
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.24 		Eun Hee Kim	      		 		Create
 *
 * </pre>
 */
@Service("rgnService")
public class RgnServiceImple extends AbstractServiceImpl implements RgnService{
	
	@Resource(name="rgnDAO")
    private RgnDAO rgnDAO;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /**
	 * Biz-method for retrieving list of region. <br>
	 * 
	 * @param vo Input item for retrieving list of region(RegionInfoVO).
	 * @return List Retrieve list of region
	 * @exception Exception
	 */
	public List<RgnVO> searchListRgn(RgnVO vo) throws Exception {
   		return rgnDAO.selectListRgn(vo);
	}
	
	/**
	 * Biz-method for retrieving total count list of region. <br>
	 * 
	 * @param vo Input item for retrieving list of region(RegionInfoVO).
	 * @return int Total Count of region List
	 * @exception Exception
	 */
    public int searchListRgnTotCnt(RgnVO vo) throws Exception {
    	return rgnDAO.selectListRgnTotCnt(vo);
	}
    
    /**
	 * Biz-method for registering information of new region. <br>
	 * 
	 * @param vo Input item for registering new region(RegionInfoVO).
	 * @return RegionInfoVO Primary Key value of registered region
	 * @exception Exception
	 */
	public RgnVO addRgn(RgnVO vo) throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
				
		rgnDAO.insertRgn(vo);
    	
    	return vo;
	}

    /**
	 * Biz-method for retrieving detail Information of region. <br>
	 * 
	 * @param vo Input item for retrieving detail information of region(RegionInfoVO).
	 * @return RegionInfoVO Retrieve detail information of region
	 * @exception Exception
	 */
	public RgnVO searchRgn(RgnVO vo) throws Exception{
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		
    	return (RgnVO)rgnDAO.selectRgn(vo);
	}
	
	/**
	 * Biz-method for retrieving total count list of lower region. <br>
	 * 
	 * @param vo Input item for retrieving list of lower region(RegionInfoVO).
	 * @return int Total Count of lower region List
	 * @exception Exception
	 */
    public int lstLowRegSize(RgnVO vo) throws Exception {
    	return rgnDAO.lstLowRegSize(vo);
	}
	
	/**
	 * Biz-method for modifying information of region. <br>
	 * 
	 * @param vo Input item for modifying region(RegionInfoVO).
	 * @exception Exception
	 */
	public void modifyRgn(RgnVO vo) throws Exception {
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
		
		rgnDAO.updateRgn(vo);
		
		if("".equals(vo.getUprAdCd()) || "null".equals(vo.getUprAdCd()) ){
			rgnDAO.updateRgnNm(vo);
		} 
	}
	
	/**
	 * Biz-method for deleting information of region. <br>
	 * 
	 * @param vo Input item for deleting region(RegionInfoVO).
	 * @exception Exception
	 */
	public void removeRgn(RgnVO vo) throws Exception {
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
		rgnDAO.deleteRgn(vo);
	}
   
	/**
	 * Biz-method for retrieving list of region. <br>
	 * 
	 * @param vo Input item for retrieving list of region(RegionInfoVO).
	 * @return List Retrieve list of region
	 * @exception Exception
	 */
	public List<RgnVO> searchListRgnAra(RgnVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd());
		return rgnDAO.selectListRgnAra(vo);
	}

	/**
	 * Biz-method for retrieving list of region. <br>
	 * 
	 * @param vo Input item for retrieving list of region(RegionInfoVO).
	 * @return List Retrieve list of region
	 * @exception Exception
	 */
	public List<RgnVO> searchListRgnDstr(RgnVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
		
		if( !("".equals(vo.getDstrCode()) || vo.getDstrCode() == null) ){
			RgnVO resultVO = rgnDAO.selectRgnAraInfr(vo);
			vo.setAraCode(resultVO.getUprAdCd());
		}
		
		return rgnDAO.selectListRgnDstr(vo);
	}
	
	
	/**
	 * Biz-method for retrieving list of region. <br>
	 * 
	 * @param vo Input item for retrieving list of region(RegionInfoVO).
	 * @return List Retrieve list of region
	 * @exception Exception
	 */
	public List<RgnVO> searchListRgnNmByPrt(RgnVO vo) throws Exception {
   		return rgnDAO.selectListRgnNmByPrt(vo);
	}
	
	/**
	 * Biz-method for retrieving list of region. <br>
	 * 
	 * @param vo Input item for retrieving list of region(RegionInfoVO).
	 * @return List Retrieve list of region
	 * @exception Exception
	 */
	public List<RgnVO> searchListRgnNmByChd(RgnVO vo) throws Exception {
   		return rgnDAO.selectListRgnNmByChd(vo);
	}
	
	/**
	 * Biz-method for retrieving list of region. <br>
	 * 
	 * @param vo Input item for retrieving list of region(RgnVO).
	 * @return List Retrieve list of region
	 * @exception Exception
	 */
	public List<EgovMap> searchListAdCd(RgnVO vo) throws Exception {
   		return rgnDAO.selectListAdCd(vo);
	}
	
	/**
	 * Biz-method for Retrieves list of overflowed province. <br>
	 * 
	 * @param vo Input item for retrieving  list of overflowed province(RgnVO).
	 * @return List Retrieves list of overflowed province
	 * @exception Exception
	 */	
	public List<RgnVO> searchListRgnLnthChk(RgnVO vo) throws Exception{
         	return rgnDAO.selecthListRgnLnthChk(vo);
	}    
	
	/**
	 * Biz-method for Retrieves total count of overflowed province <br>
	 * 
	 * @param vo Input item for retrieving  total count of overflowed province(RgnVO).
	 * @return List Retrieves total count of overflowed province
	 * @exception Exception
	 */	
	public int searchListRgnLnthChkTotCnt(RgnVO vo) throws Exception{
         	return rgnDAO.selecthListRgnLnthChkTotCnt(vo);
	}
	
}
