package afnid.cm.code.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.code.service.OrgnzService;
import afnid.cm.code.service.OrgnzVO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;

/** 
 * This service class is biz-class of organization
 * and implements organizationService class.
 * 
 * @author Afghanistan National ID Card System Application Team  Eun Hee Kim
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.17 		Eun Hee Kim	      		 		Create
 *
 * </pre>
 */
@Service("orgnzService")
public class OrgnzServiceImple extends AbstractServiceImpl implements OrgnzService{
	
	@Resource(name="orgnzDAO")
    private OrgnzDAO orgInfoDAO;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /**
	 * Biz-method for retrieving list of organization. <br>
	 * 
	 * @param vo Input item for retrieving list of organization(OrgnzVO).
	 * @return List Retrieve list of organization
	 * @exception Exception
	 */
	public List<OrgnzVO> searchListOrgnz(OrgnzVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());		
   		return orgInfoDAO.selectListOrgnz(vo);
	}
	
	/**
	 * Biz-method for retrieving total count list of organization. <br>
	 * 
	 * @param vo Input item for retrieving list of organization(OrgnzVO).
	 * @return int Total Count of organization List
	 * @exception Exception
	 */
    public int searchListOrgnzTotCnt(OrgnzVO vo) throws Exception {
    	return orgInfoDAO.selectListOrgnzTotCnt(vo);
	}
    
    /**
	 * Biz-method for retrieving detail Information of organization. <br>
	 * 
	 * @param vo Input item for retrieving detail information of organization(OrgnzVO).
	 * @return OrgnzVO Retrieve detail information of organization
	 * @exception Exception
	 */
	public OrgnzVO searchOrgnz(OrgnzVO vo) throws Exception{
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
    	return (OrgnzVO)orgInfoDAO.selectOrgnz(vo);
	}
	

    /**
	 * Biz-method for retrieving total count list of lower organization. <br>
	 * 
	 * @param vo Input item for retrieving list of lower organization(OrgnzVO).
	 * @return int Total Count of lower organization List
	 * @exception Exception
	 */
    public int searchLowOrgCnt(OrgnzVO vo) throws Exception {
    	return orgInfoDAO.selectLowOrgCnt(vo);
	}
	
    
	/**
	 * Retrieves Count  of District organization. <br>
	 * 
	 * @param vo Input item for retrieving list of organization(OrgnzVO).
	 * @return List Retrieve list of organization
	 * @exception Exception
	 */
	public int searchDstrOrgnzCnt(OrgnzVO vo) throws Exception {
		return orgInfoDAO.selectDstrOrgnzCnt(vo);
	}
	
	/**
	 * Retrieves Count  of central organization. <br>
	 * 
	 * @param vo Input item for retrieving list of organization(OrgnzVO).
	 * @return List Retrieve list of organization
	 * @exception Exception
	 */
	public int searchCtOrgnzCnt(OrgnzVO vo) throws Exception {
		return orgInfoDAO.selectCtOrgnzCnt(vo);
	}
	
	/**
	 * Biz-method for registering information of new organization. <br>
	 * 
	 * @param vo Input item for registering new organization(OrgnzVO).
	 * @return OrgInfoVO Primary Key value of registered organization
	 * @exception Exception
	 */
	public OrgnzVO addOrgnz(OrgnzVO vo) throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
				
		orgInfoDAO.insertOrgnz(vo);
    	
    	return vo;
	}
	
	/**
	 * Biz-method for modifying information of organization. <br>
	 * 
	 * @param vo Input item for modifying organization(OrgnzVO).
	 * @exception Exception
	 */
	public void modifyOrgnz(OrgnzVO vo) throws Exception {
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
		
		//Tel No
		vo.setRprtnTelNo1(NidStringUtil.getLPAD(vo.getRprtnTelNo1(), 4, " "));
		vo.setRprtnTelNo2(NidStringUtil.getLPAD(vo.getRprtnTelNo2(), 4, " "));
		vo.setRprtnTelNo3(NidStringUtil.getLPAD(vo.getRprtnTelNo3(), 4, " "));
		
		//Fax No
		vo.setRprtnFxNo1(NidStringUtil.getLPAD(vo.getRprtnFxNo1(), 4, " "));
		vo.setRprtnFxNo2(NidStringUtil.getLPAD(vo.getRprtnFxNo2(), 4, " "));
		vo.setRprtnFxNo3(NidStringUtil.getLPAD(vo.getRprtnFxNo3(), 4, " "));
		
		orgInfoDAO.updateOrgnz(vo);
	}
	
	/**
	 * Biz-method for deleting information of organization. <br>
	 * 
	 * @param vo Input item for deleting organization(OrgnzVO).
	 * @exception Exception
	 */
	public void removeOrgnz(OrgnzVO vo) throws Exception {
		orgInfoDAO.deleteOrgnz(vo);
	}

	/**
	 * Biz-method for Retrieves list of organization. <br>
	 * 
	 * @param vo Input item for retrieving approval list of organization(OrgnzVO).
	 * @return List Retrieves list of organization
	 * @exception Exception
	 */
	public List<OrgnzVO> searchListOrgnzAjax(OrgnzVO vo)
			throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		
		return orgInfoDAO.selectListOrgAjx(vo);
	}	
	
	/**
	 * Biz-method for Retrieves list of upper office. <br>
	 * 
	 * @param vo Input item for retrieving upper office(OrgnzVO).
	 * @return List Retrieves list of upper office
	 * @exception Exception
	 */
	public List<OrgnzVO> searchListUprOfic(OrgnzVO vo)
			throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		
		return orgInfoDAO.selectListUprOfic(vo);
	}
	
	/**
	 * Biz-method for Retrieves list of office. <br>
	 * 
	 * @param vo Input item for retrieving office(OrgnzVO).
	 * @return List Retrieves list of office
	 * @exception Exception
	 */
	public List<OrgnzVO> searchListOfic(OrgnzVO vo)
			throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		
		return orgInfoDAO.selectListOfic(vo);
	}	
	
    /**
	 * Biz-method for retrieving count of officer who have selected office code. <br>
	 * 
	 * @param vo Input item for retrieving count of officer who have selected office code(OrgnzVO).
	 * @return int count of officer who have selected office code
	 * @exception Exception
	 */
    public int searchOficrCnt(OrgnzVO vo) throws Exception {
    	return orgInfoDAO.selectOficrCnt(vo);
	}
    
	/**
	 * Biz-method for Retrieves list of office(tree). <br>
	 * 
	 * @param vo Input item for retrieving office(OrgnzVO).
	 * @return List Retrieves list of office
	 * @exception Exception
	 */
	public List<OrgnzVO> searchListOrgnzCdTree(OrgnzVO vo)
			throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		
		return orgInfoDAO.selectListOrgnzCdTree(vo);
	}	    
	
    /**
	 * Biz-method for retrieving office name. <br>
	 * 
	 * @param vo Input item for retrieving office name(OrgnzVO).
	 * @return OrgnzVO office name
	 * @exception Exception
	 */
	public OrgnzVO searchOrgnzNm(OrgnzVO vo) throws Exception{		
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
    	return (OrgnzVO)orgInfoDAO.selectOrgnzNm(vo);
	} 	
}
