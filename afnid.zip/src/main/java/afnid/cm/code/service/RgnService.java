package afnid.cm.code.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service interface is biz-class of region. <br>
 * 
 * @author Afghanistan National ID Card System Application Team  Eun Hee Kim
 * @since 2011.05.24
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.24 		Eun Hee Kim	      		 		Create
 *
 * </pre>
 */

public interface RgnService {
	
	/**
	 * Retrieves list of region. <br>
	 * 
	 * @param vo Input item for retrieving list of region(RegionInfoVO).
	 * @return List Retrieve list of region
	 * @exception Exception
	 */
	List <RgnVO> searchListRgn(RgnVO vo) throws Exception;
	
	/**
	 * Retrieves total count of region-list. <br>
	 * @param vo Input item for retrieving total count list of region.(RegionInfoVO)
	 * @return int Total Count of region List
	 * @exception Exception
	 */
	int searchListRgnTotCnt(RgnVO vo) throws Exception;
	
	/**
	 * Register information of new region. <br>
	 * 
	 * @param vo Input item for registering new region(RegionInfoVO).
	 * @return RegionInfoVO Primary Key value of registered region
	 * @exception Exception
	 */
	RgnVO addRgn(RgnVO vo) throws Exception;

	/**
	 * Retrieves detail Information of region. <br>
	 * 
	 * @param vo Input item for retrieving detail information of region(RegionInfoVO).
	 * @return RegionInfoVO Retrieve detail information of region
	 * @exception Exception
	 */
	RgnVO searchRgn(RgnVO vo) throws Exception;
	
	/**
	 * Retrieves total count of lower region-list. <br>
	 * @param vo Input item for retrieving total count list of lower region.(RegionInfoVO)
	 * @return int Total Count of lower region List
	 * @exception Exception
	 */
	int lstLowRegSize(RgnVO vo) throws Exception;

	/**
	 * Modifies information of region. <br>
	 * 
	 * @param vo Input item for modifying region(RegionInfoVO).
	 * @exception Exception
	 */
	void modifyRgn(RgnVO vo) throws Exception;
	
	/**
	 * Delete information of region. <br>
	 * 
	 * @param vo Input item for modifying region(RegionInfoVO).
	 * @exception Exception
	 */
	void removeRgn(RgnVO vo) throws Exception;

	/**
	 * Retrieves information of region. <br>
	 * 
	 * @param vo Input item for modifying region(RegionInfoVO).
	 * @exception Exception
	 */
	List <RgnVO> searchListRgnAra(RgnVO vo) throws Exception;
	
	/**
	 * Retrieves information of region. <br>
	 * 
	 * @param vo Input item for modifying region(RegionInfoVO).
	 * @exception Exception
	 */
	List <RgnVO> searchListRgnDstr(RgnVO vo) throws Exception;
	
	/**
	 * Biz-method for retrieving list of region. <br>
	 * 
	 * @param vo Input item for retrieving list of region(RegionInfoVO).
	 * @return List Retrieve list of region
	 * @exception Exception
	 */
	List<RgnVO> searchListRgnNmByPrt(RgnVO vo) throws Exception;
	
	/**
	 * Biz-method for retrieving list of region. <br>
	 * 
	 * @param vo Input item for retrieving list of region(RegionInfoVO).
	 * @return List Retrieve list of region
	 * @exception Exception
	 */
	List<RgnVO> searchListRgnNmByChd(RgnVO vo) throws Exception;
	
	
	/**
	 * Biz-method for retrieving list of region. <br>
	 * 
	 * @param vo Input item for retrieving list of region(RgnVO).
	 * @return List Retrieve list of region
	 * @exception Exception
	 */
	List<EgovMap> searchListAdCd(RgnVO vo) throws Exception;
	
	/**
	 * Retrieves list of overflowed province. <br>
	 * 
	 * @param vo Input item for retrieving  list of overflowed province(RgnVO).
	 * @return List Retrieves list of overflowed province
	 * @exception Exception
	 */
	List<RgnVO> searchListRgnLnthChk(RgnVO vo) throws Exception;	
	
	/**
	 * Retrieves total count of overflowed province. <br>
	 * 
	 * @param vo Input item for retrieving  total count of overflowed province(RgnVO).
	 * @return List Retrieves total count of overflowed province
	 * @exception Exception
	 */
	int searchListRgnLnthChkTotCnt(RgnVO vo) throws Exception;		

}

