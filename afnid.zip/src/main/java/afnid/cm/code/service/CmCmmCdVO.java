package afnid.cm.code.service;

/**
 * @Class Name : CmCmmCdTbVO.java
 * @Description : CmCmmCdTb VO class
 * @Modification Information
 *
 * @author DDD
 * @since DDD
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class CmCmmCdVO {

    /** CMM_CD */
    private java.lang.String cmmCd;
    
    /** CMM_CD_NM  */
    private java.lang.String cmmCdNm;
    
	/** GRP_CD */
    private java.lang.String grpCd;
    
    /** PST_CD_NM */
    private java.lang.String pstCdNm;
    
    /** DR_CD_NM */
    private java.lang.String drCdNm;
    
    /** PST_CD_DS */
    private java.lang.String pstCdDs;
    
    /** DR_CD_DS */
    private java.lang.String drCdDs;
    
    /** PROR_RNK_NO */
    private java.lang.String prorRnkNo;
    
    /** DLT_YN */
    private java.lang.String dltYn;
    
    /** DLT_RSN_DTL_CT */
    private java.lang.String dltRsnDtlCt;
    
    /** FST_RGST_USER_ID */
    private java.lang.String fstRgstUserId;
    
    /** FST_RGST_DT */
    private java.lang.String fstRgstDt;
    
    /** LST_UDT_USER_ID */
    private java.lang.String lstUdtUserId;
    
    /** LST_UDT_DT */
    private java.lang.String lstUdtDt;
    
    /** USE_LANG_CD */
    private java.lang.String useLangCd;
    
    /** MN_ID*/
    private java.lang.String mnId;
    /** MN_NM*/
    private java.lang.String mnNm;
    
    /** ORGNZ_CLS_CD */
    private java.lang.String orgnzClsCd;
    
    /** OFCAL_PSN_CD */
    private java.lang.String ofcalPsnCd;
    private java.lang.String cmmCdTye; 
    
	public java.lang.String getMnId() {
		return mnId;
	}

	public void setMnId(java.lang.String mnId) {
		this.mnId = mnId;
	}

	public java.lang.String getMnNm() {
		return mnNm;
	}

	public void setMnNm(java.lang.String mnNm) {
		this.mnNm = mnNm;
	}

	public java.lang.String getCmmCd() {
        return this.cmmCd;
    }
    
    public void setCmmCd(java.lang.String cmmCd) {
        this.cmmCd = cmmCd;
    }
    
    public java.lang.String getCmmCdNm() {
		return cmmCdNm;
	}

	public void setCmmCdNm(java.lang.String cmmCdNm) {
		this.cmmCdNm = cmmCdNm;
	}

    
    public java.lang.String getGrpCd() {
        return this.grpCd;
    }
    
    public void setGrpCd(java.lang.String grpCd) {
        this.grpCd = grpCd;
    }
    
    public java.lang.String getPstCdNm() {
        return this.pstCdNm;
    }
    
    public void setPstCdNm(java.lang.String pstCdNm) {
        this.pstCdNm = pstCdNm;
    }
    
    public java.lang.String getDrCdNm() {
        return this.drCdNm;
    }
    
    public void setDrCdNm(java.lang.String drCdNm) {
        this.drCdNm = drCdNm;
    }
    
    public java.lang.String getPstCdDs() {
        return this.pstCdDs;
    }
    
    public void setPstCdDs(java.lang.String pstCdDs) {
        this.pstCdDs = pstCdDs;
    }
    
    public java.lang.String getDrCdDs() {
        return this.drCdDs;
    }
    
    public void setDrCdDs(java.lang.String drCdDs) {
        this.drCdDs = drCdDs;
    }
    
    public java.lang.String getProrRnkNo() {
        return this.prorRnkNo;
    }
    
    public void setProrRnkNo(java.lang.String prorRnkNo) {
        this.prorRnkNo = prorRnkNo;
    }
    
    public java.lang.String getDltYn() {
        return this.dltYn;
    }
    
    public void setDltYn(java.lang.String dltYn) {
        this.dltYn = dltYn;
    }
    
    public java.lang.String getDltRsnDtlCt() {
        return this.dltRsnDtlCt;
    }
    
    public void setDltRsnDtlCt(java.lang.String dltRsnDtlCt) {
        this.dltRsnDtlCt = dltRsnDtlCt;
    }
    
    public java.lang.String getFstRgstUserId() {
        return this.fstRgstUserId;
    }
    
    public void setFstRgstUserId(java.lang.String fstRgstUserId) {
        this.fstRgstUserId = fstRgstUserId;
    }
    
    public java.lang.String getFstRgstDt() {
        return this.fstRgstDt;
    }
    
    public void setFstRgstDt(java.lang.String fstRgstDt) {
        this.fstRgstDt = fstRgstDt;
    }
    
    public java.lang.String getLstUdtUserId() {
        return this.lstUdtUserId;
    }
    
    public void setLstUdtUserId(java.lang.String lstUdtUserId) {
        this.lstUdtUserId = lstUdtUserId;
    }
    
    public java.lang.String getLstUdtDt() {
        return this.lstUdtDt;
    }
    
    public void setLstUdtDt(java.lang.String lstUdtDt) {
        this.lstUdtDt = lstUdtDt;
    }
    
    public java.lang.String getUseLangCd() {
		return useLangCd;
	}

	public void setUseLangCd(java.lang.String useLangCd) {
		this.useLangCd = useLangCd;
	}

	public java.lang.String getOrgnzClsCd() {
		return orgnzClsCd;
	}

	public void setOrgnzClsCd(java.lang.String orgnzClsCd) {
		this.orgnzClsCd = orgnzClsCd;
	}

	public java.lang.String getOfcalPsnCd() {
		return ofcalPsnCd;
	}

	public void setOfcalPsnCd(java.lang.String ofcalPsnCd) {
		this.ofcalPsnCd = ofcalPsnCd;
	}

	public java.lang.String getCmmCdTye() {
		return cmmCdTye;
	}

	public void setCmmCdTye(java.lang.String cmmCdTye) {
		this.cmmCdTye = cmmCdTye;
	}
    
	
}
