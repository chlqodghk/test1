package afnid.cm.code.service;

import java.util.List;

/** 
 * This service interface is biz-class of code group-management. <br>
 * 
 * @author Afghanistan National ID Card System Application Team 
 * @since 2011.04.10
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers				Revisions
 *   ---------			---------				----------
 *   2011.04.30  		MH Choung				Create
 *
 * </pre>
 */
public interface CmmCdService {
	
	
	/**
	 * Retrieves list of code group. <br>
	 * 
	 * @param vo Input item for retrieving list of code group(CdGrpVO).
	 * @return List Retrieve list of code group
	 * @exception Exception
	 */
	List<CdGrpVO> searchListCdGrp(CdGrpVO vo) throws Exception;
	
	/**
	 * Retrieves total count of code group-list. <br>
	 * @param vo Input item for retrieving total count list of code group.(CdGrpVO)
	 * @return int Total Count of code group List
	 * @exception Exception
	 */
	int searchListCdGrpTotCnt(CdGrpVO vo) throws Exception;	
	/**
	 * Retrieves detail Information of code group. <br>
	 * 
	 * @param vo Input item for retrieving detail information of code group(CmmCdVO).
	 * @return CdGrpVO Retrieve detail information of code group
	 * @exception Exception
	 */
	CdGrpVO searchCdGrp(CdGrpVO vo) throws Exception;
	/**
	 * Register information of new code group. <br>
	 * 
	 * @param vo Input item for registering new code group(CdGrpVO).
	 * @return CdGrpVO Primary Key value of registered code group
	 * @exception Exception
	 */
	CdGrpVO addCdGrp(CdGrpVO vo) throws Exception;

	/**
	 * Modifies information of code group. <br>
	 * 
	 * @param vo Input item for modifying code group(CdGrpVO).
	 * @exception Exception
	 */
	void modifyCdGrp(CdGrpVO vo) throws Exception;

	/**
	 * Retrieves list of Common Code. <br>
	 * 
	 * @param vo Input item for retrieving list of Common Code(CmmCdVO).
	 * @return List Retrieve list of Common Code
	 * @exception Exception
	 */
	List<CmmCdVO> searchListCmmCd(CmmCdVO vo) throws Exception;
	
	
	/**
	 * Retrieves detail Information of Common Code. <br>
	 * 
	 * @param vo Input item for retrieving detail information of Common Code(CdGrpVO).
	 * @return CdGrpVO Retrieve detail information of Common Code
	 * @exception Exception
	 */
	CmmCdVO searchCmmCd(CmmCdVO vo) throws Exception;
	/**
	 * Register information of new Common Code. <br>
	 * 
	 * @param vo Input item for registering new Common Code(CmmCdVO).
	 * @return CmmCdVO Primary Key value of registered Common Code
	 * @exception Exception
	 */
	CmmCdVO addCmmCd(CmmCdVO vo) throws Exception;

	/**
	 * Modifies information of Common Code. <br>
	 * 
	 * @param vo Input item for modifying Common Code(CmmCdVO).
	 * @exception Exception
	 */
	void modifyCmmCd(CmmCdVO vo) throws Exception;
	/**
	 * Delete information of Common Code. <br>
	 * 
	 * @param vo Input item for deleting Common Code(CdGrpVO).
	 * @exception Exception
	 */
	void removeCmmCd(CmmCdVO vo) throws Exception;
	
	/**
	 * Retrieves total count of code group-list. <br>
	 * @param vo Input item for retrieving total count list of code group.(CdGrpVO)
	 * @return int Total Count of code group List
	 * @exception Exception
	 */
	int searchListCmmCdCnt(CmmCdVO vo) throws Exception;	
	
	/**
	 * Retrieves list of overflowed code. <br>
	 * 
	 * @param vo Input item for retrieving  list of overflowed code(CmmCdVO).
	 * @return List Retrieves list of overflowed code
	 * @exception Exception
	 */
	List<CmmCdVO> searchListCdLnthChk(CmmCdVO vo) throws Exception;	
	
	/**
	 * Retrieves total count of overflowed codeh. <br>
	 * 
	 * @param vo Input item for retrieving  total count of overflowed code(CmmCdVO).
	 * @return List Retrieves total count of overflowed code
	 * @exception Exception
	 */
	int searchListCdLnthChkTotCnt(CmmCdVO vo) throws Exception;	
}