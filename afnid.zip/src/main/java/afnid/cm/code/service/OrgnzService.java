package afnid.cm.code.service;

import java.util.List;

/** 
 * This service interface is biz-class of organization. <br>
 * 
 * @author Afghanistan National ID Card System Application Team  Eun Hee Kim
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.17 		Eun Hee Kim	      		 		Create
 *
 * </pre>
 */

public interface OrgnzService {
	
	/**
	 * Retrieves list of organization. <br>
	 * 
	 * @param vo Input item for retrieving list of organization(OrgnzVO).
	 * @return List Retrieve list of organization
	 * @exception Exception
	 */
	List <OrgnzVO> searchListOrgnz(OrgnzVO vo) throws Exception;
	
	/**
	 * Retrieves total count of organization-list. <br>
	 * @param vo Input item for retrieving total count list of organization.(OrgnzVO)
	 * @return int Total Count of organization List
	 * @exception Exception
	 */
	int searchListOrgnzTotCnt(OrgnzVO vo) throws Exception;
	
	/**
	 * Retrieves detail Information of organization. <br>
	 * 
	 * @param vo Input item for retrieving detail information of organization(OrgnzVO).
	 * @return OrgnzVO Retrieve detail information of organization
	 * @exception Exception
	 */
	OrgnzVO searchOrgnz(OrgnzVO vo) throws Exception;
	
	
	/**
	 * Retrieves total count of lower organization-list. <br>
	 * @param vo Input item for retrieving total count list of lower organization.(OrgnzVO)
	 * @return int Total Count of lower organization List
	 * @exception Exception
	 */
	int searchLowOrgCnt(OrgnzVO vo) throws Exception;

	/**
	 * Retrieves Count  of District organization. <br>
	 * 
	 * @param vo Input item for retrieving list of organization(OrgnzVO).
	 * @return List Retrieve list of organization
	 * @exception Exception
	 */
	int searchDstrOrgnzCnt(OrgnzVO vo) throws Exception;
	
	/**
	 * Retrieves Count  of central organization. <br>
	 * 
	 * @param vo Input item for retrieving list of organization(OrgnzVO).
	 * @return List Retrieve list of organization
	 * @exception Exception
	 */
	int searchCtOrgnzCnt(OrgnzVO vo) throws Exception;
	
	/**
	 * Registration information of new organization. <br>
	 * 
	 * @param vo Input item for registering new organization(OrgnzVO).
	 * @return OrgnzVO Primary Key value of registered organization
	 * @exception Exception
	 */
	OrgnzVO addOrgnz(OrgnzVO vo) throws Exception;
	
	
	/**
	 * Modifies information of organization. <br>
	 * 
	 * @param vo Input item for modifying organization(OrgnzVO).
	 * @exception Exception
	 */
	void modifyOrgnz(OrgnzVO vo) throws Exception;
	
	/**
	 * Delete information of organization. <br>
	 * 
	 * @param vo Input item for modifying organization(OrgnzVO).
	 * @exception Exception
	 */
	void removeOrgnz(OrgnzVO vo) throws Exception;

	/**
	 * Retrieves list of organization. <br>
	 * 
	 * @param vo Input item for retrieving list of organization(OrgnzVO).
	 * @return List Retrieve list of organization
	 * @exception Exception
	 */
	List<OrgnzVO> searchListOrgnzAjax(OrgnzVO vo) throws Exception;
	
	/**
	 * Retrieves list of upper office. <br>
	 * 
	 * @param vo Input item for retrieving list of upper office(OrgnzVO).
	 * @return List Retrieve list of upper office
	 * @exception Exception
	 */
	List<OrgnzVO> searchListUprOfic(OrgnzVO vo) throws Exception;
	
	/**
	 * Retrieves list of office. <br>
	 * 
	 * @param vo Input item for retrieving list of office(OrgnzVO).
	 * @return List Retrieve list of office
	 * @exception Exception
	 */
	List<OrgnzVO> searchListOfic(OrgnzVO vo) throws Exception;	
		
	/**
	 * Retrieves  count of officer who have selected office code . <br>
	 * @param vo Input item for retrieving count of officer who have selected office code.(OrgnzVO)
	 * @return int count of officer who have selected office code
	 * @exception Exception
	 */
	int searchOficrCnt(OrgnzVO vo) throws Exception;	
	
	/**
	 * Retrieves list of office(tree). <br>
	 * 
	 * @param vo Input item for retrieving list of office(OrgnzVO).
	 * @return List Retrieve list of office
	 * @exception Exception
	 */
	List<OrgnzVO> searchListOrgnzCdTree(OrgnzVO vo) throws Exception;	
	
	/**
	 * Retrieves officer name. <br>	 
	 *
	 * @param vo Input item for retrieve officer name(OrgnzVO).
	 * @return List officer name
	 * @exception Exception
	 */
	public OrgnzVO searchOrgnzNm(OrgnzVO vo) throws Exception;		
}

