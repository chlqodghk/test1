package afnid.cm.code.service;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of common code -management
 * 
 * @author Afghanistan National ID Card System Application Team 
 * @since 2011.04.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers         	Revisions
 *   2011.04.21  		MH Choung         		Create
 *
 * </pre>
 */
public class CmmCdVO extends ComDefaultVO {

	private static final long serialVersionUID = 1L;
	/**COMMON CODE*/			
	private  String    cmmCd;			
    /**GROUP CODE*/			
	private  String    grpCd;			
    /**PASHTO CODE NAME*/			 
	private  String    pstCdNm;			
    /**DARI CODE NAME*/			
	private  String    drCdNm;			
    /**PASHTO CODE DESCRIPTION*/	         
	private  String    pstCdDs;			
    /**DARI CODE DESCRIPTION*/	         
	private  String    drCdDs;			
    /**PRIOR RANK NUMBER*/	         
	private  String    prorRnkNo;				
    /**DELETE YN*/	         
	private  String    dltYn;					
    /**DELETE REASON DETAIL CONTENTS*/	         
	private  String    dltRsnDtlCt;	
    /**FIRST REGISTRATION USER ID*/	         
	private  String    fstRgstUserId;	
    /**FIRST REGISTRATION DATETIME*/	         
	private  String    fstRgstDt;		
    /**LAST UPDATE USER ID*/	         
	private  String    lstUdtUserId;		
    /**LAST UPDATE DATETIME*/	         
	private  String    lstUdtDt;
	/** ENGLISH CODE NAME */
	private String enCdNm;
	 
	private String lcaCmmCdNmMaxLnth;
	private String enCmmCdNmMaxLnth;
	 
	private String pstGrpCdNm;
	private String pstGrpCdDs;
	private String drGrpCdNm;
	private String pstLnth;
	private String drLnth;
	private String enLnth;
	private String grpCdNm;
    private String sortCd;
	private String cmmCdTye; 
	private String cdSotNo; 
	
	public String getGrpCdNm() {
		return grpCdNm;
	}
	public void setGrpCdNm(String grpCdNm) {
		this.grpCdNm = grpCdNm;
	}
	public String getEnCdNm() {
		return enCdNm;
	}
	public void setEnCdNm(String enCdNm) {
		this.enCdNm = enCdNm;
	}
	public String getCmmCd() {
		return cmmCd;
	}
	public void setCmmCd(String cmmCd) {
		this.cmmCd = cmmCd;
	}
	public String getGrpCd() {
		return grpCd;
	}
	public void setGrpCd(String grpCd) {
		this.grpCd = grpCd;
	}
	public String getPstCdNm() {
		return pstCdNm;
	}
	public void setPstCdNm(String pstCdNm) {
		this.pstCdNm = pstCdNm;
	}
	public String getDrCdNm() {
		return drCdNm;
	}
	public void setDrCdNm(String drCdNm) {
		this.drCdNm = drCdNm;
	}
	public String getPstCdDs() {
		return pstCdDs;
	}
	public void setPstCdDs(String pstCdDs) {
		this.pstCdDs = pstCdDs;
	}
	public String getDrCdDs() {
		return drCdDs;
	}
	public void setDrCdDs(String drCdDs) {
		this.drCdDs = drCdDs;
	}
	public String getProrRnkNo() {
		return prorRnkNo;
	}
	public void setProrRnkNo(String prorRnkNo) {
		this.prorRnkNo = prorRnkNo;
	}
	public String getDltYn() {
		return dltYn;
	}
	public void setDltYn(String dltYn) {
		this.dltYn = dltYn;
	}
	public String getDltRsnDtlCt() {
		return dltRsnDtlCt;
	}
	public void setDltRsnDtlCt(String dltRsnDtlCt) {
		this.dltRsnDtlCt = dltRsnDtlCt;
	}
	public String getFstRgstUserId() {
		return fstRgstUserId;
	}
	public void setFstRgstUserId(String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}
	public String getFstRgstDt() {
		return fstRgstDt;
	}
	public void setFstRgstDt(String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}
	public String getLstUdtUserId() {
		return lstUdtUserId;
	}
	public void setLstUdtUserId(String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}
	public String getLstUdtDt() {
		return lstUdtDt;
	}
	public void setLstUdtDt(String lstUdtDt) {
		this.lstUdtDt = lstUdtDt;
	}
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	public String getLcaCmmCdNmMaxLnth() {
		return lcaCmmCdNmMaxLnth;
	}
	public void setLcaCmmCdNmMaxLnth(String lcaCmmCdNmMaxLnth) {
		this.lcaCmmCdNmMaxLnth = lcaCmmCdNmMaxLnth;
	}
	public String getEnCmmCdNmMaxLnth() {
		return enCmmCdNmMaxLnth;
	}
	public void setEnCmmCdNmMaxLnth(String enCmmCdNmMaxLnth) {
		this.enCmmCdNmMaxLnth = enCmmCdNmMaxLnth;
	}
	public String getPstGrpCdNm() {
		return pstGrpCdNm;
	}
	public void setPstGrpCdNm(String pstGrpCdNm) {
		this.pstGrpCdNm = pstGrpCdNm;
	}
	public String getPstGrpCdDs() {
		return pstGrpCdDs;
	}
	public void setPstGrpCdDs(String pstGrpCdDs) {
		this.pstGrpCdDs = pstGrpCdDs;
	}
	public String getDrGrpCdNm() {
		return drGrpCdNm;
	}
	public void setDrGrpCdNm(String drGrpCdNm) {
		this.drGrpCdNm = drGrpCdNm;
	}
	public String getPstLnth() {
		return pstLnth;
	}
	public void setPstLnth(String pstLnth) {
		this.pstLnth = pstLnth;
	}
	public String getDrLnth() {
		return drLnth;
	}
	public void setDrLnth(String drLnth) {
		this.drLnth = drLnth;
	}
	public String getEnLnth() {
		return enLnth;
	}
	public void setEnLnth(String enLnth) {
		this.enLnth = enLnth;
	}
	public String getSortCd() {
		return sortCd;
	}
	public void setSortCd(String sortCd) {
		this.sortCd = sortCd;
	}
	public String getCmmCdTye() {
		return cmmCdTye;
	}
	public void setCmmCdTye(String cmmCdTye) {
		this.cmmCdTye = cmmCdTye;
	}
	public String getCdSotNo() {
		return cdSotNo;
	}
	public void setCdSotNo(String cdSotNo) {
		this.cdSotNo = cdSotNo;
	}
  
}