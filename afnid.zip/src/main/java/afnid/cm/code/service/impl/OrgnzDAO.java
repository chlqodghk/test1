package afnid.cm.code.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import afnid.cm.code.service.OrgnzVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/** 
 * This class is Database Access Object of organization.
 * 
 * @author Afghanistan National ID Card System Application Team Eun Hee Kim
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2011.05.17 		Eun Hee Kim	      		 		Create
 *
 * </pre>
 */
@Repository("orgnzDAO")
public class OrgnzDAO extends EgovAbstractDAO{
	
	/**
	 * DAO-method for retrieving list Information of organization. <br>
	 * 
	 * @param vo Input item for retrieving list information of organization(OrgnzVO).
	 * @return OrgnzVO Retrieve list information of organization
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")	
	public List<OrgnzVO> selectListOrgnz(OrgnzVO vo) throws Exception{
		return list("orgInfoDAO.selectListOrgnz", vo);
	}
	
	/**
	 * DAO-method for retrieving total count list of organization. <br>
	 * 
	 * @param vo Input item for retrieving list of organization(OrgnzVO).
	 * @return int Total Count of organization List
	 * @exception Exception
	 */
    public int selectListOrgnzTotCnt(OrgnzVO vo) {
        return (Integer)selectByPk("orgInfoDAO.selectListOrgnzTotCnt", vo);
    }
    
    /**
	 * DAO-method for retrieving detail Information of organization. <br>
	 * 
	 * @param vo Input item for retrieving detail information of organization(OrgInfoVO).
	 * @return OrgInfoVO Retrieve detail information of organization
	 * @exception Exception
	 */
	public OrgnzVO selectOrgnz(OrgnzVO vo)throws Exception{
		return (OrgnzVO)selectByPk("orgInfoDAO.selectOrgnz", vo); 
	}
    	

    /**
	 * DAO-method for retrieving total count list of lower organization. <br>
	 * 
	 * @param vo Input item for retrieving list of lower organization(OrgnzVO).
	 * @return int Total Count of lower organization List
	 * @exception Exception
	 */
    public int selectLowOrgCnt(OrgnzVO vo) {
        return (Integer)selectByPk("orgInfoDAO.selectLowOrgCnt", vo);
    }
    
    
	/**
	 * DAO-method for retrieves Count  of District organization <br>
	 * 
	 * @param vo Input item for retrieving list of organization(OrgnzVO).
	 * @return int Total Count of organization List
	 * @exception Exception
	 */
    public int selectDstrOrgnzCnt(OrgnzVO vo) {
        return (Integer)selectByPk("orgInfoDAO.selectDstrOrgnzCnt", vo);
    }
    
	/**
	 * DAO-method for retrieves Count  of central organization <br>
	 * 
	 * @param vo Input item for retrieving list of organization(OrgnzVO).
	 * @return int Total Count of organization List
	 * @exception Exception
	 */
    public int selectCtOrgnzCnt(OrgnzVO vo) {
        return (Integer)selectByPk("orgInfoDAO.selectCtOrgnzCnt", vo);
    }
    
	/**
	 * DAO-method for registering information of new organization. <br>
	 * 
	 * @param vo Input item for registering new organization(OrgnzVO).
	 * @return OrgnzVO Primary Key value of registered organization
	 * @exception Exception
	 */
	public void insertOrgnz(OrgnzVO vo){
		insert("orgInfoDAO.insertOrgnz", vo);
	}

	/**
	 * DAO-method for modifying information of authorganizationor. <br>
	 * 
	 * @param vo Input item for modifying organization(OrgInfoVO).
	 * @exception Exception
	 */
	public void updateOrgnz(OrgnzVO vo){
		update("orgInfoDAO.updateOrgnz", vo);
	}
	
	/**
	 * DAO-method for deleting information of organization. <br>
	 * 
	 * @param vo Input item for deleting organization(OrgInfoVO).
	 * @exception Exception
	 */
	public void deleteOrgnz(OrgnzVO vo){
		delete("orgInfoDAO.deleteOrgnz", vo);
	}


	/**
	 * DAO-method for retrieving list of organization. <br>
	 * 
	 * @param vo Input item for retrieving information of user(UserMngVO).
	 * @return OrgnzVO Retrieve list of organization
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<OrgnzVO> selectListOrgAjx(OrgnzVO vo) throws Exception{
		return list("orgInfoDAO.selectListOrgAjx", vo);
	}	
	
	
	/**
	 * DAO-method for retrieving list of upper office. <br>
	 * 
	 * @param vo Input item for retrieving upper office(UserMngVO).
	 * @return OrgnzVO Retrieve list of upper office
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<OrgnzVO> selectListUprOfic(OrgnzVO vo) throws Exception{
		return list("orgInfoDAO.selectListUprOfic", vo);
	}
	
	/**
	 * DAO-method for retrieving list of office. <br>
	 * 
	 * @param vo Input item for retrieving office(UserMngVO).
	 * @return OrgnzVO Retrieve list of office
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<OrgnzVO> selectListOfic(OrgnzVO vo) throws Exception{
		return list("orgInfoDAO.selectListOfic", vo);
	}
	
    /**
	 * DAO-method for retrieving count of officer who have selected office code. <br>
	 * 
	 * @param vo Input item for retrieving count of officer who have selected office code(OrgInfoVO).
	 * @return int count of officer who have selected office code
	 * @exception Exception
	 */
    public int selectOficrCnt(OrgnzVO vo) {
        return (Integer)selectByPk("orgInfoDAO.selectOficrCnt", vo);
    }	
    
	/**
	 * DAO-method for retrieving list of office(tree). <br>
	 * 
	 * @param vo Input item for retrieving office(UserMngVO).
	 * @return OrgnzVO Retrieve list of office
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<OrgnzVO> selectListOrgnzCdTree(OrgnzVO vo) throws Exception{
		return list("orgInfoDAO.selectListOrgnzCdTree", vo);
	}   
	
	/**
	 * DAO-method for retrieving office name. <br>
	 * 
	 * @param vo Input item for retrieving office name(OrgnzVO).
	 * @return OrgnzVO office name
	 * @exception Exception
	 */
	public OrgnzVO selectOrgnzNm(OrgnzVO vo) throws Exception{			
		return (OrgnzVO)selectByPk("orgInfoDAO.selectOrgnzNm", vo);
	}
	
}
