package afnid.cm.uat.service;

import java.util.List;


/** 
 * This class is Value Object of login-management
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.05.17  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */
public class LgnVO {
	
	private String cert;
	
	/** Log user number */
	private String userSeqNo;
	
	
	/** Log ID */
	private String lgId;
	
	/** UserID  */
	private String userId;
	private String userId1;
	private String userId2;
	private String userId3;
	/** UserPassword */
	private String pwd;
	
	/** Pst Username*/
	private String pstUserNm;
	
	/** Dr Username */
	private String drUserNm;
	
	/** NID Number */
	private String rsdtNo;
	
	/** Organization code */
	private String orgnzCd;
	
	/** pst Organization name*/
	private String pstOrgnzNm;
	
	/** Dr Organization name*/
	private String drOrgnzNm;
	
	/** En Organization name */
	private String enOrgnzNm;	
	
	/** Sign up status codes */
	private String useStusCd;
	
	/** Title Code */
	private String ofcalPsnCd;
	
	/** Pst Title name */
	private String pstOfcalPsnNm;
	
	/**Dr Title name*/
	private String drOfcalPsnNm;
		
	/**en Title name */
	private String enOfcalPsnNm;	

	
	/** Language code */
	private String useLangCd;
	
	/** Date of retirement */
	private String rtreDd;
	
	/** User current system*/
	private String curSystemCd;
	
	/** User Login Location */
	private String userLc;
	
	/** User Error YN */
	private String erorYn;
	
	/** Language */
	private String language;
	
	/** Authority List */
	private List<String> athorList;
	
	/** Main Menu ID */
	private String mainMnId;
	
	/** Make Query */
	private List<String> makeQuery;
	
	private String nm;
	private String tamCd;
	private String tamCdNm;
	
	private String lgnFailCn;
	
	private String chgPwdDd;
	private String chgPwdYn;
	
	private String pwdMonGab;
	
	private String pwdMonYn;
	
	private String adminTelNo;
	
	
	
	private String orgnzClsCd;
	private String pstOrgnzClsCdNm;
	private String drOrgnzClsCdNm;
	private String enOrgnzClsCdNm;
	private String ipAd;	
	private String enLgnYn;
	private String nticYn;
	
	private String hstSeqNo;
	
	public String getTamCd() {
		return tamCd;
	}
	public void setTamCd(String tamCd) {
		this.tamCd = tamCd;
	}
	public String getTamCdNm() {
		return tamCdNm;
	}
	public void setTamCdNm(String tamCdNm) {
		this.tamCdNm = tamCdNm;
	}
	
	public List<String> getMakeQuery() {
		return makeQuery;
	}
	public void setMakeQuery(List<String> makeQuery) {
		this.makeQuery = makeQuery;
	}
	public String getMainMnId() {
		return mainMnId;
	}
	public void setMainMnId(String mainMnId) {
		this.mainMnId = mainMnId;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getErorYn() {
		return erorYn;
	}
	public void setErorYn(String erorYn) {
		this.erorYn = erorYn;
	}
	public String getUserLc() {
		return userLc;
	}
	public void setUserLc(String userLc) {
		this.userLc = userLc;
	}
	public String getLgId() {
		return lgId;
	}
	public void setLgId(String lgId) {
		this.lgId = lgId;
	}
	/** System Current Date */
	private String curDate;
	
	public String getCurDate() {
		return curDate;
	}
	public void setCurDate(String curDate) {
		this.curDate = curDate;
	}
	public String getCurSystemCd() {
		return curSystemCd;
	}
	public void setCurSystemCd(String curSystemCd) {
		this.curSystemCd = curSystemCd;
	}
	/** Log the error code */
	private String lgnErorCd;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getPstUserNm() {
		return pstUserNm;
	}
	public void setPstUserNm(String pstUserNm) {
		this.pstUserNm = pstUserNm;
	}
	public String getDrUserNm() {
		return drUserNm;
	}
	public void setDrUserNm(String drUserNm) {
		this.drUserNm = drUserNm;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String getPstOrgnzNm() {
		return pstOrgnzNm;
	}
	public void setPstOrgnzNm(String pstOrgnzNm) {
		this.pstOrgnzNm = pstOrgnzNm;
	}
	public String getDrOrgnzNm() {
		return drOrgnzNm;
	}
	public void setDrOrgnzNm(String drOrgnzNm) {
		this.drOrgnzNm = drOrgnzNm;
	}
	public String getOfcalPsnCd() {
		return ofcalPsnCd;
	}
	public void setOfcalPsnCd(String ofcalPsnCd) {
		this.ofcalPsnCd = ofcalPsnCd;
	}
	public String getPstOfcalPsnNm() {
		return pstOfcalPsnNm;
	}
	public void setPstOfcalPsnNm(String pstOfcalPsnNm) {
		this.pstOfcalPsnNm = pstOfcalPsnNm;
	}
	public String getDrOfcalPsnNm() {
		return drOfcalPsnNm;
	}
	public void setDrOfcalPsnNm(String drOfcalPsnNm) {
		this.drOfcalPsnNm = drOfcalPsnNm;
	}

	public String getUseLangCd() {
		return useLangCd;
	}
	public void setUseLangCd(String useLangCd) {
		this.useLangCd = useLangCd;
	}

	public String getRtreDd() {
		return rtreDd;
	}
	public void setRtreDd(String rtreDd) {
		this.rtreDd = rtreDd;
	}
	public String getLgnErorCd() {
		return lgnErorCd;
	}
	public void setLgnErorCd(String lgnErorCd) {
		this.lgnErorCd = lgnErorCd;
	}
	public String getUseStusCd() {
		return useStusCd;
	}
	public void setUseStusCd(String useStusCd) {
		this.useStusCd = useStusCd;
	}
	public List<String> getAthorList() {
		return athorList;
	}
	public void setAthorList(List<String> athorList) {
		this.athorList = athorList;
	}
	public String getNm() {
		return nm;
	}
	public void setNm(String nm) {
		this.nm = nm;
	}

	public String getLgnFailCn() {
		return lgnFailCn;
	}
	public void setLgnFailCn(String lgnFailCn) {
		this.lgnFailCn = lgnFailCn;
	}
	public String getChgPwdDd() {
		return chgPwdDd;
	}
	public void setChgPwdDd(String chgPwdDd) {
		this.chgPwdDd = chgPwdDd;
	}
	public String getChgPwdYn() {
		return chgPwdYn;
	}
	public void setChgPwdYn(String chgPwdYn) {
		this.chgPwdYn = chgPwdYn;
	}
	public String getPwdMonGab() {
		return pwdMonGab;
	}
	public void setPwdMonGab(String pwdMonGab) {
		this.pwdMonGab = pwdMonGab;
	}
	public String getPwdMonYn() {
		return pwdMonYn;
	}
	public void setPwdMonYn(String pwdMonYn) {
		this.pwdMonYn = pwdMonYn;
	}
	public String getUserId1() {
		return userId1;
	}
	public void setUserId1(String userId1) {
		this.userId1 = userId1;
	}
	public String getUserId2() {
		return userId2;
	}
	public void setUserId2(String userId2) {
		this.userId2 = userId2;
	}
	public String getUserId3() {
		return userId3;
	}
	public void setUserId3(String userId3) {
		this.userId3 = userId3;
	}
	public String getEnOrgnzNm() {
		return enOrgnzNm;
	}
	public void setEnOrgnzNm(String enOrgnzNm) {
		this.enOrgnzNm = enOrgnzNm;
	}
	public String getEnOfcalPsnNm() {
		return enOfcalPsnNm;
	}
	public void setEnOfcalPsnNm(String enOfcalPsnNm) {
		this.enOfcalPsnNm = enOfcalPsnNm;
	}

	public String getAdminTelNo() {
		return adminTelNo;
	}
	public void setAdminTelNo(String adminTelNo) {
		this.adminTelNo = adminTelNo;
	}
	public String getUserSeqNo() {
		return userSeqNo;
	}
	public void setUserSeqNo(String userSeqNo) {
		this.userSeqNo = userSeqNo;
	}
	public String getOrgnzClsCd() {
		return orgnzClsCd;
	}
	public void setOrgnzClsCd(String orgnzClsCd) {
		this.orgnzClsCd = orgnzClsCd;
	}
	public String getPstOrgnzClsCdNm() {
		return pstOrgnzClsCdNm;
	}
	public void setPstOrgnzClsCdNm(String pstOrgnzClsCdNm) {
		this.pstOrgnzClsCdNm = pstOrgnzClsCdNm;
	}
	public String getDrOrgnzClsCdNm() {
		return drOrgnzClsCdNm;
	}
	public void setDrOrgnzClsCdNm(String drOrgnzClsCdNm) {
		this.drOrgnzClsCdNm = drOrgnzClsCdNm;
	}
	public String getEnOrgnzClsCdNm() {
		return enOrgnzClsCdNm;
	}
	public void setEnOrgnzClsCdNm(String enOrgnzClsCdNm) {
		this.enOrgnzClsCdNm = enOrgnzClsCdNm;
	}
	public String getIpAd() {
		return ipAd;
	}
	public void setIpAd(String ipAd) {
		this.ipAd = ipAd;
	}
	public String getEnLgnYn() {
		return enLgnYn;
	}
	public void setEnLgnYn(String enLgnYn) {
		this.enLgnYn = enLgnYn;
	}
	public String getNticYn() {
		return nticYn;
	}
	public void setNticYn(String nticYn) {
		this.nticYn = nticYn;
	}
	public String getCert() {
		return cert;
	}
	public void setCert(String cert) {
		this.cert = cert;
	}
	public String getHstSeqNo() {
		return hstSeqNo;
	}
	public void setHstSeqNo(String hstSeqNo) {
		this.hstSeqNo = hstSeqNo;
	}
	
	
}
