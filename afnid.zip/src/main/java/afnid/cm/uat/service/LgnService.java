package afnid.cm.uat.service;

import javax.servlet.http.HttpServletRequest;

import afnid.cm.mms.service.MainMnMngVO;

/** 
 * This service interface is biz-class of login-management. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2011.05.17  		Kyung Hwan HWANG				Create
 *
 * </pre>
 */
public interface LgnService {
	
	/**
	 * Process login in to NID system .  <br>
	 * 
	 * @param vo Input item for validating user id and user password.(LgnVO).
	 * @return LgnVO Result validating user id and user password.
	 * @exception Exception
	 */
    LgnVO actionLgn(LgnVO vo, HttpServletRequest req) throws Exception;
    
    /**
	 * Register login information of user. <br>
	 * 
	 * @param vo Input item for registering login log(LgnVO).
	 * @exception Exception
	 */
    void addLgnLog(LgnVO vo) throws Exception;
    
    /**
	 * Retrieve information of main menu. <br>
	 * 
	 * @param vo Input item for registering login log(LgnVO).
	 * @exception Exception
	 */
    MainMnMngVO searchMainPage(LgnVO vo) throws Exception;

   
    /**
	 * 비밀번호를 찾는다.
	 * @param vo LoginVO
	 * @return LoginVO
	 * @exception Exc
	 * @param vo LoginVO
	 * @return boolean
	 * @exception Exception
	 */
    boolean searchPassword(LgnVO vo) throws Exception;
 
    /**
	 * update user password. <br>
	 * 
	 * @param vo Input item for registering login log(LoginVO).
	 * @exception Exception
	 */
    void updateUserPwd(LgnVO vo) throws Exception;  
    
}
