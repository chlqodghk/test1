package afnid.cm.uat.service.impl;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import afnid.cm.mms.service.MainMnMngVO;
import afnid.cm.uat.service.LgnVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
/** 
 * This class is Database Access Object of login-management
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.05.17  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */
@Repository("lgnDAO")
public class LgnDAO extends EgovAbstractDAO {
	
	/** log */
    protected static final Log LOG = LogFactory.getLog(LgnDAO.class);
    
    /**
	 * DAO-method for processing login in to NID system . <br>
	 * 
	 * @param vo Input item for validating user id and user password.(LgnVO).
	 * @return LgnVO Result validating user id and user password.
	 * @exception Exception
	 */
    public LgnVO actionLgn(LgnVO vo) throws Exception {
    	return (LgnVO)selectByPk("lgnDAO.actionLgn", vo);
    }
    
    /**
	 * DAO-method for registering login information of user. <br>
	 * 
	 * @param vo Input item for registering login log(LgnVO).
	 * @exception Exception
	 */
    public void insertLgnLog(LgnVO vo) throws Exception {
    	insert("lgnDAO.insertLgnLog", vo);
    }
    
    /**
	 * DAO-method for retrieving information of main menu. <br>
	 * 
	 * @param vo Input item for registering login log(LgnVO).
	 * @exception Exception
	 */
    public MainMnMngVO selectMainPage(LgnVO vo) throws Exception {
    	MainMnMngVO main = (MainMnMngVO)selectByPk("lgnDAO.selectMainPage", vo);
    	
    	String mainUserSeqNo = (String)selectByPk("lgnDAO.selectUserMainAthr", vo);
    		    
    	if(mainUserSeqNo != null && "3".equals(mainUserSeqNo)){
    		String mainMnId = vo.getMainMnId();
        	// Team Leader Verification List on login to connect to the hard-coded entry
        	vo.setMainMnId("30");
        	main = (MainMnMngVO)selectByPk("lgnDAO.selectMainPage", vo);
        	main.setPageUrl("/rm/rsdt/searchListRsdtRgstInfrAprvView.do");
        	main.setReqPgmId("94");
        	main.setSubMnId("30");
        	//Change the value of the past mainMnId
        	vo.setMainMnId(mainMnId);
    	}
    	return main;
    }

    /**
	 * DAO-method for upda. <br>
	 * 
	 * @param vo Input item for validating user id and user password.(LgnVO).
	 * @return LoginVO Result validating user id and user password.
	 * @exception Exception
	 */
    public int updateLgnErorCn(LgnVO vo) throws Exception {
    	return update("lgnDAO.updateLgnErorCn", vo);
    }
    
    /**
	 * DAO-method for get password. <br>
	 * @param vo Input item for get password(LoginVO).
	 * @return List
	 * @exception Exception
	 */  
	@SuppressWarnings("unchecked")	    
    public List<LgnVO> searchPassword(LgnVO vo) throws Exception {    	
    	return list ("lgnDAO.searchPassword", vo);
    }
	
	/**
	 * DAO-method for registering information of new user history. <br>
	 * 
	 * @param vo Input item for registering new user history(LoginVO).
	 * @exception Exception
	 */	
    public String insertUserHst(LgnVO vo) throws Exception {
		String hstSeqNo = (String)insert("lgnDAO.insertUserHst", vo);
		return hstSeqNo;    	
    }    
    
	/**
	 * DAO-method for registering information of user role history. <br>
	 * 
	 * @param vo Input item for registering user role history(LgnVO).
	 * @exception Exception
	 */
	public void insertUserAthrHst(LgnVO vo)throws Exception{
		insert("lgnDAO.insertUserAthrHst", vo);
	}
	
	/**
	 * DAO-method for update user password. <br>
	 * 
	 * @param vo Input item for update user password(LgnVO).
	 * @exception Exception
	 */
    public void updateUserPwd(LgnVO vo) throws Exception {
    	update("lgnDAO.updateUserPwd", vo);
    }
     
    
}
