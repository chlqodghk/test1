package afnid.cm.uat.service.impl;

import java.security.cert.X509Certificate;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import si.osi.pki.officer.OfficerCertLogin;
import afnid.cm.mms.service.MainMnMngVO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnService;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidFileScrty;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;

/** 
 * This service class is biz-class of login-management
 * and implements NidLoginService class.
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.05.17  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */
@Service("lgnService")
public class LgnServiceImpl extends AbstractServiceImpl implements LgnService {
	
    @Resource(name="lgnDAO")
    private LgnDAO lgnDAO;

    /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
	/**
	 * Biz-method for processing login in to NID system . <br>
	 * 
	 * @param vo Input item for validating user id and user password.(LgnVO).
	 * @return LgnVO Result validating user id and user password.
	 * @exception Exception
	 */
    public int  errLogin = 0;
    
    public LgnVO actionLgn(LgnVO vo, HttpServletRequest req) throws Exception {
		LgnVO lgnVO = lgnDAO.actionLgn(vo);
		int cnt= 0; 
	   	if(lgnVO != null) {
	   	
			if(!"pwd".equals(propertiesService.getString("lgnPlcy"))){
	    		//pki card check.
				X509Certificate[] certificate = (X509Certificate []) req.getAttribute("javax.servlet.request.X509Certificate");
	    		if(certificate == null){
	    			lgnVO = new LgnVO();
	    			lgnVO.setUserId(vo.getUserId());
	    			lgnVO.setLgnErorCd("7"); //certificate is null
	    			lgnVO.setLgnFailCn("0");
	    			return lgnVO;  			
	    		}
	    		
	    		if (certificate != null){

	    			String result = OfficerCertLogin.Instance.doCertVerify(certificate[0]);
	    			if(result != null && result.length() > 0){
	    				String [] cert = result.split("\\:");

	    				if(cert[0] != null && "0".equals(cert[0])){
	    					if(!lgnVO.getUserId().equals(cert[1])){
	    						lgnVO.setLgnErorCd("6");
	    						return lgnVO;
	    					}
	    				} else {
	    					throw processException("pki.msg."+cert[0]);			    					
	    				}
	    			}
	    		} 
			} 	
			
	   		cnt = Integer.parseInt(lgnVO.getLgnFailCn());    	  
	    	if (cnt> 4){ 
	    		lgnVO.setLgnErorCd("2");
	    		return lgnVO;
	    	}	
            if(lgnVO.getUseStusCd() != null &&   "2".equals(lgnVO.getUseStusCd())) { //not available
    			lgnVO.setLgnErorCd("3");    			
    			vo.setLgnFailCn(String.valueOf(cnt + 1));
    		} else if(lgnVO.getUseStusCd() != null && "3".equals(lgnVO.getUseStusCd())) { //Retirement
    			lgnVO.setLgnErorCd("4");	      			
    			vo.setLgnFailCn(String.valueOf(cnt + 1));	
    		} else if(lgnVO.getEnLgnYn() != null &&  "N".equals(lgnVO.getEnLgnYn()) && "3".equals(vo.getUseLangCd())  ) { //english login
    			lgnVO.setLgnErorCd("5");	      			
    			vo.setLgnFailCn("0");
    		} else {//login success   
    			lgnVO.setLgnErorCd("0");
    			vo.setLgnFailCn("0");
    		}
            
    		if(!"pki".equals(propertiesService.getString("lgnPlcy"))){
    			String enpassword = NidFileScrty.encryptPassword(vo.getPwd().toLowerCase());
        		if( lgnVO.getPwd() != null && !enpassword.equals(lgnVO.getPwd()) ) { //invalid password
        			lgnVO.setLgnErorCd("2");
        			vo.setLgnFailCn(String.valueOf(cnt + 1));
        		}    			
    		}
    		errLogin = lgnDAO.updateLgnErorCn(vo);//update fail count
    	} else { //userID not exist     		
    		lgnVO = new LgnVO();
    		lgnVO.setLgnFailCn(String.valueOf(cnt));
    		lgnVO.setUserId(vo.getUserId());
    		lgnVO.setLgnErorCd("1");
    		lgnVO.setLgnFailCn("0");
    	}
    	return lgnVO;
    }
    
    /**
	 * Biz-method for registering login information of user. <br>
	 * 
	 * @param vo Input item for registering login log(LgnVO).
	 * @exception Exception
	 */
    public void addLgnLog(LgnVO vo) throws Exception {
    	lgnDAO.insertLgnLog(vo);
    }
    
    /**
	 * Biz-method for retrieving information of main menu. <br>
	 * 
	 * @param vo Input item for registering login log(LgnVO).
	 * @exception Exception
	 */
    public MainMnMngVO searchMainPage(LgnVO vo) throws Exception {
    	
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUserId(user.getUserId());
		vo.setUserSeqNo(user.getUserSeqNo());
		
    	return lgnDAO.selectMainPage(vo);
    }

 
    /**
	 * get password
	 * @param vo LoginVO
	 * @return boolean
	 * @exception Exception
	 */
    public boolean searchPassword(LgnVO vo) throws Exception {
    	    	
    	List <LgnVO> lst= lgnDAO.searchPassword(vo);
    	
    	
    	if (lst == null || lst.isEmpty() ) {
    				return false;
    	}

    	return true;

    }
    
    /**
	 * Biz-method for user password update. <br>
	 * 
	 * @param vo Input item for registering login log(LoginVO).
	 * @exception Exception
	 */
    public void updateUserPwd(LgnVO vo) throws Exception {
		//insert history
		String hstSeqNo = lgnDAO.insertUserHst(vo);
		vo.setHstSeqNo(hstSeqNo);		
		lgnDAO.insertUserAthrHst(vo);    	
		
    	lgnDAO.updateUserPwd(vo);  	
    }
    
   

}
