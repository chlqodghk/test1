package afnid.cm.uat.web;

import java.security.cert.X509Certificate;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.Authentication;
import org.springframework.security.context.SecurityContext;
import org.springframework.security.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ibm.icu.util.Calendar;

import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.error.ErrorHandler;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.mms.service.MainMnMngVO;
import afnid.cm.sec.security.NidUserDetails;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnService;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidClntInfo;
import afnid.cm.util.service.NidFileScrty;
import afnid.cm.util.service.NidNoUtil;
import egovframework.rte.fdl.property.EgovPropertyService;

/** 
 * This Controller class processes request of login-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Kyung Hwan HWANG
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.05.17  		Kyung Hwan HWANG         		Create
 *
 * </pre>
 */

@Controller
public class LgnController {

    /** NidLoginService */
	@Resource(name = "lgnService")
    private LgnService lgnService;
	
	/** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** EgovPropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
	/** log */
    protected Log log = LogFactory.getLog(this.getClass());
	/**
	 * Goes to the login screen
	 * @param vo - Containing the URL to login LoginVO.
	 * @return Login Page
	 * @exception Exception
	 */
    @RequestMapping(value="/cm/uat/LgnUser.do")
	public String lgnUsrView(@ModelAttribute("loginVO") LgnVO lgnVO,
			@RequestParam(value="authorFail" ,required=false) String authorFail,
			ModelMap model,
			HttpServletRequest request) 
			throws Exception {
    	try{
    		
    	if(lgnVO.getLanguage() == null || lgnVO.getLanguage().equals("")){
    		HttpSession session = request.getSession(false);
    		if (session != null) {
    		    session.invalidate();
    		}
    		SecurityContextHolder.clearContext();
    		lgnVO.setUseLangCd("1");
    	}else{
    		if(lgnVO.getLanguage() != null && "ps".equals(lgnVO.getLanguage())){
    			lgnVO.setUseLangCd("1");
    		}
    	}
    	model.addAttribute("lgnVO", lgnVO);
    	
    	if(authorFail != null && authorFail.equals("1")){
    		String lang = lgnVO.getUseLangCd();
    		HttpSession session = request.getSession();
    		String nidLoginLangCd = (String)session.getAttribute("nidLoginLangCd");
    		lang = nidLoginLangCd;
    		if(lang != null){
    			if("1".equals(lang)){
    				lgnVO.setUseLangCd("1");
    			}else if("2".equals(lang)){
    				lgnVO.setUseLangCd("2");
    			}else if("3".equals(lang)){
    				lgnVO.setUseLangCd("3");
    			}else{
    				lgnVO.setUseLangCd("1");
    			}
    		}

    		model.addAttribute("message", nidMessageSource.getMessage(lang, "nWrkPrmsn.msg"));
    	}else if(authorFail != null && authorFail.equals("3")){
    		String lang = lgnVO.getUseLangCd();
    		HttpSession session = request.getSession();
    		String nidLoginLangCd = (String)session.getAttribute("nidLoginLangCd");
    		lang = nidLoginLangCd;
    		if(lang != null){
    			if("1".equals(lang)){
    				lgnVO.setUseLangCd("1");
    			}else if("2".equals(lang)){
    				lgnVO.setUseLangCd("2");
    			}else if("3".equals(lang)){
    				lgnVO.setUseLangCd("3");
    			}else{
    				lgnVO.setUseLangCd("1");
    			}
    		}
    		model.addAttribute("message", nidMessageSource.getMessage(lang, "logOutByCrdChng.msg"));
    	}
    	
    	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
		cmCmmCd.setGrpCd("22"); // Setting Group Code
		List<CmCmmCdVO> langList = cmmCdMngService.searchListNoSesonCmmCd(cmCmmCd, lgnVO.getUseLangCd()); 
		model.addAttribute("langList", langList);
    	
		
		String SystemExpiry ="";
		Calendar cal = Calendar.getInstance();

		String yy = String.valueOf(cal.get(Calendar.YEAR));
		String mm = String.valueOf(cal.get(Calendar.MONTH)+1);
		String dd = String.valueOf(cal.get(Calendar.DATE));
		
		if(mm.length() == 1){ mm = "0" + mm;}
		if(dd.length() == 1){ dd = "0" + dd;}

		SystemExpiry = yy + mm + dd;
		
		int SystemExpirys = Integer.parseInt(SystemExpiry);
		int SystemExpiryLimit = Integer.parseInt("20151130");
		if(SystemExpiryLimit < SystemExpirys){
			model.addAttribute("systemExpiryYn", "Y");
			model.addAttribute("sysExpd", "RM Application was expired on 30/11/2015.");
		} else {
			model.addAttribute("systemExpiryYn", "N");
		}
		
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("message", new ErrorHandler(e).getLoadMessage());
    	}

    	if("pki".equals(propertiesService.getString("lgnPlcy"))){
    		return "/cm/uat/PkiLgnUser";
    	} else {
    		return "/cm/uat/LgnUser";
    	}
    	
	}
    
    /**
     * Process login in to NID system .  <br>
     * 
     * @param LoginVO Value-object of user  to be parsed request(LoginVO)
     * @param request HttpServletRequesta
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/j_spring_security_check.do"
     * @exception Exception
     */
    @RequestMapping(value="/cm/uat/actionLogin.do")
    public String actionLogin(@ModelAttribute("loginVO") LgnVO lgnVO, 
    		                   HttpServletRequest request,
    		                   ModelMap model)
            throws Exception {
    	
    	String lgnPlcy = propertiesService.getString("lgnPlcy");
    	
    	try {
    		double  month = 0;    	
    		//Change user ID to  Number
    		
            CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("22"); // Setting Group Code
    		List<CmCmmCdVO> langList = cmmCdMngService.searchListNoSesonCmmCd(cmCmmCd, lgnVO.getUseLangCd()); 
    		model.addAttribute("langList", langList);
    		
    	    String aUserId = NidNoUtil.toPerConvetNum(lgnVO.getUserId());
    	    lgnVO.setUserId(aUserId);
    	    
    	    if(!lgnPlcy.equals("pki")){
	    	    if (aUserId == null || "".equals(aUserId) || lgnVO.getPwd() == null || "".equals(lgnVO.getPwd())){      	    	
	            	return "forward:/cm/uat/LgnUser.do?language=ps" ;
	    	    }
    	    } else {
	    	    if (aUserId == null || "".equals(aUserId)){      	    	
	            	return "forward:/cm/uat/LgnUser.do?language=ps" ;
	    	    }    	    	
    	    }
        	
	    	// Access IP
	    	String userIp = NidClntInfo.getClntIP(request);

	        String useLangCd = lgnVO.getUseLangCd();
	        
	        LgnVO resultVO = lgnService.actionLgn(lgnVO, request);
	        
	        resultVO.setIpAd(userIp);
	        
	        //Login Error YN
	        if(resultVO.getLgnErorCd() != null && !resultVO.getLgnErorCd().equals("0")){
	        	resultVO.setErorYn("Y");
	        }else {
	        	resultVO.setErorYn("N");
	        }
	        	        
	        // insert Login log
	        lgnService.addLgnLog(resultVO);	  

	        if (resultVO.getLgnErorCd() != null &&  "0".equals(resultVO.getLgnErorCd()) ) {//login success.
	        	HttpSession session = request.getSession(false);	    		
	        	session.setAttribute("nidLoginLangCd", lgnVO.getUseLangCd());
	        	session.setAttribute("lgnPlcy.afnid", lgnPlcy);
	        	
	        	if(!lgnPlcy.equals("pki")){
		        	if( "N".equals(resultVO.getChgPwdYn()) ){//first password change
		        		 model.addAttribute("lgnVO", lgnVO);
		        		 return "/cm/uat/PwdChngFst";
		        		 
		        	} else {
		        		 
		        		int pwdChngeMnth = propertiesService.getInt("pwdChngeMnth");	        		
		        		month = Double.parseDouble(resultVO.getPwdMonGab());
		        		if (month > pwdChngeMnth){ 
		        			lgnVO.setPwdMonYn("Y");
		        			model.addAttribute("lgnVO", lgnVO);
		        			return "/cm/uat/PwdChngFst";
		        		}		        		 
		        	}	        		
	        	}
	        	
	        	return "redirect:/j_spring_security_check.do?j_username="  + resultVO.getUserId() ;
	        
	        } else {//login fail
	        	int cnt =Integer.parseInt(resultVO.getLgnFailCn())+1;
	        	
                String sCnt="";
                
                if ("3".equals(lgnVO.getUseLangCd())){
                	
             	   if (cnt == 1){ 
            		   sCnt = String.valueOf("(1st).");
                   } else if(cnt == 2) {
                	   sCnt = String.valueOf("(2st).");
                   } else if(cnt == 3){
                	   sCnt = String.valueOf("(3st).");
                   } else if(cnt == 4){
                	   sCnt = String.valueOf("(4st).");
                   }else if (cnt == 5){
                	   sCnt = String.valueOf("(5st).");
                   } else {
                	   sCnt = String.valueOf(".");
                   }
                } else {
              	   
              	   if (cnt == 1){ 
             		   sCnt = String.valueOf("( ۱st ).");
                    } else if(cnt == 2) {
                 	   sCnt = String.valueOf("( ۲st ).");
                    } else if(cnt == 3){
                 	   sCnt = String.valueOf("( ۳st ).");
                    } else if(cnt == 4){
                 	   sCnt = String.valueOf("( ۴st ).");
                    }else if (cnt == 5){
                 	   sCnt = String.valueOf("( ۵st ).");
                    } else {
                 	   sCnt = String.valueOf("."); 
                    }                 	
                } 
                	
                if( "1".equals(resultVO.getLgnErorCd()) ) {//userID not exist
	            	model.addAttribute("message", nidMessageSource.getMessage(useLangCd, "lgnEror1.msg"));              	
                } else if(  "2".equals(resultVO.getLgnErorCd()) ) {//password fail
		        	if( cnt == 1 || cnt == 2 ){       	
			        	model.addAttribute("message", sCnt + " " +nidMessageSource.getMessage(useLangCd, "lgnEror2.msg") );			        		
			        } else if( cnt == 3 ){//Login error 3th
				       	model.addAttribute("message", nidMessageSource.getMessage(useLangCd, "lgnEror7.msg"));	
			        } else if( cnt == 4 ){//Login error 4th
				       	model.addAttribute("message", nidMessageSource.getMessage(useLangCd, "lgnEror8.msg"));	       		
			        } else if ( cnt >=  5 ) {//Login error 5th			    
		        		model.addAttribute("message", "( " + nidMessageSource.getMessage(useLangCd, "admTelNo") + " ) " + nidMessageSource.getMessage(useLangCd, "lgnEror6.msg")  );        			        		
			        } else {
			        	model.addAttribute("message", nidMessageSource.getMessage(useLangCd, "lgnEror5.msg"));  		        		
			        } 		        	 
	            } else if( "3".equals(resultVO.getLgnErorCd()) ) {//onHold
	        		model.addAttribute("message", nidMessageSource.getMessage(useLangCd, "lgnEror3.msg"));
	            } else if( "4".equals(resultVO.getLgnErorCd()) ) {//retirement
	        		model.addAttribute("message", nidMessageSource.getMessage(useLangCd, "lgnEror4.msg"));
	            } else if( "5".equals(resultVO.getLgnErorCd()) ) {// English login	            	 
		        	model.addAttribute("message", nidMessageSource.getMessage(lgnVO.getUseLangCd(), "lgnEror9.msg"));
		        	lgnVO.setUseLangCd("ps");
		        	model.addAttribute("lgnVO", lgnVO);
		        	return "forward:/cm/uat/LgnUser.do?language=ps";  	
	            } else if( "6".equals(resultVO.getLgnErorCd()) ) {//           	 
		        	model.addAttribute("message", nidMessageSource.getMessage(lgnVO.getUseLangCd(), "userPkiIdEror.msg"));
	            } else if( "7".equals(resultVO.getLgnErorCd()) ) {//           	 
		        	model.addAttribute("message", nidMessageSource.getMessage(lgnVO.getUseLangCd(), "pkiReadFail.msg"));		        	
	        	} else {
        			model.addAttribute("message", nidMessageSource.getMessage(useLangCd, "lgnEror5.msg"));	     		        		
	        	} 
	        }
			
        } catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("message", new NidEcptMsgHndlr().exceptionProcess(lgnVO.getUseLangCd(),e, nidMessageSource));
    	}
        
    	model.addAttribute("lgnVO", lgnVO);    	
    	
    	if("pki".equals(propertiesService.getString("lgnPlcy"))){
    		return "/cm/uat/PkiLgnUser";
    	} else {
    		return "/cm/uat/LgnUser";
    	}
    	
    }    
   
    
    /**
     * Process login in to NID system and move to notice screen.  <br>
     * 
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/NidMainView.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/cm/uat/actionMain.do")
	public String actionMain(
			HttpServletRequest request,
			ModelMap model) 
			throws Exception {
    	String main_page = ""; 
    	String language = "";
    	try {
    		HttpSession session = request.getSession();
    		String nidLoginLangCd = (String)session.getAttribute("nidLoginLangCd");
    		NidUserDetailsHelper.changeUserLangSet(nidLoginLangCd);
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		if(!"pwd".equals(propertiesService.getString("lgnPlcy"))){
	    		if(request != null){
	    			X509Certificate[] certificate = (X509Certificate []) request.getAttribute("javax.servlet.request.X509Certificate");
	    			if(certificate != null){
	        			if(certificate[0] != null && certificate[0].getSubjectDN() != null && certificate[0].getSubjectDN().getName() != null){
	        				if(!"".equals(certificate[0].getSubjectDN().getName()) && user != null && user.getCert() != null && "".equals(user.getCert())){
	        					SecurityContext context = SecurityContextHolder.getContext();
	                			Authentication authentication = context.getAuthentication();
	                			NidUserDetails details = (NidUserDetails) authentication.getPrincipal();
	                			LgnVO usercert = (LgnVO)details.getEgovUserVO();
	                			usercert.setCert(certificate[0].getSubjectDN().getName());
	                			details.setEgovUserVO(usercert);
	        				}
	        			}
	    			}
	    		}
    		}
	    	
	    	List<String> lstAthr = NidUserDetailsHelper.getAuthorities();
	    	// Login User privilege
	    	user.setAthorList(lstAthr);
	    	if(user.getUseLangCd().equals("1")) // System User Language Code가 Pashto
	    		language = "PS";
	    	else if(user.getUseLangCd().equals("2")) // System User Language Code가 Dari
	    		language = "DR";
	    	else if(user.getUseLangCd().equals("3")) // System User Language Code가 Dari
	    		language = "EN";
	    	else 
	    		language = "PS";
	    	// Move to main page
	    	MainMnMngVO mainVO = lgnService.searchMainPage(user);
	    	main_page = mainVO.getPageUrl(); //main page Url
	    	int idx = main_page.indexOf("?");
	    	if(idx > 0) { //If there are any parameters when calling the screen.
	    		String brdParam = main_page.substring(idx+4);
	    		mainVO.setId(brdParam); //Board ID Setting
	    		main_page=main_page+"&language="+language;
	    	} else {
	    		main_page=main_page+"?language="+language;
	    	}
	    	//Main menu information stored in the session
	    	request.getSession().setAttribute("mainMenuManageVO", mainVO);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "forward:" + main_page;
	}
    
    /**
     * Process login out to NID system and move to login screen.  <br>
     * 
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/j_spring_security_logout.do"
     * @exception Exception
     */
    @RequestMapping(value="/cm/uat/actionLogout.do")
	public String actionLogout(HttpServletRequest request, ModelMap model) 
			throws Exception {

    	return "redirect:/j_spring_security_logout.do";
    }
	
  	
  	/**
     * Process login out to NID system and move to login screen.  <br>
     * 
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/j_spring_security_logout.do"
     * @exception Exception
     */
    @RequestMapping(value="/cm/uat/actionLogoutSeson.do")
	public String actionLogoutSeson(HttpServletRequest request, ModelMap model) 
			throws Exception {
    	 String lang = "ps";
         String langCd = "1";
         Object obj = NidUserDetailsHelper.getAuthenticatedUser();
         if(obj != null){
         	if(obj instanceof LgnVO){
         		LgnVO user = (LgnVO)obj;
         		langCd = user.getUseLangCd();
         		if(langCd != null && "2".equals(langCd)){
         			lang = "dr";
         		}else if(langCd != null && "3".equals(langCd)){
         			lang = "en";
         		}
         	}
         }
		HttpSession session = request.getSession(false);
		if (session != null) {
		    session.invalidate();
		}
		SecurityContextHolder.clearContext();
       
        return "redirect:" + "/cm/uat/lgnSesonTmOutView.do?language="+lang+"&useLangCd="+langCd;
    }
    
    /**
	 * Goes to the login screen
	 * @param vo - Containing the URL to login LoginVO.
	 * @return Login Page
	 * @exception Exception
	 */
    @RequestMapping(value="/cm/uat/lgnSesonTmOutView.do")
	public String lgnSesonTmOutView(@ModelAttribute("loginVO") LgnVO loginVO,
			@RequestParam(value="authorFail" ,required=false) String authorFail,
			ModelMap model,
			HttpServletRequest request) 
			throws Exception {
    	try{
    		int sesonChkTm = propertiesService.getInt("sesonChkTm");
			model.addAttribute("sesonChkTm", sesonChkTm);    		
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));    		
    	}
    	return "/cm/uat/LgnSesonTmOut";
	}
    
    /**
     * Change information of user password. <br>
     * 
     * @param LgnVO 
     * @return Printed out JSP: "/cm/uat/PwdChgFst.do"
     * @exception Exception
     */
	@RequestMapping(value="/cm/uat/pwdChgFst.do")
	    public String updateUserPwd(@ModelAttribute("loginVO") LgnVO lgnVO, 
                HttpServletRequest request,
                ModelMap model)
       throws Exception {		
		try {
			
			// Encrypt User Password			
    		String pwd = NidFileScrty.encryptPassword(lgnVO.getPwd());	

    		lgnVO.setPwd(pwd);

			boolean pwdSrch = lgnService.searchPassword(lgnVO);

			if( pwdSrch ){				
				    model.addAttribute("message", nidMessageSource.getMessage(lgnVO.getUseLangCd(), "pwdChgRecy.msg"));
				    model.addAttribute("lgnVO", lgnVO);
				    return  "/cm/uat/PwdChngFst";
				
			} else {
				lgnService.updateUserPwd(lgnVO);
			    return "redirect:/j_spring_security_check.do?j_username="  + lgnVO.getUserId() ;		
			}
			
			
		} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));    		
    	}
		
		model.addAttribute("message", nidMessageSource.getMessage(lgnVO.getUseLangCd(), "pwdChgEror.msg"));
		return "/cm/uat/PwdChngFst";
		
	}
	
}