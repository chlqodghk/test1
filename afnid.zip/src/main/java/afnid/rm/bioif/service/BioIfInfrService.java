
package afnid.rm.bioif.service;

import egovframework.rte.psl.dataaccess.util.EgovMap;





/** 
 * This service interface is biz-class of common. <br>
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2013.01.04  		BH Choi				Create
 *
 * </pre>
 */

public interface BioIfInfrService {
	
	/**
	 * bio socket communication program. <br>
	 * @param String, String, String, String, String,  byte []
	 * @return boolean
	 * @exception Exception
	 */
	EgovMap addBioSocketIf(String bioKey, String rsdtNo, String dupYn, String userId, String flag, byte [] bioFle) throws Exception;
	
	/**
	 * Remove the socket bio <br>
	 * @param String, String, String, String
	 * @return boolean
	 * @exception Exception
	 */
	boolean removeBioSocketIf(String bioKey, String rsdtNo, String dupYn, String userId) throws Exception;
	
	/**
	 * search the socket bio <br>
	 * @param String, String, String, String
	 * @return byte []
	 * @exception Exception
	 */
	byte [] searchBioSocketIf(String bioKey, String rsdtNo, String dupYn, String userId) throws Exception;
	
	/**
	 * search the socket bio <br>
	 * @param String, String, String, String, String
	 * @return String
	 * @exception Exception
	 */
	String searchBioSocketIf(String bioKey, String rsdtNo, String dupYn, String userId, String xy) throws Exception;
	
	/**
	 * search abs unpack data <br>
	 * @param byte []
	 * @return boolean
	 * @exception Exception
	 */
	byte [] searchBioInfrUnPackDat(byte [] array, String type) throws Exception;
	
	/**
	 * bio interface log <br>
	 * @param EgovMap
	 * @return void
	 * @exception Exception
	 */
	void addBioInterfaceLog(EgovMap ems) throws Exception;
}
