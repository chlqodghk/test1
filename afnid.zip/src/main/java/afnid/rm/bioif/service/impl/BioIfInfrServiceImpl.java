package afnid.rm.bioif.service.impl;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import javax.annotation.Resource;

import org.apache.commons.codec.binary.Base64;
import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.cmm.error.NidException;
import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.bioif.service.BioIfInfrService;

import com.dongdo.etazkira.ABS.ABSPacking;
import com.dongdo.etazkira.ABS.ABSSocket;
import com.dongdo.etazkira.Common.commonUtil;

import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of common
 * and implements FmlyInfoService class.
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.04  		BH Choi         		Create
 *
 * </pre>
 */

@Service("bioIfInfrService")
public class BioIfInfrServiceImpl extends AbstractServiceImpl implements BioIfInfrService {
	
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    @Resource(name="lgDAO")
    private LgDAO lgDao;
	
	/**
	 * bio socket communication program. <br>
	 * @param String, String, String, String, String, byte [] 
	 * @return EgovMap
	 * @exception Exception
	 */
   	public EgovMap addBioSocketIf(String bioKey, String rsdtNo, String dupYn, String userId, String flag, byte [] bioFle) throws Exception {
   		Socket socket = null;
   		BufferedOutputStream bos = null;
   		boolean resultFlag = false;
   		String msg = "";
   		byte [] resultBio = null;
   		EgovMap eGov = new EgovMap();
   		try{
   			if(bioFle != null){
	   			String hostname = propertiesService.getString("rm.bio.socketServer");
	   			int port = propertiesService.getInt("rm.bio.socketPort");
	   			int timeout = propertiesService.getInt("rm.bio.socketTimeout");
	   		   	SocketAddress socketAddress = new InetSocketAddress(hostname, port);
	   		   	socket = new Socket();
	   		   	socket.setSoTimeout(timeout);
	   		   	socket.connect(socketAddress, timeout);
	   		   	bos = new BufferedOutputStream(socket.getOutputStream());
	   		   	ABSSocket abs = new ABSSocket();
	   		   	if(flag != null && "i".equals(flag)){
	   		   		resultBio = abs.BioData_Insert(bioKey, rsdtNo, userId, dupYn, bioFle);
	   		   	}else if(flag != null && "u".equals(flag)){
	   		   		resultBio = abs.BioData_Update(bioKey, rsdtNo, userId, dupYn, bioFle);
	   		   	}else if(flag != null && "r".equals(flag)){
	   		   		resultBio = abs.BioData_Renewal_Insert(bioKey, rsdtNo, userId, dupYn, bioFle);
	   		   	}
	   		   	bos.write(resultBio);
	   		   	bos.flush();
	   		   	byte [] resultArray = getRecvDataArray(socket);
	   			bos.close();
	   			socket.close();
			   	eGov.put("userId", userId);
			   	eGov.put("tye", "1");
			   	eGov.put("bioKey", bioKey);
	   		   	resultFlag = abs.BioData_Read(resultArray);
	   		   	eGov.put("abs", abs);
	   		   	eGov.put("resultFlag", new Boolean(resultFlag));
	   		   	if(!resultFlag){
	   		   		String retCode = abs.getRetCode();
	   		   		log.debug("abs.BioData_Read : " + resultFlag + " : " + bioKey + " : " + retCode);
	   		   		if(!"999".equals(retCode)){
		   		   		if(retCode != null && "99".equals(retCode)){
		   		   			msg = abs.getRetMessage();
		   		   		}else{
		   		   			//retCode = retCode.replaceAll(",", "");
		   		   			//msg = "bio.msg."+retCode;
		   		   			//msg = nidMessageSource.getMessage(msg);
		   		   			msg = abs.getRetMessage();
		   		   		}
		   		   		addBioInterfaceLog(eGov);
		   		   		throw new NidException(msg);
	   		   		}else{
	   		   			resultFlag = true;
	   		   		}
	   		   	}else{
	   		   		msg = abs.getRetMessage();
	   		   	}
   			}
   		}catch(ConnectException e){
   			log.error(e);
	   		msg = e.getMessage();
	   		throw e;
   		}catch(IOException e){
	   		log.error(e);
	   		msg = e.getMessage();
	   		throw e;
	   	}catch(Exception e){
	   		log.error(e);
	   		msg = e.getMessage();
	   		throw e;
	   	} finally {
	   		try {
   				if(bos != null){
   					bos.close();
   				}
   				if(socket != null){
   					socket.close();
   				}
   				//String erorYn = "Y";
			   	//if(resultFlag){
			   	//	erorYn = "N";
			   	//}
			   	//lgDao.insertBioIfLg(userId, "1", erorYn, msg, bioKey);
   			} catch (IOException e) {
   				log.error(e);
   			}
   		}
   		return eGov;
   	}
   	
   	/**
	 * Remove the socket bio <br>
	 * @param String, String, String, String, String, byte [] 
	 * @return boolean
	 * @exception Exception
	 */
   	public boolean removeBioSocketIf(String bioKey, String rsdtNo, String dupYn, String userId) throws Exception {
   		Socket socket = null;
   		BufferedOutputStream bos = null;
   		boolean resultFlag = false;
   		String msg = "";
   		try{
   			if(bioKey != null && rsdtNo != null && dupYn != null && userId != null){
	   			String hostname = propertiesService.getString("rm.bio.socketServer");
	   			int port = propertiesService.getInt("rm.bio.socketPort");
	   			int timeout = propertiesService.getInt("rm.bio.socketTimeout");
	   		   	SocketAddress socketAddress = new InetSocketAddress(hostname, port);
	   		   	socket = new Socket();
	   		   	socket.setSoTimeout(timeout);
	   		   	socket.connect(socketAddress, timeout);
	   		   	bos = new BufferedOutputStream(socket.getOutputStream());
	   		   	ABSSocket abs = new ABSSocket();
	   		   	byte [] array = abs.BioData_Delete(bioKey, rsdtNo, userId, dupYn);
	   		   	bos.write(array);
	   		   	bos.flush();
	   		   	byte [] resultArray = getRecvDataArray(socket);
	   			bos.close();
	   			socket.close();
	   		   	resultFlag = abs.BioData_Read(resultArray);
	   		   	if(!resultFlag){
		   		   	String retCode = abs.getRetCode();
	   		   		if(retCode != null && "99".equals(retCode)){
	   		   			msg = abs.getRetMessage();
	   		   		}else{
	   		   			retCode = retCode.replaceAll(",", "");
	   		   			msg = "bio.msg."+retCode;
	   		   			msg = nidMessageSource.getMessage(msg);
	   		   		}
	   		   		throw new NidException(msg);
	   		   	}else{
	   		   		msg = abs.getRetMessage();
	   		   	}
   			}
   		}catch(IOException e){
	   		log.error(e);
	   		msg = e.getMessage();
	   		throw e;
	   	}catch(Exception e){
	   		log.error(e);
	   		msg = e.getMessage();
	   		throw e;
	   	} finally {
	   		try {
   				if(bos != null){
   					bos.close();
   				}
   				if(socket != null){
   					socket.close();
   				}
   				String erorYn = "Y";
			   	if(resultFlag){
			   		erorYn = "N";
			   	}
			   	lgDao.insertBioIfLg(userId, "3", erorYn, msg, bioKey);
   			} catch (IOException e) {
   				log.error(e);
   			}
   		}
   		return resultFlag;
   	}
   	
   	/**
	 * search the socket bio <br>
	 * @param String, String, String, String
	 * @return byte []
	 * @exception Exception
	 */
   	public byte [] searchBioSocketIf(String bioKey, String rsdtNo, String dupYn, String userId) throws Exception {
   		Socket socket = null;
   		BufferedOutputStream bos = null;
   		String msg = "";
   		byte [] result = null;
   		boolean resultFlag = false;
   		try{
   			if(bioKey != null && rsdtNo != null && dupYn != null && userId != null){
	   			String hostname = propertiesService.getString("rm.bio.socketServer");
	   			int port = propertiesService.getInt("rm.bio.socketPort");
	   			int timeout = propertiesService.getInt("rm.bio.socketTimeout");
	   		   	SocketAddress socketAddress = new InetSocketAddress(hostname, port);
	   		   	socket = new Socket();
	   		   	socket.setSoTimeout(timeout);
	   		   	socket.connect(socketAddress, timeout);
	   		   	bos = new BufferedOutputStream(socket.getOutputStream());
	   		   	ABSSocket abs = new ABSSocket();
	   		   	byte [] array = abs.BioData_Search(bioKey, rsdtNo, userId, dupYn);
	   		   	bos.write(array);
	   		   	bos.flush();
	   		   	byte [] resultArray = getRecvDataArray(socket);
	   			bos.close();
	   			socket.close();
	   		   	resultFlag = abs.BioData_Read(resultArray);
	   		   	if(!resultFlag){
		   		   	String retCode = abs.getRetCode();
	   		   		if(retCode != null && "99".equals(retCode)){
	   		   			msg = abs.getRetMessage();
	   		   		}else{
	   		   			retCode = retCode.replaceAll(",", "");
	   		   			msg = "bio.msg."+retCode;
	   		   			msg = nidMessageSource.getMessage(msg);
	   		   		}
	   		   		throw new NidException(msg);
	   		   	}else{
	   		   		msg = "OK Search";
	   		   		result = abs.getReceiveData();
	   		   	}
   			}
   		}catch(IOException e){
	   		log.error(e);
	   		msg = e.getMessage();
	   		throw e;
	   	}catch(Exception e){
	   		log.error(e);
	   		msg = e.getMessage();
	   		throw e;
	   	} finally {
	   		try {
   				if(bos != null){
   					bos.close();
   				}
   				if(socket != null){
   					socket.close();
   				}
   				String erorYn = "Y";
			   	if(resultFlag){
			   		erorYn = "N";
			   	}
			   	lgDao.insertBioIfLg(userId, "2", erorYn, msg, bioKey);
   			} catch (IOException e) {
   				log.error(e);
   			}
   		}
   		return result;
   	}
   	
	/**
	 * search the socket bio <br>
	 * @param String, String, String, String, String
	 * @return String
	 * @exception Exception
	 */
   	public String searchBioSocketIf(String bioKey, String rsdtNo, String dupYn, String userId, String xy) throws Exception {
   		Socket socket = null;
   		BufferedOutputStream bos = null;
   		String msg = "";
   		byte [] result = null;
   		String resultChr = null;
   		boolean resultFlag = false;
   		try{
   			if(bioKey != null && rsdtNo != null && dupYn != null && userId != null){
	   			String hostname = propertiesService.getString("rm.bio.socketServer");
	   			int port = propertiesService.getInt("rm.bio.socketPort");
	   			int timeout = propertiesService.getInt("rm.bio.socketTimeout");
	   		   	SocketAddress socketAddress = new InetSocketAddress(hostname, port);
	   		   	socket = new Socket();
	   		   	socket.setSoTimeout(timeout);
	   		   	socket.connect(socketAddress, timeout);
	   		   	bos = new BufferedOutputStream(socket.getOutputStream());
	   		   	ABSSocket abs = new ABSSocket();
	   		   	byte [] array = abs.BioData_Search(bioKey, rsdtNo, userId, dupYn);
	   		   	bos.write(array);
	   		   	bos.flush();
	   		   	byte [] resultArray = getRecvDataArray(socket);
	   			bos.close();
	   			socket.close();
	   		   	resultFlag = abs.BioData_Read(resultArray);
	   		   	if(!resultFlag){
	   		   		String retCode = abs.getRetCode();
	   		   		if(retCode != null && "99".equals(retCode)){
	   		   			msg = abs.getRetMessage();
	   		   		}else{
	   		   			retCode = retCode.replaceAll(",", "");
	   		   			msg = "bio.msg."+retCode;
	   		   			msg = nidMessageSource.getMessage(msg);
	   		   		}
	   		   		throw new NidException(msg);
	   		   	}else{
	   		   		result = abs.getReceiveData();
	   		   		msg = "OK Search";
	   		   		if(result != null && result.length > 0){
	   		   			//resultChr = new String(result, "8859_1");
	   		   			resultChr = new String(Base64.encodeBase64(result));
	   		   		}else{
	   		   			resultChr = "";
	   		   		}
	   		   	}
   			}
   		}catch(IOException e){
	   		log.error(e);
	   		msg = e.getMessage();
	   		throw e;
	   	}catch(Exception e){
	   		log.error(e);
	   		msg = e.getMessage();
	   		throw e;
	   	} finally {
	   		try {
   				if(bos != null){
   					bos.close();
   				}
   				if(socket != null){
   					socket.close();
   				}
   				String erorYn = "Y";
			   	if(resultFlag){
			   		erorYn = "N";
			   	}
			   	lgDao.insertBioIfLg(userId, "2", erorYn, msg, bioKey);
   			} catch (IOException e) {
   				log.error(e);
   			}
   		}
   		return resultChr;
   	}
   	
   	/**
	 * unPacked image data <br>
	 * @param String, String, String, String
	 * @return byte []
	 * @exception Exception
	 */
   	public byte [] searchBioInfrUnPackDat(byte [] array, String type) throws Exception {
   		byte [] result = null;
   		String typeVal = type;
   		if(typeVal == null){
   			typeVal = "f";
   		}
   		try{
	   		if(array != null && typeVal != null){
	   			ABSSocket abs = new ABSSocket();
	   			ABSPacking pack = abs.UnPackaing(array);
	   			if("f".equals(typeVal)){
	   				result = pack.Image_Data.getFACE();
	   			}else if("s".equals(typeVal)){
	   				result = pack.Image_Data.getSIGN();
	   			}
	   		}
   		}catch(Exception e){
   			log.error(e);
   		}
   		return result;
   	}
   	
   	
   	
   	/**
	 * Results will be in charge of receiving data. <br>
	 * @param String, Socket
	 * @return byte []
	 * @exception Exception
	 */
   	public byte [] getRecvDataArray(Socket socket) throws Exception {
   		byte [] result = null;
   		BufferedInputStream bis = null;
   		ByteArrayOutputStream baos = null;
   		//int recvSize = propertiesService.getInt("rm.bio.socketRecvSize");
   		try{
   			if(socket.isConnected()){
	   			bis = new BufferedInputStream(socket.getInputStream());
			   	baos = new ByteArrayOutputStream();
			    //byte [] limit = new byte[recvSize];
			    //boolean inputFlag = true;
			   	int cnt = 0;
			   	int maxcount = 100;
			   	int count = 1;
			   	/*
			   	while(inputFlag){
			   		b = bis.read(limit);
			   		if(b != -1){
			   			baos.write(limit, 0, b);
			   		}else{
			   			inputFlag = false;
			   		}
			   	}*/
			   	

				while (true) {
					cnt = bis.read();
					baos.write(cnt);
					if (baos.size() == 67) {
						byte[] leng = new byte[4];
						System.arraycopy(baos.toByteArray(), 63, leng, 0, leng.length);
						maxcount = commonUtil.GetInt(leng);	
					}
					if (count == maxcount + 67) {
						baos.flush();
						break;
					}
					count++;
				}
				
			   	bis.close();
			   	result = baos.toByteArray();
			   	baos.close();
   			}
   		}catch(Exception e){
   			log.error(e);
   			throw e;
   		}finally{
   			try{
   				if(bis != null){
   					bis.close();
   				}
   				if(baos != null){
   					baos.close();
   				}
   			}catch(Exception e){
   				log.error(e);
   			}
   		}
   		return result;
   	}

   	/**
	 * bio interface log. <br>
	 * @param EgovMap
	 * @return void
	 * @exception Exception
	 */
	public void addBioInterfaceLog(EgovMap ems) throws Exception {
		if(ems != null && !ems.isEmpty()){
			String userId = NidStringUtil.nullConvert(ems.get("userId"));
			String tye = NidStringUtil.nullConvert(ems.get("tye"));
			String bioKey = NidStringUtil.nullConvert(ems.get("bioKey"));
			ABSSocket abs = null;
			Boolean flag = false;
			Object obj = ems.get("abs");
			if(obj != null && obj instanceof ABSSocket){
				abs = (ABSSocket)obj;
			}
			obj = null;
			obj = ems.get("resultFlag");
			if(obj != null && obj instanceof Boolean){
				flag = (Boolean)obj;
			}
			if(userId != null && tye != null && bioKey != null && abs != null && flag != null
					&& !"".equals(userId) && !"".equals(tye) && !"".equals(bioKey)){
				boolean reFlag = flag.booleanValue();
				String erorYn = "Y";
				if(reFlag){
					erorYn = "N";
				}
				String msg = "";
				if(!reFlag){
	   		   		String retCode = abs.getRetCode();
	   		   		log.debug("addBioInterfaceLog : " + reFlag + " : " + bioKey + " : " + retCode);
	   		   		if(!"999".equals(retCode)){
		   		   		if(retCode != null && "99".equals(retCode)){
		   		   			msg = abs.getRetMessage();
		   		   		}else{
		   		   			retCode = retCode.replaceAll(",", "");
		   		   			msg = "bio.msg."+retCode;
		   		   			msg = nidMessageSource.getMessage(msg);
		   		   		}
	   		   		}
	   		   	}else{
	   		   		msg = abs.getRetMessage();
	   		   	}
				lgDao.insertBioIfLg(userId, "1", erorYn, msg, bioKey);
			}
		}
	}
}