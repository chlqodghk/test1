package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsLogVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String crnDd;
	private String wrkCd;
	private String wrkStt;
	private String wrkEdDt;
	private String tableNm;	
	private String yy;
	private String tgtCn;
	private String errCn;
	private String errYn;
	private String msg;
	private String wrkSysCd;
	private String userId;
	private String gYmd;
	
	
	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	public String getWrkCd() {
		return wrkCd;
	}
	public void setWrkCd(String wrkCd) {
		this.wrkCd = wrkCd;
	}
	public String getWrkStt() {
		return wrkStt;
	}
	public void setWrkStt(String wrkStt) {
		this.wrkStt = wrkStt;
	}
	public String getWrkEdDt() {
		return wrkEdDt;
	}
	public void setWrkEdDt(String wrkEdDt) {
		this.wrkEdDt = wrkEdDt;
	}
	public String getTableNm() {
		return tableNm;
	}
	public void setTableNm(String tableNm) {
		this.tableNm = tableNm;
	}
	public String getYy() {
		return yy;
	}
	public void setYy(String yy) {
		this.yy = yy;
	}
	public String getTgtCn() {
		return tgtCn;
	}
	public void setTgtCn(String tgtCn) {
		this.tgtCn = tgtCn;
	}
	public String getErrCn() {
		return errCn;
	}
	public void setErrCn(String errCn) {
		this.errCn = errCn;
	}
	public String getErrYn() {
		return errYn;
	}
	public void setErrYn(String errYn) {
		this.errYn = errYn;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getWrkSysCd() {
		return wrkSysCd;
	}
	public void setWrkSysCd(String wrkSysCd) {
		this.wrkSysCd = wrkSysCd;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getgYmd() {
		return gYmd;
	}
	public void setgYmd(String gYmd) {
		this.gYmd = gYmd;
	}	
	
	

}
