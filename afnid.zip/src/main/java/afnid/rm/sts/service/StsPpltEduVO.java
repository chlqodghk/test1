package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsPpltEduVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String crnDd;
	private String age0Tot1;
	private String age0Tot2Y;
	private String age0Tot3Y;
	private String age0Tot4Y;
	private String age0Tot5Y;
	private String age0Tot6Y;
	private String age0Tot7Y;
	private String age0Ml1;
	private String age0Ml2Y;
	private String age0Ml3Y;
	private String age0Ml4Y;
	private String age0Ml5Y;
	private String age0Ml6Y;
	private String age0Ml7Y;
	private String age0Fm1;
	private String age0Fm2Y;
	private String age0Fm3Y;
	private String age0Fm4Y;
	private String age0Fm5Y;
	private String age0Fm6Y;
	private String age0Fm7Y;
	private String age10Tot1;
	private String age10Tot2Y;
	private String age10Tot3Y;
	private String age10Tot4Y;
	private String age10Tot5Y;
	private String age10Tot6Y;
	private String age10Tot7Y;
	private String age10Ml1;
	private String age10Ml2Y;
	private String age10Ml3Y;
	private String age10Ml4Y;
	private String age10Ml5Y;
	private String age10Ml6Y;
	private String age10Ml7Y;
	private String age10Fm1;
	private String age10Fm2Y;
	private String age10Fm3Y;
	private String age10Fm4Y;
	private String age10Fm5Y;
	private String age10Fm6Y;
	private String age10Fm7Y;
	private String age20Tot1;
	private String age20Tot2Y;
	private String age20Tot3Y;
	private String age20Tot4Y;
	private String age20Tot5Y;
	private String age20Tot6Y;
	private String age20Tot7Y;
	private String age20Ml1;
	private String age20Ml2Y;
	private String age20Ml3Y;
	private String age20Ml4Y;
	private String age20Ml5Y;
	private String age20Ml6Y;
	private String age20Ml7Y;
	private String age20Fm1;
	private String age20Fm2Y;
	private String age20Fm3Y;
	private String age20Fm4Y;
	private String age20Fm5Y;
	private String age20Fm6Y;
	private String age20Fm7Y;
	private String age30Tot1;
	private String age30Tot2Y;
	private String age30Tot3Y;
	private String age30Tot4Y;
	private String age30Tot5Y;
	private String age30Tot6Y;
	private String age30Tot7Y;
	private String age30Ml1;
	private String age30Ml2Y;
	private String age30Ml3Y;
	private String age30Ml4Y;
	private String age30Ml5Y;
	private String age30Ml6Y;
	private String age30Ml7Y;
	private String age30Fm1;
	private String age30Fm2Y;
	private String age30Fm3Y;
	private String age30Fm4Y;
	private String age30Fm5Y;
	private String age30Fm6Y;
	private String age30Fm7Y;
	private String age40Tot1;
	private String age40Tot2Y;
	private String age40Tot3Y;
	private String age40Tot4Y;
	private String age40Tot5Y;
	private String age40Tot6Y;
	private String age40Tot7Y;
	private String age40Ml1;
	private String age40Ml2Y;
	private String age40Ml3Y;
	private String age40Ml4Y;
	private String age40Ml5Y;
	private String age40Ml6Y;
	private String age40Ml7Y;
	private String age40Fm1;
	private String age40Fm2Y;
	private String age40Fm3Y;
	private String age40Fm4Y;
	private String age40Fm5Y;
	private String age40Fm6Y;
	private String age40Fm7Y;
	private String age50Tot1;
	private String age50Tot2Y;
	private String age50Tot3Y;
	private String age50Tot4Y;
	private String age50Tot5Y;
	private String age50Tot6Y;
	private String age50Tot7Y;
	private String age50Ml1;
	private String age50Ml2Y;
	private String age50Ml3Y;
	private String age50Ml4Y;
	private String age50Ml5Y;
	private String age50Ml6Y;
	private String age50Ml7Y;
	private String age50Fm1;
	private String age50Fm2Y;
	private String age50Fm3Y;
	private String age50Fm4Y;
	private String age50Fm5Y;
	private String age50Fm6Y;
	private String age50Fm7Y;
	private String age60Tot1;
	private String age60Tot2Y;
	private String age60Tot3Y;
	private String age60Tot4Y;
	private String age60Tot5Y;
	private String age60Tot6Y;
	private String age60Tot7Y;
	private String age60Ml1;
	private String age60Ml2Y;
	private String age60Ml3Y;
	private String age60Ml4Y;
	private String age60Ml5Y;
	private String age60Ml6Y;
	private String age60Ml7Y;
	private String age60Fm1;
	private String age60Fm2Y;
	private String age60Fm3Y;
	private String age60Fm4Y;
	private String age60Fm5Y;
	private String age60Fm6Y;
	private String age60Fm7Y;
	private String age70Tot1;
	private String age70Tot2Y;
	private String age70Tot3Y;
	private String age70Tot4Y;
	private String age70Tot5Y;
	private String age70Tot6Y;
	private String age70Tot7Y;
	private String age70Ml1;
	private String age70Ml2Y;
	private String age70Ml3Y;
	private String age70Ml4Y;
	private String age70Ml5Y;
	private String age70Ml6Y;
	private String age70Ml7Y;
	private String age70Fm1;
	private String age70Fm2Y;
	private String age70Fm3Y;
	private String age70Fm4Y;
	private String age70Fm5Y;
	private String age70Fm6Y;
	private String age70Fm7Y;
	private String age80Tot1;
	private String age80Tot2Y;
	private String age80Tot3Y;
	private String age80Tot4Y;
	private String age80Tot5Y;
	private String age80Tot6Y;
	private String age80Tot7Y;
	private String age80Ml1;
	private String age80Ml2Y;
	private String age80Ml3Y;
	private String age80Ml4Y;
	private String age80Ml5Y;
	private String age80Ml6Y;
	private String age80Ml7Y;
	private String age80Fm1;
	private String age80Fm2Y;
	private String age80Fm3Y;
	private String age80Fm4Y;
	private String age80Fm5Y;
	private String age80Fm6Y;
	private String age80Fm7Y;
	private String age90Tot1;
	private String age90Tot2Y;
	private String age90Tot3Y;
	private String age90Tot4Y;
	private String age90Tot5Y;
	private String age90Tot6Y;
	private String age90Tot7Y;
	private String age90Ml1;
	private String age90Ml2Y;
	private String age90Ml3Y;
	private String age90Ml4Y;
	private String age90Ml5Y;
	private String age90Ml6Y;
	private String age90Ml7Y;
	private String age90Fm1;
	private String age90Fm2Y;
	private String age90Fm3Y;
	private String age90Fm4Y;
	private String age90Fm5Y;
	private String age90Fm6Y;
	private String age90Fm7Y;
	private String age100Tot1;
	private String age100Tot2Y;
	private String age100Tot3Y;
	private String age100Tot4Y;
	private String age100Tot5Y;
	private String age100Tot6Y;
	private String age100Tot7Y;
	private String age100Ml1;
	private String age100Ml2Y;
	private String age100Ml3Y;
	private String age100Ml4Y;
	private String age100Ml5Y;
	private String age100Ml6Y;
	private String age100Ml7Y;
	private String age100Fm1;
	private String age100Fm2Y;
	private String age100Fm3Y;
	private String age100Fm4Y;
	private String age100Fm5Y;
	private String age100Fm6Y;
	private String age100Fm7Y;	  	
	private String dstrNm; 
	private String prvicNm;
	private String curtAdCd;
	private String stsTitCd;
	private String stsTitNm;
	private String adCd;
	private String adCdNm;
	
	private String age0Tot2N;
	private String age0Tot3N;
	private String age0Tot4N;
	private String age0Tot5N;
	private String age0Tot6N;
	private String age0Tot7N;

	private String age0Ml2N;
	private String age0Ml3N;
	private String age0Ml4N;
	private String age0Ml5N;
	private String age0Ml6N;
	private String age0Ml7N;

	private String age0Fm2N;
	private String age0Fm3N;
	private String age0Fm4N;
	private String age0Fm5N;
	private String age0Fm6N;
	private String age0Fm7N;

	private String age10Tot2N;
	private String age10Tot3N;
	private String age10Tot4N;
	private String age10Tot5N;
	private String age10Tot6N;
	private String age10Tot7N;

	private String age10Ml2N;
	private String age10Ml3N;
	private String age10Ml4N;
	private String age10Ml5N;
	private String age10Ml6N;
	private String age10Ml7N;

	private String age10Fm2N;
	private String age10Fm3N;
	private String age10Fm4N;
	private String age10Fm5N;
	private String age10Fm6N;
	private String age10Fm7N;

	private String age20Tot2N;
	private String age20Tot3N;
	private String age20Tot4N;
	private String age20Tot5N;
	private String age20Tot6N;
	private String age20Tot7N;

	private String age20Ml2N;
	private String age20Ml3N;
	private String age20Ml4N;
	private String age20Ml5N;
	private String age20Ml6N;
	private String age20Ml7N;

	private String age20Fm2N;
	private String age20Fm3N;
	private String age20Fm4N;
	private String age20Fm5N;
	private String age20Fm6N;
	private String age20Fm7N;

	private String age30Tot2N;
	private String age30Tot3N;
	private String age30Tot4N;
	private String age30Tot5N;
	private String age30Tot6N;
	private String age30Tot7N;

	private String age30Ml2N;
	private String age30Ml3N;
	private String age30Ml4N;
	private String age30Ml5N;
	private String age30Ml6N;
	private String age30Ml7N;

	private String age30Fm2N;
	private String age30Fm3N;
	private String age30Fm4N;
	private String age30Fm5N;
	private String age30Fm6N;
	private String age30Fm7N;

	private String age40Tot2N;
	private String age40Tot3N;
	private String age40Tot4N;
	private String age40Tot5N;
	private String age40Tot6N;
	private String age40Tot7N;

	private String age40Ml2N;
	private String age40Ml3N;
	private String age40Ml4N;
	private String age40Ml5N;
	private String age40Ml6N;
	private String age40Ml7N;

	private String age40Fm2N;
	private String age40Fm3N;
	private String age40Fm4N;
	private String age40Fm5N;
	private String age40Fm6N;
	private String age40Fm7N;

	private String age50Tot2N;
	private String age50Tot3N;
	private String age50Tot4N;
	private String age50Tot5N;
	private String age50Tot6N;
	private String age50Tot7N;

	private String age50Ml2N;
	private String age50Ml3N;
	private String age50Ml4N;
	private String age50Ml5N;
	private String age50Ml6N;
	private String age50Ml7N;

	private String age50Fm2N;
	private String age50Fm3N;
	private String age50Fm4N;
	private String age50Fm5N;
	private String age50Fm6N;
	private String age50Fm7N;

	private String age60Tot2N;
	private String age60Tot3N;
	private String age60Tot4N;
	private String age60Tot5N;
	private String age60Tot6N;
	private String age60Tot7N;

	private String age60Ml2N;
	private String age60Ml3N;
	private String age60Ml4N;
	private String age60Ml5N;
	private String age60Ml6N;
	private String age60Ml7N;

	private String age60Fm2N;
	private String age60Fm3N;
	private String age60Fm4N;
	private String age60Fm5N;
	private String age60Fm6N;
	private String age60Fm7N;

	private String age70Tot2N;
	private String age70Tot3N;
	private String age70Tot4N;
	private String age70Tot5N;
	private String age70Tot6N;
	private String age70Tot7N;

	private String age70Ml2N;
	private String age70Ml3N;
	private String age70Ml4N;
	private String age70Ml5N;
	private String age70Ml6N;
	private String age70Ml7N;

	private String age70Fm2N;
	private String age70Fm3N;
	private String age70Fm4N;
	private String age70Fm5N;
	private String age70Fm6N;
	private String age70Fm7N;

	private String age80Tot2N;
	private String age80Tot3N;
	private String age80Tot4N;
	private String age80Tot5N;
	private String age80Tot6N;
	private String age80Tot7N;

	private String age80Ml2N;
	private String age80Ml3N;
	private String age80Ml4N;
	private String age80Ml5N;
	private String age80Ml6N;
	private String age80Ml7N;

	private String age80Fm2N;
	private String age80Fm3N;
	private String age80Fm4N;
	private String age80Fm5N;
	private String age80Fm6N;
	private String age80Fm7N;

	private String age90Tot2N;
	private String age90Tot3N;
	private String age90Tot4N;
	private String age90Tot5N;
	private String age90Tot6N;
	private String age90Tot7N;

	private String age90Ml2N;
	private String age90Ml3N;
	private String age90Ml4N;
	private String age90Ml5N;
	private String age90Ml6N;
	private String age90Ml7N;

	private String age90Fm2N;
	private String age90Fm3N;
	private String age90Fm4N;
	private String age90Fm5N;
	private String age90Fm6N;
	private String age90Fm7N;

	private String age100Tot2N;
	private String age100Tot3N;
	private String age100Tot4N;
	private String age100Tot5N;
	private String age100Tot6N;
	private String age100Tot7N;

	private String age100Ml2N;
	private String age100Ml3N;
	private String age100Ml4N;
	private String age100Ml5N;
	private String age100Ml6N;
	private String age100Ml7N;

	private String age100Fm2N;
	private String age100Fm3N;
	private String age100Fm4N;
	private String age100Fm5N;
	private String age100Fm6N;
	private String age100Fm7N;
	
	
	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	public String getAge0Tot1() {
		return age0Tot1;
	}
	public void setAge0Tot1(String age0Tot1) {
		this.age0Tot1 = age0Tot1;
	}
	public String getAge0Tot2Y() {
		return age0Tot2Y;
	}
	public void setAge0Tot2Y(String age0Tot2Y) {
		this.age0Tot2Y = age0Tot2Y;
	}
	public String getAge0Tot3Y() {
		return age0Tot3Y;
	}
	public void setAge0Tot3Y(String age0Tot3Y) {
		this.age0Tot3Y = age0Tot3Y;
	}
	public String getAge0Tot4Y() {
		return age0Tot4Y;
	}
	public void setAge0Tot4Y(String age0Tot4Y) {
		this.age0Tot4Y = age0Tot4Y;
	}
	public String getAge0Tot5Y() {
		return age0Tot5Y;
	}
	public void setAge0Tot5Y(String age0Tot5Y) {
		this.age0Tot5Y = age0Tot5Y;
	}
	public String getAge0Tot6Y() {
		return age0Tot6Y;
	}
	public void setAge0Tot6Y(String age0Tot6Y) {
		this.age0Tot6Y = age0Tot6Y;
	}
	public String getAge0Tot7Y() {
		return age0Tot7Y;
	}
	public void setAge0Tot7Y(String age0Tot7Y) {
		this.age0Tot7Y = age0Tot7Y;
	}
	public String getAge0Ml1() {
		return age0Ml1;
	}
	public void setAge0Ml1(String age0Ml1) {
		this.age0Ml1 = age0Ml1;
	}
	public String getAge0Ml2Y() {
		return age0Ml2Y;
	}
	public void setAge0Ml2Y(String age0Ml2Y) {
		this.age0Ml2Y = age0Ml2Y;
	}
	public String getAge0Ml3Y() {
		return age0Ml3Y;
	}
	public void setAge0Ml3Y(String age0Ml3Y) {
		this.age0Ml3Y = age0Ml3Y;
	}
	public String getAge0Ml4Y() {
		return age0Ml4Y;
	}
	public void setAge0Ml4Y(String age0Ml4Y) {
		this.age0Ml4Y = age0Ml4Y;
	}
	public String getAge0Ml5Y() {
		return age0Ml5Y;
	}
	public void setAge0Ml5Y(String age0Ml5Y) {
		this.age0Ml5Y = age0Ml5Y;
	}
	public String getAge0Ml6Y() {
		return age0Ml6Y;
	}
	public void setAge0Ml6Y(String age0Ml6Y) {
		this.age0Ml6Y = age0Ml6Y;
	}
	public String getAge0Ml7Y() {
		return age0Ml7Y;
	}
	public void setAge0Ml7Y(String age0Ml7Y) {
		this.age0Ml7Y = age0Ml7Y;
	}
	public String getAge0Fm1() {
		return age0Fm1;
	}
	public void setAge0Fm1(String age0Fm1) {
		this.age0Fm1 = age0Fm1;
	}
	public String getAge0Fm2Y() {
		return age0Fm2Y;
	}
	public void setAge0Fm2Y(String age0Fm2Y) {
		this.age0Fm2Y = age0Fm2Y;
	}
	public String getAge0Fm3Y() {
		return age0Fm3Y;
	}
	public void setAge0Fm3Y(String age0Fm3Y) {
		this.age0Fm3Y = age0Fm3Y;
	}
	public String getAge0Fm4Y() {
		return age0Fm4Y;
	}
	public void setAge0Fm4Y(String age0Fm4Y) {
		this.age0Fm4Y = age0Fm4Y;
	}
	public String getAge0Fm5Y() {
		return age0Fm5Y;
	}
	public void setAge0Fm5Y(String age0Fm5Y) {
		this.age0Fm5Y = age0Fm5Y;
	}
	public String getAge0Fm6Y() {
		return age0Fm6Y;
	}
	public void setAge0Fm6Y(String age0Fm6Y) {
		this.age0Fm6Y = age0Fm6Y;
	}
	public String getAge0Fm7Y() {
		return age0Fm7Y;
	}
	public void setAge0Fm7Y(String age0Fm7Y) {
		this.age0Fm7Y = age0Fm7Y;
	}
	public String getAge10Tot1() {
		return age10Tot1;
	}
	public void setAge10Tot1(String age10Tot1) {
		this.age10Tot1 = age10Tot1;
	}
	public String getAge10Tot2Y() {
		return age10Tot2Y;
	}
	public void setAge10Tot2Y(String age10Tot2Y) {
		this.age10Tot2Y = age10Tot2Y;
	}
	public String getAge10Tot3Y() {
		return age10Tot3Y;
	}
	public void setAge10Tot3Y(String age10Tot3Y) {
		this.age10Tot3Y = age10Tot3Y;
	}
	public String getAge10Tot4Y() {
		return age10Tot4Y;
	}
	public void setAge10Tot4Y(String age10Tot4Y) {
		this.age10Tot4Y = age10Tot4Y;
	}
	public String getAge10Tot5Y() {
		return age10Tot5Y;
	}
	public void setAge10Tot5Y(String age10Tot5Y) {
		this.age10Tot5Y = age10Tot5Y;
	}
	public String getAge10Tot6Y() {
		return age10Tot6Y;
	}
	public void setAge10Tot6Y(String age10Tot6Y) {
		this.age10Tot6Y = age10Tot6Y;
	}
	public String getAge10Tot7Y() {
		return age10Tot7Y;
	}
	public void setAge10Tot7Y(String age10Tot7Y) {
		this.age10Tot7Y = age10Tot7Y;
	}
	public String getAge10Ml1() {
		return age10Ml1;
	}
	public void setAge10Ml1(String age10Ml1) {
		this.age10Ml1 = age10Ml1;
	}
	public String getAge10Ml2Y() {
		return age10Ml2Y;
	}
	public void setAge10Ml2Y(String age10Ml2Y) {
		this.age10Ml2Y = age10Ml2Y;
	}
	public String getAge10Ml3Y() {
		return age10Ml3Y;
	}
	public void setAge10Ml3Y(String age10Ml3Y) {
		this.age10Ml3Y = age10Ml3Y;
	}
	public String getAge10Ml4Y() {
		return age10Ml4Y;
	}
	public void setAge10Ml4Y(String age10Ml4Y) {
		this.age10Ml4Y = age10Ml4Y;
	}
	public String getAge10Ml5Y() {
		return age10Ml5Y;
	}
	public void setAge10Ml5Y(String age10Ml5Y) {
		this.age10Ml5Y = age10Ml5Y;
	}
	public String getAge10Ml6Y() {
		return age10Ml6Y;
	}
	public void setAge10Ml6Y(String age10Ml6Y) {
		this.age10Ml6Y = age10Ml6Y;
	}
	public String getAge10Ml7Y() {
		return age10Ml7Y;
	}
	public void setAge10Ml7Y(String age10Ml7Y) {
		this.age10Ml7Y = age10Ml7Y;
	}
	public String getAge10Fm1() {
		return age10Fm1;
	}
	public void setAge10Fm1(String age10Fm1) {
		this.age10Fm1 = age10Fm1;
	}
	public String getAge10Fm2Y() {
		return age10Fm2Y;
	}
	public void setAge10Fm2Y(String age10Fm2Y) {
		this.age10Fm2Y = age10Fm2Y;
	}
	public String getAge10Fm3Y() {
		return age10Fm3Y;
	}
	public void setAge10Fm3Y(String age10Fm3Y) {
		this.age10Fm3Y = age10Fm3Y;
	}
	public String getAge10Fm4Y() {
		return age10Fm4Y;
	}
	public void setAge10Fm4Y(String age10Fm4Y) {
		this.age10Fm4Y = age10Fm4Y;
	}
	public String getAge10Fm5Y() {
		return age10Fm5Y;
	}
	public void setAge10Fm5Y(String age10Fm5Y) {
		this.age10Fm5Y = age10Fm5Y;
	}
	public String getAge10Fm6Y() {
		return age10Fm6Y;
	}
	public void setAge10Fm6Y(String age10Fm6Y) {
		this.age10Fm6Y = age10Fm6Y;
	}
	public String getAge10Fm7Y() {
		return age10Fm7Y;
	}
	public void setAge10Fm7Y(String age10Fm7Y) {
		this.age10Fm7Y = age10Fm7Y;
	}
	public String getAge20Tot1() {
		return age20Tot1;
	}
	public void setAge20Tot1(String age20Tot1) {
		this.age20Tot1 = age20Tot1;
	}
	public String getAge20Tot2Y() {
		return age20Tot2Y;
	}
	public void setAge20Tot2Y(String age20Tot2Y) {
		this.age20Tot2Y = age20Tot2Y;
	}
	public String getAge20Tot3Y() {
		return age20Tot3Y;
	}
	public void setAge20Tot3Y(String age20Tot3Y) {
		this.age20Tot3Y = age20Tot3Y;
	}
	public String getAge20Tot4Y() {
		return age20Tot4Y;
	}
	public void setAge20Tot4Y(String age20Tot4Y) {
		this.age20Tot4Y = age20Tot4Y;
	}
	public String getAge20Tot5Y() {
		return age20Tot5Y;
	}
	public void setAge20Tot5Y(String age20Tot5Y) {
		this.age20Tot5Y = age20Tot5Y;
	}
	public String getAge20Tot6Y() {
		return age20Tot6Y;
	}
	public void setAge20Tot6Y(String age20Tot6Y) {
		this.age20Tot6Y = age20Tot6Y;
	}
	public String getAge20Tot7Y() {
		return age20Tot7Y;
	}
	public void setAge20Tot7Y(String age20Tot7Y) {
		this.age20Tot7Y = age20Tot7Y;
	}
	public String getAge20Ml1() {
		return age20Ml1;
	}
	public void setAge20Ml1(String age20Ml1) {
		this.age20Ml1 = age20Ml1;
	}
	public String getAge20Ml2Y() {
		return age20Ml2Y;
	}
	public void setAge20Ml2Y(String age20Ml2Y) {
		this.age20Ml2Y = age20Ml2Y;
	}
	public String getAge20Ml3Y() {
		return age20Ml3Y;
	}
	public void setAge20Ml3Y(String age20Ml3Y) {
		this.age20Ml3Y = age20Ml3Y;
	}
	public String getAge20Ml4Y() {
		return age20Ml4Y;
	}
	public void setAge20Ml4Y(String age20Ml4Y) {
		this.age20Ml4Y = age20Ml4Y;
	}
	public String getAge20Ml5Y() {
		return age20Ml5Y;
	}
	public void setAge20Ml5Y(String age20Ml5Y) {
		this.age20Ml5Y = age20Ml5Y;
	}
	public String getAge20Ml6Y() {
		return age20Ml6Y;
	}
	public void setAge20Ml6Y(String age20Ml6Y) {
		this.age20Ml6Y = age20Ml6Y;
	}
	public String getAge20Ml7Y() {
		return age20Ml7Y;
	}
	public void setAge20Ml7Y(String age20Ml7Y) {
		this.age20Ml7Y = age20Ml7Y;
	}
	public String getAge20Fm1() {
		return age20Fm1;
	}
	public void setAge20Fm1(String age20Fm1) {
		this.age20Fm1 = age20Fm1;
	}
	public String getAge20Fm2Y() {
		return age20Fm2Y;
	}
	public void setAge20Fm2Y(String age20Fm2Y) {
		this.age20Fm2Y = age20Fm2Y;
	}
	public String getAge20Fm3Y() {
		return age20Fm3Y;
	}
	public void setAge20Fm3Y(String age20Fm3Y) {
		this.age20Fm3Y = age20Fm3Y;
	}
	public String getAge20Fm4Y() {
		return age20Fm4Y;
	}
	public void setAge20Fm4Y(String age20Fm4Y) {
		this.age20Fm4Y = age20Fm4Y;
	}
	public String getAge20Fm5Y() {
		return age20Fm5Y;
	}
	public void setAge20Fm5Y(String age20Fm5Y) {
		this.age20Fm5Y = age20Fm5Y;
	}
	public String getAge20Fm6Y() {
		return age20Fm6Y;
	}
	public void setAge20Fm6Y(String age20Fm6Y) {
		this.age20Fm6Y = age20Fm6Y;
	}
	public String getAge20Fm7Y() {
		return age20Fm7Y;
	}
	public void setAge20Fm7Y(String age20Fm7Y) {
		this.age20Fm7Y = age20Fm7Y;
	}
	public String getAge30Tot1() {
		return age30Tot1;
	}
	public void setAge30Tot1(String age30Tot1) {
		this.age30Tot1 = age30Tot1;
	}
	public String getAge30Tot2Y() {
		return age30Tot2Y;
	}
	public void setAge30Tot2Y(String age30Tot2Y) {
		this.age30Tot2Y = age30Tot2Y;
	}
	public String getAge30Tot3Y() {
		return age30Tot3Y;
	}
	public void setAge30Tot3Y(String age30Tot3Y) {
		this.age30Tot3Y = age30Tot3Y;
	}
	public String getAge30Tot4Y() {
		return age30Tot4Y;
	}
	public void setAge30Tot4Y(String age30Tot4Y) {
		this.age30Tot4Y = age30Tot4Y;
	}
	public String getAge30Tot5Y() {
		return age30Tot5Y;
	}
	public void setAge30Tot5Y(String age30Tot5Y) {
		this.age30Tot5Y = age30Tot5Y;
	}
	public String getAge30Tot6Y() {
		return age30Tot6Y;
	}
	public void setAge30Tot6Y(String age30Tot6Y) {
		this.age30Tot6Y = age30Tot6Y;
	}
	public String getAge30Tot7Y() {
		return age30Tot7Y;
	}
	public void setAge30Tot7Y(String age30Tot7Y) {
		this.age30Tot7Y = age30Tot7Y;
	}
	public String getAge30Ml1() {
		return age30Ml1;
	}
	public void setAge30Ml1(String age30Ml1) {
		this.age30Ml1 = age30Ml1;
	}
	public String getAge30Ml2Y() {
		return age30Ml2Y;
	}
	public void setAge30Ml2Y(String age30Ml2Y) {
		this.age30Ml2Y = age30Ml2Y;
	}
	public String getAge30Ml3Y() {
		return age30Ml3Y;
	}
	public void setAge30Ml3Y(String age30Ml3Y) {
		this.age30Ml3Y = age30Ml3Y;
	}
	public String getAge30Ml4Y() {
		return age30Ml4Y;
	}
	public void setAge30Ml4Y(String age30Ml4Y) {
		this.age30Ml4Y = age30Ml4Y;
	}
	public String getAge30Ml5Y() {
		return age30Ml5Y;
	}
	public void setAge30Ml5Y(String age30Ml5Y) {
		this.age30Ml5Y = age30Ml5Y;
	}
	public String getAge30Ml6Y() {
		return age30Ml6Y;
	}
	public void setAge30Ml6Y(String age30Ml6Y) {
		this.age30Ml6Y = age30Ml6Y;
	}
	public String getAge30Ml7Y() {
		return age30Ml7Y;
	}
	public void setAge30Ml7Y(String age30Ml7Y) {
		this.age30Ml7Y = age30Ml7Y;
	}
	public String getAge30Fm1() {
		return age30Fm1;
	}
	public void setAge30Fm1(String age30Fm1) {
		this.age30Fm1 = age30Fm1;
	}
	public String getAge30Fm2Y() {
		return age30Fm2Y;
	}
	public void setAge30Fm2Y(String age30Fm2Y) {
		this.age30Fm2Y = age30Fm2Y;
	}
	public String getAge30Fm3Y() {
		return age30Fm3Y;
	}
	public void setAge30Fm3Y(String age30Fm3Y) {
		this.age30Fm3Y = age30Fm3Y;
	}
	public String getAge30Fm4Y() {
		return age30Fm4Y;
	}
	public void setAge30Fm4Y(String age30Fm4Y) {
		this.age30Fm4Y = age30Fm4Y;
	}
	public String getAge30Fm5Y() {
		return age30Fm5Y;
	}
	public void setAge30Fm5Y(String age30Fm5Y) {
		this.age30Fm5Y = age30Fm5Y;
	}
	public String getAge30Fm6Y() {
		return age30Fm6Y;
	}
	public void setAge30Fm6Y(String age30Fm6Y) {
		this.age30Fm6Y = age30Fm6Y;
	}
	public String getAge30Fm7Y() {
		return age30Fm7Y;
	}
	public void setAge30Fm7Y(String age30Fm7Y) {
		this.age30Fm7Y = age30Fm7Y;
	}
	public String getAge40Tot1() {
		return age40Tot1;
	}
	public void setAge40Tot1(String age40Tot1) {
		this.age40Tot1 = age40Tot1;
	}
	public String getAge40Tot2Y() {
		return age40Tot2Y;
	}
	public void setAge40Tot2Y(String age40Tot2Y) {
		this.age40Tot2Y = age40Tot2Y;
	}
	public String getAge40Tot3Y() {
		return age40Tot3Y;
	}
	public void setAge40Tot3Y(String age40Tot3Y) {
		this.age40Tot3Y = age40Tot3Y;
	}
	public String getAge40Tot4Y() {
		return age40Tot4Y;
	}
	public void setAge40Tot4Y(String age40Tot4Y) {
		this.age40Tot4Y = age40Tot4Y;
	}
	public String getAge40Tot5Y() {
		return age40Tot5Y;
	}
	public void setAge40Tot5Y(String age40Tot5Y) {
		this.age40Tot5Y = age40Tot5Y;
	}
	public String getAge40Tot6Y() {
		return age40Tot6Y;
	}
	public void setAge40Tot6Y(String age40Tot6Y) {
		this.age40Tot6Y = age40Tot6Y;
	}
	public String getAge40Tot7Y() {
		return age40Tot7Y;
	}
	public void setAge40Tot7Y(String age40Tot7Y) {
		this.age40Tot7Y = age40Tot7Y;
	}
	public String getAge40Ml1() {
		return age40Ml1;
	}
	public void setAge40Ml1(String age40Ml1) {
		this.age40Ml1 = age40Ml1;
	}
	public String getAge40Ml2Y() {
		return age40Ml2Y;
	}
	public void setAge40Ml2Y(String age40Ml2Y) {
		this.age40Ml2Y = age40Ml2Y;
	}
	public String getAge40Ml3Y() {
		return age40Ml3Y;
	}
	public void setAge40Ml3Y(String age40Ml3Y) {
		this.age40Ml3Y = age40Ml3Y;
	}
	public String getAge40Ml4Y() {
		return age40Ml4Y;
	}
	public void setAge40Ml4Y(String age40Ml4Y) {
		this.age40Ml4Y = age40Ml4Y;
	}
	public String getAge40Ml5Y() {
		return age40Ml5Y;
	}
	public void setAge40Ml5Y(String age40Ml5Y) {
		this.age40Ml5Y = age40Ml5Y;
	}
	public String getAge40Ml6Y() {
		return age40Ml6Y;
	}
	public void setAge40Ml6Y(String age40Ml6Y) {
		this.age40Ml6Y = age40Ml6Y;
	}
	public String getAge40Ml7Y() {
		return age40Ml7Y;
	}
	public void setAge40Ml7Y(String age40Ml7Y) {
		this.age40Ml7Y = age40Ml7Y;
	}
	public String getAge40Fm1() {
		return age40Fm1;
	}
	public void setAge40Fm1(String age40Fm1) {
		this.age40Fm1 = age40Fm1;
	}
	public String getAge40Fm2Y() {
		return age40Fm2Y;
	}
	public void setAge40Fm2Y(String age40Fm2Y) {
		this.age40Fm2Y = age40Fm2Y;
	}
	public String getAge40Fm3Y() {
		return age40Fm3Y;
	}
	public void setAge40Fm3Y(String age40Fm3Y) {
		this.age40Fm3Y = age40Fm3Y;
	}
	public String getAge40Fm4Y() {
		return age40Fm4Y;
	}
	public void setAge40Fm4Y(String age40Fm4Y) {
		this.age40Fm4Y = age40Fm4Y;
	}
	public String getAge40Fm5Y() {
		return age40Fm5Y;
	}
	public void setAge40Fm5Y(String age40Fm5Y) {
		this.age40Fm5Y = age40Fm5Y;
	}
	public String getAge40Fm6Y() {
		return age40Fm6Y;
	}
	public void setAge40Fm6Y(String age40Fm6Y) {
		this.age40Fm6Y = age40Fm6Y;
	}
	public String getAge40Fm7Y() {
		return age40Fm7Y;
	}
	public void setAge40Fm7Y(String age40Fm7Y) {
		this.age40Fm7Y = age40Fm7Y;
	}
	public String getAge50Tot1() {
		return age50Tot1;
	}
	public void setAge50Tot1(String age50Tot1) {
		this.age50Tot1 = age50Tot1;
	}
	public String getAge50Tot2Y() {
		return age50Tot2Y;
	}
	public void setAge50Tot2Y(String age50Tot2Y) {
		this.age50Tot2Y = age50Tot2Y;
	}
	public String getAge50Tot3Y() {
		return age50Tot3Y;
	}
	public void setAge50Tot3Y(String age50Tot3Y) {
		this.age50Tot3Y = age50Tot3Y;
	}
	public String getAge50Tot4Y() {
		return age50Tot4Y;
	}
	public void setAge50Tot4Y(String age50Tot4Y) {
		this.age50Tot4Y = age50Tot4Y;
	}
	public String getAge50Tot5Y() {
		return age50Tot5Y;
	}
	public void setAge50Tot5Y(String age50Tot5Y) {
		this.age50Tot5Y = age50Tot5Y;
	}
	public String getAge50Tot6Y() {
		return age50Tot6Y;
	}
	public void setAge50Tot6Y(String age50Tot6Y) {
		this.age50Tot6Y = age50Tot6Y;
	}
	public String getAge50Tot7Y() {
		return age50Tot7Y;
	}
	public void setAge50Tot7Y(String age50Tot7Y) {
		this.age50Tot7Y = age50Tot7Y;
	}
	public String getAge50Ml1() {
		return age50Ml1;
	}
	public void setAge50Ml1(String age50Ml1) {
		this.age50Ml1 = age50Ml1;
	}
	public String getAge50Ml2Y() {
		return age50Ml2Y;
	}
	public void setAge50Ml2Y(String age50Ml2Y) {
		this.age50Ml2Y = age50Ml2Y;
	}
	public String getAge50Ml3Y() {
		return age50Ml3Y;
	}
	public void setAge50Ml3Y(String age50Ml3Y) {
		this.age50Ml3Y = age50Ml3Y;
	}
	public String getAge50Ml4Y() {
		return age50Ml4Y;
	}
	public void setAge50Ml4Y(String age50Ml4Y) {
		this.age50Ml4Y = age50Ml4Y;
	}
	public String getAge50Ml5Y() {
		return age50Ml5Y;
	}
	public void setAge50Ml5Y(String age50Ml5Y) {
		this.age50Ml5Y = age50Ml5Y;
	}
	public String getAge50Ml6Y() {
		return age50Ml6Y;
	}
	public void setAge50Ml6Y(String age50Ml6Y) {
		this.age50Ml6Y = age50Ml6Y;
	}
	public String getAge50Ml7Y() {
		return age50Ml7Y;
	}
	public void setAge50Ml7Y(String age50Ml7Y) {
		this.age50Ml7Y = age50Ml7Y;
	}
	public String getAge50Fm1() {
		return age50Fm1;
	}
	public void setAge50Fm1(String age50Fm1) {
		this.age50Fm1 = age50Fm1;
	}
	public String getAge50Fm2Y() {
		return age50Fm2Y;
	}
	public void setAge50Fm2Y(String age50Fm2Y) {
		this.age50Fm2Y = age50Fm2Y;
	}
	public String getAge50Fm3Y() {
		return age50Fm3Y;
	}
	public void setAge50Fm3Y(String age50Fm3Y) {
		this.age50Fm3Y = age50Fm3Y;
	}
	public String getAge50Fm4Y() {
		return age50Fm4Y;
	}
	public void setAge50Fm4Y(String age50Fm4Y) {
		this.age50Fm4Y = age50Fm4Y;
	}
	public String getAge50Fm5Y() {
		return age50Fm5Y;
	}
	public void setAge50Fm5Y(String age50Fm5Y) {
		this.age50Fm5Y = age50Fm5Y;
	}
	public String getAge50Fm6Y() {
		return age50Fm6Y;
	}
	public void setAge50Fm6Y(String age50Fm6Y) {
		this.age50Fm6Y = age50Fm6Y;
	}
	public String getAge50Fm7Y() {
		return age50Fm7Y;
	}
	public void setAge50Fm7Y(String age50Fm7Y) {
		this.age50Fm7Y = age50Fm7Y;
	}
	public String getAge60Tot1() {
		return age60Tot1;
	}
	public void setAge60Tot1(String age60Tot1) {
		this.age60Tot1 = age60Tot1;
	}
	public String getAge60Tot2Y() {
		return age60Tot2Y;
	}
	public void setAge60Tot2Y(String age60Tot2Y) {
		this.age60Tot2Y = age60Tot2Y;
	}
	public String getAge60Tot3Y() {
		return age60Tot3Y;
	}
	public void setAge60Tot3Y(String age60Tot3Y) {
		this.age60Tot3Y = age60Tot3Y;
	}
	public String getAge60Tot4Y() {
		return age60Tot4Y;
	}
	public void setAge60Tot4Y(String age60Tot4Y) {
		this.age60Tot4Y = age60Tot4Y;
	}
	public String getAge60Tot5Y() {
		return age60Tot5Y;
	}
	public void setAge60Tot5Y(String age60Tot5Y) {
		this.age60Tot5Y = age60Tot5Y;
	}
	public String getAge60Tot6Y() {
		return age60Tot6Y;
	}
	public void setAge60Tot6Y(String age60Tot6Y) {
		this.age60Tot6Y = age60Tot6Y;
	}
	public String getAge60Tot7Y() {
		return age60Tot7Y;
	}
	public void setAge60Tot7Y(String age60Tot7Y) {
		this.age60Tot7Y = age60Tot7Y;
	}
	public String getAge60Ml1() {
		return age60Ml1;
	}
	public void setAge60Ml1(String age60Ml1) {
		this.age60Ml1 = age60Ml1;
	}
	public String getAge60Ml2Y() {
		return age60Ml2Y;
	}
	public void setAge60Ml2Y(String age60Ml2Y) {
		this.age60Ml2Y = age60Ml2Y;
	}
	public String getAge60Ml3Y() {
		return age60Ml3Y;
	}
	public void setAge60Ml3Y(String age60Ml3Y) {
		this.age60Ml3Y = age60Ml3Y;
	}
	public String getAge60Ml4Y() {
		return age60Ml4Y;
	}
	public void setAge60Ml4Y(String age60Ml4Y) {
		this.age60Ml4Y = age60Ml4Y;
	}
	public String getAge60Ml5Y() {
		return age60Ml5Y;
	}
	public void setAge60Ml5Y(String age60Ml5Y) {
		this.age60Ml5Y = age60Ml5Y;
	}
	public String getAge60Ml6Y() {
		return age60Ml6Y;
	}
	public void setAge60Ml6Y(String age60Ml6Y) {
		this.age60Ml6Y = age60Ml6Y;
	}
	public String getAge60Ml7Y() {
		return age60Ml7Y;
	}
	public void setAge60Ml7Y(String age60Ml7Y) {
		this.age60Ml7Y = age60Ml7Y;
	}
	public String getAge60Fm1() {
		return age60Fm1;
	}
	public void setAge60Fm1(String age60Fm1) {
		this.age60Fm1 = age60Fm1;
	}
	public String getAge60Fm2Y() {
		return age60Fm2Y;
	}
	public void setAge60Fm2Y(String age60Fm2Y) {
		this.age60Fm2Y = age60Fm2Y;
	}
	public String getAge60Fm3Y() {
		return age60Fm3Y;
	}
	public void setAge60Fm3Y(String age60Fm3Y) {
		this.age60Fm3Y = age60Fm3Y;
	}
	public String getAge60Fm4Y() {
		return age60Fm4Y;
	}
	public void setAge60Fm4Y(String age60Fm4Y) {
		this.age60Fm4Y = age60Fm4Y;
	}
	public String getAge60Fm5Y() {
		return age60Fm5Y;
	}
	public void setAge60Fm5Y(String age60Fm5Y) {
		this.age60Fm5Y = age60Fm5Y;
	}
	public String getAge60Fm6Y() {
		return age60Fm6Y;
	}
	public void setAge60Fm6Y(String age60Fm6Y) {
		this.age60Fm6Y = age60Fm6Y;
	}
	public String getAge60Fm7Y() {
		return age60Fm7Y;
	}
	public void setAge60Fm7Y(String age60Fm7Y) {
		this.age60Fm7Y = age60Fm7Y;
	}
	public String getAge70Tot1() {
		return age70Tot1;
	}
	public void setAge70Tot1(String age70Tot1) {
		this.age70Tot1 = age70Tot1;
	}
	public String getAge70Tot2Y() {
		return age70Tot2Y;
	}
	public void setAge70Tot2Y(String age70Tot2Y) {
		this.age70Tot2Y = age70Tot2Y;
	}
	public String getAge70Tot3Y() {
		return age70Tot3Y;
	}
	public void setAge70Tot3Y(String age70Tot3Y) {
		this.age70Tot3Y = age70Tot3Y;
	}
	public String getAge70Tot4Y() {
		return age70Tot4Y;
	}
	public void setAge70Tot4Y(String age70Tot4Y) {
		this.age70Tot4Y = age70Tot4Y;
	}
	public String getAge70Tot5Y() {
		return age70Tot5Y;
	}
	public void setAge70Tot5Y(String age70Tot5Y) {
		this.age70Tot5Y = age70Tot5Y;
	}
	public String getAge70Tot6Y() {
		return age70Tot6Y;
	}
	public void setAge70Tot6Y(String age70Tot6Y) {
		this.age70Tot6Y = age70Tot6Y;
	}
	public String getAge70Tot7Y() {
		return age70Tot7Y;
	}
	public void setAge70Tot7Y(String age70Tot7Y) {
		this.age70Tot7Y = age70Tot7Y;
	}
	public String getAge70Ml1() {
		return age70Ml1;
	}
	public void setAge70Ml1(String age70Ml1) {
		this.age70Ml1 = age70Ml1;
	}
	public String getAge70Ml2Y() {
		return age70Ml2Y;
	}
	public void setAge70Ml2Y(String age70Ml2Y) {
		this.age70Ml2Y = age70Ml2Y;
	}
	public String getAge70Ml3Y() {
		return age70Ml3Y;
	}
	public void setAge70Ml3Y(String age70Ml3Y) {
		this.age70Ml3Y = age70Ml3Y;
	}
	public String getAge70Ml4Y() {
		return age70Ml4Y;
	}
	public void setAge70Ml4Y(String age70Ml4Y) {
		this.age70Ml4Y = age70Ml4Y;
	}
	public String getAge70Ml5Y() {
		return age70Ml5Y;
	}
	public void setAge70Ml5Y(String age70Ml5Y) {
		this.age70Ml5Y = age70Ml5Y;
	}
	public String getAge70Ml6Y() {
		return age70Ml6Y;
	}
	public void setAge70Ml6Y(String age70Ml6Y) {
		this.age70Ml6Y = age70Ml6Y;
	}
	public String getAge70Ml7Y() {
		return age70Ml7Y;
	}
	public void setAge70Ml7Y(String age70Ml7Y) {
		this.age70Ml7Y = age70Ml7Y;
	}
	public String getAge70Fm1() {
		return age70Fm1;
	}
	public void setAge70Fm1(String age70Fm1) {
		this.age70Fm1 = age70Fm1;
	}
	public String getAge70Fm2Y() {
		return age70Fm2Y;
	}
	public void setAge70Fm2Y(String age70Fm2Y) {
		this.age70Fm2Y = age70Fm2Y;
	}
	public String getAge70Fm3Y() {
		return age70Fm3Y;
	}
	public void setAge70Fm3Y(String age70Fm3Y) {
		this.age70Fm3Y = age70Fm3Y;
	}
	public String getAge70Fm4Y() {
		return age70Fm4Y;
	}
	public void setAge70Fm4Y(String age70Fm4Y) {
		this.age70Fm4Y = age70Fm4Y;
	}
	public String getAge70Fm5Y() {
		return age70Fm5Y;
	}
	public void setAge70Fm5Y(String age70Fm5Y) {
		this.age70Fm5Y = age70Fm5Y;
	}
	public String getAge70Fm6Y() {
		return age70Fm6Y;
	}
	public void setAge70Fm6Y(String age70Fm6Y) {
		this.age70Fm6Y = age70Fm6Y;
	}
	public String getAge70Fm7Y() {
		return age70Fm7Y;
	}
	public void setAge70Fm7Y(String age70Fm7Y) {
		this.age70Fm7Y = age70Fm7Y;
	}
	public String getAge80Tot1() {
		return age80Tot1;
	}
	public void setAge80Tot1(String age80Tot1) {
		this.age80Tot1 = age80Tot1;
	}
	public String getAge80Tot2Y() {
		return age80Tot2Y;
	}
	public void setAge80Tot2Y(String age80Tot2Y) {
		this.age80Tot2Y = age80Tot2Y;
	}
	public String getAge80Tot3Y() {
		return age80Tot3Y;
	}
	public void setAge80Tot3Y(String age80Tot3Y) {
		this.age80Tot3Y = age80Tot3Y;
	}
	public String getAge80Tot4Y() {
		return age80Tot4Y;
	}
	public void setAge80Tot4Y(String age80Tot4Y) {
		this.age80Tot4Y = age80Tot4Y;
	}
	public String getAge80Tot5Y() {
		return age80Tot5Y;
	}
	public void setAge80Tot5Y(String age80Tot5Y) {
		this.age80Tot5Y = age80Tot5Y;
	}
	public String getAge80Tot6Y() {
		return age80Tot6Y;
	}
	public void setAge80Tot6Y(String age80Tot6Y) {
		this.age80Tot6Y = age80Tot6Y;
	}
	public String getAge80Tot7Y() {
		return age80Tot7Y;
	}
	public void setAge80Tot7Y(String age80Tot7Y) {
		this.age80Tot7Y = age80Tot7Y;
	}
	public String getAge80Ml1() {
		return age80Ml1;
	}
	public void setAge80Ml1(String age80Ml1) {
		this.age80Ml1 = age80Ml1;
	}
	public String getAge80Ml2Y() {
		return age80Ml2Y;
	}
	public void setAge80Ml2Y(String age80Ml2Y) {
		this.age80Ml2Y = age80Ml2Y;
	}
	public String getAge80Ml3Y() {
		return age80Ml3Y;
	}
	public void setAge80Ml3Y(String age80Ml3Y) {
		this.age80Ml3Y = age80Ml3Y;
	}
	public String getAge80Ml4Y() {
		return age80Ml4Y;
	}
	public void setAge80Ml4Y(String age80Ml4Y) {
		this.age80Ml4Y = age80Ml4Y;
	}
	public String getAge80Ml5Y() {
		return age80Ml5Y;
	}
	public void setAge80Ml5Y(String age80Ml5Y) {
		this.age80Ml5Y = age80Ml5Y;
	}
	public String getAge80Ml6Y() {
		return age80Ml6Y;
	}
	public void setAge80Ml6Y(String age80Ml6Y) {
		this.age80Ml6Y = age80Ml6Y;
	}
	public String getAge80Ml7Y() {
		return age80Ml7Y;
	}
	public void setAge80Ml7Y(String age80Ml7Y) {
		this.age80Ml7Y = age80Ml7Y;
	}
	public String getAge80Fm1() {
		return age80Fm1;
	}
	public void setAge80Fm1(String age80Fm1) {
		this.age80Fm1 = age80Fm1;
	}
	public String getAge80Fm2Y() {
		return age80Fm2Y;
	}
	public void setAge80Fm2Y(String age80Fm2Y) {
		this.age80Fm2Y = age80Fm2Y;
	}
	public String getAge80Fm3Y() {
		return age80Fm3Y;
	}
	public void setAge80Fm3Y(String age80Fm3Y) {
		this.age80Fm3Y = age80Fm3Y;
	}
	public String getAge80Fm4Y() {
		return age80Fm4Y;
	}
	public void setAge80Fm4Y(String age80Fm4Y) {
		this.age80Fm4Y = age80Fm4Y;
	}
	public String getAge80Fm5Y() {
		return age80Fm5Y;
	}
	public void setAge80Fm5Y(String age80Fm5Y) {
		this.age80Fm5Y = age80Fm5Y;
	}
	public String getAge80Fm6Y() {
		return age80Fm6Y;
	}
	public void setAge80Fm6Y(String age80Fm6Y) {
		this.age80Fm6Y = age80Fm6Y;
	}
	public String getAge80Fm7Y() {
		return age80Fm7Y;
	}
	public void setAge80Fm7Y(String age80Fm7Y) {
		this.age80Fm7Y = age80Fm7Y;
	}
	public String getAge90Tot1() {
		return age90Tot1;
	}
	public void setAge90Tot1(String age90Tot1) {
		this.age90Tot1 = age90Tot1;
	}
	public String getAge90Tot2Y() {
		return age90Tot2Y;
	}
	public void setAge90Tot2Y(String age90Tot2Y) {
		this.age90Tot2Y = age90Tot2Y;
	}
	public String getAge90Tot3Y() {
		return age90Tot3Y;
	}
	public void setAge90Tot3Y(String age90Tot3Y) {
		this.age90Tot3Y = age90Tot3Y;
	}
	public String getAge90Tot4Y() {
		return age90Tot4Y;
	}
	public void setAge90Tot4Y(String age90Tot4Y) {
		this.age90Tot4Y = age90Tot4Y;
	}
	public String getAge90Tot5Y() {
		return age90Tot5Y;
	}
	public void setAge90Tot5Y(String age90Tot5Y) {
		this.age90Tot5Y = age90Tot5Y;
	}
	public String getAge90Tot6Y() {
		return age90Tot6Y;
	}
	public void setAge90Tot6Y(String age90Tot6Y) {
		this.age90Tot6Y = age90Tot6Y;
	}
	public String getAge90Tot7Y() {
		return age90Tot7Y;
	}
	public void setAge90Tot7Y(String age90Tot7Y) {
		this.age90Tot7Y = age90Tot7Y;
	}
	public String getAge90Ml1() {
		return age90Ml1;
	}
	public void setAge90Ml1(String age90Ml1) {
		this.age90Ml1 = age90Ml1;
	}
	public String getAge90Ml2Y() {
		return age90Ml2Y;
	}
	public void setAge90Ml2Y(String age90Ml2Y) {
		this.age90Ml2Y = age90Ml2Y;
	}
	public String getAge90Ml3Y() {
		return age90Ml3Y;
	}
	public void setAge90Ml3Y(String age90Ml3Y) {
		this.age90Ml3Y = age90Ml3Y;
	}
	public String getAge90Ml4Y() {
		return age90Ml4Y;
	}
	public void setAge90Ml4Y(String age90Ml4Y) {
		this.age90Ml4Y = age90Ml4Y;
	}
	public String getAge90Ml5Y() {
		return age90Ml5Y;
	}
	public void setAge90Ml5Y(String age90Ml5Y) {
		this.age90Ml5Y = age90Ml5Y;
	}
	public String getAge90Ml6Y() {
		return age90Ml6Y;
	}
	public void setAge90Ml6Y(String age90Ml6Y) {
		this.age90Ml6Y = age90Ml6Y;
	}
	public String getAge90Ml7Y() {
		return age90Ml7Y;
	}
	public void setAge90Ml7Y(String age90Ml7Y) {
		this.age90Ml7Y = age90Ml7Y;
	}
	public String getAge90Fm1() {
		return age90Fm1;
	}
	public void setAge90Fm1(String age90Fm1) {
		this.age90Fm1 = age90Fm1;
	}
	public String getAge90Fm2Y() {
		return age90Fm2Y;
	}
	public void setAge90Fm2Y(String age90Fm2Y) {
		this.age90Fm2Y = age90Fm2Y;
	}
	public String getAge90Fm3Y() {
		return age90Fm3Y;
	}
	public void setAge90Fm3Y(String age90Fm3Y) {
		this.age90Fm3Y = age90Fm3Y;
	}
	public String getAge90Fm4Y() {
		return age90Fm4Y;
	}
	public void setAge90Fm4Y(String age90Fm4Y) {
		this.age90Fm4Y = age90Fm4Y;
	}
	public String getAge90Fm5Y() {
		return age90Fm5Y;
	}
	public void setAge90Fm5Y(String age90Fm5Y) {
		this.age90Fm5Y = age90Fm5Y;
	}
	public String getAge90Fm6Y() {
		return age90Fm6Y;
	}
	public void setAge90Fm6Y(String age90Fm6Y) {
		this.age90Fm6Y = age90Fm6Y;
	}
	public String getAge90Fm7Y() {
		return age90Fm7Y;
	}
	public void setAge90Fm7Y(String age90Fm7Y) {
		this.age90Fm7Y = age90Fm7Y;
	}
	public String getAge100Tot1() {
		return age100Tot1;
	}
	public void setAge100Tot1(String age100Tot1) {
		this.age100Tot1 = age100Tot1;
	}
	public String getAge100Tot2Y() {
		return age100Tot2Y;
	}
	public void setAge100Tot2Y(String age100Tot2Y) {
		this.age100Tot2Y = age100Tot2Y;
	}
	public String getAge100Tot3Y() {
		return age100Tot3Y;
	}
	public void setAge100Tot3Y(String age100Tot3Y) {
		this.age100Tot3Y = age100Tot3Y;
	}
	public String getAge100Tot4Y() {
		return age100Tot4Y;
	}
	public void setAge100Tot4Y(String age100Tot4Y) {
		this.age100Tot4Y = age100Tot4Y;
	}
	public String getAge100Tot5Y() {
		return age100Tot5Y;
	}
	public void setAge100Tot5Y(String age100Tot5Y) {
		this.age100Tot5Y = age100Tot5Y;
	}
	public String getAge100Tot6Y() {
		return age100Tot6Y;
	}
	public void setAge100Tot6Y(String age100Tot6Y) {
		this.age100Tot6Y = age100Tot6Y;
	}
	public String getAge100Tot7Y() {
		return age100Tot7Y;
	}
	public void setAge100Tot7Y(String age100Tot7Y) {
		this.age100Tot7Y = age100Tot7Y;
	}
	public String getAge100Ml1() {
		return age100Ml1;
	}
	public void setAge100Ml1(String age100Ml1) {
		this.age100Ml1 = age100Ml1;
	}
	public String getAge100Ml2Y() {
		return age100Ml2Y;
	}
	public void setAge100Ml2Y(String age100Ml2Y) {
		this.age100Ml2Y = age100Ml2Y;
	}
	public String getAge100Ml3Y() {
		return age100Ml3Y;
	}
	public void setAge100Ml3Y(String age100Ml3Y) {
		this.age100Ml3Y = age100Ml3Y;
	}
	public String getAge100Ml4Y() {
		return age100Ml4Y;
	}
	public void setAge100Ml4Y(String age100Ml4Y) {
		this.age100Ml4Y = age100Ml4Y;
	}
	public String getAge100Ml5Y() {
		return age100Ml5Y;
	}
	public void setAge100Ml5Y(String age100Ml5Y) {
		this.age100Ml5Y = age100Ml5Y;
	}
	public String getAge100Ml6Y() {
		return age100Ml6Y;
	}
	public void setAge100Ml6Y(String age100Ml6Y) {
		this.age100Ml6Y = age100Ml6Y;
	}
	public String getAge100Ml7Y() {
		return age100Ml7Y;
	}
	public void setAge100Ml7Y(String age100Ml7Y) {
		this.age100Ml7Y = age100Ml7Y;
	}
	public String getAge100Fm1() {
		return age100Fm1;
	}
	public void setAge100Fm1(String age100Fm1) {
		this.age100Fm1 = age100Fm1;
	}
	public String getAge100Fm2Y() {
		return age100Fm2Y;
	}
	public void setAge100Fm2Y(String age100Fm2Y) {
		this.age100Fm2Y = age100Fm2Y;
	}
	public String getAge100Fm3Y() {
		return age100Fm3Y;
	}
	public void setAge100Fm3Y(String age100Fm3Y) {
		this.age100Fm3Y = age100Fm3Y;
	}
	public String getAge100Fm4Y() {
		return age100Fm4Y;
	}
	public void setAge100Fm4Y(String age100Fm4Y) {
		this.age100Fm4Y = age100Fm4Y;
	}
	public String getAge100Fm5Y() {
		return age100Fm5Y;
	}
	public void setAge100Fm5Y(String age100Fm5Y) {
		this.age100Fm5Y = age100Fm5Y;
	}
	public String getAge100Fm6Y() {
		return age100Fm6Y;
	}
	public void setAge100Fm6Y(String age100Fm6Y) {
		this.age100Fm6Y = age100Fm6Y;
	}
	public String getAge100Fm7Y() {
		return age100Fm7Y;
	}
	public void setAge100Fm7Y(String age100Fm7Y) {
		this.age100Fm7Y = age100Fm7Y;
	}
	public String getDstrNm() {
		return dstrNm;
	}
	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}
	public String getPrvicNm() {
		return prvicNm;
	}
	public void setPrvicNm(String prvicNm) {
		this.prvicNm = prvicNm;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getStsTitCd() {
		return stsTitCd;
	}
	public void setStsTitCd(String stsTitCd) {
		this.stsTitCd = stsTitCd;
	}
	public String getStsTitNm() {
		return stsTitNm;
	}
	public void setStsTitNm(String stsTitNm) {
		this.stsTitNm = stsTitNm;
	}
	public String getAdCd() {
		return adCd;
	}
	public void setAdCd(String adCd) {
		this.adCd = adCd;
	}
	public String getAdCdNm() {
		return adCdNm;
	}
	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}
	public String getAge0Tot2N() {
		return age0Tot2N;
	}
	public void setAge0Tot2N(String age0Tot2N) {
		this.age0Tot2N = age0Tot2N;
	}
	public String getAge0Tot3N() {
		return age0Tot3N;
	}
	public void setAge0Tot3N(String age0Tot3N) {
		this.age0Tot3N = age0Tot3N;
	}
	public String getAge0Tot4N() {
		return age0Tot4N;
	}
	public void setAge0Tot4N(String age0Tot4N) {
		this.age0Tot4N = age0Tot4N;
	}
	public String getAge0Tot5N() {
		return age0Tot5N;
	}
	public void setAge0Tot5N(String age0Tot5N) {
		this.age0Tot5N = age0Tot5N;
	}
	public String getAge0Tot6N() {
		return age0Tot6N;
	}
	public void setAge0Tot6N(String age0Tot6N) {
		this.age0Tot6N = age0Tot6N;
	}
	public String getAge0Tot7N() {
		return age0Tot7N;
	}
	public void setAge0Tot7N(String age0Tot7N) {
		this.age0Tot7N = age0Tot7N;
	}
	public String getAge0Ml2N() {
		return age0Ml2N;
	}
	public void setAge0Ml2N(String age0Ml2N) {
		this.age0Ml2N = age0Ml2N;
	}
	public String getAge0Ml3N() {
		return age0Ml3N;
	}
	public void setAge0Ml3N(String age0Ml3N) {
		this.age0Ml3N = age0Ml3N;
	}
	public String getAge0Ml4N() {
		return age0Ml4N;
	}
	public void setAge0Ml4N(String age0Ml4N) {
		this.age0Ml4N = age0Ml4N;
	}
	public String getAge0Ml5N() {
		return age0Ml5N;
	}
	public void setAge0Ml5N(String age0Ml5N) {
		this.age0Ml5N = age0Ml5N;
	}
	public String getAge0Ml6N() {
		return age0Ml6N;
	}
	public void setAge0Ml6N(String age0Ml6N) {
		this.age0Ml6N = age0Ml6N;
	}
	public String getAge0Ml7N() {
		return age0Ml7N;
	}
	public void setAge0Ml7N(String age0Ml7N) {
		this.age0Ml7N = age0Ml7N;
	}
	public String getAge0Fm2N() {
		return age0Fm2N;
	}
	public void setAge0Fm2N(String age0Fm2N) {
		this.age0Fm2N = age0Fm2N;
	}
	public String getAge0Fm3N() {
		return age0Fm3N;
	}
	public void setAge0Fm3N(String age0Fm3N) {
		this.age0Fm3N = age0Fm3N;
	}
	public String getAge0Fm4N() {
		return age0Fm4N;
	}
	public void setAge0Fm4N(String age0Fm4N) {
		this.age0Fm4N = age0Fm4N;
	}
	public String getAge0Fm5N() {
		return age0Fm5N;
	}
	public void setAge0Fm5N(String age0Fm5N) {
		this.age0Fm5N = age0Fm5N;
	}
	public String getAge0Fm6N() {
		return age0Fm6N;
	}
	public void setAge0Fm6N(String age0Fm6N) {
		this.age0Fm6N = age0Fm6N;
	}
	public String getAge0Fm7N() {
		return age0Fm7N;
	}
	public void setAge0Fm7N(String age0Fm7N) {
		this.age0Fm7N = age0Fm7N;
	}
	public String getAge10Tot2N() {
		return age10Tot2N;
	}
	public void setAge10Tot2N(String age10Tot2N) {
		this.age10Tot2N = age10Tot2N;
	}
	public String getAge10Tot3N() {
		return age10Tot3N;
	}
	public void setAge10Tot3N(String age10Tot3N) {
		this.age10Tot3N = age10Tot3N;
	}
	public String getAge10Tot4N() {
		return age10Tot4N;
	}
	public void setAge10Tot4N(String age10Tot4N) {
		this.age10Tot4N = age10Tot4N;
	}
	public String getAge10Tot5N() {
		return age10Tot5N;
	}
	public void setAge10Tot5N(String age10Tot5N) {
		this.age10Tot5N = age10Tot5N;
	}
	public String getAge10Tot6N() {
		return age10Tot6N;
	}
	public void setAge10Tot6N(String age10Tot6N) {
		this.age10Tot6N = age10Tot6N;
	}
	public String getAge10Tot7N() {
		return age10Tot7N;
	}
	public void setAge10Tot7N(String age10Tot7N) {
		this.age10Tot7N = age10Tot7N;
	}
	public String getAge10Ml2N() {
		return age10Ml2N;
	}
	public void setAge10Ml2N(String age10Ml2N) {
		this.age10Ml2N = age10Ml2N;
	}
	public String getAge10Ml3N() {
		return age10Ml3N;
	}
	public void setAge10Ml3N(String age10Ml3N) {
		this.age10Ml3N = age10Ml3N;
	}
	public String getAge10Ml4N() {
		return age10Ml4N;
	}
	public void setAge10Ml4N(String age10Ml4N) {
		this.age10Ml4N = age10Ml4N;
	}
	public String getAge10Ml5N() {
		return age10Ml5N;
	}
	public void setAge10Ml5N(String age10Ml5N) {
		this.age10Ml5N = age10Ml5N;
	}
	public String getAge10Ml6N() {
		return age10Ml6N;
	}
	public void setAge10Ml6N(String age10Ml6N) {
		this.age10Ml6N = age10Ml6N;
	}
	public String getAge10Ml7N() {
		return age10Ml7N;
	}
	public void setAge10Ml7N(String age10Ml7N) {
		this.age10Ml7N = age10Ml7N;
	}
	public String getAge10Fm2N() {
		return age10Fm2N;
	}
	public void setAge10Fm2N(String age10Fm2N) {
		this.age10Fm2N = age10Fm2N;
	}
	public String getAge10Fm3N() {
		return age10Fm3N;
	}
	public void setAge10Fm3N(String age10Fm3N) {
		this.age10Fm3N = age10Fm3N;
	}
	public String getAge10Fm4N() {
		return age10Fm4N;
	}
	public void setAge10Fm4N(String age10Fm4N) {
		this.age10Fm4N = age10Fm4N;
	}
	public String getAge10Fm5N() {
		return age10Fm5N;
	}
	public void setAge10Fm5N(String age10Fm5N) {
		this.age10Fm5N = age10Fm5N;
	}
	public String getAge10Fm6N() {
		return age10Fm6N;
	}
	public void setAge10Fm6N(String age10Fm6N) {
		this.age10Fm6N = age10Fm6N;
	}
	public String getAge10Fm7N() {
		return age10Fm7N;
	}
	public void setAge10Fm7N(String age10Fm7N) {
		this.age10Fm7N = age10Fm7N;
	}
	public String getAge20Tot2N() {
		return age20Tot2N;
	}
	public void setAge20Tot2N(String age20Tot2N) {
		this.age20Tot2N = age20Tot2N;
	}
	public String getAge20Tot3N() {
		return age20Tot3N;
	}
	public void setAge20Tot3N(String age20Tot3N) {
		this.age20Tot3N = age20Tot3N;
	}
	public String getAge20Tot4N() {
		return age20Tot4N;
	}
	public void setAge20Tot4N(String age20Tot4N) {
		this.age20Tot4N = age20Tot4N;
	}
	public String getAge20Tot5N() {
		return age20Tot5N;
	}
	public void setAge20Tot5N(String age20Tot5N) {
		this.age20Tot5N = age20Tot5N;
	}
	public String getAge20Tot6N() {
		return age20Tot6N;
	}
	public void setAge20Tot6N(String age20Tot6N) {
		this.age20Tot6N = age20Tot6N;
	}
	public String getAge20Tot7N() {
		return age20Tot7N;
	}
	public void setAge20Tot7N(String age20Tot7N) {
		this.age20Tot7N = age20Tot7N;
	}
	public String getAge20Ml2N() {
		return age20Ml2N;
	}
	public void setAge20Ml2N(String age20Ml2N) {
		this.age20Ml2N = age20Ml2N;
	}
	public String getAge20Ml3N() {
		return age20Ml3N;
	}
	public void setAge20Ml3N(String age20Ml3N) {
		this.age20Ml3N = age20Ml3N;
	}
	public String getAge20Ml4N() {
		return age20Ml4N;
	}
	public void setAge20Ml4N(String age20Ml4N) {
		this.age20Ml4N = age20Ml4N;
	}
	public String getAge20Ml5N() {
		return age20Ml5N;
	}
	public void setAge20Ml5N(String age20Ml5N) {
		this.age20Ml5N = age20Ml5N;
	}
	public String getAge20Ml6N() {
		return age20Ml6N;
	}
	public void setAge20Ml6N(String age20Ml6N) {
		this.age20Ml6N = age20Ml6N;
	}
	public String getAge20Ml7N() {
		return age20Ml7N;
	}
	public void setAge20Ml7N(String age20Ml7N) {
		this.age20Ml7N = age20Ml7N;
	}
	public String getAge20Fm2N() {
		return age20Fm2N;
	}
	public void setAge20Fm2N(String age20Fm2N) {
		this.age20Fm2N = age20Fm2N;
	}
	public String getAge20Fm3N() {
		return age20Fm3N;
	}
	public void setAge20Fm3N(String age20Fm3N) {
		this.age20Fm3N = age20Fm3N;
	}
	public String getAge20Fm4N() {
		return age20Fm4N;
	}
	public void setAge20Fm4N(String age20Fm4N) {
		this.age20Fm4N = age20Fm4N;
	}
	public String getAge20Fm5N() {
		return age20Fm5N;
	}
	public void setAge20Fm5N(String age20Fm5N) {
		this.age20Fm5N = age20Fm5N;
	}
	public String getAge20Fm6N() {
		return age20Fm6N;
	}
	public void setAge20Fm6N(String age20Fm6N) {
		this.age20Fm6N = age20Fm6N;
	}
	public String getAge20Fm7N() {
		return age20Fm7N;
	}
	public void setAge20Fm7N(String age20Fm7N) {
		this.age20Fm7N = age20Fm7N;
	}
	public String getAge30Tot2N() {
		return age30Tot2N;
	}
	public void setAge30Tot2N(String age30Tot2N) {
		this.age30Tot2N = age30Tot2N;
	}
	public String getAge30Tot3N() {
		return age30Tot3N;
	}
	public void setAge30Tot3N(String age30Tot3N) {
		this.age30Tot3N = age30Tot3N;
	}
	public String getAge30Tot4N() {
		return age30Tot4N;
	}
	public void setAge30Tot4N(String age30Tot4N) {
		this.age30Tot4N = age30Tot4N;
	}
	public String getAge30Tot5N() {
		return age30Tot5N;
	}
	public void setAge30Tot5N(String age30Tot5N) {
		this.age30Tot5N = age30Tot5N;
	}
	public String getAge30Tot6N() {
		return age30Tot6N;
	}
	public void setAge30Tot6N(String age30Tot6N) {
		this.age30Tot6N = age30Tot6N;
	}
	public String getAge30Tot7N() {
		return age30Tot7N;
	}
	public void setAge30Tot7N(String age30Tot7N) {
		this.age30Tot7N = age30Tot7N;
	}
	public String getAge30Ml2N() {
		return age30Ml2N;
	}
	public void setAge30Ml2N(String age30Ml2N) {
		this.age30Ml2N = age30Ml2N;
	}
	public String getAge30Ml3N() {
		return age30Ml3N;
	}
	public void setAge30Ml3N(String age30Ml3N) {
		this.age30Ml3N = age30Ml3N;
	}
	public String getAge30Ml4N() {
		return age30Ml4N;
	}
	public void setAge30Ml4N(String age30Ml4N) {
		this.age30Ml4N = age30Ml4N;
	}
	public String getAge30Ml5N() {
		return age30Ml5N;
	}
	public void setAge30Ml5N(String age30Ml5N) {
		this.age30Ml5N = age30Ml5N;
	}
	public String getAge30Ml6N() {
		return age30Ml6N;
	}
	public void setAge30Ml6N(String age30Ml6N) {
		this.age30Ml6N = age30Ml6N;
	}
	public String getAge30Ml7N() {
		return age30Ml7N;
	}
	public void setAge30Ml7N(String age30Ml7N) {
		this.age30Ml7N = age30Ml7N;
	}
	public String getAge30Fm2N() {
		return age30Fm2N;
	}
	public void setAge30Fm2N(String age30Fm2N) {
		this.age30Fm2N = age30Fm2N;
	}
	public String getAge30Fm3N() {
		return age30Fm3N;
	}
	public void setAge30Fm3N(String age30Fm3N) {
		this.age30Fm3N = age30Fm3N;
	}
	public String getAge30Fm4N() {
		return age30Fm4N;
	}
	public void setAge30Fm4N(String age30Fm4N) {
		this.age30Fm4N = age30Fm4N;
	}
	public String getAge30Fm5N() {
		return age30Fm5N;
	}
	public void setAge30Fm5N(String age30Fm5N) {
		this.age30Fm5N = age30Fm5N;
	}
	public String getAge30Fm6N() {
		return age30Fm6N;
	}
	public void setAge30Fm6N(String age30Fm6N) {
		this.age30Fm6N = age30Fm6N;
	}
	public String getAge30Fm7N() {
		return age30Fm7N;
	}
	public void setAge30Fm7N(String age30Fm7N) {
		this.age30Fm7N = age30Fm7N;
	}
	public String getAge40Tot2N() {
		return age40Tot2N;
	}
	public void setAge40Tot2N(String age40Tot2N) {
		this.age40Tot2N = age40Tot2N;
	}
	public String getAge40Tot3N() {
		return age40Tot3N;
	}
	public void setAge40Tot3N(String age40Tot3N) {
		this.age40Tot3N = age40Tot3N;
	}
	public String getAge40Tot4N() {
		return age40Tot4N;
	}
	public void setAge40Tot4N(String age40Tot4N) {
		this.age40Tot4N = age40Tot4N;
	}
	public String getAge40Tot5N() {
		return age40Tot5N;
	}
	public void setAge40Tot5N(String age40Tot5N) {
		this.age40Tot5N = age40Tot5N;
	}
	public String getAge40Tot6N() {
		return age40Tot6N;
	}
	public void setAge40Tot6N(String age40Tot6N) {
		this.age40Tot6N = age40Tot6N;
	}
	public String getAge40Tot7N() {
		return age40Tot7N;
	}
	public void setAge40Tot7N(String age40Tot7N) {
		this.age40Tot7N = age40Tot7N;
	}
	public String getAge40Ml2N() {
		return age40Ml2N;
	}
	public void setAge40Ml2N(String age40Ml2N) {
		this.age40Ml2N = age40Ml2N;
	}
	public String getAge40Ml3N() {
		return age40Ml3N;
	}
	public void setAge40Ml3N(String age40Ml3N) {
		this.age40Ml3N = age40Ml3N;
	}
	public String getAge40Ml4N() {
		return age40Ml4N;
	}
	public void setAge40Ml4N(String age40Ml4N) {
		this.age40Ml4N = age40Ml4N;
	}
	public String getAge40Ml5N() {
		return age40Ml5N;
	}
	public void setAge40Ml5N(String age40Ml5N) {
		this.age40Ml5N = age40Ml5N;
	}
	public String getAge40Ml6N() {
		return age40Ml6N;
	}
	public void setAge40Ml6N(String age40Ml6N) {
		this.age40Ml6N = age40Ml6N;
	}
	public String getAge40Ml7N() {
		return age40Ml7N;
	}
	public void setAge40Ml7N(String age40Ml7N) {
		this.age40Ml7N = age40Ml7N;
	}
	public String getAge40Fm2N() {
		return age40Fm2N;
	}
	public void setAge40Fm2N(String age40Fm2N) {
		this.age40Fm2N = age40Fm2N;
	}
	public String getAge40Fm3N() {
		return age40Fm3N;
	}
	public void setAge40Fm3N(String age40Fm3N) {
		this.age40Fm3N = age40Fm3N;
	}
	public String getAge40Fm4N() {
		return age40Fm4N;
	}
	public void setAge40Fm4N(String age40Fm4N) {
		this.age40Fm4N = age40Fm4N;
	}
	public String getAge40Fm5N() {
		return age40Fm5N;
	}
	public void setAge40Fm5N(String age40Fm5N) {
		this.age40Fm5N = age40Fm5N;
	}
	public String getAge40Fm6N() {
		return age40Fm6N;
	}
	public void setAge40Fm6N(String age40Fm6N) {
		this.age40Fm6N = age40Fm6N;
	}
	public String getAge40Fm7N() {
		return age40Fm7N;
	}
	public void setAge40Fm7N(String age40Fm7N) {
		this.age40Fm7N = age40Fm7N;
	}
	public String getAge50Tot2N() {
		return age50Tot2N;
	}
	public void setAge50Tot2N(String age50Tot2N) {
		this.age50Tot2N = age50Tot2N;
	}
	public String getAge50Tot3N() {
		return age50Tot3N;
	}
	public void setAge50Tot3N(String age50Tot3N) {
		this.age50Tot3N = age50Tot3N;
	}
	public String getAge50Tot4N() {
		return age50Tot4N;
	}
	public void setAge50Tot4N(String age50Tot4N) {
		this.age50Tot4N = age50Tot4N;
	}
	public String getAge50Tot5N() {
		return age50Tot5N;
	}
	public void setAge50Tot5N(String age50Tot5N) {
		this.age50Tot5N = age50Tot5N;
	}
	public String getAge50Tot6N() {
		return age50Tot6N;
	}
	public void setAge50Tot6N(String age50Tot6N) {
		this.age50Tot6N = age50Tot6N;
	}
	public String getAge50Tot7N() {
		return age50Tot7N;
	}
	public void setAge50Tot7N(String age50Tot7N) {
		this.age50Tot7N = age50Tot7N;
	}
	public String getAge50Ml2N() {
		return age50Ml2N;
	}
	public void setAge50Ml2N(String age50Ml2N) {
		this.age50Ml2N = age50Ml2N;
	}
	public String getAge50Ml3N() {
		return age50Ml3N;
	}
	public void setAge50Ml3N(String age50Ml3N) {
		this.age50Ml3N = age50Ml3N;
	}
	public String getAge50Ml4N() {
		return age50Ml4N;
	}
	public void setAge50Ml4N(String age50Ml4N) {
		this.age50Ml4N = age50Ml4N;
	}
	public String getAge50Ml5N() {
		return age50Ml5N;
	}
	public void setAge50Ml5N(String age50Ml5N) {
		this.age50Ml5N = age50Ml5N;
	}
	public String getAge50Ml6N() {
		return age50Ml6N;
	}
	public void setAge50Ml6N(String age50Ml6N) {
		this.age50Ml6N = age50Ml6N;
	}
	public String getAge50Ml7N() {
		return age50Ml7N;
	}
	public void setAge50Ml7N(String age50Ml7N) {
		this.age50Ml7N = age50Ml7N;
	}
	public String getAge50Fm2N() {
		return age50Fm2N;
	}
	public void setAge50Fm2N(String age50Fm2N) {
		this.age50Fm2N = age50Fm2N;
	}
	public String getAge50Fm3N() {
		return age50Fm3N;
	}
	public void setAge50Fm3N(String age50Fm3N) {
		this.age50Fm3N = age50Fm3N;
	}
	public String getAge50Fm4N() {
		return age50Fm4N;
	}
	public void setAge50Fm4N(String age50Fm4N) {
		this.age50Fm4N = age50Fm4N;
	}
	public String getAge50Fm5N() {
		return age50Fm5N;
	}
	public void setAge50Fm5N(String age50Fm5N) {
		this.age50Fm5N = age50Fm5N;
	}
	public String getAge50Fm6N() {
		return age50Fm6N;
	}
	public void setAge50Fm6N(String age50Fm6N) {
		this.age50Fm6N = age50Fm6N;
	}
	public String getAge50Fm7N() {
		return age50Fm7N;
	}
	public void setAge50Fm7N(String age50Fm7N) {
		this.age50Fm7N = age50Fm7N;
	}
	public String getAge60Tot2N() {
		return age60Tot2N;
	}
	public void setAge60Tot2N(String age60Tot2N) {
		this.age60Tot2N = age60Tot2N;
	}
	public String getAge60Tot3N() {
		return age60Tot3N;
	}
	public void setAge60Tot3N(String age60Tot3N) {
		this.age60Tot3N = age60Tot3N;
	}
	public String getAge60Tot4N() {
		return age60Tot4N;
	}
	public void setAge60Tot4N(String age60Tot4N) {
		this.age60Tot4N = age60Tot4N;
	}
	public String getAge60Tot5N() {
		return age60Tot5N;
	}
	public void setAge60Tot5N(String age60Tot5N) {
		this.age60Tot5N = age60Tot5N;
	}
	public String getAge60Tot6N() {
		return age60Tot6N;
	}
	public void setAge60Tot6N(String age60Tot6N) {
		this.age60Tot6N = age60Tot6N;
	}
	public String getAge60Tot7N() {
		return age60Tot7N;
	}
	public void setAge60Tot7N(String age60Tot7N) {
		this.age60Tot7N = age60Tot7N;
	}
	public String getAge60Ml2N() {
		return age60Ml2N;
	}
	public void setAge60Ml2N(String age60Ml2N) {
		this.age60Ml2N = age60Ml2N;
	}
	public String getAge60Ml3N() {
		return age60Ml3N;
	}
	public void setAge60Ml3N(String age60Ml3N) {
		this.age60Ml3N = age60Ml3N;
	}
	public String getAge60Ml4N() {
		return age60Ml4N;
	}
	public void setAge60Ml4N(String age60Ml4N) {
		this.age60Ml4N = age60Ml4N;
	}
	public String getAge60Ml5N() {
		return age60Ml5N;
	}
	public void setAge60Ml5N(String age60Ml5N) {
		this.age60Ml5N = age60Ml5N;
	}
	public String getAge60Ml6N() {
		return age60Ml6N;
	}
	public void setAge60Ml6N(String age60Ml6N) {
		this.age60Ml6N = age60Ml6N;
	}
	public String getAge60Ml7N() {
		return age60Ml7N;
	}
	public void setAge60Ml7N(String age60Ml7N) {
		this.age60Ml7N = age60Ml7N;
	}
	public String getAge60Fm2N() {
		return age60Fm2N;
	}
	public void setAge60Fm2N(String age60Fm2N) {
		this.age60Fm2N = age60Fm2N;
	}
	public String getAge60Fm3N() {
		return age60Fm3N;
	}
	public void setAge60Fm3N(String age60Fm3N) {
		this.age60Fm3N = age60Fm3N;
	}
	public String getAge60Fm4N() {
		return age60Fm4N;
	}
	public void setAge60Fm4N(String age60Fm4N) {
		this.age60Fm4N = age60Fm4N;
	}
	public String getAge60Fm5N() {
		return age60Fm5N;
	}
	public void setAge60Fm5N(String age60Fm5N) {
		this.age60Fm5N = age60Fm5N;
	}
	public String getAge60Fm6N() {
		return age60Fm6N;
	}
	public void setAge60Fm6N(String age60Fm6N) {
		this.age60Fm6N = age60Fm6N;
	}
	public String getAge60Fm7N() {
		return age60Fm7N;
	}
	public void setAge60Fm7N(String age60Fm7N) {
		this.age60Fm7N = age60Fm7N;
	}
	public String getAge70Tot2N() {
		return age70Tot2N;
	}
	public void setAge70Tot2N(String age70Tot2N) {
		this.age70Tot2N = age70Tot2N;
	}
	public String getAge70Tot3N() {
		return age70Tot3N;
	}
	public void setAge70Tot3N(String age70Tot3N) {
		this.age70Tot3N = age70Tot3N;
	}
	public String getAge70Tot4N() {
		return age70Tot4N;
	}
	public void setAge70Tot4N(String age70Tot4N) {
		this.age70Tot4N = age70Tot4N;
	}
	public String getAge70Tot5N() {
		return age70Tot5N;
	}
	public void setAge70Tot5N(String age70Tot5N) {
		this.age70Tot5N = age70Tot5N;
	}
	public String getAge70Tot6N() {
		return age70Tot6N;
	}
	public void setAge70Tot6N(String age70Tot6N) {
		this.age70Tot6N = age70Tot6N;
	}
	public String getAge70Tot7N() {
		return age70Tot7N;
	}
	public void setAge70Tot7N(String age70Tot7N) {
		this.age70Tot7N = age70Tot7N;
	}
	public String getAge70Ml2N() {
		return age70Ml2N;
	}
	public void setAge70Ml2N(String age70Ml2N) {
		this.age70Ml2N = age70Ml2N;
	}
	public String getAge70Ml3N() {
		return age70Ml3N;
	}
	public void setAge70Ml3N(String age70Ml3N) {
		this.age70Ml3N = age70Ml3N;
	}
	public String getAge70Ml4N() {
		return age70Ml4N;
	}
	public void setAge70Ml4N(String age70Ml4N) {
		this.age70Ml4N = age70Ml4N;
	}
	public String getAge70Ml5N() {
		return age70Ml5N;
	}
	public void setAge70Ml5N(String age70Ml5N) {
		this.age70Ml5N = age70Ml5N;
	}
	public String getAge70Ml6N() {
		return age70Ml6N;
	}
	public void setAge70Ml6N(String age70Ml6N) {
		this.age70Ml6N = age70Ml6N;
	}
	public String getAge70Ml7N() {
		return age70Ml7N;
	}
	public void setAge70Ml7N(String age70Ml7N) {
		this.age70Ml7N = age70Ml7N;
	}
	public String getAge70Fm2N() {
		return age70Fm2N;
	}
	public void setAge70Fm2N(String age70Fm2N) {
		this.age70Fm2N = age70Fm2N;
	}
	public String getAge70Fm3N() {
		return age70Fm3N;
	}
	public void setAge70Fm3N(String age70Fm3N) {
		this.age70Fm3N = age70Fm3N;
	}
	public String getAge70Fm4N() {
		return age70Fm4N;
	}
	public void setAge70Fm4N(String age70Fm4N) {
		this.age70Fm4N = age70Fm4N;
	}
	public String getAge70Fm5N() {
		return age70Fm5N;
	}
	public void setAge70Fm5N(String age70Fm5N) {
		this.age70Fm5N = age70Fm5N;
	}
	public String getAge70Fm6N() {
		return age70Fm6N;
	}
	public void setAge70Fm6N(String age70Fm6N) {
		this.age70Fm6N = age70Fm6N;
	}
	public String getAge70Fm7N() {
		return age70Fm7N;
	}
	public void setAge70Fm7N(String age70Fm7N) {
		this.age70Fm7N = age70Fm7N;
	}
	public String getAge80Tot2N() {
		return age80Tot2N;
	}
	public void setAge80Tot2N(String age80Tot2N) {
		this.age80Tot2N = age80Tot2N;
	}
	public String getAge80Tot3N() {
		return age80Tot3N;
	}
	public void setAge80Tot3N(String age80Tot3N) {
		this.age80Tot3N = age80Tot3N;
	}
	public String getAge80Tot4N() {
		return age80Tot4N;
	}
	public void setAge80Tot4N(String age80Tot4N) {
		this.age80Tot4N = age80Tot4N;
	}
	public String getAge80Tot5N() {
		return age80Tot5N;
	}
	public void setAge80Tot5N(String age80Tot5N) {
		this.age80Tot5N = age80Tot5N;
	}
	public String getAge80Tot6N() {
		return age80Tot6N;
	}
	public void setAge80Tot6N(String age80Tot6N) {
		this.age80Tot6N = age80Tot6N;
	}
	public String getAge80Tot7N() {
		return age80Tot7N;
	}
	public void setAge80Tot7N(String age80Tot7N) {
		this.age80Tot7N = age80Tot7N;
	}
	public String getAge80Ml2N() {
		return age80Ml2N;
	}
	public void setAge80Ml2N(String age80Ml2N) {
		this.age80Ml2N = age80Ml2N;
	}
	public String getAge80Ml3N() {
		return age80Ml3N;
	}
	public void setAge80Ml3N(String age80Ml3N) {
		this.age80Ml3N = age80Ml3N;
	}
	public String getAge80Ml4N() {
		return age80Ml4N;
	}
	public void setAge80Ml4N(String age80Ml4N) {
		this.age80Ml4N = age80Ml4N;
	}
	public String getAge80Ml5N() {
		return age80Ml5N;
	}
	public void setAge80Ml5N(String age80Ml5N) {
		this.age80Ml5N = age80Ml5N;
	}
	public String getAge80Ml6N() {
		return age80Ml6N;
	}
	public void setAge80Ml6N(String age80Ml6N) {
		this.age80Ml6N = age80Ml6N;
	}
	public String getAge80Ml7N() {
		return age80Ml7N;
	}
	public void setAge80Ml7N(String age80Ml7N) {
		this.age80Ml7N = age80Ml7N;
	}
	public String getAge80Fm2N() {
		return age80Fm2N;
	}
	public void setAge80Fm2N(String age80Fm2N) {
		this.age80Fm2N = age80Fm2N;
	}
	public String getAge80Fm3N() {
		return age80Fm3N;
	}
	public void setAge80Fm3N(String age80Fm3N) {
		this.age80Fm3N = age80Fm3N;
	}
	public String getAge80Fm4N() {
		return age80Fm4N;
	}
	public void setAge80Fm4N(String age80Fm4N) {
		this.age80Fm4N = age80Fm4N;
	}
	public String getAge80Fm5N() {
		return age80Fm5N;
	}
	public void setAge80Fm5N(String age80Fm5N) {
		this.age80Fm5N = age80Fm5N;
	}
	public String getAge80Fm6N() {
		return age80Fm6N;
	}
	public void setAge80Fm6N(String age80Fm6N) {
		this.age80Fm6N = age80Fm6N;
	}
	public String getAge80Fm7N() {
		return age80Fm7N;
	}
	public void setAge80Fm7N(String age80Fm7N) {
		this.age80Fm7N = age80Fm7N;
	}
	public String getAge90Tot2N() {
		return age90Tot2N;
	}
	public void setAge90Tot2N(String age90Tot2N) {
		this.age90Tot2N = age90Tot2N;
	}
	public String getAge90Tot3N() {
		return age90Tot3N;
	}
	public void setAge90Tot3N(String age90Tot3N) {
		this.age90Tot3N = age90Tot3N;
	}
	public String getAge90Tot4N() {
		return age90Tot4N;
	}
	public void setAge90Tot4N(String age90Tot4N) {
		this.age90Tot4N = age90Tot4N;
	}
	public String getAge90Tot5N() {
		return age90Tot5N;
	}
	public void setAge90Tot5N(String age90Tot5N) {
		this.age90Tot5N = age90Tot5N;
	}
	public String getAge90Tot6N() {
		return age90Tot6N;
	}
	public void setAge90Tot6N(String age90Tot6N) {
		this.age90Tot6N = age90Tot6N;
	}
	public String getAge90Tot7N() {
		return age90Tot7N;
	}
	public void setAge90Tot7N(String age90Tot7N) {
		this.age90Tot7N = age90Tot7N;
	}
	public String getAge90Ml2N() {
		return age90Ml2N;
	}
	public void setAge90Ml2N(String age90Ml2N) {
		this.age90Ml2N = age90Ml2N;
	}
	public String getAge90Ml3N() {
		return age90Ml3N;
	}
	public void setAge90Ml3N(String age90Ml3N) {
		this.age90Ml3N = age90Ml3N;
	}
	public String getAge90Ml4N() {
		return age90Ml4N;
	}
	public void setAge90Ml4N(String age90Ml4N) {
		this.age90Ml4N = age90Ml4N;
	}
	public String getAge90Ml5N() {
		return age90Ml5N;
	}
	public void setAge90Ml5N(String age90Ml5N) {
		this.age90Ml5N = age90Ml5N;
	}
	public String getAge90Ml6N() {
		return age90Ml6N;
	}
	public void setAge90Ml6N(String age90Ml6N) {
		this.age90Ml6N = age90Ml6N;
	}
	public String getAge90Ml7N() {
		return age90Ml7N;
	}
	public void setAge90Ml7N(String age90Ml7N) {
		this.age90Ml7N = age90Ml7N;
	}
	public String getAge90Fm2N() {
		return age90Fm2N;
	}
	public void setAge90Fm2N(String age90Fm2N) {
		this.age90Fm2N = age90Fm2N;
	}
	public String getAge90Fm3N() {
		return age90Fm3N;
	}
	public void setAge90Fm3N(String age90Fm3N) {
		this.age90Fm3N = age90Fm3N;
	}
	public String getAge90Fm4N() {
		return age90Fm4N;
	}
	public void setAge90Fm4N(String age90Fm4N) {
		this.age90Fm4N = age90Fm4N;
	}
	public String getAge90Fm5N() {
		return age90Fm5N;
	}
	public void setAge90Fm5N(String age90Fm5N) {
		this.age90Fm5N = age90Fm5N;
	}
	public String getAge90Fm6N() {
		return age90Fm6N;
	}
	public void setAge90Fm6N(String age90Fm6N) {
		this.age90Fm6N = age90Fm6N;
	}
	public String getAge90Fm7N() {
		return age90Fm7N;
	}
	public void setAge90Fm7N(String age90Fm7N) {
		this.age90Fm7N = age90Fm7N;
	}
	public String getAge100Tot2N() {
		return age100Tot2N;
	}
	public void setAge100Tot2N(String age100Tot2N) {
		this.age100Tot2N = age100Tot2N;
	}
	public String getAge100Tot3N() {
		return age100Tot3N;
	}
	public void setAge100Tot3N(String age100Tot3N) {
		this.age100Tot3N = age100Tot3N;
	}
	public String getAge100Tot4N() {
		return age100Tot4N;
	}
	public void setAge100Tot4N(String age100Tot4N) {
		this.age100Tot4N = age100Tot4N;
	}
	public String getAge100Tot5N() {
		return age100Tot5N;
	}
	public void setAge100Tot5N(String age100Tot5N) {
		this.age100Tot5N = age100Tot5N;
	}
	public String getAge100Tot6N() {
		return age100Tot6N;
	}
	public void setAge100Tot6N(String age100Tot6N) {
		this.age100Tot6N = age100Tot6N;
	}
	public String getAge100Tot7N() {
		return age100Tot7N;
	}
	public void setAge100Tot7N(String age100Tot7N) {
		this.age100Tot7N = age100Tot7N;
	}
	public String getAge100Ml2N() {
		return age100Ml2N;
	}
	public void setAge100Ml2N(String age100Ml2N) {
		this.age100Ml2N = age100Ml2N;
	}
	public String getAge100Ml3N() {
		return age100Ml3N;
	}
	public void setAge100Ml3N(String age100Ml3N) {
		this.age100Ml3N = age100Ml3N;
	}
	public String getAge100Ml4N() {
		return age100Ml4N;
	}
	public void setAge100Ml4N(String age100Ml4N) {
		this.age100Ml4N = age100Ml4N;
	}
	public String getAge100Ml5N() {
		return age100Ml5N;
	}
	public void setAge100Ml5N(String age100Ml5N) {
		this.age100Ml5N = age100Ml5N;
	}
	public String getAge100Ml6N() {
		return age100Ml6N;
	}
	public void setAge100Ml6N(String age100Ml6N) {
		this.age100Ml6N = age100Ml6N;
	}
	public String getAge100Ml7N() {
		return age100Ml7N;
	}
	public void setAge100Ml7N(String age100Ml7N) {
		this.age100Ml7N = age100Ml7N;
	}
	public String getAge100Fm2N() {
		return age100Fm2N;
	}
	public void setAge100Fm2N(String age100Fm2N) {
		this.age100Fm2N = age100Fm2N;
	}
	public String getAge100Fm3N() {
		return age100Fm3N;
	}
	public void setAge100Fm3N(String age100Fm3N) {
		this.age100Fm3N = age100Fm3N;
	}
	public String getAge100Fm4N() {
		return age100Fm4N;
	}
	public void setAge100Fm4N(String age100Fm4N) {
		this.age100Fm4N = age100Fm4N;
	}
	public String getAge100Fm5N() {
		return age100Fm5N;
	}
	public void setAge100Fm5N(String age100Fm5N) {
		this.age100Fm5N = age100Fm5N;
	}
	public String getAge100Fm6N() {
		return age100Fm6N;
	}
	public void setAge100Fm6N(String age100Fm6N) {
		this.age100Fm6N = age100Fm6N;
	}
	public String getAge100Fm7N() {
		return age100Fm7N;
	}
	public void setAge100Fm7N(String age100Fm7N) {
		this.age100Fm7N = age100Fm7N;
	}
	
}