package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsPpltRignSectVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String sysSgntInsp;
	private String crnDd;
	private String noneCnt;
	private String otherCnt;
	private String buddhistCnt;
	private String judaismCnt;
	private String christianCnt;
	private String sikhlCnt;
	private String hinduCnt;
	private String islam3Cnt;
	private String islam2Cnt;
	private String islam1Cnt;
	private String islamTotCnt;	
	private String dstrNm;
	private String prvicNm;
	private String curtAdCd;
	private String stsTitCd;
	private String stsTitNm;
	private String adCd;
	private String adCdNm;	
	

	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	public String getOtherCnt() {
		return otherCnt;
	}
	public void setOtherCnt(String otherCnt) {
		this.otherCnt = otherCnt;
	}
	public String getBuddhistCnt() {
		return buddhistCnt;
	}
	public void setBuddhistCnt(String buddhistCnt) {
		this.buddhistCnt = buddhistCnt;
	}
	public String getJudaismCnt() {
		return judaismCnt;
	}
	public void setJudaismCnt(String judaismCnt) {
		this.judaismCnt = judaismCnt;
	}
	public String getChristianCnt() {
		return christianCnt;
	}
	public void setChristianCnt(String christianCnt) {
		this.christianCnt = christianCnt;
	}
	public String getSikhlCnt() {
		return sikhlCnt;
	}
	public void setSikhlCnt(String sikhlCnt) {
		this.sikhlCnt = sikhlCnt;
	}
	public String getHinduCnt() {
		return hinduCnt;
	}
	public void setHinduCnt(String hinduCnt) {
		this.hinduCnt = hinduCnt;
	}
	public String getIslam3Cnt() {
		return islam3Cnt;
	}
	public void setIslam3Cnt(String islam3Cnt) {
		this.islam3Cnt = islam3Cnt;
	}
	public String getIslam2Cnt() {
		return islam2Cnt;
	}
	public void setIslam2Cnt(String islam2Cnt) {
		this.islam2Cnt = islam2Cnt;
	}
	public String getIslam1Cnt() {
		return islam1Cnt;
	}
	public void setIslam1Cnt(String islam1Cnt) {
		this.islam1Cnt = islam1Cnt;
	}
	public String getIslamTotCnt() {
		return islamTotCnt;
	}
	public void setIslamTotCnt(String islamTotCnt) {
		this.islamTotCnt = islamTotCnt;
	}
	public String getDstrNm() {
		return dstrNm;
	}
	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}
	public String getPrvicNm() {
		return prvicNm;
	}
	public void setPrvicNm(String prvicNm) {
		this.prvicNm = prvicNm;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getStsTitCd() {
		return stsTitCd;
	}
	public void setStsTitCd(String stsTitCd) {
		this.stsTitCd = stsTitCd;
	}
	public String getStsTitNm() {
		return stsTitNm;
	}
	public void setStsTitNm(String stsTitNm) {
		this.stsTitNm = stsTitNm;
	}
	public String getAdCd() {
		return adCd;
	}
	public void setAdCd(String adCd) {
		this.adCd = adCd;
	}
	public String getAdCdNm() {
		return adCdNm;
	}
	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}
	public String getNoneCnt() {
		return noneCnt;
	}
	public void setNoneCnt(String noneCnt) {
		this.noneCnt = noneCnt;
	}
	public String getSysSgntInsp() {
		return sysSgntInsp;
	}
	public void setSysSgntInsp(String sysSgntInsp) {
		this.sysSgntInsp = sysSgntInsp;
	}

	
}
