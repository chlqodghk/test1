package afnid.rm.sts.service;

import java.util.List;

/** 
 * This service interface is biz-class of region. <br>
 * 
 * @author Afghanistan National ID RM Application Moon Soo Kim
 * @since 2015.04.13
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           				    Revisions
 *   2015.04.13  		Moon Soo Kim		                    Create
 *
 * </pre>
 */

public interface FlxbRpotService {
	
	
	/**
	 * Retrieves request list of flexible report. <br>
	 * 
	 * @param vo Input item for retrieving request list of flexible report(FlxbRpotVO).
	 * @return List Retrieve list of program
	 * @exception Exception 
	 */
	List<FlxbRpotVO> searchListRpotRqst(FlxbRpotVO vo) throws Exception;
	
	/**
	 * Biz-method for retrieving total count request list of flexible report. <br>
	 * 
	 * @param vo Input item for retrieving total count request list of flexible report(FlxbRpotVO).
	 * @return int Total Count of flexible report request list
	 * @exception Exception 
	 */
    public int searchListRpotRqstTotCn(FlxbRpotVO vo) throws Exception;
    
 
	/**
	 * Register request of flexible report <br>
	 *
	 * @param N/A
	 * @return void
	 * @exception Exception
	 */
	void addRpotRqst(FlxbRpotVO vo) throws Exception;	
	
	
	/**
	 * Retrieves condition of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving condition of flexible report(FlxbRpotVO).
	 * @return List Retrieve condition of flexible report
	 * @exception Exception 
	 */
	List<FlxbRpotVO> searchListRpotCnd(FlxbRpotVO vo) throws Exception;
	
	/**
	 * Retrieves output items of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving output items of flexible report(FlxbRpotVO).
	 * @return List Retrieve output items of flexible report
	 * @exception Exception 
	 */
	List<FlxbRpotVO> searchListRpotItem(FlxbRpotVO vo) throws Exception;
	
	/**
	 * Retrieves item width of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving item width of Flexible Report(FlxbRpotVO).
	 * @return List Retrieve  item width of Flexible Report
	 * @exception Exception 
	 */
	List<FlxbRpotVO> searchListRpotItemWdth(FlxbRpotVO vo) throws Exception;
	
	/**
	 * Retrieves  total width of Flexible Report items. <br>
	 * 
	 * @param vo Input item for retrieving total width of Flexible Report items(FlxbRpotVO).
	 * @return String Retrieve  total width of Flexible Report items
	 * @exception Exception 
	 */
	String searchRpotItemTotWdth(FlxbRpotVO vo) throws Exception;
		
	/**
	 * Retrieves Result of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving request list of flexible report(FlxbRpotVO).
	 * @return List Retrieve request list of flexible report
	 * @exception Exception 
	 */
	List<FlxbRpotVO> searchListRpotRust(FlxbRpotVO vo) throws Exception;
	
	/**
	 * Retrieves other language of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving other language list of flexible report(FlxbRpotVO).
	 * @return List Retrieve other language list of flexible report
	 * @exception Exception 
	 */
	List<FlxbRpotVO> searchListRpotRustOthrLang(FlxbRpotVO vo) throws Exception;
	
	/**
	 * Retrieves foreign language of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving foreign language list of Flexible Report(FlxbRpotVO).
	 * @return List Retrieve foreign language list of Flexible Report
	 * @exception Exception 
	 */
	List<FlxbRpotVO> searchListRpotRustFrgnLang(FlxbRpotVO vo) throws Exception;
	
	/**
	 * Biz-method for retrieving total count result list of flexible report. <br>
	 * 
	 * @param vo Input item for retrieving total count result list of flexible report(FlxbRpotVO).
	 * @return int Total Count of flexible report result list
	 * @exception Exception 
	 */
    public int searchListRpotRustTotCn(FlxbRpotVO vo) throws Exception;	
    
	/**
	 * Biz-method for retrieving date of generation. <br>
	 * 
	 * @param vo Input item for retrieving date of generation.(FlxbRpotVO).
	 * @return String date of generation.
	 * @exception Exception 
	 */
    public String searchGnrTime(FlxbRpotVO vo) throws Exception;	 
    
	/**
	 * Add view log of citizen information. <br>
	 *
	 * @param N/A
	 * @return void
	 * @exception Exception
	 */
	void addRsdtInfrLog(FlxbRpotVO vo) throws Exception;	
	    
}

