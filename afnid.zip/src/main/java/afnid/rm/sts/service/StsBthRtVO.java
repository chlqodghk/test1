package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsBthRtVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;

	private String crnDd;
	private String fmlRt01 ;
	private String mlRt01  ;
	private String fmlCnt01;
	private String mlCnt01 ;
	private String totCnt01;
	private String fmlRt02 ;
	private String mlRt02 ;
	private String fmlCnt02;
	private String mlCnt02 ;
	private String totCnt02;
	private String fmlRt03 ;
	private String mlRt03  ;
	private String fmlCnt03;
	private String mlCnt03 ;
	private String totCnt03;
	private String fmlRt04 ;
	private String mlRt04  ;
	private String fmlCnt04;
	private String mlCnt04 ;
	private String totCnt04;
	private String fmlRt05 ;
	private String mlRt05  ;
	private String fmlCnt05;
	private String mlCnt05 ;
	private String totCnt05;
	private String dstrNm;
	private String prvicNm;
	private String curtAdCd;
	private String stsTitCd;
	private String stsTitNm;
	
	private String adCd;
	private String adCdNm;	
	

	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	public String getFmlRt01() {
		return fmlRt01;
	}
	public void setFmlRt01(String fmlRt01) {
		this.fmlRt01 = fmlRt01;
	}
	public String getMlRt01() {
		return mlRt01;
	}
	public void setMlRt01(String mlRt01) {
		this.mlRt01 = mlRt01;
	}
	public String getFmlCnt01() {
		return fmlCnt01;
	}
	public void setFmlCnt01(String fmlCnt01) {
		this.fmlCnt01 = fmlCnt01;
	}
	public String getMlCnt01() {
		return mlCnt01;
	}
	public void setMlCnt01(String mlCnt01) {
		this.mlCnt01 = mlCnt01;
	}
	public String getTotCnt01() {
		return totCnt01;
	}
	public void setTotCnt01(String totCnt01) {
		this.totCnt01 = totCnt01;
	}
	public String getFmlRt02() {
		return fmlRt02;
	}
	public void setFmlRt02(String fmlRt02) {
		this.fmlRt02 = fmlRt02;
	}

	
	public String getMlRt02() {
		return mlRt02;
	}
	public void setMlRt02(String mlRt02) {
		this.mlRt02 = mlRt02;
	}
	public String getFmlCnt02() {
		return fmlCnt02;
	}
	public void setFmlCnt02(String fmlCnt02) {
		this.fmlCnt02 = fmlCnt02;
	}
	public String getMlCnt02() {
		return mlCnt02;
	}
	public void setMlCnt02(String mlCnt02) {
		this.mlCnt02 = mlCnt02;
	}
	public String getTotCnt02() {
		return totCnt02;
	}
	public void setTotCnt02(String totCnt02) {
		this.totCnt02 = totCnt02;
	}
	public String getFmlRt03() {
		return fmlRt03;
	}
	public void setFmlRt03(String fmlRt03) {
		this.fmlRt03 = fmlRt03;
	}
	public String getMlRt03() {
		return mlRt03;
	}
	public void setMlRt03(String mlRt03) {
		this.mlRt03 = mlRt03;
	}
	public String getFmlCnt03() {
		return fmlCnt03;
	}
	public void setFmlCnt03(String fmlCnt03) {
		this.fmlCnt03 = fmlCnt03;
	}
	public String getMlCnt03() {
		return mlCnt03;
	}
	public void setMlCnt03(String mlCnt03) {
		this.mlCnt03 = mlCnt03;
	}
	public String getTotCnt03() {
		return totCnt03;
	}
	public void setTotCnt03(String totCnt03) {
		this.totCnt03 = totCnt03;
	}
	public String getFmlRt04() {
		return fmlRt04;
	}
	public void setFmlRt04(String fmlRt04) {
		this.fmlRt04 = fmlRt04;
	}
	public String getMlRt04() {
		return mlRt04;
	}
	public void setMlRt04(String mlRt04) {
		this.mlRt04 = mlRt04;
	}
	public String getFmlCnt04() {
		return fmlCnt04;
	}
	public void setFmlCnt04(String fmlCnt04) {
		this.fmlCnt04 = fmlCnt04;
	}
	public String getMlCnt04() {
		return mlCnt04;
	}
	public void setMlCnt04(String mlCnt04) {
		this.mlCnt04 = mlCnt04;
	}
	public String getTotCnt04() {
		return totCnt04;
	}
	public void setTotCnt04(String totCnt04) {
		this.totCnt04 = totCnt04;
	}
	public String getFmlRt05() {
		return fmlRt05;
	}
	public void setFmlRt05(String fmlRt05) {
		this.fmlRt05 = fmlRt05;
	}
	public String getMlRt05() {
		return mlRt05;
	}
	public void setMlRt05(String mlRt05) {
		this.mlRt05 = mlRt05;
	}
	public String getFmlCnt05() {
		return fmlCnt05;
	}
	public void setFmlCnt05(String fmlCnt05) {
		this.fmlCnt05 = fmlCnt05;
	}
	public String getMlCnt05() {
		return mlCnt05;
	}
	public void setMlCnt05(String mlCnt05) {
		this.mlCnt05 = mlCnt05;
	}
	public String getTotCnt05() {
		return totCnt05;
	}
	public void setTotCnt05(String totCnt05) {
		this.totCnt05 = totCnt05;
	}
	public String getDstrNm() {
		return dstrNm;
	}
	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}
	public String getPrvicNm() {
		return prvicNm;
	}
	public void setPrvicNm(String prvicNm) {
		this.prvicNm = prvicNm;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getStsTitCd() {
		return stsTitCd;
	}
	public void setStsTitCd(String stsTitCd) {
		this.stsTitCd = stsTitCd;
	}
	public String getStsTitNm() {
		return stsTitNm;
	}
	public void setStsTitNm(String stsTitNm) {
		this.stsTitNm = stsTitNm;
	}
	public String getAdCd() {
		return adCd;
	}
	public void setAdCd(String adCd) {
		this.adCd = adCd;
	}
	public String getAdCdNm() {
		return adCdNm;
	}
	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}
	
	
	
}
