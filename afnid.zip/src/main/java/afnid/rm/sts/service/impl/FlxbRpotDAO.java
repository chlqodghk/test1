package afnid.rm.sts.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;


import afnid.rm.sts.service.FlxbRpotVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/** 
 * This class is Database Access Object of common
 * 
 * @author Afghanistan National ID Card System Application Team Moon Soo Kim
 * @since 2015.04.13
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           	Revisions
 *   2015.04.13  		M.S KIM         		Create
 *
 * </pre>
 */
@Repository("flxbRpotDAO")
public class FlxbRpotDAO extends EgovAbstractDAO {
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }

	/**
	 * DAO-method for retrieving request list of flexible report. <br>
	 * 
	 * @param vo Input item for retrieving request list of flexible report(FlxbRpotVO).
	 * @return UserMngVO Retrieve request list of flexible report
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<FlxbRpotVO> selectListRpotRqst(FlxbRpotVO vo) throws Exception{
		return list("flxbRpotDAO.selectListRpotRqst", vo);
	}
    
	/**
	 * DAO-method for retrieving total count request list of flexible report. <br>
	 * 
	 * @param vo Input item for retrieving total count request list of flexible report(FlxbRpotVO).
	 * @return int Total Count of flexible report request list
	 * @exception Exception
	 */
    public int selectListRpotRqstTotCn(FlxbRpotVO vo) throws Exception{
        return (Integer)selectByPk("flxbRpotDAO.selectListRpotRqstTotCn", vo);
    }	
	
    
	/**
	 * DAO-method for registering request of flexible report . <br>
	 * 
	 * @param FlxbRpotVO
	 * @return String
	 * @exception Exception
	 */
	public String insertRpotRqst(FlxbRpotVO vo)throws Exception{
		String result = null;
    	result = (String)insert("flxbRpotDAO.insertRpotRqst", vo);
        return result;
	}
	
	/**
	 * DAO-method for registering condition of flexible report . <br>
	 * 
	 * @param vo Input item for registering condition of flexible report(FlxbRpotVO).
	 * @exception Exception
	 */
	public void insertRpotCon(FlxbRpotVO vo)throws Exception{
		insert("flxbRpotDAO.insertRpotCon", vo);
	}
	
	/**
	 * DAO-method for registering output items of flexible report. <br>
	 * 
	 * @param vo Input item for registering items of flexible report(FlxbRpotVO).
	 * @exception Exception
	 */
	public void insertRpotItem(FlxbRpotVO vo)throws Exception{
		insert("flxbRpotDAO.insertRpotItem", vo);
	}	
    
	/**
	 * DAO-method for retrieving condition of flexible report. <br>
	 * 
	 * @param vo Input item for retrieving condition of flexible report(FlxbRpotVO).
	 * @return List Retrieve condition of flexible report
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<FlxbRpotVO> selectListRpotCnd(FlxbRpotVO vo) throws Exception{
		return list("flxbRpotDAO.selectListRpotCnd", vo);
	}
	
	/**
	 * DAO-method for retrieving output items of flexible report. <br>
	 * 
	 * @param vo Input item for retrieving output items of flexible report(FlxbRpotVO).
	 * @return List Retrieve output items of flexible report
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<FlxbRpotVO> selectListRpotItem(FlxbRpotVO vo) throws Exception{
		return list("flxbRpotDAO.selectListRpotItem", vo);
	}
	
	/**
	 * DAO-method for retrieving item width of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving item width of Flexible Report(FlxbRpotVO).
	 * @return List Retrieve item width of Flexible Report
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<FlxbRpotVO> selectListRpotItemWdth(FlxbRpotVO vo) throws Exception{
		return list("flxbRpotDAO.selectListRpotItemWdth", vo);
	}
	
	/**
	 * DAO-method for retrieving item width of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving item width of Flexible Report(FlxbRpotVO).
	 * @return String Retrieve item width of Flexible Report
	 * @exception Exception
	 */
	public String selectRpotItemTotWdth(FlxbRpotVO vo) throws Exception{
		return (String)selectByPk("flxbRpotDAO.selectRpotItemTotWdth", vo);
	}
	
	/**
	 * DAO-method for retrieving result of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving result of Flexible Report(FlxbRpotVO).
	 * @return List Retrieve result of Flexible Report.
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<FlxbRpotVO> selectListRpotRust(FlxbRpotVO vo) throws Exception{
		return list("flxbRpotDAO.selectListRpotRust", vo);
	}
    
	/**
	 * DAO-method for retrieving other language of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving other language of Flexible Report(FlxbRpotVO).
	 * @return String Retrieve other language of Flexible Report
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<FlxbRpotVO> selectListRpotRustOthrLang(FlxbRpotVO vo) throws Exception{
		return list("flxbRpotDAO.selectListRpotRustOthrLang", vo);
	}
	
	/**
	 * DAO-method for retrieving foreign language of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving foreign language of Flexible Report(FlxbRpotVO).
	 * @return String Retrieve foreign language of Flexible Report
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<FlxbRpotVO> selectListRpotRustFrgnLang(FlxbRpotVO vo) throws Exception{
		return list("flxbRpotDAO.selectListRpotRustFrgnLang", vo);
	}
	
	/**
	 * DAO-method for retrieving total count result list of flexible report. <br>
	 * 
	 * @param vo Input item for retrieving total count result list of flexible report(FlxbRpotVO).
	 * @return int Total Count of flexible report result list
	 * @exception Exception
	 */
    public int selectListRpotRustTotCn(FlxbRpotVO vo) throws Exception{
        return (Integer)selectByPk("flxbRpotDAO.selectListRpotRustTotCn", vo);
    }	
	    
	/**
	 * DAO-method for retrieving date of generation. <br>
	 * 
	 * @param vo Input item for retrieving date of generation(FlxbRpotVO).
	 * @return String date of generation
	 * @exception Exception
	 */
	public String selectGnrTime(FlxbRpotVO vo) throws Exception{
		return (String)selectByPk("flxbRpotDAO.selectGnrTime", vo);
	}    
}
