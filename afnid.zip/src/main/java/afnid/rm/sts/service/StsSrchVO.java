package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsSrchVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String crnDd;	
	private String yy;		
	private String useLangCd;
	private String officerNo;
	private String stsTitCd;
	private String stsTitNm;	
	private String orgnzClsCd;
	private String crnUserId;
	private String calTye;
	
	private String hCrnDd;
	private String gCrnDd;
	
	private String adCd;
	private String adCdNm;	
	private String oficTye;
	
	private String hRqstDd;
	private String gRqstDd;
	
	private String orgnzCd;
	private String orgnzCdNm;
	private String userId;
	private String userNm;
	private String gnrYn;
	private String rqstDt;
	private String seqNo;
	private int age;
	

	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	public String getYy() {
		return yy;
	}
	public void setYy(String yy) {
		this.yy = yy;
	}
	public String getUseLangCd() {
		return useLangCd;
	}
	public void setUseLangCd(String useLangCd) {
		this.useLangCd = useLangCd;
	}
	public String getOfficerNo() {
		return officerNo;
	}
	public void setOfficerNo(String officerNo) {
		this.officerNo = officerNo;
	}
	public String getStsTitCd() {
		return stsTitCd;
	}
	public void setStsTitCd(String stsTitCd) {
		this.stsTitCd = stsTitCd;
	}
	public String getStsTitNm() {
		return stsTitNm;
	}
	public void setStsTitNm(String stsTitNm) {
		this.stsTitNm = stsTitNm;
	}
	public String getOrgnzClsCd() {
		return orgnzClsCd;
	}
	public void setOrgnzClsCd(String orgnzClsCd) {
		this.orgnzClsCd = orgnzClsCd;
	}
	public String getCrnUserId() {
		return crnUserId;
	}
	public void setCrnUserId(String crnUserId) {
		this.crnUserId = crnUserId;
	}
	public String getCalTye() {
		return calTye;
	}
	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}
	public String gethCrnDd() {
		return hCrnDd;
	}
	public void sethCrnDd(String hCrnDd) {
		this.hCrnDd = hCrnDd;
	}
	public String getgCrnDd() {
		return gCrnDd;
	}
	public void setgCrnDd(String gCrnDd) {
		this.gCrnDd = gCrnDd;
	}
	public String getAdCd() {
		return adCd;
	}
	public void setAdCd(String adCd) {
		this.adCd = adCd;
	}
	public String getAdCdNm() {
		return adCdNm;
	}
	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}
	public String getOficTye() {
		return oficTye;
	}
	public void setOficTye(String oficTye) {
		this.oficTye = oficTye;
	}
	public String gethRqstDd() {
		return hRqstDd;
	}
	public void sethRqstDd(String hRqstDd) {
		this.hRqstDd = hRqstDd;
	}
	public String getgRqstDd() {
		return gRqstDd;
	}
	public void setgRqstDd(String gRqstDd) {
		this.gRqstDd = gRqstDd;
	}
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String getOrgnzCdNm() {
		return orgnzCdNm;
	}
	public void setOrgnzCdNm(String orgnzCdNm) {
		this.orgnzCdNm = orgnzCdNm;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getGnrYn() {
		return gnrYn;
	}
	public void setGnrYn(String gnrYn) {
		this.gnrYn = gnrYn;
	}
	public String getRqstDt() {
		return rqstDt;
	}
	public void setRqstDt(String rqstDt) {
		this.rqstDt = rqstDt;
	}
	public String getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}	


}
