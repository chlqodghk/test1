package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsSecdNltyVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String crnDd;
	private String curtAd36Cnt;
	private String curtAd35Cnt;
	private String curtAd34Cnt;
	private String curtAd33Cnt;
	private String curtAd32Cnt;
	private String curtAd31Cnt;
	private String curtAd30Cnt;
	private String curtAd29Cnt;
	private String curtAd28Cnt;
	private String curtAd27Cnt;
	private String curtAd26Cnt;
	private String curtAd25Cnt;
	private String curtAd24Cnt;
	private String curtAd23Cnt;
	private String curtAd22Cnt;
	private String curtAd21Cnt;
	private String curtAd20Cnt;
	private String curtAd19Cnt;
	private String curtAd18Cnt;
	private String curtAd17Cnt;
	private String curtAd16Cnt;
	private String curtAd15Cnt;
	private String curtAd14Cnt;
	private String curtAd13Cnt;
	private String curtAd12Cnt;
	private String curtAd11Cnt;
	private String curtAd10Cnt;
	private String curtAd09Cnt;
	private String curtAd08Cnt;
	private String curtAd07Cnt;
	private String curtAd06Cnt;
	private String curtAd05Cnt;
	private String curtAd04Cnt;
	private String curtAd03Cnt;
	private String curtAd02Cnt;
	private String curtAd01Cnt;
	private String dstrNm;
	private String prvicNm;
	private String curtAdCd;
	private String secdNltyNm;
	private String stsTitCd;
	private String stsTitNm;
	private String adCd;
	private String adCdNm;		
	

	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	
	public String getCurtAd36Cnt() {
		return curtAd36Cnt;
	}
	public void setCurtAd36Cnt(String curtAd36Cnt) {
		this.curtAd36Cnt = curtAd36Cnt;
	}
	public String getCurtAd35Cnt() {
		return curtAd35Cnt;
	}
	public void setCurtAd35Cnt(String curtAd35Cnt) {
		this.curtAd35Cnt = curtAd35Cnt;
	}
	public String getCurtAd34Cnt() {
		return curtAd34Cnt;
	}
	public void setCurtAd34Cnt(String curtAd34Cnt) {
		this.curtAd34Cnt = curtAd34Cnt;
	}
	public String getCurtAd33Cnt() {
		return curtAd33Cnt;
	}
	public void setCurtAd33Cnt(String curtAd33Cnt) {
		this.curtAd33Cnt = curtAd33Cnt;
	}
	public String getCurtAd32Cnt() {
		return curtAd32Cnt;
	}
	public void setCurtAd32Cnt(String curtAd32Cnt) {
		this.curtAd32Cnt = curtAd32Cnt;
	}
	public String getCurtAd31Cnt() {
		return curtAd31Cnt;
	}
	public void setCurtAd31Cnt(String curtAd31Cnt) {
		this.curtAd31Cnt = curtAd31Cnt;
	}
	public String getCurtAd30Cnt() {
		return curtAd30Cnt;
	}
	public void setCurtAd30Cnt(String curtAd30Cnt) {
		this.curtAd30Cnt = curtAd30Cnt;
	}
	public String getCurtAd29Cnt() {
		return curtAd29Cnt;
	}
	public void setCurtAd29Cnt(String curtAd29Cnt) {
		this.curtAd29Cnt = curtAd29Cnt;
	}
	public String getCurtAd28Cnt() {
		return curtAd28Cnt;
	}
	public void setCurtAd28Cnt(String curtAd28Cnt) {
		this.curtAd28Cnt = curtAd28Cnt;
	}
	public String getCurtAd27Cnt() {
		return curtAd27Cnt;
	}
	public void setCurtAd27Cnt(String curtAd27Cnt) {
		this.curtAd27Cnt = curtAd27Cnt;
	}
	public String getCurtAd26Cnt() {
		return curtAd26Cnt;
	}
	public void setCurtAd26Cnt(String curtAd26Cnt) {
		this.curtAd26Cnt = curtAd26Cnt;
	}
	public String getCurtAd25Cnt() {
		return curtAd25Cnt;
	}
	public void setCurtAd25Cnt(String curtAd25Cnt) {
		this.curtAd25Cnt = curtAd25Cnt;
	}
	public String getCurtAd24Cnt() {
		return curtAd24Cnt;
	}
	public void setCurtAd24Cnt(String curtAd24Cnt) {
		this.curtAd24Cnt = curtAd24Cnt;
	}
	public String getCurtAd23Cnt() {
		return curtAd23Cnt;
	}
	public void setCurtAd23Cnt(String curtAd23Cnt) {
		this.curtAd23Cnt = curtAd23Cnt;
	}
	public String getCurtAd22Cnt() {
		return curtAd22Cnt;
	}
	public void setCurtAd22Cnt(String curtAd22Cnt) {
		this.curtAd22Cnt = curtAd22Cnt;
	}
	public String getCurtAd21Cnt() {
		return curtAd21Cnt;
	}
	public void setCurtAd21Cnt(String curtAd21Cnt) {
		this.curtAd21Cnt = curtAd21Cnt;
	}
	public String getCurtAd20Cnt() {
		return curtAd20Cnt;
	}
	public void setCurtAd20Cnt(String curtAd20Cnt) {
		this.curtAd20Cnt = curtAd20Cnt;
	}
	public String getCurtAd19Cnt() {
		return curtAd19Cnt;
	}
	public void setCurtAd19Cnt(String curtAd19Cnt) {
		this.curtAd19Cnt = curtAd19Cnt;
	}
	public String getCurtAd18Cnt() {
		return curtAd18Cnt;
	}
	public void setCurtAd18Cnt(String curtAd18Cnt) {
		this.curtAd18Cnt = curtAd18Cnt;
	}
	public String getCurtAd17Cnt() {
		return curtAd17Cnt;
	}
	public void setCurtAd17Cnt(String curtAd17Cnt) {
		this.curtAd17Cnt = curtAd17Cnt;
	}
	public String getCurtAd16Cnt() {
		return curtAd16Cnt;
	}
	public void setCurtAd16Cnt(String curtAd16Cnt) {
		this.curtAd16Cnt = curtAd16Cnt;
	}
	public String getCurtAd15Cnt() {
		return curtAd15Cnt;
	}
	public void setCurtAd15Cnt(String curtAd15Cnt) {
		this.curtAd15Cnt = curtAd15Cnt;
	}
	public String getCurtAd14Cnt() {
		return curtAd14Cnt;
	}
	public void setCurtAd14Cnt(String curtAd14Cnt) {
		this.curtAd14Cnt = curtAd14Cnt;
	}
	public String getCurtAd13Cnt() {
		return curtAd13Cnt;
	}
	public void setCurtAd13Cnt(String curtAd13Cnt) {
		this.curtAd13Cnt = curtAd13Cnt;
	}
	public String getCurtAd12Cnt() {
		return curtAd12Cnt;
	}
	public void setCurtAd12Cnt(String curtAd12Cnt) {
		this.curtAd12Cnt = curtAd12Cnt;
	}
	public String getCurtAd11Cnt() {
		return curtAd11Cnt;
	}
	public void setCurtAd11Cnt(String curtAd11Cnt) {
		this.curtAd11Cnt = curtAd11Cnt;
	}
	public String getCurtAd10Cnt() {
		return curtAd10Cnt;
	}
	public void setCurtAd10Cnt(String curtAd10Cnt) {
		this.curtAd10Cnt = curtAd10Cnt;
	}
	public String getCurtAd09Cnt() {
		return curtAd09Cnt;
	}
	public void setCurtAd09Cnt(String curtAd09Cnt) {
		this.curtAd09Cnt = curtAd09Cnt;
	}
	public String getCurtAd08Cnt() {
		return curtAd08Cnt;
	}
	public void setCurtAd08Cnt(String curtAd08Cnt) {
		this.curtAd08Cnt = curtAd08Cnt;
	}
	public String getCurtAd07Cnt() {
		return curtAd07Cnt;
	}
	public void setCurtAd07Cnt(String curtAd07Cnt) {
		this.curtAd07Cnt = curtAd07Cnt;
	}
	public String getCurtAd06Cnt() {
		return curtAd06Cnt;
	}
	public void setCurtAd06Cnt(String curtAd06Cnt) {
		this.curtAd06Cnt = curtAd06Cnt;
	}
	public String getCurtAd05Cnt() {
		return curtAd05Cnt;
	}
	public void setCurtAd05Cnt(String curtAd05Cnt) {
		this.curtAd05Cnt = curtAd05Cnt;
	}
	public String getCurtAd04Cnt() {
		return curtAd04Cnt;
	}
	public void setCurtAd04Cnt(String curtAd04Cnt) {
		this.curtAd04Cnt = curtAd04Cnt;
	}
	public String getCurtAd03Cnt() {
		return curtAd03Cnt;
	}
	public void setCurtAd03Cnt(String curtAd03Cnt) {
		this.curtAd03Cnt = curtAd03Cnt;
	}
	public String getCurtAd02Cnt() {
		return curtAd02Cnt;
	}
	public void setCurtAd02Cnt(String curtAd02Cnt) {
		this.curtAd02Cnt = curtAd02Cnt;
	}
	public String getCurtAd01Cnt() {
		return curtAd01Cnt;
	}
	public void setCurtAd01Cnt(String curtAd01Cnt) {
		this.curtAd01Cnt = curtAd01Cnt;
	}
	public String getDstrNm() {
		return dstrNm;
	}
	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}
	public String getPrvicNm() {
		return prvicNm;
	}
	public void setPrvicNm(String prvicNm) {
		this.prvicNm = prvicNm;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getSecdNltyNm() {
		return secdNltyNm;
	}
	public void setSecdNltyNm(String secdNltyNm) {
		this.secdNltyNm = secdNltyNm;
	}
	public String getStsTitCd() {
		return stsTitCd;
	}
	public void setStsTitCd(String stsTitCd) {
		this.stsTitCd = stsTitCd;
	}
	public String getStsTitNm() {
		return stsTitNm;
	}
	public void setStsTitNm(String stsTitNm) {
		this.stsTitNm = stsTitNm;
	}
	public String getAdCd() {
		return adCd;
	}
	public void setAdCd(String adCd) {
		this.adCd = adCd;
	}
	public String getAdCdNm() {
		return adCdNm;
	}
	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}
	
}
