package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsRgstStusVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String curtAdCd ;
	private String prvicNm  ;
	private String dstrNm;
	private String tamNm ;
	private String fmlyBokDatCn;
	private String agDatCn1 ;
	private String agDatCn2 ;
	private String agDatCn3;

	private String officerNo;
	private String orgnzClsCd ;
	private String orgnzCd ;		  
	private String teamCd ;
	private String rgstDd ;
	
	private int listCn;
	private String adCd;
	private String adCdNm;
	
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getPrvicNm() {
		return prvicNm;
	}
	public void setPrvicNm(String prvicNm) {
		this.prvicNm = prvicNm;
	}
	public String getDstrNm() {
		return dstrNm;
	}
	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}
	public String getTamNm() {
		return tamNm;
	}
	public void setTamNm(String tamNm) {
		this.tamNm = tamNm;
	}
	public String getFmlyBokDatCn() {
		return fmlyBokDatCn;
	}
	public void setFmlyBokDatCn(String fmlyBokDatCn) {
		this.fmlyBokDatCn = fmlyBokDatCn;
	}
	public String getAgDatCn1() {
		return agDatCn1;
	}
	public void setAgDatCn1(String agDatCn1) {
		this.agDatCn1 = agDatCn1;
	}
	public String getAgDatCn2() {
		return agDatCn2;
	}
	public void setAgDatCn2(String agDatCn2) {
		this.agDatCn2 = agDatCn2;
	}
	public String getAgDatCn3() {
		return agDatCn3;
	}
	public void setAgDatCn3(String agDatCn3) {
		this.agDatCn3 = agDatCn3;
	}
	public String getOfficerNo() {
		return officerNo;
	}
	public void setOfficerNo(String officerNo) {
		this.officerNo = officerNo;
	}

	public String getOrgnzClsCd() {
		return orgnzClsCd;
	}
	public void setOrgnzClsCd(String orgnzClsCd) {
		this.orgnzClsCd = orgnzClsCd;
	}
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String getTeamCd() {
		return teamCd;
	}
	public void setTeamCd(String teamCd) {
		this.teamCd = teamCd;
	}
	public String getRgstDd() {
		return rgstDd;
	}
	public void setRgstDd(String rgstDd) {
		this.rgstDd = rgstDd;
	}
	public int getListCn() {
		return listCn;
	}
	public void setListCn(int listCn) {
		this.listCn = listCn;
	}
	public String getAdCd() {
		return adCd;
	}
	public void setAdCd(String adCd) {
		this.adCd = adCd;
	}
	public String getAdCdNm() {
		return adCdNm;
	}
	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}

}
