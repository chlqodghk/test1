package afnid.rm.sts.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;



import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

import afnid.rm.sts.service.StsBsnWrkStusVO;
import afnid.rm.sts.service.StsBthRtVO;
import afnid.rm.sts.service.StsDthRtAgeVO;
import afnid.rm.sts.service.StsDthRtVO;
import afnid.rm.sts.service.StsEpctSchAgVO;
import afnid.rm.sts.service.StsPpltAgeVO;
import afnid.rm.sts.service.StsPpltBthPlceVO;
import afnid.rm.sts.service.StsPpltEduVO;
import afnid.rm.sts.service.StsPpltEncyVO;
import afnid.rm.sts.service.StsPpltMrrgVO;
import afnid.rm.sts.service.StsPpltMthrTguVO;
import afnid.rm.sts.service.StsPpltPmntAdVO;
import afnid.rm.sts.service.StsPpltPoliStatVO;
import afnid.rm.sts.service.StsPpltPrsAdVO;
import afnid.rm.sts.service.StsPpltRignSectVO;
import afnid.rm.sts.service.StsRgstStusVO;
import afnid.rm.sts.service.StsRsdcKchiVO;
import afnid.rm.sts.service.StsSecdNltyVO;
import afnid.rm.sts.service.StsSrchVO;
import afnid.rm.sts.service.StsLogVO;
import afnid.rm.sts.service.StsVtrPrsAdVO;

/** 
 * This class is Database Access Object of common
 * 
 * @author Afghanistan National ID Card System Application Team Moon Soo Kim
 * @since 2013.06.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.06.04  		M.S KIM         		Create
 *
 * </pre>
 */
@Repository("stsDAO")
public class StsDAO extends EgovAbstractDAO {
	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	
	/**
	 * DAO-method for get Statistic Creation Date <br>
	 *
	 * @param vo Input item for get Statistic Creation Year(ymd).
	 * @return String Year
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsSrchVO> selectListStsCreYmd(String  ymd) throws Exception{	
		return list("stsDAO.selectListStsCreYmd", ymd);
	}
	
	
	/**
	 * DAO-method for get Statistic Creation Year <br>
	 *
	 * @param vo Input item for get Statistic Creation Year(gYy).
	 * @return String Year
	 * @exception Exception
	 */
	public String  selectStsCreYear(String  gYy) throws Exception{
		return (String)selectByPk("stsDAO.selectStsCreYear", gYy);
	}
	
	/**
	 * DAO-method for get job time of Statistic Creation  <br>
	 *
	 * @param vo Input item for get Statistic Creation Year(gYy).
	 * @return String Year
	 * @exception Exception
	 */
	public String  selectStsCrejobDt(String  gYmd) throws Exception{
		return (String)selectByPk("stsDAO.selectStsCrejobDt", gYmd);
	}
	
	/**
	 * DAO-method for count check of  the already created Statistic. <br>
	 *
	 * @param String Input item for String Input item for check of  the already created Statistic(gYmd).
	 * @return Int result of check of  the already created Statistic
	 * @exception Exception
	 */	
    public int selectStsChkCn(String gYmd) {
        return (Integer)selectByPk("stsDAO.selectStsChkCn", gYmd);
    }

	/**
	 * DAO-method for Statistic Creation of Family Book Number<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsFmlyBokInfr(StsSrchVO stsCrnVo) {
        //insert("stsDAO.insertStsFmlyBokInfr", stsCrnVo);
        insert("stsDAO.insertStsFmlyBokInfrProc", stsCrnVo);
    }
    
	/**
	 * DAO-method for Statistic Creation of Population by Present Address<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsPpltPrsAdInfr(StsSrchVO stsCrnVo) {
        //insert("stsDAO.insertStsPpltPrsAdInfr", stsCrnVo);
        insert("stsDAO.insertStsPpltPrsAdInfrProc", stsCrnVo);
    }
    
	/**
	 * DAO-method for Statistic Creation of  Population by Permanent Address<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsPpltPmntAdInfr(StsSrchVO stsCrnVo) {
        //insert("stsDAO.insertStsPpltPmntAdInfr", stsCrnVo);
    	insert("stsDAO.insertStsPpltPmntAdInfrProc", stsCrnVo);
    }    
    
	/**
	 * DAO-method for Statistic Creation of Population by Birth Place<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsPpltBthPlceInfr(StsSrchVO stsCrnVo) {
        //insert("stsDAO.insertStsPpltBthPlceInfr", stsCrnVo);
    	insert("stsDAO.insertStsPpltBthPlceInfrProc", stsCrnVo);
    }
    
	/**
	 * DAO-method for Statistic Creation of Population by Religion & Sect<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsPpltRignSectInfr(StsSrchVO stsCrnVo) {
        //insert("stsDAO.insertStsPpltRignSectInfr", stsCrnVo);
    	insert("stsDAO.insertStsPpltRignSectInfrProc", stsCrnVo);
    }
    
	/**
	 * DAO-method for Statistic Creation of Population by Mother Tangue<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsPpltMthrTguInfr(StsSrchVO stsCrnVo) {
        //insert("stsDAO.insertStsPpltMthrTguInfr", stsCrnVo);
    	insert("stsDAO.insertStsPpltMthrTguInfrProc", stsCrnVo);
    }
        
	/**
	 * DAO-method for Statistic Creation of Population by Ethnicity<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsPpltEncyInfr(StsSrchVO stsCrnVo) {
        //insert("stsDAO.insertStsPpltEncyInfr", stsCrnVo);
    	insert("stsDAO.insertStsPpltEncyInfrProc", stsCrnVo);
    }

    
	/**
	 * DAO-method for Statistic Creation of Population by Residence for Kochi<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsRsdcKchiInfr(StsSrchVO stsCrnVo) {
        //insert("stsDAO.insertStsRsdcKchiInfr", stsCrnVo);
    	insert("stsDAO.insertStsRsdcKchiInfrProc", stsCrnVo);
    }    
    
	/**
	 * DAO-method for Statistic Creation of Population by Second Nationality<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsSecdNltyInfr(StsSrchVO stsCrnVo) {
        //insert("stsDAO.insertStsSecdNltyInfr", stsCrnVo);
    	insert("stsDAO.insertStsSecdNltyInfrProc", stsCrnVo);
    }    
    
	/**
	 * DAO-method for Statistic Creation of  Population by Polling Station<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsPpltPoliStatInfr(StsSrchVO stsCrnVo) {
        //insert("stsDAO.insertStsPpltPoliStatInfr", stsCrnVo);
    	int votrAge = propertiesService.getInt("mlMrrgAge")-1;;
    	stsCrnVo.setAge(votrAge);
    	insert("stsDAO.insertStsPpltPoliStatInfrProc", stsCrnVo);
    }
    
	/**
	 * DAO-method for Statistic Creation of Birth Rate<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsBthRtInfr(StsSrchVO stsCrnVo) {
        //insert("stsDAO.insertStsBthRtInfr", stsCrnVo);
    	insert("stsDAO.insertStsBthRtInfrProc", stsCrnVo);
    }    
    
	/**
	 * DAO-method for Statistic Creation of  Death Rate.<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsDthRtInfr(StsSrchVO stsCrnVo) {
        //insert("stsDAO.insertStsDthRtInfr", stsCrnVo);
    	insert("stsDAO.insertStsDthRtInfrProc", stsCrnVo);
    }    
    
	/**
	 * DAO-method for Statistic Creation of  Life Expectancy for School Age Children.<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsEpctSchAgeInfr(StsSrchVO stsCrnVo) {
        //insert("stsDAO.insertStsEpctSchAgeInfr", stsCrnVo);
    	insert("stsDAO.insertStsEpctSchAgeInfrProc", stsCrnVo);
    }    
    
	/**
	 * DAO-method for Statistic Creation of  Life Expectancy for School Age Children.<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsPpltVtrStatInfr(StsSrchVO stsCrnVo) {
    	int votrAge = propertiesService.getInt("mlMrrgAge")-1;;
    	stsCrnVo.setAge(votrAge);
    	insert("stsDAO.insertStsPpltVtrStatInfrProc", stsCrnVo);
    } 
    
	/**
	 * DAO-method for Log of Statistic Creation Result.<br>
	 *
	 * @param String Input item for Log of Statistic Creation(StsLogVO).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsJobLog(StsLogVO stsLog) {
        insert("stsDAO.insertStsJobLog", stsLog);
    }    
    
    //=============================================
    //Statistic Query
    //==============================================
    
	/**
	 * DAO-method for get Year <br>
	 *
	 * @param vo Input item for get Year(StsSrchVO).
	 * @return String Year
	 * @exception Exception
	 */
	public String  selectStsYear(StsSrchVO vo) throws Exception{
		return (String)selectByPk("stsDAO.selectStsYear", vo);
	}
	
	/**
	 * DAO-method for retrieving Statistic of Population by Present address. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Present address(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Present address
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsPpltPrsAdVO> selectListStsPpltPrsAd(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsPpltPrsAd", vo);
	}
	
	/**
	 * DAO-method for retrieving Statistic of Population by Permanent address. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Permanent address(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Permanent address
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsPpltPmntAdVO> selectListStsPpltPmntAd(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsPpltPmntAd", vo);
	}
	
	/**
	 * DAO-method for retrieving Statistic of Population by Birth Place address. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Birth Place address(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Birth Place address
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsPpltBthPlceVO> selectListStsPpltBthPlce(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsPpltBthPlce", vo);
	}
	
	/**
	 * DAO-method for retrieving Statistic of Population by Age. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by AgeStsSrchVO).
	 * @return List Retrieve Statistic of Population by Age
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsPpltAgeVO> selectListStsPpltAge(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsPpltAge", vo);
	}
	
	/**
	 * DAO-method for retrieving Statistic of Population by Education Level. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Education Level(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Education Level
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsPpltEduVO> selectListStsPpltEdu(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsPpltEdu", vo);
	}
	
	/**
	 * DAO-method for retrieving Statistic of Population by Religion & Sectm. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Religion & Sect(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Religion & Sect
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsPpltRignSectVO> selectListStsPpltRignSect(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsPpltRignSect", vo);
	}
	
	/**
	 * DAO-method for retrieving Statistic of Population by Mother Tongue. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Mother Tongue(StsSrchVO).
	 * @return StsDAO Retrieve Statistic of Population by Mother Tongue
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsPpltMthrTguVO> selectListStsPpltMthrTgu(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsPpltMthrTgu", vo);
	}
	
	/**
	 * DAO-method for retrieving Statistic of Population by Ethnicity. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Ethnicity(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Ethnicity
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsPpltEncyVO> selectListStsPpltEncy(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsPpltEncy", vo);
	}
	
	/**
	 * DAO-method for retrieving Statistic of Population by Marital Status. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Marital Status(StsSrchVO).
	 * @return List Statistic of Population by Marital Status
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsPpltMrrgVO> selectListStsPpltMrrg(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsPpltMrrg", vo);
	}
	
	/**
	 * DAO-method for retrieving Statistic of Population by Residence for Kochi. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Residence for Kochi(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Residence for Kochi
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsRsdcKchiVO> selectListStsRsdcKchi(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsRsdcKchi", vo);
	}
	
	/**
	 * DAO-method for retrieving Statistic of Population by Second Nationality. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Second Nationality(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Second Nationality
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsSecdNltyVO> selectListStsSecdNlty(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsSecdNlty", vo);
	}
	
	/**
	 * DAO-method for retrieving Statistic of Population by Polling Station. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Polling Station(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Polling Station
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsPpltPoliStatVO> selectListStsPpltPoliStat(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsPpltPoliStat", vo);
	}
	
	/**
	 * DAO-method for retrieving Statistic of Birth Rate. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Birth Rate(StsSrchVO).
	 * @return List Retrieve Statistic of Birth Rate
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsBthRtVO> selectListStsBthRt(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsBthRt", vo);
	}
	
	/**
	 * DAO-method for retrieving Statistic of Death Rate. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Death Rate(StsSrchVO).
	 * @return List Retrieve Statistic of Death Rate
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsDthRtVO> selectListStsDthRt(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsDthRt", vo);
	}
	
	/**
	 * DAO-method for retrieving lStatistic of Death Rate by Age. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Death Rate by Age(StsSrchVO).
	 * @return List Retrieve Statistic of Death Rate by Age
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsDthRtAgeVO> selectListStsDthRtAge(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsDthRtAge", vo);
	}
	
	/**
	 * DAO-method for retrieving Statistic of Life Expectancy for School Age. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Life Expectancy for School Age(StsSrchVO).
	 * @return List Retrieve Statistic of Life Expectancy for School Age
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsEpctSchAgVO> selectListStsEpctSchAge(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsEpctSchAge", vo);
	}	
	
	/**
	 * DAO-method for retrieving Statistic of Voters by Present Address. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Voters by Present Address(StsSrchVO).
	 * @return List Retrieve Statistic of Voters by Present Address
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsVtrPrsAdVO> selectListStsVtrPrsAd(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsVtrPrsAd", vo);
	}
	
	/**
	 * DAO-method for retrieving province name. <br>
	 *
	 * @param vo Input item for retrieving province name(StsSrchVO).
	 * @return StsDAO Retrieve province name
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<StsSecdNltyVO> selectListPrvic(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListPrvic", vo);
	}	

		    
	 /**
	* DAO-method for retrieving Statistic Title. <br>
	* 
	* @param vo Input item for Statistic Title(StsSrchVO).
	* @return Retrieve Statistic Title
	* @exception Exception
	*/
	public String selectStsTitle(StsSrchVO vo) {
	       return (String)selectByPk("stsDAO.selectStsTitle", vo);
	 }
	
	
	/**
	 * DAO-method for count check of  the already created Registration Status Statistic. <br>
	 *
	 * @param String Input item for String Input item for check of  the already created Registration Status Statistic(gYmd).
	 * @return Int result of check of  the already created Statistic
	 * @exception Exception
	 */	
    public int selectStsRgstStusCn(String crdDd) {
        return (Integer)selectByPk("stsDAO.selectStsRgstStusCn", crdDd);
    }
	
    
	/**
	 * DAO-method for Statistic Creation of Population by Religion & Sect<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertStsRgstStusInfr(StsLogVO stsLog) {
        //insert("stsDAO.insertStsRgstStusInfr", stsLog);
        insert("stsDAO.insertStsRgstStusInfrProc", stsLog);
    }
    
	/**
	 * DAO-method for Statistic Creation of Population by Religion & Sect<br>
	 *
	 * @param String Input item for Statistic Creation(stsLog).
	 * @return void
	 * @exception Exception
	 */	
    public void insertRsdtRgstStsJobLog(StsLogVO stsLog) {
        insert("stsDAO.insertRsdtRgstStsJobLog", stsLog);
    }    
   
	/**
	 * DAO-method for retrieving Statistic of Resident Registration Status. <br>	  
	 *
	 * @param vo Input item for retrieving detail information of program(StsRgstStusVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<StsRgstStusVO> selectListRsdtRgstStusInfr(StsRgstStusVO vo) throws Exception{
		return list("stsDAO.selectListRsdtRgstStusInfr", vo);
	}

    /**
	 * DAO-method for retrieving total count  of  Resident Registration Status list. <br>
	 *
	 * @param vo Input item for retrieving list of program(StsSrchVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListRsdtRgstStusInfrTotCn(StsRgstStusVO vo) {
        return (Integer)selectByPk("stsDAO.selectListRsdtRgstStusInfrTotCn", vo);
    }    
    
    
	/**
	 * DAO-method for retrieving list of performance by office.(Daily) <br>	  
	 *
	 * @param vo Input item for retrieving list of performance by office(StsBsnWrkStusVO).
	 * @return List Retrieve list of performance by office
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<StsBsnWrkStusVO> selectListBsnWrkStusInfrDaily(StsBsnWrkStusVO vo) throws Exception{
		return list("stsDAO.selectListBsnWrkStusInfrDaily", vo);
	}
	
    /**
	 * DAO-method for retrieving total count of performance by office.(Daily) <br>
	 *
	 * @param vo Input item for retrieving total count of performance by office(StsBsnWrkStusVO).
	 * @return int Total Count of total count of performance by office
	 * @exception Exception
	 */
    public int selectListBsnWrkStusInfrDailyTotCn(StsBsnWrkStusVO vo) {
        return (Integer)selectByPk("stsDAO.selectListBsnWrkStusInfrDailyTotCn", vo);
    } 
    
	/**
	 * DAO-method for retrieving list of performance by office.(weekly) <br>	  
	 *
	 * @param vo Input item for retrieving list of performance by office(StsBsnWrkStusVO).
	 * @return List Retrieve list of performance by office
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<StsBsnWrkStusVO> selectListBsnWrkStusInfrWeekly(StsBsnWrkStusVO vo) throws Exception{
		return list("stsDAO.selectListBsnWrkStusInfrWeekly", vo);
	}
	
	
    /**
	 * DAO-method for retrieving total count of performance by office.(weekly) <br>
	 *
	 * @param vo Input item for retrieving total count of performance by office(StsBsnWrkStusVO).
	 * @return int Total Count of total count of performance by office
	 * @exception Exception
	 */
    public int selectListBsnWrkStusInfrWeeklyTotCn(StsBsnWrkStusVO vo) {
        return (Integer)selectByPk("stsDAO.selectListBsnWrkStusInfrWeeklyTotCn", vo);
    } 
    
	/**
	 * DAO-method for retrieving list of performance by office.(monthly) <br>	  
	 *
	 * @param vo Input item for retrieving list of performance by office(StsBsnWrkStusVO).
	 * @return List Retrieve list of performance by office
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<StsBsnWrkStusVO> selectListBsnWrkStusInfrMonthly(StsBsnWrkStusVO vo) throws Exception{
		return list("stsDAO.selectListBsnWrkStusInfrMonthly", vo);
	}
	
    /**
	 * DAO-method for retrieving total count of performance by office.(monthly) <br>
	 *
	 * @param vo Input item for retrieving total count of performance by office(StsBsnWrkStusVO).
	 * @return int Total Count of total count of performance by office
	 * @exception Exception
	 */
    public int selectListBsnWrkStusInfrMonthlyTotCn(StsBsnWrkStusVO vo) {
        return (Integer)selectByPk("stsDAO.selectListBsnWrkStusInfrMonthlyTotCn", vo);
    } 
    
	/**
	 * DAO-method for retrieving list of performance by office.(year) <br>	  
	 *
	 * @param vo Input item for retrieving list of performance by office(StsBsnWrkStusVO).
	 * @return List Retrieve list of performance by office
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<StsBsnWrkStusVO> selectListBsnWrkStusInfrYearly(StsBsnWrkStusVO vo) throws Exception{
		return list("stsDAO.selectListBsnWrkStusInfrYearly", vo);
	}
	
    /**
	 * DAO-method for retrieving total count of performance by office.(year) <br>
	 *
	 * @param vo Input item for retrieving total count of performance by office(StsBsnWrkStusVO).
	 * @return int Total Count of total count of performance by office
	 * @exception Exception
	 */
    public int selectListBsnWrkStusInfrYearlyTotCn(StsBsnWrkStusVO vo) {
        return (Integer)selectByPk("stsDAO.selectListBsnWrkStusInfrYearlyTotCn", vo);
    }
    
    
	/**
	 * DAO-method for retrieving list of performance by office.(total) <br>	  
	 *
	 * @param vo Input item for retrieving list of performance by office(StsBsnWrkStusVO).
	 * @return List Retrieve list of performance by office
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<StsBsnWrkStusVO> selectListBsnWrkStusInfr(StsBsnWrkStusVO vo) throws Exception{
		return list("stsDAO.selectListBsnWrkStusInfr", vo);
	}

	
	
    /**
	 * DAO-method for retrieving total count of performance by office. <br>
	 *
	 * @param vo Input item for retrieving total count of performance by office(StsBsnWrkStusVO).
	 * @return int Total Count of total count of performance by office
	 * @exception Exception
	 */
    public int selectListBsnWrkStusInfrTotCn(StsBsnWrkStusVO vo) {
        return (Integer)selectByPk("stsDAO.selectListBsnWrkStusInfrTotCn", vo);
    }    
	
	/**
	 * DAO-method for retrieving list of performance by team.(total) <br>	  
	 *
	 * @param vo Input item for retrieving list of performance by team(StsBsnWrkStusVO).
	 * @return List Retrieve list of performance by team
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<StsBsnWrkStusVO> selectListTamBsnWrkStusInfr(StsBsnWrkStusVO vo) throws Exception{
		return list("stsDAO.selectListTamBsnWrkStusInfr", vo);
	}
    
    /**
	 * DAO-method for retrieving total count of performance by team.(total) <br>
	 *
	 * @param vo Input item for retrieving total count of performance by team(StsBsnWrkStusVO).
	 * @return int Total Count of total count of performance by team
	 * @exception Exception
	 */
    public int selectListTamBsnWrkStusInfrTotCn(StsBsnWrkStusVO vo) {
        return (Integer)selectByPk("stsDAO.selectListTamBsnWrkStusInfrTotCn", vo);
    }
    
	/**
	 * DAO-method for retrieving list of performance by user.(total) <br>	  
	 *
	 * @param vo Input item for retrieving list of performance by user(StsBsnWrkStusVO).
	 * @return List Retrieve list of performance by user
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<StsBsnWrkStusVO> selectListUserBsnWrkStusInfr(StsBsnWrkStusVO vo) throws Exception{
		return list("stsDAO.selectListUserBsnWrkStusInfr", vo);
	}
    
    /**
	 * DAO-method for retrieving total count of performance by user. <br>
	 *
	 * @param vo Input item for retrieving total count of performance by user(StsBsnWrkStusVO).
	 * @return int Total Count of total count of performance by user
	 * @exception Exception
	 */
    public int selectListUserBsnWrkStusInfrTotCn(StsBsnWrkStusVO vo) {
        return (Integer)selectByPk("stsDAO.selectListUserBsnWrkStusInfrTotCn", vo);
    }    
    
    
	/**
	 * DAO-method for adding the days to persian start day. <br>
	 * 
	 * @param vo Input item for adding the days to start day(StsBsnWrkStusVO).
	 * @return String
	 * @exception Exception
	 */
	public String selectBsnWrkStusStartPreDay(StsBsnWrkStusVO vo)throws Exception {
		return (String)selectByPk("stsDAO.selectBsnWrkStusStartPreDay", vo);
	}	
	
	
	/**
	 * DAO-method for adding the days to persian last day. <br>
	 * 
	 * @param vo Input item for adding the days to last days(StsBsnWrkStusVO).
	 * @return String
	 * @exception Exception
	 */
	public String selectBsnWrkStusEndPreDay(StsBsnWrkStusVO vo)throws Exception {
		return (String)selectByPk("stsDAO.selectBsnWrkStusEndPreDay", vo);
	}	
	
	
	/**
	 * DAO-method for adding the days to Gregorian stsrt day. <br>
	 * 
	 * @param vo Input item for adding the days to start day(StsBsnWrkStusVO).
	 * @return String
	 * @exception Exception
	 */
	public String selectBsnWrkStusStartGreDay(StsBsnWrkStusVO vo)throws Exception {
		return (String)selectByPk("stsDAO.selectBsnWrkStusStartGreDay", vo);
	}	
	
	
	/**
	 * DAO-method for adding the days to Gregorian last day. <br>
	 * 
	 * @param vo Input item for adding the days to last daysStsBsnWrkStusVO).
	 * @return String
	 * @exception Exception
	 */
	public String selectBsnWrkStusEndGreDay(StsBsnWrkStusVO vo)throws Exception {
		return (String)selectByPk("stsDAO.selectBsnWrkStusEndGreDay", vo);
	}	
	
	/**
	 * DAO-method for getting day. <br>
	 * 
	 * @param String Input item for adding the days to last days.
	 * @return String
	 * @exception Exception
	 */
	public String selectMaxYmd(String key)throws Exception {
		return (String)selectByPk("stsDAO.selectMaxYmd", key);
	}
	
	/**
	 * DAO-method for getting day interval. <br>
	 * 
	 * @param String Input item for getting day interval.
	 * @return String
	 * @exception Exception
	 */
	public int selectDdItv(String key)throws Exception {
		return (Integer)selectByPk("stsDAO.selectDdItv", key);
	}
	
	/**
	 * DAO-method for getting day . <br>
	 * 
	 * @param String Input item for getting generation day .
	 * @return String
	 * @exception Exception
	 */
	public String selectCrnDd(int itv)throws Exception {
		return (String)selectByPk("stsDAO.selectCrnDd", itv);
	}
	
	/**
	 * DAO-method for check of the already requested Statistic. <br>
	 *
	 * @param String Input item for check of the already requested Statistic.
	 * @return int result of check of the already requested Statistic
	 * @exception Exception
	 */	
    public int selectRsdtStsRqstYn(String gCrnDd) {
        return (Integer)selectByPk("stsDAO.selectRsdtStsRqstYn", gCrnDd);
    }
    
	/**
	 * DAO-method for request generation of population statistics<br>
	 *
	 * @param String Input item for request generation of population statistics.
	 * @return void
	 * @exception Exception
	 */	
    public void insertRsdtStsRqst(StsSrchVO vo) {
    	insert("stsDAO.insertRsdtStsRqst", vo);
    } 	
	
	/**
	 * DAO-method for request generation of population statistics<br>
	 *
	 * @param String Input item for request generation of population statistics.
	 * @return void
	 * @exception Exception
	 */	
    public void updateRsdtStsRqst(StsSrchVO vo) {
    	update("stsDAO.updateRsdtStsRqst", vo);
    } 
    
	/**
	 * DAO-method for retrieving list of statistic generation request.<br>
	 * 
	 * @param vo Input item for retrieving list of statistic generation request(StsSrchVO).
	 * @return List Retrieve list of statistic generation request
	 * @exception Exception 
	 */		
	@SuppressWarnings("unchecked")
	public List<StsSrchVO> selectListRsdtStsRqst(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListRsdtStsRqst", vo);
	}
	
	/**
	 * DAO-method for retrieving total count list of statistic generation request. <br>
	 * 
	 * @param vo Input item for retrieving list of statistic generation request(StsSrchVO).
	 * @return int Total Count of statistic generation request list
	 * @exception Exception 
	 */
    public int selectListRsdtStsRqstTotCn(StsSrchVO vo) {
        return (Integer)selectByPk("stsDAO.selectListRsdtStsRqstTotCn", vo);
    }
 
	/**
	 * DAO-method for retrieving sequence number of statistic generation request . <br>
	 * 
	 * @param vo Input item for retrieving sequence number of statistic generation request(StsSrchVO).
	 * @return int sequence number of statistic generation request
	 * @exception Exception 
	 */
    public String selectRsdtStsGnrSeqNo(String val) {
        return (String)selectByPk("stsDAO.selectRsdtStsGnrSeqNo", val);
    }
    
    
    
    
    
    
    /**
	 * DAO-method for retrieving total count list of statistic generation request. <br>
	 * 
	 * @param vo Input item for retrieving list of statistic generation request(StsSrchVO).
	 * @return int Total Count of statistic generation request list
	 * @exception Exception 
	 */
    public int selectRmStsEcptRsdtTb(EgovMap vo) {
        return (Integer)selectByPk("stsDAO.selectRmStsEcptRsdtTb", vo);
    }
    
    /**
	 * DAO-method for request generation of population statistics<br>
	 *
	 * @param String Input item for request generation of population statistics.
	 * @return void
	 * @exception Exception
	 */	
    public void insertRmStsEcptRsdtTb(EgovMap vo) {
    	insert("stsDAO.insertRmStsEcptRsdtTb", vo);
    } 
    
    
    
    /**
	 * DAO-method for retrieving list of statistic generation request.<br>
	 * 
	 * @param vo Input item for retrieving list of statistic generation request(StsSrchVO).
	 * @return List Retrieve list of statistic generation request
	 * @exception Exception 
	 */		
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectImRsdtViewTb(EgovMap vo) throws Exception{
		return list("stsDAO.selectImRsdtViewTb", vo);
	}
	
	
	
	
	
	
	/**
	 * DAO-method for retrieving total count list of statistic generation request. <br>
	 * 
	 * @param EgovMap
	 * @return List
	 * @exception Exception 
	 */
	@SuppressWarnings("unchecked")
    public List<EgovMap> selectRmCurtAdStsTb(EgovMap vo) {
        return list("stsDAO.selectRmCurtAdStsTb", vo);
    }
    
    
    /**
	 * DAO-method for retrieving total count list of statistic generation request. <br>
	 * 
	 * @param EgovMap
	 * @return List
	 * @exception Exception 
	 */
	@SuppressWarnings("unchecked")
    public List<EgovMap> selectRmRlgnSectStsTb(EgovMap vo) {
        return list("stsDAO.selectRmRlgnSectStsTb", vo);
    }
    
    /**
	 * DAO-method for retrieving total count list of statistic generation request. <br>
	 * 
	 * @param EgovMap
	 * @return List
	 * @exception Exception 
	 */
	@SuppressWarnings("unchecked")
    public List<EgovMap> selectRmEncyStsTb(EgovMap vo) {
        return list("stsDAO.selectRmEncyStsTb", vo);
    }
    
    /**
	 * DAO-method for retrieving total count list of statistic generation request. <br>
	 * 
	 * @param EgovMap
	 * @return List
	 * @exception Exception 
	 */
	@SuppressWarnings("unchecked")
    public List<EgovMap> selectRmPoliStatStsTb(EgovMap vo) {
        return list("stsDAO.selectRmPoliStatStsTb", vo);
    }
	
	
	
	
	/**
	 * DAO-method for request generation of population statistics<br>
	 *
	 * @param EgovMap
	 * @return int
	 * @exception Exception
	 */	
    public int updateRmCurtAdStsTb(EgovMap vo) {
    	return update("stsDAO.updateRmCurtAdStsTb", vo);
    } 
    /**
	 * DAO-method for request generation of population statistics<br>
	 *
	 * @param EgovMap
	 * @return int
	 * @exception Exception
	 */	
    public int updateRmRlgnSectStsTb(EgovMap vo) {
    	return update("stsDAO.updateRmRlgnSectStsTb", vo);
    } 
    /**
	 * DAO-method for request generation of population statistics<br>
	 *
	 * @param EgovMap
	 * @return int
	 * @exception Exception
	 */	
    public int updateRmEncyStsTb(EgovMap vo) {
    	return update("stsDAO.updateRmEncyStsTb", vo);
    } 
    /**
	 * DAO-method for request generation of population statistics<br>
	 *
	 * @param EgovMap
	 * @return int
	 * @exception Exception
	 */	
    public int updateRmPoliStatStsTb(EgovMap vo) {
    	return update("stsDAO.updateRmPoliStatStsTb", vo);
    } 
	
    
    
    /**
	 * DAO-method for retrieving Statistic of Population by Age. <br>
	 *
	 * @param StsSrchVO
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRmCurtAdStsTbSign(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectRmCurtAdStsTbSign", vo);
	}
	 /**
	 * DAO-method for request generation of population statistics<br>
	 *
	 * @param EgovMap
	 * @return int
	 * @exception Exception
	 */	
    public int updateRmCurtAdStsTbSign(EgovMap vo) {
    	return update("stsDAO.updateRmCurtAdStsTbSign", vo);
    }
    
    
    
    
    /**
	 * DAO-method for retrieving Statistic of Population by Age. <br>
	 *
	 * @param StsSrchVO
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRmRlgnSectStsTbSign(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectRmRlgnSectStsTbSign", vo);
	}
	 /**
	 * DAO-method for request generation of population statistics<br>
	 *
	 * @param EgovMap
	 * @return int
	 * @exception Exception
	 */	
    public int updateRmRlgnSectStsTbSign(EgovMap vo) {
    	return update("stsDAO.updateRmRlgnSectStsTbSign", vo);
    }
    
    
    
    /**
	 * DAO-method for retrieving Statistic of Population by Age. <br>
	 *
	 * @param StsSrchVO
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRmEncyStsTbSign(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectRmEncyStsTbSign", vo);
	}
	 /**
	 * DAO-method for request generation of population statistics<br>
	 *
	 * @param EgovMap
	 * @return int
	 * @exception Exception
	 */	
    public int updateRmEncyStsTbSign(EgovMap vo) {
    	return update("stsDAO.updateRmEncyStsTbSign", vo);
    }
    
    
    
    /**
	 * DAO-method for retrieving Statistic of Population by Age. <br>
	 *
	 * @param StsSrchVO
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRmPoliStatStsTbSign(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectRmPoliStatStsTbSign", vo);
	}
	 /**
	 * DAO-method for request generation of population statistics<br>
	 *
	 * @param EgovMap
	 * @return int
	 * @exception Exception
	 */	
    public int updateRmPoliStatStsTbSign(EgovMap vo) {
    	return update("stsDAO.updateRmPoliStatStsTbSign", vo);
    }
    
    
    
    
    
    /**
	 * DAO-method for retrieving Statistic of Population by Age. <br>
	 *
	 * @param StsSrchVO
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListRmEcptRsdtTbGb(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListRmEcptRsdtTbGb", vo);
	}
    
	
	
	
	
	/**
	 * DAO-method for retrieving Statistic of Resident Registration Status. <br>	  
	 *
	 * @param StsSrchVO
	 * @return List
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListStsEcptRsdt(StsSrchVO vo) throws Exception{
		return list("stsDAO.selectListStsEcptRsdt", vo);
	}

    /**
	 * DAO-method for retrieving total count  of  Resident Registration Status list. <br>
	 *
	 * @param StsSrchVO
	 * @return int
	 * @exception Exception
	 */
    public int selectListStsEcptRsdtTotCn(StsSrchVO vo) {
        return (Integer)selectByPk("stsDAO.selectListStsEcptRsdtTotCn", vo);
    }
    
    
}
