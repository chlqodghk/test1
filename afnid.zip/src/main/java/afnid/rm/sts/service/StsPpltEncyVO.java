package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsPpltEncyVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String sysSgntInsp;
	private String crnDd;
	private String ency43Cnt;	
	private String ency42Cnt;	
	private String ency41Cnt;
	private String ency40Cnt;
	private String ency39Cnt;
	private String ency38Cnt;
	private String ency37Cnt;
	private String ency36Cnt;
	private String ency35Cnt;
	private String ency34Cnt;
	private String ency33Cnt;
	private String ency32Cnt;
	private String ency31Cnt;
	private String ency30Cnt;
	private String ency29Cnt;
	private String ency28Cnt;
	private String ency27Cnt;
	private String ency26Cnt;
	private String ency25Cnt;
	private String ency24Cnt;
	private String ency23Cnt;
	private String ency22Cnt;
	private String ency21Cnt;
	private String ency20Cnt;
	private String ency19Cnt;
	private String ency18Cnt;
	private String ency17Cnt;
	private String ency16Cnt;
	private String ency15Cnt;
	private String ency14Cnt;
	private String ency13Cnt;
	private String ency12Cnt;
	private String ency11Cnt;
	private String ency10Cnt;
	private String ency09Cnt;
	private String ency08Cnt;
	private String ency07Cnt;
	private String ency06Cnt;
	private String ency05Cnt;
	private String ency04Cnt;
	private String ency03Cnt;
	private String ency02Cnt;
	private String ency01Cnt;
	private String dstrNm;
	private String prvicNm;
	private String curtAdCd;
	private String stsTitCd;
	private String stsTitNm;	
	private String adCd;
	private String adCdNm;	
	

	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	
	public String getEncy43Cnt() {
		return ency43Cnt;
	}
	public void setEncy43Cnt(String ency43Cnt) {
		this.ency43Cnt = ency43Cnt;
	}
	public String getEncy42Cnt() {
		return ency42Cnt;
	}
	public void setEncy42Cnt(String ency42Cnt) {
		this.ency42Cnt = ency42Cnt;
	}
	
	public String getEncy41Cnt() {
		return ency41Cnt;
	}
	public void setEncy41Cnt(String ency41Cnt) {
		this.ency41Cnt = ency41Cnt;
	}
	public String getEncy40Cnt() {
		return ency40Cnt;
	}
	public void setEncy40Cnt(String ency40Cnt) {
		this.ency40Cnt = ency40Cnt;
	}
	public String getEncy39Cnt() {
		return ency39Cnt;
	}
	public void setEncy39Cnt(String ency39Cnt) {
		this.ency39Cnt = ency39Cnt;
	}
	public String getEncy38Cnt() {
		return ency38Cnt;
	}
	public void setEncy38Cnt(String ency38Cnt) {
		this.ency38Cnt = ency38Cnt;
	}
	public String getEncy37Cnt() {
		return ency37Cnt;
	}
	public void setEncy37Cnt(String ency37Cnt) {
		this.ency37Cnt = ency37Cnt;
	}
	public String getEncy36Cnt() {
		return ency36Cnt;
	}
	public void setEncy36Cnt(String ency36Cnt) {
		this.ency36Cnt = ency36Cnt;
	}
	public String getEncy35Cnt() {
		return ency35Cnt;
	}
	public void setEncy35Cnt(String ency35Cnt) {
		this.ency35Cnt = ency35Cnt;
	}
	public String getEncy34Cnt() {
		return ency34Cnt;
	}
	public void setEncy34Cnt(String ency34Cnt) {
		this.ency34Cnt = ency34Cnt;
	}
	public String getEncy33Cnt() {
		return ency33Cnt;
	}
	public void setEncy33Cnt(String ency33Cnt) {
		this.ency33Cnt = ency33Cnt;
	}
	public String getEncy32Cnt() {
		return ency32Cnt;
	}
	public void setEncy32Cnt(String ency32Cnt) {
		this.ency32Cnt = ency32Cnt;
	}
	public String getEncy31Cnt() {
		return ency31Cnt;
	}
	public void setEncy31Cnt(String ency31Cnt) {
		this.ency31Cnt = ency31Cnt;
	}
	public String getEncy30Cnt() {
		return ency30Cnt;
	}
	public void setEncy30Cnt(String ency30Cnt) {
		this.ency30Cnt = ency30Cnt;
	}
	public String getEncy29Cnt() {
		return ency29Cnt;
	}
	public void setEncy29Cnt(String ency29Cnt) {
		this.ency29Cnt = ency29Cnt;
	}
	public String getEncy28Cnt() {
		return ency28Cnt;
	}
	public void setEncy28Cnt(String ency28Cnt) {
		this.ency28Cnt = ency28Cnt;
	}
	public String getEncy27Cnt() {
		return ency27Cnt;
	}
	public void setEncy27Cnt(String ency27Cnt) {
		this.ency27Cnt = ency27Cnt;
	}
	public String getEncy26Cnt() {
		return ency26Cnt;
	}
	public void setEncy26Cnt(String ency26Cnt) {
		this.ency26Cnt = ency26Cnt;
	}
	public String getEncy25Cnt() {
		return ency25Cnt;
	}
	public void setEncy25Cnt(String ency25Cnt) {
		this.ency25Cnt = ency25Cnt;
	}
	public String getEncy24Cnt() {
		return ency24Cnt;
	}
	public void setEncy24Cnt(String ency24Cnt) {
		this.ency24Cnt = ency24Cnt;
	}
	public String getEncy23Cnt() {
		return ency23Cnt;
	}
	public void setEncy23Cnt(String ency23Cnt) {
		this.ency23Cnt = ency23Cnt;
	}
	public String getEncy22Cnt() {
		return ency22Cnt;
	}
	public void setEncy22Cnt(String ency22Cnt) {
		this.ency22Cnt = ency22Cnt;
	}
	public String getEncy21Cnt() {
		return ency21Cnt;
	}
	public void setEncy21Cnt(String ency21Cnt) {
		this.ency21Cnt = ency21Cnt;
	}
	public String getEncy20Cnt() {
		return ency20Cnt;
	}
	public void setEncy20Cnt(String ency20Cnt) {
		this.ency20Cnt = ency20Cnt;
	}
	public String getEncy19Cnt() {
		return ency19Cnt;
	}
	public void setEncy19Cnt(String ency19Cnt) {
		this.ency19Cnt = ency19Cnt;
	}
	public String getEncy18Cnt() {
		return ency18Cnt;
	}
	public void setEncy18Cnt(String ency18Cnt) {
		this.ency18Cnt = ency18Cnt;
	}
	public String getEncy17Cnt() {
		return ency17Cnt;
	}
	public void setEncy17Cnt(String ency17Cnt) {
		this.ency17Cnt = ency17Cnt;
	}
	public String getEncy16Cnt() {
		return ency16Cnt;
	}
	public void setEncy16Cnt(String ency16Cnt) {
		this.ency16Cnt = ency16Cnt;
	}
	public String getEncy15Cnt() {
		return ency15Cnt;
	}
	public void setEncy15Cnt(String ency15Cnt) {
		this.ency15Cnt = ency15Cnt;
	}
	public String getEncy14Cnt() {
		return ency14Cnt;
	}
	public void setEncy14Cnt(String ency14Cnt) {
		this.ency14Cnt = ency14Cnt;
	}
	public String getEncy13Cnt() {
		return ency13Cnt;
	}
	public void setEncy13Cnt(String ency13Cnt) {
		this.ency13Cnt = ency13Cnt;
	}
	public String getEncy12Cnt() {
		return ency12Cnt;
	}
	public void setEncy12Cnt(String ency12Cnt) {
		this.ency12Cnt = ency12Cnt;
	}
	public String getEncy11Cnt() {
		return ency11Cnt;
	}
	public void setEncy11Cnt(String ency11Cnt) {
		this.ency11Cnt = ency11Cnt;
	}
	public String getEncy10Cnt() {
		return ency10Cnt;
	}
	public void setEncy10Cnt(String ency10Cnt) {
		this.ency10Cnt = ency10Cnt;
	}
	public String getEncy09Cnt() {
		return ency09Cnt;
	}
	public void setEncy09Cnt(String ency09Cnt) {
		this.ency09Cnt = ency09Cnt;
	}
	public String getEncy08Cnt() {
		return ency08Cnt;
	}
	public void setEncy08Cnt(String ency08Cnt) {
		this.ency08Cnt = ency08Cnt;
	}
	public String getEncy07Cnt() {
		return ency07Cnt;
	}
	public void setEncy07Cnt(String ency07Cnt) {
		this.ency07Cnt = ency07Cnt;
	}
	public String getEncy06Cnt() {
		return ency06Cnt;
	}
	public void setEncy06Cnt(String ency06Cnt) {
		this.ency06Cnt = ency06Cnt;
	}
	public String getEncy05Cnt() {
		return ency05Cnt;
	}
	public void setEncy05Cnt(String ency05Cnt) {
		this.ency05Cnt = ency05Cnt;
	}
	public String getEncy04Cnt() {
		return ency04Cnt;
	}
	public void setEncy04Cnt(String ency04Cnt) {
		this.ency04Cnt = ency04Cnt;
	}
	public String getEncy03Cnt() {
		return ency03Cnt;
	}
	public void setEncy03Cnt(String ency03Cnt) {
		this.ency03Cnt = ency03Cnt;
	}
	public String getEncy02Cnt() {
		return ency02Cnt;
	}
	public void setEncy02Cnt(String ency02Cnt) {
		this.ency02Cnt = ency02Cnt;
	}
	public String getEncy01Cnt() {
		return ency01Cnt;
	}
	public void setEncy01Cnt(String ency01Cnt) {
		this.ency01Cnt = ency01Cnt;
	}
	public String getDstrNm() {
		return dstrNm;
	}
	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}
	public String getPrvicNm() {
		return prvicNm;
	}
	public void setPrvicNm(String prvicNm) {
		this.prvicNm = prvicNm;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getStsTitCd() {
		return stsTitCd;
	}
	public void setStsTitCd(String stsTitCd) {
		this.stsTitCd = stsTitCd;
	}
	public String getStsTitNm() {
		return stsTitNm;
	}
	public void setStsTitNm(String stsTitNm) {
		this.stsTitNm = stsTitNm;
	}
	public String getAdCd() {
		return adCd;
	}
	public void setAdCd(String adCd) {
		this.adCd = adCd;
	}
	public String getAdCdNm() {
		return adCdNm;
	}
	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}
	public String getSysSgntInsp() {
		return sysSgntInsp;
	}
	public void setSysSgntInsp(String sysSgntInsp) {
		this.sysSgntInsp = sysSgntInsp;
	}


}
