package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsPpltMthrTguVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String crnDd;
	private String lang35FmlCnt;
	private String lang35MlCnt ;
	private String lang35TotCnt;	
	private String lang34FmlCnt;
	private String lang34MlCnt ;
	private String lang34TotCnt;
	private String lang33FmlCnt;
	private String lang33MlCnt ;
	private String lang33TotCnt;
	private String lang32FmlCnt;
	private String lang32MlCnt ;
	private String lang32TotCnt;
	private String lang31FmlCnt;
	private String lang31MlCnt ;
	private String lang31TotCnt;
	private String lang30FmlCnt;
	private String lang30MlCnt ;
	private String lang30TotCnt ;
	private String lang29FmlCnt;
	private String lang29MlCnt  ;
	private String lang29TotCnt;
	private String lang28FmlCnt;
	private String lang28MlCnt ;
	private String lang28TotCnt;
	private String lang27FmlCnt;
	private String lang27MlCnt ;
	private String lang27TotCnt;
	private String lang26FmlCnt;
	private String lang26MlCnt ;
	private String lang26TotCnt;
	private String lang25FmlCnt;
	private String lang25MlCnt ;
	private String lang25TotCnt;
	private String lang24FmlCnt;
	private String lang24MlCnt ;
	private String lang24TotCnt;
	private String lang23FmlCnt;
	private String lang23MlCnt ;
	private String lang23TotCnt;
	private String lang22FmlCnt;
	private String lang22MlCnt ;
	private String lang22TotCnt;
	private String lang21FmlCnt;
	private String lang21MlCnt ;
	private String lang21TotCnt;
	private String lang20FmlCnt;
	private String lang20MlCnt ;
	private String lang20TotCnt;
	private String lang19FmlCnt;
	private String lang19MlCnt ;
	private String lang19TotCnt;
	private String lang18FmlCnt;
	private String lang18MlCnt ;
	private String lang18TotCnt;
	private String lang17FmlCnt;
	private String lang17MlCnt ;
	private String lang17TotCnt;
	private String lang16FmlCnt;
	private String lang16MlCnt ;
	private String lang16TotCnt;
	private String lang15FmlCnt;
	private String lang15MlCnt ;
	private String lang15TotCnt;
	private String lang14FmlCnt;
	private String lang14MlCnt ;
	private String lang14TotCnt;
	private String lang13FmlCnt;
	private String lang13MlCnt ;
	private String lang13TotCnt;
	private String lang12FmlCnt;
	private String lang12MlCnt ;
	private String lang12TotCnt;
	private String lang11FmlCnt;
	private String lang11MlCnt ;
	private String lang11TotCnt;
	private String lang10FmlCnt;
	private String lang10MlCnt ;
	private String lang10TotCnt ;
	private String lang09FmlCnt;
	private String lang09MlCnt ;
	private String lang09TotCnt;
	private String lang08FmlCnt;
	private String lang08MlCnt ;
	private String lang08TotCnt;
	private String lang07FmlCnt;
	private String lang07MlCnt ;
	private String lang07TotCnt;
	private String lang06FmlCnt;
	private String lang06MlCnt ;
	private String lang06TotCnt;
	private String lang05FmlCnt;
	private String lang05MlCnt ;
	private String lang05TotCnt;
	private String lang04FmlCnt;
	private String lang04MlCnt ;
	private String lang04TotCnt;
	private String lang03FmlCnt;
	private String lang03MlCnt ;
	private String lang03TotCnt;
	private String lang02FmlCnt;
	private String lang02MlCnt ;
	private String lang02TotCnt;
	private String lang01FmlCnt;
	private String lang01MlCnt ;
	private String lang01TotCnt;
	private String dstrNm;
	private String prvicNm;
	private String curtAdCd;
	private String stsTitCd;
	private String stsTitNm;
	private String adCd;
	private String adCdNm;	
	

	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	
	public String getLang35FmlCnt() {
		return lang35FmlCnt;
	}
	public void setLang35FmlCnt(String lang35FmlCnt) {
		this.lang35FmlCnt = lang35FmlCnt;
	}
	public String getLang35MlCnt() {
		return lang35MlCnt;
	}
	public void setLang35MlCnt(String lang35MlCnt) {
		this.lang35MlCnt = lang35MlCnt;
	}
	public String getLang35TotCnt() {
		return lang35TotCnt;
	}
	public void setLang35TotCnt(String lang35TotCnt) {
		this.lang35TotCnt = lang35TotCnt;
	}
	public String getLang34FmlCnt() {
		return lang34FmlCnt;
	}
	public void setLang34FmlCnt(String lang34FmlCnt) {
		this.lang34FmlCnt = lang34FmlCnt;
	}
	public String getLang34MlCnt() {
		return lang34MlCnt;
	}
	public void setLang34MlCnt(String lang34MlCnt) {
		this.lang34MlCnt = lang34MlCnt;
	}
	public String getLang34TotCnt() {
		return lang34TotCnt;
	}
	public void setLang34TotCnt(String lang34TotCnt) {
		this.lang34TotCnt = lang34TotCnt;
	}
	public String getLang33FmlCnt() {
		return lang33FmlCnt;
	}
	public void setLang33FmlCnt(String lang33FmlCnt) {
		this.lang33FmlCnt = lang33FmlCnt;
	}
	public String getLang33MlCnt() {
		return lang33MlCnt;
	}
	public void setLang33MlCnt(String lang33MlCnt) {
		this.lang33MlCnt = lang33MlCnt;
	}
	public String getLang33TotCnt() {
		return lang33TotCnt;
	}
	public void setLang33TotCnt(String lang33TotCnt) {
		this.lang33TotCnt = lang33TotCnt;
	}
	public String getLang32FmlCnt() {
		return lang32FmlCnt;
	}
	public void setLang32FmlCnt(String lang32FmlCnt) {
		this.lang32FmlCnt = lang32FmlCnt;
	}
	public String getLang32MlCnt() {
		return lang32MlCnt;
	}
	public void setLang32MlCnt(String lang32MlCnt) {
		this.lang32MlCnt = lang32MlCnt;
	}
	public String getLang32TotCnt() {
		return lang32TotCnt;
	}
	public void setLang32TotCnt(String lang32TotCnt) {
		this.lang32TotCnt = lang32TotCnt;
	}
	public String getLang31FmlCnt() {
		return lang31FmlCnt;
	}
	public void setLang31FmlCnt(String lang31FmlCnt) {
		this.lang31FmlCnt = lang31FmlCnt;
	}
	public String getLang31MlCnt() {
		return lang31MlCnt;
	}
	public void setLang31MlCnt(String lang31MlCnt) {
		this.lang31MlCnt = lang31MlCnt;
	}
	public String getLang31TotCnt() {
		return lang31TotCnt;
	}
	public void setLang31TotCnt(String lang31TotCnt) {
		this.lang31TotCnt = lang31TotCnt;
	}
	public String getLang30FmlCnt() {
		return lang30FmlCnt;
	}
	public void setLang30FmlCnt(String lang30FmlCnt) {
		this.lang30FmlCnt = lang30FmlCnt;
	}
	public String getLang30MlCnt() {
		return lang30MlCnt;
	}
	public void setLang30MlCnt(String lang30MlCnt) {
		this.lang30MlCnt = lang30MlCnt;
	}
	public String getLang30TotCnt() {
		return lang30TotCnt;
	}
	public void setLang30TotCnt(String lang30TotCnt) {
		this.lang30TotCnt = lang30TotCnt;
	}
	public String getLang29FmlCnt() {
		return lang29FmlCnt;
	}
	public void setLang29FmlCnt(String lang29FmlCnt) {
		this.lang29FmlCnt = lang29FmlCnt;
	}
	public String getLang29MlCnt() {
		return lang29MlCnt;
	}
	public void setLang29MlCnt(String lang29MlCnt) {
		this.lang29MlCnt = lang29MlCnt;
	}
	public String getLang29TotCnt() {
		return lang29TotCnt;
	}
	public void setLang29TotCnt(String lang29TotCnt) {
		this.lang29TotCnt = lang29TotCnt;
	}
	public String getLang28FmlCnt() {
		return lang28FmlCnt;
	}
	public void setLang28FmlCnt(String lang28FmlCnt) {
		this.lang28FmlCnt = lang28FmlCnt;
	}
	public String getLang28MlCnt() {
		return lang28MlCnt;
	}
	public void setLang28MlCnt(String lang28MlCnt) {
		this.lang28MlCnt = lang28MlCnt;
	}
	public String getLang28TotCnt() {
		return lang28TotCnt;
	}
	public void setLang28TotCnt(String lang28TotCnt) {
		this.lang28TotCnt = lang28TotCnt;
	}
	public String getLang27FmlCnt() {
		return lang27FmlCnt;
	}
	public void setLang27FmlCnt(String lang27FmlCnt) {
		this.lang27FmlCnt = lang27FmlCnt;
	}
	public String getLang27MlCnt() {
		return lang27MlCnt;
	}
	public void setLang27MlCnt(String lang27MlCnt) {
		this.lang27MlCnt = lang27MlCnt;
	}
	public String getLang27TotCnt() {
		return lang27TotCnt;
	}
	public void setLang27TotCnt(String lang27TotCnt) {
		this.lang27TotCnt = lang27TotCnt;
	}
	public String getLang26FmlCnt() {
		return lang26FmlCnt;
	}
	public void setLang26FmlCnt(String lang26FmlCnt) {
		this.lang26FmlCnt = lang26FmlCnt;
	}
	public String getLang26MlCnt() {
		return lang26MlCnt;
	}
	public void setLang26MlCnt(String lang26MlCnt) {
		this.lang26MlCnt = lang26MlCnt;
	}
	public String getLang26TotCnt() {
		return lang26TotCnt;
	}
	public void setLang26TotCnt(String lang26TotCnt) {
		this.lang26TotCnt = lang26TotCnt;
	}
	public String getLang25FmlCnt() {
		return lang25FmlCnt;
	}
	public void setLang25FmlCnt(String lang25FmlCnt) {
		this.lang25FmlCnt = lang25FmlCnt;
	}
	public String getLang25MlCnt() {
		return lang25MlCnt;
	}
	public void setLang25MlCnt(String lang25MlCnt) {
		this.lang25MlCnt = lang25MlCnt;
	}
	public String getLang25TotCnt() {
		return lang25TotCnt;
	}
	public void setLang25TotCnt(String lang25TotCnt) {
		this.lang25TotCnt = lang25TotCnt;
	}
	public String getLang24FmlCnt() {
		return lang24FmlCnt;
	}
	public void setLang24FmlCnt(String lang24FmlCnt) {
		this.lang24FmlCnt = lang24FmlCnt;
	}
	public String getLang24MlCnt() {
		return lang24MlCnt;
	}
	public void setLang24MlCnt(String lang24MlCnt) {
		this.lang24MlCnt = lang24MlCnt;
	}
	public String getLang24TotCnt() {
		return lang24TotCnt;
	}
	public void setLang24TotCnt(String lang24TotCnt) {
		this.lang24TotCnt = lang24TotCnt;
	}
	public String getLang23FmlCnt() {
		return lang23FmlCnt;
	}
	public void setLang23FmlCnt(String lang23FmlCnt) {
		this.lang23FmlCnt = lang23FmlCnt;
	}
	public String getLang23MlCnt() {
		return lang23MlCnt;
	}
	public void setLang23MlCnt(String lang23MlCnt) {
		this.lang23MlCnt = lang23MlCnt;
	}
	public String getLang23TotCnt() {
		return lang23TotCnt;
	}
	public void setLang23TotCnt(String lang23TotCnt) {
		this.lang23TotCnt = lang23TotCnt;
	}
	public String getLang22FmlCnt() {
		return lang22FmlCnt;
	}
	public void setLang22FmlCnt(String lang22FmlCnt) {
		this.lang22FmlCnt = lang22FmlCnt;
	}
	public String getLang22MlCnt() {
		return lang22MlCnt;
	}
	public void setLang22MlCnt(String lang22MlCnt) {
		this.lang22MlCnt = lang22MlCnt;
	}
	public String getLang22TotCnt() {
		return lang22TotCnt;
	}
	public void setLang22TotCnt(String lang22TotCnt) {
		this.lang22TotCnt = lang22TotCnt;
	}
	public String getLang21FmlCnt() {
		return lang21FmlCnt;
	}
	public void setLang21FmlCnt(String lang21FmlCnt) {
		this.lang21FmlCnt = lang21FmlCnt;
	}
	public String getLang21MlCnt() {
		return lang21MlCnt;
	}
	public void setLang21MlCnt(String lang21MlCnt) {
		this.lang21MlCnt = lang21MlCnt;
	}
	public String getLang21TotCnt() {
		return lang21TotCnt;
	}
	public void setLang21TotCnt(String lang21TotCnt) {
		this.lang21TotCnt = lang21TotCnt;
	}
	public String getLang20FmlCnt() {
		return lang20FmlCnt;
	}
	public void setLang20FmlCnt(String lang20FmlCnt) {
		this.lang20FmlCnt = lang20FmlCnt;
	}
	public String getLang20MlCnt() {
		return lang20MlCnt;
	}
	public void setLang20MlCnt(String lang20MlCnt) {
		this.lang20MlCnt = lang20MlCnt;
	}
	public String getLang20TotCnt() {
		return lang20TotCnt;
	}
	public void setLang20TotCnt(String lang20TotCnt) {
		this.lang20TotCnt = lang20TotCnt;
	}
	public String getLang19FmlCnt() {
		return lang19FmlCnt;
	}
	public void setLang19FmlCnt(String lang19FmlCnt) {
		this.lang19FmlCnt = lang19FmlCnt;
	}
	public String getLang19MlCnt() {
		return lang19MlCnt;
	}
	public void setLang19MlCnt(String lang19MlCnt) {
		this.lang19MlCnt = lang19MlCnt;
	}
	public String getLang19TotCnt() {
		return lang19TotCnt;
	}
	public void setLan19TotCnt(String lang19TotCnt) {
		this.lang19TotCnt = lang19TotCnt;
	}
	public String getLang18FmlCnt() {
		return lang18FmlCnt;
	}
	public void setLang18FmlCnt(String lang18FmlCnt) {
		this.lang18FmlCnt = lang18FmlCnt;
	}
	public String getLang18MlCnt() {
		return lang18MlCnt;
	}
	public void setLang18MlCnt(String lang18MlCnt) {
		this.lang18MlCnt = lang18MlCnt;
	}
	public String getLang18TotCnt() {
		return lang18TotCnt;
	}
	public void setLang18TotCnt(String lang18TotCnt) {
		this.lang18TotCnt = lang18TotCnt;
	}
	public String getLang17FmlCnt() {
		return lang17FmlCnt;
	}
	public void setLang17FmlCnt(String lang17FmlCnt) {
		this.lang17FmlCnt = lang17FmlCnt;
	}
	public String getLang17MlCnt() {
		return lang17MlCnt;
	}
	public void setLang17MlCnt(String lang17MlCnt) {
		this.lang17MlCnt = lang17MlCnt;
	}
	public String getLang17TotCnt() {
		return lang17TotCnt;
	}
	public void setLang17TotCnt(String lang17TotCnt) {
		this.lang17TotCnt = lang17TotCnt;
	}
	public String getLang16FmlCnt() {
		return lang16FmlCnt;
	}
	public void setLang16FmlCnt(String lang16FmlCnt) {
		this.lang16FmlCnt = lang16FmlCnt;
	}
	public String getLang16MlCnt() {
		return lang16MlCnt;
	}
	public void setLang16MlCnt(String lang16MlCnt) {
		this.lang16MlCnt = lang16MlCnt;
	}
	public String getLang16TotCnt() {
		return lang16TotCnt;
	}
	public void setLang16TotCnt(String lang16TotCnt) {
		this.lang16TotCnt = lang16TotCnt;
	}
	public String getLang15FmlCnt() {
		return lang15FmlCnt;
	}
	public void setLang15FmlCnt(String lang15FmlCnt) {
		this.lang15FmlCnt = lang15FmlCnt;
	}
	public String getLang15MlCnt() {
		return lang15MlCnt;
	}
	public void setLang15MlCnt(String lang15MlCnt) {
		this.lang15MlCnt = lang15MlCnt;
	}
	public String getLang15TotCnt() {
		return lang15TotCnt;
	}
	public void setLang15TotCnt(String lang15TotCnt) {
		this.lang15TotCnt = lang15TotCnt;
	}
	public String getLang14FmlCnt() {
		return lang14FmlCnt;
	}
	public void setLang14FmlCnt(String lang14FmlCnt) {
		this.lang14FmlCnt = lang14FmlCnt;
	}
	public String getLang14MlCnt() {
		return lang14MlCnt;
	}
	public void setLang14MlCnt(String lang14MlCnt) {
		this.lang14MlCnt = lang14MlCnt;
	}
	public String getLang14TotCnt() {
		return lang14TotCnt;
	}
	public void setLang14TotCnt(String lang14TotCnt) {
		this.lang14TotCnt = lang14TotCnt;
	}
	public String getLang13FmlCnt() {
		return lang13FmlCnt;
	}
	public void setLang13FmlCnt(String lang13FmlCnt) {
		this.lang13FmlCnt = lang13FmlCnt;
	}
	public String getLang13MlCnt() {
		return lang13MlCnt;
	}
	public void setLang13MlCnt(String lang13MlCnt) {
		this.lang13MlCnt = lang13MlCnt;
	}
	public String getLang13TotCnt() {
		return lang13TotCnt;
	}
	public void setLang13TotCnt(String lang13TotCnt) {
		this.lang13TotCnt = lang13TotCnt;
	}
	public String getLang12FmlCnt() {
		return lang12FmlCnt;
	}
	public void setLang12FmlCnt(String lang12FmlCnt) {
		this.lang12FmlCnt = lang12FmlCnt;
	}
	public String getLang12MlCnt() {
		return lang12MlCnt;
	}
	public void setLang12MlCnt(String lang12MlCnt) {
		this.lang12MlCnt = lang12MlCnt;
	}
	public String getLang12TotCnt() {
		return lang12TotCnt;
	}
	public void setLang12TotCnt(String lang12TotCnt) {
		this.lang12TotCnt = lang12TotCnt;
	}
	public String getLang11FmlCnt() {
		return lang11FmlCnt;
	}
	public void setLang11FmlCnt(String lang11FmlCnt) {
		this.lang11FmlCnt = lang11FmlCnt;
	}
	public String getLang11MlCnt() {
		return lang11MlCnt;
	}
	public void setLang11MlCnt(String lang11MlCnt) {
		this.lang11MlCnt = lang11MlCnt;
	}
	public String getLang11TotCnt() {
		return lang11TotCnt;
	}
	public void setLang11TotCnt(String lang11TotCnt) {
		this.lang11TotCnt = lang11TotCnt;
	}
	public String getLang10FmlCnt() {
		return lang10FmlCnt;
	}
	public void setLang10FmlCnt(String lang10FmlCnt) {
		this.lang10FmlCnt = lang10FmlCnt;
	}
	public String getLang10MlCnt() {
		return lang10MlCnt;
	}
	public void setLang10MlCnt(String lang10MlCnt) {
		this.lang10MlCnt = lang10MlCnt;
	}
	public String getLang10TotCnt() {
		return lang10TotCnt;
	}
	public void setLang10TotCnt(String lang10TotCnt) {
		this.lang10TotCnt = lang10TotCnt;
	}
	public String getLang09FmlCnt() {
		return lang09FmlCnt;
	}
	public void setLang09FmlCnt(String lang09FmlCnt) {
		this.lang09FmlCnt = lang09FmlCnt;
	}
	public String getLang09MlCnt() {
		return lang09MlCnt;
	}
	public void setLang09MlCnt(String lang09MlCnt) {
		this.lang09MlCnt = lang09MlCnt;
	}
	public String getLang09TotCnt() {
		return lang09TotCnt;
	}
	public void setLang09TotCnt(String lang09TotCnt) {
		this.lang09TotCnt = lang09TotCnt;
	}
	public String getLang08FmlCnt() {
		return lang08FmlCnt;
	}
	public void setLang08FmlCnt(String lang08FmlCnt) {
		this.lang08FmlCnt = lang08FmlCnt;
	}
	public String getLang08MlCnt() {
		return lang08MlCnt;
	}
	public void setLang08MlCnt(String lang08MlCnt) {
		this.lang08MlCnt = lang08MlCnt;
	}
	public String getLang08TotCnt() {
		return lang08TotCnt;
	}
	public void setLang08TotCnt(String lang08TotCnt) {
		this.lang08TotCnt = lang08TotCnt;
	}
	public String getLang07FmlCnt() {
		return lang07FmlCnt;
	}
	public void setLang07FmlCnt(String lang07FmlCnt) {
		this.lang07FmlCnt = lang07FmlCnt;
	}
	public String getLang07MlCnt() {
		return lang07MlCnt;
	}
	public void setLang07MlCnt(String lang07MlCnt) {
		this.lang07MlCnt = lang07MlCnt;
	}
	public String getLang07TotCnt() {
		return lang07TotCnt;
	}
	public void setLang07TotCnt(String lang07TotCnt) {
		this.lang07TotCnt = lang07TotCnt;
	}
	public String getLang06FmlCnt() {
		return lang06FmlCnt;
	}
	public void setLang06FmlCnt(String lang06FmlCnt) {
		this.lang06FmlCnt = lang06FmlCnt;
	}
	public String getLang06MlCnt() {
		return lang06MlCnt;
	}
	public void setLang06MlCnt(String lang06MlCnt) {
		this.lang06MlCnt = lang06MlCnt;
	}
	public String getLang06TotCnt() {
		return lang06TotCnt;
	}
	public void setLang06TotCnt(String lang06TotCnt) {
		this.lang06TotCnt = lang06TotCnt;
	}
	public String getLang05FmlCnt() {
		return lang05FmlCnt;
	}
	public void setLang05FmlCnt(String lang05FmlCnt) {
		this.lang05FmlCnt = lang05FmlCnt;
	}
	public String getLang05MlCnt() {
		return lang05MlCnt;
	}
	public void setLang05MlCnt(String lang05MlCnt) {
		this.lang05MlCnt = lang05MlCnt;
	}
	public String getLang05TotCnt() {
		return lang05TotCnt;
	}
	public void setLang05TotCnt(String lang05TotCnt) {
		this.lang05TotCnt = lang05TotCnt;
	}
	public String getLang04FmlCnt() {
		return lang04FmlCnt;
	}
	public void setLang04FmlCnt(String lang04FmlCnt) {
		this.lang04FmlCnt = lang04FmlCnt;
	}
	public String getLang04MlCnt() {
		return lang04MlCnt;
	}
	public void setLang04MlCnt(String lang04MlCnt) {
		this.lang04MlCnt = lang04MlCnt;
	}
	public String getLang04TotCnt() {
		return lang04TotCnt;
	}
	public void setLang04TotCnt(String lang04TotCnt) {
		this.lang04TotCnt = lang04TotCnt;
	}
	public String getLang03FmlCnt() {
		return lang03FmlCnt;
	}
	public void setLang03FmlCnt(String lang03FmlCnt) {
		this.lang03FmlCnt = lang03FmlCnt;
	}
	public String getLang03MlCnt() {
		return lang03MlCnt;
	}
	public void setLang03MlCnt(String lang03MlCnt) {
		this.lang03MlCnt = lang03MlCnt;
	}
	public String getLang03TotCnt() {
		return lang03TotCnt;
	}
	public void setLang03TotCnt(String lang03TotCnt) {
		this.lang03TotCnt = lang03TotCnt;
	}
	public String getLang02FmlCnt() {
		return lang02FmlCnt;
	}
	public void setLang02FmlCnt(String lang02FmlCnt) {
		this.lang02FmlCnt = lang02FmlCnt;
	}
	public String getLang02MlCnt() {
		return lang02MlCnt;
	}
	public void setLang02MlCnt(String lang02MlCnt) {
		this.lang02MlCnt = lang02MlCnt;
	}
	public String getLang02TotCnt() {
		return lang02TotCnt;
	}
	public void setLang02TotCnt(String lang02TotCnt) {
		this.lang02TotCnt = lang02TotCnt;
	}
	public String getLang01FmlCnt() {
		return lang01FmlCnt;
	}
	public void setLang01FmlCnt(String lang01FmlCnt) {
		this.lang01FmlCnt = lang01FmlCnt;
	}
	public String getLang01MlCnt() {
		return lang01MlCnt;
	}
	public void setLang01MlCnt(String lang01MlCnt) {
		this.lang01MlCnt = lang01MlCnt;
	}
	public String getLang01TotCnt() {
		return lang01TotCnt;
	}
	public void setLang01TotCnt(String lang01TotCnt) {
		this.lang01TotCnt = lang01TotCnt;
	}
	public String getDstrNm() {
		return dstrNm;
	}
	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}
	public String getPrvicNm() {
		return prvicNm;
	}
	public void setPrvicNm(String prvicNm) {
		this.prvicNm = prvicNm;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getStsTitCd() {
		return stsTitCd;
	}
	public void setStsTitCd(String stsTitCd) {
		this.stsTitCd = stsTitCd;
	}
	public String getStsTitNm() {
		return stsTitNm;
	}
	public void setStsTitNm(String stsTitNm) {
		this.stsTitNm = stsTitNm;
	}
	public void setLang19TotCnt(String lang19TotCnt) {
		this.lang19TotCnt = lang19TotCnt;
	}
	public String getAdCd() {
		return adCd;
	}
	public void setAdCd(String adCd) {
		this.adCd = adCd;
	}
	public String getAdCdNm() {
		return adCdNm;
	}
	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}
	
	
	


}
