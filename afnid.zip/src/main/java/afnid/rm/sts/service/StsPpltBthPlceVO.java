package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsPpltBthPlceVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String crnDd;
	private String fmlCnt;  
	private String mlCnt;   
	private String totalCnt;
	private String fmlyCnt; 
	private String dstrNm;  
	private String prvicNm; 
	private String bthPlceCd;
	private String stsTitCd;
	private String stsTitNm;
	private String adCd;
	private String adCdNm;	
		
	

	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	public String getFmlCnt() {
		return fmlCnt;
	}
	public void setFmlCnt(String fmlCnt) {
		this.fmlCnt = fmlCnt;
	}
	public String getMlCnt() {
		return mlCnt;
	}
	public void setMlCnt(String mlCnt) {
		this.mlCnt = mlCnt;
	}
	public String getTotalCnt() {
		return totalCnt;
	}
	public void setTotalCnt(String totalCnt) {
		this.totalCnt = totalCnt;
	}
	public String getFmlyCnt() {
		return fmlyCnt;
	}
	public void setFmlyCnt(String fmlyCnt) {
		this.fmlyCnt = fmlyCnt;
	}
	public String getDstrNm() {
		return dstrNm;
	}
	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}
	public String getPrvicNm() {
		return prvicNm;
	}
	public void setPrvicNm(String prvicNm) {
		this.prvicNm = prvicNm;
	}
	public String getBthPlceCd() {
		return bthPlceCd;
	}
	public void setBthPlceCd(String bthPlceCd) {
		this.bthPlceCd = bthPlceCd;
	}
	public String getStsTitCd() {
		return stsTitCd;
	}
	public void setStsTitCd(String stsTitCd) {
		this.stsTitCd = stsTitCd;
	}
	public String getStsTitNm() {
		return stsTitNm;
	}
	public void setStsTitNm(String stsTitNm) {
		this.stsTitNm = stsTitNm;
	}
	public String getAdCd() {
		return adCd;
	}
	public void setAdCd(String adCd) {
		this.adCd = adCd;
	}
	public String getAdCdNm() {
		return adCdNm;
	}
	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}


}
