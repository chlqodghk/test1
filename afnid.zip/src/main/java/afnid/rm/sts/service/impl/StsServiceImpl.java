package afnid.rm.sts.service.impl;


import java.io.Reader;
import java.io.Writer;
import java.util.List;

import javax.annotation.Resource;

import oracle.sql.CLOB;

import org.springframework.stereotype.Service;

import si.osi.dsig.XMLDsigValidate;
import si.osi.dsig.XMLSignerP11;
import afnid.cm.ComDefaultVO;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.impl.CmmDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;
import afnid.rm.sts.service.StsBsnWrkStusVO;
import afnid.rm.sts.service.StsBthRtVO;
import afnid.rm.sts.service.StsDthRtAgeVO;
import afnid.rm.sts.service.StsDthRtVO;
import afnid.rm.sts.service.StsEpctSchAgVO;
import afnid.rm.sts.service.StsLogVO;
import afnid.rm.sts.service.StsPpltAgeVO;
import afnid.rm.sts.service.StsPpltBthPlceVO;
import afnid.rm.sts.service.StsPpltEduVO;
import afnid.rm.sts.service.StsPpltEncyVO;
import afnid.rm.sts.service.StsPpltMrrgVO;
import afnid.rm.sts.service.StsPpltMthrTguVO;
import afnid.rm.sts.service.StsPpltPmntAdVO;
import afnid.rm.sts.service.StsPpltPoliStatVO;
import afnid.rm.sts.service.StsPpltPrsAdVO;
import afnid.rm.sts.service.StsPpltRignSectVO;
import afnid.rm.sts.service.StsRgstStusVO;
import afnid.rm.sts.service.StsRsdcKchiVO;
import afnid.rm.sts.service.StsSecdNltyVO;
import afnid.rm.sts.service.StsService;
import afnid.rm.sts.service.StsSrchVO;
import afnid.rm.sts.service.StsVtrPrsAdVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of Statistics  and implements StatisticsService class.
 * 
 * @author Afghanistan National ID RM Application Moon Soo Kim
 * @since 22013.05.23
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.05.23  		Moon Soo Kim		                    Create
 *
 * </pre>
 */

@Service("stsService")
public class StsServiceImpl extends AbstractServiceImpl implements StsService{
	/** RsdtInfoDao */
	@Resource(name="stsDAO")
    private StsDAO dao;
    
	
	/** RsdtInfoDao */
	@Resource(name="cmmDAO")
    private CmmDAO cmmDAO;
	
	@Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtInfrDAO;
	
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    	
	/**
	 * Retrieves  Statistic Creation Date. <br>
	 *
	 * @param vo Input item for retrieving Statistic Creation Date(ymd).
	 * @return List Retrieve Statistic Creation Date
	 * @exception Exception
	 */
	public List<StsSrchVO> searchListStsCreYmd(String ymd) throws Exception{
		 return dao.selectListStsCreYmd(ymd);
	}
    
    /**
	 * Biz-method for check of  the already created Statistic. <br>
	 *
	 * @param String Input item for check of  the already created Statistic(Yy).
	 * @return Int result of check of  the already created Statistic
	 * @exception Exception
	 */     
    public int searchStsChkCn(String gYmd) throws Exception {
        return dao.selectStsChkCn(gYmd);
	}
    
    
    /**
	 * Biz-method for Population Statistic Creation (none scheduled) <br>
	 *
	 * @param N/A
	 * @return void
	 * @exception Exception
	 */
	public void addNonScdlStsGnr() throws Exception {
		
		

		String seqNo= "";
		seqNo = dao.selectRsdtStsGnrSeqNo("");
		log.debug("===================================================================");
		log.debug("seqNo : " + seqNo);
		log.debug("===================================================================");
		
		if (seqNo !=null && !"".equals(seqNo) && !"null".equals(seqNo)){
			String gYmd = "";	
			String gYy = "";    	
			
			String[] jobStartDt = new String[14];
			String[] jobEndDt = new String[14];
			
			String[] tableNm = {  "RM_FMLY_BOK_STS_TB" 
								, "RM_CURT_AD_STS_TB"    
								, "RM_PMNT_AD_STS_TB"    
								, "RM_BTH_PLCE_STS_TB"   
								, "RM_RLGN_SECT_STS_TB"  
								, "RM_MTHR_TGU_STS_TB"   
								, "RM_ENCY_STS_TB"       
								, "RM_RSDC_KCHI_STS_TB"  
								, "RM_SECD_NLTY_STS_TB" 
								, "RM_POLI_STAT_STS_TB"  
								, "RM_BTH_RT_STS_TB"     
								, "RM_DTH_RT_STS_TB"     
								, "RM_EPTC_SCH_AG_STS_TB"
								, "RM_VTR_STS_TB"
								};
			
			
			ComDefaultVO comVo = new ComDefaultVO();		
			comVo = cmmDAO.selectGreToDay(comVo);	
			
			gYmd = comVo.getStartDay().replaceAll("-", "");
	        gYy = gYmd.substring(0, 4);
	        
	        setRmStsEcptRsdtTb(gYmd);
	
	     	StsLogVO stsLog = new StsLogVO();  
	     	
	     	stsLog.setgYmd(gYmd);
			stsLog.setTgtCn("");
			stsLog.setErrCn("");
			stsLog.setErrYn("N");
			stsLog.setMsg("Success");
			stsLog.setWrkSysCd("2"); 
			stsLog.setUserId("SYSTEM");
			stsLog.setYy(gYy);		
	
			StsSrchVO stsCrnVo = new StsSrchVO(); 
			stsCrnVo.setYy(gYy);
			stsCrnVo.setCrnDd(gYmd);
			stsCrnVo.setCrnUserId("SYSTEM");
			
			
			//int stsCnt = searchStsChkCn(gYmd);
			int stsCnt = dao.selectStsChkCn(gYmd);
			if(stsCnt < 1){
				//2.Population by Present Address, Population by Age, Population by Education Level, Population by Marital Status
				jobStartDt[1] = getJobDate();
				dao.insertStsPpltPrsAdInfr(stsCrnVo);
				jobEndDt[1] = getJobDate();
						
				//3.Population by Permanent Address
				jobStartDt[2] = getJobDate();
				dao.insertStsPpltPmntAdInfr(stsCrnVo);
				jobEndDt[2] = getJobDate();
						
				//4.Population by Birth Address
				jobStartDt[3] = getJobDate();
				dao.insertStsPpltBthPlceInfr(stsCrnVo);
				jobEndDt[3] = getJobDate();
						
				//5.Population by Religion & Sect
				jobStartDt[4] = getJobDate();
				dao.insertStsPpltRignSectInfr(stsCrnVo);
				jobEndDt[4] = getJobDate();
						
				//6.Population by Mother Tongue
				jobStartDt[5] = getJobDate();
				dao.insertStsPpltMthrTguInfr(stsCrnVo);
				jobEndDt[5] = getJobDate();
						
				//7.Population by Ethnicity
				jobStartDt[6] = getJobDate();
				dao.insertStsPpltEncyInfr(stsCrnVo);
				jobEndDt[6] = getJobDate();
						
				//8.Population by Residence for Kochi
				jobStartDt[7] = getJobDate();
				dao.insertStsRsdcKchiInfr(stsCrnVo);
				jobEndDt[7] = getJobDate();
						
				//9.Population by Second Nationality
				jobStartDt[8] = getJobDate();
				dao.insertStsSecdNltyInfr(stsCrnVo);
				jobEndDt[8] = getJobDate();
						
				//10.Population by Polling Station
				jobStartDt[9] = getJobDate();
				dao.insertStsPpltPoliStatInfr(stsCrnVo);
				jobEndDt[9] = getJobDate();
						
				//11.Birth Rate
				jobStartDt[10] = getJobDate();
				dao.insertStsBthRtInfr(stsCrnVo);
				jobEndDt[10] = getJobDate();
						
				//12. Death Rate, Death Rate by Age
				jobStartDt[11] = getJobDate();
				dao.insertStsDthRtInfr(stsCrnVo);
				jobEndDt[11] = getJobDate();
						
				//13. Life Expectancy for School Age Children
				jobStartDt[12] = getJobDate();
				dao.insertStsEpctSchAgeInfr(stsCrnVo); 		
				jobEndDt[12] = getJobDate();
						
				//14. Voter Statistics by Present Address
				jobStartDt[13] = getJobDate();
				dao.insertStsPpltVtrStatInfr(stsCrnVo); 		
				jobEndDt[13] = getJobDate();
				
				//Job Log Registration
				for(int i=1; i < jobStartDt.length; i++){
							
					stsLog.setWrkStt(jobStartDt[i]);
					stsLog.setWrkEdDt(jobEndDt[i]);
					
					switch (i){
						case 1 : stsLog.setWrkCd("2"); stsLog.setTableNm(tableNm[i]); break;
						case 2 : stsLog.setWrkCd("3"); stsLog.setTableNm(tableNm[i]); break;
						case 3 : stsLog.setWrkCd("4"); stsLog.setTableNm(tableNm[i]); break;
						case 4 : stsLog.setWrkCd("5"); stsLog.setTableNm(tableNm[i]); break;
						case 5 : stsLog.setWrkCd("6"); stsLog.setTableNm(tableNm[i]); break;
						case 6 : stsLog.setWrkCd("7"); stsLog.setTableNm(tableNm[i]); break;
						case 7 : stsLog.setWrkCd("8"); stsLog.setTableNm(tableNm[i]); break;
						case 8 : stsLog.setWrkCd("9"); stsLog.setTableNm(tableNm[i]); break;
						case 9 : stsLog.setWrkCd("10"); stsLog.setTableNm(tableNm[i]); break;
						case 10 : stsLog.setWrkCd("11"); stsLog.setTableNm(tableNm[i]); break;
						case 11 : stsLog.setWrkCd("12"); stsLog.setTableNm(tableNm[i]); break;
						case 12 : stsLog.setWrkCd("13"); stsLog.setTableNm(tableNm[i]); break;
						case 13 : stsLog.setWrkCd("20"); stsLog.setTableNm(tableNm[i]); break;					
					}
						
					dao.insertStsJobLog(stsLog);
							
				}//end-for
				
				//요청테이블 업데이트
				StsSrchVO vo = new StsSrchVO();
				vo.setSeqNo(seqNo);
				vo.setCrnDd(jobStartDt[1]);	
				dao.updateRsdtStsRqst(vo);
				
				
				EgovMap ems = new EgovMap();
		        ems.put("crnDd", gYmd);
				List<EgovMap> emList = dao.selectRmCurtAdStsTb(ems);
				if(emList != null && !emList.isEmpty()){
					for(int i = 0 ;i < emList.size(); i++){
						EgovMap em = emList.get(i);
						String emDt = NidStringUtil.nullConvert(em.get("dtMrg"));
						String result = XMLSignerP11.spkiIFRmStringDigitalSignature(emDt);
						String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
						if(result.indexOf(reg) != -1){
							String resultSgnt = getXmlData(result, "ds:Signature");
							if(resultSgnt != null && resultSgnt.length() > 0){
								em.put("sysSgnt", resultSgnt);
								dao.updateRmCurtAdStsTb(em);
							}
						}
					}
				}
				
				emList = dao.selectRmRlgnSectStsTb(ems);
				if(emList != null && !emList.isEmpty()){
					for(int i = 0 ;i < emList.size(); i++){
						EgovMap em = emList.get(i);
						String emDt = NidStringUtil.nullConvert(em.get("dtMrg"));
						String result = XMLSignerP11.spkiIFRmStringDigitalSignature(emDt);
						String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
						if(result.indexOf(reg) != -1){
							String resultSgnt = getXmlData(result, "ds:Signature");
							if(resultSgnt != null && resultSgnt.length() > 0){
								em.put("sysSgnt", resultSgnt);
								dao.updateRmRlgnSectStsTb(em);
							}
						}
					}
				}
				
				emList = dao.selectRmEncyStsTb(ems);
				if(emList != null && !emList.isEmpty()){
					for(int i = 0 ;i < emList.size(); i++){
						EgovMap em = emList.get(i);
						String emDt = NidStringUtil.nullConvert(em.get("dtMrg"));
						String result = XMLSignerP11.spkiIFRmStringDigitalSignature(emDt);
						String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
						if(result.indexOf(reg) != -1){
							String resultSgnt = getXmlData(result, "ds:Signature");
							if(resultSgnt != null && resultSgnt.length() > 0){
								em.put("sysSgnt", resultSgnt);
								dao.updateRmEncyStsTb(em);
							}
						}
					}
				}
				
				emList = dao.selectRmPoliStatStsTb(ems);
				if(emList != null && !emList.isEmpty()){
					for(int i = 0 ;i < emList.size(); i++){
						EgovMap em = emList.get(i);
						String emDt = NidStringUtil.nullConvert(em.get("dtMrg"));
						String result = XMLSignerP11.spkiIFRmStringDigitalSignature(emDt);
						String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
						if(result.indexOf(reg) != -1){
							String resultSgnt = getXmlData(result, "ds:Signature");
							if(resultSgnt != null && resultSgnt.length() > 0){
								em.put("sysSgnt", resultSgnt);
								dao.updateRmPoliStatStsTb(em);
							}
						}
					}
				}
			}
		}
	}		
    
    /**
	 * Biz-method for Population Statistic Creation (schedule) <br>
	 *
	 * @param N/A
	 * @return void
	 * @exception Exception
	 */
	public void addScdlStsGnr() throws Exception {
			
		String  gYy = "";    
		String  hYy = "";		
		String hYmd = "";
		String gYmd = "";

		int modValue = 0;
		int stsCnt = 0;

		String[] jobStartDt = new String[14];
		String[] jobEndDt = new String[14];
		String[] tableNm = { "RM_FMLY_BOK_STS_TB" 
							,"RM_CURT_AD_STS_TB"    
							,"RM_PMNT_AD_STS_TB"    
							,"RM_BTH_PLCE_STS_TB"   
							,"RM_RLGN_SECT_STS_TB"  
							,"RM_MTHR_TGU_STS_TB"   
							,"RM_ENCY_STS_TB"       
							,"RM_RSDC_KCHI_STS_TB"  
							,"RM_SECD_NLTY_STS_TB" 
							,"RM_POLI_STAT_STS_TB"  
							,"RM_BTH_RT_STS_TB"     
							,"RM_DTH_RT_STS_TB"     
							,"RM_EPTC_SCH_AG_STS_TB"
							,"RM_VTR_STS_TB"
						   };
		
		ComDefaultVO comVo = new ComDefaultVO();		
		comVo = cmmDAO.selectGreToDay(comVo);	
		
		gYmd = comVo.getStartDay().replaceAll("-", "");	
		hYmd= dao.selectStsCreYear(gYmd);    	 

        hYy = hYmd.substring(0, 4);   
        gYy = gYmd.substring(0, 4);  
        modValue = Integer.parseInt(hYy) % 4;
        
        setRmStsEcptRsdtTb(gYmd);

     	StsLogVO stsLog = new StsLogVO();  
     	
     	stsLog.setgYmd(gYmd);
		stsLog.setTgtCn("");
		stsLog.setErrCn("");
		stsLog.setErrYn("N");
		stsLog.setMsg("Success");
		stsLog.setWrkSysCd("2"); 
		stsLog.setUserId("SYSTEM");
		stsLog.setYy(gYy);
		
        if (modValue == 3){//last day : 30
        	if( hYmd.equals(hYy+"1230") ){
        		stsCnt = dao.selectStsChkCn(gYmd);
        		if (stsCnt < 1) {
        			    StsSrchVO stsCrnVo = new StsSrchVO(); 
        			    stsCrnVo.setYy(gYy);
        			    stsCrnVo.setCrnDd(gYmd);
        			    stsCrnVo.setCrnUserId("SYSTEM"); 
        				
        				//2.Population by Present Address, Population by Age, Population by Education Level, Population by Marital Status
        				jobStartDt[1] = getJobDate();
        				dao.insertStsPpltPrsAdInfr(stsCrnVo);
        				jobEndDt[1] = getJobDate();
        				
        				//3.Population by Permanent Address
        				jobStartDt[2] = getJobDate();
        				dao.insertStsPpltPmntAdInfr(stsCrnVo);
        				jobEndDt[2] = getJobDate();
        				
        				//4.Population by Birth Address
        				jobStartDt[3] = getJobDate();
        				dao.insertStsPpltBthPlceInfr(stsCrnVo);
        				jobEndDt[3] = getJobDate();
        				
        				//5.Population by Religion & Sect
        				jobStartDt[4] = getJobDate();
        				dao.insertStsPpltRignSectInfr(stsCrnVo);
        				jobEndDt[4] = getJobDate();
        				
        				//6.Population by Mother Tongue
        				jobStartDt[5] = getJobDate();
        				dao.insertStsPpltMthrTguInfr(stsCrnVo);
        				jobEndDt[5] = getJobDate();
        				
        				//7.Population by Ethnicity
        				jobStartDt[6] = getJobDate();
        				dao.insertStsPpltEncyInfr(stsCrnVo);
        				jobEndDt[6] = getJobDate();
        				
        				//8.Population by Residence for Kochi
        				jobStartDt[7] = getJobDate();
        				dao.insertStsRsdcKchiInfr(stsCrnVo);
        				jobEndDt[7] = getJobDate();
        				
        				//9.Population by Second Nationality
        				jobStartDt[8] = getJobDate();
        				dao.insertStsSecdNltyInfr(stsCrnVo);
        				jobEndDt[8] = getJobDate();
        				
        				//10.Population by Polling Station
        				jobStartDt[9] = getJobDate();
        				dao.insertStsPpltPoliStatInfr(stsCrnVo);
        				jobEndDt[9] = getJobDate();
        				
        				//11.Birth Rate
        				jobStartDt[10] = getJobDate();
        				dao.insertStsBthRtInfr(stsCrnVo);
        				jobEndDt[10] = getJobDate();
        				
        				//12. Death Rate, Death Rate by Age
        				jobStartDt[11] = getJobDate();
        				dao.insertStsDthRtInfr(stsCrnVo);
        				jobEndDt[11] = getJobDate();
        				
        				//13. Life Expectancy for School Age Children
        				jobStartDt[12] = getJobDate();
        				dao.insertStsEpctSchAgeInfr(stsCrnVo); 		
        				jobEndDt[12] = getJobDate();

        				//14. Voter Statistics by Present Address
        				jobStartDt[13] = getJobDate();
        				dao.insertStsPpltVtrStatInfr(stsCrnVo); 		
        				jobEndDt[13] = getJobDate();        				
        				//Job Log Registration

        				for(int i=1; i < jobStartDt.length; i++){
        					
        					stsLog.setWrkStt(jobStartDt[i]);
        					stsLog.setWrkEdDt(jobEndDt[i]);
        					
        					switch (i){
	    						case 1 : stsLog.setWrkCd("2"); stsLog.setTableNm(tableNm[i]); break;
	    						case 2 : stsLog.setWrkCd("3"); stsLog.setTableNm(tableNm[i]); break;
	    						case 3 : stsLog.setWrkCd("4"); stsLog.setTableNm(tableNm[i]); break;
	    						case 4 : stsLog.setWrkCd("5"); stsLog.setTableNm(tableNm[i]); break;
	    						case 5 : stsLog.setWrkCd("6"); stsLog.setTableNm(tableNm[i]); break;
	    						case 6 : stsLog.setWrkCd("7"); stsLog.setTableNm(tableNm[i]); break;
	    						case 7 : stsLog.setWrkCd("8"); stsLog.setTableNm(tableNm[i]); break;
	    						case 8 : stsLog.setWrkCd("9"); stsLog.setTableNm(tableNm[i]); break;
	    						case 9 : stsLog.setWrkCd("10"); stsLog.setTableNm(tableNm[i]); break;
	    						case 10 : stsLog.setWrkCd("11"); stsLog.setTableNm(tableNm[i]); break;
	    						case 11 : stsLog.setWrkCd("12"); stsLog.setTableNm(tableNm[i]); break;
	    						case 12 : stsLog.setWrkCd("13"); stsLog.setTableNm(tableNm[i]); break;
	    						case 13 : stsLog.setWrkCd("20"); stsLog.setTableNm(tableNm[i]); break;					
        					}
        					
        					dao.insertStsJobLog(stsLog);
        					
        				}//end-for
        		}         		
        	}
        	
        } else { //last day : 29
        	if( hYmd.equals(hYy+"1229") ){
        		stsCnt = dao.selectStsChkCn(gYmd);	
        		 
        		if (stsCnt < 1) {      			
        			StsSrchVO stsCrnVo = new StsSrchVO(); 
   			     	stsCrnVo.setYy(gYy);
   			        stsCrnVo.setCrnDd(gYmd);
   			        stsCrnVo.setCrnUserId("SYSTEM");
    				
    				//2.Population by Present Address, Population by Age, Population by Education Level, Population by Marital Status
    				jobStartDt[1] = getJobDate();
    				dao.insertStsPpltPrsAdInfr(stsCrnVo);
    				jobEndDt[1] = getJobDate();
    				
    				//3.Population by Permanent Address
    				jobStartDt[2] = getJobDate();
    				dao.insertStsPpltPmntAdInfr(stsCrnVo);
    				jobEndDt[2] = getJobDate();
    				
    				//4.Population by Birth Address
    				jobStartDt[3] = getJobDate();
    				dao.insertStsPpltBthPlceInfr(stsCrnVo);
    				jobEndDt[3] = getJobDate();
    				
    				//5.Population by Religion & Sect
    				jobStartDt[4] = getJobDate();
    				dao.insertStsPpltRignSectInfr(stsCrnVo);
    				jobEndDt[4] = getJobDate();
    				
    				//6.Population by Mother Tongue
    				jobStartDt[5] = getJobDate();
    				dao.insertStsPpltMthrTguInfr(stsCrnVo);
    				jobEndDt[5] = getJobDate();
    				
    				//7.Population by Ethnicity
    				jobStartDt[6] = getJobDate();
    				dao.insertStsPpltEncyInfr(stsCrnVo);
    				jobEndDt[6] = getJobDate();
    				
    				//8.Population by Residence for Kochi
    				jobStartDt[7] = getJobDate();
    				dao.insertStsRsdcKchiInfr(stsCrnVo);
    				jobEndDt[7] = getJobDate();
    				
    				//9.Population by Second Nationality
    				jobStartDt[8] = getJobDate();
    				dao.insertStsSecdNltyInfr(stsCrnVo);
    				jobEndDt[8] = getJobDate();
    				
    				//10.Population by Polling Station
    				jobStartDt[9] = getJobDate();
    				dao.insertStsPpltPoliStatInfr(stsCrnVo);
    				jobEndDt[9] = getJobDate();
    				
    				//11.Birth Rate
    				jobStartDt[10] = getJobDate();
    				dao.insertStsBthRtInfr(stsCrnVo);
    				jobEndDt[10] = getJobDate();
    				
    				//12. Death Rate, Death Rate by Age
    				jobStartDt[11] = getJobDate();
    				dao.insertStsDthRtInfr(stsCrnVo);
    				jobEndDt[11] = getJobDate();
    				
    				//13. Life Expectancy for School Age Children
    				jobStartDt[12] = getJobDate();
    				dao.insertStsEpctSchAgeInfr(stsCrnVo); 		
    				jobEndDt[12] = getJobDate();
    				
    				//14. Voter Statistics by Present Address
    				jobStartDt[13] = getJobDate();
    				dao.insertStsPpltVtrStatInfr(stsCrnVo); 		
    				jobEndDt[13] = getJobDate();
    				
    				//Job Log Registration
    				for(int i=1; i < jobStartDt.length; i++){

    					stsLog.setWrkStt(jobStartDt[i]);
    					stsLog.setWrkEdDt(jobEndDt[i]);

    					switch (i){
							case 1 : stsLog.setWrkCd("2"); stsLog.setTableNm(tableNm[i]); break;
							case 2 : stsLog.setWrkCd("3"); stsLog.setTableNm(tableNm[i]); break;
							case 3 : stsLog.setWrkCd("4"); stsLog.setTableNm(tableNm[i]); break;
							case 4 : stsLog.setWrkCd("5"); stsLog.setTableNm(tableNm[i]); break;
							case 5 : stsLog.setWrkCd("6"); stsLog.setTableNm(tableNm[i]); break;
							case 6 : stsLog.setWrkCd("7"); stsLog.setTableNm(tableNm[i]); break;
							case 7 : stsLog.setWrkCd("8"); stsLog.setTableNm(tableNm[i]); break;
							case 8 : stsLog.setWrkCd("9"); stsLog.setTableNm(tableNm[i]); break;
							case 9 : stsLog.setWrkCd("10"); stsLog.setTableNm(tableNm[i]); break;
							case 10 : stsLog.setWrkCd("11"); stsLog.setTableNm(tableNm[i]); break;
							case 11 : stsLog.setWrkCd("12"); stsLog.setTableNm(tableNm[i]); break;
							case 12 : stsLog.setWrkCd("13"); stsLog.setTableNm(tableNm[i]); break;
							case 13 : stsLog.setWrkCd("20"); stsLog.setTableNm(tableNm[i]); break;					
    					}    					

    					dao.insertStsJobLog(stsLog);
    					
    				}//end-for    				
            				
        		}        		 
        	}            		         	
        }
        
        EgovMap ems = new EgovMap();
        ems.put("crnDd", gYmd);
		List<EgovMap> emList = dao.selectRmCurtAdStsTb(ems);
		if(emList != null && !emList.isEmpty()){
			for(int i = 0 ;i < emList.size(); i++){
				EgovMap em = emList.get(i);
				String emDt = NidStringUtil.nullConvert(em.get("dtMrg"));
				String result = XMLSignerP11.spkiIFRmStringDigitalSignature(emDt);
				String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
				if(result.indexOf(reg) != -1){
					String resultSgnt = getXmlData(result, "ds:Signature");
					if(resultSgnt != null && resultSgnt.length() > 0){
						em.put("sysSgnt", resultSgnt);
						dao.updateRmCurtAdStsTb(em);
					}
				}
			}
		}
		
		emList = dao.selectRmRlgnSectStsTb(ems);
		if(emList != null && !emList.isEmpty()){
			for(int i = 0 ;i < emList.size(); i++){
				EgovMap em = emList.get(i);
				String emDt = NidStringUtil.nullConvert(em.get("dtMrg"));
				String result = XMLSignerP11.spkiIFRmStringDigitalSignature(emDt);
				String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
				if(result.indexOf(reg) != -1){
					String resultSgnt = getXmlData(result, "ds:Signature");
					if(resultSgnt != null && resultSgnt.length() > 0){
						em.put("sysSgnt", resultSgnt);
						dao.updateRmRlgnSectStsTb(em);
					}
				}
			}
		}
		
		emList = dao.selectRmEncyStsTb(ems);
		if(emList != null && !emList.isEmpty()){
			for(int i = 0 ;i < emList.size(); i++){
				EgovMap em = emList.get(i);
				String emDt = NidStringUtil.nullConvert(em.get("dtMrg"));
				String result = XMLSignerP11.spkiIFRmStringDigitalSignature(emDt);
				String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
				if(result.indexOf(reg) != -1){
					String resultSgnt = getXmlData(result, "ds:Signature");
					if(resultSgnt != null && resultSgnt.length() > 0){
						em.put("sysSgnt", resultSgnt);
						dao.updateRmEncyStsTb(em);
					}
				}
			}
		}
		
		emList = dao.selectRmPoliStatStsTb(ems);
		if(emList != null && !emList.isEmpty()){
			for(int i = 0 ;i < emList.size(); i++){
				EgovMap em = emList.get(i);
				String emDt = NidStringUtil.nullConvert(em.get("dtMrg"));
				String result = XMLSignerP11.spkiIFRmStringDigitalSignature(emDt);
				String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
				if(result.indexOf(reg) != -1){
					String resultSgnt = getXmlData(result, "ds:Signature");
					if(resultSgnt != null && resultSgnt.length() > 0){
						em.put("sysSgnt", resultSgnt);
						dao.updateRmPoliStatStsTb(em);
					}
				}
			}
		}
         		
	}	
	
    /**
	 * Biz-method for Statistic Creation Date<br>
	 *
	 * @param N/A
	 * @return String system date
	 * @exception Exception
	 */
	public String getJobDate() throws Exception {

		String jobDt = dao.selectStsCrejobDt("");
        
        return jobDt;
		
    }

	/**
	 * Biz-method for get Year. <br>
	 *
	 * @param vo Input item for get Year (StsSrchVO).
	 * @return String Year
	 * @exception Exception
	 */
	public  String searchStsYear(StsSrchVO vo) throws Exception {
   		return dao.selectStsYear(vo);
	}
	
    /**
	 * Biz-method for retrieving Statistic of Population by Present Address. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Present address(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Present address
	 * @exception Exception
	 */
	public List<StsPpltPrsAdVO> searchListStsPpltPrsAd(StsSrchVO vo) throws Exception {
   		return dao.selectListStsPpltPrsAd(vo);
	}
	
    /**
	 * Biz-method for retrieving Statistic of Population by Permanent Address. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Permanent address(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Permanent address
	 * @exception Exception
	 */
	public List<StsPpltPmntAdVO> searchListStsPpltPmntAd(StsSrchVO vo) throws Exception {
   		return dao.selectListStsPpltPmntAd(vo);
	}
	
    /**
	 * Biz-method for retrieving Statistic of Population by Birth Place. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Birth Place address(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Birth Place address
	 * @exception Exception
	 */
	public List<StsPpltBthPlceVO> searchListStsPpltBthPlce(StsSrchVO vo) throws Exception {
   		return dao.selectListStsPpltBthPlce(vo);
	}
	
    /**
	 * Biz-method for retrieving Statistic of  Population by Age. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Age(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Age
	 * @exception Exception
	 */
	public List<StsPpltAgeVO> searchListStsPpltAge(StsSrchVO vo) throws Exception {
   		return dao.selectListStsPpltAge(vo);
	}
	
    /**
	 * Biz-method for retrieving Statistic of Population by Education Level. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Education(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Education
	 * @exception Exception
	 */
	public List<StsPpltEduVO> searchListStsPpltEdu(StsSrchVO vo) throws Exception {
   		return dao.selectListStsPpltEdu(vo);
	}
	
    /**
	 * Biz-method for retrieving Statistic of Population by Religion & Sect. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Religion & Sect(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Religion & Sect
	 * @exception Exception
	 */
	public List<StsPpltRignSectVO> searchListStsPpltRignSect(StsSrchVO vo) throws Exception {
   		return dao.selectListStsPpltRignSect(vo);
	}	
	
    /**
	 * Biz-method for retrieving Statistic of  Population by Mother Tongue. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Mother Tongue(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Mother Tongue
	 * @exception Exception
	 */
	public List<StsPpltMthrTguVO> searchListStsPpltMthrTgu(StsSrchVO vo) throws Exception {
   		return dao.selectListStsPpltMthrTgu(vo);
	}
	
    /**
	 * Biz-method for retrieving Statistic of Population by Ethnicity for Population. <br>
	 *
	 * @param vo Input item for retrieving  Statistic of Population by Ethnicity(StsSrchVO).
	 * @return List Retrieve  Statistic of Population by Ethnicity
	 * @exception Exception
	 */
	public List<StsPpltEncyVO> searchListStsPpltEncy(StsSrchVO vo) throws Exception {
   		return dao.selectListStsPpltEncy(vo);
	}
	
    /**
	 * Biz-method for retrieving Statistic of population by Marital Status. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Marital Status(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Marital Status
	 * @exception Exception
	 */
	public List<StsPpltMrrgVO> searchListStsPpltMrrg(StsSrchVO vo) throws Exception {
   		return dao.selectListStsPpltMrrg(vo);
	}
	
    /**
	 * Biz-method for retrieving Statistic of Population by Residence for Kochi. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Residence for Kochi(StsSrchVO).
	 * @return List Retrieve lStatistic of Population by Residence for Kochi
	 * @exception Exception
	 */
	public List<StsRsdcKchiVO> searchListStsRsdcKchi(StsSrchVO vo) throws Exception {
   		return dao.selectListStsRsdcKchi(vo);
	}
	
    /**
	 * Biz-method for retrieving Statistic of Population by Second Nationality. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Second Nationality(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Second Nationality 
	 * @exception Exception
	 */
	public List<StsSecdNltyVO> searchListStsSecdNlty(StsSrchVO vo) throws Exception {
   		return dao.selectListStsSecdNlty(vo);
	}	
	
    /**
	 * Biz-method for retrieving Statistic of Population by Polling Station. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Polling Station(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Polling Station
	 * @exception Exception
	 */
	public List<StsPpltPoliStatVO> searchListStsPpltPoliStat(StsSrchVO vo) throws Exception {
   		return dao.selectListStsPpltPoliStat(vo);
	}
	
    /**
	 * Biz-method for retrieving Statistic of Birth Rate. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Death Rate(StsSrchVO).
	 * @return List Retrieve Statistic of Death Rate
	 * @exception Exception
	 */
	public List<StsBthRtVO> searchListStsBthRt(StsSrchVO vo) throws Exception {
   		return dao.selectListStsBthRt(vo);
	}	
	
    /**
	 * Biz-method for retrieving Statistic of Death Rate. <br>
	 *
	 * @param vo Input item for retrieving list of program(StsSrchVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<StsDthRtVO> searchListStsDthRt(StsSrchVO vo) throws Exception {
   		return dao.selectListStsDthRt(vo);
	}	
	
    /**
	 * Biz-method for retrieving Statistic of Death Rate By age. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Death Rate(StsSrchVO).
	 * @return List Retrieve Statistic of Death Rate
	 * @exception Exception
	 */
	public List<StsDthRtAgeVO> searchListStsDthRtAge(StsSrchVO vo) throws Exception {
   		return dao.selectListStsDthRtAge(vo);
	}	

	
    /**
	 * Biz-method for retrieving Statistic ofLife Expectancy for School Age Children. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Death Rate by Age(StsSrchVO).
	 * @return List Retrieve Statistic of Death Rate by Age
	 * @exception Exception
	 */
	public List<StsEpctSchAgVO> searchListStsEpctSchAge(StsSrchVO vo) throws Exception {
   		return dao.selectListStsEpctSchAge(vo);
	}	
	
    /**
	 * Biz-method for retrieving Statistic of Voters by Present Address. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Voters by Present Address(StsSrchVO).
	 * @return List Retrieve Statistic of Voters by Present Address
	 * @exception Exception
	 */
	public List<StsVtrPrsAdVO> searchListStsVtrPrsAd(StsSrchVO vo) throws Exception {
   		return dao.selectListStsVtrPrsAd(vo);
	}
	
    /**
	 * Biz-method for retrieving Statistic  of Life Expectancy for School Age Children. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Life Expectancy for School Age(StsSrchVO).
	 * @return List Retrieve Statistic of Life Expectancy for School Age
	 * @exception Exception
	 */
	public List<StsSecdNltyVO> searchListPrvic(StsSrchVO vo) throws Exception {
   		return dao.selectListPrvic(vo);
	}		

		
    /**
	 * Biz-method for retrieving Statistic  of Life Expectancy for School Age Children. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Life Expectancy for School Age(StsSrchVO).
	 * @return List Retrieve Statistic of Life Expectancy for School Age
	 * @exception Exception
	 */
	public String searchStsTitle(StsSrchVO vo) throws Exception {
   		return dao.selectStsTitle(vo);
	}
	
	
    /**
	 * Biz-method for Statistics Creation  Of daily Registration Status<br>
	 *
	 * @param N/A
	 * @return void
	 * @exception Exception
	 */
	public void stsGnrRsdtRgstStus() throws Exception {
		
		String gYmd = "";
		String jobStartDt = "";
		String jobEndDt = "";
		int stsCnt = 0;
		String crnDd ="";
		ComDefaultVO comVo = new ComDefaultVO();		
		comVo = cmmDAO.selectGreToDay(comVo);
		
		gYmd = comVo.getStartDay().replaceAll("-", "");
		
		int selectDdItv = dao.selectDdItv("");

     	StsLogVO stsLog = new StsLogVO();  

     	for(int i= selectDdItv; i > -1; i--){
     		crnDd =dao.selectCrnDd(i);

     		stsLog.setCrnDd(crnDd);
	     	stsLog.setgYmd(gYmd);
			stsLog.setTgtCn("");
			stsLog.setErrCn("");
			stsLog.setErrYn("N");
			stsLog.setMsg("Success");
			stsLog.setWrkSysCd("2"); 
			stsLog.setUserId("SYSTEM");
			
			stsCnt = dao.selectStsRgstStusCn(crnDd);
			
			if (stsCnt < 1) {
			
				jobStartDt = getJobDate();
				dao.insertStsRgstStusInfr(stsLog);
				jobEndDt = getJobDate();
			
	         
				stsLog.setWrkStt(jobStartDt);
				stsLog.setWrkEdDt(jobEndDt);
				stsLog.setWrkCd("15");
				stsLog.setTableNm("RM_RSDT_RGST_STS_TB");
			
				dao.insertRsdtRgstStsJobLog(stsLog);
			}
     	}
		
	}	
	

    /**
	 * Biz-method for retrieving Statistic of Resident Registration Status. <br>	  
	 *
	 * @param vo Input item for retrieving list of program(StsRgstStusVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<StsRgstStusVO> searchListRsdtRgstStusInfr(StsRgstStusVO vo) throws Exception {
   		return dao.selectListRsdtRgstStusInfr(vo);
	}

	/**
	 * Biz-method for retrieving total count  of  Resident Registration Status list. <br>
	 *
	 * @param vo Input item for retrieving list of program(StsRgstStusVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int searchListRsdtRgstStusInfrTotCn(StsRgstStusVO vo) throws Exception {
        return dao.selectListRsdtRgstStusInfrTotCn(vo);
    }
	
	
    /**
	 * Biz-method for retrieving Statistic of performance by offices. <br>	  
	 *
	 * @param vo Input item for retrieving list of performance by office(StsBsnWrkStusVO).
	 * @return List Retrieve list of performance by office
	 * @exception Exception
	 */
	public List<StsBsnWrkStusVO> searchListBsnWrkStusInfr(StsBsnWrkStusVO vo) throws Exception {
		List<StsBsnWrkStusVO> result = null;
		String prod = vo.getProd();
		
		if ("1".equals(prod)){
			result = dao.selectListBsnWrkStusInfrDaily(vo);				
		} else if("2".equals(prod)){
			result =  dao.selectListBsnWrkStusInfrWeekly(vo);			
		} else if("3".equals(prod)){
			result =  dao.selectListBsnWrkStusInfrMonthly(vo);	
		} else if("4".equals(prod)){
			result =  dao.selectListBsnWrkStusInfrYearly(vo);			
		} else if("5".equals(prod)){			
			result =  dao.selectListBsnWrkStusInfr(vo);
		}		
		
   		return result;
	}

	/**
	 * Biz-method for retrieving total count  of  performance by officet. <br>
	 *
	 * @param vo Input item for retrieving total count of performance by office(StsBsnWrkStusVO).
	 * @return int Total Count of total count of performance by office
	 * @exception Exception
	 */
    public int searchListBsnWrkStusInfrTotCn(StsBsnWrkStusVO vo) throws Exception {
		int result = 0;
		String prod = vo.getProd();
		
		if ("1".equals(prod)){
			result = dao.selectListBsnWrkStusInfrDailyTotCn(vo);				
		} else if("2".equals(prod)){
			result =  dao.selectListBsnWrkStusInfrWeeklyTotCn(vo);		
		} else if("3".equals(prod)){
			result =  dao.selectListBsnWrkStusInfrMonthlyTotCn(vo);	
		} else if("4".equals(prod)){
			result =  dao.selectListBsnWrkStusInfrYearlyTotCn(vo);				
		} else if("5".equals(prod)){			
			result =  dao.selectListBsnWrkStusInfrTotCn(vo);
		}    	
        return result; 
    }

    /**
	 * Biz-method for retrieving Statistic of performance by team. <br>	  
	 *
	 * @param vo Input item for retrieving list of performance by team(StsBsnWrkStusVO).
	 * @return List Retrieve list of performance by team
	 * @exception Exception
	 */
	public List<StsBsnWrkStusVO> searchListTamBsnWrkStusInfr(StsBsnWrkStusVO vo) throws Exception {
        return dao.selectListTamBsnWrkStusInfr(vo);
	}

	/**
	 * Biz-method for retrieving total count  of  performance by team. <br>
	 *
	 * @param vo Input item for retrieving total count of performance by team(StsBsnWrkStusVO).
	 * @return int Total Count of total count of performance by team
	 * @exception Exception
	 */
    public int searchListTamBsnWrkStusInfrTotCn(StsBsnWrkStusVO vo) throws Exception {
    	return dao.selectListTamBsnWrkStusInfrTotCn(vo);
    }
    
    /**
	 * Biz-method for retrieving Statistic of performance by user. <br>	  
	 *
	 * @param vo Input item for retrieving list of performance by user(StsBsnWrkStusVO).
	 * @return List Retrieve list of performance by user
	 * @exception Exception
	 */
	public List<StsBsnWrkStusVO> searchListUserBsnWrkStusInfr(StsBsnWrkStusVO vo) throws Exception {	
   		return dao.selectListUserBsnWrkStusInfr(vo);		

	}

	/**
	 * Biz-method for retrieving total count  of  performance by team. <br>
	 *
	 * @param vo Input item for retrieving total count of performance by user(StsBsnWrkStusVO).
	 * @return int Total Count of total count of performance by user
	 * @exception Exception
	 */
    public int searchListUserBsnWrkStusInfrTotCn(StsBsnWrkStusVO vo) throws Exception {   	
        return dao.selectListUserBsnWrkStusInfrTotCn(vo);    	
    }    
    
	/**
	 * Biz-method for adding the days to persian start day. <br>
	 * 
	 * @param vo Input item for adding the days to persian start day(StsBsnWrkStusVO).
	 * @return ComDefaultVO Adding the days to persian start day
	 * @exception Exception
	 */
	public String searchBsnWrkStusStartPreDay(StsBsnWrkStusVO vo) throws Exception {
		return dao.selectBsnWrkStusStartPreDay(vo);
	}
	
	/**
	 * Biz-method for adding the days to persian last day. <br>
	 * 
	 * @param vo Input item for adding the days to persian last day(StsBsnWrkStusVO).
	 * @return ComDefaultVO Adding the days to persian last day
	 * @exception Exception
	 */
	public String searchBsnWrkStusEndPreDay(StsBsnWrkStusVO vo) throws Exception {
		return dao.selectBsnWrkStusEndPreDay(vo);
	}
	
	/**
	 * Biz-method for adding the days to Gregorian start day. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian start day(StsBsnWrkStusVO).
	 * @return ComDefaultVO Adding the days to Gregorian start day
	 * @exception Exception
	 */
	public String searchBsnWrkStusStartGreDay(StsBsnWrkStusVO vo) throws Exception {
		return dao.selectBsnWrkStusStartGreDay(vo);
	}
	
	/**
	 * Biz-method for adding the days to Gregorian last day. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian last day(StsBsnWrkStusVO).
	 * @return ComDefaultVO Adding the days to Gregorian last day
	 * @exception Exception
	 */
	public String searchBsnWrkStusEndGreDay(StsBsnWrkStusVO vo) throws Exception {
		return dao.selectBsnWrkStusEndGreDay(vo);
	}	    
	
	
    /**
	 * Biz-method for check of the already requested Statistic. <br>
	 *
	 * @param String Input item for check of the already requested Statistic.
	 * @return int result of check of the already requested Statistic
	 * @exception Exception
	 */     
    public int searchRsdtStsRqstYn(String gCrnDd) throws Exception {
        return dao.selectRsdtStsRqstYn(gCrnDd);
	}
    
    /**
	 * Biz-method for request generation of population statistics <br>
	 *
	 * @param N/A
	 * @return void
	 * @exception Exception
	 */
	public void addRsdtStsRqst(StsSrchVO vo) throws Exception {

		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUserId(user.getUserId());
		dao.insertRsdtStsRqst(vo);		
	}	

    /**
	 * Biz-method for retrieving list of statistic generation request. <br>
	 * 
	 * @param vo Input item for statistic generation request(StsSrchVO).
	 * @return List Retrieve list of statistic generation request
	 * @exception Exception 
	 */
	public List<StsSrchVO> searchListRsdtStsRqst(StsSrchVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
   		return dao.selectListRsdtStsRqst(vo);
	}
	
	/**
	 * Biz-method for retrieving total count list of statistic generation request. <br>
	 * 
	 * @param vo Input item for retrieving list of statistic generation request(StsSrchVO).
	 * @return int Total Count of statistic generation request List
	 * @exception Exception 
	 */
    public int searchListRsdtStsRqstTotCn(StsSrchVO vo) throws Exception {
        return dao.selectListRsdtStsRqstTotCn(vo);
	}
    
    
    /**
	 * ClobToString <br>
	 *
	 * @param CLOB
	 * @return String
	 *
	 */
	private String clobToString(CLOB clob) {
		String result = "";
		if(clob != null){
			try{
				Reader reader = clob.getCharacterStream();
				StringBuffer sb = new StringBuffer();
				int size = 0;
				char[] array = new char[10];
				while(( size = reader.read(array)) != -1){
					sb.append(array, 0, size);
				}
				result = sb.toString();
			}catch(Exception e){
				log.error(e);
			}
		}
		return result;
	}
	
	/**
	 * ClobToString <br>
	 *
	 * @param CLOB
	 * @return String
	 *
	 */
	private String clobToString(weblogic.jdbc.vendor.oracle.OracleThinClob clob) {
		String result = "";
		if(clob != null){
			try{
				Writer clobWriter = clob.getCharacterOutputStream();
				log.debug("clobToString : " +clobWriter);
				StringBuffer sb = new StringBuffer();
				if(clobWriter != null){
					char buf [] = new char[clob.getChunkSize()];
					buf[0] = '\0';
					clob.getChars(1, clob.getChunkSize(), buf);
					sb.append(buf);
				}
				result = sb.toString();
			}catch(Exception e){
				log.error(e);
			}
		}
		return result;
	}
	
	
	/**
	 * RM_STS_ECPT_RSDT_TB table select, insert <br>
	 *
	 * @param String
	 * @return void
	 *
	 */
	private void setRmStsEcptRsdtTb(String gYmd) {
		if(gYmd != null){
			try{
				EgovMap ems = new EgovMap();
		        ems.put("crnDd", gYmd);
		        ems.put("bsnEcptTypeCd", "1");
		        int emsCnt = dao.selectRmStsEcptRsdtTb(ems);
		        if(emsCnt == 0){
		        	List<EgovMap> emsLst = dao.selectImRsdtViewTb(ems);
		        	if(emsLst != null && !emsLst.isEmpty()){
		        		String emsRsdtSeqNo = null;
		        		EgovMap emRsdtInfr = null;
		        		StringBuffer sb = null;
		        		int certResult = -1;
		        		for(int i = 0; i < emsLst.size(); i++){
		        			EgovMap lstEm = emsLst.get(i);
		        			emsRsdtSeqNo = NidStringUtil.nullConvert(lstEm.get("rsdtSeqNo"));
		        			emRsdtInfr  = rsdtInfrDAO.selectRsdtInfrDat(emsRsdtSeqNo);
		        			sb = new StringBuffer();
		        			String sysSgnt = null;
		        			Object obj = emRsdtInfr.get("sysSgnt");
		        			if(obj != null){
		    					log.debug("obj class: " + obj.getClass());
		    					log.debug("obj class name: " + obj.getClass().getName());
		    					if("oracle.sql.CLOB".equals(obj.getClass().getName()) ){
		    						CLOB clob = (CLOB)obj;
		    						sysSgnt = clobToString(clob);
		    						//log.debug("oracle.sql.CLOB : " + sysSgnt);
		    					}else if("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB".equals(obj.getClass().getName()) ){
		    						weblogic.jdbc.vendor.oracle.OracleThinClob clob = (weblogic.jdbc.vendor.oracle.OracleThinClob)obj;
		    						sysSgnt = clobToString(clob);
		    						//log.debug("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB : " + sysSgnt);
		    					}
		    				}
		        			String rmData = rsdtInfrDAO.setRsdtInfrHashDat(emRsdtInfr);

		        			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		        			sb.append(reg);
		        			sb.append("<root>");
		        			sb.append("\r\n<RMDSigData><![CDATA[");
		        			sb.append(rmData);
		        			sb.append("]]></RMDSigData>\r\n");
		        			sb.append(sysSgnt);
		        			sb.append("</root>");

		        			byte [] array = new byte[sb.toString().length()];			
		        			array = sb.toString().getBytes();

		        			certResult = XMLDsigValidate.spkiIFDigitalSignatureValidation(array);
		        			
		        			if(certResult != 0){
								EgovMap emsIn = new EgovMap();
								emsIn.put("crnDd", gYmd);
								emsIn.put("bsnEcptTypeCd", "1");
								emsIn.put("rsdtSeqNo", emsRsdtSeqNo);
		        				dao.insertRmStsEcptRsdtTb(emsIn);
		        			}
		        			emsRsdtSeqNo = null;
		        			emRsdtInfr  = null;
		        			sb = null;
		        			certResult = -1;
		        		}
		        	}
		        }
			}catch(Exception e){
				log.error(e);
			}
		}
	}
	
	
	
	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param String, String
   	 * @return String
   	 * @exception Exception
   	 */
   	public String getXmlData(String xml, String tag) throws Exception{
    	String result = "";
    	if(xml != null && tag != null && xml.length() > 0 && tag.length() > 0){
        	result = xml;
        	int str = result.indexOf("<"+tag);
        	int end = result.lastIndexOf("</"+tag+">");
        	result = result.substring(str, end+3+tag.length());
    	}
    	return result;
    }
   	
   	
   	
   	/**
	 * Biz-method for retrieving Statistic of  Population by Age. <br>
	 *
	 * @param StsSrchVO
	 * @return void
	 * @exception Exception
	 */
	public void searchRmCurtAdStsTbSign(StsSrchVO vo) throws Exception {
		List<EgovMap> emLst = dao.selectRmCurtAdStsTbSign(vo);
		if(emLst != null && !emLst.isEmpty()){
			for(int i = 0; i < emLst.size(); i++){
				EgovMap emp = emLst.get(i);
				String crnDd = NidStringUtil.nullConvert(emp.get("crnDd"));
				String stsSeqNo = NidStringUtil.nullConvert(emp.get("stsSeqNo"));
				String sysSgnt = null;
				String certResult = "1";
				Object obj = emp.get("sysSgnt");
    			if(obj != null){
					if("oracle.sql.CLOB".equals(obj.getClass().getName()) ){
						CLOB clob = (CLOB)obj;
						sysSgnt = clobToString(clob);
						//log.debug("oracle.sql.CLOB : " + sysSgnt);
					}else if("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB".equals(obj.getClass().getName()) ){
						weblogic.jdbc.vendor.oracle.OracleThinClob clob = (weblogic.jdbc.vendor.oracle.OracleThinClob)obj;
						sysSgnt = clobToString(clob);
						//log.debug("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB : " + sysSgnt);
					}
				}
    			String dtMrg = NidStringUtil.nullConvert(emp.get("dtMrg"));
    			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
				StringBuffer sb = new StringBuffer();
				sb.append(reg);
				sb.append("<root>");
				sb.append("\r\n<RMDSigData><![CDATA[");
				sb.append(dtMrg);
				sb.append("]]></RMDSigData>\r\n");
				sb.append(sysSgnt);
				sb.append("</root>");
				byte [] array = new byte[sb.toString().length()];			
				array = sb.toString().getBytes();
				int certResultFlag = XMLDsigValidate.spkiIFDigitalSignatureValidation(array);
				if(certResultFlag == 0){
					certResult = "0";
				}
				EgovMap emup = new EgovMap();
				emup.put("stsSeqNo", stsSeqNo);
				emup.put("crnDd", crnDd);
				emup.put("sysSgntInsp", certResult);
				dao.updateRmCurtAdStsTbSign(emup);
			}
		}
	}
	
	
	
	/**
	 * Biz-method for retrieving Statistic of  Population by Age. <br>
	 *
	 * @param StsSrchVO
	 * @return void
	 * @exception Exception
	 */
	public void searchRmRlgnSectStsTbSign(StsSrchVO vo) throws Exception {
		List<EgovMap> emLst = dao.selectRmRlgnSectStsTbSign(vo);
		if(emLst != null && !emLst.isEmpty()){
			for(int i = 0; i < emLst.size(); i++){
				EgovMap emp = emLst.get(i);
				String crnDd = NidStringUtil.nullConvert(emp.get("crnDd"));
				String stsSeqNo = NidStringUtil.nullConvert(emp.get("stsSeqNo"));
				String sysSgnt = null;
				String certResult = "1";
				Object obj = emp.get("sysSgnt");
    			if(obj != null){
					if("oracle.sql.CLOB".equals(obj.getClass().getName()) ){
						CLOB clob = (CLOB)obj;
						sysSgnt = clobToString(clob);
						//log.debug("oracle.sql.CLOB : " + sysSgnt);
					}else if("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB".equals(obj.getClass().getName()) ){
						weblogic.jdbc.vendor.oracle.OracleThinClob clob = (weblogic.jdbc.vendor.oracle.OracleThinClob)obj;
						sysSgnt = clobToString(clob);
						//log.debug("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB : " + sysSgnt);
					}
				}
    			String dtMrg = NidStringUtil.nullConvert(emp.get("dtMrg"));
    			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
				StringBuffer sb = new StringBuffer();
				sb.append(reg);
				sb.append("<root>");
				sb.append("\r\n<RMDSigData><![CDATA[");
				sb.append(dtMrg);
				sb.append("]]></RMDSigData>\r\n");
				sb.append(sysSgnt);
				sb.append("</root>");
				byte [] array = new byte[sb.toString().length()];			
				array = sb.toString().getBytes();
				int certResultFlag = XMLDsigValidate.spkiIFDigitalSignatureValidation(array);
				if(certResultFlag == 0){
					certResult = "0";
				}
				EgovMap emup = new EgovMap();
				emup.put("stsSeqNo", stsSeqNo);
				emup.put("crnDd", crnDd);
				emup.put("sysSgntInsp", certResult);
				dao.updateRmRlgnSectStsTbSign(emup);
			}
		}
	}
	
	
	
	/**
	 * Biz-method for retrieving Statistic of  Population by Age. <br>
	 *
	 * @param StsSrchVO
	 * @return void
	 * @exception Exception
	 */
	public void searchRmEncyStsTbSign(StsSrchVO vo) throws Exception {
		List<EgovMap> emLst = dao.selectRmEncyStsTbSign(vo);
		if(emLst != null && !emLst.isEmpty()){
			for(int i = 0; i < emLst.size(); i++){
				EgovMap emp = emLst.get(i);
				String crnDd = NidStringUtil.nullConvert(emp.get("crnDd"));
				String stsSeqNo = NidStringUtil.nullConvert(emp.get("stsSeqNo"));
				String sysSgnt = null;
				String certResult = "1";
				Object obj = emp.get("sysSgnt");
    			if(obj != null){
					if("oracle.sql.CLOB".equals(obj.getClass().getName()) ){
						CLOB clob = (CLOB)obj;
						sysSgnt = clobToString(clob);
						//log.debug("oracle.sql.CLOB : " + sysSgnt);
					}else if("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB".equals(obj.getClass().getName()) ){
						weblogic.jdbc.vendor.oracle.OracleThinClob clob = (weblogic.jdbc.vendor.oracle.OracleThinClob)obj;
						sysSgnt = clobToString(clob);
						//log.debug("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB : " + sysSgnt);
					}
				}
    			String dtMrg = NidStringUtil.nullConvert(emp.get("dtMrg"));
    			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
				StringBuffer sb = new StringBuffer();
				sb.append(reg);
				sb.append("<root>");
				sb.append("\r\n<RMDSigData><![CDATA[");
				sb.append(dtMrg);
				sb.append("]]></RMDSigData>\r\n");
				sb.append(sysSgnt);
				sb.append("</root>");
				byte [] array = new byte[sb.toString().length()];			
				array = sb.toString().getBytes();
				int certResultFlag = XMLDsigValidate.spkiIFDigitalSignatureValidation(array);
				if(certResultFlag == 0){
					certResult = "0";
				}
				EgovMap emup = new EgovMap();
				emup.put("stsSeqNo", stsSeqNo);
				emup.put("crnDd", crnDd);
				emup.put("sysSgntInsp", certResult);
				dao.updateRmEncyStsTbSign(emup);
			}
		}
	}
	
	
	
	
	/**
	 * Biz-method for retrieving Statistic of  Population by Age. <br>
	 *
	 * @param StsSrchVO
	 * @return void
	 * @exception Exception
	 */
	public void searchRmPoliStatStsTbSign(StsSrchVO vo) throws Exception {
		List<EgovMap> emLst = dao.selectRmPoliStatStsTbSign(vo);
		if(emLst != null && !emLst.isEmpty()){
			for(int i = 0; i < emLst.size(); i++){
				EgovMap emp = emLst.get(i);
				String crnDd = NidStringUtil.nullConvert(emp.get("crnDd"));
				String stsSeqNo = NidStringUtil.nullConvert(emp.get("stsSeqNo"));
				String sysSgnt = null;
				String certResult = "1";
				Object obj = emp.get("sysSgnt");
    			if(obj != null){
					if("oracle.sql.CLOB".equals(obj.getClass().getName()) ){
						CLOB clob = (CLOB)obj;
						sysSgnt = clobToString(clob);
						//log.debug("oracle.sql.CLOB : " + sysSgnt);
					}else if("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB".equals(obj.getClass().getName()) ){
						weblogic.jdbc.vendor.oracle.OracleThinClob clob = (weblogic.jdbc.vendor.oracle.OracleThinClob)obj;
						sysSgnt = clobToString(clob);
						//log.debug("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB : " + sysSgnt);
					}
				}
    			String dtMrg = NidStringUtil.nullConvert(emp.get("dtMrg"));
    			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
				StringBuffer sb = new StringBuffer();
				sb.append(reg);
				sb.append("<root>");
				sb.append("\r\n<RMDSigData><![CDATA[");
				sb.append(dtMrg);
				sb.append("]]></RMDSigData>\r\n");
				sb.append(sysSgnt);
				sb.append("</root>");
				byte [] array = new byte[sb.toString().length()];			
				array = sb.toString().getBytes();
				int certResultFlag = XMLDsigValidate.spkiIFDigitalSignatureValidation(array);
				if(certResultFlag == 0){
					certResult = "0";
				}
				EgovMap emup = new EgovMap();
				emup.put("stsSeqNo", stsSeqNo);
				emup.put("crnDd", crnDd);
				emup.put("sysSgntInsp", certResult);
				dao.updateRmPoliStatStsTbSign(emup);
			}
		}
	}
	
	/**
	 * Biz-method for retrieving Statistic of Population by Polling Station. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Polling Station(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Polling Station
	 * @exception Exception
	 */
	public List<EgovMap> searchListRmEcptRsdtTbGb(StsSrchVO vo) throws Exception {
   		return dao.selectListRmEcptRsdtTbGb(vo);
	}
	
	
	
	
	
	
	
	/**
	 * Biz-method for retrieving Statistic of Resident Registration Status. <br>	  
	 *
	 * @param StsSrchVO
	 * @return List
	 * @exception Exception
	 */
	public List<EgovMap> searchListStsEcptRsdt(StsSrchVO vo) throws Exception {
   		return dao.selectListStsEcptRsdt(vo);
	}

	/**
	 * Biz-method for retrieving total count  of  Resident Registration Status list. <br>
	 *
	 * @param StsSrchVO
	 * @return int
	 * @exception Exception
	 */
    public int searchListStsEcptRsdtTotCn(StsSrchVO vo) throws Exception {
        return dao.selectListStsEcptRsdtTotCn(vo);
    }
	
}
