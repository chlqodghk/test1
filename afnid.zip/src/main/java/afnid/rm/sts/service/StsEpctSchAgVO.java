package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsEpctSchAgVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String crnDd;
	private String fmlCnt1;
	private String mlCnt1 ;
	private String totCnt1;
	private String fmlCnt2;
	private String mlCnt2 ;
	private String totCnt2;
	private String fmlCnt3;
	private String mlCnt3 ;
	private String totCnt3;
	private String fmlCnt4;
	private String mlCnt4 ;
	private String totCnt4;
	private String fmlCnt5;
	private String mlCnt5 ;
	private String totCnt5;
	private String dstrNm;
	private String prvicNm;
	private String curtAdCd;
	private String stsTitCd;
	private String stsTitNm;	
	private String adCd;
	private String adCdNm;		
	

	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	public String getFmlCnt1() {
		return fmlCnt1;
	}
	public void setFmlCnt1(String fmlCnt1) {
		this.fmlCnt1 = fmlCnt1;
	}
	public String getMlCnt1() {
		return mlCnt1;
	}
	public void setMlCnt1(String mlCnt1) {
		this.mlCnt1 = mlCnt1;
	}
	public String getTotCnt1() {
		return totCnt1;
	}
	public void setTotCnt1(String totCnt1) {
		this.totCnt1 = totCnt1;
	}
	public String getFmlCnt2() {
		return fmlCnt2;
	}
	public void setFmlCnt2(String fmlCnt2) {
		this.fmlCnt2 = fmlCnt2;
	}
	public String getMlCnt2() {
		return mlCnt2;
	}
	public void setMlCnt2(String mlCnt2) {
		this.mlCnt2 = mlCnt2;
	}
	public String getTotCnt2() {
		return totCnt2;
	}
	public void setTotCnt2(String totCnt2) {
		this.totCnt2 = totCnt2;
	}
	public String getFmlCnt3() {
		return fmlCnt3;
	}
	public void setFmlCnt3(String fmlCnt3) {
		this.fmlCnt3 = fmlCnt3;
	}
	public String getMlCnt3() {
		return mlCnt3;
	}
	public void setMlCnt3(String mlCnt3) {
		this.mlCnt3 = mlCnt3;
	}
	public String getTotCnt3() {
		return totCnt3;
	}
	public void setTotCnt3(String totCnt3) {
		this.totCnt3 = totCnt3;
	}
	public String getFmlCnt4() {
		return fmlCnt4;
	}
	public void setFmlCnt4(String fmlCnt4) {
		this.fmlCnt4 = fmlCnt4;
	}
	public String getMlCnt4() {
		return mlCnt4;
	}
	public void setMlCnt4(String mlCnt4) {
		this.mlCnt4 = mlCnt4;
	}
	public String getTotCnt4() {
		return totCnt4;
	}
	public void setTotCnt4(String totCnt4) {
		this.totCnt4 = totCnt4;
	}
	public String getFmlCnt5() {
		return fmlCnt5;
	}
	public void setFmlCnt5(String fmlCnt5) {
		this.fmlCnt5 = fmlCnt5;
	}
	public String getMlCnt5() {
		return mlCnt5;
	}
	public void setMlCnt5(String mlCnt5) {
		this.mlCnt5 = mlCnt5;
	}
	public String getTotCnt5() {
		return totCnt5;
	}
	public void setTotCnt5(String totCnt5) {
		this.totCnt5 = totCnt5;
	}
	public String getDstrNm() {
		return dstrNm;
	}
	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}
	public String getPrvicNm() {
		return prvicNm;
	}
	public void setPrvicNm(String prvicNm) {
		this.prvicNm = prvicNm;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getStsTitCd() {
		return stsTitCd;
	}
	public void setStsTitCd(String stsTitCd) {
		this.stsTitCd = stsTitCd;
	}
	public String getStsTitNm() {
		return stsTitNm;
	}
	public void setStsTitNm(String stsTitNm) {
		this.stsTitNm = stsTitNm;
	}
	public String getAdCd() {
		return adCd;
	}
	public void setAdCd(String adCd) {
		this.adCd = adCd;
	}
	public String getAdCdNm() {
		return adCdNm;
	}
	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}

	
	
}
