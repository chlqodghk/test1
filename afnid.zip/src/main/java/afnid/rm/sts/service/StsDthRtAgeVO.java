package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsDthRtAgeVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String crnDd;
	private String y0Age100FmlCnt;
	private String y0Age100MlCnt;
	private String y0Age100TotCnt;
	private String y0Age90FmlCnt;
	private String y0Age90MlCnt;
	private String y0Age90TotCnt;
	private String y0Age80FmlCnt;
	private String y0Age80MlCnt;
	private String y0Age80TotCnt;
	private String y0Age70FmlCnt;
	private String y0Age70MlCnt;
	private String y0Age70TotCnt;
	private String y0Age60FmlCnt;
	private String y0Age60MlCnt;
	private String y0Age60TotCnt;
	private String y0Age50FmlCnt;
	private String y0Age50MlCnt;
	private String y0Age50TotCnt;
	private String y0Age40FmlCnt;
	private String y0Age40MlCnt;
	private String y0Age40TotCnt;
	private String y0Age30FmlCnt;
	private String y0Age30MlCnt;
	private String y0Age30TotCnt;
	private String y0Age20FmlCnt;
	private String y0Age20MlCnt;
	private String y0Age20TotCnt;
	private String y0Age10FmlCnt;
	private String y0Age10MlCnt;
	private String y0Age10TotCnt;
	private String y0Age0FmlCnt;
	private String y0Age0MlCnt;
	private String y0Age0TotCnt;
	private String y1Age100FmlCnt;
	private String y1Age100MlCnt;
	private String y1Age100TotCnt;
	private String y1Age90FmlCnt;
	private String y1Age90MlCnt;
	private String y1Age90TotCnt;
	private String y1Age80FmlCnt;
	private String y1Age80MlCnt;
	private String y1Age80TotCnt;
	private String y1Age70FmlCnt;
	private String y1Age70MlCnt;
	private String y1Age70TotCnt;
	private String y1Age60FmlCnt;
	private String y1Age60MlCnt;
	private String y1Age60TotCnt;
	private String y1Age50FmlCnt;
	private String y1Age50MlCnt;
	private String y1Age50TotCnt;
	private String y1Age40FmlCnt;
	private String y1Age40MlCnt;
	private String y1Age40TotCnt;
	private String y1Age30FmlCnt;
	private String y1Age30MlCnt;
	private String y1Age30TotCnt;
	private String y1Age20FmlCnt;
	private String y1Age20MlCnt;
	private String y1Age20TotCnt;
	private String y1Age10FmlCnt;
	private String y1Age10MlCnt;
	private String y1Age10TotCnt;
	private String y1Age0FmlCnt;
	private String y1Age0MlCnt;
	private String y1Age0TotCnt;
	private String y2Age100FmlCnt;
	private String y2Age100MlCnt;
	private String y2Age100TotCnt;
	private String y2Age90FmlCnt;
	private String y2Age90MlCnt;
	private String y2Age90TotCnt;
	private String y2Age80FmlCnt;
	private String y2Age80MlCnt;
	private String y2Age80TotCnt;
	private String y2Age70FmlCnt;
	private String y2Age70MlCnt;
	private String y2Age70TotCnt;
	private String y2Age60FmlCnt;
	private String y2Age60MlCnt;
	private String y2Age60TotCnt;
	private String y2Age50FmlCnt;
	private String y2Age50MlCnt;
	private String y2Age50TotCnt;
	private String y2Age40FmlCnt;
	private String y2Age40MlCnt;
	private String y2Age40TotCnt;
	private String y2Age30FmlCnt;
	private String y2Age30MlCnt;
	private String y2Age30TotCnt;
	private String y2Age20FmlCnt;
	private String y2Age20MlCnt;
	private String y2Age20TotCnt;
	private String y2Age10FmlCnt;
	private String y2Age10MlCnt;
	private String y2Age10TotCnt;
	private String y2Age0FmlCnt;
	private String y2Age0MlCnt;
	private String y2Age0TotCnt;
	private String y3Age100FmlCnt;
	private String y3Age100MlCnt;
	private String y3Age100TotCnt;
	private String y3Age90FmlCnt;
	private String y3Age90MlCnt;
	private String y3Age90TotCnt;
	private String y3Age80FmlCnt;
	private String y3Age80MlCnt;
	private String y3Age80TotCnt;
	private String y3Age70FmlCnt;
	private String y3Age70MlCnt;
	private String y3Age70TotCnt;
	private String y3Age60FmlCnt;
	private String y3Age60MlCnt;
	private String y3Age60TotCnt;
	private String y3Age50FmlCnt;
	private String y3Age50MlCnt;
	private String y3Age50TotCnt;
	private String y3Age40FmlCnt;
	private String y3Age40MlCnt;
	private String y3Age40TotCnt;
	private String y3Age30FmlCnt;
	private String y3Age30MlCnt;
	private String y3Age30TotCnt;
	private String y3Age20FmlCnt;
	private String y3Age20MlCnt;
	private String y3Age20TotCnt;
	private String y3Age10FmlCnt;
	private String y3Age10MlCnt;
	private String y3Age10TotCnt;
	private String y3Age0FmlCnt;
	private String y3Age0MlCnt;
	private String y3Age0TotCnt;
	private String y4Age100FmlCnt;
	private String y4Age100MlCnt;
	private String y4Age100TotCnt;
	private String y4Age90FmlCnt;
	private String y4Age90MlCnt;
	private String y4Age90TotCnt;
	private String y4Age80FmlCnt;
	private String y4Age80MlCnt;
	private String y4Age80TotCnt;
	private String y4Age70FmlCnt;
	private String y4Age70MlCnt;
	private String y4Age70TotCnt;
	private String y4Age60FmlCnt;
	private String y4Age60MlCnt;
	private String y4Age60TotCnt;
	private String y4Age50FmlCnt;
	private String y4Age50MlCnt;
	private String y4Age50TotCnt;
	private String y4Age40FmlCnt;
	private String y4Age40MlCnt;
	private String y4Age40TotCnt;
	private String y4Age30FmlCnt;
	private String y4Age30MlCnt;
	private String y4Age30TotCnt;
	private String y4Age20FmlCnt;
	private String y4Age20MlCnt;
	private String y4Age20TotCnt;
	private String y4Age10FmlCnt;
	private String y4Age10MlCnt;
	private String y4Age10TotCnt;
	private String y4Age0FmlCnt;
	private String y4Age0MlCnt;
	private String y4Age0TotCnt;
	private String dstrNm;
	private String prvicNm;
	private String curtAdCd;
	private String stsTitCd;
	private String stsTitNm;	
	
	private String adCd;
	private String adCdNm;	
	

	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	public String getY0Age100FmlCnt() {
		return y0Age100FmlCnt;
	}
	public void setY0Age100FmlCnt(String y0Age100FmlCnt) {
		this.y0Age100FmlCnt = y0Age100FmlCnt;
	}
	public String getY0Age100MlCnt() {
		return y0Age100MlCnt;
	}
	public void setY0Age100MlCnt(String y0Age100MlCnt) {
		this.y0Age100MlCnt = y0Age100MlCnt;
	}
	public String getY0Age100TotCnt() {
		return y0Age100TotCnt;
	}
	public void setY0Age100TotCnt(String y0Age100TotCnt) {
		this.y0Age100TotCnt = y0Age100TotCnt;
	}
	public String getY0Age90FmlCnt() {
		return y0Age90FmlCnt;
	}
	public void setY0Age90FmlCnt(String y0Age90FmlCnt) {
		this.y0Age90FmlCnt = y0Age90FmlCnt;
	}
	public String getY0Age90MlCnt() {
		return y0Age90MlCnt;
	}
	public void setY0Age90MlCnt(String y0Age90MlCnt) {
		this.y0Age90MlCnt = y0Age90MlCnt;
	}
	public String getY0Age90TotCnt() {
		return y0Age90TotCnt;
	}
	public void setY0Age90TotCnt(String y0Age90TotCnt) {
		this.y0Age90TotCnt = y0Age90TotCnt;
	}
	public String getY0Age80FmlCnt() {
		return y0Age80FmlCnt;
	}
	public void setY0Age80FmlCnt(String y0Age80FmlCnt) {
		this.y0Age80FmlCnt = y0Age80FmlCnt;
	}
	public String getY0Age80MlCnt() {
		return y0Age80MlCnt;
	}
	public void setY0Age80MlCnt(String y0Age80MlCnt) {
		this.y0Age80MlCnt = y0Age80MlCnt;
	}
	public String getY0Age80TotCnt() {
		return y0Age80TotCnt;
	}
	public void setY0Age80TotCnt(String y0Age80TotCnt) {
		this.y0Age80TotCnt = y0Age80TotCnt;
	}
	public String getY0Age70FmlCnt() {
		return y0Age70FmlCnt;
	}
	public void setY0Age70FmlCnt(String y0Age70FmlCnt) {
		this.y0Age70FmlCnt = y0Age70FmlCnt;
	}
	public String getY0Age70MlCnt() {
		return y0Age70MlCnt;
	}
	public void setY0Age70MlCnt(String y0Age70MlCnt) {
		this.y0Age70MlCnt = y0Age70MlCnt;
	}
	public String getY0Age70TotCnt() {
		return y0Age70TotCnt;
	}
	public void setY0Age70TotCnt(String y0Age70TotCnt) {
		this.y0Age70TotCnt = y0Age70TotCnt;
	}
	public String getY0Age60FmlCnt() {
		return y0Age60FmlCnt;
	}
	public void setY0Age60FmlCnt(String y0Age60FmlCnt) {
		this.y0Age60FmlCnt = y0Age60FmlCnt;
	}
	public String getY0Age60MlCnt() {
		return y0Age60MlCnt;
	}
	public void setY0Age60MlCnt(String y0Age60MlCnt) {
		this.y0Age60MlCnt = y0Age60MlCnt;
	}
	public String getY0Age60TotCnt() {
		return y0Age60TotCnt;
	}
	public void setY0Age60TotCnt(String y0Age60TotCnt) {
		this.y0Age60TotCnt = y0Age60TotCnt;
	}
	public String getY0Age50FmlCnt() {
		return y0Age50FmlCnt;
	}
	public void setY0Age50FmlCnt(String y0Age50FmlCnt) {
		this.y0Age50FmlCnt = y0Age50FmlCnt;
	}
	public String getY0Age50MlCnt() {
		return y0Age50MlCnt;
	}
	public void setY0Age50MlCnt(String y0Age50MlCnt) {
		this.y0Age50MlCnt = y0Age50MlCnt;
	}
	public String getY0Age50TotCnt() {
		return y0Age50TotCnt;
	}
	public void setY0Age50TotCnt(String y0Age50TotCnt) {
		this.y0Age50TotCnt = y0Age50TotCnt;
	}
	public String getY0Age40FmlCnt() {
		return y0Age40FmlCnt;
	}
	public void setY0Age40FmlCnt(String y0Age40FmlCnt) {
		this.y0Age40FmlCnt = y0Age40FmlCnt;
	}
	public String getY0Age40MlCnt() {
		return y0Age40MlCnt;
	}
	public void setY0Age40MlCnt(String y0Age40MlCnt) {
		this.y0Age40MlCnt = y0Age40MlCnt;
	}
	public String getY0Age40TotCnt() {
		return y0Age40TotCnt;
	}
	public void setY0Age40TotCnt(String y0Age40TotCnt) {
		this.y0Age40TotCnt = y0Age40TotCnt;
	}
	public String getY0Age30FmlCnt() {
		return y0Age30FmlCnt;
	}
	public void setY0Age30FmlCnt(String y0Age30FmlCnt) {
		this.y0Age30FmlCnt = y0Age30FmlCnt;
	}
	public String getY0Age30MlCnt() {
		return y0Age30MlCnt;
	}
	public void setY0Age30MlCnt(String y0Age30MlCnt) {
		this.y0Age30MlCnt = y0Age30MlCnt;
	}
	public String getY0Age30TotCnt() {
		return y0Age30TotCnt;
	}
	public void setY0Age30TotCnt(String y0Age30TotCnt) {
		this.y0Age30TotCnt = y0Age30TotCnt;
	}
	public String getY0Age20FmlCnt() {
		return y0Age20FmlCnt;
	}
	public void setY0Age20FmlCnt(String y0Age20FmlCnt) {
		this.y0Age20FmlCnt = y0Age20FmlCnt;
	}
	public String getY0Age20MlCnt() {
		return y0Age20MlCnt;
	}
	public void setY0Age20MlCnt(String y0Age20MlCnt) {
		this.y0Age20MlCnt = y0Age20MlCnt;
	}
	public String getY0Age20TotCnt() {
		return y0Age20TotCnt;
	}
	public void setY0Age20TotCnt(String y0Age20TotCnt) {
		this.y0Age20TotCnt = y0Age20TotCnt;
	}
	public String getY0Age10FmlCnt() {
		return y0Age10FmlCnt;
	}
	public void setY0Age10FmlCnt(String y0Age10FmlCnt) {
		this.y0Age10FmlCnt = y0Age10FmlCnt;
	}
	public String getY0Age10MlCnt() {
		return y0Age10MlCnt;
	}
	public void setY0Age10MlCnt(String y0Age10MlCnt) {
		this.y0Age10MlCnt = y0Age10MlCnt;
	}
	public String getY0Age10TotCnt() {
		return y0Age10TotCnt;
	}
	public void setY0Age10TotCnt(String y0Age10TotCnt) {
		this.y0Age10TotCnt = y0Age10TotCnt;
	}
	public String getY0Age0FmlCnt() {
		return y0Age0FmlCnt;
	}
	public void setY0Age0FmlCnt(String y0Age0FmlCnt) {
		this.y0Age0FmlCnt = y0Age0FmlCnt;
	}
	public String getY0Age0MlCnt() {
		return y0Age0MlCnt;
	}
	public void setY0Age0MlCnt(String y0Age0MlCnt) {
		this.y0Age0MlCnt = y0Age0MlCnt;
	}
	public String getY0Age0TotCnt() {
		return y0Age0TotCnt;
	}
	public void setY0Age0TotCnt(String y0Age0TotCnt) {
		this.y0Age0TotCnt = y0Age0TotCnt;
	}
	public String getY1Age100FmlCnt() {
		return y1Age100FmlCnt;
	}
	public void setY1Age100FmlCnt(String y1Age100FmlCnt) {
		this.y1Age100FmlCnt = y1Age100FmlCnt;
	}
	public String getY1Age100MlCnt() {
		return y1Age100MlCnt;
	}
	public void setY1Age100MlCnt(String y1Age100MlCnt) {
		this.y1Age100MlCnt = y1Age100MlCnt;
	}
	public String getY1Age100TotCnt() {
		return y1Age100TotCnt;
	}
	public void setY1Age100TotCnt(String y1Age100TotCnt) {
		this.y1Age100TotCnt = y1Age100TotCnt;
	}
	public String getY1Age90FmlCnt() {
		return y1Age90FmlCnt;
	}
	public void setY1Age90FmlCnt(String y1Age90FmlCnt) {
		this.y1Age90FmlCnt = y1Age90FmlCnt;
	}
	public String getY1Age90MlCnt() {
		return y1Age90MlCnt;
	}
	public void setY1Age90MlCnt(String y1Age90MlCnt) {
		this.y1Age90MlCnt = y1Age90MlCnt;
	}
	public String getY1Age90TotCnt() {
		return y1Age90TotCnt;
	}
	public void setY1Age90TotCnt(String y1Age90TotCnt) {
		this.y1Age90TotCnt = y1Age90TotCnt;
	}
	public String getY1Age80FmlCnt() {
		return y1Age80FmlCnt;
	}
	public void setY1Age80FmlCnt(String y1Age80FmlCnt) {
		this.y1Age80FmlCnt = y1Age80FmlCnt;
	}
	public String getY1Age80MlCnt() {
		return y1Age80MlCnt;
	}
	public void setY1Age80MlCnt(String y1Age80MlCnt) {
		this.y1Age80MlCnt = y1Age80MlCnt;
	}
	public String getY1Age80TotCnt() {
		return y1Age80TotCnt;
	}
	public void setY1Age80TotCnt(String y1Age80TotCnt) {
		this.y1Age80TotCnt = y1Age80TotCnt;
	}
	public String getY1Age70FmlCnt() {
		return y1Age70FmlCnt;
	}
	public void setY1Age70FmlCnt(String y1Age70FmlCnt) {
		this.y1Age70FmlCnt = y1Age70FmlCnt;
	}
	public String getY1Age70MlCnt() {
		return y1Age70MlCnt;
	}
	public void setY1Age70MlCnt(String y1Age70MlCnt) {
		this.y1Age70MlCnt = y1Age70MlCnt;
	}
	public String getY1Age70TotCnt() {
		return y1Age70TotCnt;
	}
	public void setY1Age70TotCnt(String y1Age70TotCnt) {
		this.y1Age70TotCnt = y1Age70TotCnt;
	}
	public String getY1Age60FmlCnt() {
		return y1Age60FmlCnt;
	}
	public void setY1Age60FmlCnt(String y1Age60FmlCnt) {
		this.y1Age60FmlCnt = y1Age60FmlCnt;
	}
	public String getY1Age60MlCnt() {
		return y1Age60MlCnt;
	}
	public void setY1Age60MlCnt(String y1Age60MlCnt) {
		this.y1Age60MlCnt = y1Age60MlCnt;
	}
	public String getY1Age60TotCnt() {
		return y1Age60TotCnt;
	}
	public void setY1Age60TotCnt(String y1Age60TotCnt) {
		this.y1Age60TotCnt = y1Age60TotCnt;
	}
	public String getY1Age50FmlCnt() {
		return y1Age50FmlCnt;
	}
	public void setY1Age50FmlCnt(String y1Age50FmlCnt) {
		this.y1Age50FmlCnt = y1Age50FmlCnt;
	}
	public String getY1Age50MlCnt() {
		return y1Age50MlCnt;
	}
	public void setY1Age50MlCnt(String y1Age50MlCnt) {
		this.y1Age50MlCnt = y1Age50MlCnt;
	}
	public String getY1Age50TotCnt() {
		return y1Age50TotCnt;
	}
	public void setY1Age50TotCnt(String y1Age50TotCnt) {
		this.y1Age50TotCnt = y1Age50TotCnt;
	}
	public String getY1Age40FmlCnt() {
		return y1Age40FmlCnt;
	}
	public void setY1Age40FmlCnt(String y1Age40FmlCnt) {
		this.y1Age40FmlCnt = y1Age40FmlCnt;
	}
	public String getY1Age40MlCnt() {
		return y1Age40MlCnt;
	}
	public void setY1Age40MlCnt(String y1Age40MlCnt) {
		this.y1Age40MlCnt = y1Age40MlCnt;
	}
	public String getY1Age40TotCnt() {
		return y1Age40TotCnt;
	}
	public void setY1Age40TotCnt(String y1Age40TotCnt) {
		this.y1Age40TotCnt = y1Age40TotCnt;
	}
	public String getY1Age30FmlCnt() {
		return y1Age30FmlCnt;
	}
	public void setY1Age30FmlCnt(String y1Age30FmlCnt) {
		this.y1Age30FmlCnt = y1Age30FmlCnt;
	}
	public String getY1Age30MlCnt() {
		return y1Age30MlCnt;
	}
	public void setY1Age30MlCnt(String y1Age30MlCnt) {
		this.y1Age30MlCnt = y1Age30MlCnt;
	}
	public String getY1Age30TotCnt() {
		return y1Age30TotCnt;
	}
	public void setY1Age30TotCnt(String y1Age30TotCnt) {
		this.y1Age30TotCnt = y1Age30TotCnt;
	}
	public String getY1Age20FmlCnt() {
		return y1Age20FmlCnt;
	}
	public void setY1Age20FmlCnt(String y1Age20FmlCnt) {
		this.y1Age20FmlCnt = y1Age20FmlCnt;
	}
	public String getY1Age20MlCnt() {
		return y1Age20MlCnt;
	}
	public void setY1Age20MlCnt(String y1Age20MlCnt) {
		this.y1Age20MlCnt = y1Age20MlCnt;
	}
	public String getY1Age20TotCnt() {
		return y1Age20TotCnt;
	}
	public void setY1Age20TotCnt(String y1Age20TotCnt) {
		this.y1Age20TotCnt = y1Age20TotCnt;
	}
	public String getY1Age10FmlCnt() {
		return y1Age10FmlCnt;
	}
	public void setY1Age10FmlCnt(String y1Age10FmlCnt) {
		this.y1Age10FmlCnt = y1Age10FmlCnt;
	}
	public String getY1Age10MlCnt() {
		return y1Age10MlCnt;
	}
	public void setY1Age10MlCnt(String y1Age10MlCnt) {
		this.y1Age10MlCnt = y1Age10MlCnt;
	}
	public String getY1Age10TotCnt() {
		return y1Age10TotCnt;
	}
	public void setY1Age10TotCnt(String y1Age10TotCnt) {
		this.y1Age10TotCnt = y1Age10TotCnt;
	}
	public String getY1Age0FmlCnt() {
		return y1Age0FmlCnt;
	}
	public void setY1Age0FmlCnt(String y1Age0FmlCnt) {
		this.y1Age0FmlCnt = y1Age0FmlCnt;
	}
	public String getY1Age0MlCnt() {
		return y1Age0MlCnt;
	}
	public void setY1Age0MlCnt(String y1Age0MlCnt) {
		this.y1Age0MlCnt = y1Age0MlCnt;
	}
	public String getY1Age0TotCnt() {
		return y1Age0TotCnt;
	}
	public void setY1Age0TotCnt(String y1Age0TotCnt) {
		this.y1Age0TotCnt = y1Age0TotCnt;
	}
	public String getY2Age100FmlCnt() {
		return y2Age100FmlCnt;
	}
	public void setY2Age100FmlCnt(String y2Age100FmlCnt) {
		this.y2Age100FmlCnt = y2Age100FmlCnt;
	}
	public String getY2Age100MlCnt() {
		return y2Age100MlCnt;
	}
	public void setY2Age100MlCnt(String y2Age100MlCnt) {
		this.y2Age100MlCnt = y2Age100MlCnt;
	}
	public String getY2Age100TotCnt() {
		return y2Age100TotCnt;
	}
	public void setY2Age100TotCnt(String y2Age100TotCnt) {
		this.y2Age100TotCnt = y2Age100TotCnt;
	}
	public String getY2Age90FmlCnt() {
		return y2Age90FmlCnt;
	}
	public void setY2Age90FmlCnt(String y2Age90FmlCnt) {
		this.y2Age90FmlCnt = y2Age90FmlCnt;
	}
	public String getY2Age90MlCnt() {
		return y2Age90MlCnt;
	}
	public void setY2Age90MlCnt(String y2Age90MlCnt) {
		this.y2Age90MlCnt = y2Age90MlCnt;
	}
	public String getY2Age90TotCnt() {
		return y2Age90TotCnt;
	}
	public void setY2Age90TotCnt(String y2Age90TotCnt) {
		this.y2Age90TotCnt = y2Age90TotCnt;
	}
	public String getY2Age80FmlCnt() {
		return y2Age80FmlCnt;
	}
	public void setY2Age80FmlCnt(String y2Age80FmlCnt) {
		this.y2Age80FmlCnt = y2Age80FmlCnt;
	}
	public String getY2Age80MlCnt() {
		return y2Age80MlCnt;
	}
	public void setY2Age80MlCnt(String y2Age80MlCnt) {
		this.y2Age80MlCnt = y2Age80MlCnt;
	}
	public String getY2Age80TotCnt() {
		return y2Age80TotCnt;
	}
	public void setY2Age80TotCnt(String y2Age80TotCnt) {
		this.y2Age80TotCnt = y2Age80TotCnt;
	}
	public String getY2Age70FmlCnt() {
		return y2Age70FmlCnt;
	}
	public void setY2Age70FmlCnt(String y2Age70FmlCnt) {
		this.y2Age70FmlCnt = y2Age70FmlCnt;
	}
	public String getY2Age70MlCnt() {
		return y2Age70MlCnt;
	}
	public void setY2Age70MlCnt(String y2Age70MlCnt) {
		this.y2Age70MlCnt = y2Age70MlCnt;
	}
	public String getY2Age70TotCnt() {
		return y2Age70TotCnt;
	}
	public void setY2Age70TotCnt(String y2Age70TotCnt) {
		this.y2Age70TotCnt = y2Age70TotCnt;
	}
	public String getY2Age60FmlCnt() {
		return y2Age60FmlCnt;
	}
	public void setY2Age60FmlCnt(String y2Age60FmlCnt) {
		this.y2Age60FmlCnt = y2Age60FmlCnt;
	}
	public String getY2Age60MlCnt() {
		return y2Age60MlCnt;
	}
	public void setY2Age60MlCnt(String y2Age60MlCnt) {
		this.y2Age60MlCnt = y2Age60MlCnt;
	}
	public String getY2Age60TotCnt() {
		return y2Age60TotCnt;
	}
	public void setY2Age60TotCnt(String y2Age60TotCnt) {
		this.y2Age60TotCnt = y2Age60TotCnt;
	}
	public String getY2Age50FmlCnt() {
		return y2Age50FmlCnt;
	}
	public void setY2Age50FmlCnt(String y2Age50FmlCnt) {
		this.y2Age50FmlCnt = y2Age50FmlCnt;
	}
	public String getY2Age50MlCnt() {
		return y2Age50MlCnt;
	}
	public void setY2Age50MlCnt(String y2Age50MlCnt) {
		this.y2Age50MlCnt = y2Age50MlCnt;
	}
	public String getY2Age50TotCnt() {
		return y2Age50TotCnt;
	}
	public void setY2Age50TotCnt(String y2Age50TotCnt) {
		this.y2Age50TotCnt = y2Age50TotCnt;
	}
	public String getY2Age40FmlCnt() {
		return y2Age40FmlCnt;
	}
	public void setY2Age40FmlCnt(String y2Age40FmlCnt) {
		this.y2Age40FmlCnt = y2Age40FmlCnt;
	}
	public String getY2Age40MlCnt() {
		return y2Age40MlCnt;
	}
	public void setY2Age40MlCnt(String y2Age40MlCnt) {
		this.y2Age40MlCnt = y2Age40MlCnt;
	}
	public String getY2Age40TotCnt() {
		return y2Age40TotCnt;
	}
	public void setY2Age40TotCnt(String y2Age40TotCnt) {
		this.y2Age40TotCnt = y2Age40TotCnt;
	}
	public String getY2Age30FmlCnt() {
		return y2Age30FmlCnt;
	}
	public void setY2Age30FmlCnt(String y2Age30FmlCnt) {
		this.y2Age30FmlCnt = y2Age30FmlCnt;
	}
	public String getY2Age30MlCnt() {
		return y2Age30MlCnt;
	}
	public void setY2Age30MlCnt(String y2Age30MlCnt) {
		this.y2Age30MlCnt = y2Age30MlCnt;
	}
	public String getY2Age30TotCnt() {
		return y2Age30TotCnt;
	}
	public void setY2Age30TotCnt(String y2Age30TotCnt) {
		this.y2Age30TotCnt = y2Age30TotCnt;
	}
	public String getY2Age20FmlCnt() {
		return y2Age20FmlCnt;
	}
	public void setY2Age20FmlCnt(String y2Age20FmlCnt) {
		this.y2Age20FmlCnt = y2Age20FmlCnt;
	}
	public String getY2Age20MlCnt() {
		return y2Age20MlCnt;
	}
	public void setY2Age20MlCnt(String y2Age20MlCnt) {
		this.y2Age20MlCnt = y2Age20MlCnt;
	}
	public String getY2Age20TotCnt() {
		return y2Age20TotCnt;
	}
	public void setY2Age20TotCnt(String y2Age20TotCnt) {
		this.y2Age20TotCnt = y2Age20TotCnt;
	}
	public String getY2Age10FmlCnt() {
		return y2Age10FmlCnt;
	}
	public void setY2Age10FmlCnt(String y2Age10FmlCnt) {
		this.y2Age10FmlCnt = y2Age10FmlCnt;
	}
	public String getY2Age10MlCnt() {
		return y2Age10MlCnt;
	}
	public void setY2Age10MlCnt(String y2Age10MlCnt) {
		this.y2Age10MlCnt = y2Age10MlCnt;
	}
	public String getY2Age10TotCnt() {
		return y2Age10TotCnt;
	}
	public void setY2Age10TotCnt(String y2Age10TotCnt) {
		this.y2Age10TotCnt = y2Age10TotCnt;
	}
	public String getY2Age0FmlCnt() {
		return y2Age0FmlCnt;
	}
	public void setY2Age0FmlCnt(String y2Age0FmlCnt) {
		this.y2Age0FmlCnt = y2Age0FmlCnt;
	}
	public String getY2Age0MlCnt() {
		return y2Age0MlCnt;
	}
	public void setY2Age0MlCnt(String y2Age0MlCnt) {
		this.y2Age0MlCnt = y2Age0MlCnt;
	}
	public String getY2Age0TotCnt() {
		return y2Age0TotCnt;
	}
	public void setY2Age0TotCnt(String y2Age0TotCnt) {
		this.y2Age0TotCnt = y2Age0TotCnt;
	}
	public String getY3Age100FmlCnt() {
		return y3Age100FmlCnt;
	}
	public void setY3Age100FmlCnt(String y3Age100FmlCnt) {
		this.y3Age100FmlCnt = y3Age100FmlCnt;
	}
	public String getY3Age100MlCnt() {
		return y3Age100MlCnt;
	}
	public void setY3Age100MlCnt(String y3Age100MlCnt) {
		this.y3Age100MlCnt = y3Age100MlCnt;
	}
	public String getY3Age100TotCnt() {
		return y3Age100TotCnt;
	}
	public void setY3Age100TotCnt(String y3Age100TotCnt) {
		this.y3Age100TotCnt = y3Age100TotCnt;
	}
	public String getY3Age90FmlCnt() {
		return y3Age90FmlCnt;
	}
	public void setY3Age90FmlCnt(String y3Age90FmlCnt) {
		this.y3Age90FmlCnt = y3Age90FmlCnt;
	}
	public String getY3Age90MlCnt() {
		return y3Age90MlCnt;
	}
	public void setY3Age90MlCnt(String y3Age90MlCnt) {
		this.y3Age90MlCnt = y3Age90MlCnt;
	}
	public String getY3Age90TotCnt() {
		return y3Age90TotCnt;
	}
	public void setY3Age90TotCnt(String y3Age90TotCnt) {
		this.y3Age90TotCnt = y3Age90TotCnt;
	}
	public String getY3Age80FmlCnt() {
		return y3Age80FmlCnt;
	}
	public void setY3Age80FmlCnt(String y3Age80FmlCnt) {
		this.y3Age80FmlCnt = y3Age80FmlCnt;
	}
	public String getY3Age80MlCnt() {
		return y3Age80MlCnt;
	}
	public void setY3Age80MlCnt(String y3Age80MlCnt) {
		this.y3Age80MlCnt = y3Age80MlCnt;
	}
	public String getY3Age80TotCnt() {
		return y3Age80TotCnt;
	}
	public void setY3Age80TotCnt(String y3Age80TotCnt) {
		this.y3Age80TotCnt = y3Age80TotCnt;
	}
	public String getY3Age70FmlCnt() {
		return y3Age70FmlCnt;
	}
	public void setY3Age70FmlCnt(String y3Age70FmlCnt) {
		this.y3Age70FmlCnt = y3Age70FmlCnt;
	}
	public String getY3Age70MlCnt() {
		return y3Age70MlCnt;
	}
	public void setY3Age70MlCnt(String y3Age70MlCnt) {
		this.y3Age70MlCnt = y3Age70MlCnt;
	}
	public String getY3Age70TotCnt() {
		return y3Age70TotCnt;
	}
	public void setY3Age70TotCnt(String y3Age70TotCnt) {
		this.y3Age70TotCnt = y3Age70TotCnt;
	}
	public String getY3Age60FmlCnt() {
		return y3Age60FmlCnt;
	}
	public void setY3Age60FmlCnt(String y3Age60FmlCnt) {
		this.y3Age60FmlCnt = y3Age60FmlCnt;
	}
	public String getY3Age60MlCnt() {
		return y3Age60MlCnt;
	}
	public void setY3Age60MlCnt(String y3Age60MlCnt) {
		this.y3Age60MlCnt = y3Age60MlCnt;
	}
	public String getY3Age60TotCnt() {
		return y3Age60TotCnt;
	}
	public void setY3Age60TotCnt(String y3Age60TotCnt) {
		this.y3Age60TotCnt = y3Age60TotCnt;
	}
	public String getY3Age50FmlCnt() {
		return y3Age50FmlCnt;
	}
	public void setY3Age50FmlCnt(String y3Age50FmlCnt) {
		this.y3Age50FmlCnt = y3Age50FmlCnt;
	}
	public String getY3Age50MlCnt() {
		return y3Age50MlCnt;
	}
	public void setY3Age50MlCnt(String y3Age50MlCnt) {
		this.y3Age50MlCnt = y3Age50MlCnt;
	}
	public String getY3Age50TotCnt() {
		return y3Age50TotCnt;
	}
	public void setY3Age50TotCnt(String y3Age50TotCnt) {
		this.y3Age50TotCnt = y3Age50TotCnt;
	}
	public String getY3Age40FmlCnt() {
		return y3Age40FmlCnt;
	}
	public void setY3Age40FmlCnt(String y3Age40FmlCnt) {
		this.y3Age40FmlCnt = y3Age40FmlCnt;
	}
	public String getY3Age40MlCnt() {
		return y3Age40MlCnt;
	}
	public void setY3Age40MlCnt(String y3Age40MlCnt) {
		this.y3Age40MlCnt = y3Age40MlCnt;
	}
	public String getY3Age40TotCnt() {
		return y3Age40TotCnt;
	}
	public void setY3Age40TotCnt(String y3Age40TotCnt) {
		this.y3Age40TotCnt = y3Age40TotCnt;
	}
	public String getY3Age30FmlCnt() {
		return y3Age30FmlCnt;
	}
	public void setY3Age30FmlCnt(String y3Age30FmlCnt) {
		this.y3Age30FmlCnt = y3Age30FmlCnt;
	}
	public String getY3Age30MlCnt() {
		return y3Age30MlCnt;
	}
	public void setY3Age30MlCnt(String y3Age30MlCnt) {
		this.y3Age30MlCnt = y3Age30MlCnt;
	}
	public String getY3Age30TotCnt() {
		return y3Age30TotCnt;
	}
	public void setY3Age30TotCnt(String y3Age30TotCnt) {
		this.y3Age30TotCnt = y3Age30TotCnt;
	}
	public String getY3Age20FmlCnt() {
		return y3Age20FmlCnt;
	}
	public void setY3Age20FmlCnt(String y3Age20FmlCnt) {
		this.y3Age20FmlCnt = y3Age20FmlCnt;
	}
	public String getY3Age20MlCnt() {
		return y3Age20MlCnt;
	}
	public void setY3Age20MlCnt(String y3Age20MlCnt) {
		this.y3Age20MlCnt = y3Age20MlCnt;
	}
	public String getY3Age20TotCnt() {
		return y3Age20TotCnt;
	}
	public void setY3Age20TotCnt(String y3Age20TotCnt) {
		this.y3Age20TotCnt = y3Age20TotCnt;
	}
	public String getY3Age10FmlCnt() {
		return y3Age10FmlCnt;
	}
	public void setY3Age10FmlCnt(String y3Age10FmlCnt) {
		this.y3Age10FmlCnt = y3Age10FmlCnt;
	}
	public String getY3Age10MlCnt() {
		return y3Age10MlCnt;
	}
	public void setY3Age10MlCnt(String y3Age10MlCnt) {
		this.y3Age10MlCnt = y3Age10MlCnt;
	}
	public String getY3Age10TotCnt() {
		return y3Age10TotCnt;
	}
	public void setY3Age10TotCnt(String y3Age10TotCnt) {
		this.y3Age10TotCnt = y3Age10TotCnt;
	}
	public String getY3Age0FmlCnt() {
		return y3Age0FmlCnt;
	}
	public void setY3Age0FmlCnt(String y3Age0FmlCnt) {
		this.y3Age0FmlCnt = y3Age0FmlCnt;
	}
	public String getY3Age0MlCnt() {
		return y3Age0MlCnt;
	}
	public void setY3Age0MlCnt(String y3Age0MlCnt) {
		this.y3Age0MlCnt = y3Age0MlCnt;
	}
	public String getY3Age0TotCnt() {
		return y3Age0TotCnt;
	}
	public void setY3Age0TotCnt(String y3Age0TotCnt) {
		this.y3Age0TotCnt = y3Age0TotCnt;
	}
	public String getY4Age100FmlCnt() {
		return y4Age100FmlCnt;
	}
	public void setY4Age100FmlCnt(String y4Age100FmlCnt) {
		this.y4Age100FmlCnt = y4Age100FmlCnt;
	}
	public String getY4Age100MlCnt() {
		return y4Age100MlCnt;
	}
	public void setY4Age100MlCnt(String y4Age100MlCnt) {
		this.y4Age100MlCnt = y4Age100MlCnt;
	}
	public String getY4Age100TotCnt() {
		return y4Age100TotCnt;
	}
	public void setY4Age100TotCnt(String y4Age100TotCnt) {
		this.y4Age100TotCnt = y4Age100TotCnt;
	}
	public String getY4Age90FmlCnt() {
		return y4Age90FmlCnt;
	}
	public void setY4Age90FmlCnt(String y4Age90FmlCnt) {
		this.y4Age90FmlCnt = y4Age90FmlCnt;
	}
	public String getY4Age90MlCnt() {
		return y4Age90MlCnt;
	}
	public void setY4Age90MlCnt(String y4Age90MlCnt) {
		this.y4Age90MlCnt = y4Age90MlCnt;
	}
	public String getY4Age90TotCnt() {
		return y4Age90TotCnt;
	}
	public void setY4Age90TotCnt(String y4Age90TotCnt) {
		this.y4Age90TotCnt = y4Age90TotCnt;
	}
	public String getY4Age80FmlCnt() {
		return y4Age80FmlCnt;
	}
	public void setY4Age80FmlCnt(String y4Age80FmlCnt) {
		this.y4Age80FmlCnt = y4Age80FmlCnt;
	}
	public String getY4Age80MlCnt() {
		return y4Age80MlCnt;
	}
	public void setY4Age80MlCnt(String y4Age80MlCnt) {
		this.y4Age80MlCnt = y4Age80MlCnt;
	}
	public String getY4Age80TotCnt() {
		return y4Age80TotCnt;
	}
	public void setY4Age80TotCnt(String y4Age80TotCnt) {
		this.y4Age80TotCnt = y4Age80TotCnt;
	}
	public String getY4Age70FmlCnt() {
		return y4Age70FmlCnt;
	}
	public void setY4Age70FmlCnt(String y4Age70FmlCnt) {
		this.y4Age70FmlCnt = y4Age70FmlCnt;
	}
	public String getY4Age70MlCnt() {
		return y4Age70MlCnt;
	}
	public void setY4Age70MlCnt(String y4Age70MlCnt) {
		this.y4Age70MlCnt = y4Age70MlCnt;
	}
	public String getY4Age70TotCnt() {
		return y4Age70TotCnt;
	}
	public void setY4Age70TotCnt(String y4Age70TotCnt) {
		this.y4Age70TotCnt = y4Age70TotCnt;
	}
	public String getY4Age60FmlCnt() {
		return y4Age60FmlCnt;
	}
	public void setY4Age60FmlCnt(String y4Age60FmlCnt) {
		this.y4Age60FmlCnt = y4Age60FmlCnt;
	}
	public String getY4Age60MlCnt() {
		return y4Age60MlCnt;
	}
	public void setY4Age60MlCnt(String y4Age60MlCnt) {
		this.y4Age60MlCnt = y4Age60MlCnt;
	}
	public String getY4Age60TotCnt() {
		return y4Age60TotCnt;
	}
	public void setY4Age60TotCnt(String y4Age60TotCnt) {
		this.y4Age60TotCnt = y4Age60TotCnt;
	}
	public String getY4Age50FmlCnt() {
		return y4Age50FmlCnt;
	}
	public void setY4Age50FmlCnt(String y4Age50FmlCnt) {
		this.y4Age50FmlCnt = y4Age50FmlCnt;
	}
	public String getY4Age50MlCnt() {
		return y4Age50MlCnt;
	}
	public void setY4Age50MlCnt(String y4Age50MlCnt) {
		this.y4Age50MlCnt = y4Age50MlCnt;
	}
	public String getY4Age50TotCnt() {
		return y4Age50TotCnt;
	}
	public void setY4Age50TotCnt(String y4Age50TotCnt) {
		this.y4Age50TotCnt = y4Age50TotCnt;
	}
	public String getY4Age40FmlCnt() {
		return y4Age40FmlCnt;
	}
	public void setY4Age40FmlCnt(String y4Age40FmlCnt) {
		this.y4Age40FmlCnt = y4Age40FmlCnt;
	}
	public String getY4Age40MlCnt() {
		return y4Age40MlCnt;
	}
	public void setY4Age40MlCnt(String y4Age40MlCnt) {
		this.y4Age40MlCnt = y4Age40MlCnt;
	}
	public String getY4Age40TotCnt() {
		return y4Age40TotCnt;
	}
	public void setY4Age40TotCnt(String y4Age40TotCnt) {
		this.y4Age40TotCnt = y4Age40TotCnt;
	}
	public String getY4Age30FmlCnt() {
		return y4Age30FmlCnt;
	}
	public void setY4Age30FmlCnt(String y4Age30FmlCnt) {
		this.y4Age30FmlCnt = y4Age30FmlCnt;
	}
	public String getY4Age30MlCnt() {
		return y4Age30MlCnt;
	}
	public void setY4Age30MlCnt(String y4Age30MlCnt) {
		this.y4Age30MlCnt = y4Age30MlCnt;
	}
	public String getY4Age30TotCnt() {
		return y4Age30TotCnt;
	}
	public void setY4Age30TotCnt(String y4Age30TotCnt) {
		this.y4Age30TotCnt = y4Age30TotCnt;
	}
	public String getY4Age20FmlCnt() {
		return y4Age20FmlCnt;
	}
	public void setY4Age20FmlCnt(String y4Age20FmlCnt) {
		this.y4Age20FmlCnt = y4Age20FmlCnt;
	}
	public String getY4Age20MlCnt() {
		return y4Age20MlCnt;
	}
	public void setY4Age20MlCnt(String y4Age20MlCnt) {
		this.y4Age20MlCnt = y4Age20MlCnt;
	}
	public String getY4Age20TotCnt() {
		return y4Age20TotCnt;
	}
	public void setY4Age20TotCnt(String y4Age20TotCnt) {
		this.y4Age20TotCnt = y4Age20TotCnt;
	}
	public String getY4Age10FmlCnt() {
		return y4Age10FmlCnt;
	}
	public void setY4Age10FmlCnt(String y4Age10FmlCnt) {
		this.y4Age10FmlCnt = y4Age10FmlCnt;
	}
	public String getY4Age10MlCnt() {
		return y4Age10MlCnt;
	}
	public void setY4Age10MlCnt(String y4Age10MlCnt) {
		this.y4Age10MlCnt = y4Age10MlCnt;
	}
	public String getY4Age10TotCnt() {
		return y4Age10TotCnt;
	}
	public void setY4Age10TotCnt(String y4Age10TotCnt) {
		this.y4Age10TotCnt = y4Age10TotCnt;
	}
	public String getY4Age0FmlCnt() {
		return y4Age0FmlCnt;
	}
	public void setY4Age0FmlCnt(String y4Age0FmlCnt) {
		this.y4Age0FmlCnt = y4Age0FmlCnt;
	}
	public String getY4Age0MlCnt() {
		return y4Age0MlCnt;
	}
	public void setY4Age0MlCnt(String y4Age0MlCnt) {
		this.y4Age0MlCnt = y4Age0MlCnt;
	}
	public String getY4Age0TotCnt() {
		return y4Age0TotCnt;
	}
	public void setY4Age0TotCnt(String y4Age0TotCnt) {
		this.y4Age0TotCnt = y4Age0TotCnt;
	}
	public String getDstrNm() {
		return dstrNm;
	}
	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}
	public String getPrvicNm() {
		return prvicNm;
	}
	public void setPrvicNm(String prvicNm) {
		this.prvicNm = prvicNm;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getStsTitCd() {
		return stsTitCd;
	}
	public void setStsTitCd(String stsTitCd) {
		this.stsTitCd = stsTitCd;
	}
	public String getStsTitNm() {
		return stsTitNm;
	}
	public void setStsTitNm(String stsTitNm) {
		this.stsTitNm = stsTitNm;
	}
	public String getAdCd() {
		return adCd;
	}
	public void setAdCd(String adCd) {
		this.adCd = adCd;
	}
	public String getAdCdNm() {
		return adCdNm;
	}
	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}
	


}
