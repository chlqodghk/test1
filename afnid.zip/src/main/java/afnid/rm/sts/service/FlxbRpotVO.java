package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class FlxbRpotVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	// add choi start
	private String gfthrRsdtSeqNo;
	private String moherRsdtSeqNo;
	private String fmalyLangCd;
	private String poliCntrSeqNo;
	private String crdIsucePlceCd;
	private String oldCrdIsucePlceCd;
	private String oldCrdIsucePlceCdNm;
	private String rsdtStusCd;
	private String curtAdDiv;
	private String curtAdNatCd;
	private String calTye;
	private String bthDd2;
	private String [] conditionList;
	private String [] outputDataList;
	// add choi end
	
	private String seqNo;
	private String hRqstDd;
	private String gRqstDd;
	private String userId;
	private String userNm;
	private String datCn;
	private String hGnrDd;
	private String gGnrDd;	
	private String gnrYn;
	
	private String rpotCndCd;
	private String rpotCndCdNm;
	private String cnd1;
	private String cnd2;
	private String cnd3;
	
	private String rpotItemCd;
	private String rpotItemCdNm;
	private String cdSotNo;
	
	private String rsutSeqNo;
	private String rsdtNo;
    private String[] rsdtNoArray;
	private String rsdtNoDp;
	private String rsdtNoDpMsk;
	private String rsdtNoXxDp;
	private String givNm;
	private String surnm;
	private String nmMsk;
	private String enGivNm;
	private String enSurnm;
	private String enNmMsk;
	private String fthrRsdtSeqNo;
	private String fthrNm;
	private String gfthrRsdeSeqNo;
	private String gfthrNm;
	private String mthrRsdtSeqNo;
	private String mthrNm;
	private String bthDd;
	private String hBthDd;
	private String gBthDd;
	private String gdrCd;
	private String gdrCdNm;
	private String pmntAdCd;
	private String pmntAdCdNm;
	private String pmntAdDtlCt;
	private String curtAdCd;
	private String curtAdCdNm;
	private String curtAdDtlCt;
	private String bthPlceCd;
	private String bthPlceCdNm;
	private String bthNatDiv;
	private String bthNatCd;
	private String bthNatCdNm;
	private String frgnBthCtyNm;
	private String wtrRsdcCd;
	private String wtrRsdcCdNm;
	private String smrRsdcCd;
	private String smrRsdcCdNm;
	private String mrrgCd;
	private String mrrgCdNm;
	private String spusRsdtSeqNo;
	private String spusNm;
	private String eduYn;
	private String eduCd;
	private String eduCdNm;
	private String eduLvDocYn;
	private String bldTyeCd;
	private String bldTyeCdNm;
	private String bldTyeDocYn;
	private String fmlyLangCd;
	private String fmlyLangCdNm;
	private String othrNatLangCd;
	private String othrNatLangCdNm;
	private String frgnLangCd;
	private String frgnLangCdNm;
	private String rlgnCd;
	private String rlgnCdNm;
	private String rlgnSectCd;
	private String rlgnSectCdNm;
	private String encyCd;
	private String encyCdNm;
	private String dsbtCd;
	private String dsbtCdNm;
	private String mltSrvcCd;
	private String mltSrvcCdNm;
	private String secdNltyYn;
	private String secdNltyCd;
	private String secdNltyCdNm;
	private String poliCntrSeqNoNm;
	private String crdIsucePlceCdNm;
	private String crdIsuceDd;
	private String hCrdIsuceDd;
	private String gCrdIsuceDd;
	private String crdExpiryDd;
	private String hCcrdExpiryDd;
	private String gCrdExpiryDd;
	private String oldCrdNo1;
	private String oldCrdNo2;
	private String oldCrdNo3;
	private String oldCrdNo4;
	private String oldCrdIsucePlceNm;
	private String oldCrdIsuceDd;
	private String hOldCrdIsuceDd;
	private String gOldCrdIsuceDd;
	private String rsdtStusCdNm;
	private String ersrCd;
	private String ersrCdNm;
	
	private String rcdCnPerPage;
	private String rpotItemWdth;
	
	private String rsdtNoUnMskLen;
	private String nmUnMskLen;
	private String enNmUnMskLen;
	
	private String sortDescYn;
	
	public String getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	public String gethRqstDd() {
		return hRqstDd;
	}
	public void sethRqstDd(String hRqstDd) {
		this.hRqstDd = hRqstDd;
	}
	public String getgRqstDd() {
		return gRqstDd;
	}
	public void setgRqstDd(String gRqstDd) {
		this.gRqstDd = gRqstDd;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getDatCn() {
		return datCn;
	}
	public void setDatCn(String datCn) {
		this.datCn = datCn;
	}
	public String gethGnrDd() {
		return hGnrDd;
	}
	public void sethGnrDd(String hGnrDd) {
		this.hGnrDd = hGnrDd;
	}
	public String getgGnrDd() {
		return gGnrDd;
	}
	public void setgGnrDd(String gGnrDd) {
		this.gGnrDd = gGnrDd;
	}
	public String getGnrYn() {
		return gnrYn;
	}
	public void setGnrYn(String gnrYn) {
		this.gnrYn = gnrYn;
	}
	public String getRpotCndCd() {
		return rpotCndCd;
	}
	public void setRpotCndCd(String rpotCndCd) {
		this.rpotCndCd = rpotCndCd;
	}
	public String getRpotCndCdNm() {
		return rpotCndCdNm;
	}
	public void setRpotCndCdNm(String rpotCndCdNm) {
		this.rpotCndCdNm = rpotCndCdNm;
	}
	public String getCnd1() {
		return cnd1;
	}
	public void setCnd1(String cnd1) {
		this.cnd1 = cnd1;
	}
	public String getCnd2() {
		return cnd2;
	}
	public void setCnd2(String cnd2) {
		this.cnd2 = cnd2;
	}
	public String getCnd3() {
		return cnd3;
	}
	public void setCnd3(String cnd3) {
		this.cnd3 = cnd3;
	}
	public String getRpotItemCd() {
		return rpotItemCd;
	}
	public void setRpotItemCd(String rpotItemCd) {
		this.rpotItemCd = rpotItemCd;
	}
	public String getRpotItemCdNm() {
		return rpotItemCdNm;
	}
	public void setRpotItemCdNm(String rpotItemCdNm) {
		this.rpotItemCdNm = rpotItemCdNm;
	}
	public String getCdSotNo() {
		return cdSotNo;
	}
	public void setCdSotNo(String cdSotNo) {
		this.cdSotNo = cdSotNo;
	}
	public String getRsutSeqNo() {
		return rsutSeqNo;
	}
	public void setRsutSeqNo(String rsutSeqNo) {
		this.rsutSeqNo = rsutSeqNo;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	public String getRsdtNoXxDp() {
		return rsdtNoXxDp;
	}
	public void setRsdtNoXxDp(String rsdtNoXxDp) {
		this.rsdtNoXxDp = rsdtNoXxDp;
	}
	public String getGivNm() {
		return givNm;
	}
	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}
	public String getSurnm() {
		return surnm;
	}
	public void setSurnm(String surnm) {
		this.surnm = surnm;
	}
	public String getEnGivNm() {
		return enGivNm;
	}
	public void setEnGivNm(String enGivNm) {
		this.enGivNm = enGivNm;
	}
	public String getEnSurnm() {
		return enSurnm;
	}
	public void setEnSurnm(String enSurnm) {
		this.enSurnm = enSurnm;
	}
	public String getFthrRsdtSeqNo() {
		return fthrRsdtSeqNo;
	}
	public void setFthrRsdtSeqNo(String fthrRsdtSeqNo) {
		this.fthrRsdtSeqNo = fthrRsdtSeqNo;
	}
	public String getFthrNm() {
		return fthrNm;
	}
	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}
	public String getGfthrRsdeSeqNo() {
		return gfthrRsdeSeqNo;
	}
	public void setGfthrRsdeSeqNo(String gfthrRsdeSeqNo) {
		this.gfthrRsdeSeqNo = gfthrRsdeSeqNo;
	}
	public String getGfthrNm() {
		return gfthrNm;
	}
	public void setGfthrNm(String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}
	public String getMthrRsdtSeqNo() {
		return mthrRsdtSeqNo;
	}
	public void setMthrRsdtSeqNo(String mthrRsdtSeqNo) {
		this.mthrRsdtSeqNo = mthrRsdtSeqNo;
	}
	public String getMthrNm() {
		return mthrNm;
	}
	public void setMthrNm(String mthrNm) {
		this.mthrNm = mthrNm;
	}
	public String getBthDd() {
		return bthDd;
	}
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	public String gethBthDd() {
		return hBthDd;
	}
	public void sethBthDd(String hBthDd) {
		this.hBthDd = hBthDd;
	}
	public String getgBthDd() {
		return gBthDd;
	}
	public void setgBthDd(String gBthDd) {
		this.gBthDd = gBthDd;
	}
	public String getGdrCd() {
		return gdrCd;
	}
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	public String getPmntAdCd() {
		return pmntAdCd;
	}
	public void setPmntAdCd(String pmntAdCd) {
		this.pmntAdCd = pmntAdCd;
	}
	public String getPmntAdCdNm() {
		return pmntAdCdNm;
	}
	public void setPmntAdCdNm(String pmntAdCdNm) {
		this.pmntAdCdNm = pmntAdCdNm;
	}
	public String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}
	public void setPmntAdDtlCt(String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}
	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}
	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}
	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}
	public String getBthPlceCd() {
		return bthPlceCd;
	}
	public void setBthPlceCd(String bthPlceCd) {
		this.bthPlceCd = bthPlceCd;
	}
	public String getBthPlceCdNm() {
		return bthPlceCdNm;
	}
	public void setBthPlceCdNm(String bthPlceCdNm) {
		this.bthPlceCdNm = bthPlceCdNm;
	}
	public String getBthNatDiv() {
		return bthNatDiv;
	}
	public void setBthNatDiv(String bthNatDiv) {
		this.bthNatDiv = bthNatDiv;
	}
	public String getBthNatCd() {
		return bthNatCd;
	}
	public void setBthNatCd(String bthNatCd) {
		this.bthNatCd = bthNatCd;
	}
	public String getBthNatCdNm() {
		return bthNatCdNm;
	}
	public void setBthNatCdNm(String bthNatCdNm) {
		this.bthNatCdNm = bthNatCdNm;
	}
	public String getFrgnBthCtyNm() {
		return frgnBthCtyNm;
	}
	public void setFrgnBthCtyNm(String frgnBthCtyNm) {
		this.frgnBthCtyNm = frgnBthCtyNm;
	}
	public String getWtrRsdcCd() {
		return wtrRsdcCd;
	}
	public void setWtrRsdcCd(String wtrRsdcCd) {
		this.wtrRsdcCd = wtrRsdcCd;
	}
	public String getWtrRsdcCdNm() {
		return wtrRsdcCdNm;
	}
	public void setWtrRsdcCdNm(String wtrRsdcCdNm) {
		this.wtrRsdcCdNm = wtrRsdcCdNm;
	}
	public String getSmrRsdcCd() {
		return smrRsdcCd;
	}
	public void setSmrRsdcCd(String smrRsdcCd) {
		this.smrRsdcCd = smrRsdcCd;
	}
	public String getSmrRsdcCdNm() {
		return smrRsdcCdNm;
	}
	public void setSmrRsdcCdNm(String smrRsdcCdNm) {
		this.smrRsdcCdNm = smrRsdcCdNm;
	}
	public String getMrrgCd() {
		return mrrgCd;
	}
	public void setMrrgCd(String mrrgCd) {
		this.mrrgCd = mrrgCd;
	}
	public String getMrrgCdNm() {
		return mrrgCdNm;
	}
	public void setMrrgCdNm(String mrrgCdNm) {
		this.mrrgCdNm = mrrgCdNm;
	}
	public String getSpusRsdtSeqNo() {
		return spusRsdtSeqNo;
	}
	public void setSpusRsdtSeqNo(String spusRsdtSeqNo) {
		this.spusRsdtSeqNo = spusRsdtSeqNo;
	}
	public String getSpusNm() {
		return spusNm;
	}
	public void setSpusNm(String spusNm) {
		this.spusNm = spusNm;
	}
	public String getEduYn() {
		return eduYn;
	}
	public void setEduYn(String eduYn) {
		this.eduYn = eduYn;
	}
	public String getEduCd() {
		return eduCd;
	}
	public void setEduCd(String eduCd) {
		this.eduCd = eduCd;
	}
	public String getEduCdNm() {
		return eduCdNm;
	}
	public void setEduCdNm(String eduCdNm) {
		this.eduCdNm = eduCdNm;
	}
	public String getEduLvDocYn() {
		return eduLvDocYn;
	}
	public void setEduLvDocYn(String eduLvDocYn) {
		this.eduLvDocYn = eduLvDocYn;
	}
	public String getBldTyeCd() {
		return bldTyeCd;
	}
	public void setBldTyeCd(String bldTyeCd) {
		this.bldTyeCd = bldTyeCd;
	}
	public String getBldTyeCdNm() {
		return bldTyeCdNm;
	}
	public void setBldTyeCdNm(String bldTyeCdNm) {
		this.bldTyeCdNm = bldTyeCdNm;
	}
	public String getBldTyeDocYn() {
		return bldTyeDocYn;
	}
	public void setBldTyeDocYn(String bldTyeDocYn) {
		this.bldTyeDocYn = bldTyeDocYn;
	}
	public String getFmlyLangCd() {
		return fmlyLangCd;
	}
	public void setFmlyLangCd(String fmlyLangCd) {
		this.fmlyLangCd = fmlyLangCd;
	}
	public String getFmlyLangCdNm() {
		return fmlyLangCdNm;
	}
	public void setFmlyLangCdNm(String fmlyLangCdNm) {
		this.fmlyLangCdNm = fmlyLangCdNm;
	}
	public String getOthrNatLangCd() {
		return othrNatLangCd;
	}
	public void setOthrNatLangCd(String othrNatLangCd) {
		this.othrNatLangCd = othrNatLangCd;
	}
	public String getOthrNatLangCdNm() {
		return othrNatLangCdNm;
	}
	public void setOthrNatLangCdNm(String othrNatLangCdNm) {
		this.othrNatLangCdNm = othrNatLangCdNm;
	}
	public String getFrgnLangCd() {
		return frgnLangCd;
	}
	public void setFrgnLangCd(String frgnLangCd) {
		this.frgnLangCd = frgnLangCd;
	}
	public String getFrgnLangCdNm() {
		return frgnLangCdNm;
	}
	public void setFrgnLangCdNm(String frgnLangCdNm) {
		this.frgnLangCdNm = frgnLangCdNm;
	}
	public String getRlgnCd() {
		return rlgnCd;
	}
	public void setRlgnCd(String rlgnCd) {
		this.rlgnCd = rlgnCd;
	}
	public String getRlgnCdNm() {
		return rlgnCdNm;
	}
	public void setRlgnCdNm(String rlgnCdNm) {
		this.rlgnCdNm = rlgnCdNm;
	}
	public String getRlgnSectCd() {
		return rlgnSectCd;
	}
	public void setRlgnSectCd(String rlgnSectCd) {
		this.rlgnSectCd = rlgnSectCd;
	}
	public String getRlgnSectCdNm() {
		return rlgnSectCdNm;
	}
	public void setRlgnSectCdNm(String rlgnSectCdNm) {
		this.rlgnSectCdNm = rlgnSectCdNm;
	}
	public String getEncyCd() {
		return encyCd;
	}
	public void setEncyCd(String encyCd) {
		this.encyCd = encyCd;
	}
	public String getEncyCdNm() {
		return encyCdNm;
	}
	public void setEncyCdNm(String encyCdNm) {
		this.encyCdNm = encyCdNm;
	}
	public String getDsbtCd() {
		return dsbtCd;
	}
	public void setDsbtCd(String dsbtCd) {
		this.dsbtCd = dsbtCd;
	}
	public String getDsbtCdNm() {
		return dsbtCdNm;
	}
	public void setDsbtCdNm(String dsbtCdNm) {
		this.dsbtCdNm = dsbtCdNm;
	}
	public String getMltSrvcCd() {
		return mltSrvcCd;
	}
	public void setMltSrvcCd(String mltSrvcCd) {
		this.mltSrvcCd = mltSrvcCd;
	}
	public String getMltSrvcCdNm() {
		return mltSrvcCdNm;
	}
	public void setMltSrvcCdNm(String mltSrvcCdNm) {
		this.mltSrvcCdNm = mltSrvcCdNm;
	}
	public String getSecdNltyYn() {
		return secdNltyYn;
	}
	public void setSecdNltyYn(String secdNltyYn) {
		this.secdNltyYn = secdNltyYn;
	}
	public String getSecdNltyCd() {
		return secdNltyCd;
	}
	public void setSecdNltyCd(String secdNltyCd) {
		this.secdNltyCd = secdNltyCd;
	}
	public String getSecdNltyCdNm() {
		return secdNltyCdNm;
	}
	public void setSecdNltyCdNm(String secdNltyCdNm) {
		this.secdNltyCdNm = secdNltyCdNm;
	}
	public String getPoliCntrSeqNoNm() {
		return poliCntrSeqNoNm;
	}
	public void setPoliCntrSeqNoNm(String poliCntrSeqNoNm) {
		this.poliCntrSeqNoNm = poliCntrSeqNoNm;
	}
	public String getCrdIsucePlceCdNm() {
		return crdIsucePlceCdNm;
	}
	public void setCrdIsucePlceCdNm(String crdIsucePlceCdNm) {
		this.crdIsucePlceCdNm = crdIsucePlceCdNm;
	}
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public String gethCrdIsuceDd() {
		return hCrdIsuceDd;
	}
	public void sethCrdIsuceDd(String hCrdIsuceDd) {
		this.hCrdIsuceDd = hCrdIsuceDd;
	}
	public String getgCrdIsuceDd() {
		return gCrdIsuceDd;
	}
	public void setgCrdIsuceDd(String gCrdIsuceDd) {
		this.gCrdIsuceDd = gCrdIsuceDd;
	}
	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}
	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}
	public String gethCcrdExpiryDd() {
		return hCcrdExpiryDd;
	}
	public void sethCcrdExpiryDd(String hCcrdExpiryDd) {
		this.hCcrdExpiryDd = hCcrdExpiryDd;
	}
	public String getgCrdExpiryDd() {
		return gCrdExpiryDd;
	}
	public void setgCrdExpiryDd(String gCrdExpiryDd) {
		this.gCrdExpiryDd = gCrdExpiryDd;
	}
	public String getOldCrdNo1() {
		return oldCrdNo1;
	}
	public void setOldCrdNo1(String oldCrdNo1) {
		this.oldCrdNo1 = oldCrdNo1;
	}
	public String getOldCrdNo2() {
		return oldCrdNo2;
	}
	public void setOldCrdNo2(String oldCrdNo2) {
		this.oldCrdNo2 = oldCrdNo2;
	}
	public String getOldCrdNo3() {
		return oldCrdNo3;
	}
	public void setOldCrdNo3(String oldCrdNo3) {
		this.oldCrdNo3 = oldCrdNo3;
	}
	public String getOldCrdNo4() {
		return oldCrdNo4;
	}
	public void setOldCrdNo4(String oldCrdNo4) {
		this.oldCrdNo4 = oldCrdNo4;
	}
	public String getOldCrdIsucePlceNm() {
		return oldCrdIsucePlceNm;
	}
	public void setOldCrdIsucePlceNm(String oldCrdIsucePlceNm) {
		this.oldCrdIsucePlceNm = oldCrdIsucePlceNm;
	}
	public String getOldCrdIsuceDd() {
		return oldCrdIsuceDd;
	}
	public void setOldCrdIsuceDd(String oldCrdIsuceDd) {
		this.oldCrdIsuceDd = oldCrdIsuceDd;
	}
	public String gethOldCrdIsuceDd() {
		return hOldCrdIsuceDd;
	}
	public void sethOldCrdIsuceDd(String hOldCrdIsuceDd) {
		this.hOldCrdIsuceDd = hOldCrdIsuceDd;
	}
	public String getgOldCrdIsuceDd() {
		return gOldCrdIsuceDd;
	}
	public void setgOldCrdIsuceDd(String gOldCrdIsuceDd) {
		this.gOldCrdIsuceDd = gOldCrdIsuceDd;
	}
	public String getRsdtStusCdNm() {
		return rsdtStusCdNm;
	}
	public void setRsdtStusCdNm(String rsdtStusCdNm) {
		this.rsdtStusCdNm = rsdtStusCdNm;
	}
	public String getErsrCd() {
		return ersrCd;
	}
	public void setErsrCd(String ersrCd) {
		this.ersrCd = ersrCd;
	}
	public String getErsrCdNm() {
		return ersrCdNm;
	}
	public void setErsrCdNm(String ersrCdNm) {
		this.ersrCdNm = ersrCdNm;
	}
	public String getRcdCnPerPage() {
		return rcdCnPerPage;
	}
	public void setRcdCnPerPage(String rcdCnPerPage) {
		this.rcdCnPerPage = rcdCnPerPage;
	}
	public String getRpotItemWdth() {
		return rpotItemWdth;
	}
	public void setRpotItemWdth(String rpotItemWdth) {
		this.rpotItemWdth = rpotItemWdth;
	}
	public String getRsdtNoDpMsk() {
		return rsdtNoDpMsk;
	}
	public void setRsdtNoDpMsk(String rsdtNoDpMsk) {
		this.rsdtNoDpMsk = rsdtNoDpMsk;
	}
	public String getNmMsk() {
		return nmMsk;
	}
	public void setNmMsk(String nmMsk) {
		this.nmMsk = nmMsk;
	}
	public String getEnNmMsk() {
		return enNmMsk;
	}
	public void setEnNmMsk(String enNmMsk) {
		this.enNmMsk = enNmMsk;
	}
	public String getRsdtNoUnMskLen() {
		return rsdtNoUnMskLen;
	}
	public void setRsdtNoUnMskLen(String rsdtNoUnMskLen) {
		this.rsdtNoUnMskLen = rsdtNoUnMskLen;
	}
	public String getNmUnMskLen() {
		return nmUnMskLen;
	}
	public void setNmUnMskLen(String nmUnMskLen) {
		this.nmUnMskLen = nmUnMskLen;
	}
	public String getEnNmUnMskLen() {
		return enNmUnMskLen;
	}
	public void setEnNmUnMskLen(String enNmUnMskLen) {
		this.enNmUnMskLen = enNmUnMskLen;
	}
	public String getSortDescYn() {
		return sortDescYn;
	}
	public void setSortDescYn(String sortDescYn) {
		this.sortDescYn = sortDescYn;
	}
	public String[] getRsdtNoArray() {
		return rsdtNoArray;
	}
	public void setRsdtNoArray(String[] rsdtNoArray) {
		this.rsdtNoArray = rsdtNoArray;
	}
	public String getGfthrRsdtSeqNo() {
		return gfthrRsdtSeqNo;
	}
	public void setGfthrRsdtSeqNo(String gfthrRsdtSeqNo) {
		this.gfthrRsdtSeqNo = gfthrRsdtSeqNo;
	}
	public String getMoherRsdtSeqNo() {
		return moherRsdtSeqNo;
	}
	public void setMoherRsdtSeqNo(String moherRsdtSeqNo) {
		this.moherRsdtSeqNo = moherRsdtSeqNo;
	}
	public String getFmalyLangCd() {
		return fmalyLangCd;
	}
	public void setFmalyLangCd(String fmalyLangCd) {
		this.fmalyLangCd = fmalyLangCd;
	}
	public String getPoliCntrSeqNo() {
		return poliCntrSeqNo;
	}
	public void setPoliCntrSeqNo(String poliCntrSeqNo) {
		this.poliCntrSeqNo = poliCntrSeqNo;
	}
	public String getCrdIsucePlceCd() {
		return crdIsucePlceCd;
	}
	public void setCrdIsucePlceCd(String crdIsucePlceCd) {
		this.crdIsucePlceCd = crdIsucePlceCd;
	}
	public String getOldCrdIsucePlceCd() {
		return oldCrdIsucePlceCd;
	}
	public void setOldCrdIsucePlceCd(String oldCrdIsucePlceCd) {
		this.oldCrdIsucePlceCd = oldCrdIsucePlceCd;
	}
	public String getOldCrdIsucePlceCdNm() {
		return oldCrdIsucePlceCdNm;
	}
	public void setOldCrdIsucePlceCdNm(String oldCrdIsucePlceCdNm) {
		this.oldCrdIsucePlceCdNm = oldCrdIsucePlceCdNm;
	}
	public String getRsdtStusCd() {
		return rsdtStusCd;
	}
	public void setRsdtStusCd(String rsdtStusCd) {
		this.rsdtStusCd = rsdtStusCd;
	}
	public String getCurtAdDiv() {
		return curtAdDiv;
	}
	public void setCurtAdDiv(String curtAdDiv) {
		this.curtAdDiv = curtAdDiv;
	}
	public String getCurtAdNatCd() {
		return curtAdNatCd;
	}
	public void setCurtAdNatCd(String curtAdNatCd) {
		this.curtAdNatCd = curtAdNatCd;
	}
	public String getCalTye() {
		return calTye;
	}
	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}
	public String getBthDd2() {
		return bthDd2;
	}
	public void setBthDd2(String bthDd2) {
		this.bthDd2 = bthDd2;
	}
	public String[] getConditionList() {
		return conditionList;
	}
	public void setConditionList(String[] conditionList) {
		this.conditionList = conditionList;
	}
	public String[] getOutputDataList() {
		return outputDataList;
	}
	public void setOutputDataList(String[] outputDataList) {
		this.outputDataList = outputDataList;
	}
	

	
}
