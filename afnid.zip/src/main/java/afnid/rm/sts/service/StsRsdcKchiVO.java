package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsRsdcKchiVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String crnDd;
	private String wrtFmlCnt;
	private String wrtMlCnt;
	private String wtrTotCnt;
	private String smrFmlCnt;
	private String smrMlCnt;
	private String smrTotCnt;
	private String dstrNm;
	private String prvicNm;
	private String curtAdCd;
	private String stsTitCd;
	private String stsTitNm;
	private String adCd;
	private String adCdNm;	
	

	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	public String getWrtFmlCnt() {
		return wrtFmlCnt;
	}
	public void setWrtFmlCnt(String wrtFmlCnt) {
		this.wrtFmlCnt = wrtFmlCnt;
	}
	public String getWrtMlCnt() {
		return wrtMlCnt;
	}
	public void setWrtMlCnt(String wrtMlCnt) {
		this.wrtMlCnt = wrtMlCnt;
	}
	public String getWtrTotCnt() {
		return wtrTotCnt;
	}
	public void setWtrTotCnt(String wtrTotCnt) {
		this.wtrTotCnt = wtrTotCnt;
	}
	public String getSmrFmlCnt() {
		return smrFmlCnt;
	}
	public void setSmrFmlCnt(String smrFmlCnt) {
		this.smrFmlCnt = smrFmlCnt;
	}
	public String getSmrMlCnt() {
		return smrMlCnt;
	}
	public void setSmrMlCnt(String smrMlCnt) {
		this.smrMlCnt = smrMlCnt;
	}
	public String getSmrTotCnt() {
		return smrTotCnt;
	}
	public void setSmrTotCnt(String smrTotCnt) {
		this.smrTotCnt = smrTotCnt;
	}
	public String getDstrNm() {
		return dstrNm;
	}
	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}
	public String getPrvicNm() {
		return prvicNm;
	}
	public void setPrvicNm(String prvicNm) {
		this.prvicNm = prvicNm;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getStsTitCd() {
		return stsTitCd;
	}
	public void setStsTitCd(String stsTitCd) {
		this.stsTitCd = stsTitCd;
	}
	public String getStsTitNm() {
		return stsTitNm;
	}
	public void setStsTitNm(String stsTitNm) {
		this.stsTitNm = stsTitNm;
	}
	public String getAdCd() {
		return adCd;
	}
	public void setAdCd(String adCd) {
		this.adCd = adCd;
	}
	public String getAdCdNm() {
		return adCdNm;
	}
	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}

	
}
