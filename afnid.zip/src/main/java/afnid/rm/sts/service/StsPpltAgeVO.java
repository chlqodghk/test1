package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsPpltAgeVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String sysSgntInsp;
	private String crnDd;
	private String age100FmlCnt;
	private String age100MlCnt; 
	private String age100TotCnt;
	private String age90FmlCnt; 
	private String age90MlCnt;  
	private String age90TotCnt; 
	private String age80FmlCnt; 
	private String age80MlCnt;  
	private String age80TotCnt; 
	private String age70FmlCnt; 
	private String age70MlCnt;  
	private String age70TotCnt; 
	private String age60FmlCnt; 
	private String age60MlCnt;  
	private String age60TotCnt; 
	private String age50FmlCnt; 
	private String age50MlCnt;  
	private String age50TotCnt; 
	private String age40FmlCnt; 
	private String age40MlCnt;  
	private String age40TotCnt; 
	private String age30FmlCnt; 
	private String age30MlCnt;  
	private String age30TotCnt; 
	private String age20FmlCnt; 
	private String age20MlCnt;  
	private String age20TotCnt; 
	private String age10FmlCnt; 
	private String age10MlCnt;
	private String age10TotCnt; 
	private String age0FmlCnt;  
	private String age0MlCnt;   
	private String age0TotCnt;  
	private String dstrNm;
	private String prvicNm;
	private String curtAdCd;
	private String stsTitCd;
	private String stsTitNm;
	private String adCd;
	private String adCdNm;	
	

	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	public String getAge100FmlCnt() {
		return age100FmlCnt;
	}
	public void setAge100FmlCnt(String age100FmlCnt) {
		this.age100FmlCnt = age100FmlCnt;
	}
	public String getAge100MlCnt() {
		return age100MlCnt;
	}
	public void setAge100MlCnt(String age100MlCnt) {
		this.age100MlCnt = age100MlCnt;
	}
	public String getAge100TotCnt() {
		return age100TotCnt;
	}
	public void setAge100TotCnt(String age100TotCnt) {
		this.age100TotCnt = age100TotCnt;
	}
	public String getAge90FmlCnt() {
		return age90FmlCnt;
	}
	public void setAge90FmlCnt(String age90FmlCnt) {
		this.age90FmlCnt = age90FmlCnt;
	}
	public String getAge90MlCnt() {
		return age90MlCnt;
	}
	public void setAge90MlCnt(String age90MlCnt) {
		this.age90MlCnt = age90MlCnt;
	}
	public String getAge90TotCnt() {
		return age90TotCnt;
	}
	public void setAge90TotCnt(String age90TotCnt) {
		this.age90TotCnt = age90TotCnt;
	}
	public String getAge80FmlCnt() {
		return age80FmlCnt;
	}
	public void setAge80FmlCnt(String age80FmlCnt) {
		this.age80FmlCnt = age80FmlCnt;
	}
	public String getAge80MlCnt() {
		return age80MlCnt;
	}
	public void setAge80MlCnt(String age80MlCnt) {
		this.age80MlCnt = age80MlCnt;
	}
	public String getAge80TotCnt() {
		return age80TotCnt;
	}
	public void setAge80TotCnt(String age80TotCnt) {
		this.age80TotCnt = age80TotCnt;
	}
	public String getAge70FmlCnt() {
		return age70FmlCnt;
	}
	public void setAge70FmlCnt(String age70FmlCnt) {
		this.age70FmlCnt = age70FmlCnt;
	}
	public String getAge70MlCnt() {
		return age70MlCnt;
	}
	public void setAge70MlCnt(String age70MlCnt) {
		this.age70MlCnt = age70MlCnt;
	}
	public String getAge70TotCnt() {
		return age70TotCnt;
	}
	public void setAge70TotCnt(String age70TotCnt) {
		this.age70TotCnt = age70TotCnt;
	}
	public String getAge60FmlCnt() {
		return age60FmlCnt;
	}
	public void setAge60FmlCnt(String age60FmlCnt) {
		this.age60FmlCnt = age60FmlCnt;
	}
	public String getAge60MlCnt() {
		return age60MlCnt;
	}
	public void setAge60MlCnt(String age60MlCnt) {
		this.age60MlCnt = age60MlCnt;
	}
	public String getAge60TotCnt() {
		return age60TotCnt;
	}
	public void setAge60TotCnt(String age60TotCnt) {
		this.age60TotCnt = age60TotCnt;
	}
	public String getAge50FmlCnt() {
		return age50FmlCnt;
	}
	public void setAge50FmlCnt(String age50FmlCnt) {
		this.age50FmlCnt = age50FmlCnt;
	}
	public String getAge50MlCnt() {
		return age50MlCnt;
	}
	public void setAge50MlCnt(String age50MlCnt) {
		this.age50MlCnt = age50MlCnt;
	}
	public String getAge50TotCnt() {
		return age50TotCnt;
	}
	public void setAge50TotCnt(String age50TotCnt) {
		this.age50TotCnt = age50TotCnt;
	}
	public String getAge40FmlCnt() {
		return age40FmlCnt;
	}
	public void setAge40FmlCnt(String age40FmlCnt) {
		this.age40FmlCnt = age40FmlCnt;
	}
	public String getAge40MlCnt() {
		return age40MlCnt;
	}
	public void setAge40MlCnt(String age40MlCnt) {
		this.age40MlCnt = age40MlCnt;
	}
	public String getAge40TotCnt() {
		return age40TotCnt;
	}
	public void setAge40TotCnt(String age40TotCnt) {
		this.age40TotCnt = age40TotCnt;
	}
	public String getAge30FmlCnt() {
		return age30FmlCnt;
	}
	public void setAge30FmlCnt(String age30FmlCnt) {
		this.age30FmlCnt = age30FmlCnt;
	}
	public String getAge30MlCnt() {
		return age30MlCnt;
	}
	public void setAge30MlCnt(String age30MlCnt) {
		this.age30MlCnt = age30MlCnt;
	}
	public String getAge30TotCnt() {
		return age30TotCnt;
	}
	public void setAge30TotCnt(String age30TotCnt) {
		this.age30TotCnt = age30TotCnt;
	}
	public String getAge20FmlCnt() {
		return age20FmlCnt;
	}
	public void setAge20FmlCnt(String age20FmlCnt) {
		this.age20FmlCnt = age20FmlCnt;
	}
	public String getAge20MlCnt() {
		return age20MlCnt;
	}
	public void setAge20MlCnt(String age20MlCnt) {
		this.age20MlCnt = age20MlCnt;
	}
	public String getAge20TotCnt() {
		return age20TotCnt;
	}
	public void setAge20TotCnt(String age20TotCnt) {
		this.age20TotCnt = age20TotCnt;
	}
	public String getAge10FmlCnt() {
		return age10FmlCnt;
	}
	public void setAge10FmlCnt(String age10FmlCnt) {
		this.age10FmlCnt = age10FmlCnt;
	}
	public String getAge10MlCnt() {
		return age10MlCnt;
	}
	public void setAge10MlCnt(String age10MlCnt) {
		this.age10MlCnt = age10MlCnt;
	}
	public String getAge10TotCnt() {
		return age10TotCnt;
	}
	public void setAge10TotCnt(String age10TotCnt) {
		this.age10TotCnt = age10TotCnt;
	}
	public String getAge0FmlCnt() {
		return age0FmlCnt;
	}
	public void setAge0FmlCnt(String age0FmlCnt) {
		this.age0FmlCnt = age0FmlCnt;
	}
	public String getAge0MlCnt() {
		return age0MlCnt;
	}
	public void setAge0MlCnt(String age0MlCnt) {
		this.age0MlCnt = age0MlCnt;
	}
	public String getAge0TotCnt() {
		return age0TotCnt;
	}
	public void setAge0TotCnt(String age0TotCnt) {
		this.age0TotCnt = age0TotCnt;
	}
	public String getDstrNm() {
		return dstrNm;
	}
	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}
	public String getPrvicNm() {
		return prvicNm;
	}
	public void setPrvicNm(String prvicNm) {
		this.prvicNm = prvicNm;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getStsTitCd() {
		return stsTitCd;
	}
	public void setStsTitCd(String stsTitCd) {
		this.stsTitCd = stsTitCd;
	}
	public String getStsTitNm() {
		return stsTitNm;
	}
	public void setStsTitNm(String stsTitNm) {
		this.stsTitNm = stsTitNm;
	}
	public String getAdCd() {
		return adCd;
	}
	public void setAdCd(String adCd) {
		this.adCd = adCd;
	}
	public String getAdCdNm() {
		return adCdNm;
	}
	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}
	public String getSysSgntInsp() {
		return sysSgntInsp;
	}
	public void setSysSgntInsp(String sysSgntInsp) {
		this.sysSgntInsp = sysSgntInsp;
	}


}
