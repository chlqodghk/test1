package afnid.rm.sts.service.impl;


import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.hst.service.RsdtInfrLgService;
import afnid.rm.sts.service.FlxbRpotService;
import afnid.rm.sts.service.FlxbRpotVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;


/** 
 * This service class is biz-class of Statistics  and implements StatisticsService class.
 * 
 * @author Afghanistan National ID RM Application Moon Soo Kim
 * @since 2015.04.13
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           	    			Revisions
 *   2015.04.13 		Moon Soo Kim		                    Create
 *
 * </pre>
 */

@Service("flxbRpotService")
public class FlxbRpotServiceImpl extends AbstractServiceImpl implements FlxbRpotService{
	/** RsdtInfoDao */
	@Resource(name="flxbRpotDAO")
    private FlxbRpotDAO dao;
	
    @Resource(name = "rsdtInfrLgService")
    private RsdtInfrLgService rsdtInfrLgService;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    	

	/**
	 * Biz-method for retrieving request list of flexible report. <br>
	 * 
	 * @param vo Input item for retrieving request list of flexible report(FlxbRpotVO).
	 * @return List Retrieve request list of flexible report
	 * @exception Exception
	 */
	public List<FlxbRpotVO> searchListRpotRqst(FlxbRpotVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());		
		return dao.selectListRpotRqst(vo);
	}

	/**
	 * Biz-method for retrieving total count request list of flexible report. <br>
	 * 
	 * @param vo Input item for retrieving total count request list of flexible report(FlxbRpotVO).
	 * @return int Total Count of flexible report request list
	 * @exception Exception
	 */
	public int searchListRpotRqstTotCn(FlxbRpotVO vo) throws Exception {
		return dao.selectListRpotRqstTotCn(vo);
	}    
    
	
	/**
	 * Biz-method for registering request of flexible report. <br>
	 * 
	 * @param vo Input item for registering request of flexible report(FlxbRpotVO).
	 * @return  void
	 * @exception Exception
	 */
	public void addRpotRqst(FlxbRpotVO vo) throws Exception {
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());	
		vo.setUserId(user.getUserId());
		vo.setDatCn(null);
		vo.setGnrYn("N");
		String seqNo = dao.insertRpotRqst(vo);
		String [] conditionList = vo.getConditionList();
		String [] outputDataList = vo.getOutputDataList();
		vo.setSeqNo(seqNo);
		if(conditionList != null && conditionList.length > 0){
			ArrayList<FlxbRpotVO> array = addRpotRqst(vo, conditionList);
			if(array != null && !array.isEmpty()){
				FlxbRpotVO vos = null;
				for(int i = 0; i < array.size(); i++){
					vos = array.get(i);
					dao.insertRpotCon(vos);
				}
			}
		}
		if(outputDataList != null && outputDataList.length > 0){
			FlxbRpotVO vos = null;
			for(int i = 0; i < outputDataList.length; i++){
				vos = new FlxbRpotVO();
				vos.setSeqNo(vo.getSeqNo());
				vos.setRpotItemCd(outputDataList[i]);
				vos.setUserId(vo.getUserId());
				dao.insertRpotItem(vos);
			}
		}
	}
	
	
	/**
	 * Biz-method for registering request of flexible report. <br>
	 * 
	 * @param String array
	 * @return  void
	 * @exception Exception
	 */
	public ArrayList<FlxbRpotVO> addRpotRqst(FlxbRpotVO vo, String [] list) throws Exception {
		ArrayList<FlxbRpotVO> array = null;
		if(vo != null && list != null){
			FlxbRpotVO vos = null;
			String cndObj = null;
			String cnd1 = null;
			String cnd2 = null;
			String cnd3 = null;
			array = new ArrayList<FlxbRpotVO>();
			for(int i = 0; i < list.length; i++){
				cndObj = list[i];
				cnd1 = "";
				cnd2 = "";
				cnd3 = "";
				if("1".equals(cndObj)){
					cnd1 = vo.getGivNm();
				}else if("2".equals(cndObj)){
					cnd1 = vo.getSurnm();
				}else if("3".equals(cndObj)){
					cnd1 = vo.getCurtAdDiv();
					String cd = "";
					if(cnd1 != null && "N".equals(cnd1)){
						cd = vo.getCurtAdCd();
					}else if(cnd1 != null && "Y".equals(cnd1)){
						cd = vo.getCurtAdNatCd();
					}
					cnd2 = cd;
				}else if("4".equals(cndObj)){
					cnd1 = vo.getBthDd();
					cnd2 = vo.getBthDd2();
					cnd3 = vo.getCalTye();
				}else if("5".equals(cndObj)){
					cnd1 = vo.getGdrCd();
				}else if("6".equals(cndObj)){
					cnd1 = vo.getFthrNm();
				}else if("7".equals(cndObj)){
					cnd1 = vo.getGfthrNm();
				}else if("8".equals(cndObj)){
					cnd1 = vo.getPmntAdCd();
				}else if("9".equals(cndObj)){
					cnd1 = vo.getBthNatDiv();
					String cd = "";
					if(cnd1 != null && "N".equals(cnd1)){
						cd = vo.getBthPlceCd();
					}else if(cnd1 != null && "Y".equals(cnd1)){
						cd = vo.getBthNatCd();
					}
					cnd2 = cd;
				}else if("10".equals(cndObj)){
					cnd1 = vo.getWtrRsdcCd();
				}else if("11".equals(cndObj)){
					cnd1 = vo.getSmrRsdcCd();
				}else if("12".equals(cndObj)){
					cnd1 = vo.getCrdIsucePlceCd();
				}else if("13".equals(cndObj)){
					cnd1 = vo.getOldCrdIsucePlceCd();
				}else if("14".equals(cndObj)){
					cnd1 = vo.getEduYn();
					cnd2 = vo.getEduCd();
					cnd3 = vo.getEduLvDocYn();
					if(cnd2 != null && !"".equals(cnd2) && cnd3 == null){
						cnd3 = "N";
					}
				}else if("15".equals(cndObj)){
					cnd1 = vo.getBldTyeCd();
					cnd2 = vo.getBldTyeDocYn();
					if(cnd2 == null){
						cnd2 = "N";
					}
				}else if("16".equals(cndObj)){
					cnd1 = vo.getMrrgCd();
				}else if("17".equals(cndObj)){
					cnd1 = vo.getFmlyLangCd();
				}else if("18".equals(cndObj)){
					cnd1 = vo.getOthrNatLangCd();
				}else if("19".equals(cndObj)){
					cnd1 = vo.getFrgnLangCd();
				}else if("20".equals(cndObj)){
					cnd1 = vo.getRlgnCd();
				}else if("21".equals(cndObj)){
					cnd1 = vo.getRlgnSectCd();
				}else if("22".equals(cndObj)){
					cnd1 = vo.getEncyCd();
				}else if("23".equals(cndObj)){
					cnd1 = vo.getDsbtCd();
				}else if("24".equals(cndObj)){
					cnd1 = vo.getMltSrvcCd();
					if(cnd1 == null){
						cnd1 = "";
					}
				}else if("25".equals(cndObj)){
					cnd1 = vo.getSecdNltyYn();
					cnd2 = vo.getSecdNltyCd();
				}else if("26".equals(cndObj)){
					cnd1 = vo.getPoliCntrSeqNo();
				}else if("27".equals(cndObj)){
					cnd1 = vo.getRsdtStusCd();
				}
				vos = new FlxbRpotVO();
				vos.setSeqNo(vo.getSeqNo());
				vos.setRpotCndCd(cndObj);
				vos.setCnd1(cnd1);
				vos.setCnd2(cnd2);
				vos.setCnd3(cnd3);
				vos.setUserId(vo.getUserId());
				array.add(vos);
			}
		}
		return array;
	}
	
	
	/**
	 * Biz-method for retrieving condition of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving condition of Flexible Report(FlxbRpotVO).
	 * @return List Retrieve condition of Flexible Report
	 * @exception Exception
	 */
	public List<FlxbRpotVO> searchListRpotCnd(FlxbRpotVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());			
		return dao.selectListRpotCnd(vo);
	}
	
	/**
	 * Biz-method for retrieving output items of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving output items of Flexible Report(FlxbRpotVO).
	 * @return List Retrieve output items of Flexible Report
	 * @exception Exception
	 */
	public List<FlxbRpotVO> searchListRpotItem(FlxbRpotVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());			
		return dao.selectListRpotItem(vo);
	}
	
	/**
	 * Biz-method for retrieving item width of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving item width of Flexible Report(FlxbRpotVO).
	 * @return List Retrieve item width of Flexible Report
	 * @exception Exception
	 */
	public List<FlxbRpotVO> searchListRpotItemWdth(FlxbRpotVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());			
		return dao.selectListRpotItemWdth(vo);
	}
	
	/**
	 * Biz-method for retrieving total width of Flexible Report items. <br>
	 * 
	 * @param vo Input item for retrieving total width of Flexible Report items(FlxbRpotVO).
	 * @return String Retrieve total width of Flexible Report items
	 * @exception Exception
	 */
	public String searchRpotItemTotWdth(FlxbRpotVO vo) throws Exception {		
		return dao.selectRpotItemTotWdth(vo);
	}
	
	/**
	 * Biz-method for retrieving Result of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving Result of Flexible Report(FlxbRpotVO).
	 * @return List Retrieve Result of Flexible Report
	 * @exception Exception
	 */
	public List<FlxbRpotVO> searchListRpotRust(FlxbRpotVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());			
		return dao.selectListRpotRust(vo);
	}
	
	/**
	 * Biz-method for retrieving other language of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving other language of Flexible Report(FlxbRpotVO).
	 * @return List Retrieve other language of Flexible Report
	 * @exception Exception
	 */
	public List<FlxbRpotVO> searchListRpotRustOthrLang(FlxbRpotVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());			
		return dao.selectListRpotRustOthrLang(vo);
	}
	
	/**
	 * Biz-method for retrieving foreign language of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving foreign language of Flexible Report(FlxbRpotVO).
	 * @return List Retrieve foreign language of Flexible Report
	 * @exception Exception
	 */
	public List<FlxbRpotVO> searchListRpotRustFrgnLang(FlxbRpotVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());			
		return dao.selectListRpotRustFrgnLang(vo);
	}
	
	
	/**
	 * Biz-method for retrieving total count Result of Flexible Report. <br>
	 * 
	 * @param vo Input item for retrieving total count rResult of Flexible Report(FlxbRpotVO).
	 * @return int Total Count of flexible report result list
	 * @exception Exception
	 */
	public int searchListRpotRustTotCn(FlxbRpotVO vo) throws Exception {		       
		return dao.selectListRpotRustTotCn(vo);
	} 

	/**
	 * Biz-method for retrieving date of generation. <br>
	 * 
	 * @param vo Input item for retrieving date of generation(FlxbRpotVO).
	 * @return String date of generation
	 * @exception Exception
	 */
	public String searchGnrTime(FlxbRpotVO vo) throws Exception {		
		return dao.selectGnrTime(vo);
	}	
	
	/**
	 * Biz-method for registering request of flexible report. <br>
	 * 
	 * @param vo Input item for registering request of flexible report(FlxbRpotVO).
	 * @return  void
	 * @exception Exception
	 */
	public void addRsdtInfrLog(FlxbRpotVO vo) throws Exception {
		rsdtInfrLgService.addRsdtInfrLg(vo.getRsdtNo(),"28");
	}	
}
