package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsPpltMrrgVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String crnDd;
	private String age100NCnt;
	private String age100YCnt;
	private String age100WCnt;
	private String age100DCnt;
	private String age90NCnt; 
	private String age90YCnt; 
	private String age90WCnt;
	private String age90DCnt;	
	private String age80NCnt; 
	private String age80YCnt; 
	private String age80WCnt;
	private String age80DCnt;		
	private String age70NCnt; 
	private String age70WCnt;
	private String age70DCnt;		
	private String age70YCnt; 
	private String age60NCnt; 
	private String age60YCnt; 
	private String age60WCnt;
	private String age60DCnt;		
	private String age50NCnt; 
	private String age50YCnt; 
	private String age50WCnt;
	private String age50DCnt;		
	private String age40NCnt; 
	private String age40YCnt; 
	private String age40WCnt;
	private String age40DCnt;		
	private String age30NCnt; 
	private String age30YCnt; 
	private String age30WCnt;
	private String age30DCnt;		
	private String age20NCnt; 
	private String age20YCnt; 
	private String age20WCnt;
	private String age20DCnt;		
	private String age10NCnt; 
	private String age10YCnt;
	private String age10WCnt;
	private String age10DCnt;		
	private String age00NCnt; 
	private String age00YCnt; 
	private String age00WCnt;
	private String age00DCnt;		
	private String dstrNm;
	private String prvicNm;
	private String curtAdCd;
	private String stsTitCd;
	private String stsTitNm;
	private String adCd;
	private String adCdNm;	
	
	private String age100NoneCnt;
	private String age90NoneCnt;
	private String age80NoneCnt;
	private String age70NoneCnt;
	private String age60NoneCnt;
	private String age50NoneCnt;
	private String age40NoneCnt;
	private String age30NoneCnt;
	private String age20NoneCnt;
	private String age10NoneCnt;
	private String age00NoneCnt;
	
	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	public String getAge100NCnt() {
		return age100NCnt;
	}
	public void setAge100NCnt(String age100nCnt) {
		age100NCnt = age100nCnt;
	}
	public String getAge100YCnt() {
		return age100YCnt;
	}
	public void setAge100YCnt(String age100yCnt) {
		age100YCnt = age100yCnt;
	}
	public String getAge90NCnt() {
		return age90NCnt;
	}
	public void setAge90NCnt(String age90nCnt) {
		age90NCnt = age90nCnt;
	}
	public String getAge90YCnt() {
		return age90YCnt;
	}
	public void setAge90YCnt(String age90yCnt) {
		age90YCnt = age90yCnt;
	}
	public String getAge80NCnt() {
		return age80NCnt;
	}
	public void setAge80NCnt(String age80nCnt) {
		age80NCnt = age80nCnt;
	}
	public String getAge80YCnt() {
		return age80YCnt;
	}
	public void setAge80YCnt(String age80yCnt) {
		age80YCnt = age80yCnt;
	}
	public String getAge70NCnt() {
		return age70NCnt;
	}
	public void setAge70NCnt(String age70nCnt) {
		age70NCnt = age70nCnt;
	}
	public String getAge70YCnt() {
		return age70YCnt;
	}
	public void setAge70YCnt(String age70yCnt) {
		age70YCnt = age70yCnt;
	}
	public String getAge60NCnt() {
		return age60NCnt;
	}
	public void setAge60NCnt(String age60nCnt) {
		age60NCnt = age60nCnt;
	}
	public String getAge60YCnt() {
		return age60YCnt;
	}
	public void setAge60YCnt(String age60yCnt) {
		age60YCnt = age60yCnt;
	}
	public String getAge50NCnt() {
		return age50NCnt;
	}
	public void setAge50NCnt(String age50nCnt) {
		age50NCnt = age50nCnt;
	}
	public String getAge50YCnt() {
		return age50YCnt;
	}
	public void setAge50YCnt(String age50yCnt) {
		age50YCnt = age50yCnt;
	}
	public String getAge40NCnt() {
		return age40NCnt;
	}
	public void setAge40NCnt(String age40nCnt) {
		age40NCnt = age40nCnt;
	}
	public String getAge40YCnt() {
		return age40YCnt;
	}
	public void setAge40YCnt(String age40yCnt) {
		age40YCnt = age40yCnt;
	}
	public String getAge30NCnt() {
		return age30NCnt;
	}
	public void setAge30NCnt(String age30nCnt) {
		age30NCnt = age30nCnt;
	}
	public String getAge30YCnt() {
		return age30YCnt;
	}
	public void setAge30YCnt(String age30yCnt) {
		age30YCnt = age30yCnt;
	}
	public String getAge20NCnt() {
		return age20NCnt;
	}
	public void setAge20NCnt(String age20nCnt) {
		age20NCnt = age20nCnt;
	}
	public String getAge20YCnt() {
		return age20YCnt;
	}
	public void setAge20YCnt(String age20yCnt) {
		age20YCnt = age20yCnt;
	}
	public String getAge10NCnt() {
		return age10NCnt;
	}
	public void setAge10NCnt(String age10nCnt) {
		age10NCnt = age10nCnt;
	}
	public String getAge10YCnt() {
		return age10YCnt;
	}
	public void setAge10YCnt(String age10yCnt) {
		age10YCnt = age10yCnt;
	}
	public String getAge00NCnt() {
		return age00NCnt;
	}
	public void setAge00NCnt(String age00nCnt) {
		age00NCnt = age00nCnt;
	}
	public String getAge00YCnt() {
		return age00YCnt;
	}
	public void setAge00YCnt(String age00yCnt) {
		age00YCnt = age00yCnt;
	}
	public String getDstrNm() {
		return dstrNm;
	}
	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}
	public String getPrvicNm() {
		return prvicNm;
	}
	public void setPrvicNm(String prvicNm) {
		this.prvicNm = prvicNm;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getStsTitCd() {
		return stsTitCd;
	}
	public void setStsTitCd(String stsTitCd) {
		this.stsTitCd = stsTitCd;
	}
	public String getStsTitNm() {
		return stsTitNm;
	}
	public void setStsTitNm(String stsTitNm) {
		this.stsTitNm = stsTitNm;
	}
	public String getAge100WCnt() {
		return age100WCnt;
	}
	public void setAge100WCnt(String age100wCnt) {
		age100WCnt = age100wCnt;
	}
	public String getAge100DCnt() {
		return age100DCnt;
	}
	public void setAge100DCnt(String age100dCnt) {
		age100DCnt = age100dCnt;
	}
	public String getAge90WCnt() {
		return age90WCnt;
	}
	public void setAge90WCnt(String age90wCnt) {
		age90WCnt = age90wCnt;
	}
	public String getAge90DCnt() {
		return age90DCnt;
	}
	public void setAge90DCnt(String age90dCnt) {
		age90DCnt = age90dCnt;
	}
	public String getAge80WCnt() {
		return age80WCnt;
	}
	public void setAge80WCnt(String age80wCnt) {
		age80WCnt = age80wCnt;
	}
	public String getAge80DCnt() {
		return age80DCnt;
	}
	public void setAge80DCnt(String age80dCnt) {
		age80DCnt = age80dCnt;
	}
	public String getAge70WCnt() {
		return age70WCnt;
	}
	public void setAge70WCnt(String age70wCnt) {
		age70WCnt = age70wCnt;
	}
	public String getAge70DCnt() {
		return age70DCnt;
	}
	public void setAge70DCnt(String age70dCnt) {
		age70DCnt = age70dCnt;
	}
	public String getAge60WCnt() {
		return age60WCnt;
	}
	public void setAge60WCnt(String age60wCnt) {
		age60WCnt = age60wCnt;
	}
	public String getAge60DCnt() {
		return age60DCnt;
	}
	public void setAge60DCnt(String age60dCnt) {
		age60DCnt = age60dCnt;
	}
	public String getAge50WCnt() {
		return age50WCnt;
	}
	public void setAge50WCnt(String age50wCnt) {
		age50WCnt = age50wCnt;
	}
	public String getAge50DCnt() {
		return age50DCnt;
	}
	public void setAge50DCnt(String age50dCnt) {
		age50DCnt = age50dCnt;
	}
	public String getAge40WCnt() {
		return age40WCnt;
	}
	public void setAge40WCnt(String age40wCnt) {
		age40WCnt = age40wCnt;
	}
	public String getAge40DCnt() {
		return age40DCnt;
	}
	public void setAge40DCnt(String age40dCnt) {
		age40DCnt = age40dCnt;
	}
	public String getAge30WCnt() {
		return age30WCnt;
	}
	public void setAge30WCnt(String age30wCnt) {
		age30WCnt = age30wCnt;
	}
	public String getAge30DCnt() {
		return age30DCnt;
	}
	public void setAge30DCnt(String age30dCnt) {
		age30DCnt = age30dCnt;
	}
	public String getAge20WCnt() {
		return age20WCnt;
	}
	public void setAge20WCnt(String age20wCnt) {
		age20WCnt = age20wCnt;
	}
	public String getAge20DCnt() {
		return age20DCnt;
	}
	public void setAge20DCnt(String age20dCnt) {
		age20DCnt = age20dCnt;
	}
	public String getAge10WCnt() {
		return age10WCnt;
	}
	public void setAge10WCnt(String age10wCnt) {
		age10WCnt = age10wCnt;
	}
	public String getAge10DCnt() {
		return age10DCnt;
	}
	public void setAge10DCnt(String age10dCnt) {
		age10DCnt = age10dCnt;
	}
	public String getAge00WCnt() {
		return age00WCnt;
	}
	public void setAge00WCnt(String age00wCnt) {
		age00WCnt = age00wCnt;
	}
	public String getAge00DCnt() {
		return age00DCnt;
	}
	public void setAge00DCnt(String age00dCnt) {
		age00DCnt = age00dCnt;
	}
	public String getAdCd() {
		return adCd;
	}
	public void setAdCd(String adCd) {
		this.adCd = adCd;
	}
	public String getAdCdNm() {
		return adCdNm;
	}
	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}
	public String getAge100NoneCnt() {
		return age100NoneCnt;
	}
	public void setAge100NoneCnt(String age100NoneCnt) {
		this.age100NoneCnt = age100NoneCnt;
	}
	public String getAge90NoneCnt() {
		return age90NoneCnt;
	}
	public void setAge90NoneCnt(String age90NoneCnt) {
		this.age90NoneCnt = age90NoneCnt;
	}
	public String getAge80NoneCnt() {
		return age80NoneCnt;
	}
	public void setAge80NoneCnt(String age80NoneCnt) {
		this.age80NoneCnt = age80NoneCnt;
	}
	public String getAge70NoneCnt() {
		return age70NoneCnt;
	}
	public void setAge70NoneCnt(String age70NoneCnt) {
		this.age70NoneCnt = age70NoneCnt;
	}
	public String getAge60NoneCnt() {
		return age60NoneCnt;
	}
	public void setAge60NoneCnt(String age60NoneCnt) {
		this.age60NoneCnt = age60NoneCnt;
	}
	public String getAge50NoneCnt() {
		return age50NoneCnt;
	}
	public void setAge50NoneCnt(String age50NoneCnt) {
		this.age50NoneCnt = age50NoneCnt;
	}
	public String getAge40NoneCnt() {
		return age40NoneCnt;
	}
	public void setAge40NoneCnt(String age40NoneCnt) {
		this.age40NoneCnt = age40NoneCnt;
	}
	public String getAge30NoneCnt() {
		return age30NoneCnt;
	}
	public void setAge30NoneCnt(String age30NoneCnt) {
		this.age30NoneCnt = age30NoneCnt;
	}

	public String getAge20NoneCnt() {
		return age20NoneCnt;
	}
	public void setAge20NoneCnt(String age20NoneCnt) {
		this.age20NoneCnt = age20NoneCnt;
	}
	public String getAge10NoneCnt() {
		return age10NoneCnt;
	}
	public void setAge10NoneCnt(String age10NoneCnt) {
		this.age10NoneCnt = age10NoneCnt;
	}
	public String getAge00NoneCnt() {
		return age00NoneCnt;
	}
	public void setAge00NoneCnt(String age00NoneCnt) {
		this.age00NoneCnt = age00NoneCnt;
	}

}
