package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsBsnWrkStusVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String curtAdCd ;
	private String prvicNm  ;
	private String dstrNm;
	private String tamNm ;
	private String fmlyBokCn;
	private String fmlyMberCn;
	private String rgstMlCn ;
	private String rsgtFemlCn ;
	private String aprvMlCn ;
	private String aprvFemlCn ;	
	private String dptScsMlCn;
	private String dptScsFemlCn;	
	private String dptFailMlCn;
	private String dptFailFemlCn;
	private String crdIsuceRqstMlCn;
	private String crdIsuceRqstFemlCn;
	private String crdIsuceScsMlCn;
	private String crdIsuceScsFemlCn;
	private String crdIsuceFailMlCn;
	private String crdIsuceFailFemlCn;
	private String crdDitbMlCn;	
	private String crdDitbFemlCn;	
	private int listCn;
	private String officerNo;
	private String orgnzClsCd ;
	private String orgnzCd ;		  
	private String teamCd ;
	private String rgstDd ;
	private String stsTitCd;
	private String stsTitNm;
	private String ofcalPsnCd;
	private String orgnzNm;
	private String prod;
	
	private String hStDd;
	private String hEndDd;
	private String gStDd;
	private String gEndDd;
	private String roleNm;	
	private String aprvCn;		
	private String rgstCn;
	private String rgstBioCn;
	private String userNm;
	private String ddItv;
	private String prePageIndex;
	private String oficTye;
	private String hldayYn;
	private String crdArvlMlCn;	
	private String crdArvlFemlCn;
	
	public String getOficTye() {
		return oficTye;
	}
	public void setOficTye(String oficTye) {
		this.oficTye = oficTye;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getPrvicNm() {
		return prvicNm;
	}
	public void setPrvicNm(String prvicNm) {
		this.prvicNm = prvicNm;
	}
	public String getDstrNm() {
		return dstrNm;
	}
	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}
	public String getTamNm() {
		return tamNm;
	}
	public void setTamNm(String tamNm) {
		this.tamNm = tamNm;
	}
	public String getFmlyBokCn() {
		return fmlyBokCn;
	}
	public void setFmlyBokCn(String fmlyBokCn) {
		this.fmlyBokCn = fmlyBokCn;
	}
	
	public String getFmlyMberCn() {
		return fmlyMberCn;
	}
	public void setFmlyMberCn(String fmlyMberCn) {
		this.fmlyMberCn = fmlyMberCn;
	}
	public String getRgstMlCn() {
		return rgstMlCn;
	}
	public void setRgstMlCn(String rgstMlCn) {
		this.rgstMlCn = rgstMlCn;
	}
	public String getRsgtFemlCn() {
		return rsgtFemlCn;
	}
	public void setRsgtFemlCn(String rsgtFemlCn) {
		this.rsgtFemlCn = rsgtFemlCn;
	}
	public String getAprvMlCn() {
		return aprvMlCn;
	}
	public void setAprvMlCn(String aprvMlCn) {
		this.aprvMlCn = aprvMlCn;
	}
	public String getAprvFemlCn() {
		return aprvFemlCn;
	}
	public void setAprvFemlCn(String aprvFemlCn) {
		this.aprvFemlCn = aprvFemlCn;
	}
	public String getDptScsMlCn() {
		return dptScsMlCn;
	}
	public void setDptScsMlCn(String dptScsMlCn) {
		this.dptScsMlCn = dptScsMlCn;
	}
	public String getDptScsFemlCn() {
		return dptScsFemlCn;
	}
	public void setDptScsFemlCn(String dptScsFemlCn) {
		this.dptScsFemlCn = dptScsFemlCn;
	}
	public String getDptFailMlCn() {
		return dptFailMlCn;
	}
	public void setDptFailMlCn(String dptFailMlCn) {
		this.dptFailMlCn = dptFailMlCn;
	}
	public String getDptFailFemlCn() {
		return dptFailFemlCn;
	}
	public void setDptFailFemlCn(String dptFailFemlCn) {
		this.dptFailFemlCn = dptFailFemlCn;
	}
	public String getCrdIsuceRqstMlCn() {
		return crdIsuceRqstMlCn;
	}
	public void setCrdIsuceRqstMlCn(String crdIsuceRqstMlCn) {
		this.crdIsuceRqstMlCn = crdIsuceRqstMlCn;
	}
	public String getCrdIsuceRqstFemlCn() {
		return crdIsuceRqstFemlCn;
	}
	public void setCrdIsuceRqstFemlCn(String crdIsuceRqstFemlCn) {
		this.crdIsuceRqstFemlCn = crdIsuceRqstFemlCn;
	}
	public String getCrdIsuceScsMlCn() {
		return crdIsuceScsMlCn;
	}
	public void setCrdIsuceScsMlCn(String crdIsuceScsMlCn) {
		this.crdIsuceScsMlCn = crdIsuceScsMlCn;
	}
	public String getCrdIsuceScsFemlCn() {
		return crdIsuceScsFemlCn;
	}
	public void setCrdIsuceScsFemlCn(String crdIsuceScsFemlCn) {
		this.crdIsuceScsFemlCn = crdIsuceScsFemlCn;
	}
	public String getCrdIsuceFailMlCn() {
		return crdIsuceFailMlCn;
	}
	public void setCrdIsuceFailMlCn(String crdIsuceFailMlCn) {
		this.crdIsuceFailMlCn = crdIsuceFailMlCn;
	}
	public String getCrdIsuceFailFemlCn() {
		return crdIsuceFailFemlCn;
	}
	public void setCrdIsuceFailFemlCn(String crdIsuceFailFemlCn) {
		this.crdIsuceFailFemlCn = crdIsuceFailFemlCn;
	}
	public String getCrdDitbMlCn() {
		return crdDitbMlCn;
	}
	public void setCrdDitbMlCn(String crdDitbMlCn) {
		this.crdDitbMlCn = crdDitbMlCn;
	}
	public String getCrdDitbFemlCn() {
		return crdDitbFemlCn;
	}
	public void setCrdDitbFemlCn(String crdDitbFemlCn) {
		this.crdDitbFemlCn = crdDitbFemlCn;
	}
	public int getListCn() {
		return listCn;
	}
	public void setListCn(int listCn) {
		this.listCn = listCn;
	}
	public String getOfficerNo() {
		return officerNo;
	}
	public void setOfficerNo(String officerNo) {
		this.officerNo = officerNo;
	}
	public String getOrgnzClsCd() {
		return orgnzClsCd;
	}
	public void setOrgnzClsCd(String orgnzClsCd) {
		this.orgnzClsCd = orgnzClsCd;
	}
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String getTeamCd() {
		return teamCd;
	}
	public void setTeamCd(String teamCd) {
		this.teamCd = teamCd;
	}
	public String getRgstDd() {
		return rgstDd;
	}
	public void setRgstDd(String rgstDd) {
		this.rgstDd = rgstDd;
	}
	public String getStsTitCd() {
		return stsTitCd;
	}
	public void setStsTitCd(String stsTitCd) {
		this.stsTitCd = stsTitCd;
	}
	public String getStsTitNm() {
		return stsTitNm;
	}
	public void setStsTitNm(String stsTitNm) {
		this.stsTitNm = stsTitNm;
	}
	public String getOfcalPsnCd() {
		return ofcalPsnCd;
	}
	public void setOfcalPsnCd(String ofcalPsnCd) {
		this.ofcalPsnCd = ofcalPsnCd;
	}
	public String getOrgnzNm() {
		return orgnzNm;
	}
	public void setOrgnzNm(String orgnzNm) {
		this.orgnzNm = orgnzNm;
	}
	public String getProd() {
		return prod;
	}
	public void setProd(String prod) {
		this.prod = prod;
	}
	public String gethStDd() {
		return hStDd;
	}
	public void sethStDd(String hStDd) {
		this.hStDd = hStDd;
	}
	public String gethEndDd() {
		return hEndDd;
	}
	public void sethEndDd(String hEndDd) {
		this.hEndDd = hEndDd;
	}
	public String getgStDd() {
		return gStDd;
	}
	public void setgStDd(String gStDd) {
		this.gStDd = gStDd;
	}
	public String getgEndDd() {
		return gEndDd;
	}
	public void setgEndDd(String gEndDd) {
		this.gEndDd = gEndDd;
	}
	public String getRoleNm() {
		return roleNm;
	}
	public void setRoleNm(String roleNm) {
		this.roleNm = roleNm;
	}
	public String getAprvCn() {
		return aprvCn;
	}
	public void setAprvCn(String aprvCn) {
		this.aprvCn = aprvCn;
	}
	public String getRgstCn() {
		return rgstCn;
	}
	public void setRgstCn(String rgstCn) {
		this.rgstCn = rgstCn;
	}
	public String getRgstBioCn() {
		return rgstBioCn;
	}
	public void setRgstBioCn(String rgstBioCn) {
		this.rgstBioCn = rgstBioCn;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getDdItv() {
		return ddItv;
	}
	public void setDdItv(String ddItv) {
		this.ddItv = ddItv;
	}

	public String getPrePageIndex() {
		return prePageIndex;
	}
	public void setPrePageIndex(String prePageIndex) {
		this.prePageIndex = prePageIndex;
	}
	public String getHldayYn() {
		return hldayYn;
	}
	public void setHldayYn(String hldayYn) {
		this.hldayYn = hldayYn;
	}
	public String getCrdArvlMlCn() {
		return crdArvlMlCn;
	}
	public void setCrdArvlMlCn(String crdArvlMlCn) {
		this.crdArvlMlCn = crdArvlMlCn;
	}
	public String getCrdArvlFemlCn() {
		return crdArvlFemlCn;
	}
	public void setCrdArvlFemlCn(String crdArvlFemlCn) {
		this.crdArvlFemlCn = crdArvlFemlCn;
	}

}
