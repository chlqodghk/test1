package afnid.rm.sts.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service interface is biz-class of region. <br>
 * 
 * @author Afghanistan National ID RM Application Moon Soo Kim
 * @since 2013.05.23
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.05.23  		Moon Soo Kim		                    Create
 *
 * </pre>
 */

public interface StsService {
	
	
	/**
	 * Retrieves  Statistic Creation Date. <br>
	 *
	 * @param vo Input item for retrieving Statistic Creation Date(ymd).
	 * @return List Retrieve Statistic Creation Date
	 * @exception Exception
	 */
	List<StsSrchVO> searchListStsCreYmd(String ymd) throws Exception;
	
	/**
	 * Check of StatisticCreation<br>
	 *
	 * @param String Input Statistic Creation  (Yy).
	 * @return result of Statistic Creation
	 * @exception Exception
	 */
	int searchStsChkCn(String  Yy) throws Exception;
	
	
	/**
	 * Irregular Population Statistic Creation (nonscheduled)<br>
	 *
	 * @param N/A
	 * @return void
	 * @exception Exception
	 */
	void addNonScdlStsGnr() throws Exception;
	
	/**
	 * Regular Population Statistic Creation (scheduled)<br>
	 *
	 * @param N/A
	 * @return void
	 * @exception Exception
	 */
	void addScdlStsGnr() throws Exception;
	
	/**
	 * Retrieves Year. <br>
	 *
	 * @param vo Input item for get Year (StsSrchVO).
	 * @return String Year
	 * @exception Exception
	 */
	String searchStsYear(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Population by Present Address. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Present Address(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Present Address
	 * @exception Exception
	 */
	List<StsPpltPrsAdVO> searchListStsPpltPrsAd(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Population by Permanent Address. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Permanent Address(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Permanent Address
	 * @exception Exception
	 */
	List<StsPpltPmntAdVO> searchListStsPpltPmntAd(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Population by Birth Place. <br>
	 *
	 * @param vo Input item for retrieving  Statistic of Population by Birth Place(StsSrchVO).
	 * @return List Retrieve  Statistic of Population by Birth Place
	 * @exception Exception
	 */
	List<StsPpltBthPlceVO> searchListStsPpltBthPlce(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Population by Age. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Age(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Age
	 * @exception Exception
	 */
	List<StsPpltAgeVO> searchListStsPpltAge(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Population by Education Level. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Education Level(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Education Level
	 * @exception Exception
	 */
	List<StsPpltEduVO> searchListStsPpltEdu(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Population by Religion & Sect. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Religion & Sect(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Religion & Sect
	 * @exception Exception
	 */
	List<StsPpltRignSectVO> searchListStsPpltRignSect(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Population by Mother Tongue. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Mother Tongue(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Mother Tongue
	 * @exception Exception
	 */
	List<StsPpltMthrTguVO> searchListStsPpltMthrTgu(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Population by Ethnicity. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Ethnicity(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Ethnicity
	 * @exception Exception
	 */
	List<StsPpltEncyVO> searchListStsPpltEncy(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Population by Marital Status. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Marital Status(RsdtInfoVO).
	 * @return List Retrieve Statistic of Population by Marital Status
	 * @exception Exception
	 */
	List<StsPpltMrrgVO> searchListStsPpltMrrg(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Population by Residence for Kochi. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Residence for Kochi(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Residence for Kochi
	 * @exception Exception
	 */
	List<StsRsdcKchiVO> searchListStsRsdcKchi(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Population by Second Nationality . <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Second Nationality (RsdtInfoVO).
	 * @return List Retrieve Statistic of Population by Second Nationality 
	 * @exception Exception
	 */
	List<StsSecdNltyVO> searchListStsSecdNlty(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Population by Polling Station. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Polling Station(StsSrchVO).
	 * @return List Retrieve Statistic of Population by Polling Station
	 * @exception Exception
	 */
	List<StsPpltPoliStatVO> searchListStsPpltPoliStat(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Birth Rate. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Birth Rate(StsSrchVO).
	 * @return List Retrieve Statistic of Birth Rate
	 * @exception Exception
	 */
	List<StsBthRtVO> searchListStsBthRt(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Death Rate. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Death Rate(StsSrchVO).
	 * @return List Retrieve Statistic of Death Rate
	 * @exception Exception
	 */
	List<StsDthRtVO> searchListStsDthRt(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Death Rate By age. <br>
	 *
	 * @param vo Input item for retrieving list of program(StsSrchVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<StsDthRtAgeVO> searchListStsDthRtAge(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves Statistic of Life Expectancy for School Age Children. <br>
	 * Statistic of Life Expectancy for School Age Children
	 * @param vo Input item for retrieving  Statistic of Life Expectancy for School Age Children(StsSrchVO).
	 * @return List  Statistic of Life Expectancy for School Age Children.
	 * @exception Exception
	 */
	List<StsEpctSchAgVO> searchListStsEpctSchAge(StsSrchVO vo) throws Exception;	
	
	/**
	 * Retrieves Statistic of Voters by Present Address. <br>
	 * Statistic of Voters by Present Address
	 * @param vo Input item for retrieving  Statistic of Voters by Present Address(StsSrchVO).
	 * @return List  Statistic of Voters by Present Address
	 * @exception Exception
	 */
	List<StsVtrPrsAdVO> searchListStsVtrPrsAd(StsSrchVO vo) throws Exception;
	
	/**
	 * Retrieves list of program for Province Name. <br>
	 *
	 * @param vo Input item for retrieving Province Name().
	 * @return List Retrieve Province Name
	 * @exception Exception
	 */
	List<StsSecdNltyVO> searchListPrvic(StsSrchVO vo) throws Exception;		

	/**
	 * Retrieves list of program for Province Name. <br>
	 *
	 * @param vo Input item for retrieving Province Name().
	 * @return List Retrieve Province Name
	 * @exception Exception
	 */
	String  searchStsTitle(StsSrchVO vo) throws Exception;	
	
	
	/**
	 * Statistics Creation  Of daily Registration Status<br>
	 *
	 * @param N/A
	 * @return void
	 * @exception Exception
	 */
	void stsGnrRsdtRgstStus() throws Exception;
	
	
	/**
	 * retrieving Statistic of Resident Registration Status. <br>	 
	 *
	 * @param vo Input item for retrieving list of program(StsRgstStusVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<StsRgstStusVO> searchListRsdtRgstStusInfr(StsRgstStusVO vo) throws Exception;


	/**
	 * retrieving total count  of  Resident Registration Status list. <br>
	 * @param vo Input item for retrieving total count list of program.(StsRgstStusVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListRsdtRgstStusInfrTotCn(StsRgstStusVO vo) throws Exception;	
	
	
	/**
	 * retrieving Statistic of performance by offices. <br>	 
	 *
     * @param vo Input item for retrieving list of performance by office(StsBsnWrkStusVO).
     * @return List Retrieve list of performance by office
	 * @exception Exception
	 */
	List<StsBsnWrkStusVO> searchListBsnWrkStusInfr(StsBsnWrkStusVO vo) throws Exception;


	/**
	 * retrieving total count  of performance by office. <br>
	 * @param vo Input item for retrieving total count of performance by office(StsBsnWrkStusVO).
	 * @return int Total Count of total count of performance by office
	 * @exception Exception
	 */
	int searchListBsnWrkStusInfrTotCn(StsBsnWrkStusVO vo) throws Exception;	
	
	
	/**
	 * retrieving Statistic of performance by team. <br>	 
	 *
	 * @param vo Input item for retrieving list of performance by team(StsBsnWrkStusVO).
	 * @return List Retrieve list of performance by team
	 * @exception Exception
	 */
	List<StsBsnWrkStusVO> searchListTamBsnWrkStusInfr(StsBsnWrkStusVO vo) throws Exception;
	
	
	/**
	 * retrieving total count  of performance by team. <br>
	 * @param vo Input item for retrieving total count of performance by team(StsBsnWrkStusVO).
	 * @return int Total Count of total count of performance by team
	 * @exception Exception
	 */
	int searchListTamBsnWrkStusInfrTotCn(StsBsnWrkStusVO vo) throws Exception;	
	
	/**
	 * retrieving Statistic of performance by user. <br>	 
	 *
	 * @param vo Input item for retrieving list of performance by user(StsBsnWrkStusVO).
	 * @return List Retrieve list of performance by user
	 * @exception Exception
	 */
	List<StsBsnWrkStusVO> searchListUserBsnWrkStusInfr(StsBsnWrkStusVO vo) throws Exception;


	/**
	 * retrieving total count  of performance by user. <br>
	 * @param vo Input item for retrieving total count of performance by user(StsBsnWrkStusVO).
	 * @return int Total Count of total count of performance by user
	 * @exception Exception
	 */
	int searchListUserBsnWrkStusInfrTotCn(StsBsnWrkStusVO vo) throws Exception;
	
	
	/**
	 * Biz-method for adding the days to persian start day. <br>
	 * 
	 * @param vo Input item for adding the days to persian start day(StsBsnWrkStusVO).
	 * @return ComDefaultVO Adding the days to persian start day
	 * @exception Exception
	 */
	public String searchBsnWrkStusStartPreDay(StsBsnWrkStusVO vo) throws Exception;
	
	/**
	 * Biz-method for adding the days to persian last day. <br>
	 * 
	 * @param vo Input item for adding the days to persian last day(StsBsnWrkStusVO).
	 * @return ComDefaultVO Adding the days to persian last day
	 * @exception Exception
	 */
	public String searchBsnWrkStusEndPreDay(StsBsnWrkStusVO vo) throws Exception ;
	
	/**
	 * Biz-method for adding the days to Gregorian start day. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian start day(StsBsnWrkStusVO).
	 * @return ComDefaultVO Adding the days to Gregorian start day
	 * @exception Exception
	 */
	public String searchBsnWrkStusStartGreDay(StsBsnWrkStusVO vo) throws Exception;
	
	/**
	 * Biz-method for adding the days to Gregorian last day. <br>
	 * 
	 * @param vo Input item for adding the days to Gregorian last day(StsBsnWrkStusVO).
	 * @return ComDefaultVO Adding the days to Gregorian last day
	 * @exception Exception
	 */
	public String searchBsnWrkStusEndGreDay(StsBsnWrkStusVO vo) throws Exception ;
	
	/**
	 * check of the already requested Statistic
	 *
	 * @param String Input item for check of the already requested Statistic.
	 * @return int result of check of the already requested Statistic
	 * @exception Exception
	 */
	int searchRsdtStsRqstYn(String gCrnDd) throws Exception;
	
	
	/**
	 * request generation of population statistics <br>
	 *
	 * @param N/A
	 * @return void
	 * @exception Exception
	 */
	void addRsdtStsRqst(StsSrchVO vo) throws Exception;	
	
	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of statistic generation request(StsSrchVO).
	 * @return List Retrieve list of program
	 * @exception Exception 
	 */
	List<StsSrchVO> searchListRsdtStsRqst(StsSrchVO vo) throws Exception;
	
	/**
	 * Biz-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of statistic generation request(StsSrchVO).
	 * @return int Total Count of statistic generation request List
	 * @exception Exception 
	 */
    public int searchListRsdtStsRqstTotCn(StsSrchVO vo) throws Exception;	
    
    
    
    
    
    
    
    /**
	 * Retrieves Statistic of Population by Age. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Age(StsSrchVO).
	 * @return void
	 * @exception Exception
	 */
	void searchRmCurtAdStsTbSign(StsSrchVO vo) throws Exception;
	
	
	/**
	 * Retrieves Statistic of Population by Age. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Age(StsSrchVO).
	 * @return void
	 * @exception Exception
	 */
	void searchRmRlgnSectStsTbSign(StsSrchVO vo) throws Exception;
	
	
	/**
	 * Retrieves Statistic of Population by Age. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Age(StsSrchVO).
	 * @return void
	 * @exception Exception
	 */
	void searchRmEncyStsTbSign(StsSrchVO vo) throws Exception;
	
	
	
	/**
	 * Retrieves Statistic of Population by Age. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Age(StsSrchVO).
	 * @return void
	 * @exception Exception
	 */
	void searchRmPoliStatStsTbSign(StsSrchVO vo) throws Exception;
	
	
	
	
	/**
	 * Retrieves Statistic of Population by Age. <br>
	 *
	 * @param vo Input item for retrieving Statistic of Population by Age(StsSrchVO).
	 * @return void
	 * @exception Exception
	 */
	List<EgovMap> searchListRmEcptRsdtTbGb(StsSrchVO vo) throws Exception;
	
	
	
	
	/**
	 * retrieving Statistic of Resident Registration Status. <br>	 
	 *
	 * @param StsSrchVO
	 * @return List
	 * @exception Exception
	 */
	List<EgovMap> searchListStsEcptRsdt(StsSrchVO vo) throws Exception;


	/**
	 * retrieving total count  of  Resident Registration Status list. <br>
	 * @param StsSrchVO
	 * @return int
	 * @exception Exception
	 */
	int searchListStsEcptRsdtTotCn(StsSrchVO vo) throws Exception;	
	
}

