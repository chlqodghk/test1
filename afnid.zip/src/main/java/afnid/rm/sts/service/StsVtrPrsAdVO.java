package afnid.rm.sts.service;

import afnid.cm.ComDefaultVO;

public class StsVtrPrsAdVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String crnDd;
	private String dstrNm;   
	private String prvicNm;  
	private String curtAdCd;
	private String stsTitCd;
	private String stsTitNm;
	private String adCd;
	private String adCdNm;
	
	private String datCnMl1;
	private String datCnMl2;
	private String datCnMl3;
	private String datCnMl4;
	private String datCnFm1;
	private String datCnFm2;
	private String datCnFm3;
	private String datCnFm4;
	
	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	public String getDstrNm() {
		return dstrNm;
	}
	public void setDstrNm(String dstrNm) {
		this.dstrNm = dstrNm;
	}
	public String getPrvicNm() {
		return prvicNm;
	}
	public void setPrvicNm(String prvicNm) {
		this.prvicNm = prvicNm;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getStsTitCd() {
		return stsTitCd;
	}
	public void setStsTitCd(String stsTitCd) {
		this.stsTitCd = stsTitCd;
	}
	public String getStsTitNm() {
		return stsTitNm;
	}
	public void setStsTitNm(String stsTitNm) {
		this.stsTitNm = stsTitNm;
	}
	public String getAdCd() {
		return adCd;
	}
	public void setAdCd(String adCd) {
		this.adCd = adCd;
	}
	public String getAdCdNm() {
		return adCdNm;
	}
	public void setAdCdNm(String adCdNm) {
		this.adCdNm = adCdNm;
	}
	public String getDatCnMl1() {
		return datCnMl1;
	}
	public void setDatCnMl1(String datCnMl1) {
		this.datCnMl1 = datCnMl1;
	}
	public String getDatCnMl2() {
		return datCnMl2;
	}
	public void setDatCnMl2(String datCnMl2) {
		this.datCnMl2 = datCnMl2;
	}
	public String getDatCnMl3() {
		return datCnMl3;
	}
	public void setDatCnMl3(String datCnMl3) {
		this.datCnMl3 = datCnMl3;
	}
	public String getDatCnMl4() {
		return datCnMl4;
	}
	public void setDatCnMl4(String datCnMl4) {
		this.datCnMl4 = datCnMl4;
	}
	public String getDatCnFm1() {
		return datCnFm1;
	}
	public void setDatCnFm1(String datCnFm1) {
		this.datCnFm1 = datCnFm1;
	}
	public String getDatCnFm2() {
		return datCnFm2;
	}
	public void setDatCnFm2(String datCnFm2) {
		this.datCnFm2 = datCnFm2;
	}
	public String getDatCnFm3() {
		return datCnFm3;
	}
	public void setDatCnFm3(String datCnFm3) {
		this.datCnFm3 = datCnFm3;
	}
	public String getDatCnFm4() {
		return datCnFm4;
	}
	public void setDatCnFm4(String datCnFm4) {
		this.datCnFm4 = datCnFm4;
	}

}
