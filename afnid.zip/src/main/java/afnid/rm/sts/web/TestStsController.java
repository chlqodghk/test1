package afnid.rm.sts.web;

/* java API */

import java.io.Reader;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;

import javax.annotation.Resource;

import oracle.sql.CLOB;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import si.osi.dsig.XMLDsigValidate;
import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.psm.service.VtrListVO;
import afnid.cm.psm.service.impl.PollStaDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.sts.service.StsService;
import afnid.rm.sts.service.StsSrchVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;


/** 
 * This Controller class processes request of resident-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Moon Soo Kim
 * @since 22013.05.23
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.05.23  		Moon Soo Kim		                    Create
 *
 * </pre>
 */

@Controller
public class TestStsController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** NidProgrmManageService */
	@Resource(name = "stsService")
    private StsService service;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
	
	/** NidCommonService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCmmService;
	
	
	@Resource(name="pollStaDAO")
    private PollStaDAO pollStaDAO;
	
	
 	/**
     * Move to creation screen of Population Statistic. <br>
     *
     * @param CmCmmCdVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsGnrIns.jsp  "
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchTestStsGnr.do")
    public String  searchTestStsGnr(
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {    		
    	try {    	
    		service.addNonScdlStsGnr();
    		
    		ComDefaultVO vo = new ComDefaultVO();
    		vo = nidCmmService.searchGreAddToDay("-1"); 
    		
    		stsSrchVO.setSearchKeyword2(vo.getStartDay().replaceAll("-", ""));
    		stsSrchVO.setSearchKeyword3(vo.getEndDay().replaceAll("-", ""));
    		model.addAttribute("stsSrchVO", stsSrchVO);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 
    	return "/rm/sts/StsGnrIns";

    }
    
    
    /**
     * Move to creation screen of Population Statistic. <br>
     *
     * @param CmCmmCdVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsGnrIns.jsp  "
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchTestStsGnrSc.do")
    public String  searchTestStsGnrSc(
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {    		
    	try {    	
    		service.addScdlStsGnr();
    		
    		ComDefaultVO vo = new ComDefaultVO();
    		vo = nidCmmService.searchGreAddToDay("-1"); 
    		
    		stsSrchVO.setSearchKeyword2(vo.getStartDay().replaceAll("-", ""));
    		stsSrchVO.setSearchKeyword3(vo.getEndDay().replaceAll("-", ""));
    		model.addAttribute("stsSrchVO", stsSrchVO);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 
    	return "/rm/sts/StsGnrIns";

    }
    
    
    @RequestMapping(value="/rm/sts/searchTestStsSign.do")
    public String  searchTestStsSign(
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {    		
    	try {    	
    		Connection conn = null;
    		conn = DriverManager.getConnection("jdbc:oracle:thin:@202.167.222.226:1521:afnid", "RMAPP", "RMAPP");
    		PreparedStatement psmt = null;
    		psmt = conn.prepareStatement("DB쿼리문");
    		psmt.setString(1, "");
    		psmt.executeUpdate();
    		conn.commit();
    		conn.close();
    		//ResultSet rs = null;
    		//rs = psmt.executeQuery();
    		
    		ComDefaultVO vo = new ComDefaultVO();
    		vo = nidCmmService.searchGreAddToDay("-1"); 
    		
    		stsSrchVO.setSearchKeyword2(vo.getStartDay().replaceAll("-", ""));
    		stsSrchVO.setSearchKeyword3(vo.getEndDay().replaceAll("-", ""));
    		model.addAttribute("stsSrchVO", stsSrchVO);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 
    	return "/rm/sts/StsGnrIns";
    	
    	
    	
    }
    	
    	
    	
    	
    	
	@RequestMapping(value="/rm/sts/searchTestStsSignOne.do")
    public String  searchTestStsSignOne(
    		@ModelAttribute("stsSrchVO") VtrListVO vtrListVO,
    		ModelMap model)
            throws Exception {    		
    	try {    	
    		
    		vtrListVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		vtrListVO.setPageSize(propertiesService.getInt("pageSize"));
    		 		
        	
        	/** pageing */
        	PaginationInfo paginationInfo = new PaginationInfo();
    		paginationInfo.setCurrentPageNo(vtrListVO.getPageIndex());
    		paginationInfo.setRecordCountPerPage(vtrListVO.getPageUnit());
    		paginationInfo.setPageSize(vtrListVO.getPageSize());

    		vtrListVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
    		vtrListVO.setLastIndex(paginationInfo.getLastRecordIndex());
    		vtrListVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
    		
    		//Setting user Language
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vtrListVO.setUseLangCd(user.getUseLangCd());
    		
    		
    		for(int j = 0;j < 2; j++){
    			String ymd = "";
    			if(j == 0){
    				ymd = "02112015";
    			}else {
    				ymd = "05112015";
    			}
    			vtrListVO.setSearchKeyword2("g");
    			vtrListVO.setSearchKeyword4(ymd);
    			vtrListVO.setSearchKeyword5(ymd);
    			vtrListVO.setPoliAdCd("949");
    			List<EgovMap> emLst = pollStaDAO.selecListVtrSign(vtrListVO);
        		if(emLst != null && !emLst.isEmpty()){
        			for(int i = 0; i < emLst.size(); i++){
        				EgovMap emp = emLst.get(i);
        				String crnDd = NidStringUtil.nullConvert(emp.get("crnDd"));
        				String rsdtSeqNo = NidStringUtil.nullConvert(emp.get("rsdtSeqNo"));
        				String sysSgnt = null;
        				String certResult = "1";
        				Object obj = emp.get("sysSgnt");
            			if(obj != null){
        					if("oracle.sql.CLOB".equals(obj.getClass().getName()) ){
        						CLOB clob = (CLOB)obj;
        						sysSgnt = clobToString(clob);
        						//log.debug("oracle.sql.CLOB : " + sysSgnt);
        					}else if("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB".equals(obj.getClass().getName()) ){
        						weblogic.jdbc.vendor.oracle.OracleThinClob clob = (weblogic.jdbc.vendor.oracle.OracleThinClob)obj;
        						sysSgnt = clobToString(clob);
        						//log.debug("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB : " + sysSgnt);
        					}
        				}
            			String dtMrg = NidStringUtil.nullConvert(emp.get("dtMrg"));
            			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
        				StringBuffer sb = new StringBuffer();
        				sb.append(reg);
        				sb.append("<root>");
        				sb.append("\r\n<RMDSigData><![CDATA[");
        				sb.append(dtMrg);
        				sb.append("]]></RMDSigData>\r\n");
        				sb.append(sysSgnt);
        				sb.append("</root>");
        				byte [] array = new byte[sb.toString().length()];			
        				array = sb.toString().getBytes();
        				log.debug("sign log start");
        				log.debug(ymd + " : " + rsdtSeqNo);
        				log.debug(sb.toString());
        				log.debug("sign log end");
        			}
        		}
    			
    		}
    		
    		
    		
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 
    	return "/rm/sts/StsGnrIns";
        	
        	
        	
        	
        	

    }
    	
    	
	@RequestMapping(value="/rm/sts/searchTestStsSignTwo.do")
    public String  searchTestStsSignTwo(
    		@ModelAttribute("stsSrchVO") VtrListVO vtrListVO,
    		ModelMap model)
            throws Exception {    		
    	try {    	
    		
    		String [] str = new String[2];
    		StringBuffer sb = new StringBuffer();
    		sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><root>");
    		sb.append("\r\n<RMDSigData><![CDATA[20151102|849|010101000|0100|0101|010101000|کابل|کابل|Kabul|کابل ښار|شهر کابل|Kabul City|||||||ناحیه اول|Area01|اوله ناحیه|141024003|15/11/02|141024003|15/11/02]]></RMDSigData>\r\n");
    		sb.append("<ds:Signature xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\"><ds:SignedInfo><ds:CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments\"/><ds:SignatureMethod Algorithm=\"http://www.w3.org/2001/04/xmldsig-more#rsa-sha256\"/><ds:Reference URI=\"\"><ds:Transforms><ds:Transform Algorithm=\"http://www.w3.org/2000/09/xmldsig#enveloped-signature\"/></ds:Transforms><ds:DigestMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#sha256\"/><ds:DigestValue>/BhhsoIYKE1RdvDITQfGrfvABOSyiCBSuXq8olx13es=</ds:DigestValue></ds:Reference></ds:SignedInfo><ds:SignatureValue>iauUojbkG42iIWg/17AbDmklpuaxnu5zXIjkfmRKXpujRVKUvKrCWkTwdVeQxejPqejMTp79xfnM");
    		sb.append("8esn9cOFmKQTWLFAdSJ6OwZ5yvxZvjH052+F4oxcK07J6wJAAzslp2foRQtV09XfJjLTt7G/Odjr");
    		sb.append("KaWgzeMn7ZiYrvkOHcABw+ior3kywTIIXeF1kkeD2XSNfmtSHE4m3dXUplrFiZe60QdWKzoHWkTd");
    		sb.append("BnUDtcBNCplvLRthlt3HfcdQ2niZIKP4HJ9AT81J0SbUuWp9YEqsD57SVRmgjd19Xy2nJE03JQKw");
    		sb.append("zU/twF1xP+G6vTVTM8TH35ESNnKttXWrN71pVg==</ds:SignatureValue><ds:KeyInfo><ds:X509Data><ds:X509SubjectName>CN=RM-SeverDS-TestSigner001, OU=services, OU=test-pki, O=ARCA, C=AF</ds:X509SubjectName><ds:X509Certificate>MIIEaTCCA1GgAwIBAgIEUUzgsjANBgkqhkiG9w0BAQsFADBFMQswCQYDVQQGEwJBRjENMAsGA1UE");
    		sb.append("ChMEQVJDQTERMA8GA1UECxMIdGVzdC1wa2kxFDASBgNVBAMTC0FGLVRlc3RDQTAxMB4XDTE0MDYy");
    		sb.append("NjE5MjcwMloXDTE1MDYyNjE5NTcwMlowZTELMAkGA1UEBhMCQUYxDTALBgNVBAoTBEFSQ0ExETAP");
    		sb.append("BgNVBAsTCHRlc3QtcGtpMREwDwYDVQQLEwhzZXJ2aWNlczEhMB8GA1UEAxMYUk0tU2V2ZXJEUy1U");
    		sb.append("ZXN0U2lnbmVyMDAxMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAoVkyDlQDgk6mecr3");
    		sb.append("5IoSYEtGQiTRj5zT0Mou7yZ7A8CMcXJjf4VAqYcXo+vsQ+iALQ8gbf/h9qbbP5C7fWLEc02kQ8/C");
    		sb.append("ZAc3RkRK/TiXetXJEtLN3+MRlAZq6qcMEsK+CqcOfMx29rsunzsmxnmfjvK6XJNiXqjuLq07T0M9");
    		sb.append("KICBDPEW4r8KbOHzjwufwJp7eEPnvaIhJZMAgr6SPzETW7H6gPYbzmqMty1dlDQhrWCEYM9WcLRf");
    		sb.append("S5hlLOgvwpz5d9TTH2MWosglaI4qy2cdFLS5SF1FDnzkHti+tTcunwBpXYqunZZROfhPsN+FeqXX");
    		sb.append("/lhvVk0x/tbVE/2t7xqurwIDAQABo4IBPzCCATswCwYDVR0PBAQDAgWgMIGYBgNVHR8EgZAwgY0w");
    		sb.append("gYqggYeggYSGKmh0dHA6Ly90ZXN0LWFmLnJwdGVzdC5vc2kuc2kvVGVzdENSTGMzLmNybKRWMFQx");
    		sb.append("CzAJBgNVBAYTAkFGMQ0wCwYDVQQKEwRBUkNBMREwDwYDVQQLEwh0ZXN0LXBraTEUMBIGA1UEAxML");
    		sb.append("QUYtVGVzdENBMDExDTALBgNVBAMTBENSTDMwKwYDVR0QBCQwIoAPMjAxNDA2MjYxOTI3MDJagQ8y");
    		sb.append("MDE1MDMwOTA3NTcwMlowHwYDVR0jBBgwFoAUiGRCCkBePrbTza0lFDPX2NKpgFUwHQYDVR0OBBYE");
    		sb.append("FFG/Tw+s1mmiTg5x5/n1GvGiu56JMAkGA1UdEwQCMAAwGQYJKoZIhvZ9B0EABAwwChsEVjguMQMC");
    		sb.append("A6gwDQYJKoZIhvcNAQELBQADggEBAAltsqmSguhnFmi8Ft/Qow++Hi9nBIuSEvapjB4mHvWNUWuC");
    		sb.append("yOlImczFZa0lrE6xfdbMVpEjiQtHRg6tm+a0R69K2NUWJXPyfGtIWs6VbQ9WMXZ6c1hbDPnejDCm");
    		sb.append("lS/IRP/eKtARf5BzR4JICp9auRoqSGg6JvlLsh5mLEoWLsUWP56JFL54zoUyAG6nBhuhY0AuiTSZ");
    		sb.append("LVhOEF7NEHv8KWTJwwk1ZMTF/RQQHuvcMpX7AgeOFNwz3x00eV0a1qAFbPPL3aExtDNrN9x6uRDz");
    		sb.append("Z8hcdT2HlEvDbuNzFsiaCnT2ZtvRlsxk5ABhtjCH34YserxD1ejvQJouz+SuEfCHD/0=</ds:X509Certificate></ds:X509Data></ds:KeyInfo></ds:Signature></root>");
    		str[0] = sb.toString();
			sb.setLength(0);
			sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><root>");
			sb.append("\r\n<RMDSigData><![CDATA[20151105|849|010101000|0100|0101|010101000|کابل|کابل|Kabul|کابل ښار|شهر کابل|Kabul City|||||||ناحیه اول|Area01|اوله ناحیه|141024003|15/11/05|141024003|15/11/05]]></RMDSigData>\r\n");
			sb.append("<ds:Signature xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\"><ds:SignedInfo><ds:CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315#WithComments\"/><ds:SignatureMethod Algorithm=\"http://www.w3.org/2001/04/xmldsig-more#rsa-sha256\"/><ds:Reference URI=\"\"><ds:Transforms><ds:Transform Algorithm=\"http://www.w3.org/2000/09/xmldsig#enveloped-signature\"/></ds:Transforms><ds:DigestMethod Algorithm=\"http://www.w3.org/2001/04/xmlenc#sha256\"/><ds:DigestValue>89rcga5gnjEQ8JveSJUDcdP5gZg+1Qyc4Wy/EnYdn08=</ds:DigestValue></ds:Reference></ds:SignedInfo><ds:SignatureValue>K+XI8dr773nIkh+f/3lN7F5W13Q08IAH1/tmCi/Alp50QmM8Yv9a4wOIYY/7DSewYM+8pEgzu1hV");
			sb.append("nyu0Yj0DHc+hgBEZjuhGJKHT3jbsAltPxrMwwUzbWlfysV1IdYLPWpd9PjFC2j/C+XjWIuf/smXu");
			sb.append("dleOWNiZFFBlXGUj7m1DJnHX4l+NbJS6F0NHASLvcvjaYY9QDusIFEZHg18rPEw30M5r2PqL05EG");
			sb.append("WmzGIs7GSMe+v53amQJKeGlTM8AF+BJ8xAwAwjTskAZAtqJjbe2wm/Bo2VxMD7vE3f+oD0PBQmhv");
			sb.append("cD4qZMVenngFfn33/zZI0SItMMmuQ77ibu7Wog==</ds:SignatureValue><ds:KeyInfo><ds:X509Data><ds:X509SubjectName>CN=RM-SeverDS-TestSigner001, OU=services, OU=test-pki, O=ARCA, C=AF</ds:X509SubjectName><ds:X509Certificate>MIIEaTCCA1GgAwIBAgIEUU01LzANBgkqhkiG9w0BAQsFADBFMQswCQYDVQQGEwJBRjENMAsGA1UE");
			sb.append("ChMEQVJDQTERMA8GA1UECxMIdGVzdC1wa2kxFDASBgNVBAMTC0FGLVRlc3RDQTAxMB4XDTE1MTEw");
			sb.append("MjIxMzA0OVoXDTIwMTEwMjIyMDA0OVowZTELMAkGA1UEBhMCQUYxDTALBgNVBAoTBEFSQ0ExETAP");
			sb.append("BgNVBAsTCHRlc3QtcGtpMREwDwYDVQQLEwhzZXJ2aWNlczEhMB8GA1UEAxMYUk0tU2V2ZXJEUy1U");
			sb.append("ZXN0U2lnbmVyMDAxMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAh9PReSuvl0ntO8o8");
			sb.append("RgOCyCC/3w1x0exh6FqWZ2NW2UGl+2ICsAP7z6ok8WJWqP01KP73kvJ1wujOhKRTLnGLen/JYzn0");
			sb.append("Skjrs7qZwgcgbcJj5sxVp/XLyBqp21ZqpX1fnQsUh2FnNwDwu43liApzWBthpnj1wg3VUF2/y/rJ");
			sb.append("kYNzUMBE7cIkKfYeXP2ZqMCw/7J99A4ySKyw/Y5RgfWrP4RcrqDrcXk+Enn/Nniy8QPgiTN0nroq");
			sb.append("IU9E0QPKxptP/qKXZ+/LsueJQIAFKMwlBWxktw/VOBmyX7/dCLWrAEGBdp5y2wlFRjV6p/5+u3Qq");
			sb.append("RaVPNnmkvlZGGopYTAQMoQIDAQABo4IBPzCCATswCwYDVR0PBAQDAgWgMIGYBgNVHR8EgZAwgY0w");
			sb.append("gYqggYeggYSGKmh0dHA6Ly90ZXN0LWFmLnJwdGVzdC5vc2kuc2kvVGVzdENSTGM2LmNybKRWMFQx");
			sb.append("CzAJBgNVBAYTAkFGMQ0wCwYDVQQKEwRBUkNBMREwDwYDVQQLEwh0ZXN0LXBraTEUMBIGA1UEAxML");
			sb.append("QUYtVGVzdENBMDExDTALBgNVBAMTBENSTDYwKwYDVR0QBCQwIoAPMjAxNTExMDIyMTMwNDlagQ8y");
			sb.append("MDIwMTEwMjIyMDA0OVowHwYDVR0jBBgwFoAUiGRCCkBePrbTza0lFDPX2NKpgFUwHQYDVR0OBBYE");
			sb.append("FL3mOPSVZdD8F3rkfHdC+JYIfXfRMAkGA1UdEwQCMAAwGQYJKoZIhvZ9B0EABAwwChsEVjguMQMC");
			sb.append("A6gwDQYJKoZIhvcNAQELBQADggEBAFPE3UpIq2mMf361MIe3oi/uJwzPvIU0zSOn8gUuU4V8jboX");
			sb.append("Ctw2/Egl5YltUMgIVOvQuNjUSDTl+8CAKpB9178vAqZDuDEN1ZnXBzvmmXJ4UHDwHGDQhT0QBheY");
			sb.append("7RKZNIWxUC3ydHRX5tvu6StyYko8xujMyZYpSFbNFOJ9q13CPUGsGPZ6zMS3Q/jJ7+M9c78WpEJe");
			sb.append("3Gxd/lt6VykC0na/jVh/WYJ2SsAsXz1pGXBnBoSoAPtTJtdvp54YBYvHeKRhcmYGCwhYM0Fi9sz4");
			sb.append("xAnRDJkW5gLqsRIiTnSMTllaUug9Oqb7n5v9tDRjzbULwsrcEWAkOXW2KGI5KWW9eDM=</ds:X509Certificate></ds:X509Data></ds:KeyInfo></ds:Signature></root>");
			str[1] = sb.toString();
			sb.setLength(0);
			for(int i = 0; i < str.length; i++){
				String sign = str[i];
				sb = new StringBuffer();
				sb.append(sign);
				byte [] array = new byte[sb.toString().length()];			
				array = sb.toString().getBytes();
				int certResultFlag = XMLDsigValidate.spkiIFDigitalSignatureValidation(array);
				String certResult = "";
				if(certResultFlag == 0){
					certResult = "Success";
				}else{
					certResult = "fail";
				}
				log.debug("sign log start");
				log.debug(i + " : " + certResult + " : code = " + certResultFlag);
				log.debug("sign log end");
			}
			
			
    		
    		
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 
    	return "/rm/sts/StsGnrIns";
        	
        	
        	
        	
        	

    }	
	
	
	/**
	 * ClobToString <br>
	 *
	 * @param CLOB
	 * @return String
	 *
	 */
	private String clobToString(CLOB clob) {
		String result = "";
		if(clob != null){
			try{
				Reader reader = clob.getCharacterStream();
				StringBuffer sb = new StringBuffer();
				int size = 0;
				char[] array = new char[10];
				while(( size = reader.read(array)) != -1){
					sb.append(array, 0, size);
				}
				result = sb.toString();
			}catch(Exception e){
				log.error(e);
			}
		}
		return result;
	}
	
	/**
	 * ClobToString <br>
	 *
	 * @param CLOB
	 * @return String
	 *
	 */
	private String clobToString(weblogic.jdbc.vendor.oracle.OracleThinClob clob) {
		String result = "";
		if(clob != null){
			try{
				Writer clobWriter = clob.getCharacterOutputStream();
				log.debug("clobToString : " +clobWriter);
				StringBuffer sb = new StringBuffer();
				if(clobWriter != null){
					char buf [] = new char[clob.getChunkSize()];
					buf[0] = '\0';
					clob.getChars(1, clob.getChunkSize(), buf);
					sb.append(buf);
				}
				result = sb.toString();
			}catch(Exception e){
				log.error(e);
			}
		}
		return result;
	}	
    
} 