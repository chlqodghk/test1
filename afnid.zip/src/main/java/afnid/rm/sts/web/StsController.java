package afnid.rm.sts.web;

/* java API */

import java.io.OutputStream;
import java.io.StringWriter;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CdGrpVO;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.sts.service.StsBsnWrkStusVO;
import afnid.rm.sts.service.StsBthRtVO;
import afnid.rm.sts.service.StsDthRtAgeVO;
import afnid.rm.sts.service.StsDthRtVO;
import afnid.rm.sts.service.StsEpctSchAgVO;
import afnid.rm.sts.service.StsPpltAgeVO;
import afnid.rm.sts.service.StsPpltBthPlceVO;
import afnid.rm.sts.service.StsPpltEduVO;
import afnid.rm.sts.service.StsPpltEncyVO;
import afnid.rm.sts.service.StsPpltMrrgVO;
import afnid.rm.sts.service.StsPpltMthrTguVO;
import afnid.rm.sts.service.StsPpltPmntAdVO;
import afnid.rm.sts.service.StsPpltPoliStatVO;
import afnid.rm.sts.service.StsPpltPrsAdVO;
import afnid.rm.sts.service.StsPpltRignSectVO;
import afnid.rm.sts.service.StsRgstStusVO;
import afnid.rm.sts.service.StsRsdcKchiVO;
import afnid.rm.sts.service.StsSecdNltyVO;
import afnid.rm.sts.service.StsService;
import afnid.rm.sts.service.StsSrchVO;
import afnid.rm.sts.service.StsVtrPrsAdVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;


/** 
 * This Controller class processes request of resident-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Moon Soo Kim
 * @since 22013.05.23
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.05.23  		Moon Soo Kim		                    Create
 *
 * </pre>
 */

@Controller
public class StsController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** NidProgrmManageService */
	@Resource(name = "stsService")
    private StsService service;
	
    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;

    /** lgService */
	@Resource(name = "lgService")
    private LgService lgService;
	
	/** NidCommonService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCmmService;
	
	
 	/**
     * Move to creation screen of Population Statistic. <br>
     *
     * @param CmCmmCdVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsGnrIns.jsp  "
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListRsdtStsRqstView.do")
    public String  searchListRsdtStsRqstView(
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {    		
    	
    	try {    	
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();    		
    		lgService.addUserWrkLg(user.getUserId(), stsSrchVO.getCurMnId());
    		
    		ComDefaultVO vo = new ComDefaultVO();
    		vo = nidCmmService.searchGreAddToDay("-1"); 
    		
    		stsSrchVO.setSearchKeyword2(vo.getStartDay().replaceAll("-", ""));
    		stsSrchVO.setSearchKeyword3(vo.getEndDay().replaceAll("-", ""));
    		model.addAttribute("stsSrchVO", stsSrchVO);

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 
    	
    	return "/rm/sts/StsGnrIns";

    }
    
 	/**
     * Move to creation screen of Population Statistic. <br>
     *
     * @param CmCmmCdVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsGnrIns.jsp  "
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListRsdtStsRqst.do")
    public String  searchListRsdtStsRqst(
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {    		
    	
    	try {    	
    		
    		stsSrchVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		stsSrchVO.setPageSize(propertiesService.getInt("pageSize"));
	   		
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(stsSrchVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(stsSrchVO.getPageUnit());
			paginationInfo.setPageSize(stsSrchVO.getPageSize());
			stsSrchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			stsSrchVO.setLastIndex(paginationInfo.getLastRecordIndex());
			stsSrchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
			List<StsSrchVO> lstRsdtStsRqst = service.searchListRsdtStsRqst(stsSrchVO);
	        model.addAttribute("lstRsdtStsRqst", lstRsdtStsRqst);
	        
	        int totCnt = service.searchListRsdtStsRqstTotCn(stsSrchVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 
    	
    	return "/rm/sts/StsGnrIns";

    }
    
 	/**
     * Request generation of statistics. <br>
     *
     * @param CmCmmCdVO Value-object for request generation of statistics(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsGnrIns.jsp  "
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/addRsdtStsRqst.do")
    public String  addRsdtStsRqst(
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {    		
    	
    	try {  
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCmmService.searchGreToDay(stsSrchVO);
    		
    		int result = service.searchRsdtStsRqstYn(comVo.getStartDay().replace("-", ""));
    		
    		if (result > 0){// in case of be already requested Statistic
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nStsGrn.msg"));
    		} else {
    			service.addRsdtStsRqst(stsSrchVO);
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));//    			
    		}
     			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 

    	return "forward:/rm/sts/searchListRsdtStsRqst.do";
    }
    
 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param CmCmmCdVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsPpltPrsAdList.jsp  "
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsPpltPrsAdView.do")
    public String searchListStsPpltPrsAdView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		@ModelAttribute("cdGrpVO") CdGrpVO cdGrpVO,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		lgService.addUserWrkLg(user.getUserId(), cdGrpVO.getCurMnId());
    		
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		String orgnzCd = user.getOrgnzCd();
    		String district = orgnzCd.substring(0, 4); 
    		String teamCd = user.getTamCdNm();
    		stsSrchVO.setOfficerNo(district+teamCd);
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
			
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			model.addAttribute("initView", "Y");
			
			searchVO.setSearchKeyword6("j");
			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsPpltPrsAdList";    
    }

 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsPpltPrsAdVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsPpltPrsAdList.jsp  "
     * @exception Exception
     */    
    @RequestMapping(value="/rm/sts/searchListStsPpltPrsAd.do")
    public String searchListStsPpltPrsAd(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }

	        List<StsPpltPrsAdVO> lstProgram = service.searchListStsPpltPrsAd(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    		
    	}
        return "/rm/sts/StsPpltPrsAdList";    
    }    
    
 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsPpltPmntAdVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsPpltPmntAdList.jsp  "
     * @exception Exception
     */        
    @RequestMapping(value="/rm/sts/searchListStsPpltPmntAd.do")
    public String searchListStsPpltPmntAd(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
			List<StsPpltPmntAdVO> lstProgram = service.searchListStsPpltPmntAd(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsPpltPmntAdList";    
    }      
    
 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsPpltBthPlceVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsPpltBthPlceList.jsp  "
     * @exception Exception
     */        
    @RequestMapping(value="/rm/sts/searchListStsPpltBthPlce.do")
    public String searchListStsPpltBthPlce(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
	        List<StsPpltBthPlceVO> lstProgram = service.searchListStsPpltBthPlce(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsPpltBthPlceList";    
    }  
    
 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsPpltAgeVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsPpltAgeList.jsp  "
     * @exception Exception
     */        
    @RequestMapping(value="/rm/sts/searchListStsPpltAge.do")
    public String searchListStsPpltAge(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
			cmCmmCd.setGrpCd("42"); // Age Group Code
			List<CmCmmCdVO> ageGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("ageGrpCd", ageGrpCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
		    service.searchRmCurtAdStsTbSign(stsSrchVO);
		    
	        List<StsPpltAgeVO> lstProgram = service.searchListStsPpltAge(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsPpltAgeList";    
    }  
    
 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsPpltEduVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsPpltEduList.jsp  "
     * @exception Exception
     */        
    @RequestMapping(value="/rm/sts/searchListStsPpltEdu.do")
    public String searchListStsPpltEdu(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
			cmCmmCd.setGrpCd("42"); //Age Group Code 
			List<CmCmmCdVO> ageGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("ageGrpCd", ageGrpCd); 
			
			cmCmmCd.setGrpCd("10"); // Gender Code
			List<CmCmmCdVO> gdrGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("gdrGrpCd", gdrGrpCd);
			
			cmCmmCd.setGrpCd("5"); // Education Code
			List<CmCmmCdVO> eduGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("eduGrpCd", eduGrpCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
	        List<StsPpltEduVO> lstProgram = service.searchListStsPpltEdu(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsPpltEduList";    
    }  
    
 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsPpltRignSectVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsPpltRignSectList.jsp  "
     * @exception Exception
     */        
    @RequestMapping(value="/rm/sts/searchListStsPpltRignSect.do")
    public String searchListStsPpltRignSect(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
						
			cmCmmCd.setGrpCd("17"); // Religion Code
			List<CmCmmCdVO> rignCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("rignCd", rignCd); 		
			
			cmCmmCd.setGrpCd("18"); //Religion Sect Code
			List<CmCmmCdVO> sectCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call			
			model.addAttribute("sectCd", sectCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
		    service.searchRmRlgnSectStsTbSign(stsSrchVO);
		    
	        List<StsPpltRignSectVO> lstProgram = service.searchListStsPpltRignSect(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsPpltRignSectList";    
    }  
    
 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsPpltMthrTguVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsPpltMthrTguList.jsp  "
     * @exception Exception
     */    
    @RequestMapping(value="/rm/sts/searchListStsPpltMthrTgu.do")
    public String searchListStsPpltMthrTgu(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
			cmCmmCd.setGrpCd("11"); //  National Language
			List<CmCmmCdVO> nltyLangCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("nltyLangCd", nltyLangCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
	        List<StsPpltMthrTguVO> lstProgram = service.searchListStsPpltMthrTgu(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);
	               
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsPpltMthrTguList";    
    }  

 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsPpltEncyVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsPpltEncyList.jsp  "
     * @exception Exception
     */        
    @RequestMapping(value="/rm/sts/searchListStsPpltEncy.do")
    public String searchListStsPpltEncy(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
			cmCmmCd.setGrpCd("6"); // Ethnicity Code
			List<CmCmmCdVO>encyCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("encyCd", encyCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    service.searchRmEncyStsTbSign(stsSrchVO);
	        List<StsPpltEncyVO> lstProgram = service.searchListStsPpltEncy(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsPpltEncyList";    
    }  

 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsPpltMrrgVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsPpltMrrgList.jsp  "
     * @exception Exception
     */        
    @RequestMapping(value="/rm/sts/searchListStsPpltMrrg.do")
    public String searchListStsPpltMrrg(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
			cmCmmCd.setGrpCd("42"); // Age Group  Code
			List<CmCmmCdVO>ageGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("ageGrpCd", ageGrpCd); 
			
			cmCmmCd.setGrpCd("12"); // Marital Status Code
			List<CmCmmCdVO>mrrgCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("mrrgCd", mrrgCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
	        List<StsPpltMrrgVO> lstProgram = service.searchListStsPpltMrrg(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsPpltMrrgList";    
    }  
    
 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsRsdcKchiVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsRsdcKchiList.jsp  "
     * @exception Exception
     */        
    @RequestMapping(value="/rm/sts/searchListStsRsdcKchi.do")
    public String searchListStsRsdcKchi(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
	        List<StsRsdcKchiVO> lstProgram = service.searchListStsRsdcKchi(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsRsdcKchiList";    
    }  

 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsSecdNltyVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsSecdNltyList.jsp  "
     * @exception Exception
     */        
    @RequestMapping(value="/rm/sts/searchListStsSecdNlty.do")
    public String searchListStsSecdNlty(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
			//province  name 
			List<StsSecdNltyVO> lstPrvic = service.searchListPrvic(stsSrchVO);			
			model.addAttribute("lstPrvic", lstPrvic);
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
	        List<StsSecdNltyVO> lstProgram = service.searchListStsSecdNlty(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsSecdNltyList";    
    }  

 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsPpltPoliStatVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsPpltPoliStatList.jsp  "
     * @exception Exception
     */        
    @RequestMapping(value="/rm/sts/searchListStsPpltPoliStat.do")
    public String searchListStsPpltPoliStat(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
			cmCmmCd.setGrpCd("42"); // Age Group Code
			List<CmCmmCdVO> ageGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("ageGrpCd", ageGrpCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    service.searchRmPoliStatStsTbSign(stsSrchVO);
	        List<StsPpltPoliStatVO> lstProgram = service.searchListStsPpltPoliStat(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsPpltPoliStatList";    
    }      
    
 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsBthRtVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsBthRtList.jsp  "
     * @exception Exception
     */        
    @RequestMapping(value="/rm/sts/searchListStsBthRt.do")
    public String searchListStsBthRt(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
    		String calTye = stsSrchVO.getSearchKeyword6();
    		
    		if("j".equals(calTye)){
	    		String frYy =  String.valueOf(Integer.parseInt(stsSrchVO.getSearchKeyword().substring(0,4))-4);
	    		stsSrchVO.setSearchKeyword9(frYy);
	    		stsSrchVO.setSearchKeyword8(stsSrchVO.getSearchKeyword().substring(0,4));    		
    		} else {
	    		String frYy =  String.valueOf(Integer.parseInt(stsSrchVO.getSearchKeyword2().substring(6,10))-4);
	    		stsSrchVO.setSearchKeyword9(frYy);
	    		stsSrchVO.setSearchKeyword8(stsSrchVO.getSearchKeyword2().substring(6,10));     			
    		}
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
	        List<StsBthRtVO> lstProgram = service.searchListStsBthRt(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsBthRtList";    
    }      
    
 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsDthRtVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsDthRtList.jsp  "
     * @exception Exception
     */        
    @RequestMapping(value="/rm/sts/searchListStsDthRt.do")
    public String searchListStsDthRt(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
    		String calTye = stsSrchVO.getSearchKeyword6();
    		
    		if("j".equals(calTye)){
	    		String frYy =  String.valueOf(Integer.parseInt(stsSrchVO.getSearchKeyword().substring(0,4))-4);
	    		stsSrchVO.setSearchKeyword9(frYy);
	    		stsSrchVO.setSearchKeyword8(stsSrchVO.getSearchKeyword().substring(0,4));    		
    		} else {
	    		String frYy =  String.valueOf(Integer.parseInt(stsSrchVO.getSearchKeyword2().substring(6,10))-4);
	    		stsSrchVO.setSearchKeyword9(frYy);
	    		stsSrchVO.setSearchKeyword8(stsSrchVO.getSearchKeyword2().substring(6,10));     			
    		}
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
	        List<StsDthRtVO> lstProgram = service.searchListStsDthRt(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsDthRtList";    
    }      
    
 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsDthRtAgeVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsDthRtAgeList.jsp  "
     * @exception Exception
     */        
    @RequestMapping(value="/rm/sts/searchListStsDthRtAge.do")
    public String searchListStsDthRtAge(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
    		String calTye = stsSrchVO.getSearchKeyword6();
    		
    		if("j".equals(calTye)){
	    		String frYy =  String.valueOf(Integer.parseInt(stsSrchVO.getSearchKeyword().substring(0,4))-4);
	    		stsSrchVO.setSearchKeyword9(frYy);
	    		stsSrchVO.setSearchKeyword8(stsSrchVO.getSearchKeyword().substring(0,4));    		
    		} else {
	    		String frYy =  String.valueOf(Integer.parseInt(stsSrchVO.getSearchKeyword2().substring(6,10))-4);
	    		stsSrchVO.setSearchKeyword9(frYy);
	    		stsSrchVO.setSearchKeyword8(stsSrchVO.getSearchKeyword2().substring(6,10));     			
    		}
    		
	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
			cmCmmCd.setGrpCd("42"); // Age Group Code
			List<CmCmmCdVO> ageGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("ageGrpCd", ageGrpCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
	        List<StsDthRtAgeVO> lstProgram = service.searchListStsDthRtAge(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsDthRtAgeList";    
    }      
    
 	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsEpctSchAgVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsEpctSchAgList.jsp  "
     * @exception Exception
     */        
    @RequestMapping(value="/rm/sts/searchListStsEpctSchAge.do")
    public String searchListStsEpctSchAge(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
    		String calTye = stsSrchVO.getSearchKeyword6();
    		
    		if("j".equals(calTye)){
	    		String frYy =  String.valueOf(Integer.parseInt(stsSrchVO.getSearchKeyword().substring(0,4))+4);
	    		stsSrchVO.setSearchKeyword9(frYy);
	    		stsSrchVO.setSearchKeyword8(stsSrchVO.getSearchKeyword().substring(0,4));    		
    		} else {
	    		String frYy =  String.valueOf(Integer.parseInt(stsSrchVO.getSearchKeyword2().substring(6,10))+4);
	    		stsSrchVO.setSearchKeyword9(frYy);
	    		stsSrchVO.setSearchKeyword8(stsSrchVO.getSearchKeyword2().substring(6,10));     			
    		}

	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // Resident Statistics Group Code
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
	        List<StsEpctSchAgVO> lstProgram = service.searchListStsEpctSchAge(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);		

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsEpctSchAgeList";            
    }          
    
	/**
     * Moved to list-screen of Statistics. <br>
     *
     * @param StsEpctSchAgVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsVtrPrsAdList.jsp  "
     * @exception Exception
     */        
    @RequestMapping(value="/rm/sts/searchListStsVtrPrsAd.do")
    public String searchListStsVtrPrsAd(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());
    		stsSrchVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
    		String calTye = stsSrchVO.getSearchKeyword6();
    		
    		if("j".equals(calTye)){
	    		String frYy =  String.valueOf(Integer.parseInt(stsSrchVO.getSearchKeyword().substring(0,4))+4);
	    		stsSrchVO.setSearchKeyword9(frYy);
	    		stsSrchVO.setSearchKeyword8(stsSrchVO.getSearchKeyword().substring(0,4));    		
    		} else {
	    		String frYy =  String.valueOf(Integer.parseInt(stsSrchVO.getSearchKeyword2().substring(6,10))+4);
	    		stsSrchVO.setSearchKeyword9(frYy);
	    		stsSrchVO.setSearchKeyword8(stsSrchVO.getSearchKeyword2().substring(6,10));     			
    		}

	    	//Common Code 조회
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성
						
			List<StsSrchVO> lstCrnDd = service.searchListStsCreYmd("");
			model.addAttribute("lstCrnDd", lstCrnDd); 
			
			cmCmmCd.setGrpCd("41"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(stsSrchVO.getSearchKeyword5());
			CmCmmCdVO stsTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("stsTle", stsTle); 
			
			cmCmmCd.setGrpCd("41"); // 
			List<CmCmmCdVO> lstStsCd = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("lstStsCd", lstStsCd); 
			
		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
	        List<StsVtrPrsAdVO> lstProgram = service.searchListStsVtrPrsAd(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);		

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsVtrPrsAdList";            
    }              
    /**=================================================================================
    EXCEL DOWN
    ===================================================================================*/
    /**
     *  Download Statistic  of Population by Present address to Excel.<br>
     * 
     * @param StsPpltPrsAdVO Value-object of Statistic  of Population by Present address to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsPpltPrsAdDownExcel.do")
    public void searchListStsPpltPrsAdDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFCell cell = null;
		
    	try {
    		String prvicNm = null;
    		String dstrNm = null;
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("1");
    		
    		String stsTitle = service.searchStsTitle(stsSrchVO);

    		List<StsPpltPrsAdVO> lstProgram = service.searchListStsPpltPrsAd(stsSrchVO);		

    		
    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 26 * 256);
    		
    		for (int i=2; i<5; i++) {
    			sheet.setColumnWidth(i, 17 * 256);
    		}
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0,0,4) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);
    		
    		String[] title = { nidMessageSource.getMessage("prvic")
			                  ,nidMessageSource.getMessage("dstr")
    				          ,nidMessageSource.getMessage("psonNo")
    				          ,nidMessageSource.getMessage("sum")
    				          ,nidMessageSource.getMessage("ml")
    				          ,nidMessageSource.getMessage("feml")
    				          };
    		
            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);
    		
    		for(int i=0; i<title.length; i++){ 
    			 if(i < 2 ){    				 
    				 cell = row1.createCell(i);    	
    				 cell.setCellStyle(titleStyle);
    				 cell.setCellValue(title[i]);
    				 cell = row2.createCell(i);    	
    				 cell.setCellStyle(titleStyle);    				 
    				 sheet.addMergedRegion( new CellRangeAddress(1, 2, i, i) );
    			 } else if (i == 2 ){    				 
    				 cell = row1.createCell(i);    	
    				 cell.setCellStyle(titleStyle);
    				 cell.setCellValue(title[i]);
    				 cell = row1.createCell(i+1);    	
    				 cell.setCellStyle(titleStyle);
    				 cell = row1.createCell(i+2);    	
    				 cell.setCellStyle(titleStyle);    				 
    				 sheet.addMergedRegion( new CellRangeAddress(1, 1, i, 4) );
    			 } else {    				 
    				 cell = row2.createCell(i-1);   
    				 cell.setCellStyle(titleStyle);
    				 cell.setCellValue(title[i]);    				 
    			 }    			    		
    		}

    		//Data Display
    		for(int k=0; k<lstProgram.size(); k++){
    			StsPpltPrsAdVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+3);

    			if ( "0001".equals(rowData.getPrvicNm())  ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getPrvicNm())|| "null".equals(rowData.getPrvicNm())){
    				prvicNm	= nidMessageSource.getMessage("frgn");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}

				if ( "0003".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getDstrNm()) || "null".equals(rowData.getDstrNm())){
    				dstrNm	= nidMessageSource.getMessage("frgn");
    			} else {
					dstrNm	= rowData.getDstrNm();
		   		}   
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);    		   
    		    
    		    cell  = row.createCell(2);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotalCnt());
    		    
    		    cell  = row.createCell(3);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt());
    		    
    		    cell  = row.createCell(4);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt());    		    
    		}
    		
   		    
    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(), "g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Population_by_Present_Address.xls");
    		workbook.write(os);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 
    	
    }  
    
    /**
     *  Download Statistic  of Population by Permanent address to Excel.<br>
     * 
     * @param StsPpltPmntAdVO Value-object of Download Statistic  of Population by Permanent address  to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsPpltPmntAdDownExcel.do")
    public void searchListStsPpltPmntAdDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFCell cell = null;
		
    	try {
    		String prvicNm = null;
    		String dstrNm = null;
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("2");
    		
    		String stsTitle = service.searchStsTitle(stsSrchVO);
    		List<StsPpltPmntAdVO> lstProgram = service.searchListStsPpltPmntAd(stsSrchVO);
    		
    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 26 * 256);

    		for (int i=2; i<5; i++) {
    			sheet.setColumnWidth(i, 17 * 256);
    		}
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 4) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);
    		
    		String[] title = {nidMessageSource.getMessage("prvic")
    				                ,nidMessageSource.getMessage("dstr")
    				                ,nidMessageSource.getMessage("psonNo")
    				                ,nidMessageSource.getMessage("sum")
    				                ,nidMessageSource.getMessage("ml")
    				                ,nidMessageSource.getMessage("feml")
    				                };
    		
            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);
    		
    		for(int i=0; i<title.length; i++){   
   			 	if(i < 2 ){    				 
   			 		cell = row1.createCell(i);    	
   				 	cell.setCellStyle(titleStyle);
   				 	cell.setCellValue(title[i]);
   				 	cell = row2.createCell(i);    	
   				 	cell.setCellStyle(titleStyle);    				 
   				 	sheet.addMergedRegion( new CellRangeAddress(1, 2, i, i) );
   			 	} else if (i == 2 ){    				 
   			 		cell = row1.createCell(i);    	
   				 	cell.setCellStyle(titleStyle);
   				 	cell.setCellValue(title[i]);
   				 	cell = row1.createCell(i+1);    	
   				 	cell.setCellStyle(titleStyle);
   				 	cell = row1.createCell(i+2);    	
   				 	cell.setCellStyle(titleStyle);    				 
   				 	sheet.addMergedRegion( new CellRangeAddress(1, 1, i, 4) );
   			 	} else {
   			 		cell = row2.createCell(i-1);   
   			 		cell.setCellStyle(titleStyle);
   			 		cell.setCellValue(title[i]);    				 
   			 	}    			    		
    		}

    		//Data Display
    		for(int k=0; k<lstProgram.size(); k++){
    			StsPpltPmntAdVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+3);
    			
    			if ( "0001".equals(rowData.getPrvicNm())  ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getPrvicNm()) || "null".equals(rowData.getPrvicNm())){
    				prvicNm	= nidMessageSource.getMessage("frgn");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}

				if ( "0003".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getDstrNm()) || "null".equals(rowData.getDstrNm()) ){
    				dstrNm	= nidMessageSource.getMessage("frgn");
    			} else {
					dstrNm	= rowData.getDstrNm();
		   		}  
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);
    		    
    		    cell  = row.createCell(2);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotalCnt());
    		    
    		    cell  = row.createCell(3);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt());
    		    
    		    cell  = row.createCell(4);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt());    		    
    		}

    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Population_by_Permanent_Address.xls");
    		workbook.write(os);    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}  

    }  
    
    /**
     * Download Statistic  of Population by Birth Place address to Excel. <br>
     * 
     * @param StsPpltBthPlceVO Value-object of Statistic  of Population by Birth Place address  to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsPpltBthPlceDownExcel.do")
    public void searchListStsPpltBthPlceDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {
    	
		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFCell cell = null;
    	try {
    		String prvicNm = null;
    		String dstrNm = null;
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("3");
    		
    		String stsTitle = service.searchStsTitle(stsSrchVO);    		
    		List<StsPpltBthPlceVO> lstProgram = service.searchListStsPpltBthPlce(stsSrchVO);
    	 	
    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 26 * 256);
    		
    		for (int i=2; i<5; i++) {
    			sheet.setColumnWidth(i, 17 * 256);
    		}
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 4) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);
    		
    		String[] title = {nidMessageSource.getMessage("prvic")
    				                ,nidMessageSource.getMessage("dstr")
    				                ,nidMessageSource.getMessage("psonNo")
    				                ,nidMessageSource.getMessage("sum")
    				                ,nidMessageSource.getMessage("ml")
    				                ,nidMessageSource.getMessage("feml")
    				                };
    		
            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);
    		
    		for(int i=0; i<title.length; i++){   
   			 	if(i < 2 ){    
   			 	    sheet.addMergedRegion( new CellRangeAddress(1, 2, i, i) );
   			 		cell = row1.createCell(i);    	
   				 	cell.setCellStyle(titleStyle);
   				 	cell.setCellValue(title[i]);
   				 	cell = row2.createCell(i);    	
   				 	cell.setCellStyle(titleStyle);    				 
   				 	
   			 	} else if (i ==2 ){    
   			 	     sheet.addMergedRegion( new CellRangeAddress(1, 1, i, 4) );
   			 		cell = row1.createCell(i);    	
   				 	cell.setCellStyle(titleStyle);
   				 	cell.setCellValue(title[i]);
   				 	cell = row1.createCell(i+1);    	
   				 	cell.setCellStyle(titleStyle);
   				 	cell = row1.createCell(i+2);    	
   				 	cell.setCellStyle(titleStyle);    				 
   				 	
   			 	} else {
   			 		cell = row2.createCell(i-1);   
   			 		cell.setCellStyle(titleStyle);
   			 		cell.setCellValue(title[i]);    				 
   			 	}    			    		
    		}

    		//Data Display
    		for(int k=0; k<lstProgram.size(); k++){
    			StsPpltBthPlceVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+3);
    			
    			if ( "0001".equals(rowData.getPrvicNm())  ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getPrvicNm())){
    				prvicNm	= nidMessageSource.getMessage("frgn");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}

				if ( "0003".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getDstrNm())){
    				dstrNm	= nidMessageSource.getMessage("frgn");
    			} else {
					dstrNm	= rowData.getDstrNm();
		   		}    
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);
    		    
    		    cell  = row.createCell(2);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotalCnt());
    		    
    		    cell  = row.createCell(3);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt());
    		    
    		    cell  = row.createCell(4);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt());    		    
    		}
    		
    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Population_by_Birth_Place_address.xls");
    		workbook.write(os);       		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 
    	
    }  
    
    /**
     *  Download Statistic  of Population by Age to Excel. <br>
     * 
     * @param StsPpltAgeVO Value-object of Statistic  of Population by Ag to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsPpltAgeDownExcel.do")
    public void searchListStsPpltAgeDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFCell cell = null;
    	try {
    		String prvicNm = null;
    		String dstrNm = null;
    		    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("4");
    		
    		String stsTitle = service.searchStsTitle(stsSrchVO);    		
    		
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); // 공통코드 Value Object 생성

			cmCmmCd.setGrpCd("42"); // Age Group Code
			List<CmCmmCdVO> ageGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			
    		List<StsPpltAgeVO> lstProgram = service.searchListStsPpltAge(stsSrchVO);

    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 26 * 256);
    		
    		for (int i=2; i<35; i++) {
    			sheet.setColumnWidth(i, 11 * 256);
    		}
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 5) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);
    		
    		String[] title = new String[16];
    		
    		title[0] = nidMessageSource.getMessage("prvic");
    		title[1] = nidMessageSource.getMessage("dstr");
    		
    		for(int i=0; i<ageGrpCd.size(); i++){
    			Object titleData = ageGrpCd.get(i);  
    			EgovMap em = (EgovMap)titleData;
    			title[i+2] = (String)em.get("cmmCdNm");
    		}
    		
    		title[13] = nidMessageSource.getMessage("sum");
    		title[14] = nidMessageSource.getMessage("ml");
    		title[15] = nidMessageSource.getMessage("feml");

            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);
    		CellStyle valStyleNumRed = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, true);
    		
    		int startVal =2;
    		int endVal  =4;
    		for(int i=0; i<(title.length-2); i++){   
    			if(i<2){    				
    				cell = row1.createCell(i);   
    				cell.setCellStyle(titleStyle);
    				cell.setCellValue(title[i]); 
    				cell = row2.createCell(i);   
    				cell.setCellStyle(titleStyle);    				
    				sheet.addMergedRegion( new CellRangeAddress(1, 2, i, i) );
     			 } else if ((i > 1) && (i<13) ){      				 
      				 cell = row1.createCell(startVal);    	
      				 cell.setCellStyle(titleStyle);
      				 cell.setCellValue(title[i]);
      				 cell = row1.createCell(startVal+1);    	
      				 cell.setCellStyle(titleStyle);
      				 cell = row1.createCell(startVal+2);    	
      				 cell.setCellStyle(titleStyle);      				 
      				 sheet.addMergedRegion( new CellRangeAddress(1, 1, startVal, endVal ));
      				startVal=startVal+3;
      				endVal = endVal +3;
      			 } else {
      				 int colStart =2;
      				 for(int k=0; k<ageGrpCd.size(); k++){
      					cell = row2.createCell(colStart);   
      				 	cell.setCellStyle(titleStyle);
      				 	cell.setCellValue(title[13]); 
      					cell = row2.createCell(colStart+1);   
      				 	cell.setCellStyle(titleStyle);      				 	
      				 	cell.setCellValue(title[14]);
      					cell = row2.createCell(colStart+2);   
      				 	cell.setCellStyle(titleStyle);      				 	
      				 	cell.setCellValue(title[15]);
      				 	colStart = colStart +3;
      			     }
      			 }
      		 }
    		
    		//Data Display
    		for(int k=0; k<lstProgram.size(); k++){
    			StsPpltAgeVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+3);
    			
    			if ( "0001".equals(rowData.getPrvicNm()) ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getPrvicNm())|| "null".equals(rowData.getPrvicNm())){
    				prvicNm	= nidMessageSource.getMessage("frgn");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}

				if ( "0003".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getDstrNm()) || "null".equals(rowData.getDstrNm())){
    				dstrNm	= nidMessageSource.getMessage("frgn");
    			} else {
					dstrNm	= rowData.getDstrNm();
		   		}  
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);
    		    
    		    String sysSgntInsp = rowData.getSysSgntInsp();
    		    
    		    cell  = row.createCell(2);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge0TotCnt());
				
    		    cell  = row.createCell(3);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge0MlCnt());
				
    		    cell  = row.createCell(4);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge0FmlCnt());   
				
    		    cell  = row.createCell(5);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge10TotCnt());   

    		    cell  = row.createCell(6);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge10MlCnt());   
				
    		    cell  = row.createCell(7);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge10FmlCnt());   

    		    cell  = row.createCell(8);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge20TotCnt());   
				
    		    cell  = row.createCell(9);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge20MlCnt());   
				
    		    cell  = row.createCell(10);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge20FmlCnt());   
				
    		    cell  = row.createCell(11);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge30TotCnt());   
				
    		    cell  = row.createCell(12);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge30MlCnt());   
				
    		    cell  = row.createCell(13);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge30FmlCnt());   
				
    		    cell  = row.createCell(14);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge40TotCnt());   
				
    		    cell  = row.createCell(15);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge40MlCnt());   
				
    		    cell  = row.createCell(16);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge40FmlCnt());   
				
    		    cell  = row.createCell(17);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge50TotCnt());   
				
    		    cell  = row.createCell(18);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge50MlCnt());   
				
    		    cell  = row.createCell(19);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge50FmlCnt());   
				
    		    cell  = row.createCell(20);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge60TotCnt());   
				
    		    cell  = row.createCell(21);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge60MlCnt());   
				
    		    cell  = row.createCell(22);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge60FmlCnt());   
				
    		    cell  = row.createCell(23);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge70TotCnt());   
				
    		    cell  = row.createCell(24);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge70MlCnt());   
				
    		    cell  = row.createCell(25);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge70FmlCnt());   
				
    		    cell  = row.createCell(26);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge80TotCnt());   
				
    		    cell  = row.createCell(27);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge80MlCnt());   
				
    		    cell  = row.createCell(28);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge80FmlCnt());   
				
    		    cell  = row.createCell(29);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge90TotCnt());   
				
    		    cell  = row.createCell(30);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge90MlCnt());   
				
    		    cell  = row.createCell(31);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge90FmlCnt());   
				
    		    cell  = row.createCell(32);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge100TotCnt());   
				
    		    cell  = row.createCell(33);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge100MlCnt());   
				
    		    cell  = row.createCell(34);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge100FmlCnt());    		    
				
    		}
    		
    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Population_by_Age.xls");
    		workbook.write(os);    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}  
    	
    }  
    
    /**
     *  Download Statistic  of Population by Education to Excel. <br>
     * 
     * @param StsPpltEduVO Value-object of Statistic  of Population by Education to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsPpltEduDownExcel.do")
    public void searchListStsPpltEduDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFRow row3 = null;
		HSSFCell cell = null;
    	try {
    		String prvicNm = null;
    		String dstrNm = null;
    		    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("5");
    		
			CmCmmCdVO cmCmmCd = new CmCmmCdVO(); 
			cmCmmCd.setGrpCd("42"); // Age Group Code
			
			List<CmCmmCdVO> ageGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd);

			cmCmmCd.setGrpCd("5"); // Education Group Code			
			List<CmCmmCdVO> eduGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			
			cmCmmCd.setGrpCd("10"); // Gender Group Code			
			List<CmCmmCdVO> gdrGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			
    		String stsTitle = service.searchStsTitle(stsSrchVO);    		
    		List<StsPpltEduVO> lstProgram = service.searchListStsPpltEdu(stsSrchVO);  		
    		
    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 26 * 256);
    		
    		for (int i=2; i<233; i++) {
    			sheet.setColumnWidth(i, 20 * 256);
    		}
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 7) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);
    		row3 = sheet.createRow((short)3);
    		row3.setHeightInPoints(18);
    		
    		String[] title = new String[23];
    		
    		title[0] = nidMessageSource.getMessage("prvic");
    		title[1] = nidMessageSource.getMessage("dstr");
    		
    		for(int i=0; i<ageGrpCd.size(); i++){
    			Object titleData = ageGrpCd.get(i);  
    			EgovMap em = (EgovMap)titleData;
    			title[i+2] = (String)em.get("cmmCdNm");
    		}
    		
    		title[13] = nidMessageSource.getMessage("sum");
    		
    		for(int i=0; i<gdrGrpCd.size(); i++){
    			Object titleData1 = gdrGrpCd.get(i);  
    			EgovMap em = (EgovMap)titleData1;
    			title[i+14] = (String)em.get("cmmCdNm");
    		}
    		
    		
    		title[16] = nidMessageSource.getMessage("iltr");
    		
    		for(int i=0; i<eduGrpCd.size(); i++){
    			Object titleData2 = eduGrpCd.get(i);  
    			EgovMap em = (EgovMap)titleData2;
    			title[i+17] = (String)em.get("cmmCdNm");
    		}

    		CellStyle titleStyle = getColumTitleStyle(workbook, true, true);
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyleAlign(workbook, stsSrchVO.getUseLangCd(), false, false, 3);    		
    		    		
    		int startVal =2;
    		int endVal   =22;
    		for(int i=0; i<title.length; i++){   
    			if(i<2){ 				
    				cell = row1.createCell(i);   
    				cell.setCellStyle(titleStyle);
    				cell.setCellValue(title[i]); 
    				cell = row2.createCell(i);   
    				cell.setCellStyle(titleStyle);    
    				cell = row3.createCell(i);   
    				cell.setCellStyle(titleStyle);      				
    				sheet.addMergedRegion( new CellRangeAddress(1, 3, i, i) );
     			 } else if ((i > 1) && (i<13) ){   
      				 cell = row1.createCell(startVal);    	
      				 cell.setCellStyle(titleStyle);
      				 cell.setCellValue(title[i]);
      				 
     				 for(int j=1; j<21; j++){
          				 cell = row1.createCell(startVal+j);    	
          				 cell.setCellStyle(titleStyle);     					 
     				 } 
      				 
      				 sheet.addMergedRegion( new CellRangeAddress(1, 1, startVal, endVal ));
      				 startVal = startVal+21;
      				 endVal   = endVal  +21;
     			 } else if(i == 13){
     				 int colMidStart = 2;
     				 int colMidEnd   = 8;
      				 for(int k=0; k<ageGrpCd.size(); k++){
      					cell = row2.createCell(colMidStart);   
      				 	cell.setCellStyle(titleStyle);
      				 	cell.setCellValue(title[13]); 
      				 	for(int m=1; m<7; m++){
      				 		cell = row2.createCell(colMidStart + m);   
      				 		cell.setCellStyle(titleStyle);  
      				 	}
      				 	sheet.addMergedRegion( new CellRangeAddress(2, 2, colMidStart, colMidEnd ));
      				 	
      					cell = row2.createCell(colMidStart+7);   
      				 	cell.setCellStyle(titleStyle);      				 	
      				 	cell.setCellValue(title[14]);
      				 	for(int m=8; m<14; m++){
	      					cell = row2.createCell(colMidStart + m);   
	      				 	cell.setCellStyle(titleStyle);
      				 	}
      				 	sheet.addMergedRegion( new CellRangeAddress(2, 2, colMidStart+7, colMidEnd+7));
   
      					cell = row2.createCell(colMidStart+14);   
      				 	cell.setCellStyle(titleStyle);      				 	
      				 	cell.setCellValue(title[15]);
      				 	for(int m=15; m<21; m++){
	      					cell = row2.createCell(colMidStart + m);   
	      				 	cell.setCellStyle(titleStyle); 
      				 	}
      				 	sheet.addMergedRegion( new CellRangeAddress(2, 2, colMidStart+14, colMidEnd+14 ));
      				 	
      				 	colMidStart = colMidStart+21;
      				 	colMidEnd   = colMidEnd  +21;
      			    }      				 
      			 } else if(i == 16){
      				 int colStart =2;
      				 for(int k=0; k<(11*3); k++){
      					for(int m=16; m<23; m++){
          					cell = row3.createCell(colStart);   
          				 	cell.setCellStyle(titleStyle);
          				 	cell.setCellValue(title[m]); 
          				 	colStart = colStart + 1;
      					}
      			     }
      			 }
      		 }
    		
    		//DATA Display
    		for(int k=0; k<lstProgram.size(); k++){
    			StsPpltEduVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+4);
    			
    			if ( "0001".equals(rowData.getPrvicNm()) ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getPrvicNm())|| "null".equals(rowData.getPrvicNm())){
    				prvicNm	= nidMessageSource.getMessage("frgn");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}

				if ( "0003".equals(rowData.getDstrNm())  ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getDstrNm()) || "null".equals(rowData.getDstrNm())){
    				dstrNm	= nidMessageSource.getMessage("frgn");
    			} else {
					dstrNm	= rowData.getDstrNm();
		   		}     
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);
    		    
    		    cell  = row.createCell(2);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Tot1());
    		    
    		    cell  = row.createCell(3);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Tot2Y() + " / " + rowData.getAge0Tot2N());
    		    
    		    cell  = row.createCell(4);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Tot3Y() + " / " + rowData.getAge0Tot3N());   
    		    
    		    cell  = row.createCell(5);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Tot4Y() + " / " + rowData.getAge0Tot4N());   

    		    cell  = row.createCell(6);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Tot5Y() + " / " + rowData.getAge0Tot5N());   
    		    
    		    cell  = row.createCell(7);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Tot6Y() + " / " + rowData.getAge0Tot6N());   

    		    cell  = row.createCell(8);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Tot7Y() + " / " + rowData.getAge0Tot7N());   

    		    cell  = row.createCell(9);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Ml1());   

    		    cell  = row.createCell(10);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Ml2Y() + " / " + rowData.getAge0Ml2N());   

    		    cell  = row.createCell(11);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Ml3Y() + " / " + rowData.getAge0Ml3N());   

    		    cell  = row.createCell(12);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Ml4Y() + " / " + rowData.getAge0Ml4N());   

    		    cell  = row.createCell(13);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Ml5Y() + " / " + rowData.getAge0Ml5N());   

    		    cell  = row.createCell(14);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Ml6Y() + " / " + rowData.getAge0Ml6N());   

    		    cell  = row.createCell(15);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Ml7Y() + " / " + rowData.getAge0Ml7N());   

    		    cell  = row.createCell(16);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Fm1());   

    		    cell  = row.createCell(17);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Fm2Y() + " / " + rowData.getAge0Fm2N());   

    		    cell  = row.createCell(18);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Fm3Y() + " / " + rowData.getAge0Fm3N() );   

    		    cell  = row.createCell(19);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Fm4Y() + " / " + rowData.getAge0Fm4N() );   

    		    cell  = row.createCell(20);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Fm5Y() + " / " + rowData.getAge0Fm5N() );   

    		    cell  = row.createCell(21);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Fm6Y() + " / " + rowData.getAge0Fm6N() );   

    		    cell  = row.createCell(22);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge0Fm7Y() + " / " + rowData.getAge0Fm7N() );   

    		    cell  = row.createCell(23);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Tot1());   

    		    cell  = row.createCell(24);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Tot2Y() + " / " + rowData.getAge10Tot2N());   

    		    cell  = row.createCell(25);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Tot3Y() + " / " + rowData.getAge10Tot3N());   

    		    cell  = row.createCell(26);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Tot4Y() + " / " + rowData.getAge10Tot4N());   

    		    cell  = row.createCell(27);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Tot5Y() + " / " + rowData.getAge10Tot5N());   

    		    cell  = row.createCell(28);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Tot6Y() + " / " + rowData.getAge10Tot6N());   

    		    cell  = row.createCell(29);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Tot7Y() + " / " + rowData.getAge10Tot7N());   

    		    cell  = row.createCell(30);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Ml1());   

    		    cell  = row.createCell(31);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Ml2Y() + " / " + rowData.getAge10Ml2N());   

    		    cell  = row.createCell(32);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Ml3Y() + " / " + rowData.getAge10Ml3N());   

    		    cell  = row.createCell(33);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Ml4Y() + " / " + rowData.getAge10Ml4N());   
    		    
    		    cell  = row.createCell(34);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Ml5Y() + " / " + rowData.getAge10Ml5N());    		    
    		      		   
    		    cell  = row.createCell(35);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Ml6Y() + " / " + rowData.getAge10Ml6N());
    			
    		    cell  = row.createCell(36);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Ml7Y() + " / " + rowData.getAge10Ml7N());
    		    
    		    cell  = row.createCell(37);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Fm1());
    		    
    		    cell  = row.createCell(38);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Fm2Y() + " / " + rowData.getAge10Fm2N());
    		    
    		    cell  = row.createCell(39);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Fm3Y() + " / " + rowData.getAge10Fm3N());   
    		    
    		    cell  = row.createCell(40);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Fm4Y() + " / " + rowData.getAge10Fm4N());   

    		    cell  = row.createCell(41);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Fm5Y() + " / " + rowData.getAge10Fm5N());   
    		    
    		    cell  = row.createCell(42);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Fm6Y() + " / " + rowData.getAge10Fm6N());   

    		    cell  = row.createCell(43);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10Fm7Y() + " / " + rowData.getAge10Fm7N());   

    		    cell  = row.createCell(44);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Tot1());   

    		    cell  = row.createCell(45);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Tot2Y() + " / " + rowData.getAge20Tot2N());   

    		    cell  = row.createCell(46);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Tot3Y() + " / " + rowData.getAge20Tot3N());   

    		    cell  = row.createCell(47);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Tot4Y() + " / " + rowData.getAge20Tot4N());   

    		    cell  = row.createCell(48);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Tot5Y() + " / " + rowData.getAge20Tot5N());   

    		    cell  = row.createCell(49);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Tot6Y() + " / " + rowData.getAge20Tot6N());   

    		    cell  = row.createCell(50);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Tot7Y() + " / " + rowData.getAge20Tot7N());   

    		    cell  = row.createCell(51);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Ml1());   

    		    cell  = row.createCell(52);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Ml2Y() + " / " + rowData.getAge20Ml2N());   

    		    cell  = row.createCell(53);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Ml3Y() + " / " + rowData.getAge20Ml3N());   

    		    cell  = row.createCell(54);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Ml4Y() + " / " + rowData.getAge20Ml4N());   

    		    cell  = row.createCell(55);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Ml5Y() + " / " + rowData.getAge20Ml5N());   

    		    cell  = row.createCell(56);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Ml6Y() + " / " + rowData.getAge20Ml6N());   

    		    cell  = row.createCell(57);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Ml7Y() + " / " + rowData.getAge20Ml7N());   

    		    cell  = row.createCell(58);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Fm1());   

    		    cell  = row.createCell(59);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Fm2Y() + " / " + rowData.getAge20Fm2N());   

    		    cell  = row.createCell(60);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Fm3Y() + " / " + rowData.getAge20Fm3N());   

    		    cell  = row.createCell(61);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Fm4Y() + " / " + rowData.getAge20Fm4N());   

    		    cell  = row.createCell(62);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Fm5Y() + " / " + rowData.getAge20Fm5N());   

    		    cell  = row.createCell(63);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Fm6Y() + " / " + rowData.getAge20Fm6N());   

    		    cell  = row.createCell(64);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20Fm7Y() + " / " + rowData.getAge20Fm7N());   

    		    cell  = row.createCell(65);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge30Tot1()); 
    		    
    		    cell  = row.createCell(66);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge30Tot2Y() + " / " + rowData.getAge30Tot2N());  
    		    
    		    cell  = row.createCell(67);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge30Tot3Y() + " / " + rowData.getAge30Tot3N());    
			    
			    cell  = row.createCell(68);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Tot4Y() + " / " + rowData.getAge30Tot4N());
			    
			    cell  = row.createCell(69);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Tot5Y() + " / " + rowData.getAge30Tot5N());
			    
			    cell  = row.createCell(70);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Tot6Y() + " / " + rowData.getAge30Tot6N());   
			    
			    cell  = row.createCell(71);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Tot7Y() + " / " + rowData.getAge30Tot7N());   
	
			    cell  = row.createCell(72);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Ml1());   
			    
			    cell  = row.createCell(73);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Ml2Y() + " / " + rowData.getAge30Ml2N());   
	
			    cell  = row.createCell(74);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Ml3Y() + " / " + rowData.getAge30Ml3N());   
	
			    cell  = row.createCell(75);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Ml4Y() + " / " + rowData.getAge30Ml4N());   
	
			    cell  = row.createCell(76);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Ml5Y() + " / " + rowData.getAge30Ml5N());   
	
			    cell  = row.createCell(77);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Ml6Y() + " / " + rowData.getAge30Ml6N());   
	
			    cell  = row.createCell(78);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Ml7Y() + " / " + rowData.getAge30Ml7N());   
	
			    cell  = row.createCell(79);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Fm1());   
	
			    cell  = row.createCell(80);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Fm2Y() + " / " + rowData.getAge30Fm2N());   
	
			    cell  = row.createCell(81);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Fm3Y() + " / " + rowData.getAge30Fm3N());   
	
			    cell  = row.createCell(82);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Fm4Y() + " / " + rowData.getAge30Fm4N());   
	
			    cell  = row.createCell(83);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Fm5Y() + " / " + rowData.getAge30Fm5N());   
	
			    cell  = row.createCell(84);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Fm6Y() + " / " + rowData.getAge30Fm6N());   
	
			    cell  = row.createCell(85);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge30Fm7Y() + " / " + rowData.getAge30Fm7N());   
	
			    cell  = row.createCell(86);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Tot1());   
	
			    cell  = row.createCell(87);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Tot2Y() + " / " + rowData.getAge40Tot2N());   
	
			    cell  = row.createCell(88);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Tot3Y() + " / " + rowData.getAge40Tot3N());   
	
			    cell  = row.createCell(89);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Tot4Y() + " / " + rowData.getAge40Tot4N());   
	
			    cell  = row.createCell(90);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Tot5Y() + " / " + rowData.getAge40Tot5N());   
	
			    cell  = row.createCell(91);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Tot6Y() + " / " + rowData.getAge40Tot6N());   
	
			    cell  = row.createCell(92);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Tot7Y() + " / " + rowData.getAge40Tot7N());   
	
			    cell  = row.createCell(93);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Ml1());   
	
			    cell  = row.createCell(94);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Ml2Y() + " / " + rowData.getAge40Ml2N());   
	
			    cell  = row.createCell(95);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Ml3Y() + " / " + rowData.getAge40Ml3N());   
	
			    cell  = row.createCell(96);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Ml4Y() + " / " + rowData.getAge40Ml4N());   
	
			    cell  = row.createCell(97);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Ml5Y() + " / " + rowData.getAge40Ml5N());   
	
			    cell  = row.createCell(98);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Ml6Y() + " / " + rowData.getAge40Ml6N());   
	
			    cell  = row.createCell(99);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Ml7Y() + " / " + rowData.getAge40Ml7N());   
			    
			    cell  = row.createCell(100);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Fm1());    		    
			      		   
			    cell  = row.createCell(101);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Fm2Y() + " / " + rowData.getAge40Fm2N());
				
			    cell  = row.createCell(102);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Fm3Y() + " / " + rowData.getAge40Fm3N());
			   
			    cell  = row.createCell(103);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Fm4Y() + " / " + rowData.getAge40Fm4N());
			    
			    cell  = row.createCell(104);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Fm5Y() + " / " + rowData.getAge40Fm5N());
			    
			    cell  = row.createCell(105);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Fm6Y() + " / " + rowData.getAge40Fm6N());   
			    
			    cell  = row.createCell(106);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge40Fm7Y() + " / " + rowData.getAge40Fm7N());   
	
			    cell  = row.createCell(107);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Tot1());   
			    
			    cell  = row.createCell(108);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Tot2Y() + " / " + rowData.getAge50Tot2N());   
	
			    cell  = row.createCell(109);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Tot3Y() + " / " + rowData.getAge50Tot3N());   
	
			    cell  = row.createCell(110);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Tot4Y() + " / " + rowData.getAge50Tot4N());   
	
			    cell  = row.createCell(111);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Tot5Y() + " / " + rowData.getAge50Tot5N());   
	
			    cell  = row.createCell(112);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Tot6Y() + " / " + rowData.getAge50Tot6N());   
	
			    cell  = row.createCell(113);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Tot7Y() + " / " + rowData.getAge50Tot7N());   
	
			    cell  = row.createCell(114);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Ml1());   
	
			    cell  = row.createCell(115);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Ml2Y() + " / " + rowData.getAge50Ml2N());   
	
			    cell  = row.createCell(116);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Ml3Y() + " / " + rowData.getAge50Ml3N());   
	
			    cell  = row.createCell(117);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Ml4Y() + " / " + rowData.getAge50Ml4N());   
	
			    cell  = row.createCell(118);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Ml5Y() + " / " + rowData.getAge50Ml5N());   
	
			    cell  = row.createCell(119);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Ml6Y() + " / " + rowData.getAge50Ml6N());   
	
			    cell  = row.createCell(120);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Ml7Y() + " / " + rowData.getAge50Ml7N());   
	
			    cell  = row.createCell(121);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Fm1());   
	
			    cell  = row.createCell(122);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Fm2Y() + " / " + rowData.getAge50Fm2N());   
	
			    cell  = row.createCell(123);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Fm3Y() + " / " + rowData.getAge50Fm3N());   
	
			    cell  = row.createCell(124);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Fm4Y() + " / " + rowData.getAge50Fm4N());   
	
			    cell  = row.createCell(125);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Fm5Y() + " / " + rowData.getAge50Fm5N());   
	
			    cell  = row.createCell(126);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Fm6Y() + " / " + rowData.getAge50Fm6N());   
	
			    cell  = row.createCell(127);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge50Fm7Y() + " / " + rowData.getAge50Fm7N());   
	
			    cell  = row.createCell(128);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Tot1());   
	
			    cell  = row.createCell(129);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Tot2Y() + " / " + rowData.getAge60Tot2N());   
	
			    cell  = row.createCell(130);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Tot3Y() + " / " + rowData.getAge60Tot3N());   
	
			    cell  = row.createCell(131);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Tot4Y() + " / " + rowData.getAge60Tot4N()); 
			    
			    cell  = row.createCell(132);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Tot5Y() + " / " + rowData.getAge60Tot5N());  
			    
			    cell  = row.createCell(133);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Tot6Y() + " / " + rowData.getAge60Tot6N());   
			    
			    cell  = row.createCell(134);	
			    cell.setCellStyle(valStyleStr);
			    cell.setCellValue(rowData.getAge60Tot7Y() + " / " + rowData.getAge60Tot7N());
				
			    cell  = row.createCell(135);	
			    cell.setCellStyle(valStyleStr);
			    cell.setCellValue(rowData.getAge60Ml1());
			    
			    cell  = row.createCell(136);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Ml2Y() + " / " + rowData.getAge60Ml2N());
			    
			    cell  = row.createCell(137);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Ml3Y() + " / " + rowData.getAge60Ml3N());
			    
			    cell  = row.createCell(138);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Ml4Y() + " / " + rowData.getAge60Ml4N());   
			    
			    cell  = row.createCell(139);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Ml5Y() + " / " + rowData.getAge60Ml5N());   
	
			    cell  = row.createCell(140);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Ml6Y() + " / " + rowData.getAge60Ml6N());   
			    
			    cell  = row.createCell(141);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Ml7Y() + " / " + rowData.getAge60Ml7N());   
	
			    cell  = row.createCell(142);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Fm1());   
	
			    cell  = row.createCell(143);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Fm2Y() + " / " + rowData.getAge60Fm2N());   
	
			    cell  = row.createCell(144);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Fm3Y() + " / " + rowData.getAge60Fm3N());   
	
			    cell  = row.createCell(145);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Fm4Y() + " / " + rowData.getAge60Fm4N());   
	
			    cell  = row.createCell(146);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Fm5Y() + " / " + rowData.getAge60Fm5N());   
	
			    cell  = row.createCell(147);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Fm6Y() + " / " + rowData.getAge60Fm6N());   
	
			    cell  = row.createCell(148);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge60Fm7Y() + " / " + rowData.getAge60Fm7N());   
	
			    cell  = row.createCell(149);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Tot1());   
	
			    cell  = row.createCell(150);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Tot2Y() + " / " + rowData.getAge70Tot2N());   
	
			    cell  = row.createCell(151);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Tot3Y() + " / " + rowData.getAge70Tot3N());   
	
			    cell  = row.createCell(152);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Tot4Y() + " / " + rowData.getAge70Tot4N());   
	
			    cell  = row.createCell(153);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Tot5Y() + " / " + rowData.getAge70Tot5N());   
	
			    cell  = row.createCell(154);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Tot6Y() + " / " + rowData.getAge70Tot6N());   
	
			    cell  = row.createCell(155);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Tot7Y() + " / " + rowData.getAge70Tot7N());   
	
			    cell  = row.createCell(156);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Ml1());   
	
			    cell  = row.createCell(157);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Ml2Y() + " / " + rowData.getAge70Ml2N());   
	
			    cell  = row.createCell(158);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Ml3Y() + " / " + rowData.getAge70Ml3N());   
	
			    cell  = row.createCell(159);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Ml4Y() + " / " + rowData.getAge70Ml3N());   
	
			    cell  = row.createCell(160);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Ml5Y() + " / " + rowData.getAge70Ml5N());   
	
			    cell  = row.createCell(161);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Ml6Y() + " / " + rowData.getAge70Ml6N());   
	
			    cell  = row.createCell(162);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Ml7Y() + " / " + rowData.getAge70Ml7N());   
	
			    cell  = row.createCell(163);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Fm1());   
	
			    cell  = row.createCell(164);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Fm2Y() + " / " + rowData.getAge70Fm2N());   
	
			    cell  = row.createCell(165);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Fm3Y() + " / " + rowData.getAge70Fm3N());   
	
			    cell  = row.createCell(166);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Fm4Y() + " / " + rowData.getAge70Fm4N());   
	
			    cell  = row.createCell(167);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Fm5Y() + " / " + rowData.getAge70Fm5N());   
			    
			    cell  = row.createCell(168);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Fm6Y() + " / " + rowData.getAge70Fm6N());    		    
			      		   
			    cell  = row.createCell(169);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge70Fm7Y() + " / " + rowData.getAge70Fm7N());
				
			    cell  = row.createCell(170);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Tot1());
			    
			    cell  = row.createCell(171);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Tot2Y() + " / " + rowData.getAge80Tot2N());
			    
			    cell  = row.createCell(172);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Tot3Y() + " / " + rowData.getAge80Tot3N());
			    
			    cell  = row.createCell(173);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Tot4Y() + " / " + rowData.getAge80Tot4N());   
			    
			    cell  = row.createCell(174);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Tot5Y() + " / " + rowData.getAge80Tot5N());   
	
			    cell  = row.createCell(175);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Tot6Y() + " / " + rowData.getAge80Tot6N());   
			    
			    cell  = row.createCell(176);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Tot7Y() + " / " + rowData.getAge80Tot7N());   
	
			    cell  = row.createCell(177);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Ml1());   
	
			    cell  = row.createCell(178);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Ml2Y() + " / " + rowData.getAge80Ml2N());   
	
			    cell  = row.createCell(179);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Ml3Y() + " / " + rowData.getAge80Ml3N());   
	
			    cell  = row.createCell(180);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Ml4Y() + " / " + rowData.getAge80Ml4N());   
	
			    cell  = row.createCell(181);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Ml5Y() + " / " + rowData.getAge80Ml5N());   
	
			    cell  = row.createCell(182);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Ml6Y() + " / " + rowData.getAge80Ml6N());   
	
			    cell  = row.createCell(183);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Ml7Y() + " / " + rowData.getAge80Ml7N());   
	
			    cell  = row.createCell(184);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Fm1());   
	
			    cell  = row.createCell(185);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Fm2Y() + " / " + rowData.getAge80Fm2N());   
	
			    cell  = row.createCell(186);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Fm3Y() + " / " + rowData.getAge80Fm3N());   
	
			    cell  = row.createCell(187);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Fm4Y() + " / " + rowData.getAge80Fm4N());   
	
			    cell  = row.createCell(188);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Fm5Y() + " / " + rowData.getAge80Fm5N());   
	
			    cell  = row.createCell(189);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Fm6Y() + " / " + rowData.getAge80Fm6N());   
	
			    cell  = row.createCell(190);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge80Fm7Y() + " / " + rowData.getAge80Fm7N());   
	
			    cell  = row.createCell(191);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Tot1());   
	
			    cell  = row.createCell(192);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Tot2Y() + " / " + rowData.getAge90Tot2N());   
	
			    cell  = row.createCell(193);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Tot3Y() + " / " + rowData.getAge90Tot3N());   
	
			    cell  = row.createCell(194);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Tot4Y() + " / " + rowData.getAge90Tot4N());   
	
			    cell  = row.createCell(195);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Tot5Y() + " / " + rowData.getAge90Tot5N());   
	
			    cell  = row.createCell(196);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Tot6Y() + " / " + rowData.getAge90Tot6N());   
	
			    cell  = row.createCell(197);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Tot7Y() + " / " + rowData.getAge90Tot7N());   
	
			    cell  = row.createCell(198);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Ml1());   
	
			    cell  = row.createCell(199);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Ml2Y() + " / " + rowData.getAge90Ml2N()); 
			    
			    cell  = row.createCell(200);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Ml3Y() + " / " + rowData.getAge90Ml3N());  
			    
			    cell  = row.createCell(201);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Ml4Y() + " / " + rowData.getAge90Ml4N()); 
			    
			    cell  = row.createCell(202);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Ml5Y() + " / " + rowData.getAge90Ml5N()); 	
			    
			    cell  = row.createCell(203);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Ml6Y() + " / " + rowData.getAge90Ml6N()); 	
			    
			    cell  = row.createCell(204);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Ml7Y() + " / " + rowData.getAge90Ml7N()); 	
			    
			    cell  = row.createCell(205);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Fm1()); 	
			    
			    cell  = row.createCell(206);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Fm2Y() + " / " + rowData.getAge90Fm2N()); 		
			    
			    cell  = row.createCell(207);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Fm3Y() + " / " + rowData.getAge90Fm3N()); 	
			    
			    cell  = row.createCell(208);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Fm4Y() + " / " + rowData.getAge90Fm4N()); 	
			    
			    cell  = row.createCell(209);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Fm5Y() + " / " + rowData.getAge90Fm5N()); 	
			    
			    cell  = row.createCell(210);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Fm6Y() + " / " + rowData.getAge90Fm6N()); 	
			    
			    cell  = row.createCell(211);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge90Fm7Y() + " / " + rowData.getAge90Fm7N()); 			
			    
			    cell  = row.createCell(212);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Tot1()); 	
			    
			    cell  = row.createCell(213);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Tot2Y() + " / " + rowData.getAge100Tot2N()); 	
			    
			    cell  = row.createCell(214);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Tot3Y() + " / " + rowData.getAge100Tot3N()); 	
			    
			    cell  = row.createCell(215);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Tot4Y() + " / " + rowData.getAge100Tot4N()); 	
			    
			    cell  = row.createCell(216);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Tot5Y() + " / " + rowData.getAge100Tot5N()); 			
			    
			    cell  = row.createCell(217);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Tot6Y() + " / " + rowData.getAge100Tot6N()); 	
			    
			    cell  = row.createCell(218);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Tot7Y() + " / " + rowData.getAge100Tot7N()); 	
			    
			    cell  = row.createCell(219);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Ml1()); 	
			    
			    cell  = row.createCell(220);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Ml2Y() + " / " + rowData.getAge100Ml2N()); 	
			    
			    cell  = row.createCell(221);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Ml3Y() + " / " + rowData.getAge100Ml3N()); 			
			    
			    cell  = row.createCell(222);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Ml4Y() + " / " + rowData.getAge100Ml4N()); 	
			    
			    cell  = row.createCell(223);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Ml5Y() + " / " + rowData.getAge100Ml5N()); 	
			    
			    cell  = row.createCell(224);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Ml6Y() + " / " + rowData.getAge100Ml6N()); 	
			    
			    cell  = row.createCell(225);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Ml7Y() + " / " + rowData.getAge100Ml7N()); 	
			    
			    cell  = row.createCell(226);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Fm1()); 			
			    
			    cell  = row.createCell(227);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Fm2Y() + " / " + rowData.getAge100Fm2N()); 	
			    
			    cell  = row.createCell(228);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Fm3Y() + " / " + rowData.getAge100Fm3N()); 	
			    
			    cell  = row.createCell(229);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Fm4Y() + " / " + rowData.getAge100Fm4N()); 	
			    
			    cell  = row.createCell(230);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Fm5Y() + " / " + rowData.getAge100Fm5N()); 
			    
			    cell  = row.createCell(231);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Fm6Y() + " / " + rowData.getAge100Fm6N()); 	
			    
			    cell  = row.createCell(232);	
			    cell.setCellStyle(valStyleNum);
			    cell.setCellValue(rowData.getAge100Fm7Y() + " / " + rowData.getAge100Fm7N()); 				    
			
    		}

    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Population_by_Education.xls");
    		workbook.write(os);

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}  

    }  
    
    /**
     *  Download Statistic  of Population by Religion & Sect to Excel.  <br>
     * 
     * @param StsPpltPrsAdVO Value-object of Statistic  of Population by Religion & Sect to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsPpltRignSectDownExcel.do")
    public void searchListStsPpltRignSectDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFCell cell = null;
    	try {
    		String prvicNm = null;
    		String dstrNm = null;
    		    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("6");
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("17"); // Religion Code
			List<CmCmmCdVO> rignCd = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			
			cmCmmCd.setGrpCd("18"); //Religion Sect Code
			List<CmCmmCdVO> sectCd = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			
    		String stsTitle = service.searchStsTitle(stsSrchVO);    		
    		List<StsPpltRignSectVO> lstProgram = service.searchListStsPpltRignSect(stsSrchVO);

    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 26 * 256);
    		
    		for (int i=2; i<12; i++) {
    			sheet.setColumnWidth(i, 11 * 256);
    		}
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 7) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);
    		
    		String[] rignTitle = new String[rignCd.size()+3];
    		String[] sectTitle = new String[sectCd.size()+2];
    		
    		rignTitle[0] = nidMessageSource.getMessage("prvic");
    		rignTitle[1] = nidMessageSource.getMessage("dstr");
    		
    		for(int i=0; i<rignCd.size(); i++){
    			Object titleData = rignCd.get(i);  
    			EgovMap emRign = (EgovMap)titleData;
    			rignTitle[i+2] = (String)emRign.get("cmmCdNm");
    		}  	
    		
    		rignTitle[rignCd.size()+2] = nidMessageSource.getMessage("none");
    		
    		sectTitle[0] = nidMessageSource.getMessage("sum");
    		
    		for(int i=0; i<sectCd.size(); i++){
    			Object titleData = sectCd.get(i);  
    			EgovMap emSect = (EgovMap)titleData;
    			sectTitle[i+1] = (String)emSect.get("cmmCdNm");
    		}      		
    		sectTitle[sectCd.size()+1] = nidMessageSource.getMessage("none");
    		
            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);
    		CellStyle valStyleNumRed = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, true);
    		
    		for(int i=0; i<rignTitle.length; i++){   
    			if(i<2){
    				
    				cell = row1.createCell(i);   
    				cell.setCellStyle(titleStyle);
    				cell.setCellValue(rignTitle[i]); 
    				cell = row2.createCell(i);   
    				cell.setCellStyle(titleStyle);    				
    				sheet.addMergedRegion( new CellRangeAddress(1, 2, i, i) );
     			 } else if (i==2 ){      				 
      				 cell = row1.createCell(i);    	
      				 cell.setCellStyle(titleStyle);
      				 cell.setCellValue(rignTitle[i]);
      				 cell = row1.createCell(i+1);    	
      				 cell.setCellStyle(titleStyle);
      				 cell = row1.createCell(i+2);    	
      				 cell.setCellStyle(titleStyle);   
      				 cell = row1.createCell(i+3);    	
      				 cell.setCellStyle(titleStyle);         				 
      				 sheet.addMergedRegion( new CellRangeAddress(1, 1, i, i+3 ));
      				 
      				 cell = row2.createCell(i);   
      				 cell.setCellStyle(titleStyle);
      				 cell.setCellValue(sectTitle[0]); 
      				 cell = row2.createCell(i+1);   
      				 cell.setCellStyle(titleStyle);
      				 cell.setCellValue(sectTitle[1]); 
      				 cell = row2.createCell(i+2);   
      				 cell.setCellStyle(titleStyle);
      				 cell.setCellValue(sectTitle[2]);   
      				 cell = row2.createCell(i+3);   
      				 cell.setCellStyle(titleStyle);
      				 cell.setCellValue(sectTitle[3]);         				 
      			 } else {
      				 cell = row1.createCell(i+3);    	
      				 cell.setCellStyle(titleStyle);
      				 cell.setCellValue(rignTitle[i]);
      				 cell = row2.createCell(i+3);    	
      				 cell.setCellStyle(titleStyle);   				 
      				 sheet.addMergedRegion( new CellRangeAddress(1, 2, i+3, i+3) );
      			 }
      		 }    		
    
    		//DATA Display    		
    		for(int k=0; k<lstProgram.size(); k++){
    			StsPpltRignSectVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+3);
    			
    			if ( "0001".equals(rowData.getPrvicNm()) ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getPrvicNm())|| "null".equals(rowData.getPrvicNm())){
    				prvicNm	= nidMessageSource.getMessage("frgn");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}

				if ( "0003".equals(rowData.getDstrNm())  ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getDstrNm()) || "null".equals(rowData.getDstrNm())){
    				dstrNm	= nidMessageSource.getMessage("frgn");
    			} else {
					dstrNm	= rowData.getDstrNm();
		   		}     
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);
    		    
    		    String sysSgntInsp = rowData.getSysSgntInsp();
    		    
    		    cell  = row.createCell(2);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getIslamTotCnt());
    		    
    		    cell  = row.createCell(3);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getIslam1Cnt());
    		    
    		    cell  = row.createCell(4);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getIslam2Cnt());   
    		    
    		    cell  = row.createCell(5);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getIslam3Cnt());   

    		    cell  = row.createCell(6);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getHinduCnt());   
    		    
    		    cell  = row.createCell(7);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getSikhlCnt());   

    		    cell  = row.createCell(8);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getChristianCnt());   

    		    cell  = row.createCell(9);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getJudaismCnt());   

    		    cell  = row.createCell(10);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getBuddhistCnt());   

    		    cell  = row.createCell(11);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getOtherCnt());  
    		    
    		    cell  = row.createCell(12);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getNoneCnt());      		    
		       		  
    		}   
    		    		
    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Population_by_Religion_Sect.xls");
    		workbook.write(os);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}  
    	
    }  
    
    /**
     * Download Statistic  of Population by Mother Tongue to Excel. <br>
     * 
     * @param StsPpltPrsAdVO Value-object of VoterList to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsPpltMthrTguDownExcel.do")
    public void searchListStsPpltMthrTguDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFCell cell = null;
    	try {
    		String prvicNm = null;
    		String dstrNm = null;
    		    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("7");
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("11"); //  National Language
			List<CmCmmCdVO> nltyLangCd = cmmCdMngService.searchListCmmCd(cmCmmCd); 	
    		String stsTitle = service.searchStsTitle(stsSrchVO);    		
    		List<StsPpltMthrTguVO> lstProgram = service.searchListStsPpltMthrTgu(stsSrchVO);
    	 	
     		workbook = new HSSFWorkbook();
     		sheet = workbook.createSheet("sheet1");
     		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 26 * 256);
    		
    		for (int i=2; i<104; i++) {
    			sheet.setColumnWidth(i, 11 * 256);
    		}
    		
     		row = sheet.createRow((short)0);
     		row.setHeightInPoints(25);
     		
     		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 7) );
     		cell = row.createCell(0);    		
     		cell.setCellStyle(getTitleStyle(workbook));
     		cell.setCellValue(stsTitle); 
     		
     		row1 = sheet.createRow((short)1);
     		row1.setHeightInPoints(18);
     		row2 = sheet.createRow((short)2);
     		row2.setHeightInPoints(18);
     		
    		String[] title = new String[nltyLangCd.size()+3];
    		
    		title[0] = nidMessageSource.getMessage("prvic");
    		title[1] = nidMessageSource.getMessage("dstr");
    		
    		for(int i=0; i<nltyLangCd.size(); i++){
    			Object titleData = nltyLangCd.get(i);  
    			EgovMap em = (EgovMap)titleData;
    			title[i+2] = (String)em.get("cmmCdNm");
    		}

    		title[nltyLangCd.size()+2] = nidMessageSource.getMessage("none");
    		
            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);
    		
    		int startVal =2;
    		for(int i=0; i<title.length; i++){   
    			if(i<2){    				
    				cell = row1.createCell(i);   
    				cell.setCellStyle(titleStyle);
    				cell.setCellValue(title[i]); 
    				cell = row2.createCell(i);   
    				cell.setCellStyle(titleStyle);    				
    				sheet.addMergedRegion( new CellRangeAddress(1, 2, i, i) );
      			 } else {
   					cell = row1.createCell(startVal);   
  				 	cell.setCellStyle(titleStyle);
  				 	cell.setCellValue(title[i]);       				 
   					cell = row1.createCell(startVal+1);   
  				 	cell.setCellStyle(titleStyle);
   					cell = row1.createCell(startVal+2);   
  				 	cell.setCellStyle(titleStyle);
  				 	sheet.addMergedRegion( new CellRangeAddress(1, 1, startVal, startVal+2 ));
  				 	
  					cell = row2.createCell(startVal);   
  				 	cell.setCellStyle(titleStyle);
  				 	cell.setCellValue(nidMessageSource.getMessage("sum")); 
  					cell = row2.createCell(startVal+1);   
  				 	cell.setCellStyle(titleStyle);      				 	
  				 	cell.setCellValue(nidMessageSource.getMessage("ml"));
  					cell = row2.createCell(startVal+2);   
  				 	cell.setCellStyle(titleStyle);      				 	
  				 	cell.setCellValue(nidMessageSource.getMessage("feml"));
  				 	
      				startVal=startVal+3;
      			 }
      		 }
    		
     		//DATA Display    		
    		for(int k=0; k<lstProgram.size(); k++){
    			StsPpltMthrTguVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+3);
    			
    			if ( "0001".equals(rowData.getPrvicNm()) ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getPrvicNm())|| "null".equals(rowData.getPrvicNm())){
    				prvicNm	= nidMessageSource.getMessage("frgn");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}

				if ( "0003".equals(rowData.getDstrNm())  ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getDstrNm()) || "null".equals(rowData.getDstrNm())){
    				dstrNm	= nidMessageSource.getMessage("frgn");
    			} else {
					dstrNm	= rowData.getDstrNm();
		   		}     
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);
    		    
    		    cell  = row.createCell(2);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang01TotCnt());
    		    
    		    cell  = row.createCell(3);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang01MlCnt());
    		    
    		    cell  = row.createCell(4);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang01FmlCnt());   
    		    
    		    cell  = row.createCell(5);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang02TotCnt());   

    		    cell  = row.createCell(6);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang02MlCnt());   
    		    
    		    cell  = row.createCell(7);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang02FmlCnt());   

    		    cell  = row.createCell(8);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang03TotCnt());   

    		    cell  = row.createCell(9);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang03MlCnt());   

    		    cell  = row.createCell(10);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang03FmlCnt());   

    		    cell  = row.createCell(11);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang04TotCnt());   

    		    cell  = row.createCell(12);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang04MlCnt());   

    		    cell  = row.createCell(13);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang04FmlCnt());   

    		    cell  = row.createCell(14);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang05TotCnt());   

    		    cell  = row.createCell(15);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang05MlCnt());   

    		    cell  = row.createCell(16);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang05FmlCnt());   

    		    cell  = row.createCell(17);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang06TotCnt());   

    		    cell  = row.createCell(18);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang06MlCnt());   

    		    cell  = row.createCell(19);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang06FmlCnt());   

    		    cell  = row.createCell(20);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang07TotCnt());   

    		    cell  = row.createCell(21);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang07MlCnt());   

    		    cell  = row.createCell(22);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang07FmlCnt());   

    		    cell  = row.createCell(23);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang08TotCnt());   

    		    cell  = row.createCell(24);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang08MlCnt());   

    		    cell  = row.createCell(25);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang08FmlCnt());   

    		    cell  = row.createCell(26);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang09TotCnt());   

    		    cell  = row.createCell(27);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang09MlCnt());   

    		    cell  = row.createCell(28);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang09FmlCnt());   

    		    cell  = row.createCell(29);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang10TotCnt());   

    		    cell  = row.createCell(30);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang10MlCnt());   

    		    cell  = row.createCell(31);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang10FmlCnt());   
    		    
    		    cell  = row.createCell(32);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang11TotCnt());    		    
    		      		
    		    cell  = row.createCell(33);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang11MlCnt());
    			
    		    cell  = row.createCell(34);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang11FmlCnt());
    		    
    		    cell  = row.createCell(35);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang12TotCnt());
    		    
    		    cell  = row.createCell(36);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang12MlCnt());
    		    
    		    cell  = row.createCell(37);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang12FmlCnt());   
    		    
    		    cell  = row.createCell(38);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang13TotCnt());   

    		    cell  = row.createCell(39);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang13MlCnt());   
    		    
    		    cell  = row.createCell(40);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang13FmlCnt());   

    		    cell  = row.createCell(41);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang14TotCnt());   

    		    cell  = row.createCell(42);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang14MlCnt());   

    		    cell  = row.createCell(43);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang14FmlCnt());   

    		    cell  = row.createCell(44);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang15TotCnt());   

    		    cell  = row.createCell(45);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang15MlCnt());   

    		    cell  = row.createCell(46);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang15FmlCnt());   

    		    cell  = row.createCell(47);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang16TotCnt());   

    		    cell  = row.createCell(48);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang16MlCnt());   

    		    cell  = row.createCell(49);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang16FmlCnt());   

    		    cell  = row.createCell(50);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang17TotCnt());   

    		    cell  = row.createCell(51);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang17MlCnt());   

    		    cell  = row.createCell(52);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang17FmlCnt());   

    		    cell  = row.createCell(53);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang18TotCnt());   

    		    cell  = row.createCell(54);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang18MlCnt());   

    		    cell  = row.createCell(55);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang18FmlCnt());   

    		    cell  = row.createCell(56);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang19TotCnt());   

    		    cell  = row.createCell(57);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang19MlCnt());   

    		    cell  = row.createCell(58);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang19FmlCnt());   

    		    cell  = row.createCell(59);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang20TotCnt());   

    		    cell  = row.createCell(60);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang20MlCnt());   

    		    cell  = row.createCell(61);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang20FmlCnt());   

    		    cell  = row.createCell(62);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang21TotCnt());   

    		    cell  = row.createCell(63);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang21MlCnt()); 
    		    
    		    cell  = row.createCell(64);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang21FmlCnt());  
    		    
    		    cell  = row.createCell(65);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang22TotCnt());
    		    
    		    cell  = row.createCell(66);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang22MlCnt());   

    		    cell  = row.createCell(67);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang22FmlCnt());   

    		    cell  = row.createCell(68);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang23TotCnt());   

    		    cell  = row.createCell(69);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang23MlCnt());   

    		    cell  = row.createCell(70);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang23FmlCnt());   

    		    cell  = row.createCell(71);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang24TotCnt());   

    		    cell  = row.createCell(72);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang24MlCnt());   

    		    cell  = row.createCell(73);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang24FmlCnt());   

    		    cell  = row.createCell(74);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang25TotCnt());   

    		    cell  = row.createCell(75);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang25MlCnt());   

    		    cell  = row.createCell(76);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang25FmlCnt());   

    		    cell  = row.createCell(77);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang26TotCnt());   

    		    cell  = row.createCell(78);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang26MlCnt());   

    		    cell  = row.createCell(79);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang26FmlCnt());   
    		    
    		    cell  = row.createCell(80);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang27TotCnt());    		    
    		      		   
    		    cell  = row.createCell(81);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang27MlCnt());
    			
    		    cell  = row.createCell(82);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang27FmlCnt());
    		    
    		    cell  = row.createCell(83);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang28TotCnt());
    		    
    		    cell  = row.createCell(84);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang28MlCnt());
    		    
    		    cell  = row.createCell(85);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang28FmlCnt());   
    		    
    		    cell  = row.createCell(86);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang29TotCnt());   

    		    cell  = row.createCell(87);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang29MlCnt());   
    		    
    		    cell  = row.createCell(88);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang29FmlCnt());   

    		    cell  = row.createCell(89);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang30TotCnt());   

    		    cell  = row.createCell(90);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang30MlCnt());   

    		    cell  = row.createCell(91);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang30FmlCnt());   

    		    cell  = row.createCell(92);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang31TotCnt());   

    		    cell  = row.createCell(93);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang31MlCnt());   

    		    cell  = row.createCell(94);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang31FmlCnt());   

    		    cell  = row.createCell(95);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang32TotCnt());   

    		    cell  = row.createCell(96);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang32MlCnt());   

    		    cell  = row.createCell(97);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang32FmlCnt());   

    		    cell  = row.createCell(98);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang33TotCnt());   

    		    cell  = row.createCell(99);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang33MlCnt());   

    		    cell  = row.createCell(100);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang33FmlCnt());   

    		    cell  = row.createCell(101);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang34TotCnt());       
    		    
    		    cell  = row.createCell(102);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang34MlCnt()); 
    		    
    		    cell  = row.createCell(103);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang34FmlCnt());     
    		    
    		    cell  = row.createCell(104);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang35TotCnt());       
    		    
    		    cell  = row.createCell(105);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang35MlCnt()); 
    		    
    		    cell  = row.createCell(106);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getLang35FmlCnt());    		    
    		   
    		}    		
    		
    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Population_by_Mother_Tongu.xls");
    		workbook.write(os);    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 

    }      
    
    /**
     * Download Statistic of Population by Ethnicity to Excel. <br>
     * 
     * @param StsPpltPrsAdVO Value-object of Statistic of Population by Ethnicity  to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception ExceptionStatistic of Population by Ethnicity 
     */
    @RequestMapping(value="/rm/sts/searchListStsPpltEncyDownExcel.do")
    public void searchListStsPpltEncyDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFCell cell = null;
    	try {
    		String prvicNm = null;
    		String dstrNm = null;
    		    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd(" 8");
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("6"); // Ethnicity Code
			List<CmCmmCdVO>encyCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		String stsTitle = service.searchStsTitle(stsSrchVO);    		
    		List<StsPpltEncyVO> lstProgram = service.searchListStsPpltEncy(stsSrchVO);
    	 	
    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 26 * 256);
    		
    		for (int i=2; i<45; i++) {
    			sheet.setColumnWidth(i, 19 * 256);
    		}
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 5) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		String[] title = new String[encyCd.size()+3];
    		
    		title[0] = nidMessageSource.getMessage("prvic");
    		title[1] = nidMessageSource.getMessage("dstr");
    		
            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);
    		CellStyle valStyleNumRed = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, true);
    		
    		for(int i=0; i<encyCd.size(); i++){
    			Object titleData = encyCd.get(i);  
    			EgovMap em = (EgovMap)titleData;
    			title[i+2] = (String)em.get("cmmCdNm");
    		}
    		
    		title[encyCd.size()+2] = nidMessageSource.getMessage("none");
    		
    		row = sheet.createRow((short)1);
    		row.setHeightInPoints(18);
    		
    		for(int i=0; i<title.length; i++){  
				cell = row.createCell(i);   
				cell.setCellStyle(titleStyle);
				cell.setCellValue(title[i]); 				
      		 }
    		
     		//DATA Display
    		for(int k=0; k<lstProgram.size(); k++){
    			StsPpltEncyVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+2);
    			
    			if ( "0001".equals(rowData.getPrvicNm()) ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getPrvicNm())|| "null".equals(rowData.getPrvicNm())){
    				prvicNm	= nidMessageSource.getMessage("frgn");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}

				if ( "0003".equals(rowData.getDstrNm())  ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getDstrNm()) || "null".equals(rowData.getDstrNm())){
    				dstrNm	= nidMessageSource.getMessage("frgn");
    			} else {
					dstrNm	= rowData.getDstrNm();
		   		} 
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);
    		    
    		    String sysSgntInsp = rowData.getSysSgntInsp();
    		    
    		    cell  = row.createCell(2);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy01Cnt());
    		    
    		    cell  = row.createCell(3);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy02Cnt());
    		    
    		    cell  = row.createCell(4);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy03Cnt());   
    		    
    		    cell  = row.createCell(5);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy04Cnt());   

    		    cell  = row.createCell(6);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy05Cnt());   
    		    
    		    cell  = row.createCell(7);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy06Cnt());   

    		    cell  = row.createCell(8);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy07Cnt());   

    		    cell  = row.createCell(9);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy08Cnt());   

    		    cell  = row.createCell(10);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy09Cnt());   

    		    cell  = row.createCell(11);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy10Cnt());   

    		    cell  = row.createCell(12);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy11Cnt());   

    		    cell  = row.createCell(13);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy12Cnt());   

    		    cell  = row.createCell(14);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy13Cnt());   

    		    cell  = row.createCell(15);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy14Cnt());   

    		    cell  = row.createCell(16);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy15Cnt());   

    		    cell  = row.createCell(17);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy16Cnt());   

    		    cell  = row.createCell(18);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy17Cnt());   

    		    cell  = row.createCell(19);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy18Cnt());   

    		    cell  = row.createCell(20);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy19Cnt());   

    		    cell  = row.createCell(21);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy20Cnt());   

    		    cell  = row.createCell(22);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy21Cnt());   

    		    cell  = row.createCell(23);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy22Cnt());   

    		    cell  = row.createCell(24);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy23Cnt());   

    		    cell  = row.createCell(25);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy24Cnt());   

    		    cell  = row.createCell(26);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy25Cnt());   

    		    cell  = row.createCell(27);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy26Cnt());   

    		    cell  = row.createCell(28);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy27Cnt());   

    		    cell  = row.createCell(29);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy28Cnt());   

    		    cell  = row.createCell(30);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy29Cnt());   

    		    cell  = row.createCell(31);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy30Cnt());   
    		    
    		    cell  = row.createCell(32);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy31Cnt());    		    
    		      		
    		    cell  = row.createCell(33);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy32Cnt());
    			
    		    cell  = row.createCell(34);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy33Cnt());
    		    
    		    cell  = row.createCell(35);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy34Cnt());
    		    
    		    cell  = row.createCell(36);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy35Cnt());
    		    
    		    cell  = row.createCell(37);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy36Cnt());   
    		    
    		    cell  = row.createCell(38);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy37Cnt());   

    		    cell  = row.createCell(39);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy38Cnt());   
    		    
    		    cell  = row.createCell(40);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy39Cnt());   

    		    cell  = row.createCell(41);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy40Cnt());   

    		    cell  = row.createCell(42);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy41Cnt());  

    		    cell  = row.createCell(43);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy42Cnt()); 
    		    
    		    cell  = row.createCell(44);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getEncy43Cnt());    		    
    		}

    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Population_by_Ethnicity.xls");
    		workbook.write(os);    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}  
    	
    }  
    
    /**
     * Download Statistic of Population by Marital Status to Excel. <br>
     * 
     * @param StsPpltPrsAdVO Value-object of Statistic of Population by Marital Status to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsPpltMrrgDownExcel.do")
    public void searchListStsPpltMrrgDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFCell cell = null;
    	try {
    		String prvicNm = null;
    		String dstrNm = null;
    		    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("9");
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("42"); // Age Group  Code
			List<CmCmmCdVO>ageGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd);  
			
			cmCmmCd.setGrpCd("12"); // Age Group  Code
			List<CmCmmCdVO>mrrgCd = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			
    		String stsTitle = service.searchStsTitle(stsSrchVO);    		
    		List<StsPpltMrrgVO> lstProgram = service.searchListStsPpltMrrg(stsSrchVO);
    	 	
    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 26 * 256);
    		sheet.setColumnWidth(1, 26 * 256);
    		
    		for (int i=2; i<57; i++) {
    			sheet.setColumnWidth(i, 11 * 256);
    		}
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 5) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);
    		
    		String[] title = new String[ageGrpCd.size()+7]; 
    		
    		title[0] = nidMessageSource.getMessage("prvic");
    		title[1] = nidMessageSource.getMessage("dstr");
    		
    		for(int i=0; i<ageGrpCd.size(); i++){
    			Object titleData = ageGrpCd.get(i);  
    			EgovMap em = (EgovMap)titleData;
    			title[i+2] = (String)em.get("cmmCdNm");
    		}
    		
    		for(int i=0; i<mrrgCd.size(); i++){
    			Object titleData = mrrgCd.get(i);  
    			EgovMap em = (EgovMap)titleData;
    			title[i+13] = (String)em.get("cmmCdNm");
    		}
    		title[ageGrpCd.size()+6] = nidMessageSource.getMessage("none");
    		
            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);
    		
    		int colStart =2;
    		int endVal = title.length-5;
    		for(int i=0; i<endVal; i++){   
    			if(i<2){    				
    				cell = row1.createCell(i);   
    				cell.setCellStyle(titleStyle);
    				cell.setCellValue(title[i]); 
    				cell = row2.createCell(i);   
    				cell.setCellStyle(titleStyle);    				
    				sheet.addMergedRegion( new CellRangeAddress(1, 2, i, i) );
      			 } else {
      				    cell = row1.createCell(colStart);
      				    cell.setCellStyle(titleStyle);
      				    cell.setCellValue(title[i]);       				    
      				    cell = row1.createCell(colStart+1);      				    
      				    cell.setCellStyle(titleStyle);
      				    cell = row1.createCell(colStart+2);      				    
      				    cell.setCellStyle(titleStyle);
      				    cell = row1.createCell(colStart+3);      				    
      				    cell.setCellStyle(titleStyle); 
      				    cell = row1.createCell(colStart+4);      				    
      				    cell.setCellStyle(titleStyle);      				    
      				    sheet.addMergedRegion(new CellRangeAddress(1,1, colStart, colStart+4) );
      				  
      					cell = row2.createCell(colStart);   
      				 	cell.setCellStyle(titleStyle);
      				 	cell.setCellValue(title[13]);
      				 	
      					cell = row2.createCell(colStart+1);      					
      				 	cell.setCellStyle(titleStyle);      				 	     				 	
      				 	cell.setCellValue(title[14]);
      				 	
      					cell = row2.createCell(colStart+2);   
      				 	cell.setCellStyle(titleStyle);      				 	     				 	
      				 	cell.setCellValue(title[15]);
      				 	
      					cell = row2.createCell(colStart+3);   
      				 	cell.setCellStyle(titleStyle);      				 	     				 	
      				 	cell.setCellValue(title[16]); 
      				 	
      					cell = row2.createCell(colStart+4);   
      				 	cell.setCellStyle(titleStyle);      				 	     				 	
      				 	cell.setCellValue(title[17]); 
      				 	
      				 	colStart = colStart + 5;
      			 }
      		 } 
    		
    		//Dtat Display     		//DATA Display
    		for(int k=0; k<lstProgram.size(); k++){
    			StsPpltMrrgVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+3);
    			
    			if ( "0001".equals(rowData.getPrvicNm()) ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getPrvicNm())|| "null".equals(rowData.getPrvicNm())){
    				prvicNm	= nidMessageSource.getMessage("frgn");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}
				if ( "0003".equals(rowData.getDstrNm())  ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getDstrNm()) || "null".equals(rowData.getDstrNm())){
    				dstrNm	= nidMessageSource.getMessage("frgn");
    			} else {
					dstrNm	= rowData.getDstrNm();
		   		}   
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);
    		    
    		    cell  = row.createCell(2);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge00YCnt());
    		    
    		    cell  = row.createCell(3);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge00NCnt());
    		        		    
    		    cell  = row.createCell(4);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge00WCnt());
    		    
    		    cell  = row.createCell(5);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge00DCnt());
    		    
    		    cell  = row.createCell(6);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge00NoneCnt());
    		    
    		    cell  = row.createCell(7);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10YCnt());   
    		    
    		    cell  = row.createCell(8);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10NCnt());   

    		    cell  = row.createCell(9);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10WCnt());
    		    
    		    cell  = row.createCell(10);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10DCnt());
    		    
    		    cell  = row.createCell(11);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge10NoneCnt());
    		    
    		    cell  = row.createCell(12);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20YCnt());   
    		    
    		    cell  = row.createCell(13);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20NCnt());   

    		    cell  = row.createCell(14);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20WCnt());
    		    
    		    cell  = row.createCell(15);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20DCnt());    		    
    		    
    		    cell  = row.createCell(16);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge20NoneCnt());
    		    
    		    cell  = row.createCell(17);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge30YCnt());   

    		    cell  = row.createCell(18);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge30NCnt());   

    		    cell  = row.createCell(19);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge30WCnt());
    		    
    		    cell  = row.createCell(20);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge30DCnt());
    		    
    		    cell  = row.createCell(21);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge30NoneCnt());    		    
    		    
    		    cell  = row.createCell(22);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge40YCnt());   

    		    cell  = row.createCell(23);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge40NCnt());   

    		    cell  = row.createCell(24);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge40WCnt());
    		    
    		    cell  = row.createCell(25);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge40DCnt());
    		    
    		    cell  = row.createCell(26);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge40NoneCnt());
    		        		    
    		    cell  = row.createCell(27);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge50YCnt());   

    		    cell  = row.createCell(28);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge50NCnt());   

    		    cell  = row.createCell(29);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge50WCnt());
    		    
    		    cell  = row.createCell(30);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge50DCnt());
    		        		    
    		    cell  = row.createCell(31);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge50NoneCnt());
    		    
    		    cell  = row.createCell(32);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge60YCnt());   

    		    cell  = row.createCell(33);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge60NCnt());   

    		    cell  = row.createCell(34);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge60WCnt());
    		    
    		    cell  = row.createCell(35);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge60DCnt());
    		    
    		    cell  = row.createCell(36);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge60NoneCnt());
    		    
    		    cell  = row.createCell(37);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge70YCnt());   

    		    cell  = row.createCell(38);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge70NCnt());   

    		    cell  = row.createCell(39);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge70WCnt());
    		    
    		    cell  = row.createCell(40);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge70DCnt());
    		    
    		    cell  = row.createCell(41);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge70NoneCnt());    		    
    		    
    		    cell  = row.createCell(42);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge80YCnt());   

    		    cell  = row.createCell(43);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge80NCnt());   

    		    cell  = row.createCell(44);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge80WCnt());
    		    
    		    cell  = row.createCell(45);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge80DCnt());
    		    
    		    cell  = row.createCell(46);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge80NoneCnt());
    		    
    		    cell  = row.createCell(47);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge90YCnt());   

    		    cell  = row.createCell(48);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge90NCnt());   

    		    cell  = row.createCell(49);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge90WCnt());
    		    
    		    cell  = row.createCell(50);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge90DCnt());
    		    
    		    cell  = row.createCell(51);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge50NoneCnt());
    		    
    		    cell  = row.createCell(52);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge100YCnt());   

    		    cell  = row.createCell(53);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge100NCnt());
    		    
    		    cell  = row.createCell(54);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge100WCnt());
    		    
    		    cell  = row.createCell(55);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge100DCnt()); 
    		    
    		    cell  = row.createCell(56);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getAge100NoneCnt());    		    
    		}

    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Population_by_Marital_Status.xls");
    		workbook.write(os);    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 
    	
    }  
    
    /**
     * Download Statistic of Population by Residence for Kochi to Excel. <br>
     * 
     * @param StsPpltPrsAdVO Value-object of  Statistic of Population by Residence for Kochi to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsRsdcKchiDownExcel.do")
    public void searchListStsRsdcKchiDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFCell cell = null;
    	try {
    		String prvicNm = null;
    		String dstrNm = null;
    		    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("10");
    		
    		String stsTitle = service.searchStsTitle(stsSrchVO);    		
    		List<StsRsdcKchiVO> lstProgram = service.searchListStsRsdcKchi(stsSrchVO);
    	 	
    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 26 * 256);
    		
    		for (int i=2; i<8; i++) {
    			sheet.setColumnWidth(i, 11 * 256);
    		}    	
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 7) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);
    		
    		String[] title = new String[4];
    		
    		title[0] = nidMessageSource.getMessage("prvic");
    		title[1] = nidMessageSource.getMessage("dstr");
    		title[2] = nidMessageSource.getMessage("smr");
    		title[3] = nidMessageSource.getMessage("wtr");    		

            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);
    		
    		int colStart =2;
    		
    		for(int i=0; i<title.length; i++){   
    			if(i<2){    				
    				cell = row1.createCell(i);   
    				cell.setCellStyle(titleStyle);
    				cell.setCellValue(title[i]); 
    				cell = row2.createCell(i);   
    				cell.setCellStyle(titleStyle);    				
    				sheet.addMergedRegion( new CellRangeAddress(1, 2, i, i) );
      			 } else {
   				    cell = row1.createCell(colStart);
   				    cell.setCellStyle(titleStyle);
   				    cell.setCellValue(title[i]);       				    
   				    cell = row1.createCell(colStart+1);      				    
   				    cell.setCellStyle(titleStyle);
   				    cell = row1.createCell(colStart+2);      				    
   				    cell.setCellStyle(titleStyle);   				    
   				    sheet.addMergedRegion(new CellRangeAddress(1,1, colStart, colStart+2) );
   				    
      				cell = row2.createCell(colStart);   
      				cell.setCellStyle(titleStyle);
      				cell.setCellValue(nidMessageSource.getMessage("sum")); 
      				cell = row2.createCell(colStart+1);   
      				cell.setCellStyle(titleStyle);      				 	
      				cell.setCellValue(nidMessageSource.getMessage("ml"));
      				cell = row2.createCell(colStart+2);   
      				cell.setCellStyle(titleStyle);      				 	
      				cell.setCellValue(nidMessageSource.getMessage("feml"));
      				colStart = colStart +3;
      			 }
      		 }
    		
    		//Dtat Display     		
    		for(int k=0; k<lstProgram.size(); k++){
    			StsRsdcKchiVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+3);
    			
    			if ( "0001".equals(rowData.getPrvicNm()) ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}

				if ( "0003".equals(rowData.getDstrNm())  ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
				} else {
					dstrNm	= rowData.getDstrNm();
		   		}   
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);
    		    
    		    cell  = row.createCell(2);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getSmrTotCnt());
    		    
    		    cell  = row.createCell(3);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getSmrMlCnt());
    		    
    		    cell  = row.createCell(4);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getSmrFmlCnt());   
    		    
    		    cell  = row.createCell(5);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getWtrTotCnt());   

    		    cell  = row.createCell(6);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getWrtMlCnt());   
    		    
    		    cell  = row.createCell(7);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getWrtFmlCnt());   
    		}

    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Population_by_Residence_for_Kochi.xls");
    		workbook.write(os);    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}  
    	
    }  
    
    /**
     * Download Statistic of Population by Second Nationality to Excel. <br>
     * 
     * @param StsPpltPrsAdVO Value-object of Statistic of Population by Second Nationality to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsSecdNltyDownExcel.do")
    public void searchListStsSecdNltyDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFCell cell = null;
    	try {
    		    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("11");
    		
    		String stsTitle = service.searchStsTitle(stsSrchVO);    		
    		List<StsSecdNltyVO> lstPrvic = service.searchListPrvic(stsSrchVO);
    		List<StsSecdNltyVO> lstProgram = service.searchListStsSecdNlty(stsSrchVO);
    		
    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		
    		int endVal = lstPrvic.size()+2; 
    		for (int i=1; i<endVal; i++) {
    			sheet.setColumnWidth(i, 14 * 256);
    		}
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 5) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		String[] title = new String[lstPrvic.size()+2];
    		
    		title[0] = nidMessageSource.getMessage("secdNlty");

    		for(int i=0; i<lstPrvic.size(); i++){
    			StsSecdNltyVO titleData = lstPrvic.get(i);  
    			title[i+1] = titleData.getPrvicNm();
    		}    		
    		
    		title[lstPrvic.size()+1] = nidMessageSource.getMessage("frgn");
    		
            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);    		
    		
    		row = sheet.createRow((short)1);
    		row.setHeightInPoints(18);
    		
    		for(int i=0; i<title.length; i++){   
     				cell = row.createCell(i);   
    				cell.setCellStyle(titleStyle);
    				cell.setCellValue(title[i]); 
      		 }
    		
    		//DATA Display
    		for(int k=0; k<lstProgram.size(); k++){
    			StsSecdNltyVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+2);

    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(rowData.getSecdNltyNm());
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd01Cnt());
    		    
    		    cell  = row.createCell(2);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd02Cnt());
    		    
    		    cell  = row.createCell(3);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd03Cnt());   
    		    
    		    cell  = row.createCell(4);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd04Cnt());   

    		    cell  = row.createCell(5);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd05Cnt());   
    		    
    		    cell  = row.createCell(6);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd06Cnt());   

    		    cell  = row.createCell(7);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd07Cnt());   

    		    cell  = row.createCell(8);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd08Cnt());   

    		    cell  = row.createCell(9);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd09Cnt());   

    		    cell  = row.createCell(10);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd10Cnt());   

    		    cell  = row.createCell(11);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd11Cnt());   

    		    cell  = row.createCell(12);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd12Cnt());   

    		    cell  = row.createCell(13);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd13Cnt());   

    		    cell  = row.createCell(14);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd14Cnt());   

    		    cell  = row.createCell(15);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd15Cnt());   

    		    cell  = row.createCell(16);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd16Cnt());   

    		    cell  = row.createCell(17);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd17Cnt());   

    		    cell  = row.createCell(18);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd18Cnt());   

    		    cell  = row.createCell(19);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd19Cnt());   

    		    cell  = row.createCell(20);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd20Cnt());   

    		    cell  = row.createCell(21);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd21Cnt());   

    		    cell  = row.createCell(22);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd22Cnt());   

    		    cell  = row.createCell(23);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd23Cnt());   

    		    cell  = row.createCell(24);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd24Cnt());   

    		    cell  = row.createCell(25);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd25Cnt());   

    		    cell  = row.createCell(26);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd26Cnt());   

    		    cell  = row.createCell(27);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd27Cnt());   

    		    cell  = row.createCell(28);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd28Cnt());   

    		    cell  = row.createCell(29);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd29Cnt());   

    		    cell  = row.createCell(30);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd30Cnt());   

    		    cell  = row.createCell(31);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd31Cnt());   

    		    cell  = row.createCell(32);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd32Cnt());   
    		    
    		    cell  = row.createCell(33);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd33Cnt());    		    
    		      		   
    		    cell  = row.createCell(34);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd34Cnt());
    			
    		    cell  = row.createCell(35);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd35Cnt());	
    		    
    		    cell  = row.createCell(36);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getCurtAd36Cnt());
    		    
    		}

    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Population_by_Second_Nationality.xls");
    		workbook.write(os);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 
    	
    }  
    
    /**
     * Download Statistic of Population by Polling Station to Excel. <br>
     * 
     * @param StsPpltPrsAdVO Value-object of Statistic of Population by Polling Station to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsPpltPoliStatDownExcel.do")
    public void searchListStsPpltPoliStatDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFCell cell = null;
    	try {
    		String prvicNm = null;
    		String dstrNm = null;
    		    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("12");
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("42"); // Age Group Code
			List<CmCmmCdVO> ageGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		String stsTitle = service.searchStsTitle(stsSrchVO);    		
    		List<StsPpltPoliStatVO> lstProgram = service.searchListStsPpltPoliStat(stsSrchVO);
    		
    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 26 * 256);
    		
    		for (int i=2; i<35; i++) {
    			sheet.setColumnWidth(i, 14 * 256);
    		}
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 5) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);
    		
    		String[] title = new String[ageGrpCd.size()+2];
    		
    		title[0] = nidMessageSource.getMessage("prvic");
    		title[1] = nidMessageSource.getMessage("dstr");
    		
    		for(int i=0; i<ageGrpCd.size(); i++){
    			Object titleData = ageGrpCd.get(i);  
    			EgovMap em = (EgovMap)titleData;
    			title[i+2] = (String)em.get("cmmCdNm");
    		}

            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);
    		CellStyle valStyleNumRed = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, true);
    		
    		int colStart =2;
    		
    		for(int i=0; i<title.length; i++){   
    			if(i<2){    				
    				cell = row1.createCell(i);   
    				cell.setCellStyle(titleStyle);
    				cell.setCellValue(title[i]); 
    				cell = row2.createCell(i);   
    				cell.setCellStyle(titleStyle);    				
    				sheet.addMergedRegion( new CellRangeAddress(1, 2, i, i) );
      			 } else {
   				    cell = row1.createCell(colStart);
   				    cell.setCellStyle(titleStyle);
   				    cell.setCellValue(title[i]);       				    
   				    cell = row1.createCell(colStart+1);      				    
   				    cell.setCellStyle(titleStyle);
   				    cell = row1.createCell(colStart+2);      				    
   				    cell.setCellStyle(titleStyle);   				    
   				    sheet.addMergedRegion(new CellRangeAddress(1,1, colStart, colStart+2) );
   				    
      				cell = row2.createCell(colStart);   
      				cell.setCellStyle(titleStyle);
      				cell.setCellValue(nidMessageSource.getMessage("sum")); 
      				cell = row2.createCell(colStart+1);   
      				cell.setCellStyle(titleStyle);      				 	
      				cell.setCellValue(nidMessageSource.getMessage("ml"));
      				cell = row2.createCell(colStart+2);   
      				cell.setCellStyle(titleStyle);      				 	
      				cell.setCellValue(nidMessageSource.getMessage("feml"));
      				colStart = colStart +3;
      			 }
      		 }
    		
    		//DATA Display
    		for(int k=0; k<lstProgram.size(); k++){
    			StsPpltPoliStatVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+3);
    			
    			if ( "0001".equals(rowData.getPrvicNm()) ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getPrvicNm())|| "null".equals(rowData.getPrvicNm())){
    				prvicNm	= nidMessageSource.getMessage("frgn");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}

				if ( "0003".equals(rowData.getDstrNm())  ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getDstrNm()) || "null".equals(rowData.getDstrNm())){
    				dstrNm	= nidMessageSource.getMessage("frgn");
    			} else {
					dstrNm	= rowData.getDstrNm();
		   		}   
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);
    		    
    		    String sysSgntInsp = rowData.getSysSgntInsp();
    		    
    		    cell  = row.createCell(2);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge0TotCnt());
    		    
    		    cell  = row.createCell(3);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge0MlCnt());
    		    
    		    cell  = row.createCell(4);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge0FmlCnt());   
    		    
    		    cell  = row.createCell(5);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge10TotCnt());   

    		    cell  = row.createCell(6);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge10MlCnt());   
    		    
    		    cell  = row.createCell(7);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge10FmlCnt());   

    		    cell  = row.createCell(8);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge20TotCnt());   

    		    cell  = row.createCell(9);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge20MlCnt());   

    		    cell  = row.createCell(10);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge20FmlCnt());   

    		    cell  = row.createCell(11);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge30TotCnt());   

    		    cell  = row.createCell(12);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge30MlCnt());   

    		    cell  = row.createCell(13);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge30FmlCnt());   

    		    cell  = row.createCell(14);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge40TotCnt());   

    		    cell  = row.createCell(15);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge40MlCnt());   

    		    cell  = row.createCell(16);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge40FmlCnt());   

    		    cell  = row.createCell(17);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge50TotCnt());   

    		    cell  = row.createCell(18);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge50MlCnt());   

    		    cell  = row.createCell(19);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge50FmlCnt());   

    		    cell  = row.createCell(20);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge60TotCnt());   

    		    cell  = row.createCell(21);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge60MlCnt());   

    		    cell  = row.createCell(22);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge60FmlCnt());   

    		    cell  = row.createCell(23);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge70TotCnt());   

    		    cell  = row.createCell(24);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge70MlCnt());   

    		    cell  = row.createCell(25);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge70FmlCnt());   

    		    cell  = row.createCell(26);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge80TotCnt());   

    		    cell  = row.createCell(27);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge80MlCnt());   

    		    cell  = row.createCell(28);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge80FmlCnt());   

    		    cell  = row.createCell(29);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge90TotCnt());   

    		    cell  = row.createCell(30);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge90MlCnt());   

    		    cell  = row.createCell(31);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge90FmlCnt());   

    		    cell  = row.createCell(32);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge100TotCnt());   

    		    cell  = row.createCell(33);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge100MlCnt());   
    		    
    		    cell  = row.createCell(34);	
    		    if(sysSgntInsp != null && "1".equals(sysSgntInsp)){
    		    	cell.setCellStyle(valStyleNumRed);
    		    }else{
    		    	cell.setCellStyle(valStyleNum);
    		    }
    		    cell.setCellValue(rowData.getAge100FmlCnt());    		    
    		      		   
    		}    
    		
    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Population_by_Polling_Station.xls");
    		workbook.write(os);    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 
    	
    }  
    
    
    /**
     * Download Statistic of Birth Rate to Excel. <br>
     * 
     * @param StsPpltPrsAdVO Value-object of Statistic of Birth Rate to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsBthRtDownExcel.do")
    public void searchListStsBthRtDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFRow row3 = null;
		HSSFCell cell = null;
		
    	try {	
    		String prvicNm = null;
    		String dstrNm = null;
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("13");
    		
    		String stsTitle = service.searchStsTitle(stsSrchVO);    		
    		List<StsBthRtVO> lstProgram = service.searchListStsBthRt(stsSrchVO);
    	 	
    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 26 * 256);
    		
    		for (int i=2; i<27; i++) {
    			sheet.setColumnWidth(i, 14 * 256);
    		}
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 5) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);
    		row3 = sheet.createRow((short)3);
    		row3.setHeightInPoints(18);
    		
    		String[] title = new String[7];
    		
    		title[0] = nidMessageSource.getMessage("prvic");
    		title[1] = nidMessageSource.getMessage("dstr");
    		

            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);
    		
    		int toYy =0;
    		int frYy =0;    		
    		String calTye = stsSrchVO.getSearchKeyword6();
    		
    		if("j".equals(calTye)){
        		toYy = Integer.parseInt(stsSrchVO.getSearchKeyword().substring(0,4));
        		frYy = Integer.parseInt(stsSrchVO.getSearchKeyword().substring(0,4))-4;    			
    		} else {
        		toYy = Integer.parseInt(stsSrchVO.getSearchKeyword2().substring(6,10));
        		frYy = Integer.parseInt(stsSrchVO.getSearchKeyword2().substring(6,10))-4;      			
    		} 
    		
    		int cnt = 2;
    		
    		for(int i= frYy; i<(toYy+1); i++){
    			title[cnt] = String.valueOf(i);
    			cnt=cnt+1;
    		}
 		
    		int colStart =2;

    		for(int i=0; i<title.length; i++){   
    			if(i<2){    				
    				cell = row1.createCell(i);   
    				cell.setCellStyle(titleStyle);
    				cell.setCellValue(title[i]); 
    				cell = row2.createCell(i);   
    				cell.setCellStyle(titleStyle);    	
    				cell = row3.createCell(i);   
    				cell.setCellStyle(titleStyle);      				
    				sheet.addMergedRegion( new CellRangeAddress(1, 3, i, i) );
     			 } else {      	    				 
     				cell = row1.createCell(colStart);   
       				cell.setCellStyle(titleStyle);
       				cell.setCellValue(title[i]);  
     				cell = row1.createCell(colStart+1);   
       				cell.setCellStyle(titleStyle);
     				cell = row1.createCell(colStart+2);   
       				cell.setCellStyle(titleStyle);
     				cell = row1.createCell(colStart+3);   
       				cell.setCellStyle(titleStyle);
       				cell.setCellValue(title[i]);  
     				cell = row1.createCell(colStart+4);   
       				cell.setCellStyle(titleStyle);
       				sheet.addMergedRegion( new CellRangeAddress(1, 1, colStart, colStart+4) );

     				cell = row2.createCell(colStart);   
       				cell.setCellStyle(titleStyle);
       				cell.setCellValue(nidMessageSource.getMessage("no"));  
     				cell = row2.createCell(colStart+1);   
       				cell.setCellStyle(titleStyle);
     				cell = row2.createCell(colStart+2);
     				sheet.addMergedRegion( new CellRangeAddress(2, 2, colStart, colStart+2) );  
     				
       				cell.setCellStyle(titleStyle);
     				cell = row2.createCell(colStart+3);   
     				cell.setCellValue(nidMessageSource.getMessage("rt"));  
       				cell.setCellStyle(titleStyle);
     				cell = row2.createCell(colStart+4);   
       				cell.setCellStyle(titleStyle);
       				sheet.addMergedRegion( new CellRangeAddress(2, 2, colStart+3, colStart+4) );
       				
       				
       				cell = row3.createCell(colStart);   
       				cell.setCellStyle(titleStyle);
       				cell.setCellValue(nidMessageSource.getMessage("sum")); 
       				cell = row3.createCell(colStart+1);   
       				cell.setCellStyle(titleStyle);      				 	
       				cell.setCellValue(nidMessageSource.getMessage("ml"));
       				cell = row3.createCell(colStart+2);   
       				cell.setCellStyle(titleStyle);      				 	
       				cell.setCellValue(nidMessageSource.getMessage("feml"));
       				cell = row3.createCell(colStart+3);   
       				cell.setCellStyle(titleStyle);      				 	
       				cell.setCellValue(nidMessageSource.getMessage("ml"));
       				cell = row3.createCell(colStart+4);   
       				cell.setCellStyle(titleStyle);      				 	
       				cell.setCellValue(nidMessageSource.getMessage("feml"));       
       				
       				colStart = colStart +5;
      			 } 
      		 }    		
    			
    		//DATA Display
    		for(int k=0; k<lstProgram.size(); k++){
    			StsBthRtVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+4);
    			
    			if ( "0001".equals(rowData.getPrvicNm()) ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getPrvicNm())|| "null".equals(rowData.getPrvicNm())){
    				prvicNm	= nidMessageSource.getMessage("frgn");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}

				if ( "0003".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getDstrNm()) || "null".equals(rowData.getDstrNm())){
    				dstrNm	= nidMessageSource.getMessage("frgn");
    			} else {
					dstrNm	= rowData.getDstrNm();
		   		}    
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);
    		    
    		    cell  = row.createCell(2);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotCnt05());
    		    
    		    cell  = row.createCell(3);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt05());
    		    
    		    cell  = row.createCell(4);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt05());   
    		    
    		    cell  = row.createCell(5);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlRt05());   

    		    cell  = row.createCell(6);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlRt05());   
    		    
    		    cell  = row.createCell(7);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotCnt04());   

    		    cell  = row.createCell(8);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt04());   

    		    cell  = row.createCell(9);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt04());   

    		    cell  = row.createCell(10);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlRt04());   

    		    cell  = row.createCell(11);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlRt04());   

    		    cell  = row.createCell(12);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotCnt03());   

    		    cell  = row.createCell(13);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt03());   

    		    cell  = row.createCell(14);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt03());   

    		    cell  = row.createCell(15);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlRt03());   

    		    cell  = row.createCell(16);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlRt03());   

    		    cell  = row.createCell(17);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotCnt02());   

    		    cell  = row.createCell(18);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt02());   

    		    cell  = row.createCell(19);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt02());   

    		    cell  = row.createCell(20);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlRt02());   

    		    cell  = row.createCell(21);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlRt02());   

    		    cell  = row.createCell(22);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotCnt01());   

    		    cell  = row.createCell(23);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt01());   

    		    cell  = row.createCell(24);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt01());   

    		    cell  = row.createCell(25);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlRt01());   

    		    cell  = row.createCell(26);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlRt01()); 
    		}    

    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Birth_Rate.xls");
    		workbook.write(os);    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 

    }  
    
    /**
     * Download Statistic  of Death Rate to Excel. <br>
     * 
     * @param StsPpltPrsAdVO Value-object of Statistic of Death Rate to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsDthRtDownExcel.do")
    public void searchListStsDthRtDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFRow row3 = null;
		HSSFCell cell = null;
    	try {
    		String prvicNm = null;
    		String dstrNm = null;
    		    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("14");
    		
    		String stsTitle = service.searchStsTitle(stsSrchVO);    		
    		List<StsDthRtVO> lstProgram = service.searchListStsDthRt(stsSrchVO);
    	 	
    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 26 * 256);
    		
    		for (int i=2; i<27; i++) {
    			sheet.setColumnWidth(i, 14 * 256);
    		}
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 5) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);
    		row3 = sheet.createRow((short)3);
    		row3.setHeightInPoints(18);
    		
    		String[] title = new String[7];
    		
    		title[0] = nidMessageSource.getMessage("prvic");
    		title[1] = nidMessageSource.getMessage("dstr");
    		
            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);
    		
    		int toYy =0;
    		int frYy =0;    		
    		String calTye = stsSrchVO.getSearchKeyword6();
    		
    		if("j".equals(calTye)){
        		toYy = Integer.parseInt(stsSrchVO.getSearchKeyword().substring(0,4));
        		frYy = Integer.parseInt(stsSrchVO.getSearchKeyword().substring(0,4))-4;    			
    		} else {
        		toYy = Integer.parseInt(stsSrchVO.getSearchKeyword2().substring(6,10));
        		frYy = Integer.parseInt(stsSrchVO.getSearchKeyword2().substring(6,10))-4;     			
    		}

    		
    		int cnt = 2;
    		for(int i= frYy; i<(toYy+1); i++){
    			title[cnt] = String.valueOf(i);
    			cnt=cnt+1;
    		}
 		
    		int colStart =2;

    		for(int i=0; i<title.length; i++){   
    			if(i<2){    				
    				cell = row1.createCell(i);   
    				cell.setCellStyle(titleStyle);
    				cell.setCellValue(title[i]); 
    				cell = row2.createCell(i);   
    				cell.setCellStyle(titleStyle);    	
    				cell = row3.createCell(i);   
    				cell.setCellStyle(titleStyle);      				
    				sheet.addMergedRegion( new CellRangeAddress(1, 3, i, i) );
     			 } else {      	    				 
     				cell = row1.createCell(colStart);   
       				cell.setCellStyle(titleStyle);
       				cell.setCellValue(title[i]);  
     				cell = row1.createCell(colStart+1);   
       				cell.setCellStyle(titleStyle);
     				cell = row1.createCell(colStart+2);   
       				cell.setCellStyle(titleStyle);
     				cell = row1.createCell(colStart+3);   
       				cell.setCellStyle(titleStyle);
       				cell.setCellValue(title[i]);  
     				cell = row1.createCell(colStart+4);   
       				cell.setCellStyle(titleStyle);
       				sheet.addMergedRegion( new CellRangeAddress(1, 1, colStart, colStart+4) );

     				cell = row2.createCell(colStart);   
       				cell.setCellStyle(titleStyle);
       				cell.setCellValue(nidMessageSource.getMessage("no"));  
     				cell = row2.createCell(colStart+1);   
       				cell.setCellStyle(titleStyle);
     				cell = row2.createCell(colStart+2);
     				sheet.addMergedRegion( new CellRangeAddress(2, 2, colStart, colStart+2) );  
     				
       				cell.setCellStyle(titleStyle);
     				cell = row2.createCell(colStart+3);   
     				cell.setCellValue(nidMessageSource.getMessage("rt"));  
       				cell.setCellStyle(titleStyle);
     				cell = row2.createCell(colStart+4);   
       				cell.setCellStyle(titleStyle);
       				sheet.addMergedRegion( new CellRangeAddress(2, 2, colStart+3, colStart+4) );
       				
       				
       				cell = row3.createCell(colStart);   
       				cell.setCellStyle(titleStyle);
       				cell.setCellValue(nidMessageSource.getMessage("sum")); 
       				cell = row3.createCell(colStart+1);   
       				cell.setCellStyle(titleStyle);      				 	
       				cell.setCellValue(nidMessageSource.getMessage("ml"));
       				cell = row3.createCell(colStart+2);   
       				cell.setCellStyle(titleStyle);      				 	
       				cell.setCellValue(nidMessageSource.getMessage("feml"));
       				cell = row3.createCell(colStart+3);   
       				cell.setCellStyle(titleStyle);      				 	
       				cell.setCellValue(nidMessageSource.getMessage("ml"));
       				cell = row3.createCell(colStart+4);   
       				cell.setCellStyle(titleStyle);      				 	
       				cell.setCellValue(nidMessageSource.getMessage("feml"));       
       				
       				colStart = colStart +5;
      			 } 
      		 }     		
    			
    		//DATA Display
    		for(int k=0; k<lstProgram.size(); k++){
    			StsDthRtVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+4);
    			
    			if ( "0001".equals(rowData.getPrvicNm())  ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getPrvicNm())|| "null".equals(rowData.getPrvicNm())){
    				prvicNm	= nidMessageSource.getMessage("frgn");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}

				if ( "0003".equals(rowData.getDstrNm())  ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getDstrNm()) || "null".equals(rowData.getDstrNm())){
    				dstrNm	= nidMessageSource.getMessage("frgn");
    			} else {
					dstrNm	= rowData.getDstrNm();
		   		}  
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);
    		    
    		    cell  = row.createCell(2);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotCnt05());
    		    
    		    cell  = row.createCell(3);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt05());
    		    
    		    cell  = row.createCell(4);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt05());   
    		    
    		    cell  = row.createCell(5);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlRt05());   

    		    cell  = row.createCell(6);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlRt05());   
    		    
    		    cell  = row.createCell(7);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotCnt04());   

    		    cell  = row.createCell(8);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt04());   

    		    cell  = row.createCell(9);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt04());   

    		    cell  = row.createCell(10);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlRt04());   

    		    cell  = row.createCell(11);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlRt04());   

    		    cell  = row.createCell(12);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotCnt03());   

    		    cell  = row.createCell(13);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt03());   

    		    cell  = row.createCell(14);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt03());   

    		    cell  = row.createCell(15);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlRt03());   

    		    cell  = row.createCell(16);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlRt03());   

    		    cell  = row.createCell(17);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotCnt02());   

    		    cell  = row.createCell(18);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt02());   

    		    cell  = row.createCell(19);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt02());   

    		    cell  = row.createCell(20);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlRt02());   

    		    cell  = row.createCell(21);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlRt02());   

    		    cell  = row.createCell(22);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotCnt01());   

    		    cell  = row.createCell(23);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt01());   

    		    cell  = row.createCell(24);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt01());   

    		    cell  = row.createCell(25);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlRt01());   

    		    cell  = row.createCell(26);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlRt01()); 
    		}    
    		    
    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Death_Rate.xls");
    		workbook.write(os);    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}   

    	
    }  
    
    
    /**
     * Download Statistic  of Death Rate by Age to Excel. <br>
     * 
     * @param StsPpltPrsAdVO Value-object of  Statistic  of Death Rate by Ag to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsDthRtAgeDownExcel.do")
    public void searchListStsDthRtAgeDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFRow row3 = null;
		HSSFCell cell = null;
    	try {
    		String prvicNm = null;
    		String dstrNm = null;
    		    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("15");
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("42"); // Age Group Code
			List<CmCmmCdVO> ageGrpCd = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
    		String stsTitle = service.searchStsTitle(stsSrchVO);    		
    		List<StsDthRtAgeVO> lstProgram = service.searchListStsDthRtAge(stsSrchVO);
    	 	
    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 26 * 256);
    		
    		for (int i=2; i<113; i++) {
    			sheet.setColumnWidth(i, 14 * 256);
    		}
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 5) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);
    		row3 = sheet.createRow((short)3);
    		row3.setHeightInPoints(18);
    		
   		    String[] title = new String[7];
   		    String[] ageTitle = new String[ageGrpCd.size()];
    		
    		title[0] = nidMessageSource.getMessage("prvic");
    		title[1] = nidMessageSource.getMessage("dstr");
    		
            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);
    		
    		int toYy =0;
    		int frYy =0;    		
    		String calTye = stsSrchVO.getSearchKeyword6();
    		
    		if("j".equals(calTye)){
        		toYy = Integer.parseInt(stsSrchVO.getSearchKeyword().substring(0,4));
        		frYy = Integer.parseInt(stsSrchVO.getSearchKeyword().substring(0,4))-4;    			
    		} else {
        		toYy = Integer.parseInt(stsSrchVO.getSearchKeyword2().substring(6,10));
        		frYy = Integer.parseInt(stsSrchVO.getSearchKeyword2().substring(6,10))-4;      			
    		}  
    		
    		int cnt = 2;
    		for(int i= frYy; i<(toYy+1); i++){
    			title[cnt] = String.valueOf(i);
    			cnt=cnt+1;
    		}
 		
    		for(int i=0; i<ageGrpCd.size(); i++){
    			Object titleData = ageGrpCd.get(i);  
    			EgovMap em = (EgovMap)titleData;
    			ageTitle[i] = (String)em.get("cmmCdNm");
    		}
    		
    		
    		int colStart =2;
    		int col2Start =2;
    		
    		for(int i=0; i<title.length; i++){   
    			if(i<2){    				
    				cell = row1.createCell(i);   
    				cell.setCellStyle(titleStyle);
    				cell.setCellValue(title[i]); 
    				cell = row2.createCell(i);   
    				cell.setCellStyle(titleStyle);  
    				cell = row3.createCell(i);   
    				cell.setCellStyle(titleStyle);       				
    				sheet.addMergedRegion( new CellRangeAddress(1, 3, i, i) );
     			 } else {     

     				cell = row1.createCell(colStart);   
       				cell.setCellStyle(titleStyle);
       				cell.setCellValue(title[i]);  

       				for(int j=(colStart+1); j< (colStart+22); j++){
         				cell = row1.createCell(j);   
           				cell.setCellStyle(titleStyle);       					
       				}
       				
       				sheet.addMergedRegion( new CellRangeAddress(1, 1, colStart, colStart+21) );
       				colStart = colStart +22;   
       				
       				for(int k=0; k<ageGrpCd.size(); k++){
         				cell = row2.createCell(col2Start);   
           				cell.setCellStyle(titleStyle);       
           				cell.setCellValue(ageTitle[k]);  
         				cell = row2.createCell(col2Start+1);   
           				cell.setCellStyle(titleStyle);           				
           				
           				sheet.addMergedRegion( new CellRangeAddress(2, 2, col2Start, col2Start+1) );
           				
         				cell = row3.createCell(col2Start);   
           				cell.setCellStyle(titleStyle);       
           				cell.setCellValue(nidMessageSource.getMessage("ml"));  
         				cell = row3.createCell(col2Start+1);   
           				cell.setCellStyle(titleStyle);  
           				cell.setCellValue(nidMessageSource.getMessage("feml"));  
           				col2Start = col2Start+2;
       				}  
       				  				
      			 } 
    			
      		 }    		
    			
    		//DATA Display
    		for(int k=0; k<lstProgram.size(); k++){
    			StsDthRtAgeVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+4);
    			
    			if ( "0001".equals(rowData.getPrvicNm()) ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getPrvicNm())|| "null".equals(rowData.getPrvicNm())){
    				prvicNm	= nidMessageSource.getMessage("frgn");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}

				if ( "0003".equals(rowData.getDstrNm())  ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getDstrNm()) || "null".equals(rowData.getDstrNm())){
    				dstrNm	= nidMessageSource.getMessage("frgn");
    			} else {
					dstrNm	= rowData.getDstrNm();
		   		}   
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);
    		    
    		    cell  = row.createCell(2);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age0MlCnt());
    		    
    		    cell  = row.createCell(3);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age0FmlCnt());
    		    
    		    cell  = row.createCell(4);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age10MlCnt());   
    		    
    		    cell  = row.createCell(5);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age10FmlCnt());   

    		    cell  = row.createCell(6);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age20MlCnt());   
    		    
    		    cell  = row.createCell(7);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age20FmlCnt());   

    		    cell  = row.createCell(8);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age30MlCnt());   

    		    cell  = row.createCell(9);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age30FmlCnt());   

    		    cell  = row.createCell(10);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age40MlCnt());   

    		    cell  = row.createCell(11);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age40FmlCnt());   

    		    cell  = row.createCell(12);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age50MlCnt());   

    		    cell  = row.createCell(13);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age50FmlCnt());   

    		    cell  = row.createCell(14);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age60MlCnt());   

    		    cell  = row.createCell(15);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age60FmlCnt());   

    		    cell  = row.createCell(16);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age70MlCnt());   

    		    cell  = row.createCell(17);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age70FmlCnt());   

    		    cell  = row.createCell(18);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age80MlCnt());   

    		    cell  = row.createCell(19);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age80FmlCnt());   

    		    cell  = row.createCell(20);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age90MlCnt());   

    		    cell  = row.createCell(21);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age90FmlCnt());   

    		    cell  = row.createCell(22);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age100MlCnt());   

    		    cell  = row.createCell(23);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY4Age100FmlCnt());   

    		    cell  = row.createCell(24);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age0MlCnt());   

    		    cell  = row.createCell(25);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age0FmlCnt());   

    		    cell  = row.createCell(26);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age10MlCnt());   

    		    cell  = row.createCell(27);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age10FmlCnt());   

    		    cell  = row.createCell(28);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age20MlCnt());   

    		    cell  = row.createCell(29);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age20FmlCnt());   

    		    cell  = row.createCell(30);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age30MlCnt());   

    		    cell  = row.createCell(31);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age30FmlCnt());   

    		    cell  = row.createCell(32);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age40MlCnt());   

    		    cell  = row.createCell(33);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age40FmlCnt());   
    		    
    		    cell  = row.createCell(34);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age50MlCnt());    		    
    		      		   
    		    cell  = row.createCell(35);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age50FmlCnt());
    			
    		    cell  = row.createCell(36);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age60MlCnt());
    		    
    		    cell  = row.createCell(37);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age60FmlCnt());
    		    
    		    cell  = row.createCell(38);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age70MlCnt());
    		    
    		    cell  = row.createCell(39);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age70FmlCnt());   
    		    
    		    cell  = row.createCell(40);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age80MlCnt());   

    		    cell  = row.createCell(41);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age80FmlCnt());   
    		    
    		    cell  = row.createCell(42);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age90MlCnt());   

    		    cell  = row.createCell(43);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age90FmlCnt());   

    		    cell  = row.createCell(44);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age100MlCnt());   

    		    cell  = row.createCell(45);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY3Age100FmlCnt());   

    		    cell  = row.createCell(46);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age0MlCnt());   

    		    cell  = row.createCell(47);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age0FmlCnt());   

    		    cell  = row.createCell(48);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age10MlCnt());   

    		    cell  = row.createCell(49);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age10FmlCnt());   

    		    cell  = row.createCell(50);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age20MlCnt());   

    		    cell  = row.createCell(51);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age20FmlCnt());   

    		    cell  = row.createCell(52);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age30MlCnt());   

    		    cell  = row.createCell(53);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age30FmlCnt());   

    		    cell  = row.createCell(54);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age40MlCnt());   

    		    cell  = row.createCell(55);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age40FmlCnt());   

    		    cell  = row.createCell(56);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age50MlCnt());   

    		    cell  = row.createCell(57);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age50FmlCnt());   

    		    cell  = row.createCell(58);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age60MlCnt());   

    		    cell  = row.createCell(59);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age60FmlCnt());   

    		    cell  = row.createCell(60);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age70MlCnt());   

    		    cell  = row.createCell(61);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age70FmlCnt());   

    		    cell  = row.createCell(62);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age80MlCnt());   

    		    cell  = row.createCell(63);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age80FmlCnt());   

    		    cell  = row.createCell(64);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age90MlCnt());   

    		    cell  = row.createCell(65);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age90FmlCnt()); 
    		    
    		    cell  = row.createCell(66);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age100MlCnt());  
    		    
    		    cell  = row.createCell(67);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY2Age100FmlCnt());      		    
  		    
    		    cell  = row.createCell(68);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age0MlCnt());   

    		    cell  = row.createCell(69);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age0FmlCnt());   

    		    cell  = row.createCell(70);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age10MlCnt());   

    		    cell  = row.createCell(71);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age10FmlCnt());   

    		    cell  = row.createCell(72);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age20MlCnt());   

    		    cell  = row.createCell(73);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age20FmlCnt());   

    		    cell  = row.createCell(74);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age30MlCnt());   

    		    cell  = row.createCell(75);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age30FmlCnt());   

    		    cell  = row.createCell(76);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age40MlCnt());   

    		    cell  = row.createCell(77);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age40FmlCnt());   

    		    cell  = row.createCell(78);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age50MlCnt());   

    		    cell  = row.createCell(79);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age50FmlCnt());   

    		    cell  = row.createCell(80);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age60MlCnt());   

    		    cell  = row.createCell(81);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age60FmlCnt());   
    		    
    		    cell  = row.createCell(82);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age70MlCnt());    		    
    		      		   
    		    cell  = row.createCell(83);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age70FmlCnt());
    			
    		    cell  = row.createCell(84);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age80MlCnt());
    		    
    		    cell  = row.createCell(85);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age80FmlCnt());
    		    
    		    cell  = row.createCell(86);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age90MlCnt());
    		    
    		    cell  = row.createCell(87);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age90FmlCnt());   
    		    
    		    cell  = row.createCell(88);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age100MlCnt());   

    		    cell  = row.createCell(89);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY1Age100FmlCnt());   
    		    
    		    cell  = row.createCell(90);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age0MlCnt());   

    		    cell  = row.createCell(91);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age0FmlCnt());   

    		    cell  = row.createCell(92);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age10MlCnt());   

    		    cell  = row.createCell(93);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age10FmlCnt());   

    		    cell  = row.createCell(94);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age20MlCnt());   

    		    cell  = row.createCell(95);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age20FmlCnt());   

    		    cell  = row.createCell(96);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age30MlCnt());   

    		    cell  = row.createCell(97);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age30FmlCnt());   

    		    cell  = row.createCell(98);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age40MlCnt());   

    		    cell  = row.createCell(99);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age40FmlCnt());   

    		    cell  = row.createCell(100);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age50MlCnt());   

    		    cell  = row.createCell(101);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age50FmlCnt());   

    		    cell  = row.createCell(102);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age60MlCnt());   

    		    cell  = row.createCell(103);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age60FmlCnt());   
   		    
    		    cell  = row.createCell(104);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age70MlCnt());      		    
  		    
    		    cell  = row.createCell(105);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age70FmlCnt());   

    		    cell  = row.createCell(106);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age80MlCnt());   

    		    cell  = row.createCell(107);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age80FmlCnt());   

    		    cell  = row.createCell(108);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age90MlCnt());   

    		    cell  = row.createCell(109);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age90FmlCnt());   

    		    cell  = row.createCell(110);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age100MlCnt());   

    		    cell  = row.createCell(111);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getY0Age100FmlCnt());   
		    		      		    
    		}
    		
    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Death_Rate_by_Age.xls");
    		workbook.write(os);    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}  
    	
    }  
    
    
    /**
     * Download Statistic  of Life Expectancy for School Age to Excel. <br>
     * 
     * @param StsPpltPrsAdVO Value-object of Statistic of Life Expectancy for School Age to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsEpctSchAgeDownExcel.do")
    public void  searchListStsEpctSchAgeDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow   row = null;
		HSSFRow   row1 = null;
		HSSFRow   row2 = null;
		HSSFCell  cell = null;
    	try {
    		String prvicNm = null;
    		String dstrNm = null;
    		    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("16");
    		
    		String stsTitle = service.searchStsTitle(stsSrchVO);    		
    		List<StsEpctSchAgVO> lstProgram = service.searchListStsEpctSchAge(stsSrchVO);
    	 	
    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 26 * 256);
    		
    		for (int i=2; i<17; i++) {
    			sheet.setColumnWidth(i, 14 * 256);
    		}
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 5) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);
    		
   		    String[] title = new String[7];
   		    
    		title[0] = nidMessageSource.getMessage("prvic");
    		title[1] = nidMessageSource.getMessage("dstr");
    		
            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);
    		
    		int toYy =0;
    		int frYy =0;    		
    		String calTye = stsSrchVO.getSearchKeyword6();
    		
    		if("j".equals(calTye)){
        		toYy = Integer.parseInt(stsSrchVO.getSearchKeyword().substring(0,4));
        		frYy = Integer.parseInt(stsSrchVO.getSearchKeyword().substring(0,4))-4;    			
    		} else {
        		toYy = Integer.parseInt(stsSrchVO.getSearchKeyword2().substring(6,10));
        		frYy = Integer.parseInt(stsSrchVO.getSearchKeyword2().substring(6,10))-4;      			
    		}  
    		
    		int cnt = 2;
    		for(int i= frYy; i<(toYy+1); i++){
    			title[cnt] = String.valueOf(i);
    			cnt=cnt+1;
    		}
 		

    		int colStart =2;

    		for(int i=0; i<title.length; i++){   
    			if(i<2){    				
    				cell = row1.createCell(i);   
    				cell.setCellStyle(titleStyle);
    				cell.setCellValue(title[i]); 
    				cell = row2.createCell(i);   
    				cell.setCellStyle(titleStyle);    	    				
    				sheet.addMergedRegion( new CellRangeAddress(1, 2, i, i) );
     			 } else {      	    				 
     				cell = row1.createCell(colStart);   
       				cell.setCellStyle(titleStyle);
       				cell.setCellValue(title[i]);  
     				cell = row1.createCell(colStart+1);   
       				cell.setCellStyle(titleStyle);
     				cell = row1.createCell(colStart+2);   
       				cell.setCellStyle(titleStyle); 
       				sheet.addMergedRegion( new CellRangeAddress(1, 1, colStart, colStart+2) );

     				cell = row2.createCell(colStart);   
       				cell.setCellStyle(titleStyle);
       				cell.setCellValue(nidMessageSource.getMessage("sum"));  
     				cell = row2.createCell(colStart+1);   
       				cell.setCellStyle(titleStyle);
       				cell.setCellValue(nidMessageSource.getMessage("ml")); 
     				cell = row2.createCell(colStart+2);     				
       				cell.setCellStyle(titleStyle);
       				cell.setCellValue(nidMessageSource.getMessage("feml")); 
       				
       				colStart = colStart +3;
      			 } 
      		 }      		

    		//DATA Display
    		for(int k=0; k<lstProgram.size(); k++){
    			StsEpctSchAgVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+3); 
    		    
    			if ( "0001".equals(rowData.getPrvicNm()) ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getPrvicNm())|| "null".equals(rowData.getPrvicNm())){
    				prvicNm	= nidMessageSource.getMessage("frgn");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}

				if ( "0003".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getDstrNm()) || "null".equals(rowData.getDstrNm())){
    				dstrNm	= nidMessageSource.getMessage("frgn");
    			} else {
					dstrNm	= rowData.getDstrNm();
		   		} 
		   		  
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);
    		    
    		    cell  = row.createCell(2);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotCnt1());
    		    
    		    cell  = row.createCell(3);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt1());
    		    
    		    cell  = row.createCell(4);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt1());   
    		    
    		    cell  = row.createCell(5);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotCnt2());   

    		    cell  = row.createCell(6);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt2());   
    		    
    		    cell  = row.createCell(7);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt2());   

    		    cell  = row.createCell(8);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotCnt3());   

    		    cell  = row.createCell(9);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt3());   

    		    cell  = row.createCell(10);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt3());   

    		    cell  = row.createCell(11);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotCnt4());   

    		    cell  = row.createCell(12);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt4());   

    		    cell  = row.createCell(13);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt4());   

    		    cell  = row.createCell(14);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getTotCnt5());   

    		    cell  = row.createCell(15);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getMlCnt5());   

    		    cell  = row.createCell(16);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getFmlCnt5()); 
    		}

    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Life_Expectancy_for_School_Age.xls");
    		workbook.write(os);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 
    	
    }      
    
 
   
    //Get Font
    public  HSSFFont getFont(HSSFWorkbook workbook, int fontSize, boolean isBold){
   	      HSSFFont font = null;
          font = workbook.createFont();
          font.setFontHeightInPoints((short)fontSize);
          if(isBold) font.setBoldweight(Font.BOLDWEIGHT_BOLD);
   	      font.setColor(HSSFColor.BLACK.index);
   	      return font; 
   }	    
    	 
    //Get Title Style
    public  HSSFCellStyle getTitleStyle(HSSFWorkbook workbook){
    	 HSSFCellStyle style = null;
    	 style = workbook.createCellStyle();
    	 style.setFont(getFont(workbook, 14, true));
    	 style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
    	 style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
    	 
    	 return style;
    }	
    
    //Get Colum Title Style
    public  HSSFCellStyle getColumTitleStyle(HSSFWorkbook workbook,  boolean isBold, boolean isBG){
    	 HSSFCellStyle style = null;

    	 style = workbook.createCellStyle();

    	 style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
    	 style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
    	 
    	 if (isBG){
    		  style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
    		  style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    	 }
    	  
    	 style.setBorderBottom(CellStyle.BORDER_THIN);
    	 style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
    	 style.setBorderLeft(CellStyle.BORDER_THIN);
    	 style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
    	 style.setBorderRight(CellStyle.BORDER_THIN);
    	 style.setRightBorderColor(IndexedColors.BLACK.getIndex());
    	 style.setBorderTop(CellStyle.BORDER_THIN);
    	 style.setTopBorderColor(IndexedColors.BLACK.getIndex());
    	
    	 return style;
    }	    
    
	 
    //Get Colum Data Style
    public  HSSFCellStyle getColumDataStyle(HSSFWorkbook workbook,  String langType, boolean isBold, boolean isBG, boolean isNum){
    	HSSFCellStyle style = null;

    	style = workbook.createCellStyle();

    	style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);		
	 
    	if(isNum){
    		style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
    	} else {
    		if ("3".equals(langType)) {
    			style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
    		} else {
    			style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
    		} 
    	}
	 
    	if (isBG){
		  style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		  style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    	}
	  
	
    	style.setBorderBottom(CellStyle.BORDER_THIN);
    	style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
    	style.setBorderLeft(CellStyle.BORDER_THIN);
    	style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
    	style.setBorderRight(CellStyle.BORDER_THIN);
    	style.setRightBorderColor(IndexedColors.BLACK.getIndex());
    	style.setBorderTop(CellStyle.BORDER_THIN);
    	style.setTopBorderColor(IndexedColors.BLACK.getIndex());

	  return style;
    }	    
    
    //Get Colum Data Style
    public  HSSFCellStyle getColumDataStyleAlign(HSSFWorkbook workbook,  String langType, boolean isBold, boolean isBG, int align){
    	HSSFCellStyle style = null;

    	style = workbook.createCellStyle();

    	style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);		
	 
    	if(align == 1){
    		style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
    	} else if(align == 2){

			style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
    	} else {
    		style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
    	}
				
    	if (isBG){
		  style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		  style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    	}
	  
	
    	style.setBorderBottom(CellStyle.BORDER_THIN);
    	style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
    	style.setBorderLeft(CellStyle.BORDER_THIN);
    	style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
    	style.setBorderRight(CellStyle.BORDER_THIN);
    	style.setRightBorderColor(IndexedColors.BLACK.getIndex());
    	style.setBorderTop(CellStyle.BORDER_THIN);
    	style.setTopBorderColor(IndexedColors.BLACK.getIndex());

	  return style;
    }
    
    /**
     * Added to the list screen mobile<br>
     *
     *@param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param stsRgstStusVO Value-object of program to be parsed request(StsRgstStusVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "/rm/rsdt/StsRsdtRgstStusList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListRsdtRgstStusView.do")
    public String searchListRsdtRgstStusView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsRgstStusVO") StsRgstStusVO stsRgstStusVO,
    		ModelMap model)
            throws Exception {
    	try{
    		ComDefaultVO vo = new ComDefaultVO();
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsRgstStusVO.setUseLangCd(user.getUseLangCd());
    		stsRgstStusVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
    		vo.setAddDay("0");
    		vo = nidCmmService.searchGreToDay(vo);
    		
            if( "1".equals(user.getOrgnzClsCd()) ){
            	stsRgstStusVO.setSearchKeyword4(user.getOrgnzCd().substring(0,2)+"00");
            	stsRgstStusVO.setSearchKeyword5(user.getOrgnzCd().substring(0,4));
            }
            
    		stsRgstStusVO.setSearchKeyword2(vo.getStartDay().replaceAll("-", ""));
    		stsRgstStusVO.setSearchKeyword3(vo.getStartDay().replaceAll("-", ""));
    		model.addAttribute("stsRgstStusVO", stsRgstStusVO);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "/rm/sts/StsRsdtRgstStusList";
    }
	    
    /**
     * Enrollment is moved to the list screen. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param stsRgstStusVO Value-object of program to be parsed request(StsRgstStusVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "/rm/sts/StsRsdtRgstStusList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListRsdtRgstStus.do")
    public String searchListRsdtRgstStus(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsRgstStusVO") StsRgstStusVO stsRgstStusVO,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		stsRgstStusVO.setUseLangCd(user.getUseLangCd());
    		stsRgstStusVO.setOrgnzClsCd(user.getOrgnzClsCd());

	   		if("1".equals(user.getOrgnzClsCd())){
	   			stsRgstStusVO.setSearchKeyword4(stsRgstStusVO.getSearchKeyword7());
	   			stsRgstStusVO.setSearchKeyword5(stsRgstStusVO.getSearchKeyword8());
	   		}
	   		
	   		stsRgstStusVO.setPageUnit(propertiesService.getInt("pageUnit"));
	   		stsRgstStusVO.setPageSize(propertiesService.getInt("pageSize"));
	   		
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(stsRgstStusVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(stsRgstStusVO.getPageUnit());
			paginationInfo.setPageSize(stsRgstStusVO.getPageSize());
			stsRgstStusVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			stsRgstStusVO.setLastIndex(paginationInfo.getLastRecordIndex());
			stsRgstStusVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
	        List<StsRgstStusVO> lstProgram = service.searchListRsdtRgstStusInfr(stsRgstStusVO);
	        stsRgstStusVO.setListCn(lstProgram.size());
	        model.addAttribute("lstProgram", lstProgram);
	        
	        int totCnt = service.searchListRsdtRgstStusInfrTotCn(stsRgstStusVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);

	        
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/sts/StsRsdtRgstStusList";
    }	  
	    
    /**
     * Added to the list screen mobile<br>
     *
     *@param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param stsBsnWrkStusVO Value-object of program to be parsed request(StsBsnWrkStusVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "/rm/rsdt/StsRsdtRgstStusList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/seachListBsnWrkStusView.do")
    public String seachListBsnWrkStusView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsBsnWrkStusVO") StsBsnWrkStusVO stsBsnWrkStusVO,
    		ModelMap model)
            throws Exception {
    	try{
    		ComDefaultVO vo = new ComDefaultVO();
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
			
    		stsBsnWrkStusVO.setUseLangCd(user.getUseLangCd());
    		stsBsnWrkStusVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
    		stsBsnWrkStusVO.setProd("1");
    		
  
    		//vo = nidCmmService.searchGreToDay(vo);
    		vo = nidCmmService.searchGreAddToDay("-1"); 
			List<String> lstAthr = NidUserDetailsHelper.getAuthorities();
			
			String ofcalPsnCd ="";
			
		    if(lstAthr != null && lstAthr.size() == 1){
		       ofcalPsnCd = lstAthr.get(0);
		    }else if(lstAthr != null && lstAthr.size() > 1){
		    	
		       for(int i = 0; i < lstAthr.size(); i++){
		    	   String athr = lstAthr.get(i);
		    	   if("4".equals(athr) ){
		    		   ofcalPsnCd = athr;
		    	   }
		       }
	        } 

		    stsBsnWrkStusVO.setOfcalPsnCd(ofcalPsnCd);
		    
            if( "2".equals(user.getOrgnzClsCd()) && !"4".equals(ofcalPsnCd) ){
            	//stsBsnWrkStusVO.setSearchKeyword4(user.getOrgnzCd().substring(0,2)+"00");
            	//stsBsnWrkStusVO.setSearchKeyword5(user.getOrgnzCd());
            	stsBsnWrkStusVO.setOrgnzCd(user.getOrgnzCd());
            	
            	if("1".equals(user.getUseLangCd())) {
            		stsBsnWrkStusVO.setOrgnzNm(user.getPstOrgnzNm());
            	} else if("2".equals(user.getUseLangCd())){
            		stsBsnWrkStusVO.setOrgnzNm(user.getDrOrgnzNm());
            	} else if("3".equals(user.getUseLangCd())){
            		stsBsnWrkStusVO.setOrgnzNm(user.getEnOrgnzNm());            		
            	} else {
            		stsBsnWrkStusVO.setOrgnzNm(user.getPstOrgnzNm());
            	}            	
            }
                     
    		
            stsBsnWrkStusVO.setSearchKeyword2(vo.getStartDay().replaceAll("-", ""));
            stsBsnWrkStusVO.setSearchKeyword3(vo.getEndDay().replaceAll("-", ""));
    		model.addAttribute("stsBsnWrkStusVO", stsBsnWrkStusVO);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "/rm/sts/StsBsnWrkStusList";
    }
	    
    /**
     * moved to the list screen. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param stsBsnWrkStusVO Value-object of program to be parsed request(StsBsnWrkStusVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "/rm/sts/StsBsnWrkStus.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/seachListBsnWrkStus.do")
    public String seachListBsnWrkStus(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsBsnWrkStusVO") StsBsnWrkStusVO stsBsnWrkStusVO,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		
    		stsBsnWrkStusVO.setUseLangCd(user.getUseLangCd());
    		stsBsnWrkStusVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
			List<String> lstAthr = NidUserDetailsHelper.getAuthorities();
			
			String ofcalPsnCd ="";
			
		    if(lstAthr != null && lstAthr.size() == 1){
		       ofcalPsnCd = lstAthr.get(0);
		    }else if(lstAthr != null && lstAthr.size() > 1){
		    	
		       for(int i = 0; i < lstAthr.size(); i++){
		    	   String athr = lstAthr.get(i);
		    	   if("4".equals(athr) ){
		    		   ofcalPsnCd = athr;
		    	   }
		       }
	        } 
		    
		    stsBsnWrkStusVO.setOfcalPsnCd(ofcalPsnCd);

		    if("2".equals(user.getOrgnzClsCd()) && !"4".equals(ofcalPsnCd)){
            	if("1".equals(user.getUseLangCd())) {
            		stsBsnWrkStusVO.setOrgnzNm(user.getPstOrgnzNm());
            	} else if("2".equals(user.getUseLangCd())){
            		stsBsnWrkStusVO.setOrgnzNm(user.getDrOrgnzNm());
            	} else if("3".equals(user.getUseLangCd())){
            		stsBsnWrkStusVO.setOrgnzNm(user.getEnOrgnzNm());            		
            	} else {
            		stsBsnWrkStusVO.setOrgnzNm(user.getPstOrgnzNm());
            	} 		    	
		    }
		    
		    if(!"".equals(stsBsnWrkStusVO.getOrgnzCd())){
		    	
	            if( "00".equals(stsBsnWrkStusVO.getOrgnzCd().substring(2, 4)) ){
	            	stsBsnWrkStusVO.setOficTye("1");
	            } else{
	            	stsBsnWrkStusVO.setOficTye("2");
	            }		    	
		    }
		    
	   		stsBsnWrkStusVO.setPageUnit(propertiesService.getInt("pageUnit"));
	   		stsBsnWrkStusVO.setPageSize(propertiesService.getInt("pageSize"));
	   		
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(stsBsnWrkStusVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(stsBsnWrkStusVO.getPageUnit());
			paginationInfo.setPageSize(stsBsnWrkStusVO.getPageSize());
			stsBsnWrkStusVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			stsBsnWrkStusVO.setLastIndex(paginationInfo.getLastRecordIndex());
			stsBsnWrkStusVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
			List<StsBsnWrkStusVO> lstProgram = service.searchListBsnWrkStusInfr(stsBsnWrkStusVO);
	        stsBsnWrkStusVO.setListCn(lstProgram.size());
	        model.addAttribute("lstProgram", lstProgram);
	        
	        int totCnt = service.searchListBsnWrkStusInfrTotCn(stsBsnWrkStusVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);

	        
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/sts/StsBsnWrkStusList";
    }	  

    
    /**
     * moved to the list screen. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param stsBsnWrkStusVO Value-object of program to be parsed request(StsBsnWrkStusVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "/rm/sts/StsBsnWrkStus.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/seachListTamBsnWrkStus.do")
    public String seachListTamBsnWrkStus(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsBsnWrkStusVO") StsBsnWrkStusVO stsBsnWrkStusVO,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		
	        if("".equals(stsBsnWrkStusVO.getSearchKeyword())){
	        	stsBsnWrkStusVO.setSearchKeyword("j");
	        }
	        	        
    		stsBsnWrkStusVO.setUseLangCd(user.getUseLangCd());
    		stsBsnWrkStusVO.setOrgnzClsCd(user.getOrgnzClsCd());
    		
	   		stsBsnWrkStusVO.setPageUnit(propertiesService.getInt("pageUnit"));
	   		stsBsnWrkStusVO.setPageSize(propertiesService.getInt("pageSize"));
	   		
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(stsBsnWrkStusVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(stsBsnWrkStusVO.getPageUnit());
			paginationInfo.setPageSize(stsBsnWrkStusVO.getPageSize());
			stsBsnWrkStusVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			stsBsnWrkStusVO.setLastIndex(paginationInfo.getLastRecordIndex());
			stsBsnWrkStusVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

			List<StsBsnWrkStusVO> lstProgram = service.searchListTamBsnWrkStusInfr(stsBsnWrkStusVO);
	        stsBsnWrkStusVO.setListCn(lstProgram.size());
	        model.addAttribute("lstProgram", lstProgram);

	        int totCnt = service.searchListTamBsnWrkStusInfrTotCn(stsBsnWrkStusVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);

	        stsBsnWrkStusVO.setOrgnzNm(lstProgram.get(0).getOrgnzNm());
	        stsBsnWrkStusVO.sethStDd(lstProgram.get(0).gethStDd());
	        stsBsnWrkStusVO.sethEndDd(lstProgram.get(0).gethEndDd());
	        stsBsnWrkStusVO.setgStDd(lstProgram.get(0).getgStDd());
	        stsBsnWrkStusVO.setgEndDd(lstProgram.get(0).getgEndDd());
	        
	        model.addAttribute("langCd", user.getUseLangCd());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/sts/p_StsTamBsnWrkStusList";
    }	  
    
    /**
     * moved to the list screen. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param stsBsnWrkStusVO Value-object of program to be parsed request(StsBsnWrkStusVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "/rm/sts/StsBsnWrkStus.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/seachListUserBsnWrkStus.do")
    public String seachListUserBsnWrkStus(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsBsnWrkStusVO") StsBsnWrkStusVO stsBsnWrkStusVO,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
	        if("".equals(stsBsnWrkStusVO.getSearchKeyword())){
	        	stsBsnWrkStusVO.setSearchKeyword("j");
	        }	        
	        
    		stsBsnWrkStusVO.setUseLangCd(user.getUseLangCd());
    		stsBsnWrkStusVO.setOrgnzClsCd(user.getOrgnzClsCd());
 

	   		stsBsnWrkStusVO.setPageUnit(propertiesService.getInt("pageUnit"));
	   		stsBsnWrkStusVO.setPageSize(propertiesService.getInt("pageSize"));
	   		
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(stsBsnWrkStusVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(stsBsnWrkStusVO.getPageUnit());
			paginationInfo.setPageSize(stsBsnWrkStusVO.getPageSize());
			stsBsnWrkStusVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			stsBsnWrkStusVO.setLastIndex(paginationInfo.getLastRecordIndex());
			stsBsnWrkStusVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
	        List<StsBsnWrkStusVO> lstProgram = service.searchListUserBsnWrkStusInfr(stsBsnWrkStusVO);
	        stsBsnWrkStusVO.setListCn(lstProgram.size());
	        model.addAttribute("lstProgram", lstProgram);
	        	        
	        int totCnt = service.searchListUserBsnWrkStusInfrTotCn(stsBsnWrkStusVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);

	        stsBsnWrkStusVO.setOrgnzNm(lstProgram.get(0).getOrgnzNm());	 
	        stsBsnWrkStusVO.setTamNm(lstProgram.get(0).getTamNm());	
	        stsBsnWrkStusVO.sethStDd(lstProgram.get(0).gethStDd());
	        stsBsnWrkStusVO.sethEndDd(lstProgram.get(0).gethEndDd());
	        stsBsnWrkStusVO.setgStDd(lstProgram.get(0).getgStDd());
	        stsBsnWrkStusVO.setgEndDd(lstProgram.get(0).getgEndDd());
	        	        
	        model.addAttribute("langCd", user.getUseLangCd());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/sts/p_StsUserBsnWrkStusList";
    }	   
    
    /**
     *  Download Statistic  of Business Work Status to Excel.<br>
     * 
     * @param StsBsnWrkStusVO Value-object of Statistic  of Population by Present address to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListBsnWrkStusDownExcel.do")
    public void searchListBsnWrkStusDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsBsnWrkStusVO") StsBsnWrkStusVO stsBsnWrkStusVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFCell cell = null;
		
    	try {

    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsBsnWrkStusVO.setUseLangCd(user.getUseLangCd());
    		String orgnzCd = user.getOrgnzCd();
    		String district = orgnzCd.substring(0, 4); 
    		String teamCd = user.getTamCdNm();
    		stsBsnWrkStusVO.setOfficerNo(district+teamCd);
    		stsBsnWrkStusVO.setStsTitCd("1");
    		
    		String stsTitle = nidMessageSource.getMessage("emrtPfmcByOfic");

    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 14 * 256);
    		sheet.setColumnWidth(2, 18 * 256);
    		
    		for (int i=3; i<21; i++) {
    			sheet.setColumnWidth(i, 14 * 256);
    		}

    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 5) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);

            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsBsnWrkStusVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsBsnWrkStusVO.getUseLangCd(), false, false, true);
    		
    		//title : enrollment date
			cell = row1.createCell(0);   
			cell.setCellStyle(titleStyle);
			cell.setCellValue(nidMessageSource.getMessage("rgstDd")); 
			cell = row1.createCell(1);   
			cell.setCellStyle(titleStyle);    	      				
			sheet.addMergedRegion( new CellRangeAddress(1, 1, 0, 1) );
			
		 	cell = row2.createCell(0);   
		 	cell.setCellStyle(titleStyle);
		 	cell.setCellValue(nidMessageSource.getMessage("frmDd")); 
		 	
		 	cell = row2.createCell(1);   
		 	cell.setCellStyle(titleStyle);
		 	cell.setCellValue(nidMessageSource.getMessage("toDd"));
		 	
		 	
			//title : office
			cell = row1.createCell(2);   
			cell.setCellStyle(titleStyle);
			cell.setCellValue(nidMessageSource.getMessage("ofic")); 
			cell = row2.createCell(2);   
			cell.setCellStyle(titleStyle);    	      				
			sheet.addMergedRegion( new CellRangeAddress(1, 2, 2, 2) );
			 			 				
    		String[] title = { nidMessageSource.getMessage("fmlyErmt")
	                          ,nidMessageSource.getMessage("indiErmt")
	                          ,nidMessageSource.getMessage("apvdCtzn")
	                          ,nidMessageSource.getMessage("bioChkPassd")
	                          ,nidMessageSource.getMessage("bioChkFaild")
	                          ,nidMessageSource.getMessage("isuceRqstd")	                          
	                          ,nidMessageSource.getMessage("isud")
	                          ,nidMessageSource.getMessage("isuceFaild")
	                          ,nidMessageSource.getMessage("ditbd")
	                          ,nidMessageSource.getMessage("foms")
	                          ,nidMessageSource.getMessage("mbers")	                          	                          
	                          ,nidMessageSource.getMessage("ml")
	                          ,nidMessageSource.getMessage("feml")
	                          };
    		
    		int stVal  = 3;
    		int endVal = 4;
    		
			for(int i=0; i<9; i++){
				cell = row1.createCell(stVal);
				cell.setCellStyle(titleStyle);
				cell.setCellValue(title[i]);
				cell = row1.createCell(endVal);
				cell.setCellStyle(titleStyle);	
				sheet.addMergedRegion( new CellRangeAddress(1, 1, stVal, endVal) );
				stVal  = stVal +2;
				endVal = endVal+2;
			}
			
			for(int i=3; i<21; i++){
			 	cell = row2.createCell(i);   
   			 	cell.setCellStyle(titleStyle);
   			 	
   			 	if(i ==3 ){
   			 		cell.setCellValue(title[9]);
   			 	} else if(i==4){
   			 		cell.setCellValue(title[10]);
   			 	} else {
   			 		if( (i%2) == 1){   	   			 		
   	   			 		cell.setCellValue(title[11]);   			 			
   			 		} else {
   	   			 		cell.setCellValue(title[12]);   			 			
   			 		}
   			 	}
   			 	 
			}
			
            
    		int totCnt = service.searchListBsnWrkStusInfrTotCn(stsBsnWrkStusVO);
    		
    		int totPage = (int)Math.ceil((double)totCnt/1000);

    		//DATA Display
    		for(int j=0; j<totPage; j++){
    			
    			
    			stsBsnWrkStusVO.setFirstIndex(j*1000);
    			stsBsnWrkStusVO.setLastIndex(j+1);
    			
    			stsBsnWrkStusVO.setRecordCountPerPage(1000);
    			
    			List<StsBsnWrkStusVO> lstProgram = service.searchListBsnWrkStusInfr(stsBsnWrkStusVO);
    			
                String stDate ="";
                String endDate ="";
                
	    		for(int k=0; k<lstProgram.size(); k++){
	    			StsBsnWrkStusVO rowData = lstProgram.get(k);
	    			

	                if("j".equals(stsBsnWrkStusVO.getSearchKeyword())){
	        			stDate  = rowData.gethStDd();
	        			endDate = rowData.gethEndDd();             	
	                } else {
	    				stDate  = rowData.getgStDd();
	    				endDate = rowData.getgEndDd();  
	                }
	                
	    			row = sheet.createRow(k+3);	    			
	    			
	    		    cell  = row.createCell(0);	
	    		    cell.setCellStyle(valStyleStr);
	    		    cell.setCellValue(stDate);
	    			
	    		    cell  = row.createCell(1);	
	    		    cell.setCellStyle(valStyleStr);
	    		    cell.setCellValue(endDate);
	    		    
	    		    cell  = row.createCell(2);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getOrgnzNm());
	    		    
	    		    cell  = row.createCell(3);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getFmlyBokCn());
	    		    
	    		    cell  = row.createCell(4);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getFmlyMberCn());
	    		    
	    		    cell  = row.createCell(5);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getRgstMlCn());
	
	    		    cell  = row.createCell(6);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getRsgtFemlCn());
	    		    
	    		    cell  = row.createCell(7);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getAprvMlCn());
	
	    		    cell  = row.createCell(8);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getAprvFemlCn()); 
	
	    		    cell  = row.createCell(9);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getDptScsMlCn()); 
	
	    		    cell  = row.createCell(10);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getDptScsFemlCn());
	
	    		    cell  = row.createCell(11);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getDptFailMlCn());
	    		    
	    		    cell  = row.createCell(12);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getDptFailFemlCn()); 
	    		    
	    		    cell  = row.createCell(13);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdIsuceRqstMlCn());   
	    		    
	    		    cell  = row.createCell(14);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdIsuceRqstFemlCn());    		    
	    		    
	    		    cell  = row.createCell(15);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdIsuceScsMlCn()); 
	    		    
	    		    cell  = row.createCell(16);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdIsuceScsFemlCn());    	
	    		    
	    		    cell  = row.createCell(17);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdIsuceFailMlCn());
	    		    
	    		    cell  = row.createCell(18);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdIsuceFailFemlCn());    
	    		    
	    		    cell  = row.createCell(19);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdDitbMlCn());   
	    		    
	    		    cell  = row.createCell(20);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdDitbFemlCn());    		    
	    		}
	    		
	    		lstProgram.clear();
    		}
   		  
    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		
    		if("j".equals(stsBsnWrkStusVO.getSearchKeyword())){
    			comVo = nidCmmService.searchPerToDay(stsBsnWrkStusVO);
    			fileDate = NidStringUtil.toNumberConvet(comVo.getStartDay(), "g");
    		} else {
    			comVo = nidCmmService.searchGreToDay(stsBsnWrkStusVO);
    			fileDate = comVo.getStartDay();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Performace_By_office.xls");
    		workbook.write(os);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    }  

    /**
     *  Download Statistic  of Business Work Status to Excel.<br>
     * 
     * @param StsBsnWrkStusVO Value-object of Statistic  of Population by Present address to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListTamBsnWrkStusDownExcel.do")
    public void searchListTamBsnWrkStusDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsBsnWrkStusVO") StsBsnWrkStusVO stsBsnWrkStusVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFRow row3 = null;
		HSSFCell cell = null;
		HSSFCell cell3 = null;
		
    	try {

    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsBsnWrkStusVO.setUseLangCd(user.getUseLangCd());
    		String orgnzCd = user.getOrgnzCd();
    		String district = orgnzCd.substring(0, 4); 
    		String teamCd = user.getTamCdNm();
    		stsBsnWrkStusVO.setOfficerNo(district+teamCd);
    		stsBsnWrkStusVO.setStsTitCd("1");
    		
    		String stsTitle = nidMessageSource.getMessage("emrtPfmcByTam");

    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 14 * 256);
    		sheet.setColumnWidth(2, 18 * 256);
    		
    		for (int i=3; i<21; i++) {
    			sheet.setColumnWidth(i, 14 * 256);
    		}

    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 5) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row3 = sheet.createRow((short)1);
    		row3.setHeightInPoints(25);
    		sheet.addMergedRegion(new CellRangeAddress(1,1, 0, 5) );
    		cell3 = row3.createCell(0);
    		cell3.setCellStyle(getTitleStyle(workbook));
    		cell3.setCellValue(""); 
    		
    		row1 = sheet.createRow((short)2);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)3);
    		row2.setHeightInPoints(18);

            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsBsnWrkStusVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsBsnWrkStusVO.getUseLangCd(), false, false, true);
    		
    		//title : enrollment date
			cell = row1.createCell(0);   
			cell.setCellStyle(titleStyle);
			cell.setCellValue(nidMessageSource.getMessage("rgstDd")); 
			cell = row1.createCell(1);   
			cell.setCellStyle(titleStyle);    	      				
			sheet.addMergedRegion( new CellRangeAddress(2, 2, 0, 1) );
			
		 	cell = row2.createCell(0);   
		 	cell.setCellStyle(titleStyle);
		 	cell.setCellValue(nidMessageSource.getMessage("frmDd")); 
		 	
		 	cell = row2.createCell(1);   
		 	cell.setCellStyle(titleStyle);
		 	cell.setCellValue(nidMessageSource.getMessage("toDd"));
		 	
		 	
			//title : office
			cell = row1.createCell(2);   
			cell.setCellStyle(titleStyle);
			cell.setCellValue(nidMessageSource.getMessage("tamNo")); 
			cell = row2.createCell(2);   
			cell.setCellStyle(titleStyle);    	      				
			sheet.addMergedRegion( new CellRangeAddress(2, 3, 2, 2) );
			 			 				
    		String[] title = { nidMessageSource.getMessage("fmlyErmt")
	                          ,nidMessageSource.getMessage("indiErmt")
	                          ,nidMessageSource.getMessage("apvdCtzn")
	                          ,nidMessageSource.getMessage("bioChkPassd")
	                          ,nidMessageSource.getMessage("bioChkFaild")
	                          ,nidMessageSource.getMessage("isuceRqstd")	                          
	                          ,nidMessageSource.getMessage("isud")
	                          ,nidMessageSource.getMessage("isuceFaild")
	                          ,nidMessageSource.getMessage("ditbd")
	                          ,nidMessageSource.getMessage("foms")
	                          ,nidMessageSource.getMessage("mbers")	                          	                          
	                          ,nidMessageSource.getMessage("ml")
	                          ,nidMessageSource.getMessage("feml")
	                          };
    		
    		int stVal  = 3;
    		int endVal = 4;
    		
			for(int i=0; i<9; i++){
				cell = row1.createCell(stVal);
				cell.setCellStyle(titleStyle);
				cell.setCellValue(title[i]);
				cell = row1.createCell(endVal);
				cell.setCellStyle(titleStyle);	
				sheet.addMergedRegion( new CellRangeAddress(2, 2, stVal, endVal) );
				stVal  = stVal +2;
				endVal = endVal+2;
			}
			
			for(int i=3; i<21; i++){
			 	cell = row2.createCell(i);   
   			 	cell.setCellStyle(titleStyle);
   			 	
   			 	if(i ==3 ){
   			 		cell.setCellValue(title[9]);
   			 	} else if(i==4){
   			 		cell.setCellValue(title[10]);
   			 	} else {
   			 		if( (i%2) == 1){   	   			 		
   	   			 		cell.setCellValue(title[11]);   			 			
   			 		} else {
   	   			 		cell.setCellValue(title[12]);   			 			
   			 		}
   			 	}
   			 	 
			}
			
            String stDate ="";
            String endDate ="";

    		int totCnt = service.searchListTamBsnWrkStusInfrTotCn(stsBsnWrkStusVO);    		
    		int totPage = (int)Math.ceil((double)totCnt/1000);
    		String subTitle ="";
    		
    		//DATA Display
    		for(int j=0; j<totPage; j++){
    			
    			
    			stsBsnWrkStusVO.setFirstIndex(j*1000);
    			stsBsnWrkStusVO.setLastIndex(j+1);
    			
    			stsBsnWrkStusVO.setRecordCountPerPage(1000);
    			
    			List<StsBsnWrkStusVO> lstProgram = service.searchListTamBsnWrkStusInfr(stsBsnWrkStusVO);
    			
    			if(j == 0){
        			StsBsnWrkStusVO subTitleData = lstProgram.get(0);
        			
            		subTitle = nidMessageSource.getMessage("ofic")+ "  : " + subTitleData.getOrgnzNm();
            		cell3.setCellValue(subTitle);        			
    			}
    			
	    		for(int k=0; k<lstProgram.size(); k++){
	    			StsBsnWrkStusVO rowData = lstProgram.get(k);
	    			row = sheet.createRow(k+4);	    			
	    			
	                if("j".equals(stsBsnWrkStusVO.getSearchKeyword())){
	        			stDate  = rowData.gethStDd();
	        			endDate = rowData.gethEndDd();             	
	                } else {
	    				stDate  = rowData.getgStDd();
	    				endDate = rowData.getgEndDd();  
	                }
	                
	    		    cell  = row.createCell(0);	
	    		    cell.setCellStyle(valStyleStr);
	    		    cell.setCellValue(stDate);
	    			
	    		    cell  = row.createCell(1);	
	    		    cell.setCellStyle(valStyleStr);
	    		    cell.setCellValue(endDate);
	    		    
	    		    cell  = row.createCell(2);	
	    		    cell.setCellStyle(valStyleNum);
	    		    if(rowData.getTamNm() == null || "".equals(rowData.getTamNm()) ){
	    		    	cell.setCellValue(nidMessageSource.getMessage("bth"));
	    		    } else {
	    		    	cell.setCellValue(rowData.getTamNm());
	    		    }
	    		    
	    		    
	    		    cell  = row.createCell(3);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getFmlyBokCn());
	    		    
	    		    cell  = row.createCell(4);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getFmlyMberCn());
	    		    
	    		    cell  = row.createCell(5);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getRgstMlCn());
	
	    		    cell  = row.createCell(6);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getRsgtFemlCn());
	    		    
	    		    cell  = row.createCell(7);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getAprvMlCn());
	
	    		    cell  = row.createCell(8);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getAprvFemlCn()); 
	
	    		    cell  = row.createCell(9);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getDptScsMlCn()); 
	
	    		    cell  = row.createCell(10);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getDptScsFemlCn());
	
	    		    cell  = row.createCell(11);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getDptFailMlCn());
	    		    
	    		    cell  = row.createCell(12);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getDptFailFemlCn()); 
	    		    
	    		    cell  = row.createCell(13);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdIsuceRqstMlCn());   
	    		    
	    		    cell  = row.createCell(14);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdIsuceRqstFemlCn());    		    
	    		    
	    		    cell  = row.createCell(15);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdIsuceScsMlCn()); 
	    		    
	    		    cell  = row.createCell(16);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdIsuceScsFemlCn());    	
	    		    
	    		    cell  = row.createCell(17);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdIsuceFailMlCn());
	    		    
	    		    cell  = row.createCell(18);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdIsuceFailFemlCn());    
	    		    
	    		    cell  = row.createCell(19);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdDitbMlCn());   
	    		    
	    		    cell  = row.createCell(20);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getCrdDitbFemlCn());    		    
	    		}
	    		
	    		lstProgram.clear();
    		}
   		  
    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		
    		if("j".equals(stsBsnWrkStusVO.getSearchKeyword())){
    			comVo = nidCmmService.searchPerToDay(stsBsnWrkStusVO);
    			fileDate = NidStringUtil.toNumberConvet(comVo.getStartDay(), "g");
    		} else {
    			comVo = nidCmmService.searchGreToDay(stsBsnWrkStusVO);
    			fileDate = comVo.getStartDay();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Performace_By_Team.xls");
    		workbook.write(os);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }  
    
    
    /**
     *  Download Statistic  of Business Work Status to Excel.<br>
     * 
     * @param StsBsnWrkStusVO Value-object of Statistic  of Population by Present address to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListUserBsnWrkStusDownExcel.do")
    public void searchListUserBsnWrkStusDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsBsnWrkStusVO") StsBsnWrkStusVO stsBsnWrkStusVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFRow row3 = null;
		HSSFCell cell = null;
		HSSFCell cell3 = null;
		HSSFCell cell4 = null;
		
    	try {

    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsBsnWrkStusVO.setUseLangCd(user.getUseLangCd());
    		String orgnzCd = user.getOrgnzCd();
    		String district = orgnzCd.substring(0, 4); 
    		String teamCd = user.getTamCdNm();
    		stsBsnWrkStusVO.setOfficerNo(district+teamCd);
    		stsBsnWrkStusVO.setStsTitCd("1");
    		
    		String stsTitle = nidMessageSource.getMessage("emrtPfmcByUser");

    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 14 * 256);
    		sheet.setColumnWidth(2, 25 * 256);
    		sheet.setColumnWidth(3, 25 * 256);
    		
    		for (int i=4; i<8; i++) {
    			sheet.setColumnWidth(i, 14 * 256);
    		}
    		sheet.setColumnWidth(8, 21 * 256);
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 5) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row3 = sheet.createRow((short)1);
    		row3.setHeightInPoints(25);
    		sheet.addMergedRegion(new CellRangeAddress(1,1, 0, 2) );
    		cell3 = row3.createCell(0);
    		cell3.setCellStyle(getTitleStyle(workbook));
    		cell3.setCellValue(""); 
    		sheet.addMergedRegion(new CellRangeAddress(1,1, 3, 5) );
    		cell4 = row3.createCell(3);
    		cell4.setCellStyle(getTitleStyle(workbook));
    		cell4.setCellValue("");
    		
    		row1 = sheet.createRow((short)2);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)3);
    		row2.setHeightInPoints(18);

            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsBsnWrkStusVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsBsnWrkStusVO.getUseLangCd(), false, false, true);
    		
    		//title : enrollment date
			cell = row1.createCell(0);   
			cell.setCellStyle(titleStyle);
			cell.setCellValue(nidMessageSource.getMessage("rgstDd")); 
			cell = row1.createCell(1);   
			cell.setCellStyle(titleStyle);    	      				
			sheet.addMergedRegion( new CellRangeAddress(2, 2, 0, 1) );
			
		 	cell = row2.createCell(0);   
		 	cell.setCellStyle(titleStyle);
		 	cell.setCellValue(nidMessageSource.getMessage("frmDd")); 
		 	
		 	cell = row2.createCell(1);   
		 	cell.setCellStyle(titleStyle);
		 	cell.setCellValue(nidMessageSource.getMessage("toDd"));
		 	
		 	
			//title : officer
			cell = row1.createCell(2);   
			cell.setCellStyle(titleStyle);
			cell.setCellValue(nidMessageSource.getMessage("oficr")); 
			cell = row1.createCell(3);   
			cell.setCellStyle(titleStyle);    	      				
			sheet.addMergedRegion( new CellRangeAddress(2, 2, 2, 3) );

			
		 	cell = row2.createCell(2);   
		 	cell.setCellStyle(titleStyle);
		 	cell.setCellValue(nidMessageSource.getMessage("role")); 
		 	
		 	cell = row2.createCell(3);   
		 	cell.setCellStyle(titleStyle);
		 	cell.setCellValue(nidMessageSource.getMessage("nm"));
		 	
			//title : family
			cell = row1.createCell(4);   
			cell.setCellStyle(titleStyle);
			cell.setCellValue(nidMessageSource.getMessage("fmlyErmt")); 
			cell = row1.createCell(5);   
			cell.setCellStyle(titleStyle);    	      				
			sheet.addMergedRegion( new CellRangeAddress(2, 2, 4, 5) );

			
		 	cell = row2.createCell(4);   
		 	cell.setCellStyle(titleStyle);
		 	cell.setCellValue(nidMessageSource.getMessage("foms")); 
		 	
		 	cell = row2.createCell(5);   
		 	cell.setCellStyle(titleStyle);
		 	cell.setCellValue(nidMessageSource.getMessage("mbers"));
		 	
			//title : Individual
			cell = row1.createCell(6);   
			cell.setCellStyle(titleStyle);
			cell.setCellValue(nidMessageSource.getMessage("indiErmt")); 
			cell = row1.createCell(7);   
			cell.setCellStyle(titleStyle);    	      				
			sheet.addMergedRegion( new CellRangeAddress(2, 2, 6, 7) );

			
		 	cell = row2.createCell(6);   
		 	cell.setCellStyle(titleStyle);
		 	cell.setCellValue(nidMessageSource.getMessage("fom")); 
		 	
		 	cell = row2.createCell(7);   
		 	cell.setCellStyle(titleStyle);
		 	cell.setCellValue(nidMessageSource.getMessage("bio"));		 	
		 	
			//title : Individual		 	
		 	cell = row1.createCell(8);   
		 	cell.setCellStyle(titleStyle);
		 	cell.setCellValue(nidMessageSource.getMessage("apvdCtzn")); 		 	
		 	cell = row2.createCell(8);   
		 	cell.setCellStyle(titleStyle);
		 	sheet.addMergedRegion( new CellRangeAddress(2, 3, 8, 8) );
		 	
		 	
            String stDate ="";
            String endDate ="";
    		
    		int totCnt = service.searchListUserBsnWrkStusInfrTotCn(stsBsnWrkStusVO);
    		
    		int totPage = (int)Math.ceil((double)totCnt/1000);
    		String ofic ="";
    		String tam ="";
    		//DATA Display
    		for(int j=0; j<totPage; j++){
    			
    			
    			stsBsnWrkStusVO.setFirstIndex(j*1000);
    			stsBsnWrkStusVO.setLastIndex(j+1);
    			
    			stsBsnWrkStusVO.setRecordCountPerPage(1000);
    			
    			List<StsBsnWrkStusVO> lstProgram = service.searchListUserBsnWrkStusInfr(stsBsnWrkStusVO);
    			
    			if(j == 0){
        			StsBsnWrkStusVO subTitleData = lstProgram.get(0);
        			String tamNm = "";
        			
        			if(subTitleData.getTamNm() == null || "".equals(subTitleData.getTamNm())){
        				tamNm = nidMessageSource.getMessage("bth");
        			} else {
        				tamNm = subTitleData.getTamNm();
        			}
        			
        			ofic =  nidMessageSource.getMessage("ofic")+ "  : " + subTitleData.getOrgnzNm();
        			tam  =  nidMessageSource.getMessage("tamNo") + "  : " + tamNm;
        			log.debug("==========================================================");
        			log.debug("office : " + ofic);
        			log.debug("team : "+ tam);
        			log.debug("==========================================================");
            		cell3.setCellValue(ofic);   
            		cell4.setCellValue(tam); 
    			}

    			        		    		        		        
	    		for(int k=0; k<lstProgram.size(); k++){
	    			StsBsnWrkStusVO rowData = lstProgram.get(k);
	    			row = sheet.createRow(k+4);	    			
	    			
	                if("j".equals(stsBsnWrkStusVO.getSearchKeyword())){
	        			stDate  = rowData.gethStDd();
	        			endDate = rowData.gethEndDd();             	
	                } else {
	    				stDate  = rowData.getgStDd();
	    				endDate = rowData.getgEndDd();  
	                }	    			
	    		    cell  = row.createCell(0);	
	    		    cell.setCellStyle(valStyleStr);
	    		    cell.setCellValue(stDate);
	    			
	    		    cell  = row.createCell(1);	
	    		    cell.setCellStyle(valStyleStr);
	    		    cell.setCellValue(endDate);
	    		    
	    		    cell  = row.createCell(2);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getRoleNm());
	    		    
	    		    cell  = row.createCell(3);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getUserNm());
	    		    
	    		    cell  = row.createCell(4);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getFmlyBokCn());
	    		    
	    		    cell  = row.createCell(5);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getFmlyMberCn());
	
	    		    cell  = row.createCell(6);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getRgstCn());
	    		    
	    		    cell  = row.createCell(7);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getRgstBioCn());
	
	    		    cell  = row.createCell(8);	
	    		    cell.setCellStyle(valStyleNum);
	    		    cell.setCellValue(rowData.getAprvCn()); 
 		    
	    		}
	    		
	    		lstProgram.clear();
    		}
   		  
    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		
    		if("j".equals(stsBsnWrkStusVO.getSearchKeyword())){
    			comVo = nidCmmService.searchPerToDay(stsBsnWrkStusVO);
    			fileDate = NidStringUtil.toNumberConvet(comVo.getStartDay(), "g");
    		} else {
    			comVo = nidCmmService.searchGreToDay(stsBsnWrkStusVO);
    			fileDate = comVo.getStartDay();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Performace_By_User.xls");
    		workbook.write(os);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }      
    /**
     * Retrieves list of organization.  <br>
     * 
     * @param regionInfoVO Value-object of region to be parsed request(UserMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListBsnWrkStusProd.do")
    public void searchListBsnWrkStusProd(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsBsnWrkStusVO") StsBsnWrkStusVO stsBsnWrkStusVO,
			ModelMap model,
			HttpServletResponse response
			)
            throws Exception {
    	try {
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		
    		//Setting user Language
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsBsnWrkStusVO.setUseLangCd(user.getUseLangCd());

    		Element e_stDd;
    		Element e_endDd;
    		
    		String stDd ="";
    		String endDd="";
    		
    		ComDefaultVO comVo = new ComDefaultVO();

			Element	ddInfo = doc.createElement("ddInfo");
			root.appendChild(ddInfo);
			
			e_stDd  = doc.createElement("e_stDd");
			e_endDd = doc.createElement("e_endDd");

			if("5".equals(stsBsnWrkStusVO.getProd())){
				
		        if("j".equals(stsBsnWrkStusVO.getSearchKeyword())){
    			    stDd = service.searchBsnWrkStusStartPreDay(stsBsnWrkStusVO).replaceAll("-", "");
    				endDd= service.searchBsnWrkStusEndPreDay(stsBsnWrkStusVO).replaceAll("-", "");	    		        	
		        } else {			        	
    			    stDd  = service.searchBsnWrkStusStartGreDay(stsBsnWrkStusVO).replaceAll("-", "") ;
    				endDd = service.searchBsnWrkStusEndGreDay(stsBsnWrkStusVO).replaceAll("-", "");
		        }
		        
			} else if("4".equals(stsBsnWrkStusVO.getProd())){
				
		        if("j".equals(stsBsnWrkStusVO.getSearchKeyword())){		        	
		        	comVo = nidCmmService.searchPreYearFstDay(comVo);
    			    stDd = comVo.getStartDay().replaceAll("-", "");
    			    comVo = nidCmmService.searchPerToDay(comVo);
    				endDd= comVo.getStartDay().replaceAll("-", "");	    		        	
		        } else {
		        	comVo = nidCmmService.searchGreYearFstDay(comVo);		        	
    			    stDd  = comVo.getStartDay().replaceAll("-", "");
    			    comVo = nidCmmService.searchGreToDay1(comVo);
    				endDd = comVo.getStartDay().replaceAll("-", "");
		        }
		        
			} else {
		        if("j".equals(stsBsnWrkStusVO.getSearchKeyword())){				        
		        	comVo = nidCmmService.searchPreAddToDay("-1");
		        	stDd = comVo.getStartDay().replaceAll("-", "");
		        	endDd= comVo.getEndDay().replaceAll("-", "");				        	
		        } else {
		        	comVo = nidCmmService.searchGreAddToDay1("-1");
		        	stDd = comVo.getStartDay().replaceAll("-", "");
		        	endDd= comVo.getEndDay().replaceAll("-", "");					        	
		        }				
			}

    		e_stDd.appendChild(doc.createTextNode(stDd));	
    		e_endDd.appendChild(doc.createTextNode(endDd));
			
    		ddInfo.appendChild(e_stDd);
    		ddInfo.appendChild(e_endDd);
 		  
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);  		
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
   
    /**
     *  Download Statistic  of Population by Permanent address to Excel.<br>
     * 
     * @param StsPpltPmntAdVO Value-object of Download Statistic  of Population by Permanent address  to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsVtrPrsAdDownExcel.do")
    public void searchListStsVtrPrsAdDownExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFCell cell = null;
		
    	try {
    		String prvicNm = null;
    		String dstrNm = null;
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		stsSrchVO.setUseLangCd(user.getUseLangCd());

		    if(!"".equals(stsSrchVO.getAdCd())){
		    	
	            if( "00".equals(stsSrchVO.getAdCd().substring(2, 4)) ){
	            	stsSrchVO.setOficTye("1");
	            } else{
	            	stsSrchVO.setOficTye("2");
	            }		    	
		    }
		    
    		stsSrchVO.setStsTitCd("17");
    		
    		String stsTitle = service.searchStsTitle(stsSrchVO);
    		List<StsVtrPrsAdVO> lstProgram = service.searchListStsVtrPrsAd(stsSrchVO);
    		
    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 14 * 256);
    		sheet.setColumnWidth(1, 26 * 256);

    		for (int i=2; i<10; i++) {
    			sheet.setColumnWidth(i, 17 * 256);
    		}
    		
    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 4) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);
    		
    		String[] title = {nidMessageSource.getMessage("prvic")
			                 ,nidMessageSource.getMessage("dstr")
			                 ,nidMessageSource.getMessage("totVtr")
			                 ,nidMessageSource.getMessage("samePrvicDstr")
			                 ,nidMessageSource.getMessage("outPrvicDstr")
			                 ,nidMessageSource.getMessage("nValue")
			                 ,nidMessageSource.getMessage("ml")
			                 ,nidMessageSource.getMessage("feml")
			                 };
    		
            CellStyle titleStyle = getColumTitleStyle(workbook, true, true);            
    		CellStyle valStyleStr = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, false);
    		CellStyle valStyleNum = getColumDataStyle(workbook, stsSrchVO.getUseLangCd(), false, false, true);
    		
    		int startVal = 2;
    		int endval  = 3;
    		for(int i=0; i<title.length; i++){   
   			 	if(i < 2 ){    				 
   			 		cell = row1.createCell(i);    	
   				 	cell.setCellStyle(titleStyle);
   				 	cell.setCellValue(title[i]);
   				 	cell = row2.createCell(i);    	
   				 	cell.setCellStyle(titleStyle);    				 
   				 	sheet.addMergedRegion( new CellRangeAddress(1, 2, i, i) );
   			 	} else if (i > 1 && i< 6){ 
   			 		cell = row1.createCell(startVal);    	
   				 	cell.setCellStyle(titleStyle);
   				 	cell.setCellValue(title[i]);
   				 	cell = row1.createCell(endval);    	
   				 	cell.setCellStyle(titleStyle);    				 
   				 	sheet.addMergedRegion( new CellRangeAddress(1, 1, startVal, endval) );
	   				startVal = startVal +2;
	   				endval = endval +2;
   			 	} else if(i == 6){
   			 		for(int j=2; j<10;){
   	   			 		cell = row2.createCell(j);   
   	   			 		cell.setCellStyle(titleStyle);
   	   			 		cell.setCellValue(title[6]);  
   	   			 		cell = row2.createCell(j+1);   
   	   			 		cell.setCellStyle(titleStyle);
   	   			 		cell.setCellValue(title[7]);  
   	   			 		j=j+2;
   			 		}   			 		
   			 	}    			    		
    		}

    		//Data Display
    		for(int k=0; k<lstProgram.size(); k++){
    			StsVtrPrsAdVO rowData = lstProgram.get(k);
    			row = sheet.createRow(k+3);
    			
    			if ( "0001".equals(rowData.getPrvicNm())  ) {
    				prvicNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getPrvicNm()) || "null".equals(rowData.getPrvicNm())){
    				prvicNm	= nidMessageSource.getMessage("frgn");
    			} else {
    				prvicNm	= rowData.getPrvicNm();
    		   	}

				if ( "0003".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("subTot");
				} else if ( "0002".equals(rowData.getDstrNm()) ) {
					dstrNm = nidMessageSource.getMessage("grndTot");
    			} else if(rowData.getPrvicNm() == null || "".equals(rowData.getDstrNm()) || "null".equals(rowData.getDstrNm()) ){
    				dstrNm	= nidMessageSource.getMessage("frgn");
    			} else {
					dstrNm	= rowData.getDstrNm();
		   		}  
    	
    		    cell  = row.createCell(0);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(prvicNm);
    			
    		    cell  = row.createCell(1);	
    		    cell.setCellStyle(valStyleStr);
    		    cell.setCellValue(dstrNm);
    		    
    		    cell  = row.createCell(2);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getDatCnMl1());
    		    
    		    cell  = row.createCell(3);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getDatCnFm1());
    		    
    		    cell  = row.createCell(4);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getDatCnMl2());   
    		    
    		    cell  = row.createCell(5);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getDatCnFm2());  
    		    
    		    cell  = row.createCell(6);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getDatCnMl3());
    		    
    		    cell  = row.createCell(7);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getDatCnFm3());

    		    cell  = row.createCell(8);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getDatCnMl4());
    		    
    		    cell  = row.createCell(9);	
    		    cell.setCellStyle(valStyleNum);
    		    cell.setCellValue(rowData.getDatCnFm4());    		    
    		}

    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		if("j".equals(stsSrchVO.getSearchKeyword6())){
    			fileDate = NidStringUtil.toNumberConvet(stsSrchVO.getSearchKeyword(),"g");
    		} else {
    			fileDate = stsSrchVO.getSearchKeyword2();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Population_by_Permanent_Address.xls");
    		workbook.write(os);    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}  

    }
    
    
    
    public  HSSFCellStyle getColumDataStyle(HSSFWorkbook workbook,  String langType, boolean isBold, boolean isNum){
    	HSSFCellStyle style = null;

    	style = workbook.createCellStyle();

    	style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);		
	 
    	if(isNum){
    		style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
    	} else {
    		if ("3".equals(langType)) {
    			style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
    		} else {
    			style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
    		} 
    	}
	 
    	style.setFillForegroundColor(HSSFColor.RED.index);
    	style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	  
	
    	style.setBorderBottom(CellStyle.BORDER_THIN);
    	style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
    	style.setBorderLeft(CellStyle.BORDER_THIN);
    	style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
    	style.setBorderRight(CellStyle.BORDER_THIN);
    	style.setRightBorderColor(IndexedColors.BLACK.getIndex());
    	style.setBorderTop(CellStyle.BORDER_THIN);
    	style.setTopBorderColor(IndexedColors.BLACK.getIndex());

	  return style;
    }
    
    
    
    
    
    
    
    
    /**
     * Moved to list-screen of Statistics. <br>
     *
     * @param CmCmmCdVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsEcptRsdtList.jsp  "
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsEcptRsdtView.do")
    public String searchListStsEcptRsdtView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		@ModelAttribute("cdGrpVO") CdGrpVO cdGrpVO,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(), cdGrpVO.getCurMnId());
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("81");
			List<CmCmmCdVO> cdLst = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("cdLst", cdLst);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsEcptRsdtList";    
    }
    
    
    
    /**
     * Moved to list-screen of Statistics. <br>
     *
     * @param CmCmmCdVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/StsEcptRsdtList.jsp  "
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListStsEcptRsdt.do")
    public String searchListStsEcptRsdt(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("stsSrchVO") StsSrchVO stsSrchVO,
    		ModelMap model)
            throws Exception {
    	try {
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("81");
			List<CmCmmCdVO> cdLst = cmmCdMngService.searchListCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("cdLst", cdLst);
			
			List<EgovMap> gnrLst = service.searchListRmEcptRsdtTbGb(stsSrchVO);
			model.addAttribute("gnrLst", gnrLst);
			
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			stsSrchVO.setUseLangCd(user.getUseLangCd());
	   		
			stsSrchVO.setPageUnit(propertiesService.getInt("pageUnit"));
			stsSrchVO.setPageSize(propertiesService.getInt("pageSize"));
	   		
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(stsSrchVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(stsSrchVO.getPageUnit());
			paginationInfo.setPageSize(stsSrchVO.getPageSize());
			stsSrchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			stsSrchVO.setLastIndex(paginationInfo.getLastRecordIndex());
			stsSrchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
	        List<EgovMap> lstProgram = service.searchListStsEcptRsdt(stsSrchVO);
	        model.addAttribute("lstProgram", lstProgram);
	        int totCnt = service.searchListStsEcptRsdtTotCn(stsSrchVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/sts/StsEcptRsdtList";
    }
    
    /**
     * Moved to list-screen of Statistics. <br>
     *
     * @param CmCmmCdVO Value-object of statistic to be parsed request(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: 
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchStsEcptRsdtGnrDd.do")
    public void searchStsEcptRsdtGnrDd(
    		ModelMap model,
    		HttpServletResponse response,
    		@ModelAttribute("stsSrchVO") StsSrchVO vo)
            throws Exception {
    	try{
    		List<EgovMap> list = service.searchListRmEcptRsdtTbGb(vo);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element eleInfo = null;
    		Element ele = null;
    		if(list != null){
    			for(int i=0; i<list.size(); i++){
        			EgovMap ems = list.get(i);
        			if(ems != null){
    	    			eleInfo = doc.createElement("list");
    	    			root.appendChild(eleInfo);
    	    			ele = doc.createElement("crnDd");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("crnDd")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("dd");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("dd")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("ddCon");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("ddCon")) ));
    	    			eleInfo.appendChild(ele);
        			}
    	    	}
    		}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
} 