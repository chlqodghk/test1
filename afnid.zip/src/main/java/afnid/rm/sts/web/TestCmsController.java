package afnid.rm.sts.web;

/* java API */

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.pkiif.cpki.CpkiRmWS;
import afnid.pkiif.cpki.CpkiRmWSService;


/** 
 * This Controller class processes request of resident-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Moon Soo Kim
 * @since 22013.05.23
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.05.23  		Moon Soo Kim		                    Create
 *
 * </pre>
 */

@Controller
public class TestCmsController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
	
    @RequestMapping(value="/rm/sts/searchTestCms.do")
    public void  searchTestStsGnr(
    		ModelMap model)
            throws Exception {    		
    	try {    	
    		log.debug("#############################################################");
    		log.debug("cms test start");
    		CpkiRmWSService orws= new CpkiRmWSService();
    		log.debug("CpkiRmWSService = " + orws);
    		CpkiRmWS orw = orws.getCpkiRmWSPort();
    		log.debug("CpkiRmWS = " + orw);
    		log.debug("cms test end");
    		log.debug("#############################################################");
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 

    }
} 