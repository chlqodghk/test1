package afnid.rm.sts.web;

/* java API */

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.sts.service.FlxbRpotService;
import afnid.rm.sts.service.FlxbRpotVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;


/** 
 * This Controller class processes request of resident-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Moon Soo Kim
 * @since 2014.03.13
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           				    Revisions
 *   2014.03.13  		Moon Soo Kim		                    Create
 *
 * </pre>
 */

@Controller
public class FlxbRpotController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

	@Resource(name = "flxbRpotService")
    private FlxbRpotService service;
	
    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;

    /** lgService */
	@Resource(name = "lgService")
    private LgService lgService;
	
	/** NidCommonService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCmmService;
	
	
 	/**
     * Move to list screen of flexible report request. <br>
     *
     * @param CmCmmCdVO Value-object of program to be parsed request(searchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/RpotRqstList.jsp  "
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListRpotRqstView.do")
    public String  searchListRpotRqstView(
    		@ModelAttribute("flxbRpotVO") FlxbRpotVO flxbRpotVO,
    		ModelMap model)
            throws Exception {    		
    	
    	try {    	
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();    		
    		lgService.addUserWrkLg(user.getUserId(), flxbRpotVO.getCurMnId());

    		ComDefaultVO vo = new ComDefaultVO();
    		vo = nidCmmService.searchGreAddToDay("-1"); 
    		
    		flxbRpotVO.setSearchKeyword2(vo.getStartDay().replaceAll("-", ""));
    		flxbRpotVO.setSearchKeyword3(vo.getEndDay().replaceAll("-", ""));
    		model.addAttribute("flxbRpotVO", flxbRpotVO);    
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 
    	
    	return "/rm/sts/RpotRqstList";
    }
    
 	/**
     * Retrieves list of flexible report request. <br>
     *
     * @param CmCmmCdVO Value-object of statistic to be parsed request(stsSrchVO)
     * 
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/RpotRqstList.jsp  "
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListRpotRqst.do")
    public String  searchListRpotRqst(
    		@ModelAttribute("flxbRpotVO") FlxbRpotVO flxbRpotVO,
    		ModelMap model)
            throws Exception {    		
    	
    	try {    	
    		
    		flxbRpotVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		flxbRpotVO.setPageSize(propertiesService.getInt("pageSize"));
	   		
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(flxbRpotVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(flxbRpotVO.getPageUnit());
			paginationInfo.setPageSize(flxbRpotVO.getPageSize());
			flxbRpotVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			flxbRpotVO.setLastIndex(paginationInfo.getLastRecordIndex());
			flxbRpotVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
			List<FlxbRpotVO> lstFlxbRpotRqst = service.searchListRpotRqst(flxbRpotVO);
	        model.addAttribute("lstFlxbRpotRqst", lstFlxbRpotRqst);
	        
	        int totCnt = service.searchListRpotRqstTotCn(flxbRpotVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 
    	
    	return "/rm/sts/RpotRqstList";

    }
    
    /**
     * Move to request screen of flexible report. <br>
     *
     * @param CmCmmCdVO Value-object for request generation of statistics(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/RpotRqstIns.jsp  "
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/addRpotRqstView.do")
    public String  addRpotRqstView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("flxbRpotVO") FlxbRpotVO flxbRpotVO,
    		ModelMap model)
            throws Exception {    		
    	
    	try {  
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("76"); // Setting Group Code
    		List<CmCmmCdVO> cndList = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("cndList", cndList);
    		
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		cndList = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("curtAdNatCd", cndList);
    		model.addAttribute("bthNatCd", cndList);
    		model.addAttribute("secdNltyCd", cndList);
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		cndList = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("gdrCd", cndList);
    		cmCmmCd.setGrpCd("5"); // Setting Group Code
    		cndList = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("eduCd", cndList);
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		cndList = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("bldTyeCd", cndList);
    		cmCmmCd.setGrpCd("12"); // Setting Group Code
    		cndList = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("mrrgCd", cndList);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		cndList = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("fmlyLangCd", cndList);
    		model.addAttribute("othrNatLangCd", cndList);
    		cmCmmCd.setGrpCd("8"); // Setting Group Code
    		cndList = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("frgnLangCd", cndList);
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		cndList = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("rlgnCd", cndList);
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		cndList = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("rlgnSectCd", cndList);
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		cndList = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("encyCd", cndList);
    		cmCmmCd.setGrpCd("68"); // Setting Group Code
    		cndList = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("dsbtCd", cndList);
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		cndList = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("mltSrvcCd", cndList);
    		cmCmmCd.setGrpCd("20"); // Setting Group Code
    		cndList = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("rsdtStusCd", cndList);
    		
    		int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		cmCmmCd.setGrpCd("77"); // Setting Group Code
    		cndList = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		List<EgovMap> abs = new ArrayList<EgovMap>();
    		List<EgovMap> absSort = new ArrayList<EgovMap>();
    		if(cndList != null && !cndList.isEmpty()){
    			int limit = 3;
    			int mod = cndList.size()%limit;
    			Object obj = null;
    			for(int i = 0; i < cndList.size(); i++){
    				obj = (Object)cndList.get(i);
    				abs.add((EgovMap)obj);
				}
    			if(mod != 0){
    				for(int i = 0; i < (limit-mod); i++){
    					abs.add(new EgovMap());
    				}
    			}
				int k = (limit-1);
				EgovMap imVO = null;
				while(abs.size() != 0){
					imVO = (EgovMap)abs.get(k);
					abs.remove(k);
					absSort.add(imVO);
					k--;
					if(k == -1){
						k = (limit-1);
					}
				}
    			model.addAttribute("outputList", absSort);
    		}else{
    			model.addAttribute("outputList", cndList);
    		}
    		
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCmmService.searchPerToDay(flxbRpotVO);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		comVo = nidCmmService.searchGreToDay(flxbRpotVO);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		int cndTableRowView = 0;
    		try{
    			cndTableRowView = propertiesService.getInt("stsCndTableRowView");
    		}catch(Exception e){
    			cndTableRowView = 5;
    		}
    		model.addAttribute("cndTableRowView", cndTableRowView);
    		
    		cndTableRowView = 0;
    		try{
    			cndTableRowView = propertiesService.getInt("stsCndChkMinLn");
    		}catch(Exception e){
    			cndTableRowView = 5;
    		}
    		model.addAttribute("stsCndChkMinLn", cndTableRowView);
    		
    		cndTableRowView = 0;
    		try{
    			cndTableRowView = propertiesService.getInt("stsOutputChkMinLn");
    		}catch(Exception e){
    			cndTableRowView = 1;
    		}
    		model.addAttribute("stsOutputChkMinLn", cndTableRowView);
    		
    		model.addAttribute("flxbRpotVO", new FlxbRpotVO());
    		
     			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 

    	return "/rm/sts/RpotRqstIns";
    }
    
 
 	/**
     * Register request of flexible report. <br>
     *
     * @param CmCmmCdVO Value-object for request generation of statistics(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/RpotRqstList.jsp  "
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/addRpotRqst.do")
    public String  addRpotRqst(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("flxbRpotVO") FlxbRpotVO flxbRpotVO,
    		ModelMap model)
            throws Exception {  
    	String returnPage = "forward:/rm/sts/searchListRpotRqst.do";
    	try {  
    		service.addRpotRqst(flxbRpotVO);
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); 
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    		returnPage = "forward:/rm/sts/addRpotRqstView.do";
    	} 
    	return returnPage; 
    }
    

 	/**
     * Retrieves Condition of Flexible Report. <br>
     *
     * @param CmCmmCdVO Value-object for request generation of statistics(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/p_RpotConList.jsp  "
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListRpotCndView.do")
    public String  searchListRpotCndView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("flxbRpotVO") FlxbRpotVO flxbRpotVO,
    		ModelMap model)
            throws Exception {    		
    	
    	try {  
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("langCd", user.getUseLangCd());

    		flxbRpotVO.setSortDescYn("N");
    		
    		List<FlxbRpotVO> lstRpotCnd = service.searchListRpotCnd(flxbRpotVO);
    		model.addAttribute("lstRpotCnd", lstRpotCnd);
    		
    		int lstRpotCndCn =lstRpotCnd.size();
    		model.addAttribute("lstRpotCndCn", lstRpotCndCn);
    		    	
    		List<FlxbRpotVO> lstRpotItem = service.searchListRpotItem(flxbRpotVO);
    		model.addAttribute("lstRpotItem", lstRpotItem);
    		
    		int modCn = lstRpotItem.size() % 3;
    		int startCn = lstRpotItem.size();

    		if(modCn == 1){
    			modCn = 2;
    		} else if(modCn == 2){
    			modCn = 1;
    		}
    		
    		if(startCn % 3 !=0){
	    		for(int i=startCn; i<(startCn+modCn); i++){
	    			lstRpotItem.add(new FlxbRpotVO());
	    		}
    		}

    		model.addAttribute("lstRpotItemCn", startCn);

    		int rowCnArray = (int)Math.ceil(startCn / 3.0);
 
    		String [][] datRow = new String[rowCnArray][6];
    		
    		FlxbRpotVO rowVo = new FlxbRpotVO();
    		int modVal = 0;
    		int j =0;
    		for(int i=1; i<lstRpotItem.size()+1; i++){
    			rowVo = lstRpotItem.get(i-1);
    			modVal = i%3;
    			
    			if(modVal == 1){
	    			datRow[j][4] = rowVo.getRpotItemCdNm();
	    			if(rowVo.getRpotItemCdNm() == null){
	    				datRow[j][5] = "";
	    			} else {
	    				datRow[j][5] = String.valueOf(i);
	    			}
    			} else if(modVal == 2){
	    			datRow[j][2] = rowVo.getRpotItemCdNm();
	    			if(rowVo.getRpotItemCdNm() == null){
	    				datRow[j][3] = "";
	    			} else {
	    				datRow[j][3] = String.valueOf(i);
	    			}	    			
	    			    				
    			}else {
	    			datRow[j][0] = rowVo.getRpotItemCdNm();
	    			
	    			if(rowVo.getRpotItemCdNm() == null){
	    				datRow[j][1] = "";
	    			} else {
	    				datRow[j][1] = String.valueOf(i);
	    			}	    			

	    			j=j+1;
    			}    	
    		}

    		model.addAttribute("lstDatRow", datRow);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 

    	return  "/rm/sts/p_RpotCndList"; 
    }
    
 	/**
     * Retrieves Result of Flexible Report. <br>
     *
     * @param CmCmmCdVO Value-object for request generation of statistics(stsSrchVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/sts/p_RpotConList.jsp  "
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/searchListRpotRustView.do")
    public String  searchListRpotRustView(
    		@ModelAttribute("flxbRpotVO") FlxbRpotVO flxbRpotVO,
    		ModelMap model)
            throws Exception {    		
    	
    	try {  
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	    		   		
    		model.addAttribute("langCd", user.getUseLangCd()); 
    		
    		int rsdtNoUnMskLen = propertiesService.getInt("rsdtNoUnMskLen");
    		if(rsdtNoUnMskLen > 13){
    			flxbRpotVO.setRsdtNoUnMskLen("13");
    		} else {
    			flxbRpotVO.setRsdtNoUnMskLen(String.valueOf(rsdtNoUnMskLen));
    		}
    		
    		int nmUnMskLen = propertiesService.getInt("nmUnMskLen");
    		if(nmUnMskLen < 1){
    			flxbRpotVO.setNmUnMskLen("1");
    		} else {
    			flxbRpotVO.setNmUnMskLen(String.valueOf(nmUnMskLen));
    		}
    		
    		int enNmUnMskLen = propertiesService.getInt("enNmUnMskLen");
    		if(nmUnMskLen < 1){
    			flxbRpotVO.setEnNmUnMskLen("1");
    		} else {
    			flxbRpotVO.setEnNmUnMskLen(String.valueOf(enNmUnMskLen));
    		}
    		
    		if(flxbRpotVO.getRcdCnPerPage() == null || "".equals(flxbRpotVO.getRcdCnPerPage())){
    			flxbRpotVO.setPageUnit(10); 
    		} else {
    			flxbRpotVO.setPageUnit(Integer.parseInt(flxbRpotVO.getRcdCnPerPage())); 
    		}
    		
    		flxbRpotVO.setPageSize(propertiesService.getInt("pageSize"));
    		flxbRpotVO.setSortDescYn("Y");
    		
    		
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(flxbRpotVO.getPageIndex());			
			paginationInfo.setRecordCountPerPage(flxbRpotVO.getPageUnit());
			paginationInfo.setPageSize(flxbRpotVO.getPageSize());
			
			flxbRpotVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			flxbRpotVO.setLastIndex(paginationInfo.getLastRecordIndex());
			flxbRpotVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

			String dtm = service.searchGnrTime(flxbRpotVO);
			String [] arg = new String[1];
			arg[0]=	dtm;

			model.addAttribute("rpotRustGnr", nidMessageSource.getMessage("rpotRustGnr", arg));
			
    		List<FlxbRpotVO> lstRpotCnd = service.searchListRpotCnd(flxbRpotVO);
    		model.addAttribute("lstRpotCnd", lstRpotCnd);
    		    		
    		String lstRpotItemTotWdth = service.searchRpotItemTotWdth(flxbRpotVO);
    		model.addAttribute("lstRpotItemTotWdth", lstRpotItemTotWdth);
    		
    		flxbRpotVO.setSortDescYn("N");
    		
    		List<FlxbRpotVO> lstRpotItemWdth = service.searchListRpotItemWdth(flxbRpotVO);
    		model.addAttribute("lstRpotItemWdth", lstRpotItemWdth);
    		
    		List<FlxbRpotVO> lstRpotItem = service.searchListRpotItem(flxbRpotVO);
    		model.addAttribute("lstRpotItem", lstRpotItem);
    		
			List<FlxbRpotVO> lstFlxbRpotRust = service.searchListRpotRust(flxbRpotVO);
	        model.addAttribute("lstFlxbRpotRust", lstFlxbRpotRust);
	        
	        FlxbRpotVO vo = new FlxbRpotVO();
	        FlxbRpotVO vo1 = new FlxbRpotVO();
	        String othrLang = "";
	        String frgnLang = "";
	        for(int i=0;i<lstFlxbRpotRust.size();i++){
	        	vo = lstFlxbRpotRust.get(i);
	        	vo1.setSeqNo(vo.getSeqNo());
	        	vo1.setRsutSeqNo(vo.getRsutSeqNo());
	        	
				List<FlxbRpotVO> lstFlxbRpotRustOthrLang = service.searchListRpotRustOthrLang(vo1);
		        model.addAttribute("lstFlxbRpotRustOthrLang", lstFlxbRpotRustOthrLang);
		        
		        FlxbRpotVO lst = new FlxbRpotVO();
		        if(lstFlxbRpotRustOthrLang != null && lstFlxbRpotRustOthrLang.size() > 0){
		        	for(int j=0;j<lstFlxbRpotRustOthrLang.size();j++){
		        		lst = lstFlxbRpotRustOthrLang.get(j);
		        		if(j != (lstFlxbRpotRustOthrLang.size()-1)){
		        			othrLang = othrLang + lst.getOthrNatLangCdNm()+",";
		        		} else {
		        			othrLang = othrLang + lst.getOthrNatLangCdNm();
		        		}
		        	}
		        }
		        
				List<FlxbRpotVO> lstFlxbRpotRustFrgnLang = service.searchListRpotRustFrgnLang(vo1);
		        model.addAttribute("lstFlxbRpotRustFrgnLang", lstFlxbRpotRustFrgnLang);	
		        
		        if(lstFlxbRpotRustFrgnLang != null && lstFlxbRpotRustFrgnLang.size() > 0){
		        	for(int j=0;j<lstFlxbRpotRustFrgnLang.size();j++){
		        		lst = lstFlxbRpotRustFrgnLang.get(j);
		        		if(j != (lstFlxbRpotRustFrgnLang.size()-1)){
		        			frgnLang = frgnLang + lst.getFrgnLangCdNm()+", ";
		        		} else {
		        			frgnLang = frgnLang + lst.getFrgnLangCdNm();
		        		}
		        	}		        	
		        }
		        
		        vo.setOthrNatLangCdNm(othrLang);
		        vo.setFrgnLangCdNm(frgnLang);
		        
		        othrLang = "";
		        frgnLang = "";		        
	        }

	        
	        int totCnt = service.searchListRpotRustTotCn(flxbRpotVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
     			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	} 

    	return  "/rm/sts/p_RpotRsutList"; 
    }
    
    /**
     * Add view log of citizen information.  <br>
     * 
     * @param regionInfoVO Value-object of region to be parsed request(UserMngVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:""
     * @exception Exception
     */
    @RequestMapping(value="/rm/sts/addRsdtInfrLogAjx.do")
    public void addRsdtInfrLogAjx(
    		@ModelAttribute("flxbRpotVO") FlxbRpotVO flxbRpotVO,
			ModelMap model,
			HttpServletResponse response
			)
            throws Exception {
    	try {
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		
    		String dat = flxbRpotVO.getRsdtNo();
    		String [] rowDat = dat.split(",");
    		FlxbRpotVO vo = new FlxbRpotVO();
    		for(int i=0;i<rowDat.length;i++){
    			vo.setRsdtNo(rowDat[i]);
    			service.addRsdtInfrLog(vo);			
    		}
    		        		  
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);  		
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }        
} 