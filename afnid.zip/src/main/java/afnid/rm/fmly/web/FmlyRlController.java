package afnid.rm.fmly.web;

/* java API */
import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.fmly.service.FmlyRlService;
import afnid.rm.fmly.service.FmlyRlVO;
import afnid.rm.hst.service.RsdtInfrLgService;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/** 
 * This Controller class processes request of family-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.05.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.05.21  		BH Choi         						Create
 *
 * </pre>
 */
@Controller
public class FmlyRlController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /** NidProgrmManageService */
	@Resource(name = "fmlyRlService")
    private FmlyRlService service;
	
	@Resource(name = "rsdtInfrLgService")
    private RsdtInfrLgService rsdtInfrLgService;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    @Resource(name = "lgService")
    private LgService lgService;
	
    /**
     * Family tree to move to the registration screen.. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyRlVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyTree.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/searchFmlyTreeView.do")
    public String searchFmlyTreeView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("fmlyRlVO") FmlyRlVO vo,
    		ModelMap model) throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/fmly/FmlyTree";
    }
    
    /**
     * Family tree to move to the registration screen.. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyRlVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyTree.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/searchFmlyTree.do")
    public String searchFmlyTree(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("fmlyRlVO") FmlyRlVO vo,
    		ModelMap model) throws Exception {
    	try {
    		String strNm = service.selectFmlyRlNm(vo);
    		String str = service.selectFmlyRl(vo);
    		if("-1".equals(str)){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstEnid.msg"));
    			model.addAttribute("strNmMsg", "-1");
    			model.addAttribute("result", "");
    		}else{
    			model.addAttribute("strNmMsg", "1");
    			model.addAttribute("strNm", strNm);
    			model.addAttribute("result", str);
    		}
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/fmly/FmlyTree";
    }
    
    
    /**
     * Family tree to move to the registration screen.. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyRlVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyTreeRqstList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/searchFmlyTreeRqstView.do")
    public String searchFmlyTreeRqstView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("fmlyRlVO") FmlyRlVO vo,
    		ModelMap model) throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/fmly/FmlyTreeRqstList";
    }
    
    
    /**
     * Family tree to move to the registration screen.. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyRlVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyTreeRqstList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/searchFmlyTreeRqst.do")
    public String searchFmlyTreeRqst(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("fmlyRlVO") FmlyRlVO vo,
    		ModelMap model) throws Exception {
    	try {
    		
    		EgovMap em = service.searchFmlyTreeRqstHead(vo);
    		if(em != null && !em.isEmpty()){
    			model.addAttribute("em", em);
    		}else{
    			if(vo != null && !"".equals(vo.getSearchKeyword()) ){
    				model.addAttribute("emMsg", "nRgstEnid");
    			}
    		}
    		String flag = service.searchFmlyTreeRqstResult(vo);
			model.addAttribute("flag", flag);
    		
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());
			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
	        List<EgovMap> lstProgram = service.searchListFmlyTreeRqst(vo);
	        model.addAttribute("lstProgram", lstProgram);
	        
	        lstProgram = setGridDataConvert(lstProgram, "j", "list");
	        
	        int totCnt = service.searchListTotCnFmlyTreeRqst(vo);
			paginationInfo.setTotalRecordCount(totCnt);
			
	        model.addAttribute("paginationInfo", paginationInfo);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/fmly/FmlyTreeRqstList";
    }
    
    
    /**
     * Family tree to move to the registration screen.. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyRlVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyTreeRqstList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/addFmlyTreeRqst.do")
    public String addFmlyTreeRqst(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("fmlyRlVO") FmlyRlVO vo,
    		ModelMap model) throws Exception {
    	try {
    		int result = service.addFmlyTreeRqst(vo);
    		if(result > 0){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}else{
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("udtFail.msg"));
    		}
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "forward:/rm/fmly/searchFmlyTreeRqst.do";
    }
    
    
    /**
     * Family tree to move to the registration screen.. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyRlVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/p_FmlyTreeRsut.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/searchFmlyTreeRsutView.do")
    public String searchFmlyTreeRsutView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("fmlyRlVO") FmlyRlVO vo,
    		ModelMap model) throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("useLangCd",  user.getUseLangCd());
    		vo.setUseLangCd(user.getUseLangCd());
    		
    		// citizen view log
    		List<EgovMap> list = service.searchListFmlyTreeRsutExcel(vo);
    		if(list != null && !list.isEmpty()){
    			for(int i = 0; i < list.size(); i++){
    				EgovMap em = list.get(i);
    				String rsdtNo = NidStringUtil.nullConvert(em.get("rsdtNo"));
    				rsdtInfrLgService.addRsdtInfrLg(rsdtNo, "27");
    			}
    		}
    		
    		
    		EgovMap em = service.searchFmlyTreeRsut(vo);
    		String str = (String)em.get("bthDdJ");
			str = NidStringUtil.toNumberConvet(str, "j");
			em.put("bthDdJ", str);
			em.put("rsdtNo", vo.getRsdtNo());
    		model.addAttribute("em", em);
    		
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());
			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
	        List<EgovMap> lstProgram = service.searchListFmlyTreeRsut(vo);
	        model.addAttribute("lstProgram", lstProgram);
	        
	        lstProgram = setGridDataConvert(lstProgram, "j", "list2");
	        
	        int totCnt = service.searchListTotCnFmlyTreeRsut(vo);
			paginationInfo.setTotalRecordCount(totCnt);
			
	        model.addAttribute("paginationInfo", paginationInfo);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/fmly/p_FmlyTreeRsut";
    }
    
    /**
     * Family tree to move to the registration screen.. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyRlVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/p_FmlyTreeRsut.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/searchFmlyTreeRsut.do")
    public String searchFmlyTreeRsut(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("fmlyRlVO") FmlyRlVO vo,
    		ModelMap model) throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("useLangCd",  user.getUseLangCd());
    		vo.setUseLangCd(user.getUseLangCd());
    		
    		EgovMap em = service.searchFmlyTreeRsut(vo);
    		String str = (String)em.get("bthDdJ");
			str = NidStringUtil.toNumberConvet(str, "j");
			em.put("bthDdJ", str);
			em.put("rsdtNo", vo.getRsdtNo());
    		model.addAttribute("em", em);
    		
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());
			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
	        List<EgovMap> lstProgram = service.searchListFmlyTreeRsut(vo);
	        model.addAttribute("lstProgram", lstProgram);
	        
	        lstProgram = setGridDataConvert(lstProgram, "j", "list2");
	        
	        int totCnt = service.searchListTotCnFmlyTreeRsut(vo);
			paginationInfo.setTotalRecordCount(totCnt);
			
	        model.addAttribute("paginationInfo", paginationInfo);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/fmly/p_FmlyTreeRsut";
    }
    
    
    
    /**
     * Family tree to move to the registration screen.. <br>
     * 
     * @param ComDefaultVO
     * @param FmlyRlVO
     * @param ModelMap
     * @param HttpServletResponse
     * @return Printed out JSP: 
     */
    @RequestMapping(value="/rm/fmly/searchFmlyTreeRsutExcel.do")
    public void searchFmlyTreeRsutExcel(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("fmlyRlVO") FmlyRlVO vo,
    		ModelMap model,
    		HttpServletResponse response) throws Exception {
    	
    	OutputStream xlsOut = null;
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    		
    		EgovMap em = service.searchFmlyTreeRsut(vo);
    		
    		String nm = getEgovMapValue(em, "nm");
    		String rsdtNoDp = getEgovMapValue(em, "rsdtNoDp");
    		StringBuffer sb = new StringBuffer();
    		sb.append(nm).append("_").append(rsdtNoDp);
    		
    		String fileName = sb.toString().trim();
    		fileName = fileName.replaceAll("([ ]*)", "");
    		
    		String [] tit = new String[5];
    		tit[0] = nidMessageSource.getMessage("bthDd");
    		tit[1] = nidMessageSource.getMessage("gdr");
    		tit[2] = nidMessageSource.getMessage("nm");
    		tit[3] = nidMessageSource.getMessage("enid");
    		tit[4] = nidMessageSource.getMessage("gnr");
			
    		int [] colWd = new int[5];
    		colWd[0] = 15;
    		colWd[1] = 15;
    		colWd[2] = 30;
    		colWd[3] = 25;
    		colWd[4] = 10;
    		
    		List<EgovMap> list = service.searchListFmlyTreeRsutExcel(vo);
    		
    		HSSFWorkbook wb = makeWorkbook(tit, colWd, list);
    		
    		response.setContentType("application/vnd.ms-excel;charset=ISO-8859-1");//charset=ISO-8859-1 charset=utf-8
    		response.setHeader("Content-Disposition", "attachment; filename=" + new String((fileName).getBytes("UTF-8"),"8859_1") +".xls");
    		xlsOut = response.getOutputStream(); 
    		wb.write(xlsOut);
    		xlsOut.close();
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}finally{
    		try{
    			if(xlsOut != null){
    				xlsOut.close();
    			}
    		}catch(Exception e){
    			log.error(e.getMessage(), e);
    		}
    	}
    }
    
    /**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param String[], int[], List
	 * @return HSSFWorkbook
	 * @exception Exception
	 */
    private HSSFWorkbook makeWorkbook(String[] tit, int[] titWd, List<EgovMap> list) throws Exception{
    	HSSFWorkbook wb = new HSSFWorkbook();
    	HSSFRow row = null;
    	HSSFCell cell = null;
    	HSSFSheet sheet = wb.createSheet();
    	
    	int rowCnt = 0;
    	wb.setSheetName(0, "data");
    	
    	String[] title = tit;
    	int cellCount = title.length;
		HSSFCellStyle titleCellStyle = wb.createCellStyle();
		titleCellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		titleCellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		titleCellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
		titleCellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
		titleCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		titleCellStyle.setFillForegroundColor(HSSFColor.WHITE.index);
		titleCellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		titleCellStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
		
		HSSFFont lf = wb.createFont();
		lf.setFontHeightInPoints((short)20);
		lf.setColor(HSSFFont.COLOR_NORMAL);
		lf.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		lf.setFontName("Arial");
		titleCellStyle.setFont(lf);
		
		row = sheet.createRow((short)rowCnt++);
		
		row = sheet.createRow((short)rowCnt);
		CellRangeAddress cra = new CellRangeAddress(rowCnt, rowCnt, 0, cellCount-1);
		sheet.addMergedRegion(cra);
		row.setHeight ((short) 0x300);
		
		
		for (int cellnum = 0; cellnum < cellCount; cellnum++) {
			cell = row.createCell(cellnum);
			cell.setCellStyle(titleCellStyle);
			if(cellnum == 0){
				cell.setCellValue(nidMessageSource.getMessage("fmlyMber"));
			}
		}
		
		rowCnt++;
		row = sheet.createRow((short)rowCnt++);
		
		HSSFCellStyle gridTitleCellStyle = wb.createCellStyle();
		gridTitleCellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		gridTitleCellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		gridTitleCellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
		gridTitleCellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
		gridTitleCellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		gridTitleCellStyle.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
		gridTitleCellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		gridTitleCellStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
		
		lf = wb.createFont();
		lf.setFontHeightInPoints((short)10);
		lf.setColor(HSSFFont.COLOR_NORMAL);
		lf.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
		lf.setFontName("Arial");
		gridTitleCellStyle.setFont(lf);
		
		row = sheet.createRow((short)rowCnt++);
		row.setHeight ((short) 0x200);
		for (int cellnum = 0; cellnum < cellCount; cellnum++) {
			cell = row.createCell(cellnum);
			cell.setCellValue(title[cellnum]);
			cell.setCellStyle(gridTitleCellStyle);
		}
		
		short width = 265;
    	if(tit != null && titWd != null && tit.length == titWd.length){
			for(int i = 0; i < titWd.length; i++){
				sheet.setColumnWidth(i, (titWd[i]*width));
			}
		}
    	//content
    	//cell style
    	HSSFCellStyle gridDataCellStyleCt = wb.createCellStyle();
    	gridDataCellStyleCt.setBorderBottom(HSSFCellStyle.BORDER_THIN);
    	gridDataCellStyleCt.setBorderLeft(HSSFCellStyle.BORDER_THIN);
    	gridDataCellStyleCt.setBorderRight(HSSFCellStyle.BORDER_THIN);
    	gridDataCellStyleCt.setBorderTop(HSSFCellStyle.BORDER_THIN);
    	gridDataCellStyleCt.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
    	gridDataCellStyleCt.setFillForegroundColor(HSSFColor.WHITE.index);
    	gridDataCellStyleCt.setAlignment(HSSFCellStyle.ALIGN_CENTER);
    	gridDataCellStyleCt.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
    	gridDataCellStyleCt.setWrapText(true);
		lf = wb.createFont();
		lf.setFontHeightInPoints((short)10);
		lf.setColor(HSSFFont.COLOR_NORMAL);
		lf.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
		lf.setFontName("Arial");
		gridDataCellStyleCt.setFont(lf);
		
		HSSFCellStyle gridDataCellStyleRt = wb.createCellStyle();
		gridDataCellStyleRt.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		gridDataCellStyleRt.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		gridDataCellStyleRt.setBorderRight(HSSFCellStyle.BORDER_THIN);
		gridDataCellStyleRt.setBorderTop(HSSFCellStyle.BORDER_THIN);
    	gridDataCellStyleRt.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
    	gridDataCellStyleRt.setFillForegroundColor(HSSFColor.WHITE.index);
    	gridDataCellStyleRt.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
    	gridDataCellStyleRt.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
    	gridDataCellStyleRt.setWrapText(true);
		lf = wb.createFont();
		lf.setFontHeightInPoints((short)10);
		lf.setColor(HSSFFont.COLOR_NORMAL);
		lf.setBoldweight(HSSFFont.BOLDWEIGHT_NORMAL);
		lf.setFontName("Arial");
		gridDataCellStyleRt.setFont(lf);
		
		HSSFCellStyle gridDataCellStyleRqstCt = wb.createCellStyle();
		gridDataCellStyleRqstCt.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		gridDataCellStyleRqstCt.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		gridDataCellStyleRqstCt.setBorderRight(HSSFCellStyle.BORDER_THIN);
		gridDataCellStyleRqstCt.setBorderTop(HSSFCellStyle.BORDER_THIN);
		gridDataCellStyleRqstCt.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		gridDataCellStyleRqstCt.setFillForegroundColor(HSSFColor.WHITE.index);
		gridDataCellStyleRqstCt.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		gridDataCellStyleRqstCt.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
		gridDataCellStyleRqstCt.setWrapText(true);
		lf = wb.createFont();
		lf.setFontHeightInPoints((short)10);
		lf.setColor(HSSFFont.COLOR_NORMAL);
		lf.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		lf.setFontName("Arial");
		gridDataCellStyleRqstCt.setFont(lf);
		
		HSSFCellStyle gridDataCellStyleRqstRt = wb.createCellStyle();
		gridDataCellStyleRqstRt.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		gridDataCellStyleRqstRt.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		gridDataCellStyleRqstRt.setBorderRight(HSSFCellStyle.BORDER_THIN);
		gridDataCellStyleRqstRt.setBorderTop(HSSFCellStyle.BORDER_THIN);
		gridDataCellStyleRqstRt.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		gridDataCellStyleRqstRt.setFillForegroundColor(HSSFColor.WHITE.index);
		gridDataCellStyleRqstRt.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
		gridDataCellStyleRqstRt.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
		gridDataCellStyleRqstRt.setWrapText(true);
		lf = wb.createFont();
		lf.setFontHeightInPoints((short)10);
		lf.setColor(HSSFFont.COLOR_NORMAL);
		lf.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		lf.setFontName("Arial");
		gridDataCellStyleRqstRt.setFont(lf);
		
    	if(list != null && !list.isEmpty()){
    		for(int i = 0; i < list.size(); i++){
    			row = sheet.createRow((short)rowCnt++);
    			EgovMap em = list.get(i);
    			String gnr = getEgovMapValue(em, "gnr");
    			String nm = getEgovMapValue(em, "nm");
    			String rsdtNoDp = getEgovMapValue(em, "rsdtNoDp");
    			String gdrCdNm = getEgovMapValue(em, "gdrCdNm");
    			String bthDdJ = getEgovMapValue(em, "bthDdJ");
    			String bthDdG = getEgovMapValue(em, "bthDdG");
    			String rsdtNoRqst = getEgovMapValue(em, "rsdtNoRqst");
    			int datCn = 0;
    			String[] gridData = new String[tit.length];
    			String bthDd = null;
    			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    			if(user != null && user.getUseLangCd() != null && "3".equals(user.getUseLangCd())){
    				bthDd = bthDdG;
    			}else{
    				bthDd = NidStringUtil.toNumberConvet(bthDdJ, "j");
    			}
    			gridData[datCn++] = bthDd; // 0
    			gridData[datCn++] = gdrCdNm; // 1
    			gridData[datCn++] = nm; // 8
    			gridData[datCn++] = rsdtNoDp; // 9
    			gridData[datCn++] = gnr; // 10
    			
    			HSSFCellStyle style = null;
    			for (int cellnum = 0; cellnum < gridData.length; cellnum++) {
    				cell = row.createCell(cellnum);
    				cell.setCellValue(gridData[cellnum]);
    				if(cellnum == 0){
    					cell.setCellType( HSSFCell.CELL_TYPE_STRING );
    				}
    				if(cellnum == 2 || cellnum == 4 || cellnum == 6 || cellnum == 8 || cellnum == 10){
    					if(rsdtNoRqst != null && "Y".equals(rsdtNoRqst)){
    						style = gridDataCellStyleRqstRt;
    					}else{
    						style = gridDataCellStyleRt;
    					}
    				}else{
    					if(rsdtNoRqst != null && "Y".equals(rsdtNoRqst)){
    						style = gridDataCellStyleRqstCt;
    					}else{
    						style = gridDataCellStyleCt;
    					}
    				}
    				cell.setCellStyle(style);
    			}
    		}
    	}
    	return wb;
    }
    
    
    /**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param List, String, String
	 * @return List
	 * @exception Exception
	 */
	private List<EgovMap> setGridDataConvert(List<EgovMap> list, String cal, String type){
		List<EgovMap> result = list;
		if(list != null && (cal != null && ("j".equals(cal.toLowerCase()) || "".equals(cal)) || cal == null) ){
			if(!list.isEmpty()){
				for(int i = 0; i < list.size(); i++){
					Object obj = list.get(i);
					if(obj instanceof EgovMap){
						EgovMap vo = (EgovMap)obj;
						if(type != null && "list".equals(type)){
							String str = (String)vo.get("rqstDdJ");
							str = NidStringUtil.toNumberConvet(str, "j");
							vo.put("rqstDdJ", str);
							
							str = (String)vo.get("gnrDdJ");
							str = NidStringUtil.toNumberConvet(str, "j");
							vo.put("gnrDdJ", str);
						}else if(type != null && "list2".equals(type)){
							String str = (String)vo.get("bthDdJ");
							str = NidStringUtil.toNumberConvet(str, "j");
							vo.put("bthDdJ", str);
						}
						result.set(i, vo);
					}
				}
			}
		}
		return result;
	}
	
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param EgovMap, String
	 * @return String
	 * @exception Exception
	 */
	private String getEgovMapValue(EgovMap obj, String value){
		String result = "";
		if(obj != null && !obj.isEmpty() && value != null){
			Object object = obj.get(value);
			if(object != null){
				if(object instanceof BigDecimal){
					BigDecimal big = (BigDecimal)object;
					int bigInt = big.intValue();
					result = String.valueOf(bigInt);
				}else if(object instanceof String){
					result = (String)object;
				}
			}
		}
		return result;
	}
	
}