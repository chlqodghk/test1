package afnid.rm.fmly.web;

/* java API */
 
import java.io.StringWriter;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;

import afnid.rm.fmly.service.FmlyRlRuleService;
import afnid.rm.fmly.service.FmlyRlRuleVO;

import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/** 
 * This Controller class processes request of relationship rule-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team MS KIM
 * @since 2015.08.06
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           					Revisions
 *   2015.08.06  		moon soo kim         						Create
 *
 * </pre>
 */
@Controller
public class FmlyRlRuleController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /** NidProgrmManageService */
	@Resource(name = "fmlyRlRuleService")
    private FmlyRlRuleService service;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    @Resource(name = "lgService")
    private LgService lgService;
	
    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
    /**
     * Move to the Family rule registration screen. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyRlRuleVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyRlRuleList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/searchListFmlyRlRuleView.do")
    public String searchListScrnView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("fmlyRlRuleVO") FmlyRlRuleVO fmlyRlRuleVO,
    		ModelMap model)
            throws Exception { 
    	    
    	try{
    		   			
        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();        	
        	lgService.addUserWrkLg(user.getUserId(), fmlyRlRuleVO.getCurMnId());
        	
	    	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("9"); // Setting Group Code
			List<CmCmmCdVO> rlList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("rlList", rlList);

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
      	return "/rm/fmly/FmlyRlRuleList";

    }
	
    /**
     * Retrieves list of Family relationship rule. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyRlRuleVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyRlRuleList.jsp"
     * @exception Exception
     */    
    @RequestMapping(value="/rm/fmly/searchListFmlyRlRule.do")
    public String searchListFmlyRlRule(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("fmlyRlRuleVO") FmlyRlRuleVO fmlyRlRuleVO,
    		ModelMap model)
            throws Exception { 
    	    
    	try{
    		   			
    		//Common Code List
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO(); 

    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		fmlyRlRuleVO.setUseLangCd(user.getUseLangCd());
    		
    		//Relationship code.
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
			List<CmCmmCdVO> rlList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("rlList", rlList);
    		
	    	/** List Paging Setting */
    		fmlyRlRuleVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		fmlyRlRuleVO.setPageSize(propertiesService.getInt("pageSize"));
	
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(fmlyRlRuleVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(fmlyRlRuleVO.getPageUnit());
			paginationInfo.setPageSize(fmlyRlRuleVO.getPageSize());
	
			fmlyRlRuleVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			fmlyRlRuleVO.setLastIndex(paginationInfo.getLastRecordIndex());
			fmlyRlRuleVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			 
	        List<FmlyRlRuleVO> lstFmlyRlRule = service.searchListFmlyRlRule(fmlyRlRuleVO);
	        model.addAttribute("lstFmlyRlRule", lstFmlyRlRule);
   		
	        int totCnt = service.searchListFmlyRlRuleTotCnt(fmlyRlRuleVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
      	return "/rm/fmly/FmlyRlRuleList";

    }    
    
    /**
     * Moved to modification-screen of Relationship rule. <br>
     * 
     * @param MnMngVO Value-object of menu to be parsed request(FmlyRlRuleVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyRlRuleUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/searchFmlyRlRule.do")
    public String searchFmlyRlRule(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("fmlyRlRuleVO") FmlyRlRuleVO vo,
    		ModelMap model)
            throws Exception { 
    	
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    		
    		FmlyRlRuleVO fmlyRlRuleVO = new FmlyRlRuleVO();
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		
    		
    		cmCmmCd.setGrpCd("9");
			List<CmCmmCdVO> rlList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("rlList", rlList);		
    		
    		cmCmmCd.setGrpCd("10"); 
			List<CmCmmCdVO> selfGdrList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("selfGdrList", selfGdrList);
			
    		cmCmmCd.setGrpCd("80"); 
			List<CmCmmCdVO> mberRstrtGdrList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("mberRstrtGdrList", mberRstrtGdrList);
			
    		cmCmmCd.setGrpCd("79");
			List<CmCmmCdVO> cnTyeList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("cnTyeList", cnTyeList);
			
    		cmCmmCd.setGrpCd("9");
			List<CmCmmCdVO> fthrRlList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("fthrRlList", fthrRlList);
			
			List<CmCmmCdVO> gfthrRlList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("gfthrRlList", gfthrRlList);
			
			List<CmCmmCdVO> mthrRlList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("mthrRlList", mthrRlList);
			
			List<CmCmmCdVO> hsbdRlList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("hsbdRlList", hsbdRlList);
			
			fmlyRlRuleVO = service.searchFmlyRlRule(vo);
			model.addAttribute("fmlyRlRuleVO", fmlyRlRuleVO);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "/rm/fmly/FmlyRlRuleUdt";
    }   
    
    /**
     * Moved to List screen of Relationship rule. <br>
     * 
     * @param MnMngVO Value-object of menu to be parsed request(FmlyRlRuleVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyRlRuleList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/moddifyFmlyRlRule.do")
    public String moddifyFmlyRlRule(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("fmlyRlRuleVO") FmlyRlRuleVO fmlyRlRuleVO,
    		ModelMap model)
            throws Exception { 
    	
    	try {
 
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		fmlyRlRuleVO.setUserId(user.getUserId());
    		
    		service.modifyFmlyRlRule(fmlyRlRuleVO);
  
    		
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return  "forward:/rm/fmly/searchListFmlyRlRule.do";
    }   
    
    /**
     * Moved to modification-screen of Relationship rule. <br>
     * 
     * @param MnMngVO Value-object of menu to be parsed request(FmlyRlRuleVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyRlRuleUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/addFmlyRlRuleView.do")
    public String addFmlyRlRuleView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("fmlyRlRuleVO") FmlyRlRuleVO vo,
    		ModelMap model)
            throws Exception { 
    	
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());

    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();    		
    		
    		cmCmmCd.setGrpCd("9");
			List<CmCmmCdVO> rlList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("rlList", rlList);		
    		
    		cmCmmCd.setGrpCd("10"); 
			List<CmCmmCdVO> selfGdrList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("selfGdrList", selfGdrList);
			
    		cmCmmCd.setGrpCd("80"); 
			List<CmCmmCdVO> mberRstrtGdrList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("mberRstrtGdrList", mberRstrtGdrList);
			
    		cmCmmCd.setGrpCd("79");
			List<CmCmmCdVO> cnTyeList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("cnTyeList", cnTyeList);
			
    		cmCmmCd.setGrpCd("9");
			List<CmCmmCdVO> fthrRlList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("fthrRlList", fthrRlList);
			
			List<CmCmmCdVO> gfthrRlList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("gfthrRlList", gfthrRlList);
			
			List<CmCmmCdVO> mthrRlList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("mthrRlList", mthrRlList);
			
			List<CmCmmCdVO> hsbdRlList = cmmCdMngService.searchListCmmCd(cmCmmCd); 
			model.addAttribute("hsbdRlList", hsbdRlList);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "/rm/fmly/FmlyRlRuleIns";
    }    
    /**
     * Moved to List screen of Relationship rule. <br>
     * 
     * @param MnMngVO Value-object of menu to be parsed request(FmlyRlRuleVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyRlRuleList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/addFmlyRlRule.do")
    public String addFmlyRlRule(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("fmlyRlRuleVO") FmlyRlRuleVO fmlyRlRuleVO,
    		ModelMap model)
            throws Exception { 
    	
    	try {
 
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		fmlyRlRuleVO.setUserId(user.getUserId());
    		
    		service.addFmlyRlRule(fmlyRlRuleVO);
      		
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return  "forward:/rm/fmly/searchListFmlyRlRule.do";
    }   
    
    /**
     * self and the birth date of check <br>
     *
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/searchChkKey.do")
    public void searchChkKey(
    		ModelMap model,
    		HttpServletResponse response,
    		@ModelAttribute("fmlyRlRuleVO") FmlyRlRuleVO vo)
            throws Exception {
    	try{

    		String flag = service.searchChkKey(vo);
       		log.debug("==============================================");
       		log.debug("flag : "+ flag);
       		log.debug("==============================================");    		
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		if(flag != null && !"".equals(flag)){
    			Element el = doc.createElement("flag");
    			el.appendChild(doc.createTextNode(flag));
	    		root.appendChild(el);
    		}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }    
}