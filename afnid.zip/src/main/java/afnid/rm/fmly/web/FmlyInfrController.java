package afnid.rm.fmly.web;

/* java API */
import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.fmly.service.FmlyInfrService;
import afnid.rm.fmly.service.FmlyInfrVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/** 
 * This Controller class processes request of family-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.02
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.02  		BH Choi         						Create
 *
 * </pre>
 */
@Controller
public class FmlyInfrController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /** NidProgrmManageService */
	@Resource(name = "fmlyInfoService")
    private FmlyInfrService service;
	
    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdManagerService;

	/** NidCommonService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCommonService;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    @Resource(name = "lgService")
    private LgService lgService;
	
    /**
     * Moved to list-screen of family book. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyInfrList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/searchListFmlyInfrView.do")   
    public String searchListFmlyInfrView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("fmlyInfoVO") FmlyInfrVO vo,
    		ModelMap model,
    		HttpServletRequest req) throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
    		
    		/*NidStringUtil nsu = new NidStringUtil();
    		String cert = nsu.getReqCertName(req);
    		if(user != null && user.getCert() != null && cert != null){
    			if(!user.getCert().equals(cert)){
    				return "forward:/cm/uat/LgnUser.do?authorFail=3";
    			}
    		}*/
    		
    		String orgnzCd = user.getOrgnzCd();
    		String district = orgnzCd.substring(0, 4); //String str1 = "L123456789"; 467
    		String teamCd = user.getTamCdNm();
    		if(teamCd == null || "".equals(teamCd)){
    			teamCd = "00";
    		}
    		comDefaultVO.setSearchKeyword2(district);
    		comDefaultVO.setSearchKeyword3(teamCd);
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd); 		
    		model.addAttribute("gdrCd", gdrCd);
    		
    		String fromToDdDrnLmt = propertiesService.getString("fromToDdDrnLmt");
    		if(fromToDdDrnLmt == null && "".equals(fromToDdDrnLmt) ){
    			fromToDdDrnLmt = "0";
    		}
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo.setAddDay(fromToDdDrnLmt);
    		comVo = nidCommonService.searchAddToDay(comVo);
    		comDefaultVO.setStartDay(comVo.getStartDay());
    		comDefaultVO.setEndDay(comVo.getEndDay());
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/fmly/FmlyInfrList";
    }
    
    /**
     * Retrieves list of program.  <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "rm/fmly/FmlyInfrList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/fmly/searchListFmlyInfr.do")
    public String searchListFmlyInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("fmlyInfoVO") FmlyInfrVO vo,
    		ModelMap model)
            throws Exception { 
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		String useLangCd = user.getUseLangCd();
    		
    		vo.setUseLangCd(useLangCd);
    		
    		// fmlyBokNo1 district, fmlyBokNo2 team code
    		String orgnzCd = user.getOrgnzCd();
    		String district = orgnzCd.substring(0, 4); //String str1 = "L123456789"; 467
    		String teamCd = user.getTamCdNm();
    		vo.setOfficerNo(district+teamCd);
	    	
    		String orgnzClsCd = user.getOrgnzClsCd();
    		vo.setRgstOrgnzCd(orgnzClsCd+orgnzCd+teamCd);
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd); 
    		model.addAttribute("gdrCd", gdrCd);
    		
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());
			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
	        List<FmlyInfrVO> lstProgram = service.searchListFmlyInfr(vo);
	        
	        lstProgram = setGridDataConvert(lstProgram, "j", "list");
	        
	        model.addAttribute("lstProgram", lstProgram);
	        int totCnt = service.searchListTotCnFmlyInfr(vo);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        
	        
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/fmly/FmlyInfrList";
    }
	
    /**
     * Moved to registration-screen of family book. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyInfrIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/searchFmlyInfrView.do")   
    public String addFmlyInfrView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("fmlyInfoVO") FmlyInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
    		
    		model.addAttribute("fmlyInfoVO", vo);
    		
    		// fmlyBokNo1 district, fmlyBokNo2 team code
    		
    		String orgnzCd = user.getOrgnzCd();
    		String district = orgnzCd.substring(0, 4); //String str1 = "L123456789"; 467
    		
    		String tamCdNm = user.getTamCdNm();
    		if(tamCdNm == null || "".equals(tamCdNm)){
    			tamCdNm = "00";
    		}
    		
    		model.addAttribute("fmlyBokNo1", district);
    		model.addAttribute("fmlyBokNo2", tamCdNm);
    		
    		vo.setFmlyBokNoNum(district+tamCdNm);
    		String fmlyBokNo = service.searchFmlyNo(vo);
    		model.addAttribute("fmlyBokNo", fmlyBokNo);
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		vo.setFmlyBokRgstDd(NidStringUtil.toNumberConvet(comVo.getStartDay(), "j"));
    		vo.setCrdIsucePlceCd(orgnzCd);
    		if(user.getUseLangCd().equals("1")){
    			vo.setCrdIsucePlceCdNm(user.getPstOrgnzNm());
    		}else if(user.getUseLangCd().equals("2")){
    			vo.setCrdIsucePlceCdNm(user.getDrOrgnzNm());
    		}else if(user.getUseLangCd().equals("3")){
    			vo.setCrdIsucePlceCdNm(user.getEnOrgnzNm());
    		}else{
    			vo.setCrdIsucePlceCdNm(user.getPstOrgnzNm());
    		}
    		
    		comVo = nidCommonService.searchGreToDay(vo);
    		String dayG = comVo.getStartDay();
    		dayG = dayG.replaceAll("-", "");
    		model.addAttribute("oldCrdIsuceDd", dayG);
    		StringBuffer sb = new StringBuffer();
    		sb.append(dayG.substring(6, 8)).append("-").append(dayG.substring(4, 6)).append("-").append(dayG.substring(0, 4));
    		dayG = sb.toString();    		
    		model.addAttribute("fmlyBokRgstDdG", dayG);
    		
    		String vefyRgstFromDd = propertiesService.getString("vefyRgstFromDd");
    		String vefyRgstToDd = propertiesService.getString("vefyRgstToDd");
    		EgovMap em = new EgovMap();
    		em.put("vefyRgstFromDd", vefyRgstFromDd);
    		em.put("vefyRgstToDd", vefyRgstToDd);
    		String vefyRgstDdYn = service.searchVefyRgstDdYn(em);
    		model.addAttribute("vefyRgstDdYn", vefyRgstDdYn);
    		model.addAttribute("userNm", user.getNm());
    		String ofcalPsnCd = "";
    		List<String> lstAthr = NidUserDetailsHelper.getAuthorities();
    		if(lstAthr != null && lstAthr.size() == 1){
    			ofcalPsnCd = lstAthr.get(0);
    		}else if(lstAthr != null && lstAthr.size() > 1){
    			for(int j = 0; j < lstAthr.size(); j++){
    				String athr = lstAthr.get(j);
    				if("1".equals(athr) || "3".equals(athr)){
    					ofcalPsnCd = athr;
    					if("3".equals(athr)){
        					break;
        				}
    				}
    			}
    		}
    		model.addAttribute("ofcalPsnCd", ofcalPsnCd);
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, ""); 
    		model.addAttribute("rlCd", codeLst); 
    		
    		comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		
    		int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("nltyCd", nltyCd);
    		
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
	        model.addAttribute("kochiAdCd", kochiAdCd);
	        
	        
	        List<EgovMap> rmRlLst = service.searchRmRlTb(new String("")); 
	        model.addAttribute("rmRlLst", rmRlLst);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/fmly/FmlyInfrIns";
    }
    
    /**
     * Family registration book. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyInfrIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/addFmlyInfr.do")   
    public String addFmlyInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("fmlyInfoVO") FmlyInfrVO vo,
    		ModelMap model)
            throws Exception {
    	String fmlyBokNo = null;
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		String userId = user.getUserId();
    		String orgnzCd = user.getOrgnzCd();
    		
    		// fmlyBokNo1 district, fmlyBokNo2 team code
    		String district = orgnzCd.substring(0, 4); //String str1 = "L123456789"; 456
    		
    		String tamCdNm = user.getTamCdNm();
    		if(tamCdNm == null || "".equals(tamCdNm)){
    			tamCdNm = "00";
    		}
    		model.addAttribute("fmlyBokNo1", district);
    		model.addAttribute("fmlyBokNo2", tamCdNm);
    		vo.setUserId(userId);
    		vo.setOrgnzCd(orgnzCd);
			fmlyBokNo = service.addFmlyInfr(vo); 
	    	vo.setFmlyBokNo(fmlyBokNo);
	    	ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		vo.setFmlyBokRgstDd(comVo.getStartDay());
    		model.addAttribute("fmlyInfoVO", vo);
	    	model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); 
    		model.addAttribute("getCudDate", nidCommonService.searchDateTime(vo));
    		
  
    		
    		vo.setFmlyBokNoNum(district+user.getTamCdNm());
    		//String fmlyBokNoIns = service.selectFmlyNumber(vo);
    		//model.addAttribute("fmlyBokNo", fmlyBokNoIns);
    		
    		vo.setFstVefyIndiGivNm("");
    		vo.setSecdVefyIndiGivNm("");
    		
    		vo.setCrdIsucePlceCd(orgnzCd);
    		if(user.getUseLangCd().equals("1")){
    			vo.setCrdIsucePlceCdNm(user.getPstOrgnzNm());
    		}else if(user.getUseLangCd().equals("2")){
    			vo.setCrdIsucePlceCdNm(user.getDrOrgnzNm());
    		}else if(user.getUseLangCd().equals("3")){
    			vo.setCrdIsucePlceCdNm(user.getEnOrgnzNm());
    		}else{
    			vo.setCrdIsucePlceCdNm(user.getPstOrgnzNm());
    		}
    		
    		if(user.getUseLangCd() != null && user.getUseLangCd().equals("3")){
    			fmlyBokNo = fmlyBokNo.substring(6,fmlyBokNo.length())+"-"+fmlyBokNo.substring(4,6)+"-"+fmlyBokNo.substring(0,4);
    		}else{
    			fmlyBokNo = fmlyBokNo.substring(0,4)+"-"+fmlyBokNo.substring(4,6)+"-"+fmlyBokNo.substring(6,fmlyBokNo.length());
    		}
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("fmlyfomNo") + " : " + fmlyBokNo);
    		
    		String vefyRgstFromDd = propertiesService.getString("vefyRgstFromDd");
    		String vefyRgstToDd = propertiesService.getString("vefyRgstToDd");
    		EgovMap em = new EgovMap();
    		em.put("vefyRgstFromDd", vefyRgstFromDd);
    		em.put("vefyRgstToDd", vefyRgstToDd);
    		String vefyRgstDdYn = service.searchVefyRgstDdYn(em);
    		model.addAttribute("vefyRgstDdYn", vefyRgstDdYn);
    		model.addAttribute("userNm", user.getNm());
    		String ofcalPsnCd = "";
    		List<String> lstAthr = NidUserDetailsHelper.getAuthorities();
    		if(lstAthr != null && lstAthr.size() == 1){
    			ofcalPsnCd = lstAthr.get(0);
    		}else if(lstAthr != null && lstAthr.size() > 1){
    			for(int j = 0; j < lstAthr.size(); j++){
    				String athr = lstAthr.get(j);
    				if("1".equals(athr) || "3".equals(athr)){
    					ofcalPsnCd = athr;
    					if("3".equals(athr)){
        					break;
        				}
    				}
    			}
    		}
    		model.addAttribute("ofcalPsnCd", ofcalPsnCd);
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, ""); 
    		model.addAttribute("rlCd", codeLst); 
    		
    		comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		
    		comVo = nidCommonService.searchGreToDay(vo);
    		String dayG = comVo.getStartDay();
    		dayG = dayG.replaceAll("-", "");
    		model.addAttribute("oldCrdIsuceDd", dayG);
    		
    		int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("nltyCd", nltyCd);
    		
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
	        model.addAttribute("kochiAdCd", kochiAdCd);
	        
	        List<EgovMap> rmRlLst = service.searchRmRlTb(new String("")); 
	        model.addAttribute("rmRlLst", rmRlLst);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "/rm/fmly/FmlyInfrIns";
    }
    
    /**
     * Moved to modify-screen of family book. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyInfrUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/searchFmlyInfrUdtView.do")   
    public String searchFmlyInfrUdtView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("fmlyInfoVO") FmlyInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		String orgnzCd = user.getOrgnzCd();
    		String teamCd = user.getTamCdNm();
    		String orgnzClsCd = user.getOrgnzClsCd();

    		vo.setRgstOrgnzCd(orgnzClsCd+orgnzCd+teamCd);
    		
    		FmlyInfrVO fmlyVo = service.searchFmlyInfrView(vo); 
    		List<FmlyInfrVO> list = service.searchListFmlyInfrView(vo);
    		
    		if(fmlyVo != null && fmlyVo.getFmlyBokRgstDd() != null ){
    			fmlyVo.setFmlyBokRgstDd(NidStringUtil.toNumberConvet(fmlyVo.getFmlyBokRgstDd(),"j"));
    		}
    		
    		
    		list = setGridDataConvert(list, "j", "mem");
    		
    		if(fmlyVo == null){
    			fmlyVo = service.searchFmlyInfrHeadDupView(vo);
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstBioDupReHeadRgst.msg"));
    		}
    		model.addAttribute("fmlyInfoVO", fmlyVo);
    		model.addAttribute("list", list);
    		
    		String ofcalPsnCd = "";
    		List<String> lstAthr = NidUserDetailsHelper.getAuthorities();
    		if(lstAthr != null && lstAthr.size() == 1){
    			ofcalPsnCd = lstAthr.get(0);
    		}else if(lstAthr != null && lstAthr.size() > 1){
    			for(int i = 0; i < lstAthr.size(); i++){
    				String athr = lstAthr.get(i);
    				if("1".equals(athr) || "3".equals(athr)){
    					ofcalPsnCd = athr;
    					if("3".equals(athr)){
        					break;
        				}
    				}
    			}
    		}
    		model.addAttribute("ofcalPsnCd", ofcalPsnCd);
    		
    		String vefyRgstFromDd = propertiesService.getString("vefyRgstFromDd");
    		String vefyRgstToDd = propertiesService.getString("vefyRgstToDd");
    		EgovMap em = new EgovMap();
    		em.put("vefyRgstFromDd", vefyRgstFromDd);
    		em.put("vefyRgstToDd", vefyRgstToDd);
    		String vefyRgstDdYn = service.searchVefyRgstDdYn(em);
    		model.addAttribute("vefyRgstDdYn", vefyRgstDdYn);
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, ""); 
    		model.addAttribute("rlCd", codeLst); 
    		
    		ComDefaultVO comVo = nidCommonService.searchGreToDay(vo);
    		String dayG = comVo.getStartDay();
    		dayG = dayG.replaceAll("-", "");
    		model.addAttribute("oldCrdIsuceDd", dayG);
    		
    		comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		
    		int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("nltyCd", nltyCd);
    		
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
	        model.addAttribute("kochiAdCd", kochiAdCd);
	        
	        List<EgovMap> rmRlLst = service.searchRmRlTb(new String("")); 
	        model.addAttribute("rmRlLst", rmRlLst);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/fmly/FmlyInfrUdt";
    }
    
    /**
     * Family Book modification. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/FmlyInfrList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/modifyFmlyInfr.do")   
    public String modifyFmlyInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("fmlyInfoVO") FmlyInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		String userId = user.getUserId();
    		vo.setUserId(userId);
    		int resultCnt = service.modifyFmlyInfr(vo);
    		if(resultCnt > 0){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); 
    		
    			model.addAttribute("getCudDate", nidCommonService.searchDateTime(vo));
    		}
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "forward:/rm/fmly/searchFmlyInfrUdtView.do";
    }
    
    
    
    /**
     *Social security number, name search. <br>
     *
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/searchRsdtNm.do")
    public void searchRsdtNm(
    		@ModelAttribute("fmlyInfoVO") FmlyInfrVO vo,
    		@RequestParam(value="tye" ,required=false) String tye,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		vo.setVrfrYn(tye);
    		EgovMap rsdtNm = (EgovMap)service.searchRsdtNm(vo);
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		
    		String fullNm = "";
    		String rsdtSeqNo = "";
    		String fthrNm = "";
    		String rsdtNo = "";
    		if(rsdtNm != null && !rsdtNm.isEmpty()){
    			fullNm = (String)rsdtNm.get("rsdtNm");
    			rsdtSeqNo = String.valueOf(((BigDecimal)rsdtNm.get("rsdtSeqNo")).intValue());
    			fthrNm = (String)rsdtNm.get("fthrNm");
    			rsdtNo = (String)rsdtNm.get("rsdtNo");
    		}
    		
    		Element child = doc.createElement("rsdtNm");
    		child.appendChild(doc.createTextNode(fullNm));
    		root.appendChild(child);
    		
    		child = doc.createElement("rsdtSeqNo");
    		child.appendChild(doc.createTextNode(rsdtSeqNo));
    		root.appendChild(child);
    		
    		child = doc.createElement("fthrNm");
    		child.appendChild(doc.createTextNode(fthrNm));
    		root.appendChild(child);
    		
    		child = doc.createElement("rsdtNo");
    		child.appendChild(doc.createTextNode(rsdtNo));
    		root.appendChild(child);
    		
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    /**
     *Social security number, name search. <br>
     *
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value={"/rm/fmly/searchFmlyRsdtInfr.do","/rm/rsdt/searchFmlyRsdtInfr.do"})
    public void searchFmlyRsdtInfr(
    		@ModelAttribute("fmlyInfoVO") FmlyInfrVO vo,
    		@RequestParam(value="tye" ,required=false) String tye,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		int vrfrAgeLmt = propertiesService.getInt("vrfrAgeLmt");
    		
    		vo.setVrfrAgeLmt(String.valueOf(vrfrAgeLmt));
    		vo.setVrfrYn(tye);
    		EgovMap rsdtNm = (EgovMap)service.searchFmlyRsdtInfr(vo);
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		
    		String fullNm = "";
    		String rsdtSeqNo = "";
    		String fthrNm = "";
    		String rsdtNo = "";
    		String gdrCd = "";
    		String oldCrdNo1 = "";
    		String oldCrdNo2 = "";
    		String oldCrdNo3 = "";
    		String oldCrdNo4 = "";
    		String bthDd = "";
    		String oldCrdIsuceDd = "";
    		String oldCrdIsucePlceCd = "";
    		String oldCrdIsucePlceCdNm = "";
    		String age="";
    		if(rsdtNm != null && !rsdtNm.isEmpty()){
    			fullNm = (String)rsdtNm.get("rsdtNm");
    			rsdtSeqNo = String.valueOf(((BigDecimal)rsdtNm.get("rsdtSeqNo")).intValue());
    			fthrNm = getEgovMapValue(rsdtNm, "fthrNm");
    			rsdtNo = getEgovMapValue(rsdtNm, "rsdtNo");
    			gdrCd = String.valueOf(((BigDecimal)rsdtNm.get("gdrCd")).intValue());
    			oldCrdNo1 = getEgovMapValue(rsdtNm, "oldCrdNo1");
    			oldCrdNo2 = getEgovMapValue(rsdtNm, "oldCrdNo2");
    			oldCrdNo3 = getEgovMapValue(rsdtNm, "oldCrdNo3");
    			oldCrdNo4 = getEgovMapValue(rsdtNm, "oldCrdNo4");
    			bthDd = getEgovMapValue(rsdtNm, "bthDd");
    			oldCrdIsuceDd = getEgovMapValue(rsdtNm, "oldCrdIsuceDd");
        		oldCrdIsucePlceCd = getEgovMapValue(rsdtNm, "oldCrdIsucePlceCd");
        		oldCrdIsucePlceCdNm = getEgovMapValue(rsdtNm, "oldCrdIsucePlceCdNm");
        		oldCrdIsucePlceCdNm = getEgovMapValue(rsdtNm, "oldCrdIsucePlceCdNm");
        		age = getEgovMapValue(rsdtNm, "age");
    		}
    		
    		Element child = doc.createElement("rsdtNm");
    		child.appendChild(doc.createTextNode(fullNm));
    		root.appendChild(child);
    		
    		child = doc.createElement("rsdtSeqNo");
    		child.appendChild(doc.createTextNode(rsdtSeqNo));
    		root.appendChild(child);
    		
    		child = doc.createElement("fthrNm");
    		child.appendChild(doc.createTextNode(fthrNm));
    		root.appendChild(child);
    		
    		child = doc.createElement("rsdtNo");
    		child.appendChild(doc.createTextNode(rsdtNo));
    		root.appendChild(child);
    		
    		child = doc.createElement("gdrCd");
    		child.appendChild(doc.createTextNode(gdrCd));
    		root.appendChild(child);
    		
    		child = doc.createElement("oldCrdNo1");
    		child.appendChild(doc.createTextNode(oldCrdNo1));
    		root.appendChild(child);
    		
    		child = doc.createElement("oldCrdNo2");
    		child.appendChild(doc.createTextNode(oldCrdNo2));
    		root.appendChild(child);
    		
    		child = doc.createElement("oldCrdNo3");
    		child.appendChild(doc.createTextNode(oldCrdNo3));
    		root.appendChild(child);
    		
    		child = doc.createElement("oldCrdNo4");
    		child.appendChild(doc.createTextNode(oldCrdNo4));
    		root.appendChild(child);
    		
    		child = doc.createElement("bthDd");
    		child.appendChild(doc.createTextNode(bthDd));
    		root.appendChild(child);
    		
    		child = doc.createElement("oldCrdIsuceDd");
    		child.appendChild(doc.createTextNode(oldCrdIsuceDd));
    		root.appendChild(child);
    		
    		child = doc.createElement("oldCrdIsucePlceCd");
    		child.appendChild(doc.createTextNode(oldCrdIsucePlceCd));
    		root.appendChild(child);
    		
    		child = doc.createElement("oldCrdIsucePlceCdNm");
    		child.appendChild(doc.createTextNode(oldCrdIsucePlceCdNm));
    		root.appendChild(child);
    		
    		child = doc.createElement("age");
    		child.appendChild(doc.createTextNode(age));
    		root.appendChild(child);
    		
    		child = doc.createElement("vrfrAgeLmt");
    		child.appendChild(doc.createTextNode(String.valueOf(vrfrAgeLmt)));
    		root.appendChild(child);
    		
    		
    		
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    /**
     * Family moved to the registration screen. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param mode Value-object of program to be parsed request(String)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/p_FmlyInfrAdd.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/addFmlyInfrPopup.do")
    public String addFmlyInfrPopup(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("fmlyInfoVO") FmlyInfrVO vo,
    		@RequestParam(value="mode" ,required=false) String mode,
    		ModelMap model)
            throws Exception {    	
    	try {
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, ""); 
    		model.addAttribute("rlCd", codeLst); 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		codeLst = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("gdrCd", codeLst); 

    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		vo.setBthDd(comVo.getStartDay());
    		model.addAttribute("mode",mode);
    		model.addAttribute("fmlyInfoVO", vo);
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		if(user != null && user.getUseLangCd() != null && user.getUseLangCd().equals("1")){
    			model.addAttribute("useLangCd",  "ps");
    		}else if(user != null && user.getUseLangCd() != null && user.getUseLangCd().equals("2")){
    			model.addAttribute("useLangCd",  "dr");
    		}else if(user != null && user.getUseLangCd() != null && user.getUseLangCd().equals("3")){
    			model.addAttribute("useLangCd",  "en");
    		}else{
    			model.addAttribute("useLangCd",  "ps");
    		}
    		
    		String vefyRgstFromDd = propertiesService.getString("vefyRgstFromDd");
    		String vefyRgstToDd = propertiesService.getString("vefyRgstToDd");
    		EgovMap em = new EgovMap();
    		em.put("vefyRgstFromDd", vefyRgstFromDd);
    		em.put("vefyRgstToDd", vefyRgstToDd);
    		String vefyRgstDdYn = service.searchVefyRgstDdYn(em);
    		model.addAttribute("vefyRgstDdYn", vefyRgstDdYn);
    		
    		comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("nltyCd", nltyCd);
    		
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
	        model.addAttribute("kochiAdCd", kochiAdCd);
	        
	        int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		List<EgovMap> rmRlLst = service.searchRmRlTb(new String("")); 
	        model.addAttribute("rmRlLst", rmRlLst);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/fmly/p_FmlyInfrAdd";
    }
    
    
    
    
    /**
     *Social security number, name search. <br>
     *
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/searchRsdtInfr.do")
    public void searchRsdtInfr(
    		@ModelAttribute("fmlyInfoVO") FmlyInfrVO vo,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		EgovMap ems = (EgovMap)service.searchRsdtInfr(vo);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		if(ems != null && !ems.isEmpty()){
    			Element person = doc.createElement("person");
    			
    			String rsdtSeqNo = getEgovMapValue(ems, "rsdtSeqNo");
    			String rsdtNo = getEgovMapValue(ems, "rsdtNo");
    			String givNm = getEgovMapValue(ems, "givNm");
    			String surnm = getEgovMapValue(ems, "surnm");
    			String useYn = getEgovMapValue(ems, "useYn");
    			String rsdtStusCd = getEgovMapValue(ems, "rsdtStusCd");
    			String gdrCd = getEgovMapValue(ems, "gdrCd");
    			String fullNm = getEgovMapValue(ems, "fullNm");
    			
    			Element infr = doc.createElement("rsdtSeqNo");
    			infr.appendChild(doc.createTextNode(rsdtSeqNo));
    			person.appendChild(infr);
    			infr = doc.createElement("rsdtNo");
    			infr.appendChild(doc.createTextNode(rsdtNo));
    			person.appendChild(infr);
    			infr = doc.createElement("givNm");
    			infr.appendChild(doc.createTextNode(givNm));
    			person.appendChild(infr);
    			infr = doc.createElement("surnm");
    			infr.appendChild(doc.createTextNode(surnm));
    			person.appendChild(infr);
    			infr = doc.createElement("useYn");
    			infr.appendChild(doc.createTextNode(useYn));
    			person.appendChild(infr);
    			infr = doc.createElement("rsdtStusCd");
    			infr.appendChild(doc.createTextNode(rsdtStusCd));
    			person.appendChild(infr);
    			infr = doc.createElement("gdrCd");
    			infr.appendChild(doc.createTextNode(gdrCd));
    			person.appendChild(infr);
    			infr = doc.createElement("fullNm");
    			infr.appendChild(doc.createTextNode(fullNm));
    			person.appendChild(infr);
    			
	    		root.appendChild(person);
    		}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    /**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param EgovMap, String
	 * @return String
	 * @exception Exception
	 */
	private String getEgovMapValue(EgovMap obj, String value){
		String result = "";
		if(obj != null && !obj.isEmpty() && value != null){
			Object object = obj.get(value);
			if(object != null){
				if(object instanceof BigDecimal){
					BigDecimal big = (BigDecimal)object;
					int bigInt = big.intValue();
					result = String.valueOf(bigInt);
				}else if(object instanceof String){
					result = (String)object;
				}
			}
		}
		return result;
	}
	
	
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param List, String
	 * @return List
	 * @exception Exception
	 */
	private List<FmlyInfrVO> setGridDataConvert(List<FmlyInfrVO> list, String cal, String type){
		List<FmlyInfrVO> result = list;
		if(list != null && (cal != null && ("j".equals(cal.toLowerCase()) || "".equals(cal)) || cal == null) ){
			if(!list.isEmpty()){
				for(int i = 0; i < list.size(); i++){
					Object obj = list.get(i);
					if(obj instanceof FmlyInfrVO){
						FmlyInfrVO vo = (FmlyInfrVO)obj;
						if(type != null && "list".equals(type)){
							String str = vo.getFmlyBokRgstDd();
							str = NidStringUtil.toNumberConvet(str, "j");
							vo.setFmlyBokRgstDd(str);
						}else if(type != null && "mem".equals(type)){
							String str = vo.getBthDdJ();
							str = NidStringUtil.toNumberConvet(str, "j");
							vo.setBthDdJ(str);
						}
						result.set(i, vo);
					}
				}
			}
		}
		return result;
	}
	
	
	
	/**
     * Family moved to the registration screen. <br>
     * 
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/fmly/p_FmlyInfrFnd.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/fmly/searchListFmlyInfrPopView.do")
    public String searchListFmlyInfrPopView(
    		@ModelAttribute("fmlyInfoVO") FmlyInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("useLangCd",  user.getUseLangCd());
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/fmly/p_FmlyInfrFnd";
    }
    
    
    
    /**
     * self and the birth date of check <br>
     *
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value={"/rm/fmly/searchChkSelfDd.do","/rm/rsdt/searchChkSelfDd.do"})
    public void searchChkSelfDd(
    		ModelMap model,
    		HttpServletResponse response,
    		@RequestParam(value="srcCal" ,required=false) String srcCal,
    		@RequestParam(value="srcBthDd" ,required=false) String srcBthDd,
    		@RequestParam(value="tagCal" ,required=false) String tagCal,
    		@RequestParam(value="tagBthDd" ,required=false) String tagBthDd,
    		@RequestParam(value="child" ,required=false) String child)
            throws Exception {
    	try{
    		EgovMap em = new EgovMap();
    		em.put("srcCal", srcCal);
    		em.put("srcBthDd", srcBthDd);
    		em.put("tagCal", tagCal);
    		em.put("tagBthDd", tagBthDd);
    		em.put("child", child);
    		String flag = service.searchChkSelfDd(em);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		if(flag != null && !"".equals(flag)){
    			Element el = doc.createElement("flag");
    			el.appendChild(doc.createTextNode(flag));
	    		root.appendChild(el);
    		}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
    
    
    
    
    
    
    
    
    /**
     * self and the birth date of check <br>
     *
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value={"/rm/fmly/searchChkBthDdLimit.do","/rm/rsdt/searchChkBthDdLimit.do"})
    public void searchChkBthDdLimit(
    		ModelMap model,
    		HttpServletResponse response,
    		@RequestParam(value="cal" ,required=false) String cal,
    		@RequestParam(value="bthDd" ,required=false) String bthDd,
    		@RequestParam(value="adultAge" ,required=false) String adultAge,
    		@RequestParam(value="cals" ,required=false) String cals,
    		@RequestParam(value="bthDds" ,required=false) String bthDds)
            throws Exception {
    	try{
    		EgovMap em = new EgovMap();
    		em.put("cal", cal);
    		em.put("bthDd", bthDd);
    		em.put("adultAge", adultAge);
    		em.put("cals", cals);
    		em.put("bthDds", bthDds);
    		String flag = service.searchChkBthDdLimit(em);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		if(flag != null && !"".equals(flag)){
    			Element el = doc.createElement("flag");
    			el.appendChild(doc.createTextNode(flag));
	    		root.appendChild(el);
    		}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
    
    
    
    
    
    
    /**
     * self and the birth date of check <br>
     *
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value={"/rm/fmly/searchRsdtInfrBthDd.do","/rm/rsdt/searchRsdtInfrBthDd.do"})
    public void searchRsdtInfrBthDd(
    		ModelMap model,
    		HttpServletResponse response,
    		@RequestParam(value="rsdtNo" ,required=false) String rsdtNo)
            throws Exception {
    	try{
    		EgovMap em = new EgovMap();
    		em.put("rsdtNo", rsdtNo);
    		String flag = service.searchRsdtInfrBthDd(em);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		if(flag != null && !"".equals(flag)){
    			Element el = doc.createElement("flag");
    			el.appendChild(doc.createTextNode(flag));
	    		root.appendChild(el);
    		}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
    
    /**
     * Check whether a person resident information and other residents see <br>
     *
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value={"/rm/fmly/searchRsdtInfrSeqInChk.do","/rm/rsdt/searchRsdtInfrSeqInChk.do"})
    public void searchRsdtInfrSeqInChk(
    		ModelMap model,
    		HttpServletResponse response,
    		@RequestParam(value="rsdtSeqNo" ,required=false) String rsdtSeqNo,
    		@RequestParam(value="fmlyBokNo" ,required=false) String fmlyBokNo)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		// fmlyBokNo1 district, fmlyBokNo2 team code
    		String orgnzCd = user.getOrgnzCd();
    		String teamCd = user.getTamCdNm();
    		String orgnzClsCd = user.getOrgnzClsCd();
    		String rgstOrgnzCd = orgnzClsCd+orgnzCd+teamCd;
    		EgovMap em = new EgovMap();
    		em.put("rsdtSeqNo", rsdtSeqNo);
    		em.put("fmlyBokNo", fmlyBokNo);
    		em.put("rgstOrgnzCd", rgstOrgnzCd);
    		List<EgovMap> list = service.searchRsdtInfrSeqInChk(em);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element eleInfo = null;
    		Element ele = null;
    		for(int i=0; i<list.size(); i++){
    			EgovMap ems = list.get(i);
    			if(ems != null){
	    			eleInfo = doc.createElement("person");
	    			root.appendChild(eleInfo);
	    			ele = doc.createElement("tye");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)ems.get("tye")) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("fmlyBokNo");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)ems.get("fmlyBokNo")) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("name");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)ems.get("name")) ));
	    			eleInfo.appendChild(ele);
    			}
	    	}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
    
    
    /**
     * self and the birth date of check <br>
     *
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value={"/rm/fmly/searchFmlyRgstRsdtInfr.do","/rm/rsdt/searchFmlyRgstRsdtInfr.do"})
    public void searchFmlyRgstRsdtInfr(
    		ModelMap model,
    		HttpServletResponse response,
    		@RequestParam(value="rsdtSeqNo" ,required=false) String rsdtSeqNo)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		EgovMap em = new EgovMap();
    		em.put("rsdtSeqNo", rsdtSeqNo);
    		em.put("useLangCd", user.getUseLangCd());
    		EgovMap ems = service.searchFmlyRgstRsdtInfr(em);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		if(ems != null && !ems.isEmpty()){
    			Element person = doc.createElement("person");
    			String fmlyBokNo = getEgovMapValue(ems, "fmlyBokNo");
    			String fmlyBokNoDp = getEgovMapValue(ems, "fmlyBokNoDp");
    			String givNm = getEgovMapValue(ems, "givNm");
    			String surnm = getEgovMapValue(ems, "surnm");
    			String name = getEgovMapValue(ems, "name");
    			String gdrCd = getEgovMapValue(ems, "gdrCd");
    			String gdrCdNm = getEgovMapValue(ems, "gdrCdNm");
    			String rlCd = getEgovMapValue(ems, "rlCd");
    			String rlCdNm = getEgovMapValue(ems, "rlCdNm");
    			String bthDd = getEgovMapValue(ems, "bthDd");
    			String calTye = getEgovMapValue(ems, "calTye");
    			String rsdtNo = getEgovMapValue(ems, "rsdtNo");
    			String rsdtNoDp = getEgovMapValue(ems, "rsdtNoDp");
    			
    			Element infr = doc.createElement("fmlyBokNo");
    			infr.appendChild(doc.createTextNode(fmlyBokNo));
    			person.appendChild(infr);
    			infr = doc.createElement("fmlyBokNoDp");
    			infr.appendChild(doc.createTextNode(fmlyBokNoDp));
    			person.appendChild(infr);
    			infr = doc.createElement("givNm");
    			infr.appendChild(doc.createTextNode(givNm));
    			person.appendChild(infr);
    			infr = doc.createElement("surnm");
    			infr.appendChild(doc.createTextNode(surnm));
    			person.appendChild(infr);
    			infr = doc.createElement("name");
    			infr.appendChild(doc.createTextNode(name));
    			person.appendChild(infr);
    			infr = doc.createElement("gdrCd");
    			infr.appendChild(doc.createTextNode(gdrCd));
    			person.appendChild(infr);
    			infr = doc.createElement("gdrCdNm");
    			infr.appendChild(doc.createTextNode(gdrCdNm));
    			person.appendChild(infr);
    			infr = doc.createElement("rlCd");
    			infr.appendChild(doc.createTextNode(rlCd));
    			person.appendChild(infr);
    			infr = doc.createElement("rlCdNm");
    			infr.appendChild(doc.createTextNode(rlCdNm));
    			person.appendChild(infr);
    			infr = doc.createElement("bthDd");
    			infr.appendChild(doc.createTextNode(bthDd));
    			person.appendChild(infr);
    			infr = doc.createElement("calTye");
    			infr.appendChild(doc.createTextNode(calTye));
    			person.appendChild(infr);
    			infr = doc.createElement("rsdtNo");
    			infr.appendChild(doc.createTextNode(rsdtNo));
    			person.appendChild(infr);
    			infr = doc.createElement("rsdtNoDp");
    			infr.appendChild(doc.createTextNode(rsdtNoDp));
    			person.appendChild(infr);
	    		root.appendChild(person);
    		}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
    
    
    
    /**
     * self and the birth date of check <br>
     *
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value={"/rm/fmly/searchRsdtInfrMothRlCn.do","/rm/rsdt/searchRsdtInfrMothRlCn.do"})
    public void searchRsdtInfrMothRlCn(
    		ModelMap model,
    		HttpServletResponse response,
    		@RequestParam(value="rsdtSeqNo" ,required=false) String rsdtSeqNo)
            throws Exception {
    	try{
    		EgovMap em = new EgovMap();
    		em.put("rsdtSeqNo", rsdtSeqNo);
    		List<EgovMap> list = service.searchRsdtInfrMothRlCn(em);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element eleInfo = null;
    		Element ele = null;
    		if(list != null){
    			for(int i=0; i<list.size(); i++){
        			EgovMap ems = list.get(i);
        			if(ems != null){
    	    			eleInfo = doc.createElement("person");
    	    			root.appendChild(eleInfo);
    	    			ele = doc.createElement("fmlyBokNo");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)ems.get("fmlyBokNo")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("fmlyBokNoDp");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)ems.get("fmlyBokNoDp")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("givNm");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)ems.get("givNm")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("surnm");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)ems.get("surnm")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("name");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)ems.get("name")) ));
    	    			eleInfo.appendChild(ele);
        			}
    	    	}
    		}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
}