
package afnid.rm.fmly.service;

import java.util.List;

/** 
 * This service interface is biz-class of common. <br>
 * 
 * @author Afghanistan National ID Card System Application Team MS KIM
 * @since 2015.08.06
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           					Revisions
 *   2015.08.06  		moon soo kim         						Create
 *
 * </pre>
 */

public interface FmlyRlRuleService {
	
	/**
	 * Retrieves list of Family Relationship Rule. <br>
	 * 
	 * @param vo Input item for retrieving list of Family Relationship Rule(FmlyRlRuleVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<FmlyRlRuleVO> searchListFmlyRlRule(FmlyRlRuleVO vo) throws Exception;
	
	/**
	 * Retrieves total count of Family Relationship Rule list. <br>
	 * @param vo Input item for retrieving total count list of Family Relationship Rule.(FmlyRlRuleVO)
	 * @return int Total Count of Family Relationship Rule list
	 * @exception Exception
	 */
	int searchListFmlyRlRuleTotCnt(FmlyRlRuleVO vo) throws Exception;
	
		
	/**
	 * Select Family Relationship Rule <br>
	 * 
	 * @param vo Input item for retrieving Family Relationship Rule(FmlyRlRuleVO).
	 * @return FmlyRlRuleVO Retrieve VO of Family Relationship Rule.
	 * @exception Exception
	 */
	FmlyRlRuleVO searchFmlyRlRule(FmlyRlRuleVO vo) throws Exception;
	
	
	/**
	 * Update Family Relationship Rule <br>
	 * 
	 * @param vo Input item for update Family Relationship Rule(FmlyRlRuleVO).
	 * @return  int update result
	 * @exception Exception
	 */
	int modifyFmlyRlRule(FmlyRlRuleVO vo) throws Exception;
	
	/**
	 * Insert Family Relationship Rule <br>
	 * 
	 * @param vo Input item for insert Family Relationship Rule(FmlyRlRuleVO).
	 * @return void
	 * @exception Exception
	 */
	void addFmlyRlRule(FmlyRlRuleVO vo) throws Exception;
	
	
	/**
	 * Check key duplication. <br>
	 * @param vo 
	 * @return String 
	 * @exception Exception
	 */
	public String searchChkKey(FmlyRlRuleVO vo) throws Exception;		
	
}
