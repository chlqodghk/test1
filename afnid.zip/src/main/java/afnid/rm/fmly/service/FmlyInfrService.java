
package afnid.rm.fmly.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;




/** 
 * This service interface is biz-class of common. <br>
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2013.01.04  		BH Choi				Create
 *
 * </pre>
 */

public interface FmlyInfrService {
	
	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<FmlyInfrVO> searchListFmlyInfr(FmlyInfrVO vo) throws Exception;
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(FmlyInfrVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListTotCnFmlyInfr(FmlyInfrVO vo) throws Exception;
	
	
	/**
	 * insert family program <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return String Registered Family Book Number
	 * @exception Exception
	 */
	String addFmlyInfr(FmlyInfrVO vo) throws Exception;
	
	
	/**
	 * insert family program <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return  int update of program
	 * @exception Exception
	 */
	int modifyFmlyInfr(FmlyInfrVO vo) throws Exception;
	
	/**
	 * select family program <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return FmlyInfrVO Retrieve vo of program
	 * @exception Exception
	 */
	FmlyInfrVO searchFmlyInfrView(FmlyInfrVO vo) throws Exception;
	
	
	
	/**
	 * select family program <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<FmlyInfrVO> searchListFmlyInfrView(FmlyInfrVO vo) throws Exception;
	
	
	
	
	
	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(FmlyInfrVO)
	 * @return String Retrieve string of program
	 * @exception Exception
	 */
	String searchFmlyNo(FmlyInfrVO vo) throws Exception;
	
	
	/**
	 * Social security number, name search. <br>
	 * @param vo Input item for retrieving total count list of program.(FmlyInfrVO)
	 * @return String Retrieve string of program
	 * @exception Exception
	 */
	EgovMap searchRsdtNm(FmlyInfrVO vo) throws Exception;
	
	/**
	 * Social security number, name search. <br>
	 * @param vo Input item for retrieving total count list of program.(FmlyInfrVO)
	 * @return String Retrieve string of program
	 * @exception Exception
	 */
	EgovMap searchFmlyRsdtInfr(FmlyInfrVO vo) throws Exception;
	
	/**
	 * Social security number, name search. <br>
	 * @param FmlyInfrVO
	 * @return EgovMap
	 * @exception Exception
	 */
	EgovMap searchRsdtInfr(FmlyInfrVO vo) throws Exception;
	
	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param EgovMap
	 * @return String
	 * @exception Exception
	 */
	String searchVefyRgstDdYn(EgovMap vo) throws Exception;
	
	
	/**
	 * self and the birth date of check <br>
	 * @param EgovMap
	 * @return String
	 * @exception Exception
	 */
	String searchChkSelfDd(EgovMap vo) throws Exception;
	
	
	
	
	/**
	 * select family program <br>
	 * 
	 * @param String
	 * @return searchRmRlTb
	 * @exception Exception
	 */
	List<EgovMap> searchRmRlTb(String vo) throws Exception;
	
	
	
	
	/**
	 * self and the birth date of check <br>
	 * @param EgovMap
	 * @return String
	 * @exception Exception
	 */
	String searchChkBthDdLimit(EgovMap vo) throws Exception;
	
	/**
	 * self and the birth date of check <br>
	 * @param EgovMap
	 * @return String
	 * @exception Exception
	 */
	String searchRsdtInfrBthDd(EgovMap vo) throws Exception;
	
	
	
	/**
	 * Check whether a person resident information and other residents see <br>
	 * @param EgovMap
	 * @return String
	 * @exception Exception
	 */
	List<EgovMap> searchRsdtInfrSeqInChk(EgovMap vo) throws Exception;
	
	
	
	/**
	 * Social security number, name search. <br>
	 * @param EgovMap
	 * @return EgovMap
	 * @exception Exception
	 */
	EgovMap searchFmlyRgstRsdtInfr(EgovMap vo) throws Exception;
	
	
	/**
	 * The number of people given me as a mom <br>
	 * @param EgovMap
	 * @return int
	 * @exception Exception
	 */
	List<EgovMap> searchRsdtInfrMothRlCn(EgovMap vo) throws Exception;
	
	
	/**
	 * select family program <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return FmlyInfrVO Retrieve vo of program
	 * @exception Exception
	 */
	FmlyInfrVO searchFmlyInfrHeadDupView(FmlyInfrVO vo) throws Exception;
	
	
}
