
package afnid.rm.fmly.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.fmly.service.FmlyInfrVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;


/** 
 * This class is Database Access Object of common
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.04  		BH Choi         		Create
 *
 * </pre>
 */

@Repository("fmlyInfoDAO")
public class FmlyInfrDAO extends EgovAbstractDAO {
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	
	
	/**
	 * DAO-method for family information of new program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return FmlyInfrVO Object of Program
	 * @exception Exception
	 */
    public String selectFmlyInfrSeq(FmlyInfrVO vo) {
        return (String)selectByPk("fmlyInfoDAO.selectFmlyInfrSeq", vo);
    }
    
    
    /**
	 * DAO-method for registering receipt information of new program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return String Registered Family Book Number 
	 * @exception Exception
	 */
    public String insertFmlyInfr(FmlyInfrVO vo) {
    	String result = null;
    	result = (String)insert("fmlyInfoDAO.insertFmlyInfo", vo);
        return result;
    }
    
    
    /**
	 * DAO-method for registering receipt information of new program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return void
	 * @exception Exception
	 */
    public void insertFmlyInfrHst(FmlyInfrVO vo) {
        insert("fmlyInfoDAO.insertFmlyInfoHst", vo);
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param vo Input item for retrieving detail information of program(FmlyInfrVO).
	 * @return FmlyInfrVO Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<FmlyInfrVO> selectListFmlyInfr(FmlyInfrVO vo) throws Exception{
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword3(NidStringUtil.toNumberConvet(vo.getSearchKeyword3(), "g"));
		vo.setSearchKeyword4(NidStringUtil.toNumberConvet(vo.getSearchKeyword4(), "g"));
		
		vo.setStartDay(NidStringUtil.toNumberConvet(vo.getStartDay(), "g"));
		vo.setEndDay(NidStringUtil.toNumberConvet(vo.getEndDay(), "g"));
		
		return list("fmlyInfoDAO.selectFmlyInfoLst", vo);
	}

    /**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListTotCnFmlyInfr(FmlyInfrVO vo) {
    	
    	vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword3(NidStringUtil.toNumberConvet(vo.getSearchKeyword3(), "g"));
		vo.setSearchKeyword4(NidStringUtil.toNumberConvet(vo.getSearchKeyword4(), "g"));
		
		vo.setStartDay(NidStringUtil.toNumberConvet(vo.getStartDay(), "g"));
		vo.setEndDay(NidStringUtil.toNumberConvet(vo.getEndDay(), "g"));
		
        return (Integer)selectByPk("fmlyInfoDAO.selectFmlyInfoLstTotCnt", vo);
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /**
	 * DAO-method for family information of new program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return FmlyInfrVO Object of Program
	 * @exception Exception
	 */
    public String selectRsdtInfrSeq(FmlyInfrVO vo) {
        return (String)selectByPk("fmlyInfoDAO.selectRsdtInfrSeq", vo);
    }
    
    /**
	 * DAO-method for registering receipt information of new program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return String Registered Social Security Number
	 * @exception Exception
	 */
    public String insertRsdtInfr(FmlyInfrVO vo) {
    	String result = null;
    	synchronized(this){
    		result = (String)insert("fmlyInfoDAO.insertRsdtInfo", vo);
    	}
        return result;
    }
    
    /**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(FmlyInfrVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateRsdtInfr(FmlyInfrVO vo){
		return update("fmlyInfoDAO.updateRsdtInfo", vo);
		
	}
	
	 /**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(FmlyInfrVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateFmlyInfr(FmlyInfrVO vo){
		return update("fmlyInfoDAO.updateFmlyInfo", vo);
		
	}
    
    
    
    
	
	/**
	 * DAO-method for Remove the plug resident information. <br>
	 *
	 * @param vo Input item for registering new program(FmlyInfrVO).
	 * @return void
	 * @exception Exception
	 */
	public void updateRsdtInfrDltFlag(FmlyInfrVO vo) throws Exception{
		update("fmlyInfoDAO.updateRsdtInfoDelFlag", vo);
	}
    
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(FmlyInfrVO).
	 * @return int modifying information of program
	 * @exception Exception
	 */
	public int updateRsdtInfrDlt(FmlyInfrVO vo){
		return update("fmlyInfoDAO.updateRsdtInfoDel", vo);
		
	}
	
    
    /**
	 * DAO-method for family information of new program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return FmlyInfrVO Object of Program
	 * @exception Exception
	 */
    public FmlyInfrVO selectFmlyInfrView(FmlyInfrVO vo) {
        return (FmlyInfrVO)selectByPk("fmlyInfoDAO.selectFmlyInfoView", vo);
    }
    
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param vo Input item for retrieving detail information of program(FmlyInfrVO).
	 * @return FmlyInfoDAO Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<FmlyInfrVO> selectListFmlyInfrView(FmlyInfrVO vo) throws Exception{
		return list("fmlyInfoDAO.selectFmlyInfoLstView", vo);
	}
    
	/**
	 * DAO-method for registering receipt information of new program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return void
	 * @exception Exception
	 */
    public void insertIfBioTb(FmlyInfrVO vo) {
        insert("fmlyInfoDAO.insertImBioTb", vo);
    }
	
	
    /**
	 * DAO-method for Plug resident registration information enrollment. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return String Object of Program
	 * @exception Exception
	 */
    public String selectRsdtRgstYnFlag(FmlyInfrVO vo) {
        return (String)selectByPk("fmlyInfoDAO.selectRsdtRgstYnFlag", vo);
    }
	
	
    /**
	 * DAO-method for Family book number to inquire.. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return String Object of Program
	 * @exception Exception
	 */
    public String selectFmlyNo(FmlyInfrVO vo) {
        return (String)selectByPk("fmlyInfoDAO.selectFmlyNumber", vo);
    }
    
    
    /**
	 * DAO-method for Residents should name lookup. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return EgovMap Object of Program
	 * @exception Exception
	 */
    public EgovMap selectRsdtNm(FmlyInfrVO vo) {
        return (EgovMap)selectByPk("fmlyInfoDAO.selectGetRsdtNm", vo);
    }
    
    /**
	 * DAO-method for Residents should name lookup. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return EgovMap Object of Program
	 * @exception Exception
	 */
    public EgovMap selectFmlyRsdtInfr(FmlyInfrVO vo) {
    	vo.setUseLangCd("1");
    	Object user = NidUserDetailsHelper.getAuthenticatedUser();
    	if(user != null){
    		if(user instanceof LgnVO){
    			LgnVO LgnVo = (LgnVO)(user);
    			vo.setUseLangCd(LgnVo.getUseLangCd());
    		}
    	}
        return (EgovMap)selectByPk("fmlyInfoDAO.selectFmlyRsdtInfr", vo);
    }
    
    
    /**
	 * DAO-method for Residents should name lookup. <br>
	 * 
	 * @param FmlyInfrVO
	 * @return EgovMap
	 * @exception Exception
	 */
    public EgovMap selectRsdtInfr(FmlyInfrVO vo) {
        return (EgovMap)selectByPk("fmlyInfoDAO.selectRsdtInfr", vo);
    }
    
    /**
	 * DAO-method for Residents should name lookup. <br>
	 * 
	 * @param EgovMap
	 * @return String
	 * @exception Exception
	 */
    public String selectVefyRgstDdYn(EgovMap vo) {
        return (String)selectByPk("fmlyInfoDAO.selectVefyRgstDdYn", vo);
    }
   
    
    /**
	 * DAO-method for self and the birth date of check. <br>
	 * 
	 * @param EgovMap
	 * @return String
	 * @exception Exception
	 */
    public String searchChkSelfDd(EgovMap vo) {
        return (String)selectByPk("fmlyInfoDAO.searchChkSelfDd", vo);
    }
    
    
    
    
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param FmlyInfrVO
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRmRlTb(String vo) throws Exception{
		Object user = NidUserDetailsHelper.getAuthenticatedUser();
		String useLangCd = "1";
    	if(user != null){
    		if(user instanceof LgnVO){
    			LgnVO LgnVo = (LgnVO)(user);
    			useLangCd = LgnVo.getUseLangCd();
    		}
    	}
		EgovMap vos = new EgovMap();
		vos.put("useLangCd", useLangCd);
		return list("fmlyInfoDAO.selectRmRlTb", vos);
	}
	
	
	
	/**
	 * DAO-method for self and the birth date of check. <br>
	 * 
	 * @param EgovMap
	 * @return String
	 * @exception Exception
	 */
    public String selectChkBthDdLimit(EgovMap vo) {
        return (String)selectByPk("fmlyInfoDAO.selectChkBthDdLimit", vo);
    }
    
    
    
    
    /**
	 * DAO-method for self and the birth date of check. <br>
	 * 
	 * @param EgovMap
	 * @return String
	 * @exception Exception
	 */
    public String selectRsdtInfrBthDd(EgovMap vo) {
        return (String)selectByPk("fmlyInfoDAO.selectRsdtInfrBthDd", vo);
    }
    
    
    
    /**
	 * DAO-method for Check whether a person resident information and other residents see. <br>
	 * 
	 * @param EgovMap
	 * @return String
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
    public List<EgovMap> selectRsdtInfrSeqInChk(EgovMap vo) {
        return list("fmlyInfoDAO.selectRsdtInfrSeqInChk", vo);
    }
    
    
    
    
    
    
    
    /**
	 * DAO-method for Residents should name lookup. <br>
	 * 
	 * @param FmlyInfrVO
	 * @return EgovMap
	 * @exception Exception
	 */
    public EgovMap selectFmlyRgstRsdtInfr(EgovMap vo) {
        return (EgovMap)selectByPk("fmlyInfoDAO.selectFmlyRgstRsdtInfr", vo);
    }
    
    /**
	 * DAO-method for Residents should name lookup. <br>
	 * 
	 * @param FmlyInfrVO
	 * @return EgovMap
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<EgovMap> selectRsdtInfrMothRlCn(EgovMap vo) {
    	return list("fmlyInfoDAO.selectRsdtInfrMothRlCn", vo);
    }
    
    
    
    /**
	 * DAO-method for family information of new program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return FmlyInfrVO Object of Program
	 * @exception Exception
	 */
    public FmlyInfrVO selectFmlyInfrHeadDupView(FmlyInfrVO vo) {
        return (FmlyInfrVO)selectByPk("fmlyInfoDAO.selectFmlyInfrHeadDupView", vo);
    }
    
    
    /**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(FmlyInfrVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateRsdtInfrHeadDup(FmlyInfrVO vo){
		return update("fmlyInfoDAO.updateRsdtInfrHeadDup", vo);
		
	}
    
}
