/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package afnid.rm.fmly.service;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of board information
 * 
 * @author Afghanistan National ID Card System Application Team 
 * @since 2013.05.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers         	Revisions
 *   2015.08.26 		moon soo kim        Create
 *
 * </pre>
 */

public class FmlyRlRuleVO extends ComDefaultVO {
	
    private static final long serialVersionUID = 1L;
    
    String rlSeqNo;
    String rlCd;
    String rlCdNm;
    String agGap;
    String mberCn;
    String mberCnTyeCd;
    String fixedRlYn;
    String fthrRlCd;
    String fthrRlCdNm;
    String fthrMdtrYn;
    String gfthrRlCd;
    String gfthrRlCdNm;
    String gfthrMdtrYn;
    String mthrRlCd;
    String mthrRlCdNm;
    String mthrMdtrYn;
    String hsbdRlCd;
    String hsbdRlCdNm;
    String hsbdMdtrYn;
    
    String fthrAgGap;
    String gfthrAgGap;
    String mthrAgGap;
    String md;
    String userId;
    String mberRstrtGdrCd;
    String mberRstrtGdrCdNm;
    String selfGdrCd;
    String selfGdrCdNm;    
    String bfSelfGdrCd;
    
	public String getRlSeqNo() {
		return rlSeqNo;
	}
	public void setRlSeqNo(String rlSeqNo) {
		this.rlSeqNo = rlSeqNo;
	}
	public String getRlCd() {
		return rlCd;
	}
	public void setRlCd(String rlCd) {
		this.rlCd = rlCd;
	}
	public String getRlCdNm() {
		return rlCdNm;
	}
	public void setRlCdNm(String rlCdNm) {
		this.rlCdNm = rlCdNm;
	}
	public String getAgGap() {
		return agGap;
	}
	public void setAgGap(String agGap) {
		this.agGap = agGap;
	}
	public String getMberCn() {
		return mberCn;
	}
	public void setMberCn(String mberCn) {
		this.mberCn = mberCn;
	}
	public String getMberCnTyeCd() {
		return mberCnTyeCd;
	}
	public void setMberCnTyeCd(String mberCnTyeCd) {
		this.mberCnTyeCd = mberCnTyeCd;
	}
	public String getFixedRlYn() {
		return fixedRlYn;
	}
	public void setFixedRlYn(String fixedRlYn) {
		this.fixedRlYn = fixedRlYn;
	}
	public String getFthrRlCd() {
		return fthrRlCd;
	}
	public void setFthrRlCd(String fthrRlCd) {
		this.fthrRlCd = fthrRlCd;
	}
	public String getFthrRlCdNm() {
		return fthrRlCdNm;
	}
	public void setFthrRlCdNm(String fthrRlCdNm) {
		this.fthrRlCdNm = fthrRlCdNm;
	}
	public String getFthrMdtrYn() {
		return fthrMdtrYn;
	}
	public void setFthrMdtrYn(String fthrMdtrYn) {
		this.fthrMdtrYn = fthrMdtrYn;
	}
	public String getGfthrRlCd() {
		return gfthrRlCd;
	}
	public void setGfthrRlCd(String gfthrRlCd) {
		this.gfthrRlCd = gfthrRlCd;
	}
	public String getGfthrRlCdNm() {
		return gfthrRlCdNm;
	}
	public void setGfthrRlCdNm(String gfthrRlCdNm) {
		this.gfthrRlCdNm = gfthrRlCdNm;
	}
	public String getGfthrMdtrYn() {
		return gfthrMdtrYn;
	}
	public void setGfthrMdtrYn(String gfthrMdtrYn) {
		this.gfthrMdtrYn = gfthrMdtrYn;
	}
	public String getMthrRlCd() {
		return mthrRlCd;
	}
	public void setMthrRlCd(String mthrRlCd) {
		this.mthrRlCd = mthrRlCd;
	}
	public String getMthrRlCdNm() {
		return mthrRlCdNm;
	}
	public void setMthrRlCdNm(String mthrRlCdNm) {
		this.mthrRlCdNm = mthrRlCdNm;
	}
	public String getMthrMdtrYn() {
		return mthrMdtrYn;
	}
	public void setMthrMdtrYn(String mthrMdtrYn) {
		this.mthrMdtrYn = mthrMdtrYn;
	}
	public String getHsbdRlCd() {
		return hsbdRlCd;
	}
	public void setHsbdRlCd(String hsbdRlCd) {
		this.hsbdRlCd = hsbdRlCd;
	}
	public String getHsbdRlCdNm() {
		return hsbdRlCdNm;
	}
	public void setHsbdRlCdNm(String hsbdRlCdNm) {
		this.hsbdRlCdNm = hsbdRlCdNm;
	}
	public String getHsbdMdtrYn() {
		return hsbdMdtrYn;
	}
	public void setHsbdMdtrYn(String hsbdMdtrYn) {
		this.hsbdMdtrYn = hsbdMdtrYn;
	}
	public String getFthrAgGap() {
		return fthrAgGap;
	}
	public void setFthrAgGap(String fthrAgGap) {
		this.fthrAgGap = fthrAgGap;
	}
	public String getGfthrAgGap() {
		return gfthrAgGap;
	}
	public void setGfthrAgGap(String gfthrAgGap) {
		this.gfthrAgGap = gfthrAgGap;
	}
	public String getMthrAgGap() {
		return mthrAgGap;
	}
	public void setMthrAgGap(String mthrAgGap) {
		this.mthrAgGap = mthrAgGap;
	}
	public String getMd() {
		return md;
	}
	public void setMd(String md) {
		this.md = md;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getMberRstrtGdrCd() {
		return mberRstrtGdrCd;
	}
	public void setMberRstrtGdrCd(String mberRstrtGdrCd) {
		this.mberRstrtGdrCd = mberRstrtGdrCd;
	}
	public String getMberRstrtGdrCdNm() {
		return mberRstrtGdrCdNm;
	}
	public void setMberRstrtGdrCdNm(String mberRstrtGdrCdNm) {
		this.mberRstrtGdrCdNm = mberRstrtGdrCdNm;
	}
	public String getSelfGdrCd() {
		return selfGdrCd;
	}
	public void setSelfGdrCd(String selfGdrCd) {
		this.selfGdrCd = selfGdrCd;
	}
	public String getSelfGdrCdNm() {
		return selfGdrCdNm;
	}
	public void setSelfGdrCdNm(String selfGdrCdNm) {
		this.selfGdrCdNm = selfGdrCdNm;
	}
	public String getBfSelfGdrCd() {
		return bfSelfGdrCd;
	}
	public void setBfSelfGdrCd(String bfSelfGdrCd) {
		this.bfSelfGdrCd = bfSelfGdrCd;
	}

    
}