package afnid.rm.fmly.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.rm.fmly.service.FmlyRlRuleService;
import afnid.rm.fmly.service.FmlyRlRuleVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;


/** 
 * This service class is biz-class of common
 * and implements FmlyRlRuleService class.
 * 
 * @author Afghanistan National ID Card System Application Team MS KIM
 * @since 2015.08.06
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           					Revisions
 *   2015.08.06  		moon soo kim         						Create
 *
 * </pre>
 */

@Service("fmlyRlRuleService")
public class FmlyRlRuleServiceImpl extends AbstractServiceImpl implements FmlyRlRuleService {
	
	/** FmlyRlRuleDAO */
    @Resource(name="fmlyRlRuleDAO")
    private FmlyRlRuleDAO dao;

    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    /**
	 * Biz-method for retrieving list of Family Relationship Rule. <br>
	 * 
	 * @param vo Input item for retrieving list of Family Relationship Rule.(FmlyRlRuleVO).
	 * @return List Retrieve list of Family Relationship Rule.
	 * @exception Exception
	 */
	public List<FmlyRlRuleVO> searchListFmlyRlRule(FmlyRlRuleVO vo) throws Exception {
   		return dao.selectListFmlyRlRule(vo);
	}
	
	/**
	 * Biz-method for retrieving total count list of Family Relationship Rule. <br>
	 * 
	 * @param vo Input item for retrieving list of Family Relationship Rule.(FmlyRlRuleVO).
	 * @return int Total Count of Family Relationship Rule.
	 * @exception Exception
	 */
    public int searchListFmlyRlRuleTotCnt(FmlyRlRuleVO vo) throws Exception {
        return dao.selectListFmlyRlRuleTotCnt(vo);
	}
        
	
	/**
	 * Biz-method for retrieving Family Relationship Rule. <br>
	 * 
	 * @param vo Input item for retrieving list of Family Relationship Rule(FmlyRlRuleVO).
	 * @return FmlyInfrVO Retrieve VO of Family Relationship Rule
	 * @exception Exception
	 */
	public FmlyRlRuleVO searchFmlyRlRule(FmlyRlRuleVO vo) throws Exception{
		return dao.selectFmlyRlRule(vo);
	}
	
	
    /**
	 * Biz-method for update information of new Family Relationship Rule. <br>
	 * 
	 * @param vo Input item for update Family Relationship Rule(FmlyInfrVO).
	 * @return int update result
	 * @exception Exception
	 */
	public int modifyFmlyRlRule(FmlyRlRuleVO vo) throws Exception {

		if(!"".equals(vo.getBfSelfGdrCd()) && "".equals(vo.getSelfGdrCd())){
			String rlSeqNo = dao.selectDelDat(vo);
			
			if(rlSeqNo != null && rlSeqNo.length() > 0){
				dao.deleteFmlyRlRule(rlSeqNo);
			}
		}
		
		if("".equals(vo.getBfSelfGdrCd()) && !"".equals(vo.getSelfGdrCd())){
			String selfGdrCd = vo.getSelfGdrCd();
			
			if("1".equals(selfGdrCd)){
				vo.setSelfGdrCd("2");
			} else {
				vo.setSelfGdrCd("1");
			}
			
			dao.insertFmlyRlRule(vo);
			
			vo.setSelfGdrCd(selfGdrCd);			
		}		
		
   		return dao.updateFmlyRlRule(vo);
	}

    /**
	 * Biz-method for insert Family Relationship Rule. <br>
	 * 
	 * @param vo Input item for insert Family Relationship RuleFmlyRlRuleVO).
	 * @return String Registered Family Book Number
	 * @exception Exception
	 */
	public void addFmlyRlRule(FmlyRlRuleVO vo) throws Exception {

		
		if(vo.getSelfGdrCd() == null || "".equals(vo.getSelfGdrCd())){
			int selfGdrCdCnt = dao.searchSameKeySelfGdrCdCnt(vo);
			
			if(selfGdrCdCnt == 1){
				FmlyRlRuleVO selfGdrCd = dao.selectSelfGdrCd(vo);
				if("1".equals(selfGdrCd.getSelfGdrCd()) ){
					vo.setSelfGdrCd("2");	
				} else {
					vo.setSelfGdrCd("1");
				}				
			}

		} else if (vo.getSelfGdrCd() != null && !"".equals(vo.getSelfGdrCd())){
			FmlyRlRuleVO selfGdrCd = dao.selectSelfGdrCd(vo);
			
			if(selfGdrCd !=null && !"".equals(selfGdrCd.getRlSeqNo())){
				String rlSeqNo = selfGdrCd.getRlSeqNo();
				String selfGdrCdVal = "";
				
				if("1".equals(vo.getSelfGdrCd())){
					selfGdrCdVal = "2";
				} else {
					selfGdrCdVal = "1";
				}
				
				FmlyRlRuleVO selfGdrCdVO = new FmlyRlRuleVO();
				selfGdrCdVO.setRlSeqNo(rlSeqNo);
				selfGdrCdVO.setSelfGdrCd(selfGdrCdVal);
				
				dao.updateSelfGdrCd(selfGdrCdVO);
			} else{
				String selfGdrCdVal = vo.getSelfGdrCd();
				
				if("1".equals(selfGdrCdVal)){
					vo.setSelfGdrCd("2");
				} else {
					vo.setSelfGdrCd("1");
				}
				
				dao.insertFmlyRlRule(vo);
				
				vo.setSelfGdrCd(selfGdrCdVal);				
			}
		}
		
		dao.insertFmlyRlRule(vo);
	}	
	
	/**
	 * Biz-method for Checking key duplication. <br>
	 *
	 * @param vo Input item for Checking key duplication(FmlyRlRuleVO).
	 * @return String
	 * @exception Exception
	 */
	public String searchChkKey(FmlyRlRuleVO vo) throws Exception {
		String result ="0";
   		String sameValYn = dao.searchSameKeyYn(vo);
   		if("Y".equals(sameValYn)){
   			result = "1";
   		} else {
   			int selfGdrCdCnt = dao.searchSameKeySelfGdrCdCnt(vo);
   			
   			if(selfGdrCdCnt == 2 &&(vo.getSelfGdrCd() == null || "".equals(vo.getSelfGdrCd()))){
   				result = "2";
   			} else if(selfGdrCdCnt == 1 && (vo.getSelfGdrCd() == null || "".equals(vo.getSelfGdrCd()))){
   				result = "3";
   			} else if(selfGdrCdCnt == 0 && (vo.getSelfGdrCd() != null && !"".equals(vo.getSelfGdrCd()))){
   				vo.setSelfGdrCd("");
   				sameValYn = dao.searchSameKeyYn(vo);
   				if("Y".equals(sameValYn)){
   					result = "4";
   				} else {
   					result = "5";
   				}
   			}
   		}

   		log.debug("=================================");
   		log.debug("result : " + result);
   		log.debug("=================================");
		return result;
	}	
}