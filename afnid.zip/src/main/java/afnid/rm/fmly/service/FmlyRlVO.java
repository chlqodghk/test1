/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package afnid.rm.fmly.service;

import java.util.List;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of board information
 * 
 * @author Afghanistan National ID Card System Application Team 
 * @since 2013.05.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers         	Revisions
 *   2013.05.21 		BH Choi         		Create
 *
 * </pre>
 */

public class FmlyRlVO extends ComDefaultVO {
	
    private static final long serialVersionUID = 1L;
    
    private String seqNo;
    private String rsdtSeqNo;
    private String rsdtNo;
    private String name;
    private String userId;
    
    private String tye;
    
    private List<String> motherArray;

	public String getTye() {
		return tye;
	}

	public void setTye(String tye) {
		this.tye = tye;
	}
    
    public FmlyRlVO init(){
    	return new FmlyRlVO();
    }

	public List<String> getMotherArray() {
		return motherArray;
	}

	public void setMotherArray(List<String> motherArray) {
		this.motherArray = motherArray;
	}

	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}

	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}

	public String getRsdtNo() {
		return rsdtNo;
	}

	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
    
    

}