
package afnid.rm.fmly.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.fmly.service.FmlyRlVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;


/** 
 * This class is Database Access Object of common
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.05.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.05.21  		BH Choi         		Create
 *
 * </pre>
 */

@Repository("fmlyRlDAO")
public class FmlyRlDAO extends EgovAbstractDAO {
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return EgovMap
	 * @exception Exception
	 */
	public EgovMap selectFmlyRlRsdtNoInfr(FmlyRlVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		return (EgovMap)selectByPk("fmlyRlDAO.selectFmlyRlRsdtNoInfr", vo);
	}

	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return EgovMap
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectFmlyRlGrandMother(FmlyRlVO vo) throws Exception{
		return list("fmlyRlDAO.selectFmlyRlGrandMother", vo);
	}
	
	
    
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return EgovMap
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectFmlyRlChildList(FmlyRlVO vo) throws Exception{
		return list("fmlyRlDAO.selectFmlyRlChildList", vo);
	}
	
	
	
	
	
	

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return EgovMap
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectFmlyRlGrandFather(FmlyRlVO vo) throws Exception{
		return list("fmlyRlDAO.selectFmlyRlGrandFather", vo);
	}
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return EgovMap
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectFmlyRlChildListMale(FmlyRlVO vo) throws Exception{
		return list("fmlyRlDAO.selectFmlyRlChildListMale", vo);
	}
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return EgovMap
	 * @exception Exception
	 */
	public EgovMap selectFmlyTreeRqstHead(FmlyRlVO vo) throws Exception{
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		return (EgovMap)selectByPk("fmlyRlDAO.selectFmlyTreeRqstHead", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListFmlyTreeRqst(FmlyRlVO vo) throws Exception{
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		return list("fmlyRlDAO.selectListFmlyTreeRqst", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return int
	 * @exception Exception
	 */
	public int selectListTotCnFmlyTreeRqst(FmlyRlVO vo) throws Exception{
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		return (Integer)selectByPk("fmlyRlDAO.selectListTotCnFmlyTreeRqst", vo);
	}
   
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return void
	 * @exception Exception
	 */
	public int insertFmlyTreeRqst(FmlyRlVO vo) throws Exception{
		int result = -1;
		synchronized(this){
			result = (Integer)selectByPk("fmlyRlDAO.selectFmlyTreeRqst", vo);
			result = -1;
			if(result > 0){
				result = update("fmlyRlDAO.updateFmlyTreeRqst", vo);
				if(result > 0){
					delete("fmlyRlDAO.deleteFmlyTreeRqstPrc", vo);
				}
			}else{
				insert("fmlyRlDAO.insertFmlyTreeRqst", vo);
				result = 1;
			}
		}
		return result;
	}
	
	
	
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return EgovMap
	 * @exception Exception
	 */
	public EgovMap selectFmlyTreeRsut(FmlyRlVO vo) throws Exception{
		return (EgovMap)selectByPk("fmlyRlDAO.selectFmlyTreeRsut", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListFmlyTreeRsut(FmlyRlVO vo) throws Exception{
		return list("fmlyRlDAO.selectListFmlyTreeRsut", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return int
	 * @exception Exception
	 */
	public int selectListTotCnFmlyTreeRsut(FmlyRlVO vo) throws Exception{
		return (Integer)selectByPk("fmlyRlDAO.selectListTotCnFmlyTreeRsut", vo);
	}
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListFmlyTreeRsutExcel(FmlyRlVO vo) throws Exception{
		return list("fmlyRlDAO.selectListFmlyTreeRsutExcel", vo);
	}
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return int
	 * @exception Exception
	 */
	public String selectFmlyTreeRqstResult(FmlyRlVO vo) throws Exception{
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		return (String)selectByPk("fmlyRlDAO.selectFmlyTreeRqstResult", vo);
	}
}
