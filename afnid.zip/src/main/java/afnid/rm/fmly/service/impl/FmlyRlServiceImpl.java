package afnid.rm.fmly.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

import javax.annotation.Resource;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.fmly.service.FmlyRlService;
import afnid.rm.fmly.service.FmlyRlVO;
import afnid.rm.hst.service.RsdtInfrLgService;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of common
 * and implements FmlyInfoService class.
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.05.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.05.21  		BH Choi         		Create
 *
 * </pre>
 */

@Service("fmlyRlService")
public class FmlyRlServiceImpl extends AbstractServiceImpl implements FmlyRlService {
	
	/** FmlyRlDAO */
   @Resource(name="fmlyRlDAO")
    private FmlyRlDAO dao;
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    @Resource(name = "rsdtInfrLgService")
    private RsdtInfrLgService rsdtInfrLgService;
    
    ArrayList<EgovMap> list = null;
    List<String> array = null;
    
    /**
	 * ArrayList getter. <br>
	 * 
	 * @param 
	 * @return ArrayList
	 */
    public ArrayList<EgovMap> getList() {
		return list;
	}
    /**
	 * ArrayList setter. <br>
	 * 
	 * @param ArrayList
	 * @return void
	 */
	public void setList(ArrayList<EgovMap> list) {
		this.list = list;
	}
	/**
	 * List getter. <br>
	 * 
	 * @param
	 * @return List
	 */
	public List<String> getArray() {
		return array;
	}
	/**
	 * List setter. <br>
	 * 
	 * @param List
	 * @return void
	 */
	public void setArray(List<String> array) {
		this.array = array;
	}

	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyRlVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public String selectFmlyRlNm(FmlyRlVO vo) throws Exception {
		String result = "";
		if(vo != null){
   			if(vo.getTye() == null || "".equals(vo.getTye())){
   				vo.setTye("R");
   			}
			EgovMap initEm = dao.selectFmlyRlRsdtNoInfr(vo);
			String givNm = getEgovMapValue(initEm, "givNm");
			String surnm = getEgovMapValue(initEm, "surnm");
			if(surnm != null && surnm.length() > 0){
				givNm = givNm + " " + surnm;
			}
			result = givNm;
		}
		return result;
	}
	
    /**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyRlVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public String selectFmlyRl(FmlyRlVO vo) throws Exception {
   		String result = null;
		//ArrayList<EgovMap> list = null;
   		if(vo != null){
   			if(vo.getTye() == null || "".equals(vo.getTye())){
   				vo.setTye("R");
   			}
   			EgovMap initEm = dao.selectFmlyRlRsdtNoInfr(vo);
   			String chisSeq = getEgovMapValue(initEm, "rsdtSeqNo");
   			if(initEm != null && !initEm.isEmpty()){
	   			int topLimit = propertiesService.getInt("uprFmlyTreeNo");
	   			initEm.put("count", String.valueOf(0));
	   			EgovMap topSeq = getTreeTopSeq(initEm, chisSeq, 0, topLimit);
	   			if(topSeq != null && !topSeq.isEmpty()){
	   				String rsdtSeqNo = getEgovMapValue(topSeq, "rsdtSeqNo");
	   				String gdrCd = getEgovMapValue(topSeq, "gdrCd");
	   				String count = getEgovMapValue(topSeq, "count");
	   				setList(new ArrayList<EgovMap>());
	   				setList(setRsdtInfrListAdd(rsdtSeqNo, getList(), "", gdrCd));
	   				setArray(setListAddElement(vo, rsdtSeqNo, getList(), gdrCd));
	   				int cnt = Integer.parseInt(count);
	   				if(cnt == 0){
	   					cnt = 0;
	   				}
	   				int limit = propertiesService.getInt("udrFmlyTreeNo")+cnt;
	   				setListAddElement(rsdtSeqNo, getList(), getArray(), 0, limit, gdrCd);
	   			}
	   			ArrayList<EgovMap> lists = getList();
	   			ArrayList<EgovMap> uniqueItems = null;
   				if(lists != null && !lists.isEmpty()){
   					uniqueItems = new ArrayList<EgovMap>(new LinkedHashSet<EgovMap>(lists));
   					log.debug("rsdtSeqNo, rsdtNo, givNm, surnm, bthDd, gdrCd, rsdtStusCd, parent, type");
   					for(int i = 0; i < lists.size(); i++){
   						EgovMap em = lists.get(i);
   						String rsdtSeqNo = getEgovMapValue(em, "rsdtSeqNo");
   						String rsdtNo = getEgovMapValue(em, "rsdtNo");
   						String givNm = getEgovMapValue(em, "givNm");
   						String surnm = getEgovMapValue(em, "surnm");
   						String bthDd = getEgovMapValue(em, "bthDd");
   						String gdrCd = getEgovMapValue(em, "gdrCd");
   						String rsdtStusCd = getEgovMapValue(em, "rsdtStusCd");
   						String parent = getEgovMapValue(em, "parent");
   						String type = getEgovMapValue(em, "type");
   						log.debug(rsdtSeqNo +", "+rsdtNo +", "+givNm +", "+surnm +", "+bthDd +", "+gdrCd +", "+rsdtStusCd +", "+parent + ", " + type);
   						rsdtInfrLgService.addRsdtInfrLg(rsdtNo, "18");
   					}
   					String resultLst = makTag(uniqueItems, "afnidTreeObj", "afnidFmlyTree");
   					resultLst = resultLst.replaceAll("&lt;", "<").replaceAll("&gt;", ">").replaceAll("&quot;", "\"");
   					result = resultLst;
   				}
   			}else{
   				result = "-1";
   			}
   		}
		return result;
	}
	
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param EgovMap, String
	 * @return String
	 * @exception Exception
	 */
	private String getEgovMapValue(EgovMap obj, String value){
		String result = "";
		if(obj != null && !obj.isEmpty() && value != null){
			Object object = obj.get(value);
			if(object != null){
				if(object instanceof BigDecimal){
					BigDecimal big = (BigDecimal)object;
					int bigInt = big.intValue();
					result = String.valueOf(bigInt);
				}else if(object instanceof String){
					result = (String)object;
				}
			}
		}
		return result;
	}
	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param EgovMap, String
	 * @return String
	 * @exception Exception
	 */
	private ArrayList<EgovMap> setRsdtInfrListAdd(String seq, ArrayList <EgovMap>obj, String parent, String type) throws Exception {
		ArrayList<EgovMap> list = obj;
		if(seq != null && obj != null ){
			FmlyRlVO tmp = new FmlyRlVO();
			tmp.setTye("S");
			tmp.setSearchKeyword(seq);
			EgovMap imsi = dao.selectFmlyRlRsdtNoInfr(tmp);
			if(imsi != null && !imsi.isEmpty()){
				imsi.put("parent", parent);
				imsi.put("type", type);
				list.add(imsi);	
			}
		}
		return list;
	}
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param List, String, String
	 * @return String
	 * @exception Exception
	 */
	public String makTag(List<EgovMap> em, String treeId, String fmlyTree){
		String result = "";
		if(em != null && !em.isEmpty()){
			result = "<div id=\""+treeId+"\"></div>";
			Document doc = Jsoup.parse(result);
			Elements rows = doc.select("#"+treeId);
			if(rows != null && !rows.isEmpty()){
				for(int i = 0; i < em.size(); i++){
					setTagMake(doc, em.get(i), fmlyTree, treeId);
				}
			}
			Element ele = doc.getElementById(treeId);
			result = ele.html();
		}
		return result;
	}
	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param Document, EgovMap, String, String
	 * @return void
	 * @exception Exception
	 */
	private void setTagMake(Document doc, EgovMap em, String root, String nodeId){
		if(doc != null && em != null && !em.isEmpty()){
			String parent = getEgovMapValue(em, "parent");
			if("".equals(parent)){
				addElement(doc, root, em, nodeId);
				
			}else{
				addElement(doc, parent, em, nodeId);
			}
		}
	}
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param Document, String, EgovMap, String
	 * @return void
	 * @exception Exception
	 */
	public void addElement(Document doc, String parId, EgovMap em, String nodeId){
		if(doc != null && parId != null && em != null && !em.isEmpty()){
			Element root = doc.getElementById(parId);
			Element ele = null;
			String rsdtSeqNo = getEgovMapValue(em, "rsdtSeqNo");
			String rsdtNo = getEgovMapValue(em, "rsdtNo");
			String rsdtNoDp = getEgovMapValue(em, "rsdtNoDp");
			String givNm = getEgovMapValue(em, "givNm");
			String surnm = getEgovMapValue(em, "surnm");
			String bthDd = getEgovMapValue(em, "bthDd");
			String gdrCdNm = getEgovMapValue(em, "gdrCdNm");
			String gdrCd = getEgovMapValue(em, "gdrCd");
			String type = getEgovMapValue(em, "type");
			String value = null;
			String title = null;
			StringBuffer sb = new StringBuffer();
			StringBuffer sbs = new StringBuffer();
			Element xxx = doc.createElement("br");
			String separator = xxx.outerHtml();
			//String parent = getEgovMapValue(em, "parent");
			if(surnm != null && surnm.length() > 0){
				givNm = givNm + " " + surnm;
			}
			
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			String useLangCd = user.getUseLangCd();
			int limit = 12;
			if(useLangCd != null && "3".equals(useLangCd)){
				limit = 13;
			}
			String rsdtNoImsi = rsdtNoDp;
			if(rsdtNoImsi != null && rsdtNoImsi.length() > 0){
				rsdtNoImsi = rsdtNoImsi.length() > limit ? rsdtNoImsi.substring(0, limit-2)+".." : rsdtNoImsi;
			}
			String givNmImsi = givNm;
			if(givNmImsi != null && givNmImsi.length() > 0){
				givNmImsi = givNmImsi.length() > limit ? givNmImsi.substring(0, limit-2)+".." : givNmImsi;
			}
			
			String src = "/images/afnid/rm/tree_l/";
			if(gdrCd != null && "2".equals(gdrCd)){
				src += "menu_folder_fs.gif";
			}else{
				src += "menu_folder_ms.gif";
			}
			String img = "<img border=\"0\" src=\""+src+"\" width=\"18\" height=\"18\">";
			sb.append(img).append(separator);
			rsdtNoImsi = "<span onclick=\"fn_view_data('"+rsdtNo+"');\" style=\"cursor:pointer;\" >"+rsdtNoImsi+"</span>";
			sb.append(rsdtNoImsi).append(separator).append(givNmImsi);
			
			separator = "&#10;";
			if(useLangCd != null && "3".equals(useLangCd)){
				rsdtNoDp = nidMessageSource.getMessage("enid") + " : " + rsdtNoDp;
				givNm = nidMessageSource.getMessage("nm") + " : " + givNm;
				bthDd = nidMessageSource.getMessage("bthDd") + " : " + bthDd;
				gdrCdNm = nidMessageSource.getMessage("gdr") + " : " + gdrCdNm;
			}else{
				rsdtNoDp = rsdtNoDp + " : " + nidMessageSource.getMessage("enid");
				givNm = givNm + " : " + nidMessageSource.getMessage("nm");
				bthDd = bthDd + " : " + nidMessageSource.getMessage("bthDd");
				gdrCdNm = gdrCdNm + " : " + nidMessageSource.getMessage("gdr");
			}
			sbs.append(rsdtNoDp).append(separator).append(givNm).append(separator).append(gdrCdNm).append(separator).append(bthDd);
			
			value = sb.toString();
			title = sbs.toString();
			
			if(root != null){
				if(root.children().size() == 0){
					ele = doc.createElement("ul");
					root.appendChild(ele);
				}
			}else{
				root = doc.getElementById(nodeId);
				ele = doc.createElement("ul");
				ele.attr("id", parId);
				root.appendChild(ele);
			}
			
			root = root.child(0);
			ele = doc.createElement("li");
			ele.attr("id", rsdtSeqNo);
			ele.attr("title", title);
			ele.attr("asd", type);
			ele.text(value);
			root.appendChild(ele);
		}
	}
	
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param String, ArrayList, List, int, int, String
	 * @return void
	 * @exception Exception
	 */
	private void setListAddElement(String seq, ArrayList<EgovMap> list, List<String> array, int count, int limit, String gdrCds) throws Exception {
		int countResult = count;
		if(countResult == limit){
			return;
		}
		countResult++;
		FmlyRlVO vos = new FmlyRlVO();
		vos.setSearchKeyword(seq);
		List<String> arrayResult = array;
		setArray(arrayResult);
		if(arrayResult != null && arrayResult.size() == 0){
			//array = null;
			setArray(null);
		}
		vos.setMotherArray(getArray());
		List<EgovMap> chlist = null;
		
		if(gdrCds != null && !"".equals(gdrCds)){
			if("1".equals(gdrCds)){
				chlist = dao.selectFmlyRlChildList(vos);
			}else{
				chlist = dao.selectFmlyRlChildListMale(vos);
			}
			setList(list);
			if(chlist != null && !chlist.isEmpty()){
				for(int i = 0; i < chlist.size(); i++){
					EgovMap em = chlist.get(i);
					String seqS = getEgovMapValue(em, "rsdtSeqNo");
					String gdrCd = getEgovMapValue(em, "gdrCd");
					String parent = getEgovMapValue(em, "parent");
					if(parent != null && !"".equals(parent)){
						setList(setRsdtInfrListAdd(seqS, getList(), parent , gdrCd));
						/*
						if(count == limit){
							return;
						}
						count++;
						*/
						// spus
						setArray(setListAddElement(vos, seqS,  getList(), gdrCd));
		   				setListAddElement(seqS, getList(), getArray(), countResult, limit, gdrCd);
					}
				}
			}
		}
	}
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param FmlyRlVO, String, ArrayList, String
	 * @return ArrayList
	 * @exception Exception
	 */
	private ArrayList<String> setListAddElement(FmlyRlVO vos, String seqS, ArrayList<EgovMap> list, String gdrCd) throws Exception {
		ArrayList<String> array = null;
		vos.setSearchKeyword(seqS);
		List<EgovMap> splist = null;
		if(gdrCd != null && !"".equals(gdrCd)){
			if("1".equals(gdrCd)){
				splist = dao.selectFmlyRlGrandMother(vos);
			}else{
				splist = dao.selectFmlyRlGrandFather(vos);
			}
			setList(list);
			if(splist != null && !splist.isEmpty()){
				array = new ArrayList<String>();
				for(int j = 0; j < splist.size(); j++){
					EgovMap ems = splist.get(j);
					String seqSp = getEgovMapValue(ems, "rsdtSeqNo");
					String gdrCdImsi = gdrCd;
					gdrCdImsi = String.valueOf(Integer.parseInt(gdrCdImsi)+2);
					setList(setRsdtInfrListAdd(seqSp, getList(), seqS, gdrCdImsi));
					array.add(seqSp);
				}
			}
		}
		return array;
	}
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param EgovMap, String, int, int
	 * @return EgovMap
	 * @exception Exception
	 */
	private EgovMap getTreeTopSeq(EgovMap em, String seq, int count, int limit) throws Exception {
		EgovMap emResult = em;
		int countResult = count;
		if(countResult == limit){
			return em;
		}
		String result = seq;
		String fSeq = getEgovMapValue(em, "fthrRsdtSeqNo");
		if(fSeq != null && !"".equals(fSeq)){
			countResult++;
			FmlyRlVO vo = new FmlyRlVO();
			vo.setTye("S");
			vo.setSearchKeyword(fSeq);
			EgovMap initEm = dao.selectFmlyRlRsdtNoInfr(vo);
			initEm.put("count", String.valueOf(countResult));
			emResult = getTreeTopSeq(initEm, result, countResult, limit);
		}
		return emResult;
	}

	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyRlVO).
	 * @return EgovMap
	 * @exception Exception
	 */
	public EgovMap searchFmlyTreeRqstHead(FmlyRlVO vo) throws Exception {
		return dao.selectFmlyTreeRqstHead(vo);
	}
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyRlVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<EgovMap> searchListFmlyTreeRqst(FmlyRlVO vo) throws Exception {
		return dao.selectListFmlyTreeRqst(vo);
	}

	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyRlVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public int searchListTotCnFmlyTreeRqst(FmlyRlVO vo) throws Exception {
		return dao.selectListTotCnFmlyTreeRqst(vo);
	}

	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyRlVO).
	 * @return int
	 * @exception Exception
	 */
	public int addFmlyTreeRqst(FmlyRlVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUserId(user.getUserId());
		return dao.insertFmlyTreeRqst(vo);
	}

	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return EgovMap
	 * @exception Exception
	 */
	public EgovMap searchFmlyTreeRsut(FmlyRlVO vo) throws Exception {
		return dao.selectFmlyTreeRsut(vo);
	}

	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return List
	 * @exception Exception
	 */
	public List<EgovMap> searchListFmlyTreeRsut(FmlyRlVO vo) throws Exception {
		return dao.selectListFmlyTreeRsut(vo);
	}

	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return int
	 * @exception Exception
	 */
	public int searchListTotCnFmlyTreeRsut(FmlyRlVO vo) throws Exception {
		return dao.selectListTotCnFmlyTreeRsut(vo);
	}

	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return List
	 * @exception Exception
	 */
	public List<EgovMap> searchListFmlyTreeRsutExcel(FmlyRlVO vo)
			throws Exception {
		return dao.selectListFmlyTreeRsutExcel(vo);
	}

	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return String
	 * @exception Exception
	 */
	public String searchFmlyTreeRqstResult(FmlyRlVO vo) throws Exception {
		return dao.selectFmlyTreeRqstResult(vo);
	}
	
	
}