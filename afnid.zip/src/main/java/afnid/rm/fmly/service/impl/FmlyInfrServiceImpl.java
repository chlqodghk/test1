package afnid.rm.fmly.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.fmly.service.FmlyInfrService;
import afnid.rm.fmly.service.FmlyInfrVO;
import afnid.rm.rsdt.service.RsdtInfrVO;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;

import com.dongdo.etazkira.ABS.ABSSocket;

import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of common
 * and implements FmlyInfoService class.
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.04  		BH Choi         		Create
 *
 * </pre>
 */

@Service("fmlyInfoService")
public class FmlyInfrServiceImpl extends AbstractServiceImpl implements FmlyInfrService {
	
	/** FmlyInfoDAO */
    @Resource(name="fmlyInfoDAO")
    private FmlyInfrDAO dao;
    
    @Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtDao;
    
    @Resource(name="lgDAO")
    private LgDAO lgDao;
    
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** ID Generation */
    //@Resource(name="egovIdGnrService")    
    //private EgovIdGnrService egovIdGnrService;

    /**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<FmlyInfrVO> searchListFmlyInfr(FmlyInfrVO vo) throws Exception {
   		return dao.selectListFmlyInfr(vo);
	}
	
	/**
	 * Biz-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int searchListTotCnFmlyInfr(FmlyInfrVO vo) throws Exception {
        return dao.selectListTotCnFmlyInfr(vo);
	}
    
    /**
	 * Biz-method for registering information of new program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return String Registered Family Book Number
	 * @exception Exception
	 */
	public String addFmlyInfr(FmlyInfrVO vo) throws Exception {
		
		//Master of Registration
		String useYn = "Y";
		vo.setUseYn(useYn);
		
		
		String fmlyBokSeqNo = null;
		String fmlyBokNo = null;
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
		synchronized(this){
			fmlyBokSeqNo = dao.selectFmlyInfrSeq(vo);
			vo.setFmlyBokSeqNo(fmlyBokSeqNo);
			vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());
			
			vo.setFmlyBokRgstDd(NidStringUtil.toNumberConvet(vo.getFmlyBokRgstDd(), "g"));
			
   			fmlyBokNo =  dao.insertFmlyInfr(vo);
		}
		
		
        String pmntAdCd = vo.getPmntAdCd();
        String pmntAdDtlCt = vo.getPmntAdDtlCt();
        String curtAdCd = vo.getCurtAdCd();
        String curtAdDtlCt = vo.getCurtAdDtlCt();
        
        String givNm = vo.getGivNm();
	   	String surnm = vo.getSurnm();
        
        String fthrNm = vo.getFthrNm();
        String fthrRsdtSeqNo = vo.getFthrRsdtSeqNo();
        String fthrTye = vo.getFthrRgstTye();
        String fthrOldCrdNo1 = vo.getFthrOldCrdNo1();
        String fthrOldCrdNo2 = vo.getFthrOldCrdNo2();
        String fthrOldCrdNo3 = vo.getFthrOldCrdNo3();
        String fthrOldCrdNo4 = vo.getFthrOldCrdNo4();
        
        String gfthrNm = vo.getGfthrNm();
        String gfthrRsdtSeqNo = vo.getGfthrRsdtSeqNo();
        String gfthrTye = vo.getGfthrRgstTye();
        String gfthrOldCrdNo1 = vo.getGfthrOldCrdNo1();
        String gfthrOldCrdNo2 = vo.getGfthrOldCrdNo2();
        String gfthrOldCrdNo3 = vo.getGfthrOldCrdNo3();
        String gfthrOldCrdNo4 = vo.getGfthrOldCrdNo4();
        
        String oldCrdNo1 = vo.getOldCrdNo1();
        String oldCrdNo2 = vo.getOldCrdNo2();
        String oldCrdNo3 = vo.getOldCrdNo3();
        String oldCrdNo4 = vo.getOldCrdNo4();
        
        String cal = vo.getCal();
        String oldCrdIsucePlceCd = vo.getOldCrdIsucePlceCd();
        String oldCrdIsuceDd = vo.getOldCrdIsuceDd();
        
   		String crdIsucePlceCd = user.getOrgnzClsCd()+user.getOrgnzCd();
        
   	    String fmlyHadYn = "Y";
        
   		String rsdtRgstYn = "N";
		String tamLedrCfmYn = "N";
		
		vo.setRsdtRgstYn(rsdtRgstYn);
		vo.setTeamLedrCfmYn(tamLedrCfmYn);
		String userId = user.getUserId();
		
		String curtAdDiv = vo.getCurtAdDiv();
		String curtAdNatCd = vo.getCurtAdNatCd();
		
   		
		fmlyHadYn = "N";
		
   		String [] rsdtNos = vo.getRsdtNos();
   		if(rsdtNos != null){
			String [] recodeNum = vo.getRecodeNum();
			String [] givNms = vo.getGivNms();
			String [] surnms = vo.getSurnms();
			String [] rlCds = vo.getRlCds();
			String [] bthDds = vo.getBthDds();
			String [] curtAdCds = vo.getCurtAdCds();
			String [] curtAdDtlCts = vo.getCurtAdDtlCts();
			String [] gdrCds = vo.getGdrCds();
			String [] cals = vo.getCals();
			String [] frngrYns = vo.getFrngrYns();
			String [] deadYns = vo.getDeadYns();
			String [] fthrRsdtSeqNos = vo.getFthrRsdtSeqNos();
			String [] fthrTyes = vo.getFthrTyes();
			String [] fthrNms = vo.getFthrNms();
			String [] gfthrRsdtSeqNos = vo.getGfthrRsdtSeqNos();
			String [] gfthrTyes = vo.getGfthrTyes();
			String [] gfthrNms = vo.getGfthrNms();
			String [] hsbdRsdtSeqNos = vo.getHsbdRsdtSeqNos();
			String [] hsbdTyes = vo.getHsbdTyes();
			String [] hsbdNms = vo.getHsbdNms();
		   	 
		   	String [] oldCrdNos1 = vo.getOldCrdNos1();
		   	String [] oldCrdNos2 = vo.getOldCrdNos2();
		   	String [] oldCrdNos3 = vo.getOldCrdNos3();
			String [] oldCrdNos4 = vo.getOldCrdNos4();
		   	String [] fthrOldCrdNos1 = vo.getFthrOldCrdNos1();
		   	String [] fthrOldCrdNos2 = vo.getFthrOldCrdNos2();
		   	String [] fthrOldCrdNos3 = vo.getFthrOldCrdNos3();
			String [] fthrOldCrdNos4 = vo.getFthrOldCrdNos4();
		   	String [] gfthrOldCrdNos1 = vo.getGfthrOldCrdNos1();
			String [] gfthrOldCrdNos2 = vo.getGfthrOldCrdNos2();
			String [] gfthrOldCrdNos3 = vo.getGfthrOldCrdNos3();
			String [] gfthrOldCrdNos4 = vo.getGfthrOldCrdNos4();
		   	String [] spusOldCrdNos1 = vo.getSpusOldCrdNos1();
			String [] spusOldCrdNos2 = vo.getSpusOldCrdNos2();
			String [] spusOldCrdNos3 = vo.getSpusOldCrdNos3();
			String [] spusOldCrdNos4 = vo.getSpusOldCrdNos4();
		   	String [] vrfrYns = vo.getVrfrYns();
		   	
		   	String [] curtAdDivs = vo.getCurtAdDivs();
		   	String [] curtAdNatCds = vo.getCurtAdNatCds();
		   	
		   	String [] oldCrdIsuceDds = vo.getOldCrdIsuceDds();
		   	String [] oldCrdIsucePlceCds = vo.getOldCrdIsucePlceCds();
		   	
		   	String [] othrRls = vo.getOthrRls();
   	   		
   	   		FmlyInfrVO info = new FmlyInfrVO();
   	   		// family of head and the family
   	   		
   	   		EgovMap recodeLst = new EgovMap();
   	   		ArrayList<FmlyInfrVO> list = new ArrayList<FmlyInfrVO>();
   			for(int i = 0 ; i < rsdtNos.length; i++){
   				String recodeNumImsi = recodeNum[i].trim();
   				String rsdtNosImsi = rsdtNos[i].trim();
   				String givNmsImsi = givNms[i].trim();
   				String surnmsImsi = surnms[i].trim();
   				String rlCdsImsi = rlCds[i].trim();
   				String bthDdsImsi = bthDds[i].trim();
   				String curtAdCdsImsi = curtAdCds[i].trim();
   				String curtAdDtlCtsImsi = curtAdDtlCts[i].trim();
   				String gdrCdsImsi = gdrCds[i].trim();
   				
   				String calsImsi = cals[i].trim();
   				String frngrYnsImsi = frngrYns[i].trim();
   				String deadYnsImsi = deadYns[i].trim();
   				String fthrRsdtSeqNosImsi = fthrRsdtSeqNos[i].trim();
   				String fthrTyesImsi = fthrTyes[i].trim();
   				String fthrNmsImsi = fthrNms[i].trim();
   				String gfthrRsdtSeqNosImsi = gfthrRsdtSeqNos[i].trim();
   				String gfthrTyesImsi = gfthrTyes[i].trim();
   				String gfthrNmsImsi = gfthrNms[i].trim();
   				String hsbdRsdtSeqNosImsi = hsbdRsdtSeqNos[i].trim();
   				String hsbdTyesImsi = hsbdTyes[i].trim();
   				String hsbdNmsImsi = hsbdNms[i].trim();
   				
   				String oldCrdNosImsi1 = oldCrdNos1[i].trim();
   				String oldCrdNosImsi2 = oldCrdNos2[i].trim();
   				String oldCrdNosImsi3 = oldCrdNos3[i].trim();
   				String oldCrdNosImsi4 = oldCrdNos4[i].trim();
   				
   				String fthrOldCrdNosImsi1 = fthrOldCrdNos1[i].trim();
   				String fthrOldCrdNosImsi2 = fthrOldCrdNos2[i].trim();
   				String fthrOldCrdNosImsi3 = fthrOldCrdNos3[i].trim();
   				String fthrOldCrdNosImsi4 = fthrOldCrdNos4[i].trim();
   				
   				String gfthrOldCrdNosImsi1 = gfthrOldCrdNos1[i].trim();
   				String gfthrOldCrdNosImsi2 = gfthrOldCrdNos2[i].trim();
   				String gfthrOldCrdNosImsi3 = gfthrOldCrdNos3[i].trim();
   				String gfthrOldCrdNosImsi4 = gfthrOldCrdNos4[i].trim();
   				
   				String spusOldCrdNosImsi1 = spusOldCrdNos1[i].trim();
   				String spusOldCrdNosImsi2 = spusOldCrdNos2[i].trim();
   				String spusOldCrdNosImsi3 = spusOldCrdNos3[i].trim();
   				String spusOldCrdNosImsi4 = spusOldCrdNos4[i].trim();
   				
   				String curtAdDivsImsi = curtAdDivs[i].trim();
   				String curtAdNatCdsImsi = curtAdNatCds[i].trim();
   				
   				String vrfrYn = vrfrYns[i].trim();
   				
   				String oldCrdIsuceDdsImsi = oldCrdIsuceDds[i].trim();
   				String oldCrdIsucePlceCdsImsi = oldCrdIsucePlceCds[i].trim();
   				String othrRlsImsi = othrRls[i].trim();
   				
   				info = info.init();
   				info.setFmlyBokNo(fmlyBokNo);
   				info.setRsdtNo(rsdtNosImsi);
   				info.setGivNm(givNmsImsi);
   				info.setSurnm(surnmsImsi);
   				
   				info.setFthrNm(fthrNmsImsi);
   				info.setGfthrNm(gfthrNmsImsi);
   				
   				info.setBthDd(bthDdsImsi);
   				info.setGdrCd(gdrCdsImsi);
   				info.setRlCd(rlCdsImsi);
   				info.setOldCrdNo1(oldCrdNosImsi1);
   				info.setOldCrdNo2(oldCrdNosImsi2);
   				info.setOldCrdNo3(oldCrdNosImsi3);
   				info.setOldCrdNo4(oldCrdNosImsi4);
   				
   				info.setFthrOldCrdNo1(fthrOldCrdNosImsi1);
   				info.setFthrOldCrdNo2(fthrOldCrdNosImsi2);
   				info.setFthrOldCrdNo3(fthrOldCrdNosImsi3);
   				info.setFthrOldCrdNo4(fthrOldCrdNosImsi4);
   				
   				info.setGfthrOldCrdNo1(gfthrOldCrdNosImsi1);
   				info.setGfthrOldCrdNo2(gfthrOldCrdNosImsi2);
   				info.setGfthrOldCrdNo3(gfthrOldCrdNosImsi3);
   				info.setGfthrOldCrdNo4(gfthrOldCrdNosImsi4);
   				
   				info.setSpusOldCrdNo1(spusOldCrdNosImsi1);
   				info.setSpusOldCrdNo2(spusOldCrdNosImsi2);
   				info.setSpusOldCrdNo3(spusOldCrdNosImsi3);
   				info.setSpusOldCrdNo4(spusOldCrdNosImsi4);
   				
   				info.setVrfrYn(vrfrYn);
   				
   				if((curtAdCdsImsi != null && curtAdCdsImsi.length() > 0 ) || (curtAdNatCdsImsi != null && curtAdNatCdsImsi.length() > 0 )){
   					info.setCurtAdCd(curtAdCdsImsi);
   					info.setCurtAdDtlCt(curtAdDtlCtsImsi);
   					info.setCurtAdDiv(curtAdDivsImsi);
   					info.setCurtAdNatCd(curtAdNatCdsImsi);
   				}else{
   					info.setCurtAdCd(curtAdCd);
   					info.setCurtAdDtlCt(curtAdDtlCt);
   					info.setCurtAdDiv(curtAdDiv);
   					info.setCurtAdNatCd(curtAdNatCd);
   				}
   				if(rlCdsImsi != null && rlCdsImsi.length() > 0){
   					//info.setPmntAdCd(pmntAdCd);
		   			//info.setPmntAdDtlCt(pmntAdDtlCt);
   					if("1".equals(rlCdsImsi)){
   						fmlyHadYn = "Y";
   						info.setPmntAdCd(pmntAdCd);
   		   				info.setPmntAdDtlCt(pmntAdDtlCt);
   		   				
	   		   			info.setCurtAdCd(curtAdCd);
	   					info.setCurtAdDtlCt(curtAdDtlCt);
	   					info.setCurtAdDiv(curtAdDiv);
	   					info.setCurtAdNatCd(curtAdNatCd);
   					}else{
   						fmlyHadYn = "N";
   					}
   				}else{
   					fmlyHadYn = "N";
   				}
   				info.setFmlyHadYn(fmlyHadYn);
   				info.setCrdIsucePlceCd(crdIsucePlceCd);
   				info.setRsdtRgstYn(rsdtRgstYn);
   				info.setTamLedrCfmYn(tamLedrCfmYn);
   				info.setUserId(userId);
   				info.setCalTye(calsImsi);
   				
   				info.setCal(cal);
   				//info.setOldCrdIsuceDd(oldCrdIsuceDd);
   				//info.setOldCrdIsucePlceCd(oldCrdIsucePlceCd);
   				
   				info.setFstVefyIndiNm(vo.getFstVefyIndiNm());
   				info.setFstVefyTye(vo.getFstVefyTye());
   				info.setFstVefyRsdtNo(vo.getFstVefyRsdtNo());
   				info.setSecdVefyIndiNm(vo.getSecdVefyIndiNm());
   				info.setSecdVefyTye(vo.getSecdVefyTye());
   				info.setSecdVefyRsdtNo(vo.getSecdVefyRsdtNo());
   				info.setFstVefyOldCrdNo1(vo.getFstVefyOldCrdNo1());
   				info.setFstVefyOldCrdNo2(vo.getFstVefyOldCrdNo2());
   				info.setFstVefyOldCrdNo3(vo.getFstVefyOldCrdNo3());
   				info.setFstVefyOldCrdNo4(vo.getFstVefyOldCrdNo4());
   				info.setSecdVefyOldCrdNo1(vo.getSecdVefyOldCrdNo1());
   				info.setSecdVefyOldCrdNo2(vo.getSecdVefyOldCrdNo2());
   				info.setSecdVefyOldCrdNo3(vo.getSecdVefyOldCrdNo3());
   				info.setSecdVefyOldCrdNo4(vo.getSecdVefyOldCrdNo4());
   				
   				info.setFstVefyFthrNm(vo.getFstVefyFthrNm());
   				info.setSecdVefyFthrNm(vo.getSecdVefyFthrNm());
   				
   				info.setFstVefyOldCrdIsucePlceCd(vo.getFstVefyOldCrdIsucePlceCd());
   				info.setFstVefyOldCrdIsuceDd(vo.getFstVefyOldCrdIsuceDd());
   				info.setSecdVefyCrdIsucePlceCd(vo.getSecdVefyCrdIsucePlceCd());
   				info.setSecdVefyOldCrdIsuceDd(vo.getSecdVefyOldCrdIsuceDd());
   				
   				info.setOldCrdIsuceDd(oldCrdIsuceDdsImsi);
   				info.setOldCrdIsucePlceCd(oldCrdIsucePlceCdsImsi);
   				
   				info.setOthrRl(othrRlsImsi);
   				
   				info.setCalTye2(calsImsi);
   				
   				if(deadYnsImsi != null && "Y".equals(deadYnsImsi)){
   					useYn = "N";
   				}
   				if(frngrYnsImsi != null && "Y".equals(frngrYnsImsi)){
   					useYn = "N";
   				}
   				info.setUseYn(useYn);
   				
   				String ofcalPsnCd = "";
   	    		List<String> lstAthr = NidUserDetailsHelper.getAuthorities();
   	    		if(lstAthr != null && lstAthr.size() == 1){
   	    			ofcalPsnCd = lstAthr.get(0);
   	    		}else if(lstAthr != null && lstAthr.size() > 1){
   	    			for(int j = 0; j < lstAthr.size(); j++){
   	    				String athr = lstAthr.get(j);
   	    				if("1".equals(athr) || "3".equals(athr)){
   	    					ofcalPsnCd = athr;
   	    					if("3".equals(athr)){
   	        					break;
   	        				}
   	    				}
   	    			}
   	    		}
   				//String ofcalPsnCd = user.getOfcalPsnCd();
   				info.setCfmTamLedrId("");
   				info.setMberRgstId("");
   				if(ofcalPsnCd != null && "3".equals(ofcalPsnCd)){
   					info.setCfmTamLedrId(userId);
   					info.setMberRgstId(userId);
   				}else if(ofcalPsnCd != null && "1".equals(ofcalPsnCd)){
   					info.setMberRgstId(userId);
   				}
   				
   				info.setFthrNm(fthrNmsImsi);
   				info.setFthrRsdtSeqNo(fthrRsdtSeqNosImsi);
   				info.setFthrRgstTye(fthrTyesImsi);
   				
   				info.setGfthrNm(gfthrNmsImsi);
   				info.setGfthrRsdtSeqNo(gfthrRsdtSeqNosImsi);
   				info.setGfthrRgstTye(gfthrTyesImsi);
   				
   				info.setSpusNm(hsbdNmsImsi);
   				info.setSpusRsdtSeqNo(hsbdRsdtSeqNosImsi);
   				info.setSpusRgstTye(hsbdTyesImsi);
   				
   				info.setFrngrYn(frngrYnsImsi);
   				
   				String dltYn = "N";
   				info.setInitDthYn(deadYnsImsi);
   				info.setDltYn(dltYn);
   				
   				String rsdtSeqNo = dao.selectRsdtInfrSeq(info);
   				info.setRsdtSeqNo(rsdtSeqNo);
   				info.setFmlyBokSeqNo(fmlyBokSeqNo);

   				String rgstOrgnzCd = user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm();
   				info.setRgstOrgnzCd(rgstOrgnzCd);
   				
   				if(rlCdsImsi != null && rlCdsImsi.length() > 0){
   					if("1".equals(rlCdsImsi)){
   						
   				   		info.setGivNm(givNm);
   						info.setSurnm(surnm);
   						
   						info.setFthrNm(fthrNm);
   		   				info.setFthrRsdtSeqNo(fthrRsdtSeqNo);
   		   				info.setFthrRgstTye(fthrTye);
	   		   			info.setFthrOldCrdNo1(fthrOldCrdNo1);
	   	   				info.setFthrOldCrdNo2(fthrOldCrdNo2);
	   	   				info.setFthrOldCrdNo3(fthrOldCrdNo3);
	   	   				info.setFthrOldCrdNo4(fthrOldCrdNo4);
   	   				
   		   				info.setGfthrNm(gfthrNm);
   		   				info.setGfthrRsdtSeqNo(gfthrRsdtSeqNo);
   		   				info.setGfthrRgstTye(gfthrTye);
	   	   				info.setGfthrOldCrdNo1(gfthrOldCrdNo1);
	   	   				info.setGfthrOldCrdNo2(gfthrOldCrdNo2);
	   	   				info.setGfthrOldCrdNo3(gfthrOldCrdNo3);
	   	   				info.setGfthrOldCrdNo4(gfthrOldCrdNo4);
	   	   				
	   	   				info.setOldCrdNo1(oldCrdNo1);
	   	   				info.setOldCrdNo2(oldCrdNo2);
	   	   				info.setOldCrdNo3(oldCrdNo3);
	   	   				info.setOldCrdNo4(oldCrdNo4);
	   	   				
	   	   				info.setOldCrdIsuceDd(oldCrdIsuceDd);
	   	   				info.setOldCrdIsucePlceCd(oldCrdIsucePlceCd);
	   	   				
	   	   				info.setCalTye2(cal);
   					}
   				}
   				
   				list.add(info);
   				recodeLst.put(recodeNumImsi, rsdtSeqNo);
   				useYn = "Y";
   			}
   			
   			if(list != null && !list.isEmpty() && list.size() > 0){
   				for(int i = 0; i < list.size(); i++){
   					FmlyInfrVO vos = list.get(i);
   					String tagRsdtSeqNo = vos.getFthrRsdtSeqNo();
   					tagRsdtSeqNo = getRecodeMatchRsdtSeqNo(tagRsdtSeqNo, recodeLst);
   					vos.setFthrRsdtSeqNo(tagRsdtSeqNo);
   					if(tagRsdtSeqNo != null && !"".equals(tagRsdtSeqNo)){
   						vos.setFthrNm("");
   						//vos.setFthrRgstTye("");
   						vos.setFthrOldCrdNo("");
   					}
   					
   					tagRsdtSeqNo = vos.getGfthrRsdtSeqNo();
   					tagRsdtSeqNo = getRecodeMatchRsdtSeqNo(tagRsdtSeqNo, recodeLst);
   					vos.setGfthrRsdtSeqNo(tagRsdtSeqNo);
   					if(tagRsdtSeqNo != null && !"".equals(tagRsdtSeqNo)){
   						vos.setGfthrNm("");
   						//vos.setGfthrRgstTye("");
   						vos.setGfthrOldCrdNo("");
   					}
   					
   					tagRsdtSeqNo = vos.getSpusRsdtSeqNo();
   					tagRsdtSeqNo = getRecodeMatchRsdtSeqNo(tagRsdtSeqNo, recodeLst);
   					vos.setSpusRsdtSeqNo(tagRsdtSeqNo);
   					if(tagRsdtSeqNo != null && !"".equals(tagRsdtSeqNo)){
   						vos.setSpusNm("");
   						//vos.setSpusRgstTye("");
   						vos.setSpusOldCrdNo("");
   					}
   					
   					dao.insertRsdtInfr(vos);
   					String crdCd = "1";
   					vos.setCrdCd(crdCd);
   					dao.insertIfBioTb(vos);
   				}
   			}
   		}
   		return fmlyBokNo;
	}
    
	
	/**
	 * Biz-method for retrieving detail of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return FmlyInfrVO Retrieve vo of program
	 * @exception Exception
	 */
	public FmlyInfrVO searchFmlyInfrView(FmlyInfrVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		
		String ofcalPsnCd = "";
		List<String> lstAthr = NidUserDetailsHelper.getAuthorities();
   		if(lstAthr != null && lstAthr.size() == 1){
   			ofcalPsnCd = lstAthr.get(0);
   		}else if(lstAthr != null && lstAthr.size() > 1){
   			for(int j = 0; j < lstAthr.size(); j++){
   				String athr = lstAthr.get(j);
   				if("1".equals(athr) || "3".equals(athr)){
   					ofcalPsnCd = athr;
   					if("3".equals(athr)){
       					break;
       				}
   				}
   			}
   		}
   		if("3".equals(ofcalPsnCd)){
   			vo.setNm(user.getNm());
   		}
		
		return dao.selectFmlyInfrView(vo);
	}
	
	/**
	 * Biz-method for retrieving detail of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<FmlyInfrVO> searchListFmlyInfrView(FmlyInfrVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		return dao.selectListFmlyInfrView(vo);
	}
	
	

	
    /**
	 * Biz-method for registering information of new program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int modifyFmlyInfr(FmlyInfrVO vo) throws Exception {
		
		int cnt = 0;
		String fmlyBokNo = vo.getFmlyBokNo();
        
        String givNm = vo.getGivNm();
	   	String surnm = vo.getSurnm();
	   	
	   	String pmntAdCd = vo.getPmntAdCd();
        String pmntAdDtlCt = vo.getPmntAdDtlCt();
        String curtAdCd = vo.getCurtAdCd();
        String curtAdDtlCt = vo.getCurtAdDtlCt();
        
        String fthrNm = vo.getFthrNm();
        String fthrRsdtSeqNo = vo.getFthrRsdtSeqNo();
        String fthrTye = vo.getFthrRgstTye();
        String fthrOldCrdNo1 = vo.getFthrOldCrdNo1();
        String fthrOldCrdNo2 = vo.getFthrOldCrdNo2();
        String fthrOldCrdNo3 = vo.getFthrOldCrdNo3();
        String fthrOldCrdNo4 = vo.getFthrOldCrdNo4();
        
        String gfthrNm = vo.getGfthrNm();
        String gfthrRsdtSeqNo = vo.getGfthrRsdtSeqNo();
        String gfthrTye = vo.getGfthrRgstTye();
        String gfthrOldCrdNo1 = vo.getGfthrOldCrdNo1();
        String gfthrOldCrdNo2 = vo.getGfthrOldCrdNo2();
        String gfthrOldCrdNo3 = vo.getGfthrOldCrdNo3();
        String gfthrOldCrdNo4 = vo.getGfthrOldCrdNo4();
        
        String oldCrdNo1 = vo.getOldCrdNo1();
        String oldCrdNo2 = vo.getOldCrdNo2();
        String oldCrdNo3 = vo.getOldCrdNo3();
        String oldCrdNo4 = vo.getOldCrdNo4();
        
        String cal = vo.getCal();
        String oldCrdIsucePlceCd = vo.getOldCrdIsucePlceCd();
        String oldCrdIsuceDd = vo.getOldCrdIsuceDd();
	   		
        cnt = dao.updateFmlyInfr(vo);
   	    dao.insertFmlyInfrHst(vo);
   	    
   	    LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();

   	 	String crdIsucePlceCd = user.getOrgnzClsCd()+user.getOrgnzCd();
   	    
   	    //Deleting data
   		String delLst = vo.getDelLst();
   		if(delLst != null && delLst.length() > 0){
   			String ofcalPsnCd = "";
    		List<String> lstAthr = NidUserDetailsHelper.getAuthorities();
    		if(lstAthr != null && lstAthr.size() == 1){
    			ofcalPsnCd = lstAthr.get(0);
    		}else if(lstAthr != null && lstAthr.size() > 1){
    			for(int j = 0; j < lstAthr.size(); j++){
    				String athr = lstAthr.get(j);
    				if("1".equals(athr) || "3".equals(athr)){
    					ofcalPsnCd = athr;
    					if("3".equals(athr)){
        					break;
        				}
    				}
    			}
    		}
   			String delOfcalPsnCd = ofcalPsnCd;
   			StringTokenizer st = new StringTokenizer(delLst, "^");
   			FmlyInfrVO info = new FmlyInfrVO();
   			while(st.hasMoreElements()){
   				String delFmlyMberNo = st.nextToken();
   				info = info.init();
   				info.setFmlyBokNo(fmlyBokNo);
   				info.setFmlyMberNo(delFmlyMberNo);
   				info.setOfficerNo(delOfcalPsnCd);
   				info.setUserId(user.getUserId());
   				dao.updateRsdtInfrDltFlag(info);
   			}
   		}
   	    
   	    String useYn = "Y";
   		String rsdtRgstYn = "N";
		String teamLedrCfmYn = "N";
		String userId = vo.getUserId();
		
		String fmlyHadYn = "N";
		String imsiFmlyMberNo = "";
		
		String curtAdDiv = vo.getCurtAdDiv();
		String curtAdNatCd = vo.getCurtAdNatCd();
		
   		String [] rsdtNos = vo.getRsdtNos();
   		if(rsdtNos != null){
   			String [] recodeNum = vo.getRecodeNum();
   			String [] givNms = vo.getGivNms();
   			String [] surnms = vo.getSurnms();
   			String [] rlCds = vo.getRlCds();
   			String [] bthDds = vo.getBthDds();
   			String [] curtAdCds = vo.getCurtAdCds();
   			String [] curtAdDtlCts = vo.getCurtAdDtlCts();
   			String [] gdrCds = vo.getGdrCds();
   			String [] cals = vo.getCals();
   			String [] frngrYns = vo.getFrngrYns();
   			String [] deadYns = vo.getDeadYns();
   			String [] fthrRsdtSeqNos = vo.getFthrRsdtSeqNos();
   			String [] fthrTyes = vo.getFthrTyes();
   			String [] fthrNms = vo.getFthrNms();
   			String [] gfthrRsdtSeqNos = vo.getGfthrRsdtSeqNos();
   			String [] gfthrTyes = vo.getGfthrTyes();
   			String [] gfthrNms = vo.getGfthrNms();
   			String [] hsbdRsdtSeqNos = vo.getHsbdRsdtSeqNos();
   			String [] hsbdTyes = vo.getHsbdTyes();
   			String [] hsbdNms = vo.getHsbdNms();
   			 
   			String [] oldCrdNos1 = vo.getOldCrdNos1();
   			String [] oldCrdNos2 = vo.getOldCrdNos2();
   			String [] oldCrdNos3 = vo.getOldCrdNos3();
   			String [] oldCrdNos4 = vo.getOldCrdNos4();
   			String [] fthrOldCrdNos1 = vo.getFthrOldCrdNos1();
   			String [] fthrOldCrdNos2 = vo.getFthrOldCrdNos2();
   			String [] fthrOldCrdNos3 = vo.getFthrOldCrdNos3();
   			String [] fthrOldCrdNos4 = vo.getFthrOldCrdNos4();
   			String [] gfthrOldCrdNos1 = vo.getGfthrOldCrdNos1();
   			String [] gfthrOldCrdNos2 = vo.getGfthrOldCrdNos2();
   			String [] gfthrOldCrdNos3 = vo.getGfthrOldCrdNos3();
   			String [] gfthrOldCrdNos4 = vo.getGfthrOldCrdNos4();
   			String [] spusOldCrdNos1 = vo.getSpusOldCrdNos1();
   			String [] spusOldCrdNos2 = vo.getSpusOldCrdNos2();
   			String [] spusOldCrdNos3 = vo.getSpusOldCrdNos3();
   			String [] spusOldCrdNos4 = vo.getSpusOldCrdNos4();
   			String [] vrfrYns = vo.getVrfrYns();
   			String [] rsdtSeqNos = vo.getRsdtSeqNos();
   			String [] fmlyMberNos = vo.getFmlyMberNos();
   			String [] tamLedrCfmYns = vo.getTamLedrCfmYns();
   			String [] rsdtRgstYns = vo.getRsdtRgstYns();
   			
   			String [] curtAdDivs = vo.getCurtAdDivs();
		   	String [] curtAdNatCds = vo.getCurtAdNatCds();
		   	
		   	String [] oldCrdIsuceDds = vo.getOldCrdIsuceDds();
		   	String [] oldCrdIsucePlceCds = vo.getOldCrdIsucePlceCds();
		   	
		   	String [] othrRls = vo.getOthrRls();
   	   		
   	   		FmlyInfrVO info = new FmlyInfrVO();
   	   		// Other family family of head
   	   		EgovMap recodeLst = new EgovMap();
			ArrayList<FmlyInfrVO> list = new ArrayList<FmlyInfrVO>();
   			for(int i = 0 ; i < rsdtNos.length; i++){
   				String recodeNumImsi = recodeNum[i].trim();
   				String rsdtNosImsi = rsdtNos[i].trim();
   				String givNmsImsi = givNms[i].trim();
   				String surnmsImsi = surnms[i].trim();
   				String rlCdsImsi = rlCds[i].trim();
   				String bthDdsImsi = bthDds[i].trim();
   				String curtAdCdsImsi = curtAdCds[i].trim();
   				String curtAdDtlCtsImsi = curtAdDtlCts[i].trim();
   				String gdrCdsImsi = gdrCds[i].trim();
   				
   				String calsImsi = cals[i].trim();
   				String frngrYnsImsi = frngrYns[i].trim();
   				String deadYnsImsi = deadYns[i].trim();
   				String fthrRsdtSeqNosImsi = fthrRsdtSeqNos[i].trim();
   				String fthrTyesImsi = fthrTyes[i].trim();
   				String fthrNmsImsi = fthrNms[i].trim();
   				String gfthrRsdtSeqNosImsi = gfthrRsdtSeqNos[i].trim();
   				String gfthrTyesImsi = gfthrTyes[i].trim();
   				String gfthrNmsImsi = gfthrNms[i].trim();
   				String hsbdRsdtSeqNosImsi = hsbdRsdtSeqNos[i].trim();
   				String hsbdTyesImsi = hsbdTyes[i].trim();
   				String hsbdNmsImsi = hsbdNms[i].trim();
   				
   				String oldCrdNosImsi1 = oldCrdNos1[i].trim();
   				String oldCrdNosImsi2 = oldCrdNos2[i].trim();
   				String oldCrdNosImsi3 = oldCrdNos3[i].trim();
   				String oldCrdNosImsi4 = oldCrdNos4[i].trim();
   				
   				String fthrOldCrdNosImsi1 = fthrOldCrdNos1[i].trim();
   				String fthrOldCrdNosImsi2 = fthrOldCrdNos2[i].trim();
   				String fthrOldCrdNosImsi3 = fthrOldCrdNos3[i].trim();
   				String fthrOldCrdNosImsi4 = fthrOldCrdNos4[i].trim();
   				
   				String gfthrOldCrdNosImsi1 = gfthrOldCrdNos1[i].trim();
   				String gfthrOldCrdNosImsi2 = gfthrOldCrdNos2[i].trim();
   				String gfthrOldCrdNosImsi3 = gfthrOldCrdNos3[i].trim();
   				String gfthrOldCrdNosImsi4 = gfthrOldCrdNos4[i].trim();
   				
   				String spusOldCrdNosImsi1 = spusOldCrdNos1[i].trim();
   				String spusOldCrdNosImsi2 = spusOldCrdNos2[i].trim();
   				String spusOldCrdNosImsi3 = spusOldCrdNos3[i].trim();
   				String spusOldCrdNosImsi4 = spusOldCrdNos4[i].trim();
   				
   				String vrfrYn = vrfrYns[i].trim();
   				
   				String curtAdDivsImsi = curtAdDivs[i].trim();
   				String curtAdNatCdsImsi = curtAdNatCds[i].trim();
   				
   				String rsdtSeqNo = rsdtSeqNos[i].trim();
   				String fmlyMberNosa = fmlyMberNos[i].trim();
   				String tamLedrCfmYnsa = tamLedrCfmYns[i].trim();
   				String rsdtRgstYnsa = rsdtRgstYns[i].trim();
   				
   				String oldCrdIsuceDdsImsi = oldCrdIsuceDds[i].trim();
   				String oldCrdIsucePlceCdsImsi = oldCrdIsucePlceCds[i].trim();
   				
   				String othrRlsImsi = othrRls[i].trim();
   				
   				info = info.init();
   				info.setFmlyBokNo(fmlyBokNo);
   				info.setRsdtNo(rsdtNosImsi);
   				info.setGivNm(givNmsImsi);
   				info.setSurnm(surnmsImsi);
   				
   				info.setFthrNm(fthrNmsImsi);
   				info.setGfthrNm(gfthrNmsImsi);
   				
   				info.setBthDd(bthDdsImsi);
   				info.setGdrCd(gdrCdsImsi);
   				info.setRlCd(rlCdsImsi);
   				info.setOldCrdNo1(oldCrdNosImsi1);
   				info.setOldCrdNo2(oldCrdNosImsi2);
   				info.setOldCrdNo3(oldCrdNosImsi3);
   				info.setOldCrdNo4(oldCrdNosImsi4);
   				
   				info.setFthrOldCrdNo1(fthrOldCrdNosImsi1);
   				info.setFthrOldCrdNo2(fthrOldCrdNosImsi2);
   				info.setFthrOldCrdNo3(fthrOldCrdNosImsi3);
   				info.setFthrOldCrdNo4(fthrOldCrdNosImsi4);
   				
   				info.setGfthrOldCrdNo1(gfthrOldCrdNosImsi1);
   				info.setGfthrOldCrdNo2(gfthrOldCrdNosImsi2);
   				info.setGfthrOldCrdNo3(gfthrOldCrdNosImsi3);
   				info.setGfthrOldCrdNo4(gfthrOldCrdNosImsi4);
   				
   				info.setSpusOldCrdNo1(spusOldCrdNosImsi1);
   				info.setSpusOldCrdNo2(spusOldCrdNosImsi2);
   				info.setSpusOldCrdNo3(spusOldCrdNosImsi3);
   				info.setSpusOldCrdNo4(spusOldCrdNosImsi4);
   				
   				info.setVrfrYn(vrfrYn);
   				
   				if((curtAdCdsImsi != null && curtAdCdsImsi.length() > 0 ) || (curtAdNatCdsImsi != null && curtAdNatCdsImsi.length() > 0 )){
   					info.setCurtAdCd(curtAdCdsImsi);
   					info.setCurtAdDtlCt(curtAdDtlCtsImsi);
   					info.setCurtAdDiv(curtAdDivsImsi);
   					info.setCurtAdNatCd(curtAdNatCdsImsi);
   				}else{
   					info.setCurtAdCd(curtAdCd);
   					info.setCurtAdDtlCt(curtAdDtlCt);
   					info.setCurtAdDiv(curtAdDiv);
   					info.setCurtAdNatCd(curtAdNatCd);
   				}
   				
   				if(rlCdsImsi != null && rlCdsImsi.length() > 0){
   					if("1".equals(rlCdsImsi)){
   						fmlyHadYn = "Y";
   						info.setPmntAdCd(pmntAdCd);
   						info.setPmntAdDtlCt(pmntAdDtlCt);
   						info.setCurtAdCd(curtAdCd);
	   					info.setCurtAdDtlCt(curtAdDtlCt);
	   					info.setCurtAdDiv(curtAdDiv);
	   					info.setCurtAdNatCd(curtAdNatCd);
   					}else{
   						fmlyHadYn = "N";
   					}
   				}else{
   					fmlyHadYn = "N";
   				}
   				info.setFmlyHadYn(fmlyHadYn);
   				info.setCrdIsucePlceCd(crdIsucePlceCd);
   				
   				info.setUserId(userId);
   				info.setCalTye(calsImsi);
   				
   				info.setCal(cal);
   				//info.setOldCrdIsuceDd(oldCrdIsuceDd);
   				//info.setOldCrdIsucePlceCd(oldCrdIsucePlceCd);
   				
   				info.setFstVefyIndiNm(vo.getFstVefyIndiNm());
   				info.setFstVefyTye(vo.getFstVefyTye());
   				info.setFstVefyRsdtNo(vo.getFstVefyRsdtNo());
   				info.setSecdVefyIndiNm(vo.getSecdVefyIndiNm());
   				info.setSecdVefyTye(vo.getSecdVefyTye());
   				info.setSecdVefyRsdtNo(vo.getSecdVefyRsdtNo());
   				info.setFstVefyOldCrdNo1(vo.getFstVefyOldCrdNo1());
   				info.setFstVefyOldCrdNo2(vo.getFstVefyOldCrdNo2());
   				info.setFstVefyOldCrdNo3(vo.getFstVefyOldCrdNo3());
   				info.setFstVefyOldCrdNo4(vo.getFstVefyOldCrdNo4());
   				info.setSecdVefyOldCrdNo1(vo.getSecdVefyOldCrdNo1());
   				info.setSecdVefyOldCrdNo2(vo.getSecdVefyOldCrdNo2());
   				info.setSecdVefyOldCrdNo3(vo.getSecdVefyOldCrdNo3());
   				info.setSecdVefyOldCrdNo4(vo.getSecdVefyOldCrdNo4());
   				
   				info.setFstVefyFthrNm(vo.getFstVefyFthrNm());
   				info.setSecdVefyFthrNm(vo.getSecdVefyFthrNm());
   				
   				info.setFstVefyOldCrdIsucePlceCd(vo.getFstVefyOldCrdIsucePlceCd());
   				info.setFstVefyOldCrdIsuceDd(vo.getFstVefyOldCrdIsuceDd());
   				info.setSecdVefyCrdIsucePlceCd(vo.getSecdVefyCrdIsucePlceCd());
   				info.setSecdVefyOldCrdIsuceDd(vo.getSecdVefyOldCrdIsuceDd());
   				
   				info.setOldCrdIsuceDd(oldCrdIsuceDdsImsi);
   				info.setOldCrdIsucePlceCd(oldCrdIsucePlceCdsImsi);
   				
   				info.setOthrRl(othrRlsImsi);
   				
   				info.setCalTye2(calsImsi);
   				
   				if(deadYnsImsi != null && "Y".equals(deadYnsImsi)){
   					useYn = "N";
   				}
   				if(frngrYnsImsi != null && "Y".equals(frngrYnsImsi)){
   					useYn = "N";
   				}
   				info.setUseYn(useYn);
   				
   				info.setInitDthYn(deadYnsImsi);
   				
   				String ofcalPsnCd = "";
   	    		List<String> lstAthr = NidUserDetailsHelper.getAuthorities();
   	    		if(lstAthr != null && lstAthr.size() == 1){
   	    			ofcalPsnCd = lstAthr.get(0);
   	    		}else if(lstAthr != null && lstAthr.size() > 1){
   	    			for(int j = 0; j < lstAthr.size(); j++){
   	    				String athr = lstAthr.get(j);
   	    				if("1".equals(athr) || "3".equals(athr)){
   	    					ofcalPsnCd = athr;
   	    					if("3".equals(athr)){
   	        					break;
   	        				}
   	    				}
   	    			}
   	    		}
   				//String ofcalPsnCd = user.getOfcalPsnCd();
   				info.setOfficerNo(ofcalPsnCd);
   				
   				info.setFthrNm(fthrNmsImsi);
   				info.setFthrRsdtSeqNo(fthrRsdtSeqNosImsi);
   				info.setFthrRgstTye(fthrTyesImsi);
   				
   				info.setGfthrNm(gfthrNmsImsi);
   				info.setGfthrRsdtSeqNo(gfthrRsdtSeqNosImsi);
   				info.setGfthrRgstTye(gfthrTyesImsi);
   				
   				info.setSpusNm(hsbdNmsImsi);
   				info.setSpusRsdtSeqNo(hsbdRsdtSeqNosImsi);
   				info.setSpusRgstTye(hsbdTyesImsi);
   				
   				info.setFrngrYn(frngrYnsImsi);
   				
   				info.setFmlyMberNo(fmlyMberNosa);
   				
   				
   				
   				if(fmlyMberNosa != null && fmlyMberNosa.length() > 0){
   					
   					info.setRsdtRgstYn(rsdtRgstYnsa);
   					info.setRsdtSeqNo(rsdtSeqNo);
   					info.setTamLedrCfmYn(tamLedrCfmYnsa);
   					//if(tamLedrCfmYnsa != null && !"Y".equals(tamLedrCfmYnsa)){
   					//	dao.updateRsdtInfr(info);
   					//}
   				}else{
   					
   					info.setRsdtRgstYn(rsdtRgstYn);
   					//info.setPmntAdCd(pmntAdCd);
   	   				//info.setPmntAdDtlCt(pmntAdDtlCt);
   	   				
   					//Registration of new material
   					info.setTamLedrCfmYn(teamLedrCfmYn);
   					imsiFmlyMberNo = dao.selectRsdtInfrSeq(info);
   	   				info.setRsdtSeqNo(imsiFmlyMberNo);
   	   				info.setFmlyBokSeqNo(vo.getFmlyBokSeqNo());
	   	   			String rgstOrgnzCd = user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm();
	   				info.setRgstOrgnzCd(rgstOrgnzCd);
	   				rsdtSeqNo = imsiFmlyMberNo;
	   				String dltYn = "N";
	   				info.setDltYn(dltYn);
	   				
	   				info.setCfmTamLedrId("");
	   				info.setMberRgstId("");
	   				if(ofcalPsnCd != null && "3".equals(ofcalPsnCd)){
	   					info.setCfmTamLedrId(userId);
	   				}else if(ofcalPsnCd != null && "1".equals(ofcalPsnCd)){
	   					info.setMberRgstId(userId);
	   				}
   				}
   				if(rlCdsImsi != null && rlCdsImsi.length() > 0){
   					if("1".equals(rlCdsImsi)){
   						info.setGivNm(givNm);
   						info.setSurnm(surnm);
   						
   						info.setFthrNm(fthrNm);
   		   				info.setFthrRsdtSeqNo(fthrRsdtSeqNo);
   		   				info.setFthrRgstTye(fthrTye);
	   		   			info.setFthrOldCrdNo1(fthrOldCrdNo1);
	   	   				info.setFthrOldCrdNo2(fthrOldCrdNo2);
	   	   				info.setFthrOldCrdNo3(fthrOldCrdNo3);
	   	   				info.setFthrOldCrdNo4(fthrOldCrdNo4);
   	   				
   		   				info.setGfthrNm(gfthrNm);
   		   				info.setGfthrRsdtSeqNo(gfthrRsdtSeqNo);
   		   				info.setGfthrRgstTye(gfthrTye);
	   	   				info.setGfthrOldCrdNo1(gfthrOldCrdNo1);
	   	   				info.setGfthrOldCrdNo2(gfthrOldCrdNo2);
	   	   				info.setGfthrOldCrdNo3(gfthrOldCrdNo3);
	   	   				info.setGfthrOldCrdNo4(gfthrOldCrdNo4);
	   	   				
	   	   				info.setOldCrdNo1(oldCrdNo1);
	   	   				info.setOldCrdNo2(oldCrdNo2);
	   	   				info.setOldCrdNo3(oldCrdNo3);
	   	   				info.setOldCrdNo4(oldCrdNo4);
	   	   				
	   	   				info.setOldCrdIsuceDd(oldCrdIsuceDd);
	   	   				info.setOldCrdIsucePlceCd(oldCrdIsucePlceCd);
	   	   				
	   	   				info.setCalTye2(cal);
   					}
   				}
   				list.add(info);
   				recodeLst.put(recodeNumImsi, rsdtSeqNo);
   				useYn = "Y";
   			}
   			
   			if(list != null && !list.isEmpty() && list.size() > 0){
   				for(int i = 0; i < list.size(); i++){
   					FmlyInfrVO vos = list.get(i);
   					String tagRsdtSeqNo = vos.getFthrRsdtSeqNo();
   					tagRsdtSeqNo = getRecodeMatchRsdtSeqNo(tagRsdtSeqNo, recodeLst);
   					vos.setFthrRsdtSeqNo(tagRsdtSeqNo);
   					if(tagRsdtSeqNo != null && !"".equals(tagRsdtSeqNo)){
   						vos.setFthrNm("");
   						//vos.setFthrRgstTye("");
   						vos.setFthrOldCrdNo("");
   					}
   					tagRsdtSeqNo = vos.getGfthrRsdtSeqNo();
   					tagRsdtSeqNo = getRecodeMatchRsdtSeqNo(tagRsdtSeqNo, recodeLst);
   					vos.setGfthrRsdtSeqNo(tagRsdtSeqNo);
   					if(tagRsdtSeqNo != null && !"".equals(tagRsdtSeqNo)){
   						vos.setGfthrNm("");
   						//vos.setGfthrRgstTye("");
   						vos.setGfthrOldCrdNo("");
   					}
   					tagRsdtSeqNo = vos.getSpusRsdtSeqNo();
   					tagRsdtSeqNo = getRecodeMatchRsdtSeqNo(tagRsdtSeqNo, recodeLst);
   					vos.setSpusRsdtSeqNo(tagRsdtSeqNo);
   					if(tagRsdtSeqNo != null && !"".equals(tagRsdtSeqNo)){
   						vos.setSpusNm("");
   						//vos.setSpusRgstTye("");
   						vos.setSpusOldCrdNo("");
   					}
   					
   					//age check
   					if(!"".equals(vos.getFmlyMberNo()) && !"Y".equals(vos.getTamLedrCfmYn())){
	   					RsdtInfrVO voo = new RsdtInfrVO();
	   					//voo.setCalTye(vos.getCalTye());
	   					//voo.setCalTye(vos.getBthDd());
	   					voo.setCalTye(vos.getRsdtSeqNo());
	   					EgovMap em = rsdtDao.selectRsdtInfrDat(vos.getRsdtSeqNo());
	   					if(em != null && !em.isEmpty()){
	   						String oldBthdd = NidStringUtil.nullConvert(em.get("bthDd"));
	   						String bioKey = NidStringUtil.nullConvert(em.get("bioKey"));
	   						if(oldBthdd != null && oldBthdd.length() > 7){
	   							StringBuffer sb = new StringBuffer();
	   							sb.append(oldBthdd.substring(6, 8));
	   							sb.append(oldBthdd.substring(4, 6));
	   							sb.append(oldBthdd.substring(0, 4));
	   							voo.setCalTye("g");
	   							voo.setBthDd(sb.toString());
	   							String resultData = rsdtDao.selectRsdtBthCheck(voo);
	   							if(resultData != null && resultData.length() > 0){
	   	   							int age = Integer.parseInt(resultData);
	   	   							if(age > 17){
	   	   								voo.setCalTye(vos.getCalTye());
	   	   								voo.setBthDd(vos.getBthDd());
	   	   								String updateData = rsdtDao.selectRsdtBthCheck(voo);
	   	   								if(updateData != null && updateData.length() > 0){
	   	   									int oldAge = Integer.parseInt(updateData);
	   	   									if(oldAge < 18){
	   	   										EgovMap bioMap = rsdtDao.selectImBioCaptTbInfr(bioKey);
	   	   										if(bioMap != null && bioMap.get("bioFle") != null){
	   	   											ABSSocket abs = new ABSSocket();
		   	   										boolean resultFlag = abs.Age18UnderChange(bioKey);
		   	   										String erorYn = "N";
		   	   										if(!resultFlag){
		   	   											erorYn = "N";
			   	   									}
		   	   										try{
		   	   											lgDao.insertBioIfLg(userId, "1", erorYn, "Age18UnderChange", bioKey);
			   	   									}catch(Exception e){
		   	   											log.error(e);
		   	   										}
		   	   										log.debug("abs.Age18UnderChange : " + resultFlag);
		   	   										if(!resultFlag){
		   	   											throw processException("fail");
		   	   										}
	   	   										}
	   	   									}
	   	   								}
	   	   							}else{
	   	   								//
		   	   							voo.setCalTye(vos.getCalTye());
	   	   								voo.setBthDd(vos.getBthDd());
	   	   								String updateData = rsdtDao.selectRsdtBthCheck(voo);
	   	   								if(updateData != null && updateData.length() > 0){
	   	   									int oldAge = Integer.parseInt(updateData);
	   	   									if(oldAge > 17){
	   	   										EgovMap bioMap = rsdtDao.selectImBioCaptTbInfr(bioKey);
	   	   										if(bioMap != null && bioMap.get("bioFle") != null){
	   	   											ABSSocket abs = new ABSSocket();
		   	   										boolean resultFlag = abs.Age18OverChange(bioKey);
		   	   										String erorYn = "N";
		   	   										if(!resultFlag){
		   	   											erorYn = "N";
			   	   									}
		   	   										try{
		   	   											lgDao.insertBioIfLg(userId, "1", erorYn, "Age18OverChange", bioKey);
			   	   									}catch(Exception e){
		   	   											log.error(e);
		   	   										}
		   	   										log.debug("abs.Age18OverChange : " + resultFlag);
		   	   										if(!resultFlag){
		   	   											throw processException("fail");
		   	   										}
	   	   										}
	   	   									}
	   	   								}
	   	   							}
	   	   	   					}
	   						}
	   					}
   					}
   					
   					
   					if(!"".equals(vos.getFmlyMberNo()) && !"Y".equals(vos.getTamLedrCfmYn())){
   						dao.updateRsdtInfr(vos);
   					}else if("".equals(vos.getFmlyMberNo()) ){
   						if(vos != null && "1".equals(vos.getRlCd())){
   							dao.updateRsdtInfrHeadDup(vos);
   						}
   						dao.insertRsdtInfr(vos);
   	   					String crdCd = "1";
   	   					vos.setCrdCd(crdCd);
   	   					dao.insertIfBioTb(vos);
   					}
   					
   				}
   			}
   			
   		}
   		return cnt;
	}
	
	
	/**
	 * Biz-method for retrieving detail of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return String Retrieve string of program
	 * @exception Exception
	 */
	public String searchFmlyNo(FmlyInfrVO vo) throws Exception{
		return dao.selectFmlyNo(vo);
	}
	
	
	/**
	 * Biz-method for retrieving detail of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return String Retrieve string of program
	 * @exception Exception
	 */
	public EgovMap searchRsdtNm(FmlyInfrVO vo) throws Exception{
		return dao.selectRsdtNm(vo);
	}
	
	/**
	 * Biz-method for retrieving detail of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return String Retrieve string of program
	 * @exception Exception
	 */
	public EgovMap searchFmlyRsdtInfr(FmlyInfrVO vo) throws Exception{
		return dao.selectFmlyRsdtInfr(vo);
	}
	
	/**
	 * Biz-method for retrieving detail of program. <br>
	 * 
	 * @param String, EgovMap
	 * @return String
	 * @exception Exception
	 */
	private String getRecodeMatchRsdtSeqNo(String recodeNm, EgovMap em) throws Exception{
		String result = recodeNm;
		if(recodeNm != null && !"".equals(recodeNm) && recodeNm.indexOf("recodeNum") != -1){
			if(recodeNm != null && em != null){
				if(recodeNm.length() > 0 && !em.isEmpty()){
					Object obj = em.get(recodeNm);
					String sobj = null;
					if(obj != null && obj instanceof String){
						sobj = (String)obj;
						if(sobj != null && sobj.length() > 0){
							result = sobj;
						}
					}
				}
			}
		}
		return result;
	}
    
	
	
	
	/**
	 * Biz-method for retrieving detail of program. <br>
	 * 
	 * @param FmlyInfrVO
	 * @return EgovMap
	 * @exception Exception
	 */
	public EgovMap searchRsdtInfr(FmlyInfrVO vo) throws Exception{
		return dao.selectRsdtInfr(vo);
	}
	
	
	/**
	 * Biz-method for retrieving detail of program. <br>
	 * 
	 * @param EgovMap
	 * @return String Retrieve string of program
	 * @exception Exception
	 */
	public String searchVefyRgstDdYn(EgovMap vo) throws Exception{
		return dao.selectVefyRgstDdYn(vo);
	}
	
	
	/**
	 * Biz-method for self and the birth date of check <br>
	 * 
	 * @param EgovMap
	 * @return String Retrieve string of program
	 * @exception Exception
	 */
	public String searchChkSelfDd(EgovMap vo) throws Exception{
		return dao.searchChkSelfDd(vo);
	}
	
	
	
	
	/**
	 * Biz-method for retrieving detail of program. <br>
	 * 
	 * @param String
	 * @return List
	 * @exception Exception
	 */
	public List<EgovMap> searchRmRlTb(String vo) throws Exception{
		return dao.selectRmRlTb(vo);
	}
	
	
	
	
	
	/**
	 * Biz-method for self and the birth date of check <br>
	 * 
	 * @param EgovMap
	 * @return String Retrieve string of program
	 * @exception Exception
	 */
	public String searchChkBthDdLimit(EgovMap vo) throws Exception{
		return dao.selectChkBthDdLimit(vo);
	}
	
	
	
	/**
	 * Biz-method for self and the birth date of check <br>
	 * 
	 * @param EgovMap
	 * @return String Retrieve string of program
	 * @exception Exception
	 */
	public String searchRsdtInfrBthDd(EgovMap vo) throws Exception{
		return dao.selectRsdtInfrBthDd(vo);
	}
	
	
	/**
	 * Biz-method for Check whether a person resident information and other residents see <br>
	 * 
	 * @param EgovMap
	 * @return String Retrieve string of program
	 * @exception Exception
	 */
	public List<EgovMap> searchRsdtInfrSeqInChk(EgovMap vo) throws Exception{
		return dao.selectRsdtInfrSeqInChk(vo);
	}
	
	
	
	
	
	/**
	 * Biz-method for retrieving detail of program. <br>
	 * 
	 * @param EgovMap
	 * @return EgovMap
	 * @exception Exception
	 */
	public EgovMap searchFmlyRgstRsdtInfr(EgovMap vo) throws Exception{
		return dao.selectFmlyRgstRsdtInfr(vo);
	}
	
	
	
	/**
	 * Biz-method for retrieving detail of program. <br>
	 * 
	 * @param EgovMap
	 * @return int
	 * @exception Exception
	 */
	public List<EgovMap> searchRsdtInfrMothRlCn(EgovMap vo) throws Exception{
		return dao.selectRsdtInfrMothRlCn(vo);
	}
	
	
	
	/**
	 * Biz-method for retrieving detail of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(FmlyInfrVO).
	 * @return FmlyInfrVO Retrieve vo of program
	 * @exception Exception
	 */
	public FmlyInfrVO searchFmlyInfrHeadDupView(FmlyInfrVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		return dao.selectFmlyInfrHeadDupView(vo);
	}
	
	
}