
package afnid.rm.fmly.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;


import afnid.rm.fmly.service.FmlyRlRuleVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;



/** 
 * This class is Database Access Object of common
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.05.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.05.21  		BH Choi         		Create
 *
 * </pre>
 */

@Repository("fmlyRlRuleDAO")
public class FmlyRlRuleDAO extends EgovAbstractDAO {
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }

	
	/**
	 * DAO-method for retrieving list of Family Relationship Rule. <br>
	 * 
	 * @param FmlyRlVO
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<FmlyRlRuleVO> selectListFmlyRlRule(FmlyRlRuleVO vo) throws Exception{
		return list("fmlyRlRuleDAO.selectListFmlyRlRule", vo);
	}
	
	/**
	 * DAO-method for retrieving total count of Family Relationship Rule list. <br>
	 * 
	 * @param FmlyRlRuleVO
	 * @return int
	 * @exception Exception
	 */
	public int selectListFmlyRlRuleTotCnt(FmlyRlRuleVO vo) throws Exception{;
		return (Integer)selectByPk("fmlyRlRuleDAO.selectListFmlyRlRuleTotCnt", vo);
	}
   
	/**
	 * DAO-method for retrieving Family Relationship Rule. <br>
	 * 
	 * @param FmlyRlRuleVO
	 * @return FmlyRlRuleVO
	 * @exception Exception
	 */
	public FmlyRlRuleVO selectFmlyRlRule(FmlyRlRuleVO vo) throws Exception{
		return (FmlyRlRuleVO)selectByPk("fmlyRlRuleDAO.selectFmlyRlRule", vo);
	}
	
	/**
	 * DAO-method for update information of Family Relationship Rule. <br>
	 * 
	 * @param vo Input item for update Family Relationship Rule(FmlyRlRuleVO).
	 * @exception Exception
	 */
	public int updateFmlyRlRule(FmlyRlRuleVO vo){
		return (Integer)update("fmlyRlRuleDAO.updateFmlyRlRule", vo);
	}
	
	/**
	 * DAO-method for insert Family Relationship Rule. <br>
	 * 
	 * @param FmlyRlRuleVO
	 * @return void
	 * @exception Exception
	 */
	public void insertFmlyRlRule(FmlyRlRuleVO vo) throws Exception{
		insert("fmlyRlRuleDAO.insertFmlyRlRule", vo);
	}
	
	/**
	 * DAO-method. <br>
	 * 
	 * @param vo.
	 * @exception Exception
	 */
	public String searchSameKeyYn(FmlyRlRuleVO vo){
		return (String)selectByPk("fmlyRlRuleDAO.searchSameKeyYn", vo);
	}
	
	/**
	 * DAO-method. <br>
	 * 
	 * @param vo.
	 * @exception Exception
	 */
	public int searchSameKeySelfGdrCdCnt(FmlyRlRuleVO vo){
		return (Integer)selectByPk("fmlyRlRuleDAO.searchSameKeySelfGdrCdCnt", vo);
	}	
	
	/**
	 * DAO-method. <br>
	 * 
	 * @param vo.
	 * @exception Exception
	 */
	public FmlyRlRuleVO selectSelfGdrCd(FmlyRlRuleVO vo){
		return (FmlyRlRuleVO)selectByPk("fmlyRlRuleDAO.selectSelfGdrCd", vo);
	}	
	
	/**
	 * DAO-method for update information of Family Relationship Rule. <br>
	 * 
	 * @param vo Input item for update Family Relationship Rule(FmlyRlRuleVO).
	 * @exception Exception
	 */
	public int updateSelfGdrCd(FmlyRlRuleVO vo){
		return (Integer)update("fmlyRlRuleDAO.updateSelfGdrCd", vo);
	}
	
	/**
	 * DAO-method. <br>
	 * 
	 * @param vo.
	 * @exception Exception
	 */
	public String selectDelDat(FmlyRlRuleVO vo){
		return (String)selectByPk("fmlyRlRuleDAO.selectDelDat", vo);
	}	
	
	/**
	 * DAO-method. <br>
	 * 
	 * @param vo.
	 * @exception Exception
	 */
	public void deleteFmlyRlRule(String rlSeqNo){
		delete("fmlyRlRuleDAO.deleteFmlyRlRule", rlSeqNo);
	}	
}
