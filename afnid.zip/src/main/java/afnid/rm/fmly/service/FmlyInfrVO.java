/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package afnid.rm.fmly.service;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of board information
 * 
 * @author Afghanistan National ID Card System Application Team 
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers         	Revisions
 *   2013.01.04  		BH Choi         		Create
 *
 * </pre>
 */

public class FmlyInfrVO extends ComDefaultVO {
	
    private static final long serialVersionUID = 1L;
    private String othrRl;
    private String fstVefyOldCrdIsuceDdJ;
    private String fstVefyOldCrdIsuceDdG;
    private String secdVefyOldCrdIsuceDdJ;
    private String secdVefyOldCrdIsuceDdG;
    
    private String oldCrdIsuceDdJ;
    private String oldCrdIsuceDdG;
    private String calTye2;
    private String fstVefyOldCrdIsucePlceCdNm;
    private String secdVefyCrdIsucePlceCdNm;
    private	String fstVefyOldCrdIsucePlceCd;
    private	String fstVefyOldCrdIsuceDd;
    private	String secdVefyCrdIsucePlceCd;
    private	String secdVefyOldCrdIsuceDd;
    
    private String [] othrRls;
    private	String [] oldCrdIsuceDds;
    private	String [] oldCrdIsucePlceCds;
    private	String [] oldCrdIsucePlceCdNms;
    
    private	String curtAdNatCdNm;
    private	String curtAdDtlCtD;
    private	String curtAdDtlCtF;
    
    private	String [] curtAdDivs;
    private	String [] curtAdNatCds;
    
    private	String curtAdDiv;
    private	String curtAdNatCd;
    
    private	String crdExpiryDdG;
    private 	String crdExpiryDd;
    private	String crdIsuceDdG;
    private	String cfmTamLedrIdNm;
    private	String mberRgstIdNm;
    private	String oldCrdIsucePlceCd;
    private	String oldCrdIsucePlceCdNm;
    private	String gfthrOldCrdNo4;
    private	String fthrOldCrdNo4;
    private	String spusOldCrdNo4;
    private	String oldCrdNo4;
    private	String cal;
    private	String oldCrdIsuceDd;

    private	String fomFillHeprOldCrdNo1;
    private	String fomFillHeprOldCrdNo2;
    private	String fomFillHeprOldCrdNo3;
    private	String fomFillHeprOldCrdNo4;

    private	String fstVefyFthrNm;
    private	String fstVefyOldCrdNo1;
    private	String fstVefyOldCrdNo2;
    private	String fstVefyOldCrdNo3;
    private	String fstVefyOldCrdNo4;

    private	String secdVefyFthrNm;
    private	String secdVefyOldCrdNo1;
    private	String secdVefyOldCrdNo2;
    private	String secdVefyOldCrdNo3;
    private	String secdVefyOldCrdNo4;
    //add 2014.04.28 start
    private	String bthDdJ;
    private	String bthDdG;
    private 	String spusRsdtNo;
    private 	String mthrRsdtNo;
    private 	String gfthrRsdtNo;
    private 	String fthrRsdtNo;
    private	String fmlyBokRgstDdG;
    private	String cfmTamLedrId;
    private	String oldCrdNo1;
    private	String oldCrdNo2;
    private	String oldCrdNo3;
    private	String mthrOldCrdNo1;
    private	String mthrOldCrdNo2;
    private	String mthrOldCrdNo3;
    private	String spusOldCrdNo1;
    private	String spusOldCrdNo2;
    private	String spusOldCrdNo3;
    private	String fthrTye;
    private	String gfthrTye;
    private	String vrfrYn;
    private	String fthrOldCrdNo1;
    private	String fthrOldCrdNo2;
    private	String fthrOldCrdNo3;
    private	String gfthrOldCrdNo1;
    private	String gfthrOldCrdNo2;
    private	String gfthrOldCrdNo3;
    private	String fomFillHeprNo1;
    private	String fomFillHeprNo2;
    private	String fomFillHeprNo3;
    private	String initDthYn;
    private	String dltYn;
    private	String [] recodeNum;
    private	String [] frngrYns;
    private	String [] deadYns;
    private	String [] fthrRsdtSeqNos;
    private	String [] fthrTyes;
    private	String [] fthrRsdtNos;
    private	String [] fthrNms;
    private	String [] gfthrRsdtSeqNos;
    private	String [] gfthrTyes;
    private	String [] gfthrNms;
    private	String [] gfthrRsdtNos;
    private	String [] mthrRsdtSeqNos;
    private	String [] mthrTyes;
    private	String [] mthrNms;
    private	String [] mthrRsdtNos;
    private	String [] hsbdRsdtSeqNos;
    private	String [] hsbdTyes;
    private	String [] hsbdNms;
    private	String [] hsbdRsdtNos;
    private	String [] pmntAdCds;
    private	String [] pmntAdCdNms;
    private	String [] pmntAdDtlCts;
    
    private	String [] oldCrdNos1;
    private	String [] oldCrdNos2;
    private	String [] oldCrdNos3;
    private	String [] oldCrdNos4;
    private	String [] fthrOldCrdNos1;
    private	String [] fthrOldCrdNos2;
    private	String [] fthrOldCrdNos3;
    private	String [] fthrOldCrdNos4;
    private	String [] gfthrOldCrdNos1;
    private	String [] gfthrOldCrdNos2;
    private	String [] gfthrOldCrdNos3;
    private	String [] gfthrOldCrdNos4;
    private	String [] mthrOldCrdNos1;
    private	String [] mthrOldCrdNos2;
    private	String [] mthrOldCrdNos3;
    private	String [] mthrOldCrdNos4;
    private	String [] spusOldCrdNos1;
    private	String [] spusOldCrdNos2;
    private	String [] spusOldCrdNos3;
    private	String [] spusOldCrdNos4;
    private	String [] vrfrYns;
    
    private String mberRgstId;
    private String fthrRsdtSeqNo;
    private String fthrRgstTye;
    private String fthrOldCrdNo;
    private String gfthrRsdtSeqNo;
    private String gfthrRgstTye;
    private String gfthrOldCrdNo;
    private String mthrNm;
    private String mthrRsdtSeqNo;
    private String mthrRgstTye;
    private String mthrOldCrdNo;
    private String spusNm;
    private String spusRsdtSeqNo;
    private String spusRgstTye;
    private String spusOldCrdNo;
    private String frngrYn;
  //add 2014.04.28 end
    
    
    private String fmlyBokSeqNo;
    private String fmlyBokNo;
    private String fmlyBokRgstDd;
    private String fstVefyIndiNm;
    private String fstVefyTye;
    private String fstVefyRsdtNo;
    private String secdVefyIndiNm;
    private String secdVefyTye;
    private String secdVefyRsdtNo;
    private String fomFillHeprNm;
    private String fomFillHeprTye;
    private String fomFillHeprRsdtNo;
    private String useYn;
    
    
	//Family Book Number
    private	String	fmlyBokNoNum;
    
    private String rsdtSeqNo;
    private String fmlyMberNo;
    private String oldCrdNo;
    private String rlCd;
    private String givNm;
    private String surnm;
    private String fthrNm;
    private String gfthrNm;
    private String calTye;
    private String bthDd;
    private String gdrCd;
    private String pmntAdCd;
    private String pmntAdDtlCt;
    private String curtAdCd;
    private String curtAdDtlCt;
    private String fmlyHadYn;
    private String rsdtTyeCd;
    private String rsdtStusCd;
    private String bioKey;
    private String bioRgstDd;
    
    
  //Card Type
    private String crdCd;
    private String rsdtRgstYn;
    private String teamLedrCfmYn;
    
    
    private String rgstOrgnzCd;
    
    
    // Family Book Release Date
    private	String	rgstDd;
    // Personal Number
    private	String	rsdtNo;
    
    
    private	String	fthrGivNm;
    private	String	fthrSurnm;
    private	String	gfthrGivNm;
    private	String	gfthrSurnm;
    // Family Relationships
    private	String	rlCdNm;
    // Date of birth
    // Current Address
    private	String	curtAdPrvicCd;
    private	String	curtAdDstrCd;
    private	String	curtAdVillagCd;
    private	String	curtAdPostCd;
    //gender
    //For three weeks
    //Orphan Status
    private	String	orphanYn;
    // Domicile address
    private	String	pmntAdPrvicCd;
    private	String	pmntAdDstrCd;
    private	String	pmntAdVillagCd;
    private	String	pmntAdPostCd;
    //Place cards issued
    private	String	crdIsucePlceCd;
    //Card Issue Date
    private	String	crdIsuceDd;
    //With resolver
    private	String	fstVefyIndiRsdtNo;
    private	String	secdVefyIndiRsdtNo;
    private	String	seniorRgstOficrRsdtNo;
    private	String	rgstOficrRsdtNo;
    private	String	rgstTeamLedrRsdtNo;
    // Family Members
    //Check Username
    private	String	fstVefyIndiRsdtNoNm;
    private	String	secdVefyIndiRsdtNoNm;
    private	String	seniorRgstOficrRsdtNoNm;
    private	String	rgstOficrRsdtNoNm;
    private	String	rgstTeamLedrRsdtNoNm;
    
    //Family members
    private	String [] rsdtNos;
    private	String [] givNms;
    private	String [] surnms;
    private	String [] fthrGivNms;
    private	String [] fthrSurnms;
    private	String [] gfthrGivNms;
    private	String [] gfthrSurnms;
    private	String [] rlCds;
    private	String [] bthDds;
    private	String [] curtAdCds;
    private	String [] curtAdDtlCts;
    private	String [] gdrCds;
    private	String [] fmlyHadYns;
    private	String [] orphanYns;
    private	String [] curtAdNms;
    private	String [] tamLedrCfmYns;
    private String tamLedrCfmYn;
    private	String [] cals;
    private 	String [] rsdtSeqNos;
    
    //Log in Username
    private	String userId;
    //Social Security Number three weeks
    private	String fmlyFadRsdtNo;
    //	Whether public officials
    private	String oficrYn;
    //	Ministry for registration
    private	String fmlyBokRgstYn;
    // Whether to use
    //Personal check to the town
    private	String villagIndiVefyRsdtNo;
    //Family Name
    private	String fmlyNm;
    //Family status
    private	String fmlyStusCd;
    //Diffie social security number
    private	String rsdtNoDp;
    //Gender nine minutes people
    private	String gdrCdNm;
    //No current address
    private	String curtAdCdNm;
    //People never address
    private	String pmntAdCdNm;
    //Turn
    private	String rn;
    //Language code
    private	String useLangCd;

    //Ministry for registration
    private	String [] fmlyBokRgstYns;
    
    //Place of issue
    private	String crdIsucePlceCdNm;
    //old card number
    //Erasure code
    private String ersr;
    //Resident status code
    
    //Check one, check two
    private String fstVefyIndiRsdtNoNm1;
    private String fstVefyIndiRsdtNoNm2;
    private String secdVefyIndiRsdtNoNm1;
    private String secdVefyIndiRsdtNoNm2; 
    
    private String fomFillHeprGivNm;
    private String fomFillHeprSurnm;
    private String fstVefyIndiGivNm;
    private String fstVefyIndiSurnm;
    private String secdVefyIndiGivNm;
    private String secdVefyIndiSurnm;
    
    
    private String officerNo;
    private String [] rsdtRgstYns;
    private String	[] fmlyMberNos;
    private String delLst;
    private String [] oldCrdNos;
    private String crdIsucdPlceCdNm;
    private String crdIsucdPlceCd;
    
    //Institutions Code
    private String orgnzCd;
    private String orgnzCdNm;
    
    
    
    private String preAdCd;
    
    private String age;
    private String vrfrAgeLmt;	
	
    
    
	public FmlyInfrVO init() {
		return new FmlyInfrVO();
	}




	public String getFmlyBokSeqNo() {
		return fmlyBokSeqNo;
	}




	public void setFmlyBokSeqNo(String fmlyBokSeqNo) {
		this.fmlyBokSeqNo = fmlyBokSeqNo;
	}




	public String getFmlyBokNo() {
		return fmlyBokNo;
	}




	public void setFmlyBokNo(String fmlyBokNo) {
		this.fmlyBokNo = fmlyBokNo;
	}




	public String getFmlyBokRgstDd() {
		return fmlyBokRgstDd;
	}




	public void setFmlyBokRgstDd(String fmlyBokRgstDd) {
		this.fmlyBokRgstDd = fmlyBokRgstDd;
	}




	public String getFstVefyIndiNm() {
		return fstVefyIndiNm;
	}




	public void setFstVefyIndiNm(String fstVefyIndiNm) {
		this.fstVefyIndiNm = fstVefyIndiNm;
	}




	public String getFstVefyTye() {
		return fstVefyTye;
	}




	public void setFstVefyTye(String fstVefyTye) {
		this.fstVefyTye = fstVefyTye;
	}




	public String getFstVefyRsdtNo() {
		return fstVefyRsdtNo;
	}




	public void setFstVefyRsdtNo(String fstVefyRsdtNo) {
		this.fstVefyRsdtNo = fstVefyRsdtNo;
	}




	public String getSecdVefyIndiNm() {
		return secdVefyIndiNm;
	}




	public void setSecdVefyIndiNm(String secdVefyIndiNm) {
		this.secdVefyIndiNm = secdVefyIndiNm;
	}




	public String getSecdVefyTye() {
		return secdVefyTye;
	}




	public void setSecdVefyTye(String secdVefyTye) {
		this.secdVefyTye = secdVefyTye;
	}




	public String getSecdVefyRsdtNo() {
		return secdVefyRsdtNo;
	}




	public void setSecdVefyRsdtNo(String secdVefyRsdtNo) {
		this.secdVefyRsdtNo = secdVefyRsdtNo;
	}




	public String getFomFillHeprNm() {
		return fomFillHeprNm;
	}




	public void setFomFillHeprNm(String fomFillHeprNm) {
		this.fomFillHeprNm = fomFillHeprNm;
	}




	public String getFomFillHeprTye() {
		return fomFillHeprTye;
	}




	public void setFomFillHeprTye(String fomFillHeprTye) {
		this.fomFillHeprTye = fomFillHeprTye;
	}




	public String getFomFillHeprRsdtNo() {
		return fomFillHeprRsdtNo;
	}




	public void setFomFillHeprRsdtNo(String fomFillHeprRsdtNo) {
		this.fomFillHeprRsdtNo = fomFillHeprRsdtNo;
	}




	public String getUseYn() {
		return useYn;
	}




	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}




	public String getFmlyBokNoNum() {
		return fmlyBokNoNum;
	}




	public void setFmlyBokNoNum(String fmlyBokNoNum) {
		this.fmlyBokNoNum = fmlyBokNoNum;
	}




	public String getRgstDd() {
		return rgstDd;
	}




	public void setRgstDd(String rgstDd) {
		this.rgstDd = rgstDd;
	}




	public String getRsdtNo() {
		return rsdtNo;
	}




	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}




	public String getGivNm() {
		return givNm;
	}




	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}




	public String getSurnm() {
		return surnm;
	}




	public void setSurnm(String surnm) {
		this.surnm = surnm;
	}




	public String getFthrGivNm() {
		return fthrGivNm;
	}




	public void setFthrGivNm(String fthrGivNm) {
		this.fthrGivNm = fthrGivNm;
	}




	public String getFthrSurnm() {
		return fthrSurnm;
	}




	public void setFthrSurnm(String fthrSurnm) {
		this.fthrSurnm = fthrSurnm;
	}




	public String getGfthrGivNm() {
		return gfthrGivNm;
	}




	public void setGfthrGivNm(String gfthrGivNm) {
		this.gfthrGivNm = gfthrGivNm;
	}




	public String getGfthrSurnm() {
		return gfthrSurnm;
	}




	public void setGfthrSurnm(String gfthrSurnm) {
		this.gfthrSurnm = gfthrSurnm;
	}




	public String getRlCd() {
		return rlCd;
	}




	public void setRlCd(String rlCd) {
		this.rlCd = rlCd;
	}




	public String getRlCdNm() {
		return rlCdNm;
	}




	public void setRlCdNm(String rlCdNm) {
		this.rlCdNm = rlCdNm;
	}




	public String getBthDd() {
		return bthDd;
	}




	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}




	public String getCurtAdPrvicCd() {
		return curtAdPrvicCd;
	}




	public void setCurtAdPrvicCd(String curtAdPrvicCd) {
		this.curtAdPrvicCd = curtAdPrvicCd;
	}




	public String getCurtAdDstrCd() {
		return curtAdDstrCd;
	}




	public void setCurtAdDstrCd(String curtAdDstrCd) {
		this.curtAdDstrCd = curtAdDstrCd;
	}




	public String getCurtAdVillagCd() {
		return curtAdVillagCd;
	}




	public void setCurtAdVillagCd(String curtAdVillagCd) {
		this.curtAdVillagCd = curtAdVillagCd;
	}




	public String getCurtAdCd() {
		return curtAdCd;
	}




	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}




	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}




	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}




	public String getCurtAdPostCd() {
		return curtAdPostCd;
	}




	public void setCurtAdPostCd(String curtAdPostCd) {
		this.curtAdPostCd = curtAdPostCd;
	}




	public String getGdrCd() {
		return gdrCd;
	}




	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}




	public String getFmlyHadYn() {
		return fmlyHadYn;
	}




	public void setFmlyHadYn(String fmlyHadYn) {
		this.fmlyHadYn = fmlyHadYn;
	}




	public String getOrphanYn() {
		return orphanYn;
	}




	public void setOrphanYn(String orphanYn) {
		this.orphanYn = orphanYn;
	}




	public String getPmntAdPrvicCd() {
		return pmntAdPrvicCd;
	}




	public void setPmntAdPrvicCd(String pmntAdPrvicCd) {
		this.pmntAdPrvicCd = pmntAdPrvicCd;
	}




	public String getPmntAdDstrCd() {
		return pmntAdDstrCd;
	}




	public void setPmntAdDstrCd(String pmntAdDstrCd) {
		this.pmntAdDstrCd = pmntAdDstrCd;
	}




	public String getPmntAdVillagCd() {
		return pmntAdVillagCd;
	}




	public void setPmntAdVillagCd(String pmntAdVillagCd) {
		this.pmntAdVillagCd = pmntAdVillagCd;
	}




	public String getPmntAdCd() {
		return pmntAdCd;
	}




	public void setPmntAdCd(String pmntAdCd) {
		this.pmntAdCd = pmntAdCd;
	}




	public String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}




	public void setPmntAdDtlCt(String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}




	public String getPmntAdPostCd() {
		return pmntAdPostCd;
	}




	public void setPmntAdPostCd(String pmntAdPostCd) {
		this.pmntAdPostCd = pmntAdPostCd;
	}




	public String getCrdIsucePlceCd() {
		return crdIsucePlceCd;
	}




	public void setCrdIsucePlceCd(String crdIsucePlceCd) {
		this.crdIsucePlceCd = crdIsucePlceCd;
	}




	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}




	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}




	public String getFstVefyIndiRsdtNo() {
		return fstVefyIndiRsdtNo;
	}




	public void setFstVefyIndiRsdtNo(String fstVefyIndiRsdtNo) {
		this.fstVefyIndiRsdtNo = fstVefyIndiRsdtNo;
	}




	public String getSecdVefyIndiRsdtNo() {
		return secdVefyIndiRsdtNo;
	}




	public void setSecdVefyIndiRsdtNo(String secdVefyIndiRsdtNo) {
		this.secdVefyIndiRsdtNo = secdVefyIndiRsdtNo;
	}




	public String getSeniorRgstOficrRsdtNo() {
		return seniorRgstOficrRsdtNo;
	}




	public void setSeniorRgstOficrRsdtNo(String seniorRgstOficrRsdtNo) {
		this.seniorRgstOficrRsdtNo = seniorRgstOficrRsdtNo;
	}




	public String getRgstOficrRsdtNo() {
		return rgstOficrRsdtNo;
	}




	public void setRgstOficrRsdtNo(String rgstOficrRsdtNo) {
		this.rgstOficrRsdtNo = rgstOficrRsdtNo;
	}




	public String getRgstTeamLedrRsdtNo() {
		return rgstTeamLedrRsdtNo;
	}




	public void setRgstTeamLedrRsdtNo(String rgstTeamLedrRsdtNo) {
		this.rgstTeamLedrRsdtNo = rgstTeamLedrRsdtNo;
	}




	public String getFmlyMberNo() {
		return fmlyMberNo;
	}




	public void setFmlyMberNo(String fmlyMberNo) {
		this.fmlyMberNo = fmlyMberNo;
	}




	public String getFstVefyIndiRsdtNoNm() {
		return fstVefyIndiRsdtNoNm;
	}




	public void setFstVefyIndiRsdtNoNm(String fstVefyIndiRsdtNoNm) {
		this.fstVefyIndiRsdtNoNm = fstVefyIndiRsdtNoNm;
	}




	public String getSecdVefyIndiRsdtNoNm() {
		return secdVefyIndiRsdtNoNm;
	}




	public void setSecdVefyIndiRsdtNoNm(String secdVefyIndiRsdtNoNm) {
		this.secdVefyIndiRsdtNoNm = secdVefyIndiRsdtNoNm;
	}




	public String getSeniorRgstOficrRsdtNoNm() {
		return seniorRgstOficrRsdtNoNm;
	}




	public void setSeniorRgstOficrRsdtNoNm(String seniorRgstOficrRsdtNoNm) {
		this.seniorRgstOficrRsdtNoNm = seniorRgstOficrRsdtNoNm;
	}




	public String getRgstOficrRsdtNoNm() {
		return rgstOficrRsdtNoNm;
	}




	public void setRgstOficrRsdtNoNm(String rgstOficrRsdtNoNm) {
		this.rgstOficrRsdtNoNm = rgstOficrRsdtNoNm;
	}




	public String getRgstTeamLedrRsdtNoNm() {
		return rgstTeamLedrRsdtNoNm;
	}




	public void setRgstTeamLedrRsdtNoNm(String rgstTeamLedrRsdtNoNm) {
		this.rgstTeamLedrRsdtNoNm = rgstTeamLedrRsdtNoNm;
	}




	public String[] getRsdtNos() {
		return rsdtNos;
	}




	public void setRsdtNos(String[] rsdtNos) {
		this.rsdtNos = rsdtNos;
	}




	public String[] getGivNms() {
		return givNms;
	}




	public void setGivNms(String[] givNms) {
		this.givNms = givNms;
	}




	public String[] getSurnms() {
		return surnms;
	}




	public void setSurnms(String[] surnms) {
		this.surnms = surnms;
	}




	public String[] getFthrGivNms() {
		return fthrGivNms;
	}




	public void setFthrGivNms(String[] fthrGivNms) {
		this.fthrGivNms = fthrGivNms;
	}




	public String[] getFthrSurnms() {
		return fthrSurnms;
	}




	public void setFthrSurnms(String[] fthrSurnms) {
		this.fthrSurnms = fthrSurnms;
	}




	public String[] getGfthrGivNms() {
		return gfthrGivNms;
	}




	public void setGfthrGivNms(String[] gfthrGivNms) {
		this.gfthrGivNms = gfthrGivNms;
	}




	public String[] getGfthrSurnms() {
		return gfthrSurnms;
	}




	public void setGfthrSurnms(String[] gfthrSurnms) {
		this.gfthrSurnms = gfthrSurnms;
	}




	public String[] getRlCds() {
		return rlCds;
	}




	public void setRlCds(String[] rlCds) {
		this.rlCds = rlCds;
	}




	public String[] getBthDds() {
		return bthDds;
	}




	public void setBthDds(String[] bthDds) {
		this.bthDds = bthDds;
	}




	public String[] getCurtAdCds() {
		return curtAdCds;
	}




	public void setCurtAdCds(String[] curtAdCds) {
		this.curtAdCds = curtAdCds;
	}




	public String[] getCurtAdDtlCts() {
		return curtAdDtlCts;
	}




	public void setCurtAdDtlCts(String[] curtAdDtlCts) {
		this.curtAdDtlCts = curtAdDtlCts;
	}




	public String[] getGdrCds() {
		return gdrCds;
	}




	public void setGdrCds(String[] gdrCds) {
		this.gdrCds = gdrCds;
	}




	public String[] getFmlyHadYns() {
		return fmlyHadYns;
	}




	public void setFmlyHadYns(String[] fmlyHadYns) {
		this.fmlyHadYns = fmlyHadYns;
	}




	public String[] getOrphanYns() {
		return orphanYns;
	}




	public void setOrphanYns(String[] orphanYns) {
		this.orphanYns = orphanYns;
	}




	public String[] getCurtAdNms() {
		return curtAdNms;
	}




	public void setCurtAdNms(String[] curtAdNms) {
		this.curtAdNms = curtAdNms;
	}




	public String[] getTamLedrCfmYns() {
		return tamLedrCfmYns;
	}




	public void setTamLedrCfmYns(String[] tamLedrCfmYns) {
		this.tamLedrCfmYns = tamLedrCfmYns;
	}




	public String getTamLedrCfmYn() {
		return tamLedrCfmYn;
	}




	public void setTamLedrCfmYn(String tamLedrCfmYn) {
		this.tamLedrCfmYn = tamLedrCfmYn;
	}




	public String[] getCals() {
		return cals;
	}




	public void setCals(String[] cals) {
		this.cals = cals;
	}




	public String getCalTye() {
		return calTye;
	}




	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}




	public String getUserId() {
		return userId;
	}




	public void setUserId(String userId) {
		this.userId = userId;
	}




	public String getFmlyFadRsdtNo() {
		return fmlyFadRsdtNo;
	}




	public void setFmlyFadRsdtNo(String fmlyFadRsdtNo) {
		this.fmlyFadRsdtNo = fmlyFadRsdtNo;
	}




	public String getOficrYn() {
		return oficrYn;
	}




	public void setOficrYn(String oficrYn) {
		this.oficrYn = oficrYn;
	}




	public String getFmlyBokRgstYn() {
		return fmlyBokRgstYn;
	}




	public void setFmlyBokRgstYn(String fmlyBokRgstYn) {
		this.fmlyBokRgstYn = fmlyBokRgstYn;
	}




	public String getVillagIndiVefyRsdtNo() {
		return villagIndiVefyRsdtNo;
	}




	public void setVillagIndiVefyRsdtNo(String villagIndiVefyRsdtNo) {
		this.villagIndiVefyRsdtNo = villagIndiVefyRsdtNo;
	}




	public String getFmlyNm() {
		return fmlyNm;
	}




	public void setFmlyNm(String fmlyNm) {
		this.fmlyNm = fmlyNm;
	}




	public String getFmlyStusCd() {
		return fmlyStusCd;
	}




	public void setFmlyStusCd(String fmlyStusCd) {
		this.fmlyStusCd = fmlyStusCd;
	}




	public String getRsdtNoDp() {
		return rsdtNoDp;
	}




	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}




	public String getGdrCdNm() {
		return gdrCdNm;
	}




	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}




	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}




	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}




	public String getPmntAdCdNm() {
		return pmntAdCdNm;
	}




	public void setPmntAdCdNm(String pmntAdCdNm) {
		this.pmntAdCdNm = pmntAdCdNm;
	}




	public String getRn() {
		return rn;
	}




	public void setRn(String rn) {
		this.rn = rn;
	}




	public String getUseLangCd() {
		return useLangCd;
	}




	public void setUseLangCd(String useLangCd) {
		this.useLangCd = useLangCd;
	}




	public String[] getFmlyBokRgstYns() {
		return fmlyBokRgstYns;
	}




	public void setFmlyBokRgstYns(String[] fmlyBokRgstYns) {
		this.fmlyBokRgstYns = fmlyBokRgstYns;
	}




	public String getCrdIsucePlceCdNm() {
		return crdIsucePlceCdNm;
	}




	public void setCrdIsucePlceCdNm(String crdIsucePlceCdNm) {
		this.crdIsucePlceCdNm = crdIsucePlceCdNm;
	}




	public String getOldCrdNo() {
		return oldCrdNo;
	}




	public void setOldCrdNo(String oldCrdNo) {
		this.oldCrdNo = oldCrdNo;
	}




	public String getErsr() {
		return ersr;
	}




	public void setErsr(String ersr) {
		this.ersr = ersr;
	}




	public String getRsdtStusCd() {
		return rsdtStusCd;
	}




	public void setRsdtStusCd(String rsdtStusCd) {
		this.rsdtStusCd = rsdtStusCd;
	}




	public String getFstVefyIndiRsdtNoNm1() {
		return fstVefyIndiRsdtNoNm1;
	}




	public void setFstVefyIndiRsdtNoNm1(String fstVefyIndiRsdtNoNm1) {
		this.fstVefyIndiRsdtNoNm1 = fstVefyIndiRsdtNoNm1;
	}




	public String getFstVefyIndiRsdtNoNm2() {
		return fstVefyIndiRsdtNoNm2;
	}




	public void setFstVefyIndiRsdtNoNm2(String fstVefyIndiRsdtNoNm2) {
		this.fstVefyIndiRsdtNoNm2 = fstVefyIndiRsdtNoNm2;
	}




	public String getSecdVefyIndiRsdtNoNm1() {
		return secdVefyIndiRsdtNoNm1;
	}




	public void setSecdVefyIndiRsdtNoNm1(String secdVefyIndiRsdtNoNm1) {
		this.secdVefyIndiRsdtNoNm1 = secdVefyIndiRsdtNoNm1;
	}




	public String getSecdVefyIndiRsdtNoNm2() {
		return secdVefyIndiRsdtNoNm2;
	}




	public void setSecdVefyIndiRsdtNoNm2(String secdVefyIndiRsdtNoNm2) {
		this.secdVefyIndiRsdtNoNm2 = secdVefyIndiRsdtNoNm2;
	}




	public String getFomFillHeprGivNm() {
		return fomFillHeprGivNm;
	}




	public void setFomFillHeprGivNm(String fomFillHeprGivNm) {
		this.fomFillHeprGivNm = fomFillHeprGivNm;
	}




	public String getFomFillHeprSurnm() {
		return fomFillHeprSurnm;
	}




	public void setFomFillHeprSurnm(String fomFillHeprSurnm) {
		this.fomFillHeprSurnm = fomFillHeprSurnm;
	}




	public String getFstVefyIndiGivNm() {
		return fstVefyIndiGivNm;
	}




	public void setFstVefyIndiGivNm(String fstVefyIndiGivNm) {
		this.fstVefyIndiGivNm = fstVefyIndiGivNm;
	}




	public String getFstVefyIndiSurnm() {
		return fstVefyIndiSurnm;
	}




	public void setFstVefyIndiSurnm(String fstVefyIndiSurnm) {
		this.fstVefyIndiSurnm = fstVefyIndiSurnm;
	}




	public String getSecdVefyIndiGivNm() {
		return secdVefyIndiGivNm;
	}




	public void setSecdVefyIndiGivNm(String secdVefyIndiGivNm) {
		this.secdVefyIndiGivNm = secdVefyIndiGivNm;
	}




	public String getSecdVefyIndiSurnm() {
		return secdVefyIndiSurnm;
	}




	public void setSecdVefyIndiSurnm(String secdVefyIndiSurnm) {
		this.secdVefyIndiSurnm = secdVefyIndiSurnm;
	}




	public String getRsdtRgstYn() {
		return rsdtRgstYn;
	}




	public void setRsdtRgstYn(String rsdtRgstYn) {
		this.rsdtRgstYn = rsdtRgstYn;
	}




	public String getTeamLedrCfmYn() {
		return teamLedrCfmYn;
	}




	public void setTeamLedrCfmYn(String teamLedrCfmYn) {
		this.teamLedrCfmYn = teamLedrCfmYn;
	}




	public String getOfficerNo() {
		return officerNo;
	}




	public void setOfficerNo(String officerNo) {
		this.officerNo = officerNo;
	}




	public String[] getRsdtRgstYns() {
		return rsdtRgstYns;
	}




	public void setRsdtRgstYns(String[] rsdtRgstYns) {
		this.rsdtRgstYns = rsdtRgstYns;
	}




	public String[] getFmlyMberNos() {
		return fmlyMberNos;
	}




	public void setFmlyMberNos(String[] fmlyMberNos) {
		this.fmlyMberNos = fmlyMberNos;
	}




	public String getDelLst() {
		return delLst;
	}




	public void setDelLst(String delLst) {
		this.delLst = delLst;
	}




	public String[] getOldCrdNos() {
		return oldCrdNos;
	}




	public void setOldCrdNos(String[] oldCrdNos) {
		this.oldCrdNos = oldCrdNos;
	}




	public String getCrdIsucdPlceCdNm() {
		return crdIsucdPlceCdNm;
	}




	public void setCrdIsucdPlceCdNm(String crdIsucdPlceCdNm) {
		this.crdIsucdPlceCdNm = crdIsucdPlceCdNm;
	}




	public String getCrdIsucdPlceCd() {
		return crdIsucdPlceCd;
	}




	public void setCrdIsucdPlceCd(String crdIsucdPlceCd) {
		this.crdIsucdPlceCd = crdIsucdPlceCd;
	}




	public String getOrgnzCd() {
		return orgnzCd;
	}




	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}




	public String getOrgnzCdNm() {
		return orgnzCdNm;
	}




	public void setOrgnzCdNm(String orgnzCdNm) {
		this.orgnzCdNm = orgnzCdNm;
	}




	public String getCrdCd() {
		return crdCd;
	}




	public void setCrdCd(String crdCd) {
		this.crdCd = crdCd;
	}




	public String getPreAdCd() {
		return preAdCd;
	}




	public void setPreAdCd(String preAdCd) {
		this.preAdCd = preAdCd;
	}




	public static long getSerialversionuid() {
		return serialVersionUID;
	}




	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}




	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}




	public String getFthrNm() {
		return fthrNm;
	}




	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}




	public String getGfthrNm() {
		return gfthrNm;
	}




	public void setGfthrNm(String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}




	public String getRsdtTyeCd() {
		return rsdtTyeCd;
	}




	public void setRsdtTyeCd(String rsdtTyeCd) {
		this.rsdtTyeCd = rsdtTyeCd;
	}




	public String getBioKey() {
		return bioKey;
	}




	public void setBioKey(String bioKey) {
		this.bioKey = bioKey;
	}




	public String getBioRgstDd() {
		return bioRgstDd;
	}




	public void setBioRgstDd(String bioRgstDd) {
		this.bioRgstDd = bioRgstDd;
	}




	public String getRgstOrgnzCd() {
		return rgstOrgnzCd;
	}




	public void setRgstOrgnzCd(String rgstOrgnzCd) {
		this.rgstOrgnzCd = rgstOrgnzCd;
	}




	public String[] getRsdtSeqNos() {
		return rsdtSeqNos;
	}




	public void setRsdtSeqNos(String[] rsdtSeqNos) {
		this.rsdtSeqNos = rsdtSeqNos;
	}




	public String[] getRecodeNum() {
		return recodeNum;
	}




	public void setRecodeNum(String[] recodeNum) {
		this.recodeNum = recodeNum;
	}




	public String[] getFrngrYns() {
		return frngrYns;
	}




	public void setFrngrYns(String[] frngrYns) {
		this.frngrYns = frngrYns;
	}




	public String[] getDeadYns() {
		return deadYns;
	}




	public void setDeadYns(String[] deadYns) {
		this.deadYns = deadYns;
	}




	public String[] getFthrRsdtSeqNos() {
		return fthrRsdtSeqNos;
	}




	public void setFthrRsdtSeqNos(String[] fthrRsdtSeqNos) {
		this.fthrRsdtSeqNos = fthrRsdtSeqNos;
	}




	public String[] getFthrTyes() {
		return fthrTyes;
	}




	public void setFthrTyes(String[] fthrTyes) {
		this.fthrTyes = fthrTyes;
	}




	public String[] getFthrRsdtNos() {
		return fthrRsdtNos;
	}




	public void setFthrRsdtNos(String[] fthrRsdtNos) {
		this.fthrRsdtNos = fthrRsdtNos;
	}




	public String[] getFthrNms() {
		return fthrNms;
	}




	public void setFthrNms(String[] fthrNms) {
		this.fthrNms = fthrNms;
	}




	public String[] getGfthrRsdtSeqNos() {
		return gfthrRsdtSeqNos;
	}




	public void setGfthrRsdtSeqNos(String[] gfthrRsdtSeqNos) {
		this.gfthrRsdtSeqNos = gfthrRsdtSeqNos;
	}




	public String[] getGfthrTyes() {
		return gfthrTyes;
	}




	public void setGfthrTyes(String[] gfthrTyes) {
		this.gfthrTyes = gfthrTyes;
	}




	public String[] getGfthrNms() {
		return gfthrNms;
	}




	public void setGfthrNms(String[] gfthrNms) {
		this.gfthrNms = gfthrNms;
	}




	public String[] getGfthrRsdtNos() {
		return gfthrRsdtNos;
	}




	public void setGfthrRsdtNos(String[] gfthrRsdtNos) {
		this.gfthrRsdtNos = gfthrRsdtNos;
	}




	public String[] getMthrRsdtSeqNos() {
		return mthrRsdtSeqNos;
	}




	public void setMthrRsdtSeqNos(String[] mthrRsdtSeqNos) {
		this.mthrRsdtSeqNos = mthrRsdtSeqNos;
	}




	public String[] getMthrTyes() {
		return mthrTyes;
	}




	public void setMthrTyes(String[] mthrTyes) {
		this.mthrTyes = mthrTyes;
	}




	public String[] getMthrNms() {
		return mthrNms;
	}




	public void setMthrNms(String[] mthrNms) {
		this.mthrNms = mthrNms;
	}




	public String[] getMthrRsdtNos() {
		return mthrRsdtNos;
	}




	public void setMthrRsdtNos(String[] mthrRsdtNos) {
		this.mthrRsdtNos = mthrRsdtNos;
	}




	public String[] getHsbdRsdtSeqNos() {
		return hsbdRsdtSeqNos;
	}




	public void setHsbdRsdtSeqNos(String[] hsbdRsdtSeqNos) {
		this.hsbdRsdtSeqNos = hsbdRsdtSeqNos;
	}




	public String[] getHsbdTyes() {
		return hsbdTyes;
	}




	public void setHsbdTyes(String[] hsbdTyes) {
		this.hsbdTyes = hsbdTyes;
	}




	public String[] getHsbdNms() {
		return hsbdNms;
	}




	public void setHsbdNms(String[] hsbdNms) {
		this.hsbdNms = hsbdNms;
	}




	public String[] getHsbdRsdtNos() {
		return hsbdRsdtNos;
	}




	public void setHsbdRsdtNos(String[] hsbdRsdtNos) {
		this.hsbdRsdtNos = hsbdRsdtNos;
	}




	public String[] getPmntAdCds() {
		return pmntAdCds;
	}




	public void setPmntAdCds(String[] pmntAdCds) {
		this.pmntAdCds = pmntAdCds;
	}




	public String[] getPmntAdCdNms() {
		return pmntAdCdNms;
	}




	public void setPmntAdCdNms(String[] pmntAdCdNms) {
		this.pmntAdCdNms = pmntAdCdNms;
	}




	public String[] getPmntAdDtlCts() {
		return pmntAdDtlCts;
	}




	public void setPmntAdDtlCts(String[] pmntAdDtlCts) {
		this.pmntAdDtlCts = pmntAdDtlCts;
	}




	public String getMberRgstId() {
		return mberRgstId;
	}




	public void setMberRgstId(String mberRgstId) {
		this.mberRgstId = mberRgstId;
	}




	public String getFthrRsdtSeqNo() {
		return fthrRsdtSeqNo;
	}




	public void setFthrRsdtSeqNo(String fthrRsdtSeqNo) {
		this.fthrRsdtSeqNo = fthrRsdtSeqNo;
	}




	public String getFthrRgstTye() {
		return fthrRgstTye;
	}




	public void setFthrRgstTye(String fthrRgstTye) {
		this.fthrRgstTye = fthrRgstTye;
	}




	public String getFthrOldCrdNo() {
		return fthrOldCrdNo;
	}




	public void setFthrOldCrdNo(String fthrOldCrdNo) {
		this.fthrOldCrdNo = fthrOldCrdNo;
	}




	public String getGfthrRsdtSeqNo() {
		return gfthrRsdtSeqNo;
	}




	public void setGfthrRsdtSeqNo(String gfthrRsdtSeqNo) {
		this.gfthrRsdtSeqNo = gfthrRsdtSeqNo;
	}




	public String getGfthrRgstTye() {
		return gfthrRgstTye;
	}




	public void setGfthrRgstTye(String gfthrRgstTye) {
		this.gfthrRgstTye = gfthrRgstTye;
	}




	public String getGfthrOldCrdNo() {
		return gfthrOldCrdNo;
	}




	public void setGfthrOldCrdNo(String gfthrOldCrdNo) {
		this.gfthrOldCrdNo = gfthrOldCrdNo;
	}




	public String getMthrNm() {
		return mthrNm;
	}




	public void setMthrNm(String mthrNm) {
		this.mthrNm = mthrNm;
	}




	public String getMthrRsdtSeqNo() {
		return mthrRsdtSeqNo;
	}




	public void setMthrRsdtSeqNo(String mthrRsdtSeqNo) {
		this.mthrRsdtSeqNo = mthrRsdtSeqNo;
	}




	public String getMthrRgstTye() {
		return mthrRgstTye;
	}




	public void setMthrRgstTye(String mthrRgstTye) {
		this.mthrRgstTye = mthrRgstTye;
	}




	public String getMthrOldCrdNo() {
		return mthrOldCrdNo;
	}




	public void setMthrOldCrdNo(String mthrOldCrdNo) {
		this.mthrOldCrdNo = mthrOldCrdNo;
	}




	public String getSpusNm() {
		return spusNm;
	}




	public void setSpusNm(String spusNm) {
		this.spusNm = spusNm;
	}




	public String getSpusRsdtSeqNo() {
		return spusRsdtSeqNo;
	}




	public void setSpusRsdtSeqNo(String spusRsdtSeqNo) {
		this.spusRsdtSeqNo = spusRsdtSeqNo;
	}




	public String getSpusRgstTye() {
		return spusRgstTye;
	}




	public void setSpusRgstTye(String spusRgstTye) {
		this.spusRgstTye = spusRgstTye;
	}




	public String getSpusOldCrdNo() {
		return spusOldCrdNo;
	}




	public void setSpusOldCrdNo(String spusOldCrdNo) {
		this.spusOldCrdNo = spusOldCrdNo;
	}




	public String getFrngrYn() {
		return frngrYn;
	}




	public void setFrngrYn(String frngrYn) {
		this.frngrYn = frngrYn;
	}




	public String getInitDthYn() {
		return initDthYn;
	}




	public void setInitDthYn(String initDthYn) {
		this.initDthYn = initDthYn;
	}




	public String getDltYn() {
		return dltYn;
	}




	public void setDltYn(String dltYn) {
		this.dltYn = dltYn;
	}




	public String getFomFillHeprNo1() {
		return fomFillHeprNo1;
	}




	public void setFomFillHeprNo1(String fomFillHeprNo1) {
		this.fomFillHeprNo1 = fomFillHeprNo1;
	}




	public String getFomFillHeprNo2() {
		return fomFillHeprNo2;
	}




	public void setFomFillHeprNo2(String fomFillHeprNo2) {
		this.fomFillHeprNo2 = fomFillHeprNo2;
	}




	public String getFomFillHeprNo3() {
		return fomFillHeprNo3;
	}




	public void setFomFillHeprNo3(String fomFillHeprNo3) {
		this.fomFillHeprNo3 = fomFillHeprNo3;
	}




	public String getFthrOldCrdNo1() {
		return fthrOldCrdNo1;
	}




	public void setFthrOldCrdNo1(String fthrOldCrdNo1) {
		this.fthrOldCrdNo1 = fthrOldCrdNo1;
	}




	public String getFthrOldCrdNo2() {
		return fthrOldCrdNo2;
	}




	public void setFthrOldCrdNo2(String fthrOldCrdNo2) {
		this.fthrOldCrdNo2 = fthrOldCrdNo2;
	}




	public String getFthrOldCrdNo3() {
		return fthrOldCrdNo3;
	}




	public void setFthrOldCrdNo3(String fthrOldCrdNo3) {
		this.fthrOldCrdNo3 = fthrOldCrdNo3;
	}




	public String getGfthrOldCrdNo1() {
		return gfthrOldCrdNo1;
	}




	public void setGfthrOldCrdNo1(String gfthrOldCrdNo1) {
		this.gfthrOldCrdNo1 = gfthrOldCrdNo1;
	}




	public String getGfthrOldCrdNo2() {
		return gfthrOldCrdNo2;
	}




	public void setGfthrOldCrdNo2(String gfthrOldCrdNo2) {
		this.gfthrOldCrdNo2 = gfthrOldCrdNo2;
	}




	public String getGfthrOldCrdNo3() {
		return gfthrOldCrdNo3;
	}




	public void setGfthrOldCrdNo3(String gfthrOldCrdNo3) {
		this.gfthrOldCrdNo3 = gfthrOldCrdNo3;
	}




	public String getVrfrYn() {
		return vrfrYn;
	}




	public void setVrfrYn(String vrfrYn) {
		this.vrfrYn = vrfrYn;
	}




	public String[] getOldCrdNos1() {
		return oldCrdNos1;
	}




	public void setOldCrdNos1(String[] oldCrdNos1) {
		this.oldCrdNos1 = oldCrdNos1;
	}




	public String[] getOldCrdNos2() {
		return oldCrdNos2;
	}




	public void setOldCrdNos2(String[] oldCrdNos2) {
		this.oldCrdNos2 = oldCrdNos2;
	}




	public String[] getOldCrdNos3() {
		return oldCrdNos3;
	}




	public void setOldCrdNos3(String[] oldCrdNos3) {
		this.oldCrdNos3 = oldCrdNos3;
	}




	public String[] getFthrOldCrdNos1() {
		return fthrOldCrdNos1;
	}




	public void setFthrOldCrdNos1(String[] fthrOldCrdNos1) {
		this.fthrOldCrdNos1 = fthrOldCrdNos1;
	}




	public String[] getFthrOldCrdNos2() {
		return fthrOldCrdNos2;
	}




	public void setFthrOldCrdNos2(String[] fthrOldCrdNos2) {
		this.fthrOldCrdNos2 = fthrOldCrdNos2;
	}




	public String[] getFthrOldCrdNos3() {
		return fthrOldCrdNos3;
	}




	public void setFthrOldCrdNos3(String[] fthrOldCrdNos3) {
		this.fthrOldCrdNos3 = fthrOldCrdNos3;
	}




	public String[] getGfthrOldCrdNos1() {
		return gfthrOldCrdNos1;
	}




	public void setGfthrOldCrdNos1(String[] gfthrOldCrdNos1) {
		this.gfthrOldCrdNos1 = gfthrOldCrdNos1;
	}




	public String[] getGfthrOldCrdNos2() {
		return gfthrOldCrdNos2;
	}




	public void setGfthrOldCrdNos2(String[] gfthrOldCrdNos2) {
		this.gfthrOldCrdNos2 = gfthrOldCrdNos2;
	}




	public String[] getGfthrOldCrdNos3() {
		return gfthrOldCrdNos3;
	}




	public void setGfthrOldCrdNos3(String[] gfthrOldCrdNos3) {
		this.gfthrOldCrdNos3 = gfthrOldCrdNos3;
	}




	public String[] getMthrOldCrdNos1() {
		return mthrOldCrdNos1;
	}




	public void setMthrOldCrdNos1(String[] mthrOldCrdNos1) {
		this.mthrOldCrdNos1 = mthrOldCrdNos1;
	}




	public String[] getMthrOldCrdNos2() {
		return mthrOldCrdNos2;
	}




	public void setMthrOldCrdNos2(String[] mthrOldCrdNos2) {
		this.mthrOldCrdNos2 = mthrOldCrdNos2;
	}




	public String[] getMthrOldCrdNos3() {
		return mthrOldCrdNos3;
	}




	public void setMthrOldCrdNos3(String[] mthrOldCrdNos3) {
		this.mthrOldCrdNos3 = mthrOldCrdNos3;
	}




	public String[] getSpusOldCrdNos1() {
		return spusOldCrdNos1;
	}




	public void setSpusOldCrdNos1(String[] spusOldCrdNos1) {
		this.spusOldCrdNos1 = spusOldCrdNos1;
	}




	public String[] getSpusOldCrdNos2() {
		return spusOldCrdNos2;
	}




	public void setSpusOldCrdNos2(String[] spusOldCrdNos2) {
		this.spusOldCrdNos2 = spusOldCrdNos2;
	}




	public String[] getSpusOldCrdNos3() {
		return spusOldCrdNos3;
	}




	public void setSpusOldCrdNos3(String[] spusOldCrdNos3) {
		this.spusOldCrdNos3 = spusOldCrdNos3;
	}




	public String[] getVrfrYns() {
		return vrfrYns;
	}




	public void setVrfrYns(String[] vrfrYns) {
		this.vrfrYns = vrfrYns;
	}




	public String getFthrTye() {
		return fthrTye;
	}




	public void setFthrTye(String fthrTye) {
		this.fthrTye = fthrTye;
	}




	public String getGfthrTye() {
		return gfthrTye;
	}




	public void setGfthrTye(String gfthrTye) {
		this.gfthrTye = gfthrTye;
	}




	public String getOldCrdNo1() {
		return oldCrdNo1;
	}




	public void setOldCrdNo1(String oldCrdNo1) {
		this.oldCrdNo1 = oldCrdNo1;
	}




	public String getOldCrdNo2() {
		return oldCrdNo2;
	}




	public void setOldCrdNo2(String oldCrdNo2) {
		this.oldCrdNo2 = oldCrdNo2;
	}




	public String getOldCrdNo3() {
		return oldCrdNo3;
	}




	public void setOldCrdNo3(String oldCrdNo3) {
		this.oldCrdNo3 = oldCrdNo3;
	}




	public String getMthrOldCrdNo1() {
		return mthrOldCrdNo1;
	}




	public void setMthrOldCrdNo1(String mthrOldCrdNo1) {
		this.mthrOldCrdNo1 = mthrOldCrdNo1;
	}




	public String getMthrOldCrdNo2() {
		return mthrOldCrdNo2;
	}




	public void setMthrOldCrdNo2(String mthrOldCrdNo2) {
		this.mthrOldCrdNo2 = mthrOldCrdNo2;
	}




	public String getMthrOldCrdNo3() {
		return mthrOldCrdNo3;
	}




	public void setMthrOldCrdNo3(String mthrOldCrdNo3) {
		this.mthrOldCrdNo3 = mthrOldCrdNo3;
	}




	public String getSpusOldCrdNo1() {
		return spusOldCrdNo1;
	}




	public void setSpusOldCrdNo1(String spusOldCrdNo1) {
		this.spusOldCrdNo1 = spusOldCrdNo1;
	}




	public String getSpusOldCrdNo2() {
		return spusOldCrdNo2;
	}




	public void setSpusOldCrdNo2(String spusOldCrdNo2) {
		this.spusOldCrdNo2 = spusOldCrdNo2;
	}




	public String getSpusOldCrdNo3() {
		return spusOldCrdNo3;
	}




	public void setSpusOldCrdNo3(String spusOldCrdNo3) {
		this.spusOldCrdNo3 = spusOldCrdNo3;
	}




	public String getCfmTamLedrId() {
		return cfmTamLedrId;
	}




	public void setCfmTamLedrId(String cfmTamLedrId) {
		this.cfmTamLedrId = cfmTamLedrId;
	}




	public String getFmlyBokRgstDdG() {
		return fmlyBokRgstDdG;
	}




	public void setFmlyBokRgstDdG(String fmlyBokRgstDdG) {
		this.fmlyBokRgstDdG = fmlyBokRgstDdG;
	}




	public String getSpusRsdtNo() {
		return spusRsdtNo;
	}




	public void setSpusRsdtNo(String spusRsdtNo) {
		this.spusRsdtNo = spusRsdtNo;
	}




	public String getMthrRsdtNo() {
		return mthrRsdtNo;
	}




	public void setMthrRsdtNo(String mthrRsdtNo) {
		this.mthrRsdtNo = mthrRsdtNo;
	}




	public String getGfthrRsdtNo() {
		return gfthrRsdtNo;
	}




	public void setGfthrRsdtNo(String gfthrRsdtNo) {
		this.gfthrRsdtNo = gfthrRsdtNo;
	}




	public String getFthrRsdtNo() {
		return fthrRsdtNo;
	}




	public void setFthrRsdtNo(String fthrRsdtNo) {
		this.fthrRsdtNo = fthrRsdtNo;
	}




	public String getBthDdJ() {
		return bthDdJ;
	}




	public void setBthDdJ(String bthDdJ) {
		this.bthDdJ = bthDdJ;
	}




	public String getBthDdG() {
		return bthDdG;
	}




	public void setBthDdG(String bthDdG) {
		this.bthDdG = bthDdG;
	}




	public String getGfthrOldCrdNo4() {
		return gfthrOldCrdNo4;
	}




	public void setGfthrOldCrdNo4(String gfthrOldCrdNo4) {
		this.gfthrOldCrdNo4 = gfthrOldCrdNo4;
	}




	public String getFthrOldCrdNo4() {
		return fthrOldCrdNo4;
	}




	public void setFthrOldCrdNo4(String fthrOldCrdNo4) {
		this.fthrOldCrdNo4 = fthrOldCrdNo4;
	}




	public String getOldCrdNo4() {
		return oldCrdNo4;
	}




	public void setOldCrdNo4(String oldCrdNo4) {
		this.oldCrdNo4 = oldCrdNo4;
	}




	public String getCal() {
		return cal;
	}




	public void setCal(String cal) {
		this.cal = cal;
	}




	public String getOldCrdIsuceDd() {
		return oldCrdIsuceDd;
	}




	public void setOldCrdIsuceDd(String oldCrdIsuceDd) {
		this.oldCrdIsuceDd = oldCrdIsuceDd;
	}




	public String getFomFillHeprOldCrdNo1() {
		return fomFillHeprOldCrdNo1;
	}




	public void setFomFillHeprOldCrdNo1(String fomFillHeprOldCrdNo1) {
		this.fomFillHeprOldCrdNo1 = fomFillHeprOldCrdNo1;
	}




	public String getFomFillHeprOldCrdNo2() {
		return fomFillHeprOldCrdNo2;
	}




	public void setFomFillHeprOldCrdNo2(String fomFillHeprOldCrdNo2) {
		this.fomFillHeprOldCrdNo2 = fomFillHeprOldCrdNo2;
	}




	public String getFomFillHeprOldCrdNo3() {
		return fomFillHeprOldCrdNo3;
	}




	public void setFomFillHeprOldCrdNo3(String fomFillHeprOldCrdNo3) {
		this.fomFillHeprOldCrdNo3 = fomFillHeprOldCrdNo3;
	}




	public String getFomFillHeprOldCrdNo4() {
		return fomFillHeprOldCrdNo4;
	}




	public void setFomFillHeprOldCrdNo4(String fomFillHeprOldCrdNo4) {
		this.fomFillHeprOldCrdNo4 = fomFillHeprOldCrdNo4;
	}




	public String getFstVefyFthrNm() {
		return fstVefyFthrNm;
	}




	public void setFstVefyFthrNm(String fstVefyFthrNm) {
		this.fstVefyFthrNm = fstVefyFthrNm;
	}




	public String getFstVefyOldCrdNo1() {
		return fstVefyOldCrdNo1;
	}




	public void setFstVefyOldCrdNo1(String fstVefyOldCrdNo1) {
		this.fstVefyOldCrdNo1 = fstVefyOldCrdNo1;
	}




	public String getFstVefyOldCrdNo2() {
		return fstVefyOldCrdNo2;
	}




	public void setFstVefyOldCrdNo2(String fstVefyOldCrdNo2) {
		this.fstVefyOldCrdNo2 = fstVefyOldCrdNo2;
	}




	public String getFstVefyOldCrdNo3() {
		return fstVefyOldCrdNo3;
	}




	public void setFstVefyOldCrdNo3(String fstVefyOldCrdNo3) {
		this.fstVefyOldCrdNo3 = fstVefyOldCrdNo3;
	}




	public String getFstVefyOldCrdNo4() {
		return fstVefyOldCrdNo4;
	}




	public void setFstVefyOldCrdNo4(String fstVefyOldCrdNo4) {
		this.fstVefyOldCrdNo4 = fstVefyOldCrdNo4;
	}




	public String getSecdVefyFthrNm() {
		return secdVefyFthrNm;
	}




	public void setSecdVefyFthrNm(String secdVefyFthrNm) {
		this.secdVefyFthrNm = secdVefyFthrNm;
	}




	public String getSecdVefyOldCrdNo1() {
		return secdVefyOldCrdNo1;
	}




	public void setSecdVefyOldCrdNo1(String secdVefyOldCrdNo1) {
		this.secdVefyOldCrdNo1 = secdVefyOldCrdNo1;
	}




	public String getSecdVefyOldCrdNo2() {
		return secdVefyOldCrdNo2;
	}




	public void setSecdVefyOldCrdNo2(String secdVefyOldCrdNo2) {
		this.secdVefyOldCrdNo2 = secdVefyOldCrdNo2;
	}




	public String getSecdVefyOldCrdNo3() {
		return secdVefyOldCrdNo3;
	}




	public void setSecdVefyOldCrdNo3(String secdVefyOldCrdNo3) {
		this.secdVefyOldCrdNo3 = secdVefyOldCrdNo3;
	}




	public String getSecdVefyOldCrdNo4() {
		return secdVefyOldCrdNo4;
	}




	public void setSecdVefyOldCrdNo4(String secdVefyOldCrdNo4) {
		this.secdVefyOldCrdNo4 = secdVefyOldCrdNo4;
	}




	public String[] getOldCrdNos4() {
		return oldCrdNos4;
	}




	public void setOldCrdNos4(String[] oldCrdNos4) {
		this.oldCrdNos4 = oldCrdNos4;
	}




	public String[] getFthrOldCrdNos4() {
		return fthrOldCrdNos4;
	}




	public void setFthrOldCrdNos4(String[] fthrOldCrdNos4) {
		this.fthrOldCrdNos4 = fthrOldCrdNos4;
	}




	public String[] getGfthrOldCrdNos4() {
		return gfthrOldCrdNos4;
	}




	public void setGfthrOldCrdNos4(String[] gfthrOldCrdNos4) {
		this.gfthrOldCrdNos4 = gfthrOldCrdNos4;
	}




	public String[] getMthrOldCrdNos4() {
		return mthrOldCrdNos4;
	}




	public void setMthrOldCrdNos4(String[] mthrOldCrdNos4) {
		this.mthrOldCrdNos4 = mthrOldCrdNos4;
	}




	public String[] getSpusOldCrdNos4() {
		return spusOldCrdNos4;
	}




	public void setSpusOldCrdNos4(String[] spusOldCrdNos4) {
		this.spusOldCrdNos4 = spusOldCrdNos4;
	}




	public String getOldCrdIsucePlceCd() {
		return oldCrdIsucePlceCd;
	}




	public void setOldCrdIsucePlceCd(String oldCrdIsucePlceCd) {
		this.oldCrdIsucePlceCd = oldCrdIsucePlceCd;
	}




	public String getOldCrdIsucePlceCdNm() {
		return oldCrdIsucePlceCdNm;
	}




	public void setOldCrdIsucePlceCdNm(String oldCrdIsucePlceCdNm) {
		this.oldCrdIsucePlceCdNm = oldCrdIsucePlceCdNm;
	}




	public String getSpusOldCrdNo4() {
		return spusOldCrdNo4;
	}




	public void setSpusOldCrdNo4(String spusOldCrdNo4) {
		this.spusOldCrdNo4 = spusOldCrdNo4;
	}




	public String getCfmTamLedrIdNm() {
		return cfmTamLedrIdNm;
	}




	public void setCfmTamLedrIdNm(String cfmTamLedrIdNm) {
		this.cfmTamLedrIdNm = cfmTamLedrIdNm;
	}




	public String getMberRgstIdNm() {
		return mberRgstIdNm;
	}




	public void setMberRgstIdNm(String mberRgstIdNm) {
		this.mberRgstIdNm = mberRgstIdNm;
	}




	public String getCrdExpiryDdG() {
		return crdExpiryDdG;
	}




	public void setCrdExpiryDdG(String crdExpiryDdG) {
		this.crdExpiryDdG = crdExpiryDdG;
	}




	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}




	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}




	public String getCrdIsuceDdG() {
		return crdIsuceDdG;
	}




	public void setCrdIsuceDdG(String crdIsuceDdG) {
		this.crdIsuceDdG = crdIsuceDdG;
	}




	public String getCurtAdDiv() {
		return curtAdDiv;
	}




	public void setCurtAdDiv(String curtAdDiv) {
		this.curtAdDiv = curtAdDiv;
	}




	public String getCurtAdNatCd() {
		return curtAdNatCd;
	}




	public void setCurtAdNatCd(String curtAdNatCd) {
		this.curtAdNatCd = curtAdNatCd;
	}




	public String[] getCurtAdDivs() {
		return curtAdDivs;
	}




	public void setCurtAdDivs(String[] curtAdDivs) {
		this.curtAdDivs = curtAdDivs;
	}




	public String[] getCurtAdNatCds() {
		return curtAdNatCds;
	}




	public void setCurtAdNatCds(String[] curtAdNatCds) {
		this.curtAdNatCds = curtAdNatCds;
	}




	public String getCurtAdDtlCtD() {
		return curtAdDtlCtD;
	}




	public void setCurtAdDtlCtD(String curtAdDtlCtD) {
		this.curtAdDtlCtD = curtAdDtlCtD;
	}




	public String getCurtAdDtlCtF() {
		return curtAdDtlCtF;
	}




	public void setCurtAdDtlCtF(String curtAdDtlCtF) {
		this.curtAdDtlCtF = curtAdDtlCtF;
	}




	public String getCurtAdNatCdNm() {
		return curtAdNatCdNm;
	}




	public void setCurtAdNatCdNm(String curtAdNatCdNm) {
		this.curtAdNatCdNm = curtAdNatCdNm;
	}




	public String getFstVefyOldCrdIsucePlceCd() {
		return fstVefyOldCrdIsucePlceCd;
	}




	public void setFstVefyOldCrdIsucePlceCd(String fstVefyOldCrdIsucePlceCd) {
		this.fstVefyOldCrdIsucePlceCd = fstVefyOldCrdIsucePlceCd;
	}




	public String getFstVefyOldCrdIsuceDd() {
		return fstVefyOldCrdIsuceDd;
	}




	public void setFstVefyOldCrdIsuceDd(String fstVefyOldCrdIsuceDd) {
		this.fstVefyOldCrdIsuceDd = fstVefyOldCrdIsuceDd;
	}




	public String getSecdVefyCrdIsucePlceCd() {
		return secdVefyCrdIsucePlceCd;
	}




	public void setSecdVefyCrdIsucePlceCd(String secdVefyCrdIsucePlceCd) {
		this.secdVefyCrdIsucePlceCd = secdVefyCrdIsucePlceCd;
	}




	public String getSecdVefyOldCrdIsuceDd() {
		return secdVefyOldCrdIsuceDd;
	}




	public void setSecdVefyOldCrdIsuceDd(String secdVefyOldCrdIsuceDd) {
		this.secdVefyOldCrdIsuceDd = secdVefyOldCrdIsuceDd;
	}




	public String[] getOldCrdIsuceDds() {
		return oldCrdIsuceDds;
	}




	public void setOldCrdIsuceDds(String[] oldCrdIsuceDds) {
		this.oldCrdIsuceDds = oldCrdIsuceDds;
	}




	public String[] getOldCrdIsucePlceCds() {
		return oldCrdIsucePlceCds;
	}




	public void setOldCrdIsucePlceCds(String[] oldCrdIsucePlceCds) {
		this.oldCrdIsucePlceCds = oldCrdIsucePlceCds;
	}




	public String[] getOldCrdIsucePlceCdNms() {
		return oldCrdIsucePlceCdNms;
	}




	public void setOldCrdIsucePlceCdNms(String[] oldCrdIsucePlceCdNms) {
		this.oldCrdIsucePlceCdNms = oldCrdIsucePlceCdNms;
	}




	public String getFstVefyOldCrdIsucePlceCdNm() {
		return fstVefyOldCrdIsucePlceCdNm;
	}




	public void setFstVefyOldCrdIsucePlceCdNm(String fstVefyOldCrdIsucePlceCdNm) {
		this.fstVefyOldCrdIsucePlceCdNm = fstVefyOldCrdIsucePlceCdNm;
	}




	public String getSecdVefyCrdIsucePlceCdNm() {
		return secdVefyCrdIsucePlceCdNm;
	}




	public void setSecdVefyCrdIsucePlceCdNm(String secdVefyCrdIsucePlceCdNm) {
		this.secdVefyCrdIsucePlceCdNm = secdVefyCrdIsucePlceCdNm;
	}




	public String getCalTye2() {
		return calTye2;
	}




	public void setCalTye2(String calTye2) {
		this.calTye2 = calTye2;
	}




	public String getOldCrdIsuceDdJ() {
		return oldCrdIsuceDdJ;
	}




	public void setOldCrdIsuceDdJ(String oldCrdIsuceDdJ) {
		this.oldCrdIsuceDdJ = oldCrdIsuceDdJ;
	}




	public String getOldCrdIsuceDdG() {
		return oldCrdIsuceDdG;
	}




	public void setOldCrdIsuceDdG(String oldCrdIsuceDdG) {
		this.oldCrdIsuceDdG = oldCrdIsuceDdG;
	}




	public String getFstVefyOldCrdIsuceDdJ() {
		return fstVefyOldCrdIsuceDdJ;
	}




	public void setFstVefyOldCrdIsuceDdJ(String fstVefyOldCrdIsuceDdJ) {
		this.fstVefyOldCrdIsuceDdJ = fstVefyOldCrdIsuceDdJ;
	}




	public String getFstVefyOldCrdIsuceDdG() {
		return fstVefyOldCrdIsuceDdG;
	}




	public void setFstVefyOldCrdIsuceDdG(String fstVefyOldCrdIsuceDdG) {
		this.fstVefyOldCrdIsuceDdG = fstVefyOldCrdIsuceDdG;
	}




	public String getSecdVefyOldCrdIsuceDdJ() {
		return secdVefyOldCrdIsuceDdJ;
	}




	public void setSecdVefyOldCrdIsuceDdJ(String secdVefyOldCrdIsuceDdJ) {
		this.secdVefyOldCrdIsuceDdJ = secdVefyOldCrdIsuceDdJ;
	}




	public String getSecdVefyOldCrdIsuceDdG() {
		return secdVefyOldCrdIsuceDdG;
	}




	public void setSecdVefyOldCrdIsuceDdG(String secdVefyOldCrdIsuceDdG) {
		this.secdVefyOldCrdIsuceDdG = secdVefyOldCrdIsuceDdG;
	}




	public String getOthrRl() {
		return othrRl;
	}




	public void setOthrRl(String othrRl) {
		this.othrRl = othrRl;
	}




	public String[] getOthrRls() {
		return othrRls;
	}




	public void setOthrRls(String[] othrRls) {
		this.othrRls = othrRls;
	}




	public String getAge() {
		return age;
	}




	public void setAge(String age) {
		this.age = age;
	}




	public String getVrfrAgeLmt() {
		return vrfrAgeLmt;
	}




	public void setVrfrAgeLmt(String vrfrAgeLmt) {
		this.vrfrAgeLmt = vrfrAgeLmt;
	}

	

}