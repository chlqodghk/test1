
package afnid.rm.fmly.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;





/** 
 * This service interface is biz-class of common. <br>
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.05.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2013.05.21  		BH Choi				Create
 *
 * </pre>
 */

public interface FmlyRlService {
	
	
	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return String
	 * @exception Exception
	 */
	String selectFmlyRlNm(FmlyRlVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return String
	 * @exception Exception
	 */
	String selectFmlyRl(FmlyRlVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return EgovMap
	 * @exception Exception
	 */
	EgovMap searchFmlyTreeRqstHead(FmlyRlVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return List
	 * @exception Exception
	 */
	List<EgovMap> searchListFmlyTreeRqst(FmlyRlVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return int
	 * @exception Exception
	 */
	int searchListTotCnFmlyTreeRqst(FmlyRlVO vo) throws Exception;
	
	
	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return int
	 * @exception Exception
	 */
	int addFmlyTreeRqst(FmlyRlVO vo) throws Exception;
	
	
	
	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return EgovMap
	 * @exception Exception
	 */
	EgovMap searchFmlyTreeRsut(FmlyRlVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return List
	 * @exception Exception
	 */
	List<EgovMap> searchListFmlyTreeRsut(FmlyRlVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return int
	 * @exception Exception
	 */
	int searchListTotCnFmlyTreeRsut(FmlyRlVO vo) throws Exception;
	
	
	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return List
	 * @exception Exception
	 */
	List<EgovMap> searchListFmlyTreeRsutExcel(FmlyRlVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param FmlyRlVO
	 * @return String
	 * @exception Exception
	 */
	String searchFmlyTreeRqstResult(FmlyRlVO vo) throws Exception;
	
}
