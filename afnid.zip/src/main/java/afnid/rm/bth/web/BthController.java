package afnid.rm.bth.web;


import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.bioif.service.BioIfInfrService;
import afnid.rm.bth.service.BthService;
import afnid.rm.bth.service.BthVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;



/** 
 * This Controller class processes request of resident-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Team Ha Na YIM
 * @since 2011.04.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.04.19  		Ha Na YIM          		                    Create
 *
 * </pre>
 */

@Controller
public class BthController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
	/** NidCommonService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCmmService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** bthService */
	@Resource(name = "bthService")
    private BthService service;
	
	@Resource(name = "lgService")
    private LgService lgService;
	
	@Resource(name = "bioIfInfrService")
    private BioIfInfrService bioIfService;
    
 	/**
     * Move to Screen Birth Registration <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(bBthVOthVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/bth/BthIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/addBthView.do")
    public String addBthView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
    		
    		vo.setUseLangCd(user.getUseLangCd());

    		
    		vo.setRgstOrgnzCd(user.getOrgnzClsCd() + user.getOrgnzCd()+ user.getTamCdNm());
    		vo.setCrdIsuceLangCd(user.getUseLangCd());
    		
			CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		
			//orphan Y/N
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		List<CmCmmCdVO> mltSrvcCd = NidStringUtil.setListReverse( cmmCdMngService.searchListCmmCd(cmCmmCd, true, "") );
    		model.addAttribute("mltSrvcCd", mltSrvcCd);
    		
    		//relationship
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdMngService.searchListCmmCd(cmCmmCd, true, ""); 
    		model.addAttribute("rlCdLst", codeLst); 
    		
    		//gender
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		    	
    		//blood type
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> bldTyeCd = cmmCdMngService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("bldTyeCd", bldTyeCd); 
    		
    		//mother tongue
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> fmlyLangCd = cmmCdMngService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("fmlyLangCd", fmlyLangCd);
    		
    		//ethnicity
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		List<CmCmmCdVO> etncityCd = cmmCdMngService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("etncityCd", etncityCd);

    		//religion
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		List<CmCmmCdVO> rlgnCd = cmmCdMngService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("rlgnCd", rlgnCd);
    		
    		//religion sect
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		List<CmCmmCdVO> rlgnSect = cmmCdMngService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("rlgnSect", rlgnSect);
    		
    		//Country
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdMngService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("nltyCd", nltyCd);

    		cmCmmCd.setGrpCd("68"); 
    		List<CmCmmCdVO> dsbtCd = cmmCdMngService.searchListCmmCd(cmCmmCd, true, "");  
    		model.addAttribute("dsbtCd", dsbtCd);  
    		
    		ComDefaultVO vos = nidCmmService.searchPerToDay	(searchVO);
	    	model.addAttribute("toDatePe", vos != null && vos.getStartDay() != null ? vos.getStartDay().replaceAll("-", "") : "");
	    	
	    	vos = nidCmmService.searchGreToDay(searchVO);
	    	model.addAttribute("toDateGe", vos != null && vos.getStartDay() != null ? vos.getStartDay().replaceAll("-", "") : "");
	    	
	    	String bthRgstLmt = propertiesService.getString("bthRgstLmt");
	    	model.addAttribute("bthRgstLmt", bthRgstLmt); 
	    	
	    	int crdDlvrDd = propertiesService.getInt("crdDlvrDd");
    		vo.setCrdDlvrDd(String.valueOf(crdDlvrDd));
	    	vo.setBthRgstLmt(bthRgstLmt);
	    	BthVO bthVO=service.searchRegLimitDd(vo);
	    	
	    	if(bthVO != null){
	    		String ddObj = bthVO.getCrdIsuceDdJ();
	    		if(ddObj != null){
	    			ddObj = NidStringUtil.toNumberConvet(ddObj, "j");
	    			bthVO.setCrdIsuceDdJ(ddObj);
	    		}
	    		ddObj = bthVO.getCrdExpiryDdJ();
	    		if(ddObj != null){
	    			ddObj = NidStringUtil.toNumberConvet(ddObj, "j");
	    			bthVO.setCrdExpiryDdJ(ddObj);
	    		}
	    	}
	    	
	    	model.addAttribute("bthVO", bthVO);
	    	
	    	int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd));
    		EgovMap ems = cmmCdMngService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAdCd", ems);
    		
    		int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		model.addAttribute("useLangCd", user.getUseLangCd());
    		model.addAttribute("userId", user.getUserId());
    				
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/bth/BthIns";
    }

 	/**
     * New Registration of Birth <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param rsdtMdfcVO Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/RsdtMdfcIns.jsp"
     * @exception Exception
     */    
    @RequestMapping(value="/rm/bth/addBthInfr.do")
    public String addBthInfr(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model)
            throws Exception {
    	String resultPage = "/rm/bth/BthIns";
    	try{
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		vo.setUseLangCd(user.getUseLangCd());
    		vo.setUserId(user.getUserId());
    		vo.setLstUdtUserId(user.getUserId());
    		
    		vo.setRgstOrgnzCd(user.getOrgnzClsCd() + user.getOrgnzCd()+ user.getTamCdNm());
    		vo.setCrdIsucePlceCd(user.getOrgnzClsCd() + user.getOrgnzCd());
    		vo.setCrdIsuceLangCd(user.getUseLangCd());
    		
			CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		
			//orphan Y/N
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		List<CmCmmCdVO> mltSrvcCd = NidStringUtil.setListReverse( cmmCdMngService.searchListCmmCd(cmCmmCd, true, "") );
    		model.addAttribute("mltSrvcCd", mltSrvcCd);
    		
    		//relationship
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdMngService.searchListCmmCd(cmCmmCd, true, ""); 
    		model.addAttribute("rlCdLst", codeLst); 
    		
    		//gender
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		    	
    		//blood type
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> bldTyeCd = cmmCdMngService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("bldTyeCd", bldTyeCd); 
    		
    		//mother tongue
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> fmlyLangCd = cmmCdMngService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("fmlyLangCd", fmlyLangCd);
    		
    		//ethnicity
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		List<CmCmmCdVO> etncityCd = cmmCdMngService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("etncityCd", etncityCd);

    		//religion
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		List<CmCmmCdVO> rlgnCd = cmmCdMngService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("rlgnCd", rlgnCd);
    		
    		//religion sect
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		List<CmCmmCdVO> rlgnSect = cmmCdMngService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("rlgnSect", rlgnSect);
    		
    		//Country
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdMngService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("nltyCd", nltyCd);
    		
    		cmCmmCd.setGrpCd("68"); 
    		List<CmCmmCdVO> dsbtCd = cmmCdMngService.searchListCmmCd(cmCmmCd, true, "");  
    		model.addAttribute("dsbtCd", dsbtCd); 
    		
    		ComDefaultVO vos = nidCmmService.searchPerToDay	(searchVO);
	    	model.addAttribute("toDatePe", vos != null && vos.getStartDay() != null ? vos.getStartDay().replaceAll("-", "") : "");
	    	    		
	    	vos = nidCmmService.searchGreToDay(searchVO);
	    	model.addAttribute("toDateGe", vos != null && vos.getStartDay() != null ? vos.getStartDay().replaceAll("-", "") : "");
	    	
	    	int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd));
    		EgovMap ems = cmmCdMngService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAdCd", ems);
	    	
    		String bthRgstLmt = propertiesService.getString("bthRgstLmt");
	    	model.addAttribute("bthRgstLmt", bthRgstLmt); 
	    	
	    	int crdDlvrDd = propertiesService.getInt("crdDlvrDd");
    		vo.setCrdDlvrDd(String.valueOf(crdDlvrDd));
	    	vo.setBthRgstLmt(bthRgstLmt);
	    	BthVO bthVOs = service.searchRegLimitDd(vo);
	    	
	    	if(bthVOs != null){
	    		String ddObj = bthVOs.getCrdIsuceDdJ();
	    		if(ddObj != null){
	    			ddObj = NidStringUtil.toNumberConvet(ddObj, "j");
	    			bthVOs.setCrdIsuceDdJ(ddObj);
	    		}
	    		ddObj = bthVOs.getCrdExpiryDdJ();
	    		if(ddObj != null){
	    			ddObj = NidStringUtil.toNumberConvet(ddObj, "j");
	    			bthVOs.setCrdExpiryDdJ(ddObj);
	    		}
	    	}
	    	model.addAttribute("bthVO", bthVOs);
	    	String bthSeqNo = service.addBthInfr(vo);
	    	model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); 
	    	String crdIsuceYn = vo.getCrdIsuceYn();
			if(crdIsuceYn != null && "Y".equals(crdIsuceYn)){
				resultPage = "forward:/rm/bth/searchBthInfrUdt.do?bthSeqNo="+bthSeqNo;
			}else{
				resultPage = "forward:/rm/bth/searchBthInfrUdt.do?bthSeqNo="+bthSeqNo;
			}
			
			int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		model.addAttribute("useLangCd", user.getUseLangCd());
    		model.addAttribute("userId", user.getUserId());
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return resultPage;
    }
    
     
    
    
    /**
     * Is the edit screen. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(BthVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/bth/BthUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/searchBthInfrUdtView.do")
    public String searchBthInfrUdtView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("bthVO") BthVO bthVO,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("bldTyeCd", result); 
    		cmCmmCd.setGrpCd("12"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("mrrgCd", result); 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCdDesc(cmCmmCd); 		
    		model.addAttribute("gdrCd", result);
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("etncityCd", result);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("fmlyLangCd", result);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("nallangCd", result);
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("rlgnCd", result);
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("rlgnSect", result);
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		result = NidStringUtil.setListReverse( cmmCdMngService.searchListCmmCd(cmCmmCd) );
    		model.addAttribute("mltSrvcCd", result);
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("nltyCd", result);
    		cmCmmCd.setGrpCd("8"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("frgnLang", result);
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("rlCdLst", result); 
    		
    		cmCmmCd.setGrpCd("68"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("dsbtCd", result); 
    		
    		BthVO vo = new BthVO();
    		model.addAttribute("bthVO", vo);
    		
	    	String bthRgstLmt = propertiesService.getString("bthRgstLmt");
	    	model.addAttribute("bthRgstLmt", bthRgstLmt); 
	    	
	    	int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd));
    		EgovMap ems = cmmCdMngService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAdCd", ems);
	    	
    		int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/bth/BthUdt";
    }
    
    
    
    /**
     * Modify Birth Registration <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(BthVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/bth/BthUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/searchBthInfrUdt.do")
    public String searchBthInfrUdt(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("bldTyeCd", result); 
    		cmCmmCd.setGrpCd("12"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("mrrgCd", result); 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCdDesc(cmCmmCd); 		
    		model.addAttribute("gdrCd", result);
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("etncityCd", result);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("fmlyLangCd", result);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("nallangCd", result);
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("rlgnCd", result);
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("rlgnSect", result);
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		result = NidStringUtil.setListReverse( cmmCdMngService.searchListCmmCd(cmCmmCd) );
    		model.addAttribute("mltSrvcCd", result);
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("nltyCd", result);
    		cmCmmCd.setGrpCd("8"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("frgnLang", result);
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("rlCdLst", result); 
    		cmCmmCd.setGrpCd("68"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("dsbtCd", result);     
    		
	    	String bthRgstLmt = propertiesService.getString("bthRgstLmt");
	    	model.addAttribute("bthRgstLmt", bthRgstLmt); 
	    	vo.setBthRgstLmt(bthRgstLmt);
	    	
	    	int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd));
    		EgovMap ems = cmmCdMngService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAdCd", ems);
    		
    		int crdDlvrDd = propertiesService.getInt("crdDlvrDd");
    		vo.setCrdDlvrDd(String.valueOf(crdDlvrDd));
	    	
    		EgovMap em = null;
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		if(vo != null && vo.getBthSeqNo() != null && !"".equals(vo.getBthSeqNo())){
    			em = service.searchBthInfrDlt(vo);
    			if(em != null){
    				if(em.get("crdIsuceDdJ") != null){
    					String objDd = (String)em.get("crdIsuceDdJ");
    					em.remove("crdIsuceDdJ");
    					em.put("crdIsuceDdJ", NidStringUtil.toNumberConvet(objDd, "j"));
    				}
    				if(em.get("crdExpiryDdJ") != null){
    					String objDd = (String)em.get("crdExpiryDdJ");
    					em.remove("crdExpiryDdJ");
    					em.put("crdExpiryDdJ", NidStringUtil.toNumberConvet(objDd, "j"));
    				}
    			}
				model.addAttribute("bthVO", em);
    		}else{
        		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
        		List<EgovMap> list = service.searchBthInfrCnt(vo);
        		if(list != null && !list.isEmpty()){
        			if(list.size() > 1){
        				model.addAttribute("resultPop", "Y");
        				String searchKeyword2 = vo.getSearchKeyword2();
        				BthVO vos = new BthVO();
        				vos.setSearchKeyword2(searchKeyword2);
            			model.addAttribute("bthVO", vos);
        			}else{
        				if(list.size() == 1){
        					EgovMap lst = list.get(0);
        					BigDecimal bd = (BigDecimal)lst.get("bthSeqNo");
        					vo.setBthSeqNo(bd.toString());
        					em = service.searchBthInfrDlt(vo);
        					if(em != null){
        	    				if(em.get("crdIsuceDdJ") != null){
        	    					String objDd = (String)em.get("crdIsuceDdJ");
        	    					em.remove("crdIsuceDdJ");
        	    					em.put("crdIsuceDdJ", NidStringUtil.toNumberConvet(objDd, "j"));
        	    				}
        	    				if(em.get("crdExpiryDdJ") != null){
        	    					String objDd = (String)em.get("crdExpiryDdJ");
        	    					em.remove("crdExpiryDdJ");
        	    					em.put("crdExpiryDdJ", NidStringUtil.toNumberConvet(objDd, "j"));
        	    				}
        	    			}
        					model.addAttribute("bthVO", em);
        				}
        			}
        		}else{
        			model.addAttribute("resultMsg", nidMessageSource.getMessage("nBthRgstHst.msg"));
        			String searchKeyword2 = vo.getSearchKeyword2();
        			BthVO vos = new BthVO();
        			vos.setSearchKeyword2(searchKeyword2);
        			model.addAttribute("bthVO", vos);
        		}
    		}
    		model.addAttribute("useLangCd", user.getUseLangCd());
    		model.addAttribute("userId", user.getUserId());
    		
    		int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/bth/BthUdt";
    }
    
    
    
    
    
    
    
    /**
     *Social security number, name search. <br>
     *
     * @param vo Value-object of program to be parsed request(BthVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/searchBthParentRsdtInfoView.do")
    public void searchBthParentRsdtInfoView(
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element eleInfo = doc.createElement("rsdt_info");
    		Element ele = null;
			root.appendChild(eleInfo);
			ele = doc.createElement("is_data");
    		EgovMap em = service.searchBthParentRsdtInfoView(vo);
    		if(em != null && !em.isEmpty()){
    			ele.appendChild(doc.createTextNode( "yes" ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("rsdtSeqNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("rsdtSeqNo")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("rsdtNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("rsdtNo")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fmlyBokNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fmlyBokNo")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fmlyBokNoNum");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fmlyBokNoNum")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("givNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("givNm")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("surnm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("surnm")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("enNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("enNm")) ));
    			eleInfo.appendChild(ele);    			
    			ele = doc.createElement("gdrCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("gdrCd")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("bthDd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("bthDd")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("bthAge");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("bthAge")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fthrNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fthrNm")) ));
    			eleInfo.appendChild(ele); 
    			ele = doc.createElement("fthrRsdtSeqNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fthrRsdtSeqNo")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("pmntAdCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("pmntAdCd")) ));
    			eleInfo.appendChild(ele);      			
    			ele = doc.createElement("pmntAdCdNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("pmntAdCdNm")) ));
    			eleInfo.appendChild(ele);      			
    			ele = doc.createElement("pmntAdDtlCt");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("pmntAdDtlCt")) ));
    			eleInfo.appendChild(ele);      			
    			ele = doc.createElement("curtAdCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdCd")) ));
    			eleInfo.appendChild(ele);      			
    			ele = doc.createElement("curtAdCdNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdCdNm")) ));
    			eleInfo.appendChild(ele);      			
    			ele = doc.createElement("curtAdDtlCt");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdDtlCt")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("curtAdDiv");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdDiv")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("curtAdNatCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdNatCd")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("spusNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("spusNm")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("spusRsdtSeqNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("spusRsdtSeqNo")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("spusCnt");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("spusCnt")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("frngrYn");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("frngrYn")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("spusSeq");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("spusSeq")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("bthDdJ");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("bthDdJ")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fthrAge");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fthrAge")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("enSurnm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("enSurnm")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("fmlyHadNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fmlyHadNm")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("rlCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("rlCd")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("rlCdNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("rlCdNm")) ));
    			eleInfo.appendChild(ele);
    			    			
    		}else{
    			ele.appendChild(doc.createTextNode( "no" ));
    			eleInfo.appendChild(ele);
    		}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
    
    /**
     *Social security number, name search. <br>
     *
     * @param vo Value-object of program to be parsed request(BthVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/searchBthParentRsdtInfrSeqView.do")
    public void searchBthParentRsdtInfrSeqView(
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element eleInfo = doc.createElement("rsdt_info");
    		Element ele = null;
			root.appendChild(eleInfo);
			ele = doc.createElement("is_data");
    		EgovMap em = service.searchBthParentRsdtInfrSeqView(vo);
    		if(em != null && !em.isEmpty()){
    			ele.appendChild(doc.createTextNode( "yes" ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("rsdtSeqNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("rsdtSeqNo")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("rsdtNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("rsdtNo")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fmlyBokNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fmlyBokNo")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fmlyBokNoNum");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fmlyBokNoNum")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("givNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("givNm")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("surnm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("surnm")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("enNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("enNm")) ));
    			eleInfo.appendChild(ele);    			
    			ele = doc.createElement("gdrCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("gdrCd")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("bthDd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("bthDd")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("bthAge");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("bthAge")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fthrNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fthrNm")) ));
    			eleInfo.appendChild(ele); 
    			ele = doc.createElement("fthrRsdtSeqNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fthrRsdtSeqNo")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("pmntAdCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("pmntAdCd")) ));
    			eleInfo.appendChild(ele);      			
    			ele = doc.createElement("pmntAdCdNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("pmntAdCdNm")) ));
    			eleInfo.appendChild(ele);      			
    			ele = doc.createElement("pmntAdDtlCt");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("pmntAdDtlCt")) ));
    			eleInfo.appendChild(ele);      			
    			ele = doc.createElement("curtAdCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdCd")) ));
    			eleInfo.appendChild(ele);      			
    			ele = doc.createElement("curtAdCdNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdCdNm")) ));
    			eleInfo.appendChild(ele);      			
    			ele = doc.createElement("curtAdDtlCt");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdDtlCt")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("frngrYn");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("frngrYn")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("curtAdDiv");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdDiv")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("curtAdNatCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdNatCd")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("bthDdJ");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("bthDdJ")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fthrAge");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fthrAge")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("enSurnm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("enSurnm")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("fmlyHadNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fmlyHadNm")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("rlCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("rlCd")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("rlCdNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("rlCdNm")) ));
    			eleInfo.appendChild(ele);
    			
    		}else{
    			ele.appendChild(doc.createTextNode( "no" ));
    			eleInfo.appendChild(ele);
    		}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
    
    /**
     * Birth registration data query. <br>
     *
     * @param vo Value-object of program to be parsed request(BthVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/searchListBthPop.do")
    public String searchListBthPop(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));
	    	//** pageing *//*
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());
			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
	        List<EgovMap> lstProgram = service.searchListBthInfrPop(vo);
	        
	        if(lstProgram != null){
	        	String key = "bthDtJ";
		        for(int i = 0; i < lstProgram.size(); i++){
		        	EgovMap em = lstProgram.get(i);
		        	if(em != null && em.get(key) != null){
		        		String bthDdJ = (String)em.get(key);
		        		bthDdJ = NidStringUtil.toNumberConvet(bthDdJ, "j");
		        		em.remove(key);
		        		em.put(key, bthDdJ);
		        		key = "regDdJ";
		        		if(em != null && em.get(key) != null){
		        			bthDdJ = (String)em.get(key);
			        		bthDdJ = NidStringUtil.toNumberConvet(bthDdJ, "j");
			        		em.remove(key);
			        		em.put(key, bthDdJ);
		        		}
		        		lstProgram.set(i, em);
		        	}
		        	key = "bthDtJ";
		        }
	        }
	        
	        
	        model.addAttribute("lstProgram", lstProgram);
	        int totCnt = service.searchListBthInfrPopTotCnt(vo);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
	        model.addAttribute("useLangCd", user.getUseLangCd());
	        
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/bth/p_BthList";
    }
    
    
    
    
    /**
     * Birth registration data query. <br>
     *
     * @param vo Value-object of program to be parsed request(BthVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/modifyBthInfrModify.do")
    public String modifyBthInfrModify(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model)
            throws Exception {
    	try{
	        int result = service.modifyBthInfrUdt(vo);
	        if(result > 0){
	        	model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
	        }
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "forward:/rm/bth/searchBthInfrUdt.do";
    }
    
    /**
     * Born approval to move screen. <br>
     *
     * @param vo Value-object of program to be parsed request(BthVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/searchListBthAprvView.do")
    public String searchListBthAprvView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
     		cmCmmCd.setGrpCd("26"); 
     		List<CmCmmCdVO> cfmYn = NidStringUtil.setListReverse( cmmCdMngService.searchListCmmCd(cmCmmCd) );     		
     		model.addAttribute("cfmYn", cfmYn);
     		cmCmmCd.setGrpCd("10"); 
     		List<CmCmmCdVO> gdrCd = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
     		model.addAttribute("gdrCd", gdrCd);
     		searchVO.setSearchKeyword5("2");
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/bth/BthAprvList";
    }
    
    
    /**
     * Born approved list screen. <br>
     *
     * @param vo Value-object of program to be parsed request(BthVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/searchListBthAprv.do")
    public String searchListBthAprv(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		vo.setUseLangCd(user.getUseLangCd());	
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzCd();		
    		String orgnzCls = user.getOrgnzClsCd();		    		
    		
    		vo.setRgstOrgnzCd(orgnzCls+orgnzCd);

    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));

	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());

			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
			int aprvListTm = propertiesService.getInt("aprvListTm");
	    	vo.setAprvListTm(String.valueOf(aprvListTm));
			
			List<BthVO> lstProgram = service.searchListBtnAprv(vo);
			
			if(lstProgram != null && lstProgram.size() > 0){
				for(int i = 0; i < lstProgram.size(); i++){
					BthVO bth = lstProgram.get(i);
					String bthDt = bth.getBthDtJ();
					bthDt = NidStringUtil.toNumberConvet(bthDt, "j");
					bth.setBthDtJ(bthDt);
					lstProgram.set(i, bth);
				}
			}
			model.addAttribute("lstProgram", lstProgram);	
			
			int totCnt = service.searchListBtnAprvTotCn(vo);			
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);	
	            
	        CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("26"); 
    		List<CmCmmCdVO> cfmYn = NidStringUtil.setListReverse( cmmCdMngService.searchListCmmCd(cmCmmCd) );
    		model.addAttribute("cfmYn", cfmYn);
    		cmCmmCd.setGrpCd("10"); 
    		List<CmCmmCdVO> gdrCd = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/bth/BthAprvList";
    }
    
    
    
    /**
     * Born approved Detailed. <br>
     *
     * @param vo Value-object of program to be parsed request(BthVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/searchBthAprv.do")
    public String searchBthAprv(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("bldTyeCd", result); 
    		cmCmmCd.setGrpCd("12"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("mrrgCd", result); 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCdDesc(cmCmmCd); 		
    		model.addAttribute("gdrCd", result);
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("etncityCd", result);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("fmlyLangCd", result);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("nallangCd", result);
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("rlgnCd", result);
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("rlgnSect", result);
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		result = NidStringUtil.setListReverse( cmmCdMngService.searchListCmmCd(cmCmmCd) );
    		model.addAttribute("mltSrvcCd", result);
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("nltyCd", result);
    		cmCmmCd.setGrpCd("8"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
    		model.addAttribute("frgnLang", result);
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("rlCd", result); 
    		cmCmmCd.setGrpCd("68"); // Setting Group Code
    		result = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("dsbtCd", result);
    		
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd));
    		EgovMap ems = cmmCdMngService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAdCd", ems);
    		
    		String bthRgstLmt = propertiesService.getString("bthRgstLmt");
	    	model.addAttribute("bthRgstLmt", bthRgstLmt); 
    		vo.setBthRgstLmt(bthRgstLmt);
    		
    		int crdDlvrDd = propertiesService.getInt("crdDlvrDd");
    		vo.setCrdDlvrDd(String.valueOf(crdDlvrDd));
    		
    		EgovMap em = service.searchBthInfrDlt(vo);
    		if(em != null){
				if(em.get("crdIsuceDdJ") != null){
					String objDd = (String)em.get("crdIsuceDdJ");
					em.remove("crdIsuceDdJ");
					em.put("crdIsuceDdJ", NidStringUtil.toNumberConvet(objDd, "j"));
				}
				if(em.get("crdExpiryDdJ") != null){
					String objDd = (String)em.get("crdExpiryDdJ");
					em.remove("crdExpiryDdJ");
					em.put("crdExpiryDdJ", NidStringUtil.toNumberConvet(objDd, "j"));
				}
			}
    		model.addAttribute("bthVO", em); 
    		
    		int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		model.addAttribute("useLangCd", user.getUseLangCd());
    		model.addAttribute("userId", user.getUserId());
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/bth/BthAprvUdt";
    }
    
    
    
    /**
     * Moved to list-screen of confirm after Save. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(BthVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/bth/BthAprvUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/modifyBthInfrAprv.do")   
    public String modifyBthInfrAprv(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model)
            throws Exception {
    	try {
			int result = service.modifyBthInfrUdt(vo);
			if(result > 0){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
			}
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "forward:/rm/bth/searchBthAprv.do";
    }
    
    
    
    /**
     * Moved to list-screen of confirm after Save. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtRgstAprvUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/aprvBthInfr.do")   
    public String aprvBthInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model)
            throws Exception {
    	String returnPage = "forward:/rm/bth/searchBthAprv.do";
    	try {
    		
    			int result = service.searchBthCertNoOffDup(vo);
    			if(result > 0){
    				model.addAttribute("resultMsg", nidMessageSource.getMessage("nBthAprvByAprv.msg"));
    			}else{
		    		EgovMap em = service.aprvBthInfr(vo);
		    		result = -1;
		    		if(em != null && !em.isEmpty()){
		    			if(em.get("result") != null && em.get("result") instanceof Integer){
		    				result = ((Integer)em.get("result")).intValue();
		    			}
		    			if(em.get("bioEm") != null && em.get("bioEm") instanceof EgovMap){
		    				EgovMap bioEm = (EgovMap)em.get("bioEm");
		    				bioIfService.addBioInterfaceLog(bioEm);
		    			}
		    		}
		    		if(result > 0){
		    			model.addAttribute("resultMsg", nidMessageSource.getMessage("apvScsfl.msg")); 
		    			returnPage = "forward:/rm/bth/searchListBthAprv.do";
		    		}
    			}
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return returnPage;
    }
    
    
    
    
    /**
     * Birth registration data query. <br>
     *
     * @param vo Value-object of program to be parsed request(BthVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: "/rm/bth/p_BthSpusList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/searchListBthSpusPop.do")
    public String searchListBthSpusPop(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));
	    	//** pageing *//*
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());
			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
	        List<EgovMap> lstProgram = service.searchListBthInfrSpusPop(vo);
	        if(lstProgram != null){
	        	String key = "bthDdJ";
		        for(int i = 0; i < lstProgram.size(); i++){
		        	EgovMap em = lstProgram.get(i);
		        	if(em != null && em.get(key) != null){
		        		String bthDdJ = (String)em.get(key);
		        		bthDdJ = NidStringUtil.toNumberConvet(bthDdJ, "j");
		        		em.remove(key);
		        		em.put(key, bthDdJ);
		        		lstProgram.set(i, em);
		        	}
		        }
	        }
	        model.addAttribute("lstProgram", lstProgram);
	        int totCnt = service.searchListBthInfrSpusPopTotCnt(vo);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
	        model.addAttribute("useLangCd", user.getUseLangCd());
	        
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/bth/p_BthSpusList";
    }
    
    
    /**
     * Birth registration data query. <br>
     *
     * @param vo Value-object of program to be parsed request(BthVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: "/rm/bth/p_BthCfmRcpt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/searchBthCfmRcpt.do")
    public String searchBthCfmRcpt(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		EgovMap result = service.searchBthCfmRcpt(vo);
    		 if(user != null && !user.getUseLangCd().equals("3")){
    			 result.put("fmlyBokNoNum", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("fmlyBokNoNum")), "j")));
    			 result.put("bthDd", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("bthDd")), "j")));
    			 result.put("prntDd", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("prntDd")), "j")));
    			 result.put("crdIsuceDd", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("crdIsuceDd")), "j")));
    			 result.put("crdExpiryDd", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("crdExpiryDd")), "j")));
    			 result.put("rsdtNoDp", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("rsdtNoDp")), "j")));
    			 result.put("fmlyMberMlNo", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("fmlyMberMlNo")), "j")));
    			 result.put("fmlyMberFemlNo", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("fmlyMberFemlNo")), "j")));
    			 result.put("oldCrdNo1", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("oldCrdNo1")), "j")));
    			 result.put("oldCrdNo2", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("oldCrdNo2")), "j")));
    			 result.put("oldCrdNo3", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("oldCrdNo3")), "j")));
    			 result.put("oldCrdNo4", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("oldCrdNo4")), "j")));
    			 result.put("bthTime", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("bthTime")), "j")));
 	        }
			model.addAttribute("resultVO", result);
			model.addAttribute("useLangCd", user.getUseLangCd());
			model.addAttribute("userNm", user.getNm());
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/bth/p_BthCfmRcpt";
    }
    
    
    
    /**
     * Birth registration data query. <br>
     *
     * @param vo Value-object of program to be parsed request(BthVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: "/rm/bth/p_BthRcpt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/searchBthRcpt.do")
    public String searchBthRcpt(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		EgovMap result = service.searchBthCfmRcpt(vo);
    		 if(user != null && !user.getUseLangCd().equals("3")){
    			 result.put("fmlyBokNoNum", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("fmlyBokNoNum")), "j")));
    			 result.put("bthDd", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("bthDd")), "j")));
    			 result.put("prntDd", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("prntDd")), "j")));
    			 result.put("crdIsuceDd", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("crdIsuceDd")), "j")));
    			 result.put("crdExpiryDd", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("crdExpiryDd")), "j")));
    			 result.put("rsdtNoDp", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("rsdtNoDp")), "j")));
    			 result.put("fmlyMberMlNo", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("fmlyMberMlNo")), "j")));
    			 result.put("fmlyMberFemlNo", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("fmlyMberFemlNo")), "j")));
    			 result.put("oldCrdNo1", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("oldCrdNo1")), "j")));
    			 result.put("oldCrdNo2", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("oldCrdNo2")), "j")));
    			 result.put("oldCrdNo3", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("oldCrdNo3")), "j")));
    			 result.put("oldCrdNo4", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("oldCrdNo4")), "j")));
    			 result.put("rsdtRgstDd", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("rsdtRgstDd")), "j")));
    			 result.put("crdIsuDueDd", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("crdIsuDueDd")), "j")));
    			 result.put("rsdtNoDp", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("rsdtNoDp")), "j")));
    			 result.put("bthTime", (NidStringUtil.toNumberConvet(NidStringUtil.isNullToString(result.get("bthTime")), "j")));
 	        }
			model.addAttribute("resultVO", result);
			model.addAttribute("useLangCd", user.getUseLangCd());
			model.addAttribute("userNm", user.getNm());
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/bth/p_BthRcpt";
    }
    
	 /**
	 * Retrives wife relationship. <br>
	 *
	 * @param MrrgVO Value-object of resident to be parsed request(MrrgVO)
	 * @param model Object to be parsed http request(ModelMap)
	 * @return Printed out xml
	 * @exception Exception
	 */
	@RequestMapping(value="/rm/bth/searchMberCn.do")
	public void searchMberCn(
			@ModelAttribute("bthVO") BthVO vo,
			ModelMap model,
			HttpServletResponse response)
	        throws Exception {
		try{
			
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			vo.setUseLangCd(user.getUseLangCd());
	
			int fmlyMberCn = 0;
			
			BthVO mberCnTyeCd = service.searchMberCnTyeCd(vo);
			vo.setMberCnTyeCd(mberCnTyeCd.getMberCnTyeCd());

			fmlyMberCn = service.searchMberCn(vo);


    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");    		
    		doc.appendChild(root);
    		
    		Element el;
    		
    		if("X".equals(mberCnTyeCd.getMberCn())) {			
    			el = doc.createElement("flag");
    			el.appendChild(doc.createTextNode("N"));
        		root.appendChild(el);  
        		
    			el = doc.createElement("mberCn");
    			el.appendChild(doc.createTextNode("0"));
        		root.appendChild(el);          		
    		} else {    			
        		if( (fmlyMberCn+1) > Integer.parseInt(mberCnTyeCd.getMberCn())){
        			el = doc.createElement("flag");
        			el.appendChild(doc.createTextNode("Y"));
            		root.appendChild(el);
    	    		
        		} else {      			
        			el = doc.createElement("flag");
        			el.appendChild(doc.createTextNode("N"));
            		root.appendChild(el);    			
        		}
        		
    			el = doc.createElement("mberCn");
    			el.appendChild(doc.createTextNode(mberCnTyeCd.getMberCn()));
        		root.appendChild(el);        		
    		}
	
			Properties output = new Properties();
		    output.setProperty(OutputKeys.INDENT, "yes");
		    output.setProperty(OutputKeys.ENCODING, "UTF-8");
		    TransformerFactory tf = TransformerFactory.newInstance();
			Transformer t = tf.newTransformer();
		    t.setOutputProperties(output);
			StringWriter sw = new StringWriter();
			StreamResult result = new StreamResult(sw);
			DOMSource source = new DOMSource(doc);
			t.transform(source, result);    		
			response.setContentType("text/xml; charset=utf-8");
			response.getWriter().write(sw.toString());
		}catch (Exception e) {
			log.error(e.getMessage(), e);
			model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		}
	}
	
    /**
     * check validation of relationship <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/bth/searchChkRl.do")
    public void searchChkRl(
    		@ModelAttribute("bthVO") BthVO vo,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		String flag = service.searchChkRl(vo);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		
    		doc.appendChild(root);
    		if(flag != null && !"".equals(flag)){
    			Element el = doc.createElement("flag");
    			el.appendChild(doc.createTextNode(flag));
	    		root.appendChild(el);
    		}
    		
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }        
}
