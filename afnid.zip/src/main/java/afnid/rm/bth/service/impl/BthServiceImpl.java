package afnid.rm.bth.service.impl;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.bioif.service.BioIfInfrService;
import afnid.rm.bth.service.BthService;
import afnid.rm.bth.service.BthVO;
import afnid.rm.rsdt.service.RsdtInfrService;
import afnid.rm.rsdt.service.RsdtInfrVO;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Service("bthService")
public class BthServiceImpl extends AbstractServiceImpl implements BthService{
	
	/** crdFndDAO */
    @Resource(name="bthDAO")
    private BthDAO dao;
    
    @Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtInfrDAO;
    
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    @Resource(name = "bioIfInfrService")
    private BioIfInfrService bioIfService;
    
    @Resource(name = "rsdtInfoService")
    private RsdtInfrService rsdtInfrService;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
	
	private int sendCnt = 0;
    
   	/**
   	 * Biz-method for retrieving resident information for card found registration. <br>
   	 *
   	 * @param vo Input item for retrieving resident information for card found registration(BthVO).
   	 * @return CrdFndVO Retrieve resident information for card found registration
   	 * @exception Exception
   	 */    
	public BthVO searchRegLimitDd(BthVO vo) throws Exception{
		
		return dao.selectRegLimitDd(vo);
	}  
	
   	/**
   	 * Biz-method for retrieving resident information for card found registration. <br>
   	 *
   	 * @param vo Input item for retrieving resident information for card found registration(BthVO).
   	 * @return CrdFndVO Retrieve resident information for card found registration
   	 * @exception Exception
   	 */    
	public String addBthInfr(BthVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
		String rsdtSeqNo = dao.selectRsdtSeqNoInfr(vo);
		vo.setUserId(user.getUserId());
		vo.setRsdtSeqNo(rsdtSeqNo);
		dao.insertBthInfrRsdtInfr(vo);
		String crdCd = "1";
		vo.setCrdCd(crdCd);
		dao.insertImBioTb(vo);
		
		String crdIsuceYn = vo.getCrdIsuceYn();
		if(crdIsuceYn != null && "Y".equals(crdIsuceYn)){
			String bldTyeDocYn = vo.getBldTyeDocYn();
			if(bldTyeDocYn == null){
				vo.setBldTyeDocYn("N");
			}
			
		}else if(crdIsuceYn != null && "N".equals(crdIsuceYn)){
			vo.setCrdIsuceDd("");
			vo.setCrdExpiryDd("");
			vo.setCrdIsuDueDd("");
		}
		return dao.insertBthInfr(vo);
	}    

   	/**
   	 * Biz-method for retrieving resident information for card found registration. <br>
   	 *
   	 * @param vo Input item for retrieving resident information for card found registration(BthVO).
   	 * @return CrdFndVO Retrieve resident information for card found registration
   	 * @exception Exception
   	 */
   	public int searchListBtnAprvTotCn(BthVO vo) throws Exception {
      		return dao.selectListBtnAprvTotCn(vo);
   	}
   	
	/**
   	 * Biz-method for retrieving resident information for card found registration. <br>
   	 *
   	 * @param vo Input item for retrieving resident information for card found registration(BthVO).
   	 * @return CrdFndVO Retrieve resident information for card found registration
   	 * @exception Exception
   	 */
   	public List<BthVO> searchListBtnAprv(BthVO vo) throws Exception {
      		return dao.selectListBtnAprv(vo);
   	}

	/**
	 * Biz-method for update information of program. <br>
	 * 
	 * @param vo Input item for update information of program(BthVO).
	 * @return int result
	 * @exception Exception
	 */
	public int modifyBthInfrAprv(BthVO vo) throws Exception {   	
		return dao.updateBthInfrAprv(vo);
	}  
	

	/**
   	 * Biz-method for retrieving resident information for card found registration. <br>
   	 *
   	 * @param vo Input item for retrieving resident information for card found registration(BthVO).
   	 * @return EgovMap
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchBthInfrCnt(BthVO vo) throws Exception {
      	return dao.selectBthInfrCnt(vo);
   	}
   	
   	
   	/**
   	 * Biz-method for retrieving resident information for card found registration. <br>
   	 *
   	 * @param vo Input item for retrieving resident information for card found registration(BthVO).
   	 * @return EgovMap
   	 * @exception Exception
   	 */
   	public EgovMap searchBthInfrDlt(BthVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
   		vo.setUseLangCd(user.getUseLangCd());
   		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
   		int adultAge = propertiesService.getInt("adultAge");
   		vo.setAdultAge(String.valueOf(adultAge));
      	return dao.selectBthInfrDlt(vo);
   	}
   	
   	/**
   	 * Biz-method for retrieving resident information for card found registration. <br>
   	 *
   	 * @param vo Input item for retrieving resident information for card found registration(BthVO).
   	 * @return EgovMap
   	 * @exception Exception
   	 */
   	public EgovMap searchBthParentRsdtInfoView(BthVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
   		vo.setUseLangCd(user.getUseLangCd());   		
      	return dao.selectBthParentRsdtInfoView(vo);
   	}
   	
   	
	/**
   	 * Biz-method for retrieving resident information for card found registration. <br>
   	 *
   	 * @param vo Input item for retrieving resident information for card found registration(BthVO).
   	 * @return EgovMap
   	 * @exception Exception
   	 */
   	public EgovMap searchBthParentRsdtInfrSeqView(BthVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
   		vo.setUseLangCd(user.getUseLangCd());   		
      	return dao.selectBthParentRsdtInfrSeqView(vo);
   	}
   	
   	
   	/**
   	 * Biz-method for retrieving resident information for card found registration. <br>
   	 *
   	 * @param vo Input item for retrieving resident information for card found registration(BthVO).
   	 * @return EgovMap
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchListBthInfrPop(BthVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
   		vo.setUseLangCd(user.getUseLangCd());
   		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
      	return dao.selectListBthInfrPop(vo);
   	}
   	
   	/**
   	 * Biz-method for retrieving resident information for card found registration. <br>
   	 *
   	 * @param vo Input item for retrieving resident information for card found registration(BthVO).
   	 * @return EgovMap
   	 * @exception Exception
   	 */
   	public int searchListBthInfrPopTotCnt(BthVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
   		vo.setUseLangCd(user.getUseLangCd());
   		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());   		
      	return dao.selectListBthInfrPopTotCnt(vo);
   	}
   	
   	
   	
   	/**
   	 * Biz-method for Modify birth <br>
   	 *
   	 * @param vo Input item for Modify birth(BthVO).
   	 * @return int
   	 * @exception Exception
   	 */
   	public int modifyBthInfrUdt(BthVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
   		vo.setUserId(user.getUserId());
   		vo.setRgstOrgnzCd(user.getOrgnzClsCd() + user.getOrgnzCd());
   		
   		String crdIsuceYn = vo.getCrdIsuceYn();
		if(crdIsuceYn != null && "Y".equals(crdIsuceYn)){
			String bldTyeDocYn = vo.getBldTyeDocYn();
			if(bldTyeDocYn == null){
				vo.setBldTyeDocYn("N");
			}
		}else if(crdIsuceYn != null && "N".equals(crdIsuceYn)){
			vo.setCrdIsuceDd("");
			vo.setCrdExpiryDd("");
			vo.setCrdIsuDueDd("");
		}
		String rsdtCfmYn = vo.getRsdtCfmYn();
		if(rsdtCfmYn == null){
			vo.setRsdtCfmYn("N");
		}
		
      	return dao.updateBthInfrModify(vo);
   	}
   	
   	/**
	 * Biz-method for update information of program. <br>
	 * 
	 * @param vo Input item for update information of program(BthVO).
	 * @return EgovMap
	 * @exception Exception
	 */
	public EgovMap aprvBthInfr(BthVO vo) throws Exception { 
		EgovMap reMap = new EgovMap();
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
   		vo.setUserId(user.getUserId());
   		vo.setRgstOrgnzCd(user.getOrgnzClsCd() + user.getOrgnzCd());
   		String crdIsuceYn = vo.getCrdIsuceYn();
		if(crdIsuceYn != null && "Y".equals(crdIsuceYn)){
			String bldTyeDocYn = vo.getBldTyeDocYn();
			if(bldTyeDocYn == null){
				vo.setBldTyeDocYn("N");
			}
		}else if(crdIsuceYn != null && "N".equals(crdIsuceYn)){
			vo.setCrdIsuceDd("");
			vo.setCrdExpiryDd("");
			vo.setCrdIsuDueDd("");
		}
		String rsdtCfmYn = vo.getRsdtCfmYn();
		if(rsdtCfmYn == null){
			vo.setRsdtCfmYn("N");
		}
      	int result = dao.updateBthInfrModify(vo);
      	if(result > 0){
      		
      		String userId = user.getUserId();
    		vo.setUserId(user.getUserId());
    		vo.setTamLedrCfmYn("Y");
    		vo.setRgstOrgnzCd(user.getOrgnzClsCd() + user.getOrgnzCd());
    		result = dao.updateBthAprv(vo);
    		
    		String rsdtNo = dao.selectBthRsdtNo(vo);
    		vo.setRsdtNo(rsdtNo);
    		
    		if(result > 0){
    			//String rsdtSeqNo = vo.getRsdtSeqNo();
    			dao.updateBthInfrRsdtInfrMv(vo);
    			
    			RsdtInfrVO vos = new RsdtInfrVO();
    			vos.setRsdtSeqNo(vo.getRsdtSeqNo());
    			vos.setSgnt(vo.getSgnt());
    			String resultSgnt = rsdtInfrService.getXmlData(vos.getSgnt(), "Signature");
    	   		if(resultSgnt != null && resultSgnt.length() > 0){
    		   		vos.setSgnt(resultSgnt);
    		   		rsdtInfrDAO.updateRsdtInfrSgnt(vos);
    	   		}
    	   		
    	   		EgovMap em = rsdtInfrDAO.selectRsdtInfrDat(vos.getRsdtSeqNo());
    	   		String hash = "";
    	   		if(em != null && !em.isEmpty()){
    	   			hash = rsdtInfrDAO.selectRsdtInfrHashDat(em, "3");
    	   			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
    				if(hash != null && hash.indexOf(reg) == -1){
    					String admTel = nidMessageSource.getMessage("admTelNo");
    					throw processException("pki.websrvcEror.msg", new String[]{hash, admTel});
    				}
    	   			resultSgnt = rsdtInfrService.getXmlData(hash, "ds:Signature");
    	   		}
    	   		if(resultSgnt != null && resultSgnt.length() > 0){
    	   			vos.setSysSgnt(resultSgnt);
    	   			rsdtInfrDAO.updateRsdtInfrSysSgnt(vos);
    	   		}
    			
    			//rsdtInfrDAO.insertRsdtInfrHst(rsdtSeqNo, userId);
    			if(vo != null && "Y".equals(vo.getCrdIsuceYn())){
    				dao.insertIfCrdIsuTb(vo);
    				int adultAge = propertiesService.getInt("adultAge");
    		   		vo.setAdultAge(String.valueOf(adultAge));
    				EgovMap tcpMap = rsdtInfrDAO.selectRsdtInfrTcpIpDat(vo.getRsdtSeqNo());
    		   		if(tcpMap != null && !tcpMap.isEmpty()){
    		   			String rsdtNoa = (String)tcpMap.get("rsdtNo");
    		   			String bioKey = (String)tcpMap.get("bioKey");
    		   			String dupYn = (String)tcpMap.get("age");
    		   			String insUpd = "i";
    		   			byte [] bioFle = null;
    	   				EgovMap ImCapt = rsdtInfrDAO.selectImBioCaptTbInfr(bioKey);
    	   				if(ImCapt != null && !ImCapt.isEmpty()){
    	   					int cnt = rsdtInfrDAO.selectBmBioTb(bioKey, rsdtNoa);
    	   					if(cnt > 0){
    	   						insUpd = "u";
    	   					}
    	   					rsdtInfrDAO.deleteImBioCaptTb(bioKey);
    	   		   			bioFle = (byte[])ImCapt.get("bioFle");
    	   		   			if(bioFle != null){
    	   		   				dupYn = "N";
    	   		   				EgovMap bioEm = addRsdtInfrBioIf(bioKey, rsdtNoa, dupYn, userId, insUpd, bioFle);
    	   		   				reMap.put("bioEm", bioEm);
    	   		   			}
    	   				}
    		   		}
    			}else{
    				rsdtInfrDAO.deleteImBioCaptTb(vo.getBioKey());
    				dao.updateImBioTbInit(vo);
    			}
    		}
      	}
      	reMap.put("result", new Integer(result));
		
		return reMap;
	} 
   	
	/**
	 * Biz-method for update information of program. <br>
	 * 
	 * @param BthVO
	 * @return int result
	 * @exception Exception
	 */
	public int searchBthCertNoOffDup(BthVO vo) throws Exception { 
		return dao.selectBthCertNoOffDup(vo);
	} 
	
	
	/**
	 * Bio bio-data sent to the server. <br>
	 * @param String, String, String, String, String, byte[]
	 * @return void
	 * @exception Exception
	 */
   	private EgovMap addRsdtInfrBioIf(String bioKey, String rsdtNo, String dupYn, String userId, String insUpd, byte [] bioFle) throws Exception {
   		int tcpCnt = propertiesService.getInt("rm.bio.socketReSend");
   		sendCnt++;
   		EgovMap em = null;
   		try{
   			em = bioIfService.addBioSocketIf(bioKey, rsdtNo, dupYn, userId, insUpd, bioFle);
   		}catch(IOException e){
   			log.error(e);
   			if(tcpCnt != sendCnt){
   				em = addRsdtInfrBioIf(bioKey, rsdtNo, dupYn, userId, insUpd, bioFle);
   			}else{
   				log.error(e);
   				sendCnt = 0;
   				throw e;
   			}
   		}catch(Exception e){
   			log.error(e);
   			sendCnt = 0;
   			throw e;
   		}finally{
   			try{
   				sendCnt = 0;
   			}catch(Exception e){
   				log.error(e);
   			}
   		}
   		return em;
   	}
   	
   	
   	
   	
   	/**
   	 * Biz-method for retrieving resident information for card found registration. <br>
   	 *
   	 * @param vo Input item for retrieving resident information for card found registration(BthVO).
   	 * @return EgovMap
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchListBthInfrSpusPop(BthVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
   		vo.setUseLangCd(user.getUseLangCd());
      	return dao.selectListBthInfrSpusPop(vo);
   	}
   	
   	/**
   	 * Biz-method for retrieving resident information for card found registration. <br>
   	 *
   	 * @param vo Input item for retrieving resident information for card found registration(BthVO).
   	 * @return EgovMap
   	 * @exception Exception
   	 */
   	public int searchListBthInfrSpusPopTotCnt(BthVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
   		vo.setUseLangCd(user.getUseLangCd());
      	return dao.selectListBthInfrSpusPopTotCnt(vo);
   	}
   	
   	
   	
   	/**
   	 * Biz-method for retrieving resident information for card found registration. <br>
   	 *
   	 * @param vo Input item for retrieving resident information for card found registration(BthVO).
   	 * @return EgovMap
   	 * @exception Exception
   	 */
   	public EgovMap searchBthCfmRcpt(BthVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
   		vo.setUseLangCd(user.getUseLangCd());
   		vo.setRgstOrgnzCd(user.getOrgnzClsCd() + user.getOrgnzCd());
   		vo.setUserId(user.getUserId());
      	return dao.selectBthCfmRcpt(vo);
   	}
   	
	/**
	 * Biz-method for retrieving count relationship in family book.. <br>
	 * 
	 * @param vo Input item for retrieving count relationship in family book.(BthVO).
	 * @return List Retrieve count relationship in family book.
	 * @exception Exception
	 */
	public int searchMberCn(BthVO vo) throws Exception {		
   		return dao.selectMberCn(vo);
	}    	
	
	/**
	 * Biz-method for retrieving member count type and member count in RM_RL_TB. <br>
	 * 
	 * @param vo Input item for retrieving member count type and member count in RM_RL_TB.(BthVO).
	 * @return BthVO
	 * @exception Exception
	 */
	public BthVO searchMberCnTyeCd(BthVO vo) throws Exception {		
   		return dao.searchMberCnTyeCd(vo);
	}
	
   	/**
	 * Biz-method for retrieving validation of relationship. <br>
	 *
	 * @param vo Input item for retrieving validation of relationship(RsdtInfrVO).
	 * @return String validation value
	 * @exception Exception
	 */
   	public String searchChkRl(BthVO vo) throws Exception {
   		String flag ="N";

		List<BthVO> rlList= dao.selectListMntrRl(vo);
		
		if(rlList != null && rlList.size()>0){
			BthVO rowDat = new BthVO();
			
			for(int i=0; i< rlList.size(); i++){
				rowDat = rlList.get(i);
				
				if(vo.getRlCd().equals(rowDat.getRlCd())){
					flag ="Y";
					break;
				}
			}   			
		} else {
			List<BthVO> rlNullList= dao.selectListMntrRlNull(vo);
   			if(rlNullList != null && rlNullList.size()>0){
   				BthVO rowDat = new BthVO();
   				
   				for(int i=0; i< rlNullList.size(); i++){
   					rowDat = rlNullList.get(i);
   					
   					if(vo.getRlCd().equals(rowDat.getRlCd())){
   						flag ="Y";
   						break;
   					}
   				}
   			}
		}

   		
        return flag;
	} 	
}
