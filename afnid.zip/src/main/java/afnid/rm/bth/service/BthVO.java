package afnid.rm.bth.service;

import afnid.cm.ComDefaultVO;

public class BthVO extends ComDefaultVO{

	private static final long serialVersionUID = 1L;
	private String othrRl;
	private String fmlyHadNm;
	private String fEnSurnm;
	private String rsdtNoDp;
	private String fAge;
	private String mAge;
	private String gAge;
	
	private String curtAdNatCdNm;
	private String curtAdDiv;
	private String curtAdNatCd;
	private String secdNltyYn;
	private String emlAd;
	private String curtAdDtlCtD;
	private String curtAdDtlCtF;
	
	private String adultAge;
	private String aprvListTm;
	private String bthDtJ;
	private String bthDtG;
	private String bthRgstLmt;
	private String age;
	private String crdExpiryDdJ;
	private String crdExpiryDdG;
	private String crdIsuceDdJ;
	private String crdIsuceDdG;
	private String crdDlvrDd;
	private String cntTelNo;
	private String cntTelNo2;
	private String fmlyMberNo;
	private String searchKeywordNm;
	private String bthDtTime1;
	private String bthDtTime2;
	private String bthDtTime3;
	private String regDd;
	private String toDateGe;
	private String toDatePe;
	private String regGeLimitDd;
	private String regPeLimitDd;
	private String crdCd;
	private String bthSeqNo;
	private String orpYn;
	private String bthDt;
	private String gdrCd;
	private String gdrCdNm;
	private String givNm;
	private String surnm;
	private String bthPlceCd;
	private String bthPlceCdNm;
	private String bthPlceDtlCt;
	private String bthNatCd;
	private String bthNatDiv;
	private String frgnBthCtyNm;
	private String fthrNm;
	private String fthrRsdtSeqNo;
	private String mthrNm;
	private String mthrRsdtSeqNo;
	private String gfthrNm;
	private String pmntAdCd;
	private String pmntAdCdNm;
	private String pmntAdDtlCt;
	private String curtAdCd;
	private String curtAdCdNm;
	private String curtAdDtlCt;
	private String fmlyBokNo;
	private String fmlyBokNoNum;
	private String certNo;
	private String pbctOfic;
	private String rmk;
	private String crdIsuceYn;
	private String rsdtTyeCd;
	private String enNm;
	private String bldTyeCd;
	private String encyCd;
	private String fmlyLangCd;
	private String smrRsdcCd;
	private String smrRsdcCdNm;
	private String wtrRsdcCd;
	private String wtrRsdcCdNm;
	private String secdNltyCd;
	private String dsbtDtlCt;
	private String rlgnCd;
	private String rlgnSectCd;
	private String crdIsucePlceCd;
	private String crdIsuceLangCd;
	private String crdIsuceDd;
	private String crdExpiryDd;
	private String crdIsuDueDd;
	private String rsdtSeqNo;
	private String rgstOrgnzCd;
	private String tamLedrCfmYn;
	private String cfmTamLedrId;
	private String fstRgstUserId;
	private String fstRgstDt;
	private String lstUdtUserId;
	private String lstUdtDt;
	private String rlCd;
	private String rlCdNm;
	private String fthrRsdtNo;
	private String mthrRsdtNo;
	private String tmpRlgnSectCd;
	private String tmpRlgnSectNm;
	private String calTye;
	private String toDate;
	private String bthDtTime;
	private String oprYn;
	private String frgnBtnCtyNm;
	private String userId;
	private String rsdtNo;
	private String sgnt;
	private String crdIsucePlceCdNm;
	private String bioCaptYn;
	private String bioKey;
	private String enSurnm;
	private String enGivNm;
	private String dsbtCd;
	private String dsbtCdNm;
	private String rsdtCfmYn;
	private String bldTyeDocYn;
	private String eduLvDocYn;	
	private String gfthrRsdtSeqNo;
	private String crdIsuceDdPe;
	
	private String flag;
	private String mberCn;
	private String mberCnTyeCd;
	private String fthrRlCd;
	private String mthrRlCd;
	private String fthrRlCdNm;
	private String mthrRlCdNm;
	private String fmlYHadGdrCd;
	
	public String getSgnt() {
		return sgnt;
	}
	public void setSgnt(String sgnt) {
		this.sgnt = sgnt;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFrgnBtnCtyNm() {
		return frgnBtnCtyNm;
	}
	public void setFrgnBtnCtyNm(String frgnBtnCtyNm) {
		this.frgnBtnCtyNm = frgnBtnCtyNm;
	}
	public String getOprYn() {
		return oprYn;
	}
	public void setOprYn(String oprYn) {
		this.oprYn = oprYn;
	}
	public String getBthDtTime() {
		return bthDtTime;
	}
	public void setBthDtTime(String bthDtTime) {
		this.bthDtTime = bthDtTime;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getCalTye() {
		return calTye;
	}
	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}
	public String getTmpRlgnSectCd() {
		return tmpRlgnSectCd;
	}
	public void setTmpRlgnSectCd(String tmpRlgnSectCd) {
		this.tmpRlgnSectCd = tmpRlgnSectCd;
	}
	public String getTmpRlgnSectNm() {
		return tmpRlgnSectNm;
	}
	public void setTmpRlgnSectNm(String tmpRlgnSectNm) {
		this.tmpRlgnSectNm = tmpRlgnSectNm;
	}
	public String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}
	public void setPmntAdDtlCt(String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}
	public String getFthrRsdtNo() {
		return fthrRsdtNo;
	}
	public void setFthrRsdtNo(String fthrRsdtNo) {
		this.fthrRsdtNo = fthrRsdtNo;
	}
	public String getMthrRsdtNo() {
		return mthrRsdtNo;
	}
	public void setMthrRsdtNo(String mthrRsdtNo) {
		this.mthrRsdtNo = mthrRsdtNo;
	}
	public String getFmlyBokNoNum() {
		return fmlyBokNoNum;
	}
	public void setFmlyBokNoNum(String fmlyBokNoNum) {
		this.fmlyBokNoNum = fmlyBokNoNum;
	}
	public String getBthNatCd() {
		return bthNatCd;
	}
	public void setBthNatCd(String bthNatCd) {
		this.bthNatCd = bthNatCd;
	}
	public String getBthNatDiv() {
		return bthNatDiv;
	}
	public void setBthNatDiv(String bthNatDiv) {
		this.bthNatDiv = bthNatDiv;
	}
	public String getFrgnBthCtyNm() {
		return frgnBthCtyNm;
	}
	public void setFrgnBthCtyNm(String frgnBthCtyNm) {
		this.frgnBthCtyNm = frgnBthCtyNm;
	}
	public String getSmrRsdcCdNm() {
		return smrRsdcCdNm;
	}
	public void setSmrRsdcCdNm(String smrRsdcCdNm) {
		this.smrRsdcCdNm = smrRsdcCdNm;
	}
	public String getWtrRsdcCdNm() {
		return wtrRsdcCdNm;
	}
	public void setWtrRsdcCdNm(String wtrRsdcCdNm) {
		this.wtrRsdcCdNm = wtrRsdcCdNm;
	}
	public String getRlCd() {
		return rlCd;
	}
	public void setRlCd(String rlCd) {
		this.rlCd = rlCd;
	}
	public String getBthSeqNo() {
		return bthSeqNo;
	}
	public void setBthSeqNo(String bthSeqNo) {
		this.bthSeqNo = bthSeqNo;
	}
	public String getOrpYn() {
		return orpYn;
	}
	public void setOrpYn(String orpYn) {
		this.orpYn = orpYn;
	}
	public String getBthDt() {
		return bthDt;
	}
	public void setBthDt(String bthDt) {
		this.bthDt = bthDt;
	}
	public String getGdrCd() {
		return gdrCd;
	}
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	public String getGivNm() {
		return givNm;
	}
	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}
	public String getSurnm() {
		return surnm;
	}
	public void setSurnm(String surnm) {
		this.surnm = surnm;
	}
	public String getBthPlceCd() {
		return bthPlceCd;
	}
	public void setBthPlceCd(String bthPlceCd) {
		this.bthPlceCd = bthPlceCd;
	}
	public String getBthPlceCdNm() {
		return bthPlceCdNm;
	}
	public void setBthPlceCdNm(String bthPlceCdNm) {
		this.bthPlceCdNm = bthPlceCdNm;
	}
	public String getBthPlceDtlCt() {
		return bthPlceDtlCt;
	}
	public void setBthPlceDtlCt(String bthPlceDtlCt) {
		this.bthPlceDtlCt = bthPlceDtlCt;
	}
	public String getFthrNm() {
		return fthrNm;
	}
	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}
	public String getFthrRsdtSeqNo() {
		return fthrRsdtSeqNo;
	}
	public void setFthrRsdtSeqNo(String fthrRsdtSeqNo) {
		this.fthrRsdtSeqNo = fthrRsdtSeqNo;
	}
	public String getMthrNm() {
		return mthrNm;
	}
	public void setMthrNm(String mthrNm) {
		this.mthrNm = mthrNm;
	}
	public String getMthrRsdtSeqNo() {
		return mthrRsdtSeqNo;
	}
	public void setMthrRsdtSeqNo(String mthrRsdtSeqNo) {
		this.mthrRsdtSeqNo = mthrRsdtSeqNo;
	}
	public String getGfthrNm() {
		return gfthrNm;
	}
	public void setGfthrNm(String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}
	public String getPmntAdCd() {
		return pmntAdCd;
	}
	public void setPmntAdCd(String pmntAdCd) {
		this.pmntAdCd = pmntAdCd;
	}
	public String getPmntAdCdNm() {
		return pmntAdCdNm;
	}
	public void setPmntAdCdNm(String pmntAdCdNm) {
		this.pmntAdCdNm = pmntAdCdNm;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}
	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}
	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}
	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}
	public String getFmlyBokNo() {
		return fmlyBokNo;
	}
	public void setFmlyBokNo(String fmlyBokNo) {
		this.fmlyBokNo = fmlyBokNo;
	}
	public String getCertNo() {
		return certNo;
	}
	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}
	public String getPbctOfic() {
		return pbctOfic;
	}
	public void setPbctOfic(String pbctOfic) {
		this.pbctOfic = pbctOfic;
	}
	public String getRmk() {
		return rmk;
	}
	public void setRmk(String rmk) {
		this.rmk = rmk;
	}
	public String getCrdIsuceYn() {
		return crdIsuceYn;
	}
	public void setCrdIsuceYn(String crdIsuceYn) {
		this.crdIsuceYn = crdIsuceYn;
	}
	public String getRsdtTyeCd() {
		return rsdtTyeCd;
	}
	public void setRsdtTyeCd(String rsdtTyeCd) {
		this.rsdtTyeCd = rsdtTyeCd;
	}
	public String getEnNm() {
		return enNm;
	}
	public void setEnNm(String enNm) {
		this.enNm = enNm;
	}
	public String getBldTyeCd() {
		return bldTyeCd;
	}
	public void setBldTyeCd(String bldTyeCd) {
		this.bldTyeCd = bldTyeCd;
	}
	public String getEncyCd() {
		return encyCd;
	}
	public void setEncyCd(String encyCd) {
		this.encyCd = encyCd;
	}
	public String getFmlyLangCd() {
		return fmlyLangCd;
	}
	public void setFmlyLangCd(String fmlyLangCd) {
		this.fmlyLangCd = fmlyLangCd;
	}
	public String getSmrRsdcCd() {
		return smrRsdcCd;
	}
	public void setSmrRsdcCd(String smrRsdcCd) {
		this.smrRsdcCd = smrRsdcCd;
	}
	public String getWtrRsdcCd() {
		return wtrRsdcCd;
	}
	public void setWtrRsdcCd(String wtrRsdcCd) {
		this.wtrRsdcCd = wtrRsdcCd;
	}
	public String getSecdNltyCd() {
		return secdNltyCd;
	}
	public void setSecdNltyCd(String secdNltyCd) {
		this.secdNltyCd = secdNltyCd;
	}
	public String getDsbtDtlCt() {
		return dsbtDtlCt;
	}
	public void setDsbtDtlCt(String dsbtDtlCt) {
		this.dsbtDtlCt = dsbtDtlCt;
	}
	public String getRlgnCd() {
		return rlgnCd;
	}
	public void setRlgnCd(String rlgnCd) {
		this.rlgnCd = rlgnCd;
	}
	public String getRlgnSectCd() {
		return rlgnSectCd;
	}
	public void setRlgnSectCd(String rlgnSectCd) {
		this.rlgnSectCd = rlgnSectCd;
	}
	public String getCrdIsucePlceCd() {
		return crdIsucePlceCd;
	}
	public void setCrdIsucePlceCd(String crdIsucePlceCd) {
		this.crdIsucePlceCd = crdIsucePlceCd;
	}
	public String getCrdIsuceLangCd() {
		return crdIsuceLangCd;
	}
	public void setCrdIsuceLangCd(String crdIsuceLangCd) {
		this.crdIsuceLangCd = crdIsuceLangCd;
	}
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}
	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}
	public String getCrdIsuDueDd() {
		return crdIsuDueDd;
	}
	public void setCrdIsuDueDd(String crdIsuDueDd) {
		this.crdIsuDueDd = crdIsuDueDd;
	}
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getRgstOrgnzCd() {
		return rgstOrgnzCd;
	}
	public void setRgstOrgnzCd(String rgstOrgnzCd) {
		this.rgstOrgnzCd = rgstOrgnzCd;
	}
	public String getTamLedrCfmYn() {
		return tamLedrCfmYn;
	}
	public void setTamLedrCfmYn(String tamLedrCfmYn) {
		this.tamLedrCfmYn = tamLedrCfmYn;
	}
	public String getCfmTamLedrId() {
		return cfmTamLedrId;
	}
	public void setCfmTamLedrId(String cfmTamLedrId) {
		this.cfmTamLedrId = cfmTamLedrId;
	}
	public String getFstRgstUserId() {
		return fstRgstUserId;
	}
	public void setFstRgstUserId(String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}
	public String getFstRgstDt() {
		return fstRgstDt;
	}
	public void setFstRgstDt(String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}
	public String getLstUdtUserId() {
		return lstUdtUserId;
	}
	public void setLstUdtUserId(String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}
	public String getLstUdtDt() {
		return lstUdtDt;
	}
	public void setLstUdtDt(String lstUdtDt) {
		this.lstUdtDt = lstUdtDt;
	}
	public String getSearchKeywordNm() {
		return searchKeywordNm;
	}
	public void setSearchKeywordNm(String searchKeywordNm) {
		this.searchKeywordNm = searchKeywordNm;
	}
	public String getCrdIsucePlceCdNm() {
		return crdIsucePlceCdNm;
	}
	public void setCrdIsucePlceCdNm(String crdIsucePlceCdNm) {
		this.crdIsucePlceCdNm = crdIsucePlceCdNm;
	}
	public String getToDateGe() {
		return toDateGe;
	}
	public void setToDateGe(String toDateGe) {
		this.toDateGe = toDateGe;
	}
	public String getToDatePe() {
		return toDatePe;
	}
	public void setToDatePe(String toDatePe) {
		this.toDatePe = toDatePe;
	}
	public String getRegGeLimitDd() {
		return regGeLimitDd;
	}
	public void setRegGeLimitDd(String regGeLimitDd) {
		this.regGeLimitDd = regGeLimitDd;
	}
	public String getRegPeLimitDd() {
		return regPeLimitDd;
	}
	public void setRegPeLimitDd(String regPeLimitDd) {
		this.regPeLimitDd = regPeLimitDd;
	}
	public String getRegDd() {
		return regDd;
	}
	public void setRegDd(String regDd) {
		this.regDd = regDd;
	}
	public String getBthDtTime1() {
		return bthDtTime1;
	}
	public void setBthDtTime1(String bthDtTime1) {
		this.bthDtTime1 = bthDtTime1;
	}
	public String getBthDtTime2() {
		return bthDtTime2;
	}
	public void setBthDtTime2(String bthDtTime2) {
		this.bthDtTime2 = bthDtTime2;
	}
	public String getBthDtTime3() {
		return bthDtTime3;
	}
	public void setBthDtTime3(String bthDtTime3) {
		this.bthDtTime3 = bthDtTime3;
	}
	public String getCrdCd() {
		return crdCd;
	}
	public void setCrdCd(String crdCd) {
		this.crdCd = crdCd;
	}
	public String getFmlyMberNo() {
		return fmlyMberNo;
	}
	public void setFmlyMberNo(String fmlyMberNo) {
		this.fmlyMberNo = fmlyMberNo;
	}
	public String getBioCaptYn() {
		return bioCaptYn;
	}
	public void setBioCaptYn(String bioCaptYn) {
		this.bioCaptYn = bioCaptYn;
	}
	public String getBioKey() {
		return bioKey;
	}
	public void setBioKey(String bioKey) {
		this.bioKey = bioKey;
	}
	public String getEnSurnm() {
		return enSurnm;
	}
	public void setEnSurnm(String enSurnm) {
		this.enSurnm = enSurnm;
	}
	public String getEnGivNm() {
		return enGivNm;
	}
	public void setEnGivNm(String enGivNm) {
		this.enGivNm = enGivNm;
	}
	public String getDsbtCd() {
		return dsbtCd;
	}
	public void setDsbtCd(String dsbtCd) {
		this.dsbtCd = dsbtCd;
	}
	public String getDsbtCdNm() {
		return dsbtCdNm;
	}
	public void setDsbtCdNm(String dsbtCdNm) {
		this.dsbtCdNm = dsbtCdNm;
	}
	public String getRsdtCfmYn() {
		return rsdtCfmYn;
	}
	public void setRsdtCfmYn(String rsdtCfmYn) {
		this.rsdtCfmYn = rsdtCfmYn;
	}
	public String getBldTyeDocYn() {
		return bldTyeDocYn;
	}
	public void setBldTyeDocYn(String bldTyeDocYn) {
		this.bldTyeDocYn = bldTyeDocYn;
	}
	public String getEduLvDocYn() {
		return eduLvDocYn;
	}
	public void setEduLvDocYn(String eduLvDocYn) {
		this.eduLvDocYn = eduLvDocYn;
	}
	public String getGfthrRsdtSeqNo() {
		return gfthrRsdtSeqNo;
	}
	public void setGfthrRsdtSeqNo(String gfthrRsdtSeqNo) {
		this.gfthrRsdtSeqNo = gfthrRsdtSeqNo;
	}
	public String getCrdIsuceDdPe() {
		return crdIsuceDdPe;
	}
	public void setCrdIsuceDdPe(String crdIsuceDdPe) {
		this.crdIsuceDdPe = crdIsuceDdPe;
	}
	public String getCntTelNo() {
		return cntTelNo;
	}
	public void setCntTelNo(String cntTelNo) {
		this.cntTelNo = cntTelNo;
	}
	public String getCrdDlvrDd() {
		return crdDlvrDd;
	}
	public void setCrdDlvrDd(String crdDlvrDd) {
		this.crdDlvrDd = crdDlvrDd;
	}
	public String getCrdExpiryDdJ() {
		return crdExpiryDdJ;
	}
	public void setCrdExpiryDdJ(String crdExpiryDdJ) {
		this.crdExpiryDdJ = crdExpiryDdJ;
	}
	public String getCrdExpiryDdG() {
		return crdExpiryDdG;
	}
	public void setCrdExpiryDdG(String crdExpiryDdG) {
		this.crdExpiryDdG = crdExpiryDdG;
	}
	public String getCrdIsuceDdJ() {
		return crdIsuceDdJ;
	}
	public void setCrdIsuceDdJ(String crdIsuceDdJ) {
		this.crdIsuceDdJ = crdIsuceDdJ;
	}
	public String getCrdIsuceDdG() {
		return crdIsuceDdG;
	}
	public void setCrdIsuceDdG(String crdIsuceDdG) {
		this.crdIsuceDdG = crdIsuceDdG;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getBthRgstLmt() {
		return bthRgstLmt;
	}
	public void setBthRgstLmt(String bthRgstLmt) {
		this.bthRgstLmt = bthRgstLmt;
	}
	public String getBthDtJ() {
		return bthDtJ;
	}
	public void setBthDtJ(String bthDtJ) {
		this.bthDtJ = bthDtJ;
	}
	public String getBthDtG() {
		return bthDtG;
	}
	public void setBthDtG(String bthDtG) {
		this.bthDtG = bthDtG;
	}
	public String getAprvListTm() {
		return aprvListTm;
	}
	public void setAprvListTm(String aprvListTm) {
		this.aprvListTm = aprvListTm;
	}
	public String getAdultAge() {
		return adultAge;
	}
	public void setAdultAge(String adultAge) {
		this.adultAge = adultAge;
	}
	public String getCurtAdDiv() {
		return curtAdDiv;
	}
	public void setCurtAdDiv(String curtAdDiv) {
		this.curtAdDiv = curtAdDiv;
	}
	public String getCurtAdNatCd() {
		return curtAdNatCd;
	}
	public void setCurtAdNatCd(String curtAdNatCd) {
		this.curtAdNatCd = curtAdNatCd;
	}
	public String getSecdNltyYn() {
		return secdNltyYn;
	}
	public void setSecdNltyYn(String secdNltyYn) {
		this.secdNltyYn = secdNltyYn;
	}
	public String getEmlAd() {
		return emlAd;
	}
	public void setEmlAd(String emlAd) {
		this.emlAd = emlAd;
	}
	public String getCurtAdDtlCtD() {
		return curtAdDtlCtD;
	}
	public void setCurtAdDtlCtD(String curtAdDtlCtD) {
		this.curtAdDtlCtD = curtAdDtlCtD;
	}
	public String getCurtAdDtlCtF() {
		return curtAdDtlCtF;
	}
	public void setCurtAdDtlCtF(String curtAdDtlCtF) {
		this.curtAdDtlCtF = curtAdDtlCtF;
	}
	public String getCurtAdNatCdNm() {
		return curtAdNatCdNm;
	}
	public void setCurtAdNatCdNm(String curtAdNatCdNm) {
		this.curtAdNatCdNm = curtAdNatCdNm;
	}
	public String getCntTelNo2() {
		return cntTelNo2;
	}
	public void setCntTelNo2(String cntTelNo2) {
		this.cntTelNo2 = cntTelNo2;
	}
	public String getfAge() {
		return fAge;
	}
	public void setfAge(String fAge) {
		this.fAge = fAge;
	}
	public String getmAge() {
		return mAge;
	}
	public void setmAge(String mAge) {
		this.mAge = mAge;
	}
	public String getgAge() {
		return gAge;
	}
	public void setgAge(String gAge) {
		this.gAge = gAge;
	}
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	public String getfEnSurnm() {
		return fEnSurnm;
	}
	public void setfEnSurnm(String fEnSurnm) {
		this.fEnSurnm = fEnSurnm;
	}
	public String getFmlyHadNm() {
		return fmlyHadNm;
	}
	public void setFmlyHadNm(String fmlyHadNm) {
		this.fmlyHadNm = fmlyHadNm;
	}
	public String getOthrRl() {
		return othrRl;
	}
	public void setOthrRl(String othrRl) {
		this.othrRl = othrRl;
	}
	public String getRlCdNm() {
		return rlCdNm;
	}
	public void setRlCdNm(String rlCdNm) {
		this.rlCdNm = rlCdNm;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getMberCn() {
		return mberCn;
	}
	public void setMberCn(String mberCn) {
		this.mberCn = mberCn;
	}
	public String getMberCnTyeCd() {
		return mberCnTyeCd;
	}
	public void setMberCnTyeCd(String mberCnTyeCd) {
		this.mberCnTyeCd = mberCnTyeCd;
	}
	public String getFthrRlCd() {
		return fthrRlCd;
	}
	public void setFthrRlCd(String fthrRlCd) {
		this.fthrRlCd = fthrRlCd;
	}
	public String getMthrRlCd() {
		return mthrRlCd;
	}
	public void setMthrRlCd(String mthrRlCd) {
		this.mthrRlCd = mthrRlCd;
	}
	public String getFthrRlCdNm() {
		return fthrRlCdNm;
	}
	public void setFthrRlCdNm(String fthrRlCdNm) {
		this.fthrRlCdNm = fthrRlCdNm;
	}
	public String getMthrRlCdNm() {
		return mthrRlCdNm;
	}
	public void setMthrRlCdNm(String mthrRlCdNm) {
		this.mthrRlCdNm = mthrRlCdNm;
	}
	public String getFmlYHadGdrCd() {
		return fmlYHadGdrCd;
	}
	public void setFmlYHadGdrCd(String fmlYHadGdrCd) {
		this.fmlYHadGdrCd = fmlYHadGdrCd;
	}		
	
}
