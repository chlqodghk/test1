package afnid.rm.bth.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.cm.util.service.NidStringUtil;
import afnid.rm.bth.service.BthVO;
import afnid.rm.rsdt.service.RsdtInfrVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Repository("bthDAO")
public class BthDAO extends EgovAbstractDAO{
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	
	
	/**
	 * DAO-method for registering information of new family book history. <br>
	 *
	 * @param vo Input item for registering new program(BthVO).
	 * @return void
	 * @exception Exception
	 */
	public BthVO selectRegLimitDd(BthVO vo) throws Exception{
		return (BthVO)selectByPk("bthDAO.selectRegLimitDd", vo);
	}
	
	/**
	 * DAO-method for registering information of new family book history. <br>
	 *
	 * @param vo Input item for registering new program(BthVO).
	 * @return void
	 * @exception Exception
	 */
	public String insertBthInfr(BthVO vo) throws Exception{
		String result = null;
		synchronized(this){
			result = (String)insert("bthDAO.insertBthInfr", vo);
		}
		return result;
	}


	/**
	 * DAO-method for retrieving Resident information of program. <br>
	 *
	 * @param vo Input item for retrieving Resident information of program(BthVO).
	 * @return BthVO Retrieve Resident information of program
	 * @exception Exception
	 */
	public BthVO selectBtnDtlAprv(BthVO vo) throws Exception{
		return (BthVO)selectByPk("bthDAO.selectBtnDtlAprv", vo);		
	}
	/**
	 * DAO-method for retrieving count Resident information of program. <br>
	 *
	 * @param vo Input item for retrieving count Resident information of program(BthVO).
	 * @return int Count of Program List
	 * @exception Exception
	 */
    public int selectListBtnAprvTotCn(BthVO vo) throws Exception{
        
    	vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
    	
    	return (Integer)selectByPk("bthDAO.selectListBtnAprvTotCn", vo);
    }
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(BthVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<BthVO> selectListBtnAprv(BthVO vo) throws Exception{		
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return list("bthDAO.selectListBtnAprv", vo);		
	}
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(BthVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateBthInfrAprv(BthVO vo){
		return update("bthDAO.updateBthInfrAprv", vo);
	}
	

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(BthVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectBthInfrCnt(BthVO vo) throws Exception{		
		
		vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		
		return list("bthDAO.selectBthInfrCnt", vo);		
	}
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(BthVO).
	 * @return EgovMap
	 * @exception Exception
	 */
	public EgovMap selectBthInfrDlt(BthVO vo) throws Exception{		
		return (EgovMap)selectByPk("bthDAO.selectBthInfrDlt", vo);		
	}
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(BthVO).
	 * @return EgovMap
	 * @exception Exception
	 */
	public EgovMap selectBthParentRsdtInfoView(BthVO vo) throws Exception{		
		return (EgovMap)selectByPk("bthDAO.selectBthParentRsdtInfoView", vo);		
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(BthVO).
	 * @return EgovMap
	 * @exception Exception
	 */
	public EgovMap selectBthParentRsdtInfrSeqView(BthVO vo) throws Exception{		
		return (EgovMap)selectByPk("bthDAO.selectBthParentRsdtInfrSeqView", vo);		
	}
	
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(BthVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListBthInfrPop(BthVO vo) throws Exception{
		return list("bthDAO.selectListBthInfrPop", vo);		
	}
	/**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(BthVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListBthInfrPopTotCnt(BthVO vo) {
        return (Integer)selectByPk("bthDAO.selectListBthInfrPopTotCnt", vo);
    }
    
    /**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(BthVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateBthInfrModify(BthVO vo){
		return update("bthDAO.updateBthInfrModify", vo);
	}
	
	
	/**
	 * DAO-method for retrieving Resident information of program. <br>
	 *
	 * @param vo Input item for retrieving Resident information of program(BthVO).
	 * @return BthVO Retrieve Resident information of program
	 * @exception Exception
	 */
	public String selectRsdtSeqNoInfr(BthVO vo) throws Exception{
		return (String)selectByPk("bthDAO.selectRsdtSeqNoInfr", vo);		
	}
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(BthVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateBthAprv(BthVO vo){
		return update("bthDAO.updateBthAprv", vo);
	}
	
	/**
	 * DAO-method for registering information of new family book history. <br>
	 *
	 * @param vo Input item for registering new program(BthVO).
	 * @return void
	 * @exception Exception
	 */
	public void updateBthInfrRsdtInfrMv(BthVO vo) throws Exception{
		insert("bthDAO.updateBthInfrRsdtInfrMv", vo);
	}
	
	/**
	 * DAO-method for registering information of new family book history. <br>
	 *
	 * @param vo Input item for registering new program(BthVO).
	 * @return void
	 * @exception Exception
	 */
	public void insertImBioTb(BthVO vo) throws Exception{
		insert("bthDAO.insertImBioTb", vo);
	}
	
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(BthVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateBthInfrRsdtInfrSgnt(BthVO vo){
		return update("bthDAO.updateBthInfrRsdtInfrSgnt", vo);
	}
	
	
	/**
	 * DAO-method for retrieving count Resident information of program. <br>
	 *
	 * @param BthVO.
	 * @return int
	 * @exception Exception
	 */
    public int selectBthCertNoOffDup(BthVO vo) throws Exception{
    	return (Integer)selectByPk("bthDAO.selectBthCertNoOffDup", vo);
    }
    
    
    
    
    /**
	 * DAO-method for registering information <br>
	 *
	 * @param vo Input item for registering new program(BthVO).
	 * @return void
	 * @exception Exception
	 */
	public void insertBthInfrRsdtInfr(BthVO vo) throws Exception{
		synchronized(this){
			insert("bthDAO.insertBthInfrRsdtInfr", vo);
		}
	}
	
	
	/**
	 * DAO-method for retrieving count Resident information of program. <br>
	 *
	 * @param BthVO.
	 * @return String
	 * @exception Exception
	 */
    public String selectBthRsdtNo(BthVO vo) throws Exception{
    	String rsdtNo = null;
    	synchronized(this){
    		rsdtNo = (String)selectByPk("bthDAO.selectBthRsdtNo", vo);
    	}
    	return rsdtNo;
    }
    
    
    
    
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(BthVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListBthInfrSpusPop(BthVO vo) throws Exception{
		return list("bthDAO.selectListBthInfrSpusPop", vo);		
	}
	/**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(BthVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListBthInfrSpusPopTotCnt(BthVO vo) {
        return (Integer)selectByPk("bthDAO.selectListBthInfrSpusPopTotCnt", vo);
    }
    
    
    
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(BthVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	public EgovMap selectBthCfmRcpt(BthVO vo) throws Exception{
		return (EgovMap)selectByPk("bthDAO.selectBthCfmRcpt", vo);
	}
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(BthVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateImBioTbInit(BthVO vo){
		return update("bthDAO.updateImBioTbInit", vo);
	}
	
	/**
	 * DAO-method for registering of program. <br>
	 * 
	 * @param BthVO
	 * @return void
	 * @exception Exception
	 */
    public void insertIfCrdIsuTb(BthVO vo) {
    	RsdtInfrVO vos = new RsdtInfrVO();
    	vos.setRsdtNo(vo.getRsdtNo());
    	vos.setCrdCd("1");
    	vos.setAplCd("1");
    	vos.setFleNm("");
    	vos.setBsnCd("3");
    	vos.setBsnSeqNo(vo.getBthSeqNo());    	
        insert("rsdtInfoDAO.insertImCrdIsuTb", vos);
    }
	
	/**
	 * DAO-method for retrieving count relationship in family book. <br>
	 * 
	 * @param vo Input item for retrieving count relationship in family book(BthVO).
	 * @return int Count of relationship in family book
	 * @exception Exception
	 */
   	public int selectMberCn(BthVO vo) {
   		return (Integer)selectByPk("bthDAO.selectMberCn", vo);
   	}    
   	
	/**
	 * DAO-method for retrieving member count type and member count in RM_RL_TB. <br>
	 * 
	 * @param vo Input item for retrieving member count type and member count in RM_RL_TB.(BthVO).
	 * @return BthVO
	 * @exception Exception
	 */
   	public BthVO searchMberCnTyeCd(BthVO vo) {
   		return (BthVO)selectByPk("bthDAO.searchMberCnTyeCd", vo);
   	}
   	
	/**
	 * DAO-method for retrieving relationship. <br>
	 *
	 * @param vo Input item for retrieving relationship(BthVO).
	 * @return BthVO Retrieve relationship
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")   	
	public List<BthVO> selectListMntrRl(BthVO vo) throws Exception{
		return list ("bthDAO.selectListMntrRl", vo);		
	}  
	
	/**
	 * DAO-method for retrieving relationship. <br>
	 *
	 * @param vo Input item for retrieving relationship(BthVO).
	 * @return BthVO Retrieve relationship
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")   	
	public List<BthVO> selectListMntrRlNull(BthVO vo) throws Exception{
		return list ("bthDAO.selectListMntrRlNull", vo);		
	}	
}
