package afnid.rm.bth.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;




public interface BthService {

   	/**
   	 * Biz-method for retrieving resident information faddBthInfror card found registration. <br>
   	 *
   	 * @param vo Input item for retrieving resident information for card found registration(BthVO).
   	 * @return CrdFndVO Retrieve resident information for card found registration
   	 * @exception Exception
   	 */    
	 BthVO searchRegLimitDd(BthVO vo) throws Exception;
	 

	/**
	 * Retrieves resident information for card found registration <br>
	 *
	 * @param vo Input item for retrieving resident information for card found registration(BthVO).
	 * @return BthVO Retrieve resident information
	 * @exception Exception
	 */	
	String addBthInfr(BthVO vo) throws Exception;
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(BthVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */	
	int searchListBtnAprvTotCn(BthVO vo) throws Exception;
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(BthVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */	
	List<BthVO> searchListBtnAprv(BthVO vo) throws Exception;
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(BthVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */	
	int modifyBthInfrAprv(BthVO vo) throws Exception;
	

	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(BthVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	List<EgovMap> searchBthInfrCnt(BthVO vo) throws Exception;
	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(BthVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	EgovMap searchBthInfrDlt(BthVO vo) throws Exception;
	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(BthVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	EgovMap searchBthParentRsdtInfoView(BthVO vo) throws Exception;
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(BthVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	EgovMap searchBthParentRsdtInfrSeqView(BthVO vo) throws Exception;
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(BthVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	List<EgovMap> searchListBthInfrPop(BthVO vo) throws Exception;
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(BthVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListBthInfrPopTotCnt(BthVO vo) throws Exception;
	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(BthVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int modifyBthInfrUdt(BthVO vo) throws Exception;
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(BthVO)
	 * @return EgovMap
	 * @exception Exception
	 */
	EgovMap aprvBthInfr(BthVO vo) throws Exception;
	
	/**
	 * Approved by the same agency in the same certificate number, make sure the material<br>
	 * @param BthVO
	 * @return int
	 * @exception Exception
	 */
	int searchBthCertNoOffDup(BthVO vo) throws Exception;
	
	
	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(BthVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	List<EgovMap> searchListBthInfrSpusPop(BthVO vo) throws Exception;
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(BthVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListBthInfrSpusPopTotCnt(BthVO vo) throws Exception;
	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(BthVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	EgovMap searchBthCfmRcpt(BthVO vo) throws Exception;
	
	/**
	 * Retrieves count relationship in family book.. <br>
	 *
	 * @param vo Input item for retrieving total count relationship in family book.(BthVO).
	 * @return count relationship in family book.
	 * @exception Exception
	 */
	int searchMberCn(BthVO vo) throws Exception;	
	
	/**
	 * Retrieves member count type and member count in RM_RL_TB. <br>
	 *
	 * @param vo Input item for retrieving member count type and member count in RM_RL_TB..(BthVO).
	 * @return BthVO
	 * @exception Exception
	 */
	BthVO searchMberCnTyeCd(BthVO vo) throws Exception;	
	
	/**
	 * Retrieves validation of relationship <br>
	 * @param vo Input item for retrieving validation of relationship
	 * @return String 
	 * @exception Exception
	 */
	public String searchChkRl(BthVO vo) throws Exception;	
		
	
}
