package afnid.rm.hst.web;

/* java API */

import java.util.List;
import javax.annotation.Resource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.hst.service.RsdtInfrHstVO;
import afnid.rm.hst.service.RsdtInfrHstService;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/** 
 * This Controller class processes request of Citizen Information History. <br>
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2014.03.25
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			    Revisions
 *   2014.03.25  		MS Kim         						Create
 *
 * </pre>
 */
@Controller
public class RsdtInfrHstController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** lgService */
	@Resource(name = "lgService")
    private LgService lgService;
	
    @Resource(name = "rsdtInfrHstService")
    private RsdtInfrHstService rsdtInfrHstService;
	
    /**
     * Moved to list-screen of citizen information view log. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrHstVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/hst/RsdtInfrHstList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/hst/searchListRsdtInfrHstView.do")   
    public String searchListRsdtInfrHstView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfrHstVO") RsdtInfrHstVO vo,
    		ModelMap model) throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/hst/RsdtInfrHstList";
    }
    
    /**
     * Retrieves list of citizen information view log <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrHstVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/hst/RsdtInfrHstList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/hst/searchListRsdtInfrHst.do")
	                       
    public String searchListRsdtInfrHst(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfrHstVO") RsdtInfrHstVO vo, ModelMap model)
            throws Exception { 
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		String certValdYn="";
    		
    		if("".equals(searchVO.getSearchKeyword6())){
        		searchVO.setSearchKeyword6("j");    			
    		}
    		
    		vo.setUseLangCd(user.getUseLangCd());	    	
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));
    		
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());
			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
	        List<RsdtInfrHstVO> lstRsdtInfrhst = rsdtInfrHstService.searchListRsdtInfrHst(vo);
	        
	        for(int i=0; i< lstRsdtInfrhst.size(); i++){
	        	RsdtInfrHstVO cert = lstRsdtInfrhst.get(i);

	        	int certResult = rsdtInfrHstService.selectCert(cert);
	        	
	       		if(certResult == 0){
	       			certValdYn = "Y";
	       		} else {
	       			certValdYn = "N";
	       		}

	        	cert.setCertValdYn(certValdYn);

	        }
	        
	        model.addAttribute("lstRsdtInfrhst", lstRsdtInfrhst);
	        
	        int totCnt = rsdtInfrHstService.searchListRsdtInfrHstTotCnt(vo);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        
	        String rsdtNm ="";
	        
	        if(totCnt > 0){
	        	RsdtInfrHstVO rsdtNmVo = lstRsdtInfrhst.get(0);
	        	rsdtNm = rsdtNmVo.getRsdtNm();
	        }
	        
	        model.addAttribute("rsdtNm", rsdtNm);
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/hst/RsdtInfrHstList";
    }
	
    /**
     * Moved to list-screen of citizen information view log. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrHstVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/hst/RsdtInfrHstList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/hst/searchRsdtInfrHst.do")   
    public String searchRsdtInfrHst(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfrHstVO") RsdtInfrHstVO vo,
    		ModelMap model) throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	    		
    		vo.setUseLangCd(user.getUseLangCd());    		
    		model.addAttribute("useLangCd", user.getUseLangCd()); 
    		
    		if("0".equals(vo.getHstSeqNo())){
    			RsdtInfrHstVO rsdtInfr = rsdtInfrHstService.searchRsdtInfrRsdtTb(vo);
    			model.addAttribute("rsdtInfrhst", rsdtInfr);
    			
    			List<RsdtInfrHstVO> othrNatLangList = rsdtInfrHstService.searchOthrNatLangListTb(vo);
    			model.addAttribute("othrNatLangListHst", othrNatLangList);
    			
    			List<RsdtInfrHstVO> frgnLangList = rsdtInfrHstService.searchFrgnLangListTb(vo);
    			model.addAttribute("frgnLangListHst", frgnLangList);
    			
    			RsdtInfrHstVO changeFlag = rsdtInfrHstService.searchRsdtHstChngFlag(vo);
    			model.addAttribute("changeFlag", changeFlag);
    			
    		} else {
    			RsdtInfrHstVO rsdtInfrhst = rsdtInfrHstService.searchRsdtInfrRsdtHstTb(vo);
    			model.addAttribute("rsdtInfrhst", rsdtInfrhst);
    			
    			List<RsdtInfrHstVO> othrNatLangListHst = rsdtInfrHstService.searchOthrNatLangListHstTb(vo);
    			model.addAttribute("othrNatLangListHst", othrNatLangListHst);
    			
    			List<RsdtInfrHstVO> frgnLangListHst = rsdtInfrHstService.searchFrgnLangListHstTb(vo);
    			model.addAttribute("frgnLangListHst", frgnLangListHst);
    			
    			RsdtInfrHstVO changeFlagHst = rsdtInfrHstService.searchRsdtHstChngFlagHst(vo);
    			model.addAttribute("changeFlag", changeFlagHst);    			
    		}

    		RsdtInfrHstVO rsdtInfrBfhst = rsdtInfrHstService.searchRsdtInfrBfRsdtHstTb(vo);  
    		model.addAttribute("rsdtInfrBfhst", rsdtInfrBfhst); 
    		
    		List<RsdtInfrHstVO> othrNatLangListBfhst = rsdtInfrHstService.searchOthrNatLangListBfHstTb(vo);
    		model.addAttribute("othrNatLangListBfhst", othrNatLangListBfhst);
    		
    		List<RsdtInfrHstVO> frgnLangListBfhst = rsdtInfrHstService.searchFrgnLangListBfHstTb(vo);
    		model.addAttribute("frgnLangListBfhst", frgnLangListBfhst);
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/hst/p_RsdtInfrHstDtl";
    }    
}