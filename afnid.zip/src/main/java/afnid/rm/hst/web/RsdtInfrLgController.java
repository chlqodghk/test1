package afnid.rm.hst.web;

/* java API */

import java.util.List;
import javax.annotation.Resource;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.hst.service.RsdtInfrLgVO;
import afnid.rm.hst.service.RsdtInfrLgService;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/** 
 * This Controller class processes request of Citizen Information View Log. <br>
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2014.03.25
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			    Revisions
 *   2014.03.25  		MS Kim         						Create
 *
 * </pre>
 */
@Controller
public class RsdtInfrLgController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** lgService */
	@Resource(name = "lgService")
    private LgService lgService;
	
    @Resource(name = "rsdtInfrLgService")
    private RsdtInfrLgService rsdtInfrLgService;
	
    /**
     * Moved to list-screen of citizen information view log. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrLgVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/hst/RsdtInfrLgList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/hst/searchListRsdtInfrLgView.do")   
    public String searchListRsdtInfrLgView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfrLgVO") RsdtInfrLgVO vo,
    		ModelMap model) throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/hst/RsdtInfrLgList";
    }
    
    /**
     * Retrieves list of citizen information view log <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrLgVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/hst/RsdtInfrLgList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/hst/searchListRsdtInfrLg.do")
	                       
    public String searchListRsdtInfrLg(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfrLgVO") RsdtInfrLgVO vo,
    		ModelMap model)
            throws Exception { 
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		String rsdtNm ="";
    		if("".equals(searchVO.getSearchKeyword6())){
        		searchVO.setSearchKeyword6("j");    			
    		}

    		vo.setUseLangCd(user.getUseLangCd());	    	
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));
    		
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());
			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
	        List<RsdtInfrLgVO> lstRsdtInfrLg = rsdtInfrLgService.searchListRsdtInfrLg(vo);
	        model.addAttribute("lstRsdtInfrLg", lstRsdtInfrLg);
	        
	        int totCnt = rsdtInfrLgService.searchListRsdtInfrLgTotCnt(vo);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        
	        if(totCnt > 0){
	        	RsdtInfrLgVO rsdtNmVo = lstRsdtInfrLg.get(0);
	        	rsdtNm = rsdtNmVo.getRsdtNm();
	        }
	        
	        model.addAttribute("rsdtNm", rsdtNm);
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/hst/RsdtInfrLgList";
    }
	
    
}