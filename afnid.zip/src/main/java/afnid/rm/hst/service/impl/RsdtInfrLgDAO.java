
package afnid.rm.hst.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.springframework.stereotype.Repository;
import afnid.rm.hst.service.RsdtInfrLgVO;

import com.ibatis.sqlmap.client.SqlMapClient;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;


/** 
 * This class is Database Access Object of Citizen Information View Log
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2014.03.25
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			    Revisions
 *   2014.03.25  		MS Kim         						Create
 *
 * </pre>
 */

@Repository("rsdtInfrLgDAO")
public class RsdtInfrLgDAO extends EgovAbstractDAO {
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }

    
	/**
	 * DAO-method for retrieving list of citizen information view log.<br>
	 * 
	 * @param vo Input item for retrieving list of citizen information view log(RsdtInfrLgVO).
	 * @return List Retrieve list of citizen information view log
	 * @exception Exception 
	 */		
	@SuppressWarnings("unchecked")
	public List<RsdtInfrLgVO> selectListRsdtInfrLg(RsdtInfrLgVO vo) throws Exception{
		return list("rsdtInfrLgDAO.selectListRsdtInfrLg", vo);
	}
	
	/**
	 * DAO-method for retrieving total count of citizen information view log. <br>
	 * 
	 * @param vo Input item for retrieving list of citizen information view log(RsdtInfrLgVO).
	 * @return int Total Count of citizen information view log
	 * @exception Exception 
	 */
    public int selectListRsdtInfrLgTotCnt(RsdtInfrLgVO vo) {
        return (Integer)selectByPk("rsdtInfrLgDAO.selectListRsdtInfrLgTotCnt", vo);
    }
 
	/**
	 * DAO-method for registration of citizen information view log <br>
	 * 
	 * @param vo Input item for registration of citizen information view log(RsdtInfrLgVO).
	 * @return 
	 * @exception Exception
	 */
	public void insertRsdtInfrLg(RsdtInfrLgVO vo ) throws Exception{
		insert("rsdtInfrLgDAO.insertRsdtInfrLg",vo);
	}
	
	
}
