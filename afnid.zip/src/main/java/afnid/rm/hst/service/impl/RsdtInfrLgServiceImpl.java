package afnid.rm.hst.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.hst.service.RsdtInfrLgService;
import afnid.rm.hst.service.RsdtInfrLgVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;

/** 
 * This service class is biz-class of Citizen Information View Log
 * and implements FmlyInfoService class.
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2014.03.25
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			    Revisions
 *   2014.03.25  		MS Kim         						Create
 *
 * </pre>
 */

@Service("rsdtInfrLgService")
public class RsdtInfrLgServiceImpl extends AbstractServiceImpl implements RsdtInfrLgService {
	
	/** RsdtInfrLgDAO */
    @Resource(name="rsdtInfrLgDAO")
    private RsdtInfrLgDAO dao;
    
    /**
	 * Biz-method for retrieving list of citizen information view log. <br>
	 * 
	 * @param vo Input item for retrieving list of citizen information view log(RsdtInfrLgVO).
	 * @return List Retrieve list of citizen information view log
	 * @exception Exception
	 */
	public List<RsdtInfrLgVO> searchListRsdtInfrLg(RsdtInfrLgVO vo) throws Exception {
   		return dao.selectListRsdtInfrLg(vo);
	}
	
	/**
	 * Biz-method for retrieving total count list of citizen information view log. <br>
	 * 
	 * @param vo Input item for retrieving total count of citizen information view log(RsdtInfrLgVO).
	 * @return int Total Count of citizen information view log
	 * @exception Exception
	 */
    public int searchListRsdtInfrLgTotCnt(RsdtInfrLgVO vo) throws Exception {
        return dao.selectListRsdtInfrLgTotCnt(vo);
	}
    
    /**
	 * Biz-method for registration of program. <br>
	 * 
	 * @param vo Input item for registration of citizen information view log(RsdtInfrLgVO).
	 * @return 
	 * @exception Exception
	 */
    public void addRsdtInfrLg(String rsdtNo, String bsnCd) throws Exception{
    	RsdtInfrLgVO vo = new RsdtInfrLgVO();
    	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    	
    	vo.setOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
    	vo.setUserId(user.getUserId());
    	vo.setRsdtNo(rsdtNo);
    	vo.setBsnCd(bsnCd);
	    dao.insertRsdtInfrLg(vo);	
    }
    
}