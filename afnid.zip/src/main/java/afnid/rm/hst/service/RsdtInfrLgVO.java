/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package afnid.rm.hst.service;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of Citizen Information View Log
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2014.03.25
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			    Revisions
 *   2014.03.25  		MS Kim         						Create
 *
 * </pre>
 */

public class RsdtInfrLgVO extends ComDefaultVO {
	
    private static final long serialVersionUID = 1L;

    private String seqNo;
    private String rsdtNo;
    private String orgnzNm;
    private String orgnzCd;
    private String ddttm;
    private String nm;
    private String userId;
    
    private String hDdttm;    
    private String gDdttm;
    private String calTye;
    private String bsnCd;
    private String bsnCdNm;
    private String rsdtNoDp;
    private String rsdtNm;
    
	public String getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getOrgnzNm() {
		return orgnzNm;
	}
	public void setOrgnzNm(String orgnzNm) {
		this.orgnzNm = orgnzNm;
	}	
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String getDdttm() {
		return ddttm;
	}
	public void setDdttm(String ddttm) {
		this.ddttm = ddttm;
	}
	public String getNm() {
		return nm;
	}
	public void setNm(String nm) {
		this.nm = nm;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String gethDdttm() {
		return hDdttm;
	}
	public void sethDdttm(String hDdttm) {
		this.hDdttm = hDdttm;
	}
	public String getgDdttm() {
		return gDdttm;
	}
	public void setgDdttm(String gDdttm) {
		this.gDdttm = gDdttm;
	}
	public String getCalTye() {
		return calTye;
	}
	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}
	public String getBsnCd() {
		return bsnCd;
	}
	public void setBsnCd(String bsnCd) {
		this.bsnCd = bsnCd;
	}
	public String getBsnCdNm() {
		return bsnCdNm;
	}
	public void setBsnCdNm(String bsnCdNm) {
		this.bsnCdNm = bsnCdNm;
	}
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	public String getRsdtNm() {
		return rsdtNm;
	}
	public void setRsdtNm(String rsdtNm) {
		this.rsdtNm = rsdtNm;
	}

}