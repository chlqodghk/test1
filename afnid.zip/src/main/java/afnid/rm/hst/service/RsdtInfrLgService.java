
package afnid.rm.hst.service;

import java.util.List;


/** 
 * This service interface is biz-class of Citizen Information View Log. <br>
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2014.03.25
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			    Revisions
 *   2014.03.25  		MS Kim         						Create
 *
 * </pre>
 */

public interface RsdtInfrLgService {
	
	/**
	 * Retrieves list of citizen information view log. <br>
	 * 
	 * @param vo Input item for retrieving list of citizen information view log(RsdtInfrLgVO).
	 * @return List Retrieve list of citizen information view log
	 * @exception Exception
	 */
	List<RsdtInfrLgVO> searchListRsdtInfrLg(RsdtInfrLgVO vo) throws Exception;
	
	/**
	 * Retrieves total count of citizen information view log. <br>
	 * @param vo Input item for retrieving total count list of citizen information view log.(RsdtInfrLgVO)
	 * @return int Total Count of citizen information view log
	 * @exception Exception
	 */
	int searchListRsdtInfrLgTotCnt(RsdtInfrLgVO vo) throws Exception;
	
	
	/**
	 * Registration of citizen information view log. <br>
	 * @param vo Input item for registration of citizen information view log.(RsdtInfrLgVO)
	 * @return 
	 * @exception Exception
	 */
	void addRsdtInfrLg(String rsdtNo, String bsnCd) throws Exception;
	
	
}
