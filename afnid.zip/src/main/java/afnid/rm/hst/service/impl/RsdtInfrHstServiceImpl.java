package afnid.rm.hst.service.impl;

import java.util.List;
import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import si.osi.dsig.XMLDsigValidate;

import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.hst.service.RsdtInfrHstService;
import afnid.rm.hst.service.RsdtInfrHstVO;
import afnid.rm.hst.service.RsdtInfrLgService;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of Citizen Information History
 * and implements FmlyInfoService class.
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2014.03.25
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			    Revisions
 *   2014.03.25  		MS Kim         						Create
 *
 * </pre>
 */

@Service("rsdtInfrHstService")
public class RsdtInfrHstServiceImpl extends AbstractServiceImpl implements RsdtInfrHstService {
	
	/** RsdtInfrHstDAO */
    @Resource(name="rsdtInfrHstDAO")
    private RsdtInfrHstDAO dao;
    
    @Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtInfrDAO;
    
    /** logDAO */
    @Resource(name="lgDAO")
    private LgDAO lgDAO;
    
    @Resource(name = "rsdtInfrLgService")
    private RsdtInfrLgService rsdtInfrLgService;
    
    /**
	 * Biz-method for retrieving list of citizen information history. <br>
	 * 
	 * @param vo Input item for retrieving list of citizen information history(RsdtInfrHstVO).
	 * @return List Retrieve list of citizen information history
	 * @exception Exception
	 */
	public List<RsdtInfrHstVO> searchListRsdtInfrHst(RsdtInfrHstVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		
		List<RsdtInfrHstVO> lstRsdtInfrhst = dao.selectListRsdtInfrHst(vo);
		
        for(int i=0; i< lstRsdtInfrhst.size(); i++){
        	RsdtInfrHstVO lst = lstRsdtInfrhst.get(i);        	
    		String lgSeqNo = lgDAO.insertPubKeyIfLg(user.getUserId(), lst.getRsdtNo(), "19", "1", "16", "");	        	
    		lst.setLgSeqNo(lgSeqNo);
        	lstRsdtInfrhst.set(i, lst);
        }        		
		
   		return lstRsdtInfrhst;
	}
	
	/**
	 * Biz-method for retrieving total count list of citizen information history. <br>
	 * 
	 * @param vo Input item for retrieving total count of citizen information history(RsdtInfrHstVO).
	 * @return int Total Count of citizen information history
	 * @exception Exception
	 */
    public int searchListRsdtInfrHstTotCnt(RsdtInfrHstVO vo) throws Exception {
        return dao.selectListRsdtInfrHstTotCnt(vo);
	}

    /**
	 * Biz-method for retrieving citizen information history. <br>
	 * 
	 * @param vo Input item for retrieving citizen information history(RsdtInfrHstVO).
	 * @return  citizen information history
	 * @exception Exception
	 */
	public RsdtInfrHstVO searchRsdtInfrRsdtTb(RsdtInfrHstVO vo) throws Exception {
		rsdtInfrLgService.addRsdtInfrLg(vo.getRsdtNo(),"16");
   		return dao.selectRsdtInfrRsdtTb(vo);
	}    
	
    /**
	 * Biz-method for retrieving citizen information history. <br>
	 * 
	 * @param vo Input item for retrieving citizen information history(RsdtInfrHstVO).
	 * @return  citizen information history
	 * @exception Exception
	 */
	public RsdtInfrHstVO searchRsdtInfrRsdtHstTb(RsdtInfrHstVO vo) throws Exception {
		rsdtInfrLgService.addRsdtInfrLg(vo.getRsdtNo(),"16");
   		return dao.selectRsdtInfrRsdtHstTb(vo);
	} 	
	
    /**
	 * Biz-method for retrieving citizen information history. <br>
	 * 
	 * @param vo Input item for retrieving citizen information history(RsdtInfrHstVO).
	 * @return  citizen information history
	 * @exception Exception
	 */
	public RsdtInfrHstVO searchRsdtInfrBfRsdtHstTb(RsdtInfrHstVO vo) throws Exception {
   		return dao.selectRsdtInfrBfRsdtHstTb(vo);
	} 	
	
    /**
	 * Biz-method for retrieving value of signature comparison. <br>
	 * 
	 * @param vo Input item for retrieving value of signature comparison(RsdtInfrHstVO).
	 * @return  String value of signature comparison
	 * @exception Exception
	 */
	public int selectCert(RsdtInfrHstVO vo) throws Exception {

		String erorYn ="Y";
		
		int  certResult = -1;
		EgovMap em = null;

		StringBuffer sb = new StringBuffer();
		
		//data select
		if ("1".equals(vo.getTbDiv())){
			em  = rsdtInfrDAO.selectRsdtInfrDat(vo.getRsdtSeqNo());
		}else {
			em  = rsdtInfrDAO.selectRsdtHstInfrDat(vo.getRsdtSeqNo(), vo.getHstSeqNo());	
		}
		
		String sysSgnt = vo.getSysSgnt();
		String rmData = rsdtInfrDAO.setRsdtInfrHashDat(em);
	
		String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
		sb.append(reg);
		sb.append("<root>");
		sb.append("\r\n<RMDSigData><![CDATA[");
		sb.append(rmData);
		sb.append("]]></RMDSigData>\r\n");
		sb.append(sysSgnt);
		sb.append("</root>");

		byte [] array = new byte[sb.toString().length()];			
		array = sb.toString().getBytes();

		certResult = XMLDsigValidate.spkiIFDigitalSignatureValidation(array);
		log.debug("========================================================================" );
		log.debug("server certResult ===============> :  " + certResult);
		log.debug("========================================================================" );
		
		/*
		String sgnt    = vo.getSgnt();
		String oficData = vo.getUserId()+vo.getRsdtSeqNo()+vo.getUptWrkCd()+vo.getTrstId();
		StringBuffer sb1 = new StringBuffer();	
		
		log.debug("========================================================================" );
		log.debug("sgnt ===============> :  " + sgnt);
		log.debug("========================================================================" );
		
		log.debug("========================================================================" );
		log.debug("oficData ===============> :  " + oficData);
		log.debug("========================================================================" );
		
		sb1.append(reg);
		sb1.append("<root>");
		sb1.append("\r\n<trxID>");
		sb1.append(oficData);
		sb1.append("</trxID>\r\n");
		sb1.append(sgnt);
		sb1.append("</root>");
		
		byte [] array1 = new byte[sb1.toString().length()];
		
		array1 = sb1.toString().getBytes();

		log.debug("========================================================================" );
		log.debug("sb1 ===============> :  " + sb1.toString());
		log.debug("========================================================================" );
		
		certResult = XMLDsigValidate.spkiOfficerDSigValidation(array1);
		log.debug("========================================================================" );
		log.debug("officer certResult ===============> :  " + certResult);
		log.debug("========================================================================" );			
		*/
		
   		if(certResult == 0){
   			erorYn ="N";
   		}

   		lgDAO.updatePubKeyIfLg(vo.getLgSeqNo(), String.valueOf(certResult), erorYn);
   		
		return certResult;
	}
	
	
    /**
	 * Biz-method for retrieving list of other national language. <br>
	 *
	 * @param vo Input item for retrieving list of other national language(RsdtInfrHstVO).
	 * @return List Retrieve list of other national language
	 * @exception Exception
	 */
	public List<RsdtInfrHstVO> searchOthrNatLangListTb(RsdtInfrHstVO vo) throws Exception {
   		return dao.selectOthrNatLangListTb(vo);
	}
	
    /**
	 * Biz-method for retrieving list of foreign language. <br>
	 *
	 * @param vo Input item for retrieving list of foreign language(RsdtInfrHstVO).
	 * @return List Retrieve list of foreign language
	 * @exception Exception
	 */
	public List<RsdtInfrHstVO> searchFrgnLangListTb(RsdtInfrHstVO vo) throws Exception {
   		return dao.selectFrgnLangListTb(vo);
	}
	
    /**
	 * Biz-method for retrieving list of other national language. <br>
	 *
	 * @param vo Input item for retrieving list of other national language(RsdtInfrHstVO).
	 * @return List Retrieve list of other national language
	 * @exception Exception
	 */
	public List<RsdtInfrHstVO> searchOthrNatLangListHstTb(RsdtInfrHstVO vo) throws Exception {
   		return dao.selectOthrNatLangListHstTb(vo);
	}
	
    /**
	 * Biz-method for retrieving list of foreign language. <br>
	 *
	 * @param vo Input item for retrieving list of foreign language(RsdtInfrHstVO).
	 * @return List Retrieve list of foreign language
	 * @exception Exception
	 */
	public List<RsdtInfrHstVO> searchFrgnLangListHstTb(RsdtInfrHstVO vo) throws Exception {
   		return dao.selectFrgnLangListHstTb(vo);
	}
	
    /**
	 * Biz-method for retrieving list of other national language. <br>
	 *
	 * @param vo Input item for retrieving list of other national language(RsdtInfrHstVO).
	 * @return List Retrieve list of other national language
	 * @exception Exception
	 */
	public List<RsdtInfrHstVO> searchOthrNatLangListBfHstTb(RsdtInfrHstVO vo) throws Exception {
   		return dao.selectOthrNatLangListBfHstTb(vo);
	}
	
    /**
	 * Biz-method for retrieving list of foreign language. <br>
	 *
	 * @param vo Input item for retrieving list of foreign language(RsdtInfrHstVO).
	 * @return List Retrieve list of foreign language
	 * @exception Exception
	 */
	public List<RsdtInfrHstVO> searchFrgnLangListBfHstTb(RsdtInfrHstVO vo) throws Exception {
   		return dao.selectFrgnLangListBfHstTb(vo);
	}	
	
    /**
	 * Biz-method for retrieving  Field Value Change Y/N(other national language, foreign language). <br>
	 * 
	 * @param vo Input item for retrieving  Field Value Change Y/N(RsdtInfrHstVO).
	 * @return  Field Value Change Y/N(
	 * @exception Exception
	 */
	public RsdtInfrHstVO searchRsdtHstChngFlag(RsdtInfrHstVO vo) throws Exception {
   		return dao.selectRsdtHstChngFlag(vo);
	} 
	
    /**
	 * Biz-method for retrieving  Field Value Change Y/N(other national language, foreign language). <br>
	 * 
	 * @param vo Input item for retrieving  Field Value Change Y/N(RsdtInfrHstVO).
	 * @return  Field Value Change Y/N(
	 * @exception Exception
	 */
	public RsdtInfrHstVO searchRsdtHstChngFlagHst(RsdtInfrHstVO vo) throws Exception {
   		return dao.selectRsdtHstChngFlagHst(vo);
	} 	
	
}