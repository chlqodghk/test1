/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package afnid.rm.hst.service;

import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of board information
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2014.03.25
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			    Revisions
 *   2014.03.25  		MS Kim         						Create
 *
 * </pre>
 */

public class RsdtInfrHstVO extends ComDefaultVO {
	
    private static final long serialVersionUID = 1L;

    private String rsdtSeqNo;
    private String hstSeqNo;    
    private String seqNo;
    private String rsdtNo;
    private String orgnzNm;
    private String orgnzCd;
    private String ddttm;
    private String nm;
    private String userId;
    private String udtWrkNm;   
    
    private String fmlyBokNoNum;
    private String fmlyBokNo;
    private String fmlyMberNo;
    private String oldCrdNo;
    private String oldCrdIsucePlceNm;
    private String oldCrdIsuceDd;
    private String rsdtNoDp;
    private String rlCdNm;
    private String givNm;
    private String surnm;
    private String enNm;
    private String fthrNm;
    private String mthrNm;
    private String gfthrNm;
    private String bthDd;
    private String bthPlceCdNm;
    private String bthNatDiv;
    private String bthNatCdNm;
    private String frgnBthCtyNm;
    private String pmntAdCdNm;
    private String pmntAdDtlCt;
    private String curtAdCdNm;
    private String curtAdDtlCt;
    private String bldTyeCdNm;
    private String mrrgCdNm;
    private String gdrCdNm;
    private String encyCdNm;
    private String fmlyLangCdNm;
    private String secdNltyCdNm;
    private String dsbtDtlCt;
    private String ocp;
    private String rlgnCdNm;
    private String rlgnSectCdNm;
    private String eduCdNm;
    private String mltSrvcCdNm;
    private String smrRsdcCdNm;
    private String wtrRsdcCdNm;
    private String fmlyMberMlNo;
    private String fmlyMberFemlNo;
    private String crdIsucePlceCdNm;
    private String crdIsuLangCd;
    private String crdIsuceDd;
    private String crdExpiryDd;
    private String crdIsuDueDd;
    private String crdStusCdNm;
    private String calTye;
    private String adChngYn;
    private String fmlyHadYn;
    private String fmlyHadRsdtNo;
    private String rsdtTyeCd;
    private String rsdtTyeCdNm;
    private String rsdtRgstYn;
    private String rsdtStusCdNm;
    private String bioKey;
    private String bioRgstDd;
    private String poliCntrSeqNoNm;
    private String ersrCd;
    private String ersrCdNm;
    private String rsdtRgstDd;
    private String rsdtRgstId;
    private String rsdtRgstIdNm;
    private String tamLedrCfmYn;
    private String cfmTamLedrId;
    private String cfmTamLedrIdNm;
    private String useYn;
    private String lstUdtUserId;
    private String lstUdtUserIdNm;
    private String fstVefyIndiNm;
    private String fstVefyTye;
    private String fstVefyRsdtNo;
    private String secdVefyIndiNm;
    private String secdVefyTye;
    private String secdVefyRsdtNo;
    private String mberRgstId;
    private String mberRgstIdNm;
    
    private String enSurnm;
    private String enGivNm;

    private String gfthrRsdtSeqNo;
    private String spusRsdtSeqNo;
    private String spusNm;
    private String dsbtCd;
    private String dsbtCdNm;
    private String frngrYn;

    private String afSpusEnSurnm;
    private String spusEnSurnm;
    private String spusEnGivNm;


    private String fthrRgstTye;
    private String mthrRgstTye;
    private String gfthrRgstTye;
    private String spusRgstTye;
    private String fthrOldCrdNo;
    private String mthrOldCrdNo;
    private String gfthrOldCrdNo;
    private String spusOldCrdNo;
    private String rsdtCfmYn;
    private String bldTyeDocYn;
    private String eduLvDocYn;    
    
    private String oldCrdNo1;
    private String oldCrdNo2;
    private String oldCrdNo3;
    private String oldCrdNo4;
    
    private String hDdttm;
    private String gDdttm;
    
    private String fstVefyOldCrdNo1;
    private String fstVefyOldCrdNo2;
    private String fstVefyOldCrdNo3;
    private String fstVefyOldCrdNo4;
    
    private String secdVefyOldCrdNo1;
    private String secdVefyOldCrdNo2;
    private String secdVefyOldCrdNo3;
    private String secdVefyOldCrdNo4;
    private String sgnt;
    private String sysSgnt;
    private String certValdYn;
    private String tbDiv;
    private String trstId;
    private String uptWrkCd;
    private String lgSeqNo;
    private String rsdtNm;
    private String cntTelNo;
    private String cntTelNo2;
    private String emlAd;

    private String natLangCdNm;    
    private String frgnLangCdNm;
    private String natLangCd;
    private String frgnLangCd;
    private String othrCount;
    private String frgnCount;
    
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getHstSeqNo() {
		return hstSeqNo;
	}
	public void setHstSeqNo(String hstSeqNo) {
		this.hstSeqNo = hstSeqNo;
	}
	public String getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getOrgnzNm() {
		return orgnzNm;
	}
	public void setOrgnzNm(String orgnzNm) {
		this.orgnzNm = orgnzNm;
	}
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String getDdttm() {
		return ddttm;
	}
	public void setDdttm(String ddttm) {
		this.ddttm = ddttm;
	}
	public String getNm() {
		return nm;
	}
	public void setNm(String nm) {
		this.nm = nm;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUdtWrkNm() {
		return udtWrkNm;
	}
	public void setUdtWrkNm(String udtWrkNm) {
		this.udtWrkNm = udtWrkNm;
	}
	public String getFmlyBokNoNum() {
		return fmlyBokNoNum;
	}
	public void setFmlyBokNoNum(String fmlyBokNoNum) {
		this.fmlyBokNoNum = fmlyBokNoNum;
	}
	public String getFmlyBokNo() {
		return fmlyBokNo;
	}
	public void setFmlyBokNo(String fmlyBokNo) {
		this.fmlyBokNo = fmlyBokNo;
	}
	public String getFmlyMberNo() {
		return fmlyMberNo;
	}
	public void setFmlyMberNo(String fmlyMberNo) {
		this.fmlyMberNo = fmlyMberNo;
	}
	public String getOldCrdNo() {
		return oldCrdNo;
	}
	public void setOldCrdNo(String oldCrdNo) {
		this.oldCrdNo = oldCrdNo;
	}
	public String getOldCrdIsucePlceNm() {
		return oldCrdIsucePlceNm;
	}
	public void setOldCrdIsucePlceNm(String oldCrdIsucePlceNm) {
		this.oldCrdIsucePlceNm = oldCrdIsucePlceNm;
	}
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	public String getRlCdNm() {
		return rlCdNm;
	}
	public void setRlCdNm(String rlCdNm) {
		this.rlCdNm = rlCdNm;
	}
	public String getGivNm() {
		return givNm;
	}
	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}
	public String getSurnm() {
		return surnm;
	}
	public void setSurnm(String surnm) {
		this.surnm = surnm;
	}
	public String getEnNm() {
		return enNm;
	}
	public void setEnNm(String enNm) {
		this.enNm = enNm;
	}
	public String getFthrNm() {
		return fthrNm;
	}
	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}
	public String getMthrNm() {
		return mthrNm;
	}
	public void setMthrNm(String mthrNm) {
		this.mthrNm = mthrNm;
	}
	public String getGfthrNm() {
		return gfthrNm;
	}
	public void setGfthrNm(String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}
	public String getBthDd() {
		return bthDd;
	}
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	public String getBthPlceCdNm() {
		return bthPlceCdNm;
	}
	public void setBthPlceCdNm(String bthPlceCdNm) {
		this.bthPlceCdNm = bthPlceCdNm;
	}
	public String getBthNatDiv() {
		return bthNatDiv;
	}
	public void setBthNatDiv(String bthNatDiv) {
		this.bthNatDiv = bthNatDiv;
	}
	public String getBthNatCdNm() {
		return bthNatCdNm;
	}
	public void setBthNatCdNm(String bthNatCdNm) {
		this.bthNatCdNm = bthNatCdNm;
	}
	public String getFrgnBthCtyNm() {
		return frgnBthCtyNm;
	}
	public void setFrgnBthCtyNm(String frgnBthCtyNm) {
		this.frgnBthCtyNm = frgnBthCtyNm;
	}
	public String getPmntAdCdNm() {
		return pmntAdCdNm;
	}
	public void setPmntAdCdNm(String pmntAdCdNm) {
		this.pmntAdCdNm = pmntAdCdNm;
	}
	public String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}
	public void setPmntAdDtlCt(String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}
	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}
	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}
	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}
	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}
	public String getBldTyeCdNm() {
		return bldTyeCdNm;
	}
	public void setBldTyeCdNm(String bldTyeCdNm) {
		this.bldTyeCdNm = bldTyeCdNm;
	}
	public String getMrrgCdNm() {
		return mrrgCdNm;
	}
	public void setMrrgCdNm(String mrrgCdNm) {
		this.mrrgCdNm = mrrgCdNm;
	}
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	public String getEncyCdNm() {
		return encyCdNm;
	}
	public void setEncyCdNm(String encyCdNm) {
		this.encyCdNm = encyCdNm;
	}
	public String getFmlyLangCdNm() {
		return fmlyLangCdNm;
	}
	public void setFmlyLangCdNm(String fmlyLangCdNm) {
		this.fmlyLangCdNm = fmlyLangCdNm;
	}
	public String getSecdNltyCdNm() {
		return secdNltyCdNm;
	}
	public void setSecdNltyCdNm(String secdNltyCdNm) {
		this.secdNltyCdNm = secdNltyCdNm;
	}
	public String getDsbtDtlCt() {
		return dsbtDtlCt;
	}
	public void setDsbtDtlCt(String dsbtDtlCt) {
		this.dsbtDtlCt = dsbtDtlCt;
	}
	public String getOcp() {
		return ocp;
	}
	public void setOcp(String ocp) {
		this.ocp = ocp;
	}
	public String getRlgnCdNm() {
		return rlgnCdNm;
	}
	public void setRlgnCdNm(String rlgnCdNm) {
		this.rlgnCdNm = rlgnCdNm;
	}
	public String getRlgnSectCdNm() {
		return rlgnSectCdNm;
	}
	public void setRlgnSectCdNm(String rlgnSectCdNm) {
		this.rlgnSectCdNm = rlgnSectCdNm;
	}
	public String getEduCdNm() {
		return eduCdNm;
	}
	public void setEduCdNm(String eduCdNm) {
		this.eduCdNm = eduCdNm;
	}
	public String getMltSrvcCdNm() {
		return mltSrvcCdNm;
	}
	public void setMltSrvcCdNm(String mltSrvcCdNm) {
		this.mltSrvcCdNm = mltSrvcCdNm;
	}
	public String getSmrRsdcCdNm() {
		return smrRsdcCdNm;
	}
	public void setSmrRsdcCdNm(String smrRsdcCdNm) {
		this.smrRsdcCdNm = smrRsdcCdNm;
	}
	public String getWtrRsdcCdNm() {
		return wtrRsdcCdNm;
	}
	public void setWtrRsdcCdNm(String wtrRsdcCdNm) {
		this.wtrRsdcCdNm = wtrRsdcCdNm;
	}
	public String getFmlyMberMlNo() {
		return fmlyMberMlNo;
	}
	public void setFmlyMberMlNo(String fmlyMberMlNo) {
		this.fmlyMberMlNo = fmlyMberMlNo;
	}
	public String getFmlyMberFemlNo() {
		return fmlyMberFemlNo;
	}
	public void setFmlyMberFemlNo(String fmlyMberFemlNo) {
		this.fmlyMberFemlNo = fmlyMberFemlNo;
	}
	public String getCrdIsucePlceCdNm() {
		return crdIsucePlceCdNm;
	}
	public void setCrdIsucePlceCdNm(String crdIsucePlceCdNm) {
		this.crdIsucePlceCdNm = crdIsucePlceCdNm;
	}
	public String getCrdIsuLangCd() {
		return crdIsuLangCd;
	}
	public void setCrdIsuLangCd(String crdIsuLangCd) {
		this.crdIsuLangCd = crdIsuLangCd;
	}
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}
	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}
	public String getCrdIsuDueDd() {
		return crdIsuDueDd;
	}
	public void setCrdIsuDueDd(String crdIsuDueDd) {
		this.crdIsuDueDd = crdIsuDueDd;
	}
	public String getCrdStusCdNm() {
		return crdStusCdNm;
	}
	public void setCrdStusCdNm(String crdStusCdNm) {
		this.crdStusCdNm = crdStusCdNm;
	}
	public String getCalTye() {
		return calTye;
	}
	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}
	public String getAdChngYn() {
		return adChngYn;
	}
	public void setAdChngYn(String adChngYn) {
		this.adChngYn = adChngYn;
	}
	public String getFmlyHadYn() {
		return fmlyHadYn;
	}
	public void setFmlyHadYn(String fmlyHadYn) {
		this.fmlyHadYn = fmlyHadYn;
	}
	public String getFmlyHadRsdtNo() {
		return fmlyHadRsdtNo;
	}
	public void setFmlyHadRsdtNo(String fmlyHadRsdtNo) {
		this.fmlyHadRsdtNo = fmlyHadRsdtNo;
	}
	public String getRsdtTyeCd() {
		return rsdtTyeCd;
	}
	public void setRsdtTyeCd(String rsdtTyeCd) {
		this.rsdtTyeCd = rsdtTyeCd;
	}
	public String getRsdtTyeCdNm() {
		return rsdtTyeCdNm;
	}
	public void setRsdtTyeCdNm(String rsdtTyeCdNm) {
		this.rsdtTyeCdNm = rsdtTyeCdNm;
	}
	public String getRsdtRgstYn() {
		return rsdtRgstYn;
	}
	public void setRsdtRgstYn(String rsdtRgstYn) {
		this.rsdtRgstYn = rsdtRgstYn;
	}
	public String getRsdtStusCdNm() {
		return rsdtStusCdNm;
	}
	public void setRsdtStusCdNm(String rsdtStusCdNm) {
		this.rsdtStusCdNm = rsdtStusCdNm;
	}
	public String getBioKey() {
		return bioKey;
	}
	public void setBioKey(String bioKey) {
		this.bioKey = bioKey;
	}
	public String getBioRgstDd() {
		return bioRgstDd;
	}
	public void setBioRgstDd(String bioRgstDd) {
		this.bioRgstDd = bioRgstDd;
	}
	public String getPoliCntrSeqNoNm() {
		return poliCntrSeqNoNm;
	}
	public void setPoliCntrSeqNoNm(String poliCntrSeqNoNm) {
		this.poliCntrSeqNoNm = poliCntrSeqNoNm;
	}
	public String getErsrCd() {
		return ersrCd;
	}
	public void setErsrCd(String ersrCd) {
		this.ersrCd = ersrCd;
	}
	public String getRsdtRgstDd() {
		return rsdtRgstDd;
	}
	public void setRsdtRgstDd(String rsdtRgstDd) {
		this.rsdtRgstDd = rsdtRgstDd;
	}
	public String getRsdtRgstId() {
		return rsdtRgstId;
	}
	public void setRsdtRgstId(String rsdtRgstId) {
		this.rsdtRgstId = rsdtRgstId;
	}
	public String getRsdtRgstIdNm() {
		return rsdtRgstIdNm;
	}
	public void setRsdtRgstIdNm(String rsdtRgstIdNm) {
		this.rsdtRgstIdNm = rsdtRgstIdNm;
	}
	public String getTamLedrCfmYn() {
		return tamLedrCfmYn;
	}
	public void setTamLedrCfmYn(String tamLedrCfmYn) {
		this.tamLedrCfmYn = tamLedrCfmYn;
	}
	public String getCfmTamLedrId() {
		return cfmTamLedrId;
	}
	public void setCfmTamLedrId(String cfmTamLedrId) {
		this.cfmTamLedrId = cfmTamLedrId;
	}
	public String getCfmTamLedrIdNm() {
		return cfmTamLedrIdNm;
	}
	public void setCfmTamLedrIdNm(String cfmTamLedrIdNm) {
		this.cfmTamLedrIdNm = cfmTamLedrIdNm;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getLstUdtUserId() {
		return lstUdtUserId;
	}
	public void setLstUdtUserId(String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}
	public String getLstUdtUserIdNm() {
		return lstUdtUserIdNm;
	}
	public void setLstUdtUserIdNm(String lstUdtUserIdNm) {
		this.lstUdtUserIdNm = lstUdtUserIdNm;
	}
	public String getFstVefyIndiNm() {
		return fstVefyIndiNm;
	}
	public void setFstVefyIndiNm(String fstVefyIndiNm) {
		this.fstVefyIndiNm = fstVefyIndiNm;
	}
	public String getFstVefyTye() {
		return fstVefyTye;
	}
	public void setFstVefyTye(String fstVefyTye) {
		this.fstVefyTye = fstVefyTye;
	}
	public String getFstVefyRsdtNo() {
		return fstVefyRsdtNo;
	}
	public void setFstVefyRsdtNo(String fstVefyRsdtNo) {
		this.fstVefyRsdtNo = fstVefyRsdtNo;
	}
	public String getSecdVefyIndiNm() {
		return secdVefyIndiNm;
	}
	public void setSecdVefyIndiNm(String secdVefyIndiNm) {
		this.secdVefyIndiNm = secdVefyIndiNm;
	}
	public String getSecdVefyTye() {
		return secdVefyTye;
	}
	public void setSecdVefyTye(String secdVefyTye) {
		this.secdVefyTye = secdVefyTye;
	}
	public String getSecdVefyRsdtNo() {
		return secdVefyRsdtNo;
	}
	public void setSecdVefyRsdtNo(String secdVefyRsdtNo) {
		this.secdVefyRsdtNo = secdVefyRsdtNo;
	}
	public String getErsrCdNm() {
		return ersrCdNm;
	}
	public void setErsrCdNm(String ersrCdNm) {
		this.ersrCdNm = ersrCdNm;
	}
	public String getMberRgstId() {
		return mberRgstId;
	}
	public void setMberRgstId(String mberRgstId) {
		this.mberRgstId = mberRgstId;
	}
	public String getMberRgstIdNm() {
		return mberRgstIdNm;
	}
	public void setMberRgstIdNm(String mberRgstIdNm) {
		this.mberRgstIdNm = mberRgstIdNm;
	}
	public String getEnSurnm() {
		return enSurnm;
	}
	public void setEnSurnm(String enSurnm) {
		this.enSurnm = enSurnm;
	}
	public String getEnGivNm() {
		return enGivNm;
	}
	public void setEnGivNm(String enGivNm) {
		this.enGivNm = enGivNm;
	}
	public String getGfthrRsdtSeqNo() {
		return gfthrRsdtSeqNo;
	}
	public void setGfthrRsdtSeqNo(String gfthrRsdtSeqNo) {
		this.gfthrRsdtSeqNo = gfthrRsdtSeqNo;
	}
	public String getSpusRsdtSeqNo() {
		return spusRsdtSeqNo;
	}
	public void setSpusRsdtSeqNo(String spusRsdtSeqNo) {
		this.spusRsdtSeqNo = spusRsdtSeqNo;
	}
	public String getSpusNm() {
		return spusNm;
	}
	public void setSpusNm(String spusNm) {
		this.spusNm = spusNm;
	}
	public String getDsbtCd() {
		return dsbtCd;
	}
	public void setDsbtCd(String dsbtCd) {
		this.dsbtCd = dsbtCd;
	}
	public String getDsbtCdNm() {
		return dsbtCdNm;
	}
	public void setDsbtCdNm(String dsbtCdNm) {
		this.dsbtCdNm = dsbtCdNm;
	}
	public String getFrngrYn() {
		return frngrYn;
	}
	public void setFrngrYn(String frngrYn) {
		this.frngrYn = frngrYn;
	}
	public String getAfSpusEnSurnm() {
		return afSpusEnSurnm;
	}
	public void setAfSpusEnSurnm(String afSpusEnSurnm) {
		this.afSpusEnSurnm = afSpusEnSurnm;
	}
	public String getSpusEnSurnm() {
		return spusEnSurnm;
	}
	public void setSpusEnSurnm(String spusEnSurnm) {
		this.spusEnSurnm = spusEnSurnm;
	}
	public String getSpusEnGivNm() {
		return spusEnGivNm;
	}
	public void setSpusEnGivNm(String spusEnGivNm) {
		this.spusEnGivNm = spusEnGivNm;
	}
	public String getFthrRgstTye() {
		return fthrRgstTye;
	}
	public void setFthrRgstTye(String fthrRgstTye) {
		this.fthrRgstTye = fthrRgstTye;
	}
	public String getMthrRgstTye() {
		return mthrRgstTye;
	}
	public void setMthrRgstTye(String mthrRgstTye) {
		this.mthrRgstTye = mthrRgstTye;
	}
	public String getGfthrRgstTye() {
		return gfthrRgstTye;
	}
	public void setGfthrRgstTye(String gfthrRgstTye) {
		this.gfthrRgstTye = gfthrRgstTye;
	}
	public String getSpusRgstTye() {
		return spusRgstTye;
	}
	public void setSpusRgstTye(String spusRgstTye) {
		this.spusRgstTye = spusRgstTye;
	}
	public String getFthrOldCrdNo() {
		return fthrOldCrdNo;
	}
	public void setFthrOldCrdNo(String fthrOldCrdNo) {
		this.fthrOldCrdNo = fthrOldCrdNo;
	}
	public String getMthrOldCrdNo() {
		return mthrOldCrdNo;
	}
	public void setMthrOldCrdNo(String mthrOldCrdNo) {
		this.mthrOldCrdNo = mthrOldCrdNo;
	}
	public String getGfthrOldCrdNo() {
		return gfthrOldCrdNo;
	}
	public void setGfthrOldCrdNo(String gfthrOldCrdNo) {
		this.gfthrOldCrdNo = gfthrOldCrdNo;
	}
	public String getSpusOldCrdNo() {
		return spusOldCrdNo;
	}
	public void setSpusOldCrdNo(String spusOldCrdNo) {
		this.spusOldCrdNo = spusOldCrdNo;
	}
	public String getRsdtCfmYn() {
		return rsdtCfmYn;
	}
	public void setRsdtCfmYn(String rsdtCfmYn) {
		this.rsdtCfmYn = rsdtCfmYn;
	}
	public String getBldTyeDocYn() {
		return bldTyeDocYn;
	}
	public void setBldTyeDocYn(String bldTyeDocYn) {
		this.bldTyeDocYn = bldTyeDocYn;
	}
	public String getEduLvDocYn() {
		return eduLvDocYn;
	}
	public void setEduLvDocYn(String eduLvDocYn) {
		this.eduLvDocYn = eduLvDocYn;
	}
	public String gethDdttm() {
		return hDdttm;
	}
	public void sethDdttm(String hDdttm) {
		this.hDdttm = hDdttm;
	}
	public String getgDdttm() {
		return gDdttm;
	}
	public void setgDdttm(String gDdttm) {
		this.gDdttm = gDdttm;
	}
	public String getOldCrdNo1() {
		return oldCrdNo1;
	}
	public void setOldCrdNo1(String oldCrdNo1) {
		this.oldCrdNo1 = oldCrdNo1;
	}
	public String getOldCrdNo2() {
		return oldCrdNo2;
	}
	public void setOldCrdNo2(String oldCrdNo2) {
		this.oldCrdNo2 = oldCrdNo2;
	}
	public String getOldCrdNo3() {
		return oldCrdNo3;
	}
	public void setOldCrdNo3(String oldCrdNo3) {
		this.oldCrdNo3 = oldCrdNo3;
	}
	public String getOldCrdNo4() {
		return oldCrdNo4;
	}
	public void setOldCrdNo4(String oldCrdNo4) {
		this.oldCrdNo4 = oldCrdNo4;
	}
	public String getFstVefyOldCrdNo1() {
		return fstVefyOldCrdNo1;
	}
	public void setFstVefyOldCrdNo1(String fstVefyOldCrdNo1) {
		this.fstVefyOldCrdNo1 = fstVefyOldCrdNo1;
	}
	public String getFstVefyOldCrdNo2() {
		return fstVefyOldCrdNo2;
	}
	public void setFstVefyOldCrdNo2(String fstVefyOldCrdNo2) {
		this.fstVefyOldCrdNo2 = fstVefyOldCrdNo2;
	}
	public String getFstVefyOldCrdNo3() {
		return fstVefyOldCrdNo3;
	}
	public void setFstVefyOldCrdNo3(String fstVefyOldCrdNo3) {
		this.fstVefyOldCrdNo3 = fstVefyOldCrdNo3;
	}
	public String getFstVefyOldCrdNo4() {
		return fstVefyOldCrdNo4;
	}
	public void setFstVefyOldCrdNo4(String fstVefyOldCrdNo4) {
		this.fstVefyOldCrdNo4 = fstVefyOldCrdNo4;
	}
	public String getSecdVefyOldCrdNo1() {
		return secdVefyOldCrdNo1;
	}
	public void setSecdVefyOldCrdNo1(String secdVefyOldCrdNo1) {
		this.secdVefyOldCrdNo1 = secdVefyOldCrdNo1;
	}
	public String getSecdVefyOldCrdNo2() {
		return secdVefyOldCrdNo2;
	}
	public void setSecdVefyOldCrdNo2(String secdVefyOldCrdNo2) {
		this.secdVefyOldCrdNo2 = secdVefyOldCrdNo2;
	}
	public String getSecdVefyOldCrdNo3() {
		return secdVefyOldCrdNo3;
	}
	public void setSecdVefyOldCrdNo3(String secdVefyOldCrdNo3) {
		this.secdVefyOldCrdNo3 = secdVefyOldCrdNo3;
	}
	public String getSecdVefyOldCrdNo4() {
		return secdVefyOldCrdNo4;
	}
	public void setSecdVefyOldCrdNo4(String secdVefyOldCrdNo4) {
		this.secdVefyOldCrdNo4 = secdVefyOldCrdNo4;
	}
	
	public String getSgnt() {
		return sgnt;
	}
	public void setSgnt(String sgnt) {
		this.sgnt = sgnt;
	}
	public String getSysSgnt() {
		return sysSgnt;
	}
	public void setSysSgnt(String sysSgnt) {
		this.sysSgnt = sysSgnt;
	}
	public String getCertValdYn() {
		return certValdYn;
	}
	public void setCertValdYn(String certValdYn) {
		this.certValdYn = certValdYn;
	}
	public String getTbDiv() {
		return tbDiv;
	}
	public void setTbDiv(String tbDiv) {
		this.tbDiv = tbDiv;
	}
	public String getTrstId() {
		return trstId;
	}
	public void setTrstId(String trstId) {
		this.trstId = trstId;
	}
	public String getUptWrkCd() {
		return uptWrkCd;
	}
	public void setUptWrkCd(String uptWrkCd) {
		this.uptWrkCd = uptWrkCd;
	}
	public String getLgSeqNo() {
		return lgSeqNo;
	}
	public void setLgSeqNo(String lgSeqNo) {
		this.lgSeqNo = lgSeqNo;
	}
	public String getRsdtNm() {
		return rsdtNm;
	}
	public void setRsdtNm(String rsdtNm) {
		this.rsdtNm = rsdtNm;
	}

	public String getOldCrdIsuceDd() {
		return oldCrdIsuceDd;
	}
	public void setOldCrdIsuceDd(String oldCrdIsuceDd) {
		this.oldCrdIsuceDd = oldCrdIsuceDd;
	}
	public String getCntTelNo() {
		return cntTelNo;
	}
	public void setCntTelNo(String cntTelNo) {
		this.cntTelNo = cntTelNo;
	}
	public String getCntTelNo2() {
		return cntTelNo2;
	}
	public String getNatLangCdNm() {
		return natLangCdNm;
	}
	public void setNatLangCdNm(String natLangCdNm) {
		this.natLangCdNm = natLangCdNm;
	}
	public String getFrgnLangCdNm() {
		return frgnLangCdNm;
	}
	public void setFrgnLangCdNm(String frgnLangCdNm) {
		this.frgnLangCdNm = frgnLangCdNm;
	}
	public void setCntTelNo2(String cntTelNo2) {
		this.cntTelNo2 = cntTelNo2;
	}
	public String getEmlAd() {
		return emlAd;
	}
	public void setEmlAd(String emlAd) {
		this.emlAd = emlAd;
	}
	public String getNatLangCd() {
		return natLangCd;
	}
	public void setNatLangCd(String natLangCd) {
		this.natLangCd = natLangCd;
	}
	public String getFrgnLangCd() {
		return frgnLangCd;
	}
	public void setFrgnLangCd(String frgnLangCd) {
		this.frgnLangCd = frgnLangCd;
	}
	public String getOthrCount() {
		return othrCount;
	}
	public void setOthrCount(String othrCount) {
		this.othrCount = othrCount;
	}
	public String getFrgnCount() {
		return frgnCount;
	}
	public void setFrgnCount(String frgnCount) {
		this.frgnCount = frgnCount;
	}
    
}