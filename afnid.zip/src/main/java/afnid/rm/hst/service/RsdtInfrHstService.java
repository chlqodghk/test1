
package afnid.rm.hst.service;

import java.util.List;


/** 
 * This service interface is biz-class of Citizen Information History. <br>
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2014.03.25
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			    Revisions
 *   2014.03.25  		MS Kim         						Create
 *
 * </pre>
 */

public interface RsdtInfrHstService {
	
	/**
	 * Retrieves list of citizen information history. <br>
	 * 
	 * @param vo Input item for retrieving list of citizen information history(RsdtInfrHstVO).
	 * @return List Retrieve list of citizen information history
	 * @exception Exception
	 */
	List<RsdtInfrHstVO> searchListRsdtInfrHst(RsdtInfrHstVO vo) throws Exception;
	
	/**
	 * Retrieves total count of citizen information history. <br>
	 * @param vo Input item for retrieving total count list of citizen information history.(RsdtInfrHstVO)
	 * @return int Total Count of citizen information history
	 * @exception Exception
	 */
	int searchListRsdtInfrHstTotCnt(RsdtInfrHstVO vo) throws Exception;
	
	/**
	 * Retrieves citizen information history. <br>
	 * 
	 * @param vo Input item for retrieving citizen information history(RsdtInfrHstVO).
	 * @return  citizen information history
	 * @exception Exception
	 */
	RsdtInfrHstVO searchRsdtInfrRsdtTb(RsdtInfrHstVO vo) throws Exception;
	
	/**
	 * Retrieves citizen information history. <br>
	 * 
	 * @param vo Input item for retrieving citizen information history(RsdtInfrHstVO).
	 * @return  citizen information history
	 * @exception Exception
	 */
	RsdtInfrHstVO searchRsdtInfrRsdtHstTb(RsdtInfrHstVO vo) throws Exception;
	
	/**
	 * Retrieves citizen information history. <br>
	 * 
	 * @param vo Input item for retrieving citizen information history(RsdtInfrHstVO).
	 * @return  citizen information history
	 * @exception Exception
	 */
	RsdtInfrHstVO searchRsdtInfrBfRsdtHstTb(RsdtInfrHstVO vo) throws Exception;	
	
	/**
	 * Retrieves value of signature comparison. <br>
	 * 
	 * @param vo Input item for retrieving value of signature comparison(RsdtInfrHstVO).
	 * @return  String value of signature comparison
	 * @exception Exception
	 */
	int selectCert(RsdtInfrHstVO vo) throws Exception;	
	
	/**
	 * Retrieves list of other national language. <br>
	 *
	 * @param vo Input item for retrieving list of other national language(RsdtInfrVO).
	 * @return List Retrieve list of other national language
	 * @exception Exception
	 */
	List<RsdtInfrHstVO> searchOthrNatLangListTb(RsdtInfrHstVO vo) throws Exception;
	
	/**
	 * Retrieves list of foreign language. <br>
	 *
	 * @param vo Input item for retrieving list of foreign language(RsdtInfrVO).
	 * @return List Retrieve list of foreign language
	 * @exception Exception
	 */
	List<RsdtInfrHstVO> searchFrgnLangListTb(RsdtInfrHstVO vo) throws Exception;
	
	/**
	 * Retrieves list of other national language. <br>
	 *
	 * @param vo Input item for retrieving list of other national language(RsdtInfrHstVO).
	 * @return List Retrieve list of other national language
	 * @exception Exception
	 */
	List<RsdtInfrHstVO> searchOthrNatLangListHstTb(RsdtInfrHstVO vo) throws Exception;
	
	/**
	 * Retrieves list of foreign language. <br>
	 *
	 * @param vo Input item for retrieving list of foreign language(RsdtInfrHstVO).
	 * @return List Retrieve list of foreign language
	 * @exception Exception
	 */
	List<RsdtInfrHstVO> searchFrgnLangListHstTb(RsdtInfrHstVO vo) throws Exception;
	
	/**
	 * Retrieves list of other national language. <br>
	 *
	 * @param vo Input item for retrieving list of other national language(RsdtInfrHstVO).
	 * @return List Retrieve list of other national language
	 * @exception Exception
	 */
	List<RsdtInfrHstVO> searchOthrNatLangListBfHstTb(RsdtInfrHstVO vo) throws Exception;
	
	/**
	 * Retrieves list of foreign language. <br>
	 *
	 * @param vo Input item for retrieving list of foreign language(RsdtInfrHstVO).
	 * @return List Retrieve list of foreign language
	 * @exception Exception
	 */
	List<RsdtInfrHstVO> searchFrgnLangListBfHstTb(RsdtInfrHstVO vo) throws Exception;	
	
	/**
	 * Retrieves Field Value Change Y/N(other national language, foreign language). <br>
	 * 
	 * @param vo Input item for retrieving Field Value Change Y/N(RsdtInfrHstVO).
	 * @return  Field Value Change Y/N(other national language, foreign language)
	 * @exception Exception
	 */
	RsdtInfrHstVO searchRsdtHstChngFlag(RsdtInfrHstVO vo) throws Exception;
	
	/**
	 * Retrieves Field Value Change Y/N(other national language, foreign language). <br>
	 * 
	 * @param vo Input item for retrieving Field Value Change Y/N(RsdtInfrHstVO).
	 * @return  Field Value Change Y/N
	 * @exception Exception
	 */
	RsdtInfrHstVO searchRsdtHstChngFlagHst(RsdtInfrHstVO vo) throws Exception;	
}
