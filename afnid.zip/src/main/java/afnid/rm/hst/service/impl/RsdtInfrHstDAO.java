
package afnid.rm.hst.service.impl;

import java.util.List;
import javax.annotation.Resource;
import org.springframework.stereotype.Repository;

import afnid.rm.hst.service.RsdtInfrHstVO;

import com.ibatis.sqlmap.client.SqlMapClient;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;


/** 
 * This class is Database Access Object of Citizen Information History
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2014.03.25
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			    Revisions
 *   2014.03.25  		MS Kim         						Create
 *
 * </pre>
 */

@Repository("rsdtInfrHstDAO")
public class RsdtInfrHstDAO extends EgovAbstractDAO {
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }

    
	/**
	 * DAO-method for retrieving list of citizen information history.<br>
	 * 
	 * @param vo Input item for retrieving list of citizen information history(RsdtInfrHstVO).
	 * @return List Retrieve list of citizen information history
	 * @exception Exception 
	 */		
	@SuppressWarnings("unchecked")
	public List<RsdtInfrHstVO> selectListRsdtInfrHst(RsdtInfrHstVO vo) throws Exception{
		return list("rsdtInfrHstDAO.selectListRsdtInfrHst", vo);
	}
	
	/**
	 * DAO-method for retrieving total count of citizen information history. <br>
	 * 
	 * @param vo Input item for retrieving list of citizen information history(RsdtInfrHstVO).
	 * @return int Total Count of citizen information history
	 * @exception Exception 
	 */
    public int selectListRsdtInfrHstTotCnt(RsdtInfrHstVO vo) {
        return (Integer)selectByPk("rsdtInfrHstDAO.selectListRsdtInfrHstTotCnt", vo);
    }
	
	/**
	 * DAO-method for retrieving citizen information history.<br>
	 * 
	 * @param vo Input item for retrieving citizen information history(RsdtInfrHstVO).
	 * @return citizen information history
	 * @exception Exception 
	 */		
	public RsdtInfrHstVO selectRsdtInfrRsdtTb(RsdtInfrHstVO vo) throws Exception{
		return (RsdtInfrHstVO)selectByPk("rsdtInfrHstDAO.selectRsdtInfrRsdtTb", vo);
	}
	
	/**
	 * DAO-method for retrieving citizen information history.<br>
	 * 
	 * @param vo Input item for retrieving citizen information history(RsdtInfrHstVO).
	 * @return citizen information history
	 * @exception Exception 
	 */		

	public RsdtInfrHstVO selectRsdtInfrRsdtHstTb(RsdtInfrHstVO vo) throws Exception{
		return (RsdtInfrHstVO)selectByPk("rsdtInfrHstDAO.selectRsdtInfrRsdtHstTb", vo);
	}
	
	/**
	 * DAO-method for retrieving citizen information history.<br>
	 * 
	 * @param vo Input item for retrieving citizen information history(RsdtInfrHstVO).
	 * @return citizen information history
	 * @exception Exception 
	 */		
	public RsdtInfrHstVO selectRsdtInfrBfRsdtHstTb(RsdtInfrHstVO vo) throws Exception{
		return (RsdtInfrHstVO)selectByPk("rsdtInfrHstDAO.selectRsdtInfrBfRsdtHstTb", vo);
	}	
	
	/**
	 * DAO-method for retrieving list of other national language. <br>
	 *
	 * @param vo Input item for retrieving list of other national language(RsdtInfrHstVO).
	 * @return List Retrieve list information of other national language
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrHstVO> selectOthrNatLangListTb(RsdtInfrHstVO vo) throws Exception{
		return list("rsdtInfrHstDAO.selectOthrNatLangListTb", vo);
	}
	
	/**
	 * DAO-method for retrieving list of foreign language. <br>
	 *
	 * @param vo Input item for retrieving list of foreign language(RsdtInfrVO).
	 * @return List Retrieve list of foreign language
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrHstVO> selectFrgnLangListTb(RsdtInfrHstVO vo) throws Exception{
		return list("rsdtInfrHstDAO.selectFrgnLangListTb", vo);
	}
	
	/**
	 * DAO-method for retrieving list of other national language. <br>
	 *
	 * @param vo Input item for retrieving list of other national language(RsdtInfrHstVO).
	 * @return List Retrieve list of other national language
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrHstVO> selectOthrNatLangListHstTb(RsdtInfrHstVO vo) throws Exception{
		return list("rsdtInfrHstDAO.selectOthrNatLangListHstTb", vo);
	}
	
	/**
	 * DAO-method for retrieving list of foreign language. <br>
	 *
	 * @param vo Input item for retrieving list of foreign language(RsdtInfrHstVO).
	 * @return List Retrieve list of foreign language
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrHstVO> selectFrgnLangListHstTb(RsdtInfrHstVO vo) throws Exception{
		return list("rsdtInfrHstDAO.selectFrgnLangListHstTb", vo);
	}
	
	/**
	 * DAO-method for retrieving list of other national language. <br>
	 *
	 * @param vo Input item for retrieving list of other national language(RsdtInfrHstVO).
	 * @return List Retrieve list of other national language
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrHstVO> selectOthrNatLangListBfHstTb(RsdtInfrHstVO vo) throws Exception{
		return list("rsdtInfrHstDAO.selectOthrNatLangListBfHstTb", vo);
	}
	
	/**
	 * DAO-method for retrieving list of foreign language. <br>
	 *
	 * @param vo Input item for retrieving list of foreign language(RsdtInfrHstVO).
	 * @return List Retrieve list of foreign language
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrHstVO> selectFrgnLangListBfHstTb(RsdtInfrHstVO vo) throws Exception{
		return list("rsdtInfrHstDAO.selectFrgnLangListBfHstTb", vo);
	}	
	
    /**
	 * Biz-method for retrieving  Field Value Change Y/N(other national language, foreign language). <br>
	 * 
	 * @param vo Input item for retrieving  Field Value Change Y/N(RsdtInfrHstVO).
	 * @return  Field Value Change Y/N(
	 * @exception Exception
	 */	
	public RsdtInfrHstVO selectRsdtHstChngFlag(RsdtInfrHstVO vo) throws Exception{
		return (RsdtInfrHstVO)selectByPk("rsdtInfrHstDAO.selectRsdtHstChngFlag", vo);
	}
	
    /**
	 * Biz-method for retrieving  Field Value Change Y/N(other national language, foreign language). <br>
	 * 
	 * @param vo Input item for retrieving  Field Value Change Y/N(RsdtInfrHstVO).
	 * @return  Field Value Change Y/N(
	 * @exception Exception
	 */	
	public RsdtInfrHstVO selectRsdtHstChngFlagHst(RsdtInfrHstVO vo) throws Exception{
		return (RsdtInfrHstVO)selectByPk("rsdtInfrHstDAO.selectRsdtHstChngFlagHst", vo);
	}
	
}
