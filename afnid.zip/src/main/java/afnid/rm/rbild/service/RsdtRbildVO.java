package afnid.rm.rbild.service;

import afnid.cm.ComDefaultVO;

public class RsdtRbildVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	//Information pop-up window
	private String rsdtNo;
	private String rsdtNoDply;
	private String rsdtSeqNo;
	private String nm;
	private String gdrCd;
	private String gdrCdNm;
	private String bthDd;
	private String gBthDd;
	private String hBthDd;
	private String rlCd;
	private String rlCdNm;
	private String ersrCdNm;
	
	private String bfRsdtNo;
	private String bfRsdtNoDply;
	private String bfRsdtSeqNo;
	private String bfNm;

	private String afRsdtNo;
	private String afRsdtNoDply;
	private String afRsdtSeqNo;
	private String afNm;
	
	private String[] lstChngYn;
	private String[] lstCddRsdtNo;
	private String[] lstRsdtNo;
	private String[] lstRsdtSeqNo;
	private String[] oficSgntList;
	private String[] lstRlCd;
	
	private String rvokdRsdtNo;
	private String rvokdRsdtNoDply;
	private String rvokdRsdtSeqNo;
	private String rvokdNm;
	private String rvokdGdrCd;
	private String rvokdGdrCdNm;
	private String rvokdBthDd;
	private String rvokdGbthDd;
	private String rvokdHbthDd;	
	
	private String rbildRsdtNo;
	private String rbildRsdtNoDply;	
	private String rbildRsdtSeqNo;
	private String rbildNm;
	private String rbildGdrCd;
	private String rbildGdrCdNm;
	private String rbildBthDd;
	private String rbildGbthDd;
	private String rbildHbthDd;
	
	private String userId;
	private String chngTyp;
	private String rbildYn;
	
	private String orgnzCd;
	private String orgnzCdNm;
	private String srchOrgnzCd;
	private String srchOrgnzNm;
	private String orgnzClsCd;
	private String localYn;
	private String oficTye;
	
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getRsdtNoDply() {
		return rsdtNoDply;
	}
	public void setRsdtNoDply(String rsdtNoDply) {
		this.rsdtNoDply = rsdtNoDply;
	}
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getNm() {
		return nm;
	}
	public void setNm(String nm) {
		this.nm = nm;
	}
	public String getGdrCd() {
		return gdrCd;
	}
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	public String getgBthDd() {
		return gBthDd;
	}
	public void setgBthDd(String gBthDd) {
		this.gBthDd = gBthDd;
	}
	public String gethBthDd() {
		return hBthDd;
	}
	public void sethBthDd(String hBthDd) {
		this.hBthDd = hBthDd;
	}
	public String getRlCd() {
		return rlCd;
	}
	public void setRlCd(String rlCd) {
		this.rlCd = rlCd;
	}
	public String getRlCdNm() {
		return rlCdNm;
	}
	public void setRlCdNm(String rlCdNm) {
		this.rlCdNm = rlCdNm;
	}
	public String getBfRsdtNo() {
		return bfRsdtNo;
	}
	public void setBfRsdtNo(String bfRsdtNo) {
		this.bfRsdtNo = bfRsdtNo;
	}
	public String getBfRsdtNoDply() {
		return bfRsdtNoDply;
	}
	public void setBfRsdtNoDply(String bfRsdtNoDply) {
		this.bfRsdtNoDply = bfRsdtNoDply;
	}
	public String getBfRsdtSeqNo() {
		return bfRsdtSeqNo;
	}
	public void setBfRsdtSeqNo(String bfRsdtSeqNo) {
		this.bfRsdtSeqNo = bfRsdtSeqNo;
	}
	public String getBfNm() {
		return bfNm;
	}
	public void setBfNm(String bfNm) {
		this.bfNm = bfNm;
	}
	public String getAfRsdtNo() {
		return afRsdtNo;
	}
	public void setAfRsdtNo(String afRsdtNo) {
		this.afRsdtNo = afRsdtNo;
	}
	public String getAfRsdtNoDply() {
		return afRsdtNoDply;
	}
	public void setAfRsdtNoDply(String afRsdtNoDply) {
		this.afRsdtNoDply = afRsdtNoDply;
	}
	public String getAfRsdtSeqNo() {
		return afRsdtSeqNo;
	}
	public void setAfRsdtSeqNo(String afRsdtSeqNo) {
		this.afRsdtSeqNo = afRsdtSeqNo;
	}
	public String getAfNm() {
		return afNm;
	}
	public void setAfNm(String afNm) {
		this.afNm = afNm;
	}
	public String[] getLstChngYn() {
		return lstChngYn;
	}
	public void setLstChngYn(String[] lstChngYn) {
		this.lstChngYn = lstChngYn;
	}
	public String[] getLstCddRsdtNo() {
		return lstCddRsdtNo;
	}
	public void setLstCddRsdtNo(String[] lstCddRsdtNo) {
		this.lstCddRsdtNo = lstCddRsdtNo;
	}
	public String getRvokdRsdtNo() {
		return rvokdRsdtNo;
	}
	public void setRvokdRsdtNo(String rvokdRsdtNo) {
		this.rvokdRsdtNo = rvokdRsdtNo;
	}
	public String getRvokdRsdtNoDply() {
		return rvokdRsdtNoDply;
	}
	public void setRvokdRsdtNoDply(String rvokdRsdtNoDply) {
		this.rvokdRsdtNoDply = rvokdRsdtNoDply;
	}
	public String getRvokdRsdtSeqNo() {
		return rvokdRsdtSeqNo;
	}
	public void setRvokdRsdtSeqNo(String rvokdRsdtSeqNo) {
		this.rvokdRsdtSeqNo = rvokdRsdtSeqNo;
	}
	public String getRvokdNm() {
		return rvokdNm;
	}
	public void setRvokdNm(String rvokdNm) {
		this.rvokdNm = rvokdNm;
	}
	public String getRvokdGdrCd() {
		return rvokdGdrCd;
	}
	public void setRvokdGdrCd(String rvokdGdrCd) {
		this.rvokdGdrCd = rvokdGdrCd;
	}
	public String getRvokdGdrCdNm() {
		return rvokdGdrCdNm;
	}
	public void setRvokdGdrCdNm(String rvokdGdrCdNm) {
		this.rvokdGdrCdNm = rvokdGdrCdNm;
	}
	public String getRvokdGbthDd() {
		return rvokdGbthDd;
	}
	public void setRvokdGbthDd(String rvokdGbthDd) {
		this.rvokdGbthDd = rvokdGbthDd;
	}
	public String getRvokdHbthDd() {
		return rvokdHbthDd;
	}
	public void setRvokdHbthDd(String rvokdHbthDd) {
		this.rvokdHbthDd = rvokdHbthDd;
	}
	public String getRbildRsdtNo() {
		return rbildRsdtNo;
	}
	public void setRbildRsdtNo(String rbildRsdtNo) {
		this.rbildRsdtNo = rbildRsdtNo;
	}
	public String getRbildRsdtSeqNo() {
		return rbildRsdtSeqNo;
	}
	public void setRbildRsdtSeqNo(String rbildRsdtSeqNo) {
		this.rbildRsdtSeqNo = rbildRsdtSeqNo;
	}
	public String getRbildNm() {
		return rbildNm;
	}
	public void setRbildNm(String rbildNm) {
		this.rbildNm = rbildNm;
	}
	public String getRbildGdrCd() {
		return rbildGdrCd;
	}
	public void setRbildGdrCd(String rbildGdrCd) {
		this.rbildGdrCd = rbildGdrCd;
	}
	public String getRbildGdrCdNm() {
		return rbildGdrCdNm;
	}
	public void setRbildGdrCdNm(String rbildGdrCdNm) {
		this.rbildGdrCdNm = rbildGdrCdNm;
	}
	public String getRbildGbthDd() {
		return rbildGbthDd;
	}
	public void setRbildGbthDd(String rbildGbthDd) {
		this.rbildGbthDd = rbildGbthDd;
	}
	public String getRbildHbthDd() {
		return rbildHbthDd;
	}
	public void setRbildHbthDd(String rbildHbthDd) {
		this.rbildHbthDd = rbildHbthDd;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getRbildRsdtNoDply() {
		return rbildRsdtNoDply;
	}
	public void setRbildRsdtNoDply(String rbildRsdtNoDply) {
		this.rbildRsdtNoDply = rbildRsdtNoDply;
	}
	public String getErsrCdNm() {
		return ersrCdNm;
	}
	public void setErsrCdNm(String ersrCdNm) {
		this.ersrCdNm = ersrCdNm;
	}

	public String getChngTyp() {
		return chngTyp;
	}
	public void setChngTyp(String chngTyp) {
		this.chngTyp = chngTyp;
	}
	public String getRvokdBthDd() {
		return rvokdBthDd;
	}
	public void setRvokdBthDd(String rvokdBthDd) {
		this.rvokdBthDd = rvokdBthDd;
	}
	public String getRbildBthDd() {
		return rbildBthDd;
	}
	public void setRbildBthDd(String rbildBthDd) {
		this.rbildBthDd = rbildBthDd;
	}
	public String getBthDd() {
		return bthDd;
	}
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	public String getRbildYn() {
		return rbildYn;
	}
	public void setRbildYn(String rbildYn) {
		this.rbildYn = rbildYn;
	}
	public String[] getLstRsdtNo() {
		return lstRsdtNo;
	}
	public void setLstRsdtNo(String[] lstRsdtNo) {
		this.lstRsdtNo = lstRsdtNo;
	}
	public String[] getLstRsdtSeqNo() {
		return lstRsdtSeqNo;
	}
	public void setLstRsdtSeqNo(String[] lstRsdtSeqNo) {
		this.lstRsdtSeqNo = lstRsdtSeqNo;
	}
	public String[] getOficSgntList() {
		return oficSgntList;
	}
	public void setOficSgntList(String[] oficSgntList) {
		this.oficSgntList = oficSgntList;
	}
	public String[] getLstRlCd() {
		return lstRlCd;
	}
	public void setLstRlCd(String[] lstRlCd) {
		this.lstRlCd = lstRlCd;
	}
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String getOrgnzCdNm() {
		return orgnzCdNm;
	}
	public void setOrgnzCdNm(String orgnzCdNm) {
		this.orgnzCdNm = orgnzCdNm;
	}
	public String getSrchOrgnzCd() {
		return srchOrgnzCd;
	}
	public void setSrchOrgnzCd(String srchOrgnzCd) {
		this.srchOrgnzCd = srchOrgnzCd;
	}
	public String getSrchOrgnzNm() {
		return srchOrgnzNm;
	}
	public void setSrchOrgnzNm(String srchOrgnzNm) {
		this.srchOrgnzNm = srchOrgnzNm;
	}
	public String getOrgnzClsCd() {
		return orgnzClsCd;
	}
	public void setOrgnzClsCd(String orgnzClsCd) {
		this.orgnzClsCd = orgnzClsCd;
	}
	public String getLocalYn() {
		return localYn;
	}
	public void setLocalYn(String localYn) {
		this.localYn = localYn;
	}
	public String getOficTye() {
		return oficTye;
	}
	public void setOficTye(String oficTye) {
		this.oficTye = oficTye;
	}
	

}
