package afnid.rm.rbild.service;

import java.util.List;

/** 
 * This service interface is biz-class of monitor. <br>
 * 
 * @author Afghanistan National ID RM Application Team moon soo kim
 * @since 2015.01.22
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           				 Revisions
 *  --------------------------------------------------------------------
 *  2015.01.22 		   moon soo kim        		             Create
 *
 * </pre>
 */
public interface RsdtRbildService {

	
	/**
	 * Retrieves citizen. <br>	 
	 *
	 * @param rsdtRbildVO Input item for retrieve citizen(RsdtRbildVO).
	 * @return citizen citizen
	 * @exception Exception
	 */
	public RsdtRbildVO searchRsdt(RsdtRbildVO rsdtRbildVO) throws Exception;
	
	/**
	 * Retrieves detail Information of revoked citizen. <br>	 
	 *
	 * @param rsdtRbildVO Input item for retrieve detail Information of revoked citizen(RsdtRbildVO).
	 * @return citizen detail Information of revoked citizen
	 * @exception Exception
	 */
	public RsdtRbildVO searchRvokdRsdt(RsdtRbildVO rsdtRbildVO) throws Exception;
	
	
	/**
	 * Retrieves detail Information of rebuild citizen. <br>	 
	 *
	 * @param rsdtRbildVO Input item for retrieve detail Information of rebuild citizen(RsdtRbildVO).
	 * @return citizen detail Information of rebuild citizen
	 * @exception Exception
	 */
	public RsdtRbildVO searchRbildRsdt(RsdtRbildVO rsdtRbildVO) throws Exception;
	
	/**
	 * Retrieves list of rebuild Citizens. <br>
	 * 
	 * @param rsdtRbildVO Input item for retrieving list of rebuild Citizens(OrgnzVO).
	 * @return List list of rebuild Citizens
	 * @exception Exception
	 */
	public List<RsdtRbildVO> searchListRbildLink(RsdtRbildVO rsdtRbildVO) throws Exception;	

	/**
	 * Retrieves total count list of rebuild Citizens. <br>
	 * @param rsdtRbildVO Input item for retrieving total count list of rebuild Citizens.(OrgnzVO)
	 * @return int Total Count list of rebuild Citizens
	 * @exception Exception
	 */
	public int searchListRbildLinkTotCnt(RsdtRbildVO rsdtRbildVO) throws Exception;	
	
	
	/**
	 * Modifies information of citizen link. <br>
	 * 
	 * @param rsdtRbildVO Input item for modifying information of citizen link(RsdtRbildVO).
	 * @return 	void
	 * @exception Exception
	 */
	public void modifyRbildLink(RsdtRbildVO rsdtRbildVO) throws Exception;		
	
	/**
	 * Retrieves list of rebuild Candidate. <br>
	 * 
	 * @param rsdtRbildVO Input item for retrieving list of rebuild Candidate(RsdtRbildVO).
	 * @return List list of rebuild Candidate
	 * @exception Exception
	 */
	public List<RsdtRbildVO> searchListRbildLinkCdd(RsdtRbildVO rsdtRbildVO) throws Exception;	

	/**
	 * Retrieves total count list of rebuild Candidate. <br>
	 * @param rsdtRbildVO Input item for retrieving total count list of rebuild Candidate.(RsdtRbildVO)
	 * @return int Total Count list of rebuild Candidate
	 * @exception Exception
	 */
	public int searchListRbildLinkCddTotCnt(RsdtRbildVO rsdtRbildVO) throws Exception;	
	

	
}
