package afnid.rm.rbild.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.rbild.service.RsdtRbildService;
import afnid.rm.rbild.service.RsdtRbildVO;
import afnid.rm.rsdt.service.RsdtInfrService;
import afnid.rm.rsdt.service.RsdtInfrVO;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of organization
 * and implements organizationService class.
 * 
 * @author Afghanistan National ID RM Application Team moon soo kim
 * @since 2015.01.22
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           				 Revisions
 *  --------------------------------------------------------------------
 *  2015.01.22 		   moon soo kim        		             Create
 *
 * </pre>
 */
@Service("rsdtRbildService")
public class RsdtRbuildServiceImple extends AbstractServiceImpl implements RsdtRbildService{
	
	@Resource(name="rsdtRbildDAO")
    private RsdtRbildDAO rsdtRbildDAO;
    	
    @Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtDao;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    @Resource(name="rsdtInfoService")
    private RsdtInfrService rsdtInfoService;    
    
    /**
	 * Biz-method for retrieving citizen. <br>
	 * 
	 * @param vrsdtRbildVO Input item for retrieving citizen(RsdtRbildVO).
	 * @return RsdtRbildVO citizen
	 * @exception Exception
	 */
	public RsdtRbildVO searchRsdt(RsdtRbildVO rsdtRbildVO) throws Exception{		
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		rsdtRbildVO.setUseLangCd(user.getUseLangCd());
    	return (RsdtRbildVO)rsdtRbildDAO.selectRsdt(rsdtRbildVO);
	}
	
    /**
	 * Biz-method for retrieving detail Information of revoked citizen. <br>
	 * 
	 * @param rsdtRbildVO Input item for retrieving detail information of revoked citizen(RsdtRbildVO).
	 * @return RsdtRbildVO detail information of revoked citizen
	 * @exception Exception
	 */
	public RsdtRbildVO searchRvokdRsdt(RsdtRbildVO rsdtRbildVO) throws Exception{		
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		rsdtRbildVO.setUseLangCd(user.getUseLangCd());
    	return (RsdtRbildVO)rsdtRbildDAO.selectRvokdRsdt(rsdtRbildVO);
	}
	
	
    /**
	 * Biz-method for retrieving detail Information of rebuild citizen <br>
	 * 
	 * @param rsdtRbildVOo Input item for retrieving detail information of rebuild citizen(RsdtRbildVO).
	 * @return RsdtRbildVO  detail information of rebuild citizen
	 * @exception Exception
	 */
	public RsdtRbildVO searchRbildRsdt(RsdtRbildVO rsdtRbildVO) throws Exception{
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		rsdtRbildVO.setUseLangCd(user.getUseLangCd());
    	return (RsdtRbildVO)rsdtRbildDAO.selectRbildRsdt(rsdtRbildVO);
	}
	
    /**
	 * Biz-method for retrieving list of rebuild Citizens. <br>
	 * 
	 * @param rsdtRbildVO Input item for retrieving list of rebuild Citizens(RsdtRbildVO).
	 * @return List list of rebuild Citizens
	 * @exception Exception
	 */
	public List<RsdtRbildVO> searchListRbildLink(RsdtRbildVO rsdtRbildVO) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		rsdtRbildVO.setUseLangCd(user.getUseLangCd());		
   		return rsdtRbildDAO.selecthListRbildLink(rsdtRbildVO);
	}
	
	/**
	 * Biz-method for retrieving total count list of rebuild Citizens. <br>
	 * 
	 * @param rsdtRbildVO Input item for retrieving list of rebuild Citizens(RsdtRbildVO).
	 * @return int Total Count list of rebuild Citizens
	 * @exception Exception
	 */
    public int searchListRbildLinkTotCnt(RsdtRbildVO rsdtRbildVO) throws Exception {
    	return rsdtRbildDAO.selectListRbildLinkTotCnt(rsdtRbildVO);
	}

	/**
	 * Biz-method for modifying information of citizen link. <br>
	 * 
	 * @param rsdtRbildVO Input item for modifying citizen link(RsdtRbildVO).
	 * @return void
	 * @exception Exception
	 */
	public void modifyRbildLink(RsdtRbildVO rsdtRbildVO) throws Exception {
		
		RsdtInfrVO rsdtVo = new RsdtInfrVO();
		
		/** Loading session information */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		rsdtRbildVO.setUserId(user.getUserId());

		String [] chngYn    = rsdtRbildVO.getLstChngYn();
		String [] rsdtSeqNo = rsdtRbildVO.getLstRsdtSeqNo();		
		String [] rlCd      = rsdtRbildVO.getLstRlCd();
		String [] oficSgnt  = rsdtRbildVO.getOficSgntList();
		if (chngYn != null) {
			for(int k=0;k<chngYn.length; k++ ){
				if("Y".equals(chngYn[k])){
					
					//insert history
					rsdtDao.insertRsdtInfrHst(rsdtSeqNo[k], user.getUserId());	
					
					//citizen information update
					rsdtRbildVO.setRsdtSeqNo(rsdtSeqNo[k]);		
					rsdtRbildVO.setRlCd(rlCd[k]);
					rsdtRbildDAO.updateRbildLink(rsdtRbildVO);
					
					//officer signature update		
					rsdtVo.setRsdtSeqNo(rsdtSeqNo[k]);
			   		String resultSgnt = rsdtInfoService.getXmlData(oficSgnt[k], "Signature");
			   		
			   		if(resultSgnt != null && resultSgnt.length() > 0){			   			
			   			rsdtVo.setSgnt(resultSgnt);
				   		rsdtDao.updateRsdtInfrSgnt(rsdtVo);
			   		}				   		
				   		
			   		//system signature update
			   		EgovMap em = rsdtDao.selectRsdtInfrDat(rsdtSeqNo[k]);
			   		String hash = "";
			   		if(em != null && !em.isEmpty()){
			   			hash = rsdtDao.selectRsdtInfrHashDat(em, "24");
			   			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
						if(hash != null && hash.indexOf(reg) == -1){
							String admTelNo = nidMessageSource.getMessage("admTelNo");
							throw processException("pki.websrvcEror.msg", new String[]{hash, admTelNo});
						}
			   			resultSgnt = rsdtInfoService.getXmlData(hash, "ds:Signature");
			   		}
			   		
			   		if(resultSgnt != null && resultSgnt.length() > 0){
			   			rsdtVo.setSysSgnt(resultSgnt);
			   			rsdtDao.updateRsdtInfrSysSgnt(rsdtVo);
			   		}
			   		
				}//end-if
			}//end-for
		}
					
	}

	
    /**
	 * Biz-method for retrieving list of rebuild Candidate. <br>
	 * 
	 * @param rsdtRbildVO Input item for retrieving list of rebuild Citizens(RsdtRbildVO).
	 * @return List list of rebuild Candidate
	 * @exception Exception
	 */
	public List<RsdtRbildVO> searchListRbildLinkCdd(RsdtRbildVO rsdtRbildVO) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		rsdtRbildVO.setUseLangCd(user.getUseLangCd());		
   		return rsdtRbildDAO.selectListRbildLinkCdd(rsdtRbildVO);
	}
	
	/**
	 * Biz-method for retrieving total count list of rebuild Candidate. <br>
	 * 
	 * @param rsdtRbildVO Input item for retrieving list of rebuild Candidate(RsdtRbildVO).
	 * @return int Total Count list of rebuild Candidate
	 * @exception Exception
	 */
    public int searchListRbildLinkCddTotCnt(RsdtRbildVO rsdtRbildVO) throws Exception {
    	return rsdtRbildDAO.selectListRbildLinkCddTotCnt(rsdtRbildVO);
	}
    
   
}
