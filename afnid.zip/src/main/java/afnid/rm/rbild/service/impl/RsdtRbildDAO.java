package afnid.rm.rbild.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.ibatis.sqlmap.client.SqlMapClient;

import afnid.rm.rbild.service.RsdtRbildVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/** 
 * This class is Database Access Object of organization.
 * 
 * @author Afghanistan National ID RM Application Team moon soo kim
 * @since 2015.01.22
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           				 Revisions
 *  --------------------------------------------------------------------
 *  2015.01.22 		   moon soo kim        		             Create
 *
 * </pre>
 */
@Repository("rsdtRbildDAO")
public class RsdtRbildDAO extends EgovAbstractDAO{
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	
	/**
	 * DAO-method for retrieving citizen. <br>
	 * 
	 * @param rsdtRbildVO Input item for retrieving citizen(RsdtRbildVO).
	 * @return RsdtRbildVO citizen
	 * @exception Exception
	 */
	public RsdtRbildVO selectRsdt(RsdtRbildVO rsdtRbildVO) throws Exception{			
		return (RsdtRbildVO)selectByPk("rsdtRbildDAO.selectRsdt", rsdtRbildVO);
	}
	
	/**
	 * DAO-method for retrieving detail Information of revoked citizen. <br>
	 * 
	 * @param rsdtRbildVO Input item for retrieving detail Information of revoked citizen(RsdtRbildVO).
	 * @return RsdtRbildVO detail Information of revoked citizen
	 * @exception Exception
	 */
	public RsdtRbildVO selectRvokdRsdt(RsdtRbildVO rsdtRbildVO) throws Exception{			
		return (RsdtRbildVO)selectByPk("rsdtRbildDAO.selectRvokdRsdt", rsdtRbildVO);
	}
	
	/**
	 * DAO-method for retrieving detail Information of rebuild citizen. <br>
	 * 
	 * @param rsdtRbildVO Input item for retrieving detail Information of rebuild citizen(RsdtRbildVO).
	 * @return RsdtRbildVO detail Information of rebuild citizen
	 * @exception Exception
	 */	
	public RsdtRbildVO selectRbildRsdt(RsdtRbildVO rsdtRbildVO) throws Exception{
		return (RsdtRbildVO)selectByPk("rsdtRbildDAO.selectRbildRsdt", rsdtRbildVO);
	}
	
	
	/**
	 * DAO-method for retrieving list of rebuild Citizens. <br>
	 * 
	 * @param rsdtRbildVO Input item for retrieving list of rebuild Citizens(OrgnzVO).
	 * @return List list of rebuild Citizens
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")	
	public List<RsdtRbildVO> selecthListRbildLink(RsdtRbildVO rsdtRbildVO) throws Exception{
		return list("rsdtRbildDAO.selecthListRbildLink", rsdtRbildVO);
	}
	
	
	/**
	 * DAO-method for retrieving total count list of rebuild Citizens.. <br>
	 * 
	 * @param rsdtRbildVO Input item for total count list of rebuild Citizens.(RsdtRbildVO).
	 * @return int Total Count list of rebuild Citizens.
	 * @exception Exception
	 */
    public int selectListRbildLinkTotCnt(RsdtRbildVO rsdtRbildVO) {
        return (Integer)selectByPk("rsdtRbildDAO.selectListRbildLinkTotCnt", rsdtRbildVO);
    }
    

	/**
	 * DAO-method for modifying information of citizen link. <br>
	 * 
	 * @param vo Input item for modifying information of citizen link(OrgInfoVO).
	 * @return void 
	 * @exception Exception
	 */
	public void updateRbildLink(RsdtRbildVO rsdtRbildVO){
		update("rsdtRbildDAO.updateRbildLink", rsdtRbildVO);
	}


	/**
	 * DAO-method for retrieving list of rebuild Candidate. <br>
	 * 
	 * @param rsdtRbildVO Input item for retrieving list of rebuild Candidate(OrgnzVO).
	 * @return List list of rebuild Candidate
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")	
	public List<RsdtRbildVO> selectListRbildLinkCdd(RsdtRbildVO rsdtRbildVO) throws Exception{
		return list("rsdtRbildDAO.selectListRbildLinkCdd", rsdtRbildVO);
	}
	
	
	/**
	 * DAO-method for retrieving total count list of rebuild Candidate. <br>
	 * 
	 * @param rsdtRbildVO Input item for retrieving list of rebuild Candidate(RsdtRbildVO).
	 * @return int Total Count list of rebuild Candidate
	 * @exception Exception
	 */
    public int selectListRbildLinkCddTotCnt(RsdtRbildVO rsdtRbildVO) {
        return (Integer)selectByPk("rsdtRbildDAO.selectListRbildLinkCddTotCnt", rsdtRbildVO);
    }
}
