package afnid.rm.rbild.web;

/* java API */
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.code.service.OrgnzService;
import afnid.cm.code.service.OrgnzVO;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.rbild.service.RsdtRbildService;
import afnid.rm.rbild.service.RsdtRbildVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/** 
 * This Controller class processes request of resident rebuilding management biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Team moon soo kim
 * @since 2015.01.22
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           				 Revisions
 *  --------------------------------------------------------------------
 *  2015.01.22 		   moon soo kim        		             Create
 *
 * </pre>
 */

@Controller
public class RsdtRbildController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	
	@Resource(name = "rsdtRbildService")
    private RsdtRbildService service;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    @Resource(name = "lgService")
    private LgService lgService;
	
    /** orgnzService */
	@Resource(name = "orgnzService")
    private OrgnzService orgnzService; 
	
 	/**
     * Move to rebuild of citizen link screen. <br>
     *
     * @param searchVO Value-object of rebuild citizen link to be parsed request(ComDefaultVO)
     * @param rsdtMdfcVO Value-object of rebuild citizen link to be parsed request(RsdtRbildVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rbild/RsdtRbildLinkList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rbild/searchListRbildLinkView.do")
    public String searchListRbildLinkView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtRbildVo") RsdtRbildVO rsdtRbildVo,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(), rsdtRbildVo.getCurMnId());
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "rm/rbild/RsdtRbildLinkList";
    }

    /**
     * Retrieves list of rebuild Citizens.  <br>
     * 
     * @param rsdtRbildVo Value-object of rebuild Citizens to be parsed request(RsdtRbildVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "rm/rbild/RsdtRbildLinkList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rbild/searchListRbildLinkBf.do")
    public String searchListRbildLink(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtRbildVo") RsdtRbildVO rsdtRbildVo,
    		ModelMap model)
            throws Exception { 

    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("userId", user.getUserId());
    		
	    	/**Paging Setting */
    		rsdtRbildVo.setPageUnit(propertiesService.getInt("pageUnit"));
    		rsdtRbildVo.setPageSize(propertiesService.getInt("pageSize"));
	
    		List<RsdtRbildVO>  lstRbildLink = null;
    		
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(rsdtRbildVo.getPageIndex());
			paginationInfo.setRecordCountPerPage(rsdtRbildVo.getPageUnit());
			paginationInfo.setPageSize(rsdtRbildVo.getPageSize());
	
			rsdtRbildVo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			rsdtRbildVo.setLastIndex(paginationInfo.getLastRecordIndex());
			rsdtRbildVo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
			rsdtRbildVo.setRsdtNo(rsdtRbildVo.getSearchKeyword());
			RsdtRbildVO rsdtNo = service.searchRsdt(rsdtRbildVo);
			
			if(rsdtNo != null) {
				RsdtRbildVO rvokdRsdtVo = service.searchRvokdRsdt(rsdtRbildVo);
		        model.addAttribute("rvokdRsdtVo", rvokdRsdtVo);
		        
		        if(rvokdRsdtVo != null) {
		        	rsdtRbildVo.setRvokdRsdtSeqNo(rvokdRsdtVo.getRvokdRsdtSeqNo());
			        lstRbildLink = service.searchListRbildLink(rsdtRbildVo);	       
			
			        RsdtRbildVO rowtData = new RsdtRbildVO();
			        for(int i=0; i<lstRbildLink.size(); i++){
			        	rowtData = lstRbildLink.get(i);
			        	rowtData.setBfNm(rvokdRsdtVo.getRvokdNm());
			        	rowtData.setBfRsdtNoDply(rvokdRsdtVo.getRvokdRsdtNoDply());
			        }
			        
			        int totCnt = service.searchListRbildLinkTotCnt(rsdtRbildVo);
					paginationInfo.setTotalRecordCount(totCnt);	
					searchVO.setTotCnt(totCnt);
					if(totCnt == 0){			        
						model.addAttribute("resultMsg", nidMessageSource.getMessage("nRbildCtnz.msg"));
					}
		        } else {
			        searchVO.setTotCnt(0);
					paginationInfo.setTotalRecordCount(0);	        	
		        	model.addAttribute("resultMsg", nidMessageSource.getMessage("nRvokdEnid.msg"));
		        }
		        
			} else {
		        searchVO.setTotCnt(0);
				paginationInfo.setTotalRecordCount(0);	        	
	        	model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstEnid.msg"));				
			}
				
	        model.addAttribute("paginationInfo", paginationInfo);
	        model.addAttribute("lstRbildLink", lstRbildLink);
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "rm/rbild/RsdtRbildLinkList";
    }	
	
    /**
     * Retrieves list of rebuild Citizens.  <br>
     * 
     * @param rsdtRbildVo Value-object of rebuild Citizens to be parsed request(RsdtRbildVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "rm/rbild/RsdtRbildLinkList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rbild/searchListRbildLinkAf.do")
    public String searchListRbildLinkAf(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtRbildVo") RsdtRbildVO rsdtRbildVo,
    		ModelMap model)
            throws Exception { 

    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("userId", user.getUserId());
    		
	    	/**Paging Setting */
    		rsdtRbildVo.setPageUnit(propertiesService.getInt("pageUnit"));
    		rsdtRbildVo.setPageSize(propertiesService.getInt("pageSize"));
	
    		List<RsdtRbildVO>  lstRbildLink = null;
    		
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(rsdtRbildVo.getPageIndex());
			paginationInfo.setRecordCountPerPage(rsdtRbildVo.getPageUnit());
			paginationInfo.setPageSize(rsdtRbildVo.getPageSize());
	
			rsdtRbildVo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			rsdtRbildVo.setLastIndex(paginationInfo.getLastRecordIndex());
			rsdtRbildVo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
			//check eNID
			rsdtRbildVo.setRsdtNo(rsdtRbildVo.getSearchKeyword4());
			RsdtRbildVO rsdtNo = service.searchRsdt(rsdtRbildVo);
			
			//rebuild  citizen
			RsdtRbildVO rbildRsdtVo = service.searchRbildRsdt(rsdtRbildVo);
	        model.addAttribute("rbildRsdtVo", rbildRsdtVo);
	        
	        // revoked citizen
			RsdtRbildVO rvokdRsdtVo = service.searchRvokdRsdt(rsdtRbildVo);
	        model.addAttribute("rvokdRsdtVo", rvokdRsdtVo);
	        
	        if(rvokdRsdtVo != null) {	        
	        	rsdtRbildVo.setRvokdRsdtSeqNo(rvokdRsdtVo.getRvokdRsdtSeqNo());
		        lstRbildLink = service.searchListRbildLink(rsdtRbildVo);	       
		
		        RsdtRbildVO rowtData = new RsdtRbildVO();
		        for(int i=0; i<lstRbildLink.size(); i++){
		        	rowtData = lstRbildLink.get(i);
		        	rowtData.setBfNm(rvokdRsdtVo.getRvokdNm());
		        	rowtData.setBfRsdtNoDply(rvokdRsdtVo.getRvokdRsdtNoDply());		        	
		        	rowtData.setRbildYn("Y");
		        	rowtData.setChngTyp("");
		        	
		        	if (rbildRsdtVo != null){//A
			        	rowtData.setAfNm(rbildRsdtVo.getRbildNm());
			        	rowtData.setAfRsdtNoDply(rbildRsdtVo.getRbildRsdtNoDply());	
			        	
		        		//if(rbildRsdtVo.getRbildRsdtSeqNo() != null && !"".equals(rbildRsdtVo.getRbildRsdtSeqNo())) {

	        			if(!rvokdRsdtVo.getRvokdGdrCd().equals(rbildRsdtVo.getRbildGdrCd()) ){//in case of changed gender
	        				if("1".equals(rbildRsdtVo.getGdrCd())){//in case of changed male
	        					rowtData.setChngTyp("1");
	        					if( "7".equals(rowtData.getRlCd()) ){//link as mother
	        						rowtData.setRbildYn("N");
	        					}
	        				} else {//in case of changed female
	        					rowtData.setChngTyp("2");
	        					if( !"7".equals(rowtData.getRlCd()) ){//link as not mother
	        						rowtData.setRbildYn("N");
	        					}			        					
	        				}
	        			}
	        			
		        		if( !"2".equals(rowtData.getRlCd())){//in case of link as father, mother, grandfather
		        			if( Integer.parseInt(rbildRsdtVo.getRbildBthDd()) > Integer.parseInt(rowtData.getBthDd()) ){// check date of birth
		        				if(rowtData.getChngTyp() == null || "null".equals("null".equals(rowtData.getChngTyp())) || "".equals(rowtData.getChngTyp()) ){
		        					rowtData.setChngTyp("3");
		        				} else {
		        					rowtData.setChngTyp(rowtData.getChngTyp()+"3");
		        				}
		        				
		        				rowtData.setRbildYn("N"); 
		        			}
		        		}				        		 
		        		//}
		        	}//end A
		        	
		        }
		        
		        int totCnt = service.searchListRbildLinkTotCnt(rsdtRbildVo);
				paginationInfo.setTotalRecordCount(totCnt);	
				searchVO.setTotCnt(totCnt);
				if(totCnt == 0){			        
					model.addAttribute("resultMsg", nidMessageSource.getMessage("nRbildCtnz.msg"));
				}
	        } else {
		        searchVO.setTotCnt(0);
				paginationInfo.setTotalRecordCount(0);	        	
	        	model.addAttribute("resultMsg", nidMessageSource.getMessage("nRvokdEnid.msg"));
	        }
	        
	        model.addAttribute("paginationInfo", paginationInfo);
	        model.addAttribute("lstRbildLink", lstRbildLink);			

	        if(rsdtNo != null){
		        if (rbildRsdtVo == null){
			        model.addAttribute("resultMsg", nidMessageSource.getMessage("nRbildEnid.msg"));
		        }
	        } else {	        	
	        	model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstEnid.msg"));		        	
	        }
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "rm/rbild/RsdtRbildLinkList";
    }    
    
    /**
     *  Modifies information of citizen link.  <br>
     * 
     * @param rsdtRbildVo Value-object of Modifies information of citizen link to be parsed request(RsdtRbildVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "rm/rbild/RsdtRbildLinkList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rbild/modifyRbildLink.do")
    public String modifyRbildLink(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtRbildVo") RsdtRbildVO rsdtRbildVo,
    		ModelMap model)
            throws Exception {
    	try{    	
			service.modifyRbildLink(rsdtRbildVo);   
			model.addAttribute("succssMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}		
		return "forward:/rm/rbild/searchListRbildLinkAf.do";
    }
    		
    
 	/**
     * Residents move to rebuild candidate of citizen link screen. <br>
     *
     * @param searchVO Value-object of rebuild candidate  to be parsed request(ComDefaultVO)
     * @param rsdtMdfcVO Value-object of rebuild candidate  to be parsed request(RsdtRbildVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rbild/RsdtRbildLinkCddList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rbild/searchListRbildLinkCddView.do")
    public String searchListRbildLinkCddView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtRbildVo") RsdtRbildVO rsdtRbildVo,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(), rsdtRbildVo.getCurMnId());
    		
    		OrgnzVO vo = new OrgnzVO();
    		
    		if(!"00".equals(user.getOrgnzCd().substring(0,2))){
    			vo.setOrgnzCd(user.getOrgnzCd());
    			vo.setOrgnzClsCd(user.getOrgnzClsCd());
    			
    			OrgnzVO rowData = orgnzService.searchOrgnzNm(vo);
    			
    			rsdtRbildVo.setOrgnzCdNm(rowData.getOrgnzNm());
    			rsdtRbildVo.setSrchOrgnzCd(user.getOrgnzCd());
    			rsdtRbildVo.setLocalYn("Y");
    		} 
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "rm/rbild/RsdtRbildLinkCddList";
    }  
    
    /**
     * Retrieves list of rebuild Citizens.  <br>
     * 
     * @param rsdtRbildVo Value-object of rebuild Citizens to be parsed request(RsdtRbildVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "rm/rbild/RsdtRbildLinkList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rbild/searchListRbildLinkCdd.do")
    public String searchListRbildLinkCdd(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtRbildVo") RsdtRbildVO rsdtRbildVo,
    		ModelMap model)
            throws Exception { 

    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("userId", user.getUserId());
    		
	    	/**Paging Setting */
    		rsdtRbildVo.setPageUnit(propertiesService.getInt("pageUnit"));
    		rsdtRbildVo.setPageSize(propertiesService.getInt("pageSize"));
    		
	    	/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(rsdtRbildVo.getPageIndex());
			paginationInfo.setRecordCountPerPage(rsdtRbildVo.getPageUnit());
			paginationInfo.setPageSize(rsdtRbildVo.getPageSize());
	
			rsdtRbildVo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			rsdtRbildVo.setLastIndex(paginationInfo.getLastRecordIndex());
			rsdtRbildVo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		    
			if(rsdtRbildVo.getSrchOrgnzCd().length() > 3){
	            if( "00".equals(rsdtRbildVo.getSrchOrgnzCd().substring(2, 4)) ){
	            	rsdtRbildVo.setOficTye("1");
	            } else{
	            	rsdtRbildVo.setOficTye("2");
	            }
			}
		    
			List<RsdtRbildVO> lstRbildLinkCdd = service.searchListRbildLinkCdd(rsdtRbildVo);	       
	        model.addAttribute("lstRbildLinkCdd", lstRbildLinkCdd);
	        
	        int totCnt = service.searchListRbildLinkCddTotCnt(rsdtRbildVo);
			paginationInfo.setTotalRecordCount(totCnt);	
	        model.addAttribute("paginationInfo", paginationInfo);
	        
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

      	return "rm/rbild/RsdtRbildLinkCddList";
    }	    
}