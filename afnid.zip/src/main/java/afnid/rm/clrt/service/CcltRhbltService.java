package afnid.rm.clrt.service;

import java.util.List;
import java.util.Map;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service interface is biz-class of common. <br>
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2013.01.04  		BH Choi				Create
 *
 * </pre>
 */
public interface CcltRhbltService {
	
	/**
	 * Retrieves information for Citizen Revocation / Rehabilitation <br>
	 * 
	 * @param vo retrieving information of program(CcltRhbltVO).
	 * @return CcltRhbltVO
	 * @exception Exception
	 */	
	CcltRhbltVO searchRsdtInfr(CcltRhbltVO vo) throws Exception;	
	
	/**
	 * Retrieves wives Information <br>
	 * 
	 * @param vo retrieving wives Information(CcltRhbltVO).
	 * @return List<CcltRhbltVO>
	 * @exception Exception
	 */	
	List<CcltRhbltVO> searchWifeRsdtInfrForRvctgIns(CcltRhbltVO vo) throws Exception;
	
	/**	 
	 * Retrieves information of program. <br>
	 *
	 * @param vo retrieving information of program(CcltRhbltVO).
	 * @return CcltRhbltVO
	 * @exception Exception
	 */
    CcltRhbltVO searchCcltSeqNo(CcltRhbltVO vo) throws Exception;
    
	/**	 
	 * Retrieves information of program. <br>
	 *
	 * @param vo retrieving information of program(CcltRhbltVO).
	 * @return CcltRhbltVO
	 * @exception Exception
	 */
    CcltRhbltVO searchCcltInfr(CcltRhbltVO vo) throws Exception;
    
	/**	 
	 * Retrieves information of program. <br>
	 *
	 * @param vo retrieving information of program(CcltRhbltVO).
	 * @return CcltRhbltVO
	 * @exception Exception
	 */
    CcltRhbltVO searchCcltInfrUdt(CcltRhbltVO vo) throws Exception;
    
    /**	 
	 * Retrieves information of spouse. <br>
	 *
	 * @param vo retrieving information of program(CcltRhbltVO).
	 * @return List<CcltRhbltVO> information of spouse.
	 * @exception Exception
	 */
    List<CcltRhbltVO> searchSpusRsdtInfrForRvctgUdt(CcltRhbltVO vo) throws Exception;
    
    /**	 
	 * Retrieves information of spouse after approval.. <br>
	 *
	 * @param vo retrieving information of program(CcltRhbltVO).
	 * @return List<CcltRhbltVO> information of spouse.
	 * @exception Exception
	 */
    List<CcltRhbltVO> searchSpusRsdtInfrForAfAprv(CcltRhbltVO vo) throws Exception;
    
	/**	 
	 * Retrieves information of program. <br>
	 *
	 * @param vo retrieving information of program(CcltRhbltVO).
	 * @return CcltRhbltVO
	 * @exception Exception
	 */
    CcltRhbltVO searchRhbltSeqNo(CcltRhbltVO vo) throws Exception;    
    
	/**	 
	 * Retrieves information of program. <br>
	 *
	 * @param vo retrieving information of program(CcltRhbltVO).
	 * @return CcltRhbltVO 
	 * @exception Exception
	 */
    CcltRhbltVO searchRhbltInfr(CcltRhbltVO vo) throws Exception;
    
    /**	 
	 * Retrieves information of wives for rehabilitation.. <br>
	 *
	 * @param vo retrieving information of program(CcltRhbltVO).
	 * @return List<CcltRhbltVO> 
	 * @exception Exception
	 */
    List<CcltRhbltVO> searchWifeRsdtInfrForRhbltIns(CcltRhbltVO vo) throws Exception;
	
	/**	 
	 * Retrieves information of program. <br>
	 *
	 * @param vo retrieving information of program(CcltRhbltVO).
	 * @return CcltRhbltVO 
	 * @exception Exception
	 */
    CcltRhbltVO searchRhbltInfrUdt(CcltRhbltVO vo) throws Exception;
	
    /**
	 * Register information of new program. <br>
	 * 
	 * @param vo Input item for registering new Citizen Revocation(CcltRhbltVO).
	 * @return CcltRhbltVO
	 * @exception Exception
	 */
    CcltRhbltVO addCcltInfr(CcltRhbltVO vo) throws Exception;	
	
	/**
	 * Update information of Citizen Revocation <br>
	 * @param vo Input item for Update information of Citizen Revocation.(CcltRhbltVO)
	 * @return CcltRhbltVO
	 * @exception Exception
	 */
    CcltRhbltVO modifyCcltInfr(CcltRhbltVO vo) throws Exception;
    
    /**
	 * Register information of new program. <br>
	 * 
	 * @param vo Input item for registering new Citizen Rehabilitation(CcltRhbltVO).
	 * @return CcltRhbltVO 
	 * @exception Exception
	 */
    CcltRhbltVO addRhbltInfr(CcltRhbltVO vo) throws Exception;    
    
    /**
	 * Update information of Citizen Rehabilitation <br>
	 * @param vo Input item for Update information of Citizen Rehabilitation.(CcltRhbltVO)
	 * @return CcltRhbltVO
	 * @exception Exception
	 */
    CcltRhbltVO modifyRhbltInfr(CcltRhbltVO vo) throws Exception;
    
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(ccltRhbltVO).
	 * @return List 
	 * @exception Exception
	 */
	List<EgovMap> searchListCcltRhbltAprv(CcltRhbltVO vo) throws Exception;   
    
	/**
	 * Retrieves total count of program-list. <br>
	 *
	 * @param vo retrieving list of program(ccltRhbltVO).
	 * @return int 
	 * @exception Exception
	 */
	int searchListTotCntCcltRhbltAprv(CcltRhbltVO vo) throws Exception;  
	
	/**
	 * Retrieves information for Citizen Revocation approval. <br>
	 * @param vo retrieving Citizen Revocation approval.(ccltRhbltVO)
	 * @return CcltRhbltVO 
	 * @exception Exception
	 */
	CcltRhbltVO searchCcltAprv(CcltRhbltVO vo) throws Exception;	
	
	/**
	 * Retrieves information for Citizen Rehabilitation approval. <br>
	 * @param vo Input item for retrieving Citizen Rehabilitation approval.(ccltRhbltVO)
	 * @return CcltRhbltVO
	 * @exception Exception
	 */
	CcltRhbltVO searchRhbltAprv(CcltRhbltVO vo) throws Exception;
	
	/**
	 * Modifies information of Citizen Revocation / Rehabilitation. <br>
	 * 
	 * @param vo Input item for modifying Revocation / Rehabilitation.(ccltRhbltVO) 
	 * @return int
	 * @exception Exception
	 */
	int modifyCcltRhbltInfr(CcltRhbltVO vo) throws Exception;
	
	/**
	 * Approve Citizen Revocation by Team Leader. <br>
	 * 
	 * @param vo Input item for Revocation Approval.(ccltRhbltVO) 
	 * @return Map<String,String>
	 * @exception Exception
	 */
	Map<String,String> approveCcltInfr(CcltRhbltVO vo) throws Exception;	
	
	
	/**
	 * user retirement(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for user retirement(CcltRhbltVO).
	 * @return CcltRhbltVO Primary Key value of user retirement
	 * @exception Exception
	 */
	String approveCcltPkiIf(CcltRhbltVO vo) throws Exception;	
	
	/**
	 * Approve Citizen Rehabilitation by Team Leader. <br>
	 * 
	 * @param vo Input item for Rehabilitation Approval.(CcltRhbltVO) 
	 * @return void
	 * @exception Exception
	 */
	String approveRhbltInfr(CcltRhbltVO vo) throws Exception;
	
	/**
	 * user retirement(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for user retirement(CcltRhbltVO).
	 * @return CcltRhbltVO Primary Key value of user retirement
	 * @exception Exception
	 */
	String approveRhbltPkiIf(CcltRhbltVO vo) throws Exception;	
	
	/**
	 * Retrieves detail Information of Revocation citizen. <br>	 
	 *
	 * @param ccltRhbltVO Input item for retrieve detail Information of Revocation citizen(CcltRhbltVO).
	 * @return citizen detail Information of Revocation citizen
	 * @exception Exception
	 */
	public CcltRhbltVO searchCcltCfmRcpt(CcltRhbltVO ccltRhbltVO) throws Exception;
	
	/**
	 * Retrieves list of wife of Revocation citizen. <br>
	 * 
	 * @param ccltRhbltVO Input item for retrieving list of wife of Revocation citizen(CcltRhbltVO).
	 * @return List list of wife of Revocation citizene
	 * @exception Exception
	 */
	public List<CcltRhbltVO> searchListCcltSpus(CcltRhbltVO ccltRhbltVO) throws Exception;
	
	/**
	 * Retrieves detail Information of Rehabilitation citizen. <br>	 
	 *
	 * @param ccltRhbltVO Input item for retrieve detail Information of Rehabilitation citizen(CcltRhbltVO).
	 * @return citizen detail Information of Rehabilitation citizen
	 * @exception Exception
	 */
	public CcltRhbltVO searchRhbltCfmRcpt(CcltRhbltVO ccltRhbltVO) throws Exception;	
	
	/**
	 * Retrieves list of wife of Rehabilitation citizen. <br>
	 * 
	 * @param ccltRhbltVO Input item for retrieving list of wife of Rehabilitation citizen(CcltRhbltVO).
	 * @return List list of wife of Rehabilitation citizen
	 * @exception Exception
	 */
	public List<CcltRhbltVO> searchListRhbltSpus(CcltRhbltVO ccltRhbltVO) throws Exception;	
	
    /**
   	 * Retrieves list of discard information. <br>
   	 *
   	 * @param vo Input item for retrieving discard information.(CcltRhbltVO).
   	 * @return List<CcltRhbltVO>
   	 * @exception Exception
   	 */
    public List<CcltRhbltVO> searchListDrcd(CcltRhbltVO vo) throws Exception;
    
}
