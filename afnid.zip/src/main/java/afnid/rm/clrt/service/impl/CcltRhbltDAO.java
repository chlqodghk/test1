package afnid.rm.clrt.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.cm.util.service.NidStringUtil;
import afnid.rm.clrt.service.CcltRhbltVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;


/** 
 * This class is Database Access Object of common
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04`
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.04  		BH Choi         		Create
 *
 * </pre>
 */
@Repository("ccltRhbltDAO")
public class CcltRhbltDAO extends EgovAbstractDAO {
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }

	/**
	 * DAO-method for retrieving Information of program. <br>
	 *
	 * @param vo Input item for retrieving information of program(CcltRhbltVO).
	 * @return CcltRhbltVO Retrieve information of program
	 * @exception Exception
	 */
    public CcltRhbltVO selectRsdtInfr(CcltRhbltVO vo){    	
    	
    	vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
    	
    	return (CcltRhbltVO)selectByPk("ccltRhbltDAO.selectRsdtInfr", vo);
    }
    
    /**
	 * DAO-method for retrieving wives Information of program. <br>
	 *
	 * @param vo Input item for retrieving wives information of program(CcltRhbltVO).
	 * @return CcltRhbltVO Retrieve information of program
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<CcltRhbltVO> selectWifeRsdtInfrForRvctgIns(CcltRhbltVO vo){    	
    		
    	return list("ccltRhbltDAO.selectWifeRsdtInfrForRvctgIns", vo);
    }
    
   	/**
   	 * DAO-method for retrieving Information of program. <br>
   	 *
   	 * @param vo Input item for retrieving information of program(CcltRhbltVO).
   	 * @return CcltRhbltVO 
   	 * @exception Exception
   	 */
    public CcltRhbltVO selectCcltSeqNo(CcltRhbltVO vo){    	
		return (CcltRhbltVO)selectByPk("ccltRhbltDAO.selectCcltSeqNo",vo);
	}
    
   	/**
   	 * DAO-method for retrieving Information of program. <br>
   	 *
   	 * @param vo Input item for retrieving information of program(CcltRhbltVO).
   	 * @return CcltRhbltVO
   	 * @exception Exception
   	 */
    public CcltRhbltVO selectCcltInfr(CcltRhbltVO vo){    	
		return (CcltRhbltVO)selectByPk("ccltRhbltDAO.selectCcltInfr",vo);
	}
    
   	/**
   	 * DAO-method for retrieving Information of program. <br>
   	 *
   	 * @param vo Input item for retrieving information of program(CcltRhbltVO).
   	 * @return CcltRhbltVO
   	 * @exception Exception
   	 */
    public CcltRhbltVO selectCcltInfrUdt(CcltRhbltVO vo){    	
		return (CcltRhbltVO)selectByPk("ccltRhbltDAO.selectCcltInfrUdt",vo);
	}
    
    /**
   	 * DAO-method for retrieving Information of spouse. <br>
   	 *
   	 * @param vo Input item for retrieving information of spouse(CcltRhbltVO).
   	 * @return List<CcltRhbltVO>
   	 * @exception Exception
   	 */
    @SuppressWarnings("unchecked")
	public List<CcltRhbltVO> selectSpusRsdtInfrForRvctgUdt(CcltRhbltVO vo){    	
		return list("ccltRhbltDAO.selectSpusRsdtInfrForRvctgUdt",vo);
	}
    
    /**
   	 * DAO-method for retrieving Information of spouse after approval. <br>
   	 *
   	 * @param vo Input item for retrieving information of spouse (CcltRhbltVO).
   	 * @return List<CcltRhbltVO>
   	 * @exception Exception
   	 */
    @SuppressWarnings("unchecked")
	public List<CcltRhbltVO> selectSpusRsdtInfrForAfAprv(CcltRhbltVO vo){    	
		return list("ccltRhbltDAO.selectSpusRsdtInfrForAfAprv",vo);
	}
    
   	/**
   	 * DAO-method for retrieving Information of program. <br>
   	 *
   	 * @param vo Input item for retrieving information of program(CcltRhbltVO).
   	 * @return CcltRhbltVO
   	 * @exception Exception
   	 */
	public CcltRhbltVO selectRhbltSeqNo(CcltRhbltVO vo){    	
		return (CcltRhbltVO)selectByPk("ccltRhbltDAO.selectRhbltSeqNo",vo);
	}    
	
   	/**
   	 * DAO-method for retrieving Information of program. <br>
   	 *
   	 * @param vo Input item for retrieving information of program(CcltRhbltVO).
   	 * @return CcltRhbltVO
   	 * @exception Exception
   	 */
    public CcltRhbltVO selectRhbltInfr(CcltRhbltVO vo){    	
		return (CcltRhbltVO)selectByPk("ccltRhbltDAO.selectRhbltInfr",vo);
	}
    
    /**
   	 * DAO-method for retrieving Information of wives for rehabilitation. <br>
   	 *
   	 * @param vo Input item for retrieving information of program(CcltRhbltVO).
   	 * @return List<CcltRhbltVO>
   	 * @exception Exception
   	 */
    @SuppressWarnings("unchecked")
	public List<CcltRhbltVO> selectWifeRsdtInfrForRhbltIns(CcltRhbltVO vo){    	
		return list("ccltRhbltDAO.selectWifeRsdtInfrForRhbltIns",vo);
	}
	
   	/**
   	 * DAO-method for retrieving Information of program. <br>
   	 *
   	 * @param vo Input item for retrieving information of program(CcltRhbltVO).
   	 * @return String value of Cancellation sequence number
   	 * @exception Exception
   	 */
    public CcltRhbltVO selectRhbltInfrUdt(CcltRhbltVO vo){    	
		return (CcltRhbltVO)selectByPk("ccltRhbltDAO.selectRhbltInfrUdt",vo);
	} 	
	
	/**
	 * DAO-method for registering information of new program. <br>
	 * 
	 * @param vo Input item for registering of program(CcltRhbltVO).
	 * @return String
	 * @exception Exception
	 */
    public String insertCcltInfr(CcltRhbltVO vo) {
        return (String)insert("ccltRhbltDAO.insertCcltInfr", vo);
    } 
    
    /**
	 * DAO-method for registering information of new program. <br>
	 * 
	 * @param vo Input item for registering of program(CcltRhbltVO).
	 * @return void
	 * @exception Exception
	 */
    public void insertCcltMrrgInfr(CcltRhbltVO vo) {
        insert("ccltRhbltDAO.insertCcltMrrgInfr", vo);
    } 

    /**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(CcltRhbltVO).
	 * @return int
	 * @exception Exception
	 */
	public int updateCcltInfr(CcltRhbltVO vo){
		return update("ccltRhbltDAO.updateCcltInfr", vo);
	}
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(CcltRhbltVO).
	 * @return int
	 * @exception Exception
	 */
	public int updateCcltMrrgInfr(CcltRhbltVO vo){
		return update("ccltRhbltDAO.updateCcltMrrgInfr", vo);
	}
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(CcltRhbltVO).
	 * @return int restult
	 * @exception Exception
	 */
	public int updateLastCcltMrrgInfr(CcltRhbltVO vo){
		return update("ccltRhbltDAO.updateLastCcltMrrgInfr", vo);
	}
	
	/**
	 * DAO-method for delete information from RM_CCLT_MRRG_TB. <br>
	 *
	 * @param vo Input item for delete information(CcltRhbltVO).
	 * @return int result
	 * @exception Exception
	 */
	public int deleteCcltMrrgInfr(CcltRhbltVO vo) throws Exception{
		return delete("ccltRhbltDAO.deleteCcltMrrgInfr", vo);
	}
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(CcltRhbltVO).
	 * @return void
	 * @exception Exception
	 */
	public int updateRsdtMrrgCd(CcltRhbltVO vo){
		return update("ccltRhbltDAO.updateRsdtMrrgCd", vo);
	}
    
    /**
	 * DAO-method for registering information of new program. <br>
	 * 
	 * @param vo Input item for registering of program(CcltRhbltVO).
	 * @return void
	 * @exception Exception
	 */
    public void insertRhbltInfr(CcltRhbltVO vo) {
        insert("ccltRhbltDAO.insertRhbltInfr", vo);
    }    
    
    /**
	 * DAO-method for registering information of new program. <br>
	 * 
	 * @param vo Input item for registering of program(CcltRhbltVO).
	 * @return void
	 * @exception Exception
	 */
    public void insertRhbltMrrgInfr(CcltRhbltVO vo) {
        insert("ccltRhbltDAO.insertRhbltMrrgInfr", vo);
    } 
    
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(CcltRhbltVO).
	 * @return void
	 * @exception Exception
	 */
	public void updateRhbltInfr(CcltRhbltVO vo){
		update("ccltRhbltDAO.updateRhbltInfr", vo);
	} 
		
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(CcltRhbltVO).
	 * @return list Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListCcltRhbltAprv(CcltRhbltVO vo) throws Exception{		
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return list("ccltRhbltDAO.selectCcltRhbltVfyLst", vo);		
	}   
    
	/**
	 * DAO-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CcltRhbltVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListTotCntCcltRhbltAprv(CcltRhbltVO vo) {
        
    	vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
    	
    	return (Integer)selectByPk("ccltRhbltDAO.selectCcltRhbltVfyLstTotCnt", vo);
    }   
    
    /**
	 * DAO-method for retrieving information for Citizen Revocation Approval. <br>
	 * 
	 * @param vo Input item for retrieving information of Citizen Revocation Approval.(CcltRhbltVO)
	 * @return CcltRhbltVO information for Citizen Revocation Approval.
	 * @exception Exception
	 */
    public CcltRhbltVO selectCcltDtl(CcltRhbltVO vo){
    	return (CcltRhbltVO)selectByPk("ccltRhbltDAO.selectCcltDtl", vo);
    }  
    
    /**
	 * DAO-method for retrieving information for Citizen Rehabilitation Approval. <br>
	 * 
	 * @param vo Input item for retrieving information of Citizen Rehabilitation Approval.(CcltRhbltVO)
	 * @return CcltRhbltVO information for Citizen Rehabilitation Approval.
	 * @exception Exception
	 */
    public CcltRhbltVO selectRhbltDtl(CcltRhbltVO vo){
    	return (CcltRhbltVO)selectByPk("ccltRhbltDAO.selectRhbltDtl", vo);
    }
       
    /**
	 * DAO-method for modifying information of Resident Cancellation / Rehabilitation <br>
	 * 
	 * @param vo Input item for modifying Resident Cancellation / Rehabilitation (CcltRhbltVO).
	 * @return int result of update
	 * @exception Exception
	 */
    public int updateCcltRhbltInfr(CcltRhbltVO vo){    	
    	return update("ccltRhbltDAO.updateCcltRhbltInfr",vo);
    }
	
    /**
	 * DAO-method for modifying information of Citizen Revocation Approval. <br>
	 * 
	 * @param vo Input item for modifying Citizen Revocation Approval.(CcltRhbltVO).
	 * @return boolean result of update
	 * @exception Exception
	 */
    public boolean updateCcltAprv(CcltRhbltVO vo){
    	boolean result = false; 
    	int Result =  update("ccltRhbltDAO.updateCcltAprv",vo);
    	
    	if(Result == 1){
			result = true;
		}
    	return result;
    	
    }
	
    /**
	 * DAO-method for update information of Citizen. <br>
	 * 
	 * @param vo Input item for update information of Citizen.(CcltRhbltVO).
	 * @return boolean result of update
	 * @exception Exception
	 */    
    public boolean updateRsdtCcltInfr(CcltRhbltVO vo){
    	boolean result = false; 
		
		int Result =  update("ccltRhbltDAO.updateRsdtCcltInfr",vo);
		
		if(Result == 1){
			result = true;
		}
		
		return result;
    }
    
    /**
	 * DAO-method for Update Signature Data to RM_RSDT_TB. <br>
	 * 
	 * @param vo Input item for Update Signature Data.(CcltRhbltVO).
	 * @return boolean result of Updating Signature Data.
	 * @exception Exception
	 */
	public boolean updateSgntDat(CcltRhbltVO vo) throws Exception{
		
		boolean result = false; 
		int sgntResult = update("ccltRhbltDAO.updateSgntDat", vo);
			
		if(sgntResult == 1){
			result = true;
		}
		
		return result ;
	}
	
    /**
	 * DAO-method for modifying information of Citizen Rehabilitation Approval. <br>
	 * 
	 * @param vo Input item for modifying Citizen Rehabilitation Approval.(CcltRhbltVO).
	 * @return boolean result of update
	 * @exception Exception
	 */
    public boolean updateRhbltAprv(CcltRhbltVO vo){
    	boolean result = false; 
		int sgntResult = update("ccltRhbltDAO.updateRhbltAprv",vo);
			
		if(sgntResult == 1){
			result = true;
		}
		
		return result ;
    }
    
    /**
	 * DAO-method for update information of Citizen. <br>
	 * 
	 * @param vo Input item for update information of Citizen.(CcltRhbltVO).
	 * @return boolean result of update
	 * @exception Exception
	 */    
    public boolean updateRsdtRhbltInfr(CcltRhbltVO vo){
    	boolean result = false; 
		int sgntResult = update("ccltRhbltDAO.updateRsdtRhbltInfr",vo);
			
		if(sgntResult == 1){
			result = true;
		}
		
		return result ;
    }
    
    
	/**
	 * DAO-method for retrieving Information of Revocation citizen. <br>
	 *
	 * @param vo Input item for retrieving information of Revocation citizen(CcltRhbltVO).
	 * @return CcltRhbltVO Retrieve information of Revocation citizen
	 * @exception Exception
	 */
    public CcltRhbltVO selectCcltCfmRcpt(CcltRhbltVO vo){    	

    	return (CcltRhbltVO)selectByPk("ccltRhbltDAO.selectCcltCfmRcpt", vo);
    }
    
    /**
	 * DAO-method for retrieving list of wife of Revocation citizen. <br>
	 *
	 * @param vo Input item for retrieving list of wife of Revocation citizen(CcltRhbltVO).
	 * @return CcltRhbltVO Retrieve list of wife of Revocation citizen
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<CcltRhbltVO> selectListCcltSpus(CcltRhbltVO vo){    	
    	if("2".equals(vo.getGdrCd())){
    		return list("ccltRhbltDAO.selectListCcltHsbd", vo);
    	} else {
    		return list("ccltRhbltDAO.selectListCcltWife", vo);
    	}
    }
    
    
	/**
	 * DAO-method for retrieving Information of Rehabilitation citizen. <br>
	 *
	 * @param vo Input item for retrieving information of Rehabilitation citizen(CcltRhbltVO).
	 * @return CcltRhbltVO Retrieve information of Rehabilitation citizen
	 * @exception Exception
	 */
    public CcltRhbltVO selectRhbltCfmRcpt(CcltRhbltVO vo){    	
    	return (CcltRhbltVO)selectByPk("ccltRhbltDAO.selectRhbltCfmRcpt", vo);
    } 
    
    /**
	 * DAO-method for retrieving list of wife of Rehabilitation citizen. <br>
	 *
	 * @param vo Input item for retrieving list of wife of Rehabilitation citizen(CcltRhbltVO).
	 * @return CcltRhbltVO Retrieve list of wife of Rehabilitation citizen
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<CcltRhbltVO> selectListRhbltSpus(CcltRhbltVO vo){    	
    	if("2".equals(vo.getGdrCd())){
    		return list("ccltRhbltDAO.selectListRhbltHsbd", vo);
    	} else {
    		return list("ccltRhbltDAO.selectListRhbltWife", vo);
    	}    		
    	
    }
    
    /**
   	 * DAO-method for retrieving discard information. <br>
   	 *
   	 * @param vo Input item for retrieving discard information(CcltRhbltVO).
   	 * @return List<CcltRhbltVO>
   	 * @exception Exception
   	 */
    @SuppressWarnings("unchecked")
	public List<CcltRhbltVO> selectListDrcd(CcltRhbltVO vo){    	
		return list("ccltRhbltDAO.selectListDrcd",vo);
	}   
    
	/**
	 * DAO-method for registering discard Information. <br>
	 * 
	 * @param vo Input item for registering of discard Information(CcltRhbltVO).
	 * @return String
	 * @exception Exception
	 */
    public void insertDcrd(CcltRhbltVO vo) {
        insert("ccltRhbltDAO.insertDcrd", vo);
    } 
    
	/**
	 * DAO-method for delete discard information. <br>
	 *
	 * @param vo Input item for delete discard information(CcltRhbltVO).
	 * @return int result
	 * @exception Exception
	 */
	public int deleteDcrd(CcltRhbltVO vo) throws Exception{
		return delete("ccltRhbltDAO.deleteDcrd", vo);
	}
	    
	/**
	 * DAO-method for registering discard Information in RM_DCRD_TB. <br>
	 * 
	 * @param vo Input item for registering of discard Information(in RM_DCRD_TB.CcltRhbltVO).
	 * @return String
	 * @exception Exception
	 */
    public void insertDcrdTb(CcltRhbltVO vo) {
        insert("ccltRhbltDAO.insertDcrdTb", vo);
    } 
    
}
