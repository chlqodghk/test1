package afnid.rm.clrt.service;

import java.util.List;

import afnid.cm.ComDefaultVO;

public class CcltRhbltVO extends ComDefaultVO  {
	
	private static final long serialVersionUID = 1L;

	//pk
	private String rsdtSeqNo;
	private String ccltSeqNo;
	//family book no
	private String fmlyBokNo;
	//resident no
	private String rsdtNo;
	//resident number for screen dsiplay
	private String rsdtNoDp;
	//given name
	private String givNm;
	//surname
	private String surNm;
	//father name
	private String fthrGivNm;
	// grandfather name
	private String gfthrGivNm;
	//birthday
	private String bthDd;
	private String hBthDd;
	private String gBthDd;	
	//gender code
	private String gdrCd;
	
	private String mrrgCd;
	//gender code name
	private String gdrCdNm;
	//permanent address
	private String pmntAdCd;
	//current address
	private String curtAdCd;
	//resident status code
	private String rsdtStusCd;
	//CRD_STUS_CD 
	private String crdStusCd;
	//revocation date
	private String ocrncDd;
	//revocation reason code
	private String rsnCd;
	//revocation reason detail
	private String rsnDtlCt;
	//team leader confirm yn
	private String tamLedrCfmYn;
	//confirm team leader id
	private String cfmTamLedrId;
	//user id
	private String userId;
	//RGST_ORGNZ_CD
	private String rgstOrgnzCd;
	//RGST_ORGNZ_CD Name
	private String rgstOrgnzCdNm;
	//givNm+surNm
	private String name;
	
	// division
	private String keyword;
	
	//Variables for RHBLT TB
	private String rOcrncDd;
	private String rRsnCd;
	// userid, date
	private String fstRgstUserId;
	private String fstRgstDt;
	private String lstUdtUserId;
	private String lstUdtDt;
	
	//type of calendar
	private String calTye;
	private String calTye2;
	
	//name
	private String rsdtStusCdNm;
	
	//revocation date
	private String ccltDd;
	// revocation date persian type
	private String perCcltDd;
	// revocation date gregorian type
	private String greCcltDd;
	
	//use_yn rsdt_tb use yn
	private String useYn;
	
	//revocation time(death)
	private String ccltTm;
	//new nationality(Nationality Secession)
	private String newNltyCd;
	
	// certification number
	private String certNo;
	//publishing office
	private String pbctOfic;
	//rehablilitation date
	private String rhbltDd;
	// citizen approve information
	private String sgnt;
	// count of (revocation reason = nationality secession)
	private String nltySecCnt;
	//CAR_ISUCE_PLCE_CD
	private String crdIsucePlceCd;
	// ERSR_CD
	private String ersrCd;
	private String ersrCdNm;
	private String isAdult;
	private String isExp;
	private String adultAge;
	private String lgSeqNo;
	
	private String 	bfWifeMrrgCd;
	private String 	bfWifeMrrgCdNm;
	private String 	afWifeMrrgCd;
	private List<String> bfWifeMrrgCdList;
	private List<String> afWifeMrrgCdList;
	private List<String> wifeRsdtSeqNoList;
	private List<String> wifeHsbdRsdtSeqNoList;
	private List<String> hsbdWifeRsdtSeqNoList;
	private List<String> wifeStusCdList;
	private List<String> wifeErsrCdList;
	private List<String> wifeSgntList;
	private String 	bfWifeNm;
	private String 	afWifeNm;
	private String 	bfWifeRsdtSeqNo;
	private String 	afWifeRsdtSeqNo;
	private String 	bfWifeRsdtNoDp;
	private String 	afWifeRsdtNoDp;
	private String 	bfHsbdNm;
	private String 	afHsbdNm;
	private String 	bfHsbdRsdtSeqNo;
	private String 	afHsbdRsdtSeqNo;
	private String 	bfHsbdRsdtNoDp;
	private String 	afHsbdRsdtNoDp;
	private String 	frngrYn;
	private String 	bfHsbdMrrgCd;
	private String 	bfHsbdMrrgCdNm;
	private String 	afHsbdMrrgCd;
	private String 	tye;
	private String 	bfMrrgCd;
	private String 	afMrrgCd;
	private String 	spusRsdtStusCd;
	private String 	spusErsrCd;
	private String  spusRsdtSeqNo;
	private String  hsbdSgnt;
	private String	wifeStusCd;
	private String	wifeErsrCd;
	private String	wifeStusCdNm;
	private String	hsbdStusCd;
	private String	hsbdErsrCd;
	private String	hsbdStusCdNm;
	private String	spusSeqDelYn;
	
	private String fmlyBokNoDp;
	private String enNm;
	private String natLangCdNm;
	private String fthrNm;
	private String frgnLangCdNm;
	private String mthrNm;
	private String smrRsdcCdNm;
	private String gfthrNm;
	private String wtrRsdcCdNm;
	private String mrrgCdNm;
	private String ocp;
	private String bthPlceCdNm;
	private String bthNatDiv;
	private String bthNatCdNm;
	private String frgnBthCtyNm;
	private String mltSrvcCdNm;
	private String encyCdNm;
	private String dsbtCdNm;
	private String fmlyLangCdNm;
	private String poliCntrNm;
	private String pmntAdCdNm;
	private String pmntAdDtlCt; 
	private String eduCdNm;
	private String eduYn;
	private String eduLvDocYn;
	private String curtAdCdNm;
	private String curtAdDtlCt;
	private String bldTyeCdNm;
	private String bldTyeDocYn;
	private String rlgnCdNm;
	private String secdNltyCdNm;
	private String rlgnSectCdNm;
	private String rvctgRsn;
	private String rvctDd;
	private String rsnCdNm;
	private String rsdtRgstDd;
	private String rsdtRgstIdNm;
	private String cfmTamLedrIdNm;
	private String spusNm;
    private String secdNltyYn;
	private String curtAdDiv;
	private String curtAdNatCdNm;
	private String crdCltYn;
    private String dcrdSeqNo;
	
	private List<String> dcrdList;
	private String crdIsuceSrlNo;
	private String crdIsuceDd;
	private String rsdtCfmYn;
	private String aprvListTm;
	
	public String getSpusSeqDelYn() {
		return spusSeqDelYn;
	}
	public void setSpusSeqDelYn(String spusSeqDelYn) {
		this.spusSeqDelYn = spusSeqDelYn;
	}
	public List<String> getWifeHsbdRsdtSeqNoList() {
		return wifeHsbdRsdtSeqNoList;
	}
	public void setWifeHsbdRsdtSeqNoList(List<String> wifeHsbdRsdtSeqNoList) {
		this.wifeHsbdRsdtSeqNoList = wifeHsbdRsdtSeqNoList;
	}
	public List<String> getWifeStusCdList() {
		return wifeStusCdList;
	}
	public void setWifeStusCdList(List<String> wifeStusCdList) {
		this.wifeStusCdList = wifeStusCdList;
	}
	public List<String> getWifeErsrCdList() {
		return wifeErsrCdList;
	}
	public void setWifeErsrCdList(List<String> wifeErsrCdList) {
		this.wifeErsrCdList = wifeErsrCdList;
	}
	public String getWifeStusCd() {
		return wifeStusCd;
	}
	public void setWifeStusCd(String wifeStusCd) {
		this.wifeStusCd = wifeStusCd;
	}
	public String getWifeErsrCd() {
		return wifeErsrCd;
	}
	public void setWifeErsrCd(String wifeErsrCd) {
		this.wifeErsrCd = wifeErsrCd;
	}
	public String getWifeStusCdNm() {
		return wifeStusCdNm;
	}
	public void setWifeStusCdNm(String wifeStusCdNm) {
		this.wifeStusCdNm = wifeStusCdNm;
	}
	public String getHsbdStusCd() {
		return hsbdStusCd;
	}
	public void setHsbdStusCd(String hsbdStusCd) {
		this.hsbdStusCd = hsbdStusCd;
	}
	public String getHsbdErsrCd() {
		return hsbdErsrCd;
	}
	public void setHsbdErsrCd(String hsbdErsrCd) {
		this.hsbdErsrCd = hsbdErsrCd;
	}
	public String getHsbdStusCdNm() {
		return hsbdStusCdNm;
	}
	public void setHsbdStusCdNm(String hsbdStusCdNm) {
		this.hsbdStusCdNm = hsbdStusCdNm;
	}
	public String getSpusRsdtStusCd() {
		return spusRsdtStusCd;
	}
	public void setSpusRsdtStusCd(String spusRsdtStusCd) {
		this.spusRsdtStusCd = spusRsdtStusCd;
	}
	public String getSpusErsrCd() {
		return spusErsrCd;
	}
	public void setSpusErsrCd(String spusErsrCd) {
		this.spusErsrCd = spusErsrCd;
	}
	public String getHsbdSgnt() {
		return hsbdSgnt;
	}
	public void setHsbdSgnt(String hsbdSgnt) {
		this.hsbdSgnt = hsbdSgnt;
	}
	public List<String> getWifeSgntList() {
		return wifeSgntList;
	}
	public void setWifeSgntList(List<String> wifeSgntList) {
		this.wifeSgntList = wifeSgntList;
	}
	public List<String> getHsbdWifeRsdtSeqNoList() {
		return hsbdWifeRsdtSeqNoList;
	}
	public void setHsbdWifeRsdtSeqNoList(List<String> hsbdWifeRsdtSeqNoList) {
		this.hsbdWifeRsdtSeqNoList = hsbdWifeRsdtSeqNoList;
	}
	public String getSpusRsdtSeqNo() {
		return spusRsdtSeqNo;
	}
	public void setSpusRsdtSeqNo(String spusRsdtSeqNo) {
		this.spusRsdtSeqNo = spusRsdtSeqNo;
	}
	public String getBfMrrgCd() {
		return bfMrrgCd;
	}
	public void setBfMrrgCd(String bfMrrgCd) {
		this.bfMrrgCd = bfMrrgCd;
	}
	public String getAfMrrgCd() {
		return afMrrgCd;
	}
	public void setAfMrrgCd(String afMrrgCd) {
		this.afMrrgCd = afMrrgCd;
	}

	public String getTye() {
		return tye;
	}
	public void setTye(String tye) {
		this.tye = tye;
	}
	public List<String> getBfWifeMrrgCdList() {
		return bfWifeMrrgCdList;
	}
	public void setBfWifeMrrgCdList(List<String> bfWifeMrrgCdList) {
		this.bfWifeMrrgCdList = bfWifeMrrgCdList;
	}
	public List<String> getWifeRsdtSeqNoList() {
		return wifeRsdtSeqNoList;
	}
	public void setWifeRsdtSeqNoList(List<String> wifeRsdtSeqNoList) {
		this.wifeRsdtSeqNoList = wifeRsdtSeqNoList;
	}
	public String getBfHsbdMrrgCd() {
		return bfHsbdMrrgCd;
	}
	public void setBfHsbdMrrgCd(String bfHsbdMrrgCd) {
		this.bfHsbdMrrgCd = bfHsbdMrrgCd;
	}
	public String getBfHsbdMrrgCdNm() {
		return bfHsbdMrrgCdNm;
	}
	public void setBfHsbdMrrgCdNm(String bfHsbdMrrgCdNm) {
		this.bfHsbdMrrgCdNm = bfHsbdMrrgCdNm;
	}
	public String getAfHsbdMrrgCd() {
		return afHsbdMrrgCd;
	}
	public void setAfHsbdMrrgCd(String afHsbdMrrgCd) {
		this.afHsbdMrrgCd = afHsbdMrrgCd;
	}
	public String getFrngrYn() {
		return frngrYn;
	}
	public void setFrngrYn(String frngrYn) {
		this.frngrYn = frngrYn;
	}
	public List<String> getAfWifeMrrgCdList() {
		return afWifeMrrgCdList;
	}
	public void setAfWifeMrrgCdList(List<String> afWifeMrrgCdList) {
		this.afWifeMrrgCdList = afWifeMrrgCdList;
	}
	public String getMrrgCd() {
		return mrrgCd;
	}
	public void setMrrgCd(String mrrgCd) {
		this.mrrgCd = mrrgCd;
	}
	public String getBfWifeMrrgCd() {
		return bfWifeMrrgCd;
	}
	public void setBfWifeMrrgCd(String bfWifeMrrgCd) {
		this.bfWifeMrrgCd = bfWifeMrrgCd;
	}
	public String getBfWifeMrrgCdNm() {
		return bfWifeMrrgCdNm;
	}
	public void setBfWifeMrrgCdNm(String bfWifeMrrgCdNm) {
		this.bfWifeMrrgCdNm = bfWifeMrrgCdNm;
	}
	public String getAfWifeMrrgCd() {
		return afWifeMrrgCd;
	}
	public void setAfWifeMrrgCd(String afWifeMrrgCd) {
		this.afWifeMrrgCd = afWifeMrrgCd;
	}
	public String getBfWifeNm() {
		return bfWifeNm;
	}
	public void setBfWifeNm(String bfWifeNm) {
		this.bfWifeNm = bfWifeNm;
	}
	public String getAfWifeNm() {
		return afWifeNm;
	}
	public void setAfWifeNm(String afWifeNm) {
		this.afWifeNm = afWifeNm;
	}
	public String getBfWifeRsdtSeqNo() {
		return bfWifeRsdtSeqNo;
	}
	public void setBfWifeRsdtSeqNo(String bfWifeRsdtSeqNo) {
		this.bfWifeRsdtSeqNo = bfWifeRsdtSeqNo;
	}
	public String getAfWifeRsdtSeqNo() {
		return afWifeRsdtSeqNo;
	}
	public void setAfWifeRsdtSeqNo(String afWifeRsdtSeqNo) {
		this.afWifeRsdtSeqNo = afWifeRsdtSeqNo;
	}
	public String getBfWifeRsdtNoDp() {
		return bfWifeRsdtNoDp;
	}
	public void setBfWifeRsdtNoDp(String bfWifeRsdtNoDp) {
		this.bfWifeRsdtNoDp = bfWifeRsdtNoDp;
	}
	public String getAfWifeRsdtNoDp() {
		return afWifeRsdtNoDp;
	}
	public void setAfWifeRsdtNoDp(String afWifeRsdtNoDp) {
		this.afWifeRsdtNoDp = afWifeRsdtNoDp;
	}
	public String getBfHsbdNm() {
		return bfHsbdNm;
	}
	public void setBfHsbdNm(String bfHsbdNm) {
		this.bfHsbdNm = bfHsbdNm;
	}
	public String getAfHsbdNm() {
		return afHsbdNm;
	}
	public void setAfHsbdNm(String afHsbdNm) {
		this.afHsbdNm = afHsbdNm;
	}
	public String getBfHsbdRsdtSeqNo() {
		return bfHsbdRsdtSeqNo;
	}
	public void setBfHsbdRsdtSeqNo(String bfHsbdRsdtSeqNo) {
		this.bfHsbdRsdtSeqNo = bfHsbdRsdtSeqNo;
	}
	public String getAfHsbdRsdtSeqNo() {
		return afHsbdRsdtSeqNo;
	}
	public void setAfHsbdRsdtSeqNo(String afHsbdRsdtSeqNo) {
		this.afHsbdRsdtSeqNo = afHsbdRsdtSeqNo;
	}
	public String getBfHsbdRsdtNoDp() {
		return bfHsbdRsdtNoDp;
	}
	public void setBfHsbdRsdtNoDp(String bfHsbdRsdtNoDp) {
		this.bfHsbdRsdtNoDp = bfHsbdRsdtNoDp;
	}
	public String getAfHsbdRsdtNoDp() {
		return afHsbdRsdtNoDp;
	}
	public void setAfHsbdRsdtNoDp(String afHsbdRsdtNoDp) {
		this.afHsbdRsdtNoDp = afHsbdRsdtNoDp;
	}
	public String getAdultAge() {
		return adultAge;
	}
	public void setAdultAge(String adultAge) {
		this.adultAge = adultAge;
	}
	public String getRgstOrgnzCdNm() {
		return rgstOrgnzCdNm;
	}
	public void setRgstOrgnzCdNm(String rgstOrgnzCdNm) {
		this.rgstOrgnzCdNm = rgstOrgnzCdNm;
	}
	public String getIsExp() {
		return isExp;
	}
	public void setIsExp(String isExp) {
		this.isExp = isExp;
	}
	public String getIsAdult() {
		return isAdult;
	}
	public void setIsAdult(String isAdult) {
		this.isAdult = isAdult;
	}
	public String getRsdtStusCdNm() {
		return rsdtStusCdNm;
	}
	public void setRsdtStusCdNm(String rsdtStusCdNm) {
		this.rsdtStusCdNm = rsdtStusCdNm;
	}
	public String getCalTye() {
		return calTye;
	}
	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}
	/**
	 * @return the calTye2
	 */
	public String getCalTye2() {
		return calTye2;
	}
	/**
	 * @param calTye2 the calTye2 to set
	 */
	public void setCalTye2(String calTye2) {
		this.calTye2 = calTye2;
	}
	public String getFstRgstUserId() {
		return fstRgstUserId;
	}
	public void setFstRgstUserId(String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}
	public String getFstRgstDt() {
		return fstRgstDt;
	}
	public void setFstRgstDt(String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}
	public String getLstUdtUserId() {
		return lstUdtUserId;
	}
	public void setLstUdtUserId(String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}
	public String getLstUdtDt() {
		return lstUdtDt;
	}
	public void setLstUdtDt(String lstUdtDt) {
		this.lstUdtDt = lstUdtDt;
	}
	public String getSurNm() {
		return surNm;
	}
	public void setSurNm(String surNm) {
		this.surNm = surNm;
	}
	public String getFthrGivNm() {
		return fthrGivNm;
	}
	public void setFthrGivNm(String fthrGivNm) {
		this.fthrGivNm = fthrGivNm;
	}
	/**
	 * @return the rRsnCd
	 */
	public String getrOcrncDd() {
		return rOcrncDd;
	}
	/**
	 * @param rOcrncDd the rOcrncDd to set
	 */
	public void setrOcrncDd(String rOcrncDd) {
		this.rOcrncDd = rOcrncDd;
	}
	/**
	 * @return the rRsnCd
	 */
	public String getrRsnCd() {
		return rRsnCd;
	}
	/**
	 * @param rRsnCd the rRsnCd to set
	 */
	public void setrRsnCd(String rRsnCd) {
		this.rRsnCd = rRsnCd;
	}
	/**
	 * @return the keyword
	 */
	public String getKeyword() {
		return keyword;
	}
	/**
	 * @param keyword the keyword to set
	 */
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the rsdtSeqNo
	 */
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	/**
	 * @param rsdtSeqNo the rsdtSeqNo to set
	 */
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	/**
	 * @return the ccltSeqNo
	 */
	public String getCcltSeqNo() {
		return ccltSeqNo;
	}
	/**
	 * @param ccltSeqNo the ccltSeqNo to set
	 */
	public void setCcltSeqNo(String ccltSeqNo) {
		this.ccltSeqNo = ccltSeqNo;
	}
	/**
	 * @return the fmlyBokNo
	 */
	public String getFmlyBokNo() {
		return fmlyBokNo;
	}
	/**
	 * @param fmlyBokNo the fmlyBokNo to set
	 */
	public void setFmlyBokNo(String fmlyBokNo) {
		this.fmlyBokNo = fmlyBokNo;
	}
	/**
	 * @return the rsdtNo
	 */
	public String getRsdtNo() {
		return rsdtNo;
	}
	/**
	 * @param rsdtNo the rsdtNo to set
	 */
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	/**
	 * @return the givNm
	 */
	public String getGivNm() {
		return givNm;
	}
	/**
	 * @param givNm the givNm to set
	 */
	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}
	
	/**
	 * @return the gfthrGivNm
	 */
	public String getGfthrGivNm() {
		return gfthrGivNm;
	}
	/**
	 * @param gfthrGivNm the gfthrGivNm to set
	 */
	public void setGfthrGivNm(String gfthrGivNm) {
		this.gfthrGivNm = gfthrGivNm;
	}
	/**
	 * @return the bthDd
	 */
	public String getBthDd() {
		return bthDd;
	}
	/**
	 * @param bthDd the bthDd to set
	 */
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	/**
	 * @return the gdrCd
	 */
	public String getGdrCd() {
		return gdrCd;
	}
	/**
	 * @param gdrCd the gdrCd to set
	 */
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	/**
	 * @return the gdrCdNm
	 */
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	/**
	 * @param gdrCdNm the gdrCdNm to set
	 */
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	/**
	 * @return the pmntAdCd
	 */
	public String getPmntAdCd() {
		return pmntAdCd;
	}
	/**
	 * @param pmntAdCd the pmntAdCd to set
	 */
	public void setPmntAdCd(String pmntAdCd) {
		this.pmntAdCd = pmntAdCd;
	}
	/**
	 * @return the curtAdCd
	 */
	public String getCurtAdCd() {
		return curtAdCd;
	}
	/**
	 * @param curtAdCd the curtAdCd to set
	 */
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	/**
	 * @return the rstdtStusCd
	 */
	public String getRsdtStusCd() {
		return rsdtStusCd;
	}
	/**
	 * @param rstdtStusCd the rstdtStusCd to set
	 */
	public void setRsdtStusCd(String rsdtStusCd) {
		this.rsdtStusCd = rsdtStusCd;
	}
	/**
	 * @return the crdStusYn
	 */
	public String getCrdStusCd() {
		return crdStusCd;
	}
	/**
	 * @param crdStusYn the crdStusYn to set
	 */
	public void setCrdStusCd(String crdStusCd) {
		this.crdStusCd = crdStusCd;
	}
	/**
	 * @return the ocrncDd
	 */
	public String getOcrncDd() {
		return ocrncDd;
	}
	/**
	 * @param ocrncDd the ocrncDd to set
	 */
	public void setOcrncDd(String ocrncDd) {
		this.ocrncDd = ocrncDd;
	}
	/**
	 * @return the rsnCd
	 */
	public String getRsnCd() {
		return rsnCd;
	}
	/**
	 * @param rsnCd the rsnCd to set
	 */
	public void setRsnCd(String rsnCd) {
		this.rsnCd = rsnCd;
	}
	/**
	 * @return the rsnDtlCt
	 */
	public String getRsnDtlCt() {
		return rsnDtlCt;
	}
	/**
	 * @param rsnDtlCt the rsnDtlCt to set
	 */
	public void setRsnDtlCt(String rsnDtlCt) {
		this.rsnDtlCt = rsnDtlCt;
	}
	/**
	 * @return the tamLedrCfmYn
	 */
	public String getTamLedrCfmYn() {
		return tamLedrCfmYn;
	}
	/**
	 * @param tamLedrCfmYn the tamLedrCfmYn to set
	 */
	public void setTamLedrCfmYn(String tamLedrCfmYn) {
		this.tamLedrCfmYn = tamLedrCfmYn;
	}
	/**
	 * @return the cfmTamLedrId
	 */
	public String getCfmTamLedrId() {
		return cfmTamLedrId;
	}
	/**
	 * @param cfmTamLedrId the cfmTamLedrId to set
	 */
	public void setCfmTamLedrId(String cfmTamLedrId) {
		this.cfmTamLedrId = cfmTamLedrId;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the rgstOrgnzCd
	 */
	public String getRgstOrgnzCd() {
		return rgstOrgnzCd;
	}
	/**
	 * @param rgstOrgnzCd the rgstOrgnzCd to set
	 */
	public void setRgstOrgnzCd(String rgstOrgnzCd) {
		this.rgstOrgnzCd = rgstOrgnzCd;
	}
	/**
	 * @return the rsdtNoDp
	 */
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	/**
	 * @param rsdtNoDp the rsdtNoDp to set
	 */
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	/**
	 * @return the useYn
	 */
	public String getUseYn() {
		return useYn;
	}
	/**
	 * @param useYn the useYn to set
	 */
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	/**
	 * @return the ccltDd
	 */
	public String getCcltDd() {
		return ccltDd;
	}
	/**
	 * @param ccltDd the ccltDd to set
	 */
	public void setCcltDd(String ccltDd) {
		this.ccltDd = ccltDd;
	}
	/**
	 * @return the perCcltDd
	 */
	public String getPerCcltDd() {
		return perCcltDd;
	}
	/**
	 * @param perCcltDd the perCcltDd to set
	 */
	public void setPerCcltDd(String perCcltDd) {
		this.perCcltDd = perCcltDd;
	}
	/**
	 * @return the greCcltDd
	 */
	public String getGreCcltDd() {
		return greCcltDd;
	}
	/**
	 * @param greCcltDd the greCcltDd to set
	 */
	public void setGreCcltDd(String greCcltDd) {
		this.greCcltDd = greCcltDd;
	}
	/**
	 * @return the ccltTm
	 */
	public String getCcltTm() {
		return ccltTm;
	}
	/**
	 * @param ccltTm the ccltTm to set
	 */
	public void setCcltTm(String ccltTm) {
		this.ccltTm = ccltTm;
	}
	/**
	 * @return the newNltyCd
	 */
	public String getNewNltyCd() {
		return newNltyCd;
	}
	/**
	 * @param newNltyCd the newNltyCd to set
	 */
	public void setNewNltyCd(String newNltyCd) {
		this.newNltyCd = newNltyCd;
	}
	/**
	 * @return the certNo
	 */
	public String getCertNo() {
		return certNo;
	}
	/**
	 * @param certNo the certNo to set
	 */
	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}
	/**
	 * @return the pbctOfic
	 */
	public String getPbctOfic() {
		return pbctOfic;
	}
	/**
	 * @param pbctOfic the pbctOfic to set
	 */
	public void setPbctOfic(String pbctOfic) {
		this.pbctOfic = pbctOfic;
	}
	/**
	 * @return the rhbltDd
	 */
	public String getRhbltDd() {
		return rhbltDd;
	}
	/**
	 * @param rhbltDd the rhbltDd to set
	 */
	public void setRhbltDd(String rhbltDd) {
		this.rhbltDd = rhbltDd;
	}

	/**
	 * @return the sgnt
	 */
	public String getSgnt() {
		return sgnt;
	}
	/**
	 * @param sgnt the sgnt to set
	 */
	public void setSgnt(String sgnt) {
		this.sgnt = sgnt;
	}
	/**
	 * @return the nltySecCnt
	 */
	public String getNltySecCnt() {
		return nltySecCnt;
	}
	/**
	 * @param nltySecCnt the nltySecCnt to set
	 */
	public void setNltySecCnt(String nltySecCnt) {
		this.nltySecCnt = nltySecCnt;
	}
	/**
	 * @return the crdIsucePlceCd
	 */
	public String getCrdIsucePlceCd() {
		return crdIsucePlceCd;
	}
	/**
	 * @param crdIsucePlceCd the crdIsucePlceCd to set
	 */
	public void setCrdIsucePlceCd(String crdIsucePlceCd) {
		this.crdIsucePlceCd = crdIsucePlceCd;
	}
	/**
	 * @return the ersrCd
	 */
	public String getErsrCd() {
		return ersrCd;
	}
	/**
	 * @param ersrCd the ersrCd to set
	 */
	public void setErsrCd(String ersrCd) {
		this.ersrCd = ersrCd;
	}
	/**
	 * @return the ersrCdNm
	 */
	public String getErsrCdNm() {
		return ersrCdNm;
	}
	/**
	 * @param ersrCdNm the ersrCdNm to set
	 */
	public void setErsrCdNm(String ersrCdNm) {
		this.ersrCdNm = ersrCdNm;
	}
	public String getLgSeqNo() {
		return lgSeqNo;
	}
	public void setLgSeqNo(String lgSeqNo) {
		this.lgSeqNo = lgSeqNo;
	}
	public String getFmlyBokNoDp() {
		return fmlyBokNoDp;
	}
	public void setFmlyBokNoDp(String fmlyBokNoDp) {
		this.fmlyBokNoDp = fmlyBokNoDp;
	}
	public String getNatLangCdNm() {
		return natLangCdNm;
	}
	public void setNatLangCdNm(String natLangCdNm) {
		this.natLangCdNm = natLangCdNm;
	}
	public String getFthrNm() {
		return fthrNm;
	}
	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}
	public String getFrgnLangCdNm() {
		return frgnLangCdNm;
	}
	public void setFrgnLangCdNm(String frgnLangCdNm) {
		this.frgnLangCdNm = frgnLangCdNm;
	}
	public String getMthrNm() {
		return mthrNm;
	}
	public void setMthrNm(String mthrNm) {
		this.mthrNm = mthrNm;
	}
	public String getSmrRsdcCdNm() {
		return smrRsdcCdNm;
	}
	public void setSmrRsdcCdNm(String smrRsdcCdNm) {
		this.smrRsdcCdNm = smrRsdcCdNm;
	}
	public String getGfthrNm() {
		return gfthrNm;
	}
	public void setGfthrNm(String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}
	public String getWtrRsdcCdNm() {
		return wtrRsdcCdNm;
	}
	public void setWtrRsdcCdNm(String wtrRsdcCdNm) {
		this.wtrRsdcCdNm = wtrRsdcCdNm;
	}
	public String getMrrgCdNm() {
		return mrrgCdNm;
	}
	public void setMrrgCdNm(String mrrgCdNm) {
		this.mrrgCdNm = mrrgCdNm;
	}
	public String getOcp() {
		return ocp;
	}
	public void setOcp(String ocp) {
		this.ocp = ocp;
	}
	public String getBthPlceCdNm() {
		return bthPlceCdNm;
	}
	public void setBthPlceCdNm(String bthPlceCdNm) {
		this.bthPlceCdNm = bthPlceCdNm;
	}
	public String getBthNatDiv() {
		return bthNatDiv;
	}
	public void setBthNatDiv(String bthNatDiv) {
		this.bthNatDiv = bthNatDiv;
	}
	public String getBthNatCdNm() {
		return bthNatCdNm;
	}
	public void setBthNatCdNm(String bthNatCdNm) {
		this.bthNatCdNm = bthNatCdNm;
	}
	public String getFrgnBthCtyNm() {
		return frgnBthCtyNm;
	}
	public void setFrgnBthCtyNm(String frgnBthCtyNm) {
		this.frgnBthCtyNm = frgnBthCtyNm;
	}
	public String getMltSrvcCdNm() {
		return mltSrvcCdNm;
	}
	public void setMltSrvcCdNm(String mltSrvcCdNm) {
		this.mltSrvcCdNm = mltSrvcCdNm;
	}
	public String getEncyCdNm() {
		return encyCdNm;
	}
	public void setEncyCdNm(String encyCdNm) {
		this.encyCdNm = encyCdNm;
	}
	public String getDsbtCdNm() {
		return dsbtCdNm;
	}
	public void setDsbtCdNm(String dsbtCdNm) {
		this.dsbtCdNm = dsbtCdNm;
	}
	public String getFmlyLangCdNm() {
		return fmlyLangCdNm;
	}
	public void setFmlyLangCdNm(String fmlyLangCdNm) {
		this.fmlyLangCdNm = fmlyLangCdNm;
	}
	public String getPoliCntrNm() {
		return poliCntrNm;
	}
	public void setPoliCntrNm(String poliCntrNm) {
		this.poliCntrNm = poliCntrNm;
	}
	public String getPmntAdCdNm() {
		return pmntAdCdNm;
	}
	public void setPmntAdCdNm(String pmntAdCdNm) {
		this.pmntAdCdNm = pmntAdCdNm;
	}
	public String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}
	public void setPmntAdDtlCt(String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}
	public String getEduCdNm() {
		return eduCdNm;
	}
	public void setEduCdNm(String eduCdNm) {
		this.eduCdNm = eduCdNm;
	}
	public String getEduYn() {
		return eduYn;
	}
	public void setEduYn(String eduYn) {
		this.eduYn = eduYn;
	}
	public String getEduLvDocYn() {
		return eduLvDocYn;
	}
	public void setEduLvDocYn(String eduLvDocYn) {
		this.eduLvDocYn = eduLvDocYn;
	}
	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}
	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}
	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}
	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}
	public String getBldTyeCdNm() {
		return bldTyeCdNm;
	}
	public void setBldTyeCdNm(String bldTyeCdNm) {
		this.bldTyeCdNm = bldTyeCdNm;
	}
	public String getBldTyeDocYn() {
		return bldTyeDocYn;
	}
	public void setBldTyeDocYn(String bldTyeDocYn) {
		this.bldTyeDocYn = bldTyeDocYn;
	}
	public String getRlgnCdNm() {
		return rlgnCdNm;
	}
	public void setRlgnCdNm(String rlgnCdNm) {
		this.rlgnCdNm = rlgnCdNm;
	}
	public String getSecdNltyCdNm() {
		return secdNltyCdNm;
	}
	public void setSecdNltyCdNm(String secdNltyCdNm) {
		this.secdNltyCdNm = secdNltyCdNm;
	}
	public String getRlgnSectCdNm() {
		return rlgnSectCdNm;
	}
	public void setRlgnSectCdNm(String rlgnSectCdNm) {
		this.rlgnSectCdNm = rlgnSectCdNm;
	}
	public String getRvctgRsn() {
		return rvctgRsn;
	}
	public void setRvctgRsn(String rvctgRsn) {
		this.rvctgRsn = rvctgRsn;
	}
	public String getRvctDd() {
		return rvctDd;
	}
	public void setRvctDd(String rvctDd) {
		this.rvctDd = rvctDd;
	}
	public String getRsnCdNm() {
		return rsnCdNm;
	}
	public void setRsnCdNm(String rsnCdNm) {
		this.rsnCdNm = rsnCdNm;
	}
	public String getRsdtRgstDd() {
		return rsdtRgstDd;
	}
	public void setRsdtRgstDd(String rsdtRgstDd) {
		this.rsdtRgstDd = rsdtRgstDd;
	}
	public String getRsdtRgstIdNm() {
		return rsdtRgstIdNm;
	}
	public void setRsdtRgstIdNm(String rsdtRgstIdNm) {
		this.rsdtRgstIdNm = rsdtRgstIdNm;
	}
	public String getCfmTamLedrIdNm() {
		return cfmTamLedrIdNm;
	}
	public void setCfmTamLedrIdNm(String cfmTamLedrIdNm) {
		this.cfmTamLedrIdNm = cfmTamLedrIdNm;
	}
	public String getEnNm() {
		return enNm;
	}
	public void setEnNm(String enNm) {
		this.enNm = enNm;
	}
	public String getSpusNm() {
		return spusNm;
	}
	public void setSpusNm(String spusNm) {
		this.spusNm = spusNm;
	}
	public String getSecdNltyYn() {
		return secdNltyYn;
	}
	public void setSecdNltyYn(String secdNltyYn) {
		this.secdNltyYn = secdNltyYn;
	}
	public String getCurtAdDiv() {
		return curtAdDiv;
	}
	public void setCurtAdDiv(String curtAdDiv) {
		this.curtAdDiv = curtAdDiv;
	}
	public String getCurtAdNatCdNm() {
		return curtAdNatCdNm;
	}
	public void setCurtAdNatCdNm(String curtAdNatCdNm) {
		this.curtAdNatCdNm = curtAdNatCdNm;
	}
	public String gethBthDd() {
		return hBthDd;
	}
	public void sethBthDd(String hBthDd) {
		this.hBthDd = hBthDd;
	}
	public String getgBthDd() {
		return gBthDd;
	}
	public void setgBthDd(String gBthDd) {
		this.gBthDd = gBthDd;
	}
	public String getCrdCltYn() {
		return crdCltYn;
	}
	public void setCrdCltYn(String crdCltYn) {
		this.crdCltYn = crdCltYn;
	}
	public String getCrdIsuceSrlNo() {
		return crdIsuceSrlNo;
	}
	public void setCrdIsuceSrlNo(String crdIsuceSrlNo) {
		this.crdIsuceSrlNo = crdIsuceSrlNo;
	}
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public List<String> getDcrdList() {
		return dcrdList;
	}
	public void setDcrdList(List<String> dcrdList) {
		this.dcrdList = dcrdList;
	}
	public String getDcrdSeqNo() {
		return dcrdSeqNo;
	}
	public void setDcrdSeqNo(String dcrdSeqNo) {
		this.dcrdSeqNo = dcrdSeqNo;
	}
	public String getRsdtCfmYn() {
		return rsdtCfmYn;
	}
	public void setRsdtCfmYn(String rsdtCfmYn) {
		this.rsdtCfmYn = rsdtCfmYn;
	}
	public String getAprvListTm() {
		return aprvListTm;
	}
	public void setAprvListTm(String aprvListTm) {
		this.aprvListTm = aprvListTm;
	}


	
}
