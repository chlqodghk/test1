package afnid.rm.clrt.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.pkiif.cpki.CpkiRmWS;
import afnid.pkiif.cpki.CpkiRmWSService;
import afnid.pkiif.cpki.PkiRsWsResponse;
import afnid.rm.clrt.service.CcltRhbltService;
import afnid.rm.clrt.service.CcltRhbltVO;
import afnid.rm.crd.service.CrdFndService;
import afnid.rm.rsdt.service.RsdtInfrService;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Service("ccltRhbltService")
public class CcltRhbltServiceImpl extends AbstractServiceImpl implements CcltRhbltService {
	/** CcltRhbltDAO */
    @Resource(name="ccltRhbltDAO")
    private CcltRhbltDAO dao;
    /** RsdtInfrDAO */
    @Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtDao;
    /** LgDAO */
    @Resource(name="lgDAO")
    private LgDAO lgDao;
    /** RsdtInfrService */
    @Resource(name = "rsdtInfoService")
    private RsdtInfrService rsdtInfrService;
    
    /** crdFndService */
   	@Resource(name = "crdFndService")
       private CrdFndService crdFndService;
   	
   	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
	/**
	 * Biz-method for retrieving information of Citizen <br>
	 * 
	 * @param vo Input item for retrieving Citizen Revocation information of program.(CcltRhbltVO)
	 * @return CcltRhbltVO
	 * @exception Exception
	 */	
	public CcltRhbltVO searchRsdtInfr(CcltRhbltVO vo) throws Exception {
		return dao.selectRsdtInfr(vo);
	}
	
   	/**
   	 * Biz-method for retrieving information of Revocation table. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CcltRhbltVO).
   	 * @return CcltRhbltVO
   	 * @exception Exception
   	 */
    public CcltRhbltVO searchCcltSeqNo(CcltRhbltVO vo) throws Exception {
		return dao.selectCcltSeqNo(vo);
	}

   	/**
   	 * Biz-method for retrieving information of Citizen for Revocation new regstration. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CcltRhbltVO).
   	 * @return CcltRhbltVO
   	 * @exception Exception
   	 */
    public CcltRhbltVO searchCcltInfr(CcltRhbltVO vo) throws Exception {
		return dao.selectCcltInfr(vo);
	}
    
    /**
   	 * Biz-method for retrieving wives Information. <br>
   	 *
   	 * @param vo Input item for retrieving wives Information.(CcltRhbltVO).
   	 * @return List<CcltRhbltVO>
   	 * @exception Exception
   	 */
    public List<CcltRhbltVO> searchWifeRsdtInfrForRvctgIns(CcltRhbltVO vo) throws Exception {
		return dao.selectWifeRsdtInfrForRvctgIns(vo);
	}

   	/**
   	 * Biz-method for retrieving information of Citizen for Revocation modify. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CcltRhbltVO).
   	 * @return CcltRhbltVO
   	 * @exception Exception
   	 */
    public CcltRhbltVO searchCcltInfrUdt(CcltRhbltVO vo) throws Exception {
		return dao.selectCcltInfrUdt(vo);
	}
    
    /**
   	 * Biz-method for retrieving information of spouse. <br>
   	 *
   	 * @param vo Input item for retrieving list of spouse(CcltRhbltVO).
   	 * @return List<CcltRhbltVO>
   	 * @exception Exception
   	 */
    public List<CcltRhbltVO> searchSpusRsdtInfrForRvctgUdt(CcltRhbltVO vo) throws Exception {
		return dao.selectSpusRsdtInfrForRvctgUdt(vo);
	}
    
    /**
   	 * Biz-method for retrieving information of spouse after approval. <br>
   	 *
   	 * @param vo Input item for retrieving list of spouse(CcltRhbltVO).
   	 * @return List<CcltRhbltVO>
   	 * @exception Exception
   	 */
    public List<CcltRhbltVO> searchSpusRsdtInfrForAfAprv(CcltRhbltVO vo) throws Exception {
		return dao.selectSpusRsdtInfrForAfAprv(vo);
	}
    
   	/**
   	 * Biz-method for retrieving information of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CcltRhbltVO).
   	 * @return CcltRhbltVO
   	 * @exception Exception
   	 */
    public CcltRhbltVO searchRhbltSeqNo(CcltRhbltVO vo) throws Exception {
		return dao.selectRhbltSeqNo(vo);
	}    
 
   	/**
   	 * Biz-method for retrieving information of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CcltRhbltVO).
   	 * @return CcltRhbltVO
   	 * @exception Exception
   	 */
    public CcltRhbltVO searchRhbltInfr(CcltRhbltVO vo) throws Exception {
		return dao.selectRhbltInfr(vo);
	}
    
    /**
   	 * Biz-method for retrieving information of wives for rehabilitation. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CcltRhbltVO).
   	 * @return List<CcltRhbltVO>
   	 * @exception Exception
   	 */
    public List<CcltRhbltVO> searchWifeRsdtInfrForRhbltIns(CcltRhbltVO vo) throws Exception {
		return dao.selectWifeRsdtInfrForRhbltIns(vo);
	}
    
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CcltRhbltVO).
   	 * @return CcltRhbltVO
   	 * @exception Exception
   	 */
    public CcltRhbltVO searchRhbltInfrUdt(CcltRhbltVO vo) throws Exception {
		return dao.selectRhbltInfrUdt(vo);   
    }
    
	/**
	 * Biz-method for Register information of new program. <br>
	 * 
	 * @param vo Input item for registering new program.(CcltRhbltVO)
	 * @exception Exception
	 */
    public CcltRhbltVO addCcltInfr(CcltRhbltVO vo) throws Exception {		
		String ccltSeqNo = dao.insertCcltInfr(vo);
		vo.setCcltSeqNo(ccltSeqNo);
		String gdrCd = vo.getGdrCd();
		
		List<String> dcrdList = vo.getDcrdList();
		
		if(dcrdList != null){
			String[] rowData = null;
			for(int i = 0; i<dcrdList.size(); i++){
				rowData = dcrdList.get(i).split(":");
				log.debug("==========================================================");
				log.debug("rowData[0] : " + rowData[0]);
				log.debug("rowData[1] : " + rowData[1]);
				log.debug("==========================================================");
				vo.setCrdIsuceSrlNo(rowData[0]);
				vo.setCrdIsuceDd(rowData[1]);
				dao.insertDcrd(vo);
			}
		}
		
		if("1".equals(gdrCd)){
			List<String> wifeRsdtSeqNoList = vo.getWifeRsdtSeqNoList();
			List<String> bfWifeMrrgCdList = vo.getBfWifeMrrgCdList();
			List<String> afWifeMrrgCdList = vo.getAfWifeMrrgCdList();
			vo.setTye("1");
			if(wifeRsdtSeqNoList != null){
				
				for(int i = 0; i<wifeRsdtSeqNoList.size(); i++){
					vo.setSpusRsdtSeqNo(wifeRsdtSeqNoList.get(i));
					vo.setBfMrrgCd(bfWifeMrrgCdList.get(i));
					vo.setAfMrrgCd(afWifeMrrgCdList.get(i));
					dao.insertCcltMrrgInfr(vo);
				}
			}	
		}else{
			String bfHsbdRsdtSeqNo = vo.getBfHsbdRsdtSeqNo();
			String bfHsbdMrrgCd = vo.getBfHsbdMrrgCd();
			String afHsbdMrrgCd = vo.getAfHsbdMrrgCd();
			if(null != bfHsbdRsdtSeqNo && !"".equals(bfHsbdRsdtSeqNo)){
				vo.setTye("1");
				vo.setSpusRsdtSeqNo(bfHsbdRsdtSeqNo);
				vo.setBfMrrgCd(bfHsbdMrrgCd);
				vo.setAfMrrgCd(afHsbdMrrgCd);
				dao.insertCcltMrrgInfr(vo);
			}
		}
    	return vo;
	}    
    
	/**
	 * Biz-method for Update information of Citizen Revocation <br>
	 * @param vo Input item for Update information of Citizen Revocation.(CcltRhbltVO)
	 * @return void
	 * @exception Exception
	 */
    public CcltRhbltVO modifyCcltInfr(CcltRhbltVO vo) throws Exception {
		int result = dao.updateCcltInfr(vo);
		
		if(result != 1){
			throw processException( "udtFail.msg");
		}
		
		dao.deleteDcrd(vo);
		
		List<String> dcrdList = vo.getDcrdList();
		
		if(dcrdList != null){
			String[] rowData = null;
			for(int i = 0; i<dcrdList.size(); i++){
				rowData = dcrdList.get(i).split(":");
				log.debug("==========================================================");
				log.debug("rowData[0] : " + rowData[0]);
				log.debug("rowData[1] : " + rowData[1]);
				log.debug("==========================================================");
				vo.setCrdIsuceSrlNo(rowData[0]);
				vo.setCrdIsuceDd(rowData[1]);
				dao.insertDcrd(vo);
			}
		}
		
		String gdrCd = vo.getGdrCd();
		
		if("1".equals(gdrCd)){
			List<String> wifeRsdtSeqNoList = vo.getWifeRsdtSeqNoList();
			List<String> afWifeMrrgCdList = vo.getAfWifeMrrgCdList();
			if(wifeRsdtSeqNoList != null){
				int wifeResult = 0;
				for(int i = 0; i<wifeRsdtSeqNoList.size(); i++){
					vo.setSpusRsdtSeqNo(wifeRsdtSeqNoList.get(i));
					vo.setAfMrrgCd(afWifeMrrgCdList.get(i));
					wifeResult = dao.updateCcltMrrgInfr(vo);
					
					if(wifeResult != 1){
						throw processException( "udtFail.msg");
					}
					wifeResult = 0;
				}
				
			}	
		}else{
			String bfHsbdRsdtSeqNo = vo.getBfHsbdRsdtSeqNo();
			String afHsbdMrrgCd = vo.getAfHsbdMrrgCd();
			
			if(null != bfHsbdRsdtSeqNo && !"".equals(bfHsbdRsdtSeqNo)){
				vo.setSpusRsdtSeqNo(bfHsbdRsdtSeqNo);
				vo.setAfMrrgCd(afHsbdMrrgCd);
				int hsbdResult = dao.updateCcltMrrgInfr(vo);
				
				if(hsbdResult != 1){
					throw processException( "udtFail.msg");
				}
			}
		}
		
		return vo;
	}     
    
	/**
	 * Biz-method for Register information of new program. <br>
	 * 
	 * @param vo Input item for registering new program.(CcltRhbltVO)
	 * @exception Exception
	 */
    public CcltRhbltVO addRhbltInfr(CcltRhbltVO vo) throws Exception {
		dao.insertRhbltInfr(vo);
    	return vo;
	}
    
	/**
	 * Biz-method for Update information of Citizen Rehabilitation <br>
	 * @param vo Input item for Update information of Citizen Rehabilitation.(CcltRhbltVO)
	 * @return void
	 * @exception Exception
	 */
    public CcltRhbltVO modifyRhbltInfr(CcltRhbltVO vo) throws Exception {
    	dao.updateRhbltInfr(vo);
		return vo;	
	}
    
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CcltRhbltVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */    
    public List<EgovMap> searchListCcltRhbltAprv(CcltRhbltVO vo) throws Exception{    	
    	return dao.selectListCcltRhbltAprv(vo);
    }    
    
  	/**
	 * Biz-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CcltRhbltVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
   	public int searchListTotCntCcltRhbltAprv(CcltRhbltVO vo) throws Exception {
        return dao.selectListTotCntCcltRhbltAprv(vo);
	}    
    
	/**
	 * Biz-method for retrieving information for Citizen Revocation <br>
	 * 
	 * @param vo Input item for retrieving information of Citizen Revocation.(CcltRhbltVO)
	 * @return CcltRhbltVO information for Citizen Revocation.
	 * @exception Exception
	 */
	public CcltRhbltVO searchCcltAprv(CcltRhbltVO vo) throws Exception {		
		return dao.selectCcltDtl(vo);
	}     
    
	/**
	 * Biz-method for retrieving information for Citizen Rehabilitation. <br>
	 * 
	 * @param vo Input item for retrieving information of Citizen Rehabilitation.(CcltRhbltVO)
	 * @return CcltRhbltVO information for Citizen Rehabilitation.
	 * @exception Exception
	 */
	public CcltRhbltVO searchRhbltAprv(CcltRhbltVO vo) throws Exception {		
		return dao.selectRhbltDtl(vo);
	}     
    
	/**
	 * Biz-method for modify of Citizen Revocation / Rehabilitation. <br>
	 * 
	 * @param vo Input item for modify of Revocation / Rehabilitation.(CcltRhbltVO)
	 * @return int result of update
	 * @exception Exception
	 */
	public int modifyCcltRhbltInfr(CcltRhbltVO vo) throws Exception {		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
		vo.setUseLangCd(user.getUseLangCd());	
		String userId = user.getUserId();    			    		
		
		vo.setUserId( userId );
		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
		vo.setRgstOrgnzCd( orgnzCd );
		
		vo.setOcrncDd( vo.getOcrncDd().replace("-", "") );
		
		if( "1".equals(vo.getRsnCd()) && "".equals(vo.getCcltTm())){    			
			vo.setCcltTm("000000");    			
		}
		
		if("CCLT".equals(vo.getKeyword()) && "1".equals(vo.getRsnCd())){
			vo.setNewNltyCd("");
				
		} 
		
		int result = dao.updateCcltRhbltInfr(vo);
		
		if(result != 1){
			throw processException( "udtFail.msg");
		}
		
		if("CCLT".equals(vo.getKeyword())){
			String gdrCd = vo.getGdrCd();
			vo.setLstUdtUserId(userId);
			
			vo.setCalTye(vo.getSearchKeyword8());	
			dao.deleteDcrd(vo);
			
			List<String> dcrdList = vo.getDcrdList();
			
			if(dcrdList != null){
				String[] rowData = null;
				for(int i = 0; i<dcrdList.size(); i++){
					rowData = dcrdList.get(i).split(":");
					log.debug("==========================================================");
					log.debug("rowData[0] : " + rowData[0]);
					log.debug("rowData[1] : " + rowData[1]);
					log.debug("==========================================================");
					vo.setCrdIsuceSrlNo(rowData[0]);
					vo.setCrdIsuceDd(rowData[1]);
					dao.insertDcrd(vo);
				}
			}
			
			if("1".equals(gdrCd)){
				List<String> wifeRsdtSeqNoList = vo.getWifeRsdtSeqNoList();
				List<String> afWifeMrrgCdList = vo.getAfWifeMrrgCdList();
				if(wifeRsdtSeqNoList != null){
					
					for(int i = 0; i<wifeRsdtSeqNoList.size(); i++){
						vo.setSpusRsdtSeqNo(wifeRsdtSeqNoList.get(i));
						vo.setAfMrrgCd(afWifeMrrgCdList.get(i));
						int wifeResult = dao.updateCcltMrrgInfr(vo);
						
						if(wifeResult != 1){
							throw processException( "udtFail.msg");
						}
					}
					
				}	
			}else{
				String bfHsbdRsdtSeqNo = vo.getBfHsbdRsdtSeqNo();
				String afHsbdMrrgCd = vo.getAfHsbdMrrgCd();
				
				if(null != bfHsbdRsdtSeqNo && !"".equals(bfHsbdRsdtSeqNo)){
					vo.setSpusRsdtSeqNo(bfHsbdRsdtSeqNo);
					vo.setAfMrrgCd(afHsbdMrrgCd);
					int hsbdResult = dao.updateCcltMrrgInfr(vo);
					
					if(hsbdResult != 1){
						throw processException( "udtFail.msg");
					}
				}
			}
		}
		
		return result;
	}    
	
	/**
	 * Biz-method for approval of Citizen Revocation / Rehabilitation . <br>
	 * 
	 * @param vo Input item for approval of Revocation / Rehabilitation.(CcltRhbltVO)
	 * @exception Exception
	 */
	public Map<String,String> approveCcltInfr(CcltRhbltVO vo) throws Exception {		
		int result = modifyCcltRhbltInfr(vo);
		if(result != 1){
			throw processException( "udtFail.msg");
		}
		
		Map<String,String> map = new HashMap<String,String>(); 
		String lgSeqNo ="";
		
		//rm_rsdt_tb history 
		rsdtDao.insertRsdtInfrHst(vo.getRsdtSeqNo(), vo.getUserId() );
		
		//approval
		boolean ccltResult = dao.updateCcltAprv(vo);
		
		//rm_rsdt_tb update
		boolean rsdtResult = dao.updateRsdtCcltInfr( vo );
		
		if(!ccltResult || !rsdtResult){
			throw processException( "udtFail.msg");
		}
		
		//Update Signature Data to RM_RSDT_TB
		rsdtInfrService.updateDigitalSgnt(vo.getRsdtSeqNo(), vo.getSgnt(), "6");
		
		
		//get PKI cert issuance count
		int crtisuceCn = rsdtInfrService.searchPkiCrtIsuceCn(vo.getRsdtSeqNo());
		
		//Check Adult for PKI
		if(0 < crtisuceCn){
			String enid = vo.getRsdtNo();	
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		    
		    //Insert PKI log
		    lgSeqNo=lgDao.insertPubKeyIfLg(user.getUserId(), enid, "4", "1", "6", "");
		    
			 
		}
		map.put("lgSeqNo", lgSeqNo);
		
		//card discard
		if("Y".equals(vo.getCrdCltYn())){
			
		}
		
		String dsuseMsg = "";
		StringBuffer strBf = new StringBuffer();
		List<String> OrgList =crdFndService.modifyCrdFndPrcssStus(vo.getRsdtNo(), "2", "", "44");
		for(int i=0; i < OrgList.size(); i++){
			if(i == 0){
				strBf.append(OrgList.get(i));
			}else{
				strBf.append(", ").append(OrgList.get(i));
			}	
		}
		
		if(0 < OrgList.size()){
			dsuseMsg = nidMessageSource.getMessage("rgstDuseObjt.msg",new String[]{strBf.toString()}); //Message Setting
		}
		map.put("dsuseMsg", dsuseMsg);
		log.debug(dsuseMsg);

		vo.setCalTye(vo.getSearchKeyword8());
		dao.deleteDcrd(vo);
		
		List<String> dcrdList = vo.getDcrdList();
		
		if(dcrdList != null){
			String[] rowData = null;
			for(int i = 0; i<dcrdList.size(); i++){
				rowData = dcrdList.get(i).split(":");
				log.debug("==========================================================");
				log.debug("rowData[0] : " + rowData[0]);
				log.debug("rowData[1] : " + rowData[1]);
				log.debug("==========================================================");
				vo.setCrdIsuceSrlNo(rowData[0]);
				vo.setCrdIsuceDd(rowData[1]);
				dao.insertDcrd(vo);
				dao.insertDcrdTb(vo);//RM_DCRD_TB insert
				
			}
		}		
		String gdrCd = vo.getGdrCd();
		
		if("1".equals(gdrCd)){
			List<String> wifeRsdtSeqNoList = vo.getWifeRsdtSeqNoList();
			List<String> afWifeMrrgCdList = vo.getAfWifeMrrgCdList();
			List<String> bfWifeMrrgCdList = vo.getBfWifeMrrgCdList();
			List<String> wifeStusCdList = vo.getWifeStusCdList();
			List<String> wifeErsrCdList = vo.getWifeErsrCdList();
			List<String> wifeHsbdRsdtSeqNoList = vo.getWifeHsbdRsdtSeqNoList();
			List<String> wifeSgntList = vo.getWifeSgntList();
			
			if(wifeRsdtSeqNoList != null){
				boolean delFlag = false;
				String wifeSgnt = "";
				String wifersdtSeqNo = "";
				String wifeMrrgCd = "";
				String bfWifeMrrgCd = "";
				String wifeStusCd = "";
				String wifeErsrCd = "";
				String wifeHsbdRsdtSeqNo = "";
				
				for(int i = 0; i<wifeRsdtSeqNoList.size(); i++){
					
					wifersdtSeqNo = wifeRsdtSeqNoList.get(i);
					wifeMrrgCd = afWifeMrrgCdList.get(i);
					bfWifeMrrgCd = bfWifeMrrgCdList.get(i);
					wifeStusCd = wifeStusCdList.get(i);
					wifeErsrCd = wifeErsrCdList.get(i);
					wifeHsbdRsdtSeqNo = wifeHsbdRsdtSeqNoList.get(i);
					log.debug(i+".wifeRsdtSeqNo :" + wifersdtSeqNo);
					
					vo.setSpusRsdtSeqNo(wifersdtSeqNo);
					vo.setAfMrrgCd(wifeMrrgCd);
					vo.setBfMrrgCd(bfWifeMrrgCd);
					vo.setSpusRsdtStusCd(wifeStusCd);
					vo.setSpusErsrCd(wifeErsrCd);
					
					//RM_CCLT_MRRG_TB Last update
					int wifeCcltResult = dao.updateLastCcltMrrgInfr(vo);
					log.debug(i+".wifeCcltResult :" + wifeCcltResult);
					
					if(wifeCcltResult != 1){
						throw processException( "udtFail.msg");
					}
					
					//check wife Status
					delFlag = false;
					if(null != wifeStusCd && !"".equals(wifeStusCd) && !"1".equals(wifeStusCd) && !"2".equals(wifeErsrCd) ){
						log.debug(wifersdtSeqNo+" IS Revocation :");
						delFlag = true;
					}else if(!vo.getRsdtSeqNo().equals(wifeHsbdRsdtSeqNo) ){
						log.debug(wifersdtSeqNo+" IS married with another person :");
						delFlag = true;
					}
					log.debug(i+".DELETE FLag :" + delFlag);
					//delete wife who flag is true
					if(delFlag){
						int delResult = dao.deleteCcltMrrgInfr(vo);
						log.debug(i+".delResult :" + delResult);
						if(delResult != 1){
							throw processException( "udtFail.msg");
						}
					}
					
					wifeSgnt = wifeSgntList.get(i);
					if(!"".equals(wifeSgnt) && !delFlag){
						
						log.debug(i+".wifeRsdtSeqNo :" + wifersdtSeqNo);
						
						//rm_rsdt_tb history 
						rsdtDao.insertRsdtInfrHst(wifersdtSeqNo, vo.getUserId() );
												
						if("2".equals(wifeMrrgCd) || "4".equals(wifeMrrgCd)){
							vo.setSpusSeqDelYn("Y");
						}else{
							vo.setSpusSeqDelYn("N");
						}
						
						//rm_rsdt_tb update
						int wifeResult = dao.updateRsdtMrrgCd(vo);
						
						log.debug(i+".wife update Result :" + wifeResult);
						
						if(wifeResult != 1){
							throw processException( "udtFail.msg");
						}
						
						//Update Signature Data to RM_RSDT_TB
						rsdtInfrService.updateDigitalSgnt(wifersdtSeqNo, wifeSgnt, "6");
						log.debug(i+".wife Sgnt Date :" + wifeSgnt);
					}
					
					//value init
					wifeSgnt = "";
					wifersdtSeqNo = "";
					wifeMrrgCd = "";
					bfWifeMrrgCd = "";
					wifeStusCd = "";
					wifeErsrCd = "";
					wifeHsbdRsdtSeqNo = "";
					
				}	
			}	
		}else{
			String hsbdRsdtSeqNo = vo.getBfHsbdRsdtSeqNo();
			String afHsbdMrrgCd = vo.getAfHsbdMrrgCd();
			String bfHsbdMrrgCd = vo.getBfHsbdMrrgCd();
			String hsbdStusCd = vo.getHsbdStusCd();
			String hsbdErsrcd = vo.getHsbdErsrCd();
			String afHsbdRsdtSeqNo = vo.getAfHsbdRsdtSeqNo();
			
			if(null != hsbdRsdtSeqNo && !"".equals(hsbdRsdtSeqNo)){
				
				vo.setSpusRsdtSeqNo(hsbdRsdtSeqNo);
				vo.setAfMrrgCd(afHsbdMrrgCd);
				vo.setBfMrrgCd(bfHsbdMrrgCd);
				vo.setSpusRsdtStusCd(hsbdStusCd);
				vo.setSpusErsrCd(hsbdErsrcd);
				
				//check husband Status
				boolean delFlag = false;
				if(null != hsbdStusCd && !"".equals(hsbdStusCd) && !"1".equals(hsbdStusCd) && !"2".equals(hsbdErsrcd) ){
					log.debug(hsbdRsdtSeqNo+" IS Revocation :");
					delFlag = true;
				}else if(!hsbdRsdtSeqNo.equals(afHsbdRsdtSeqNo) ){
					log.debug(hsbdRsdtSeqNo+" IS married with another person :");
					delFlag = true;
				}
				log.debug(".DELETE FLag :" + delFlag);
				//delete wife who flag is true
				if(delFlag){
					int delResult = dao.deleteCcltMrrgInfr(vo);
					log.debug(".delResult :" + delResult);
					
					if(delResult != 1){
						throw processException( "udtFail.msg");
					}
				}else{
					
					//RM_CCLT_MRRG_TB Last update
					int hsbdCcltResult = dao.updateLastCcltMrrgInfr(vo);
					
					if(hsbdCcltResult != 1){
						throw processException( "udtFail.msg");
					}
					
					List<String> hsbdWifeRsdtSeqNoList = vo.getHsbdWifeRsdtSeqNoList();
					if(hsbdWifeRsdtSeqNoList != null){
						vo.setBfMrrgCd("");
						vo.setAfMrrgCd("");
						vo.setTye("2");
						for(int i = 0; i<hsbdWifeRsdtSeqNoList.size(); i++){
							vo.setTye("2");
							vo.setSpusRsdtSeqNo(hsbdWifeRsdtSeqNoList.get(i));
							dao.insertCcltMrrgInfr(vo);
						}
					}
	
				}
				
				String hsbdSgnt = vo.getHsbdSgnt();
				if(!"".equals(hsbdSgnt)){
					log.debug("hsbdRsdtSeqNo :" + hsbdRsdtSeqNo);
					//rm_rsdt_tb history 
					rsdtDao.insertRsdtInfrHst(hsbdRsdtSeqNo, vo.getUserId() );
					
					vo.setAfMrrgCd(afHsbdMrrgCd);
					vo.setSpusRsdtSeqNo(hsbdRsdtSeqNo);
					//rm_rsdt_tb update
					int hsbdResult = dao.updateRsdtMrrgCd(vo);
					
					log.debug("hsbd update Result :" + hsbdResult);

					if(hsbdResult != 1){
						throw processException( "udtFail.msg");
					}
					
					//Update Signature Data to RM_RSDT_TB
					rsdtInfrService.updateDigitalSgnt(hsbdRsdtSeqNo, hsbdSgnt, "6");
					
					log.debug("hsbd sgnt date :" + hsbdSgnt);
				}
			}
		}
		

		
		return map;
	}
    
	/**
	 * Biz-method for registering information of new user(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for registering new user(CcltRhbltVO).
	 * @return CcltRhbltVO Primary Key value of registered user
	 * @exception Exception
	 */
	public String approveCcltPkiIf(CcltRhbltVO vo) throws Exception {
		
		String status = "";
		String erorYn ="Y";

		//Citizen Account Revocation 
		CpkiRmWSService orws= new CpkiRmWSService();
		CpkiRmWS orw = orws.getCpkiRmWSPort();		
			
		PkiRsWsResponse prwr = orw.cpkiIFaccountRevocation(vo.getRsdtNo());
		status= prwr.getStatusCode();
		log.debug("status ====> " + status);
		if("0".equals(status)){
			erorYn ="N";
		}
		
		lgDao.updatePubKeyIfLg(vo.getLgSeqNo(), status, erorYn);			
		
		
    	return status;
    	
	}		
	
	/**
	 * Biz-method for approval of Citizen Revocation / Rehabilitation. <br>
	 * 
	 * @param vo Input item for approval of Revocation / Rehabilitation.(CcltRhbltVO)
	 * @exception Exception
	 */
	public String approveRhbltInfr(CcltRhbltVO vo) throws Exception {		
		int result = modifyCcltRhbltInfr(vo);
		if(result != 1){
			throw processException( "udtFail.msg");
		}
		String mrrgCd = vo.getMrrgCd();
		if("2".equals(mrrgCd) || "4".equals(mrrgCd)){
			vo.setSpusSeqDelYn("Y");
		}
		
		//rm_rsdt_tb history 
		rsdtDao.insertRsdtInfrHst(vo.getRsdtSeqNo(), vo.getUserId() );
		//approval
		boolean rhbltResult = dao.updateRhbltAprv(vo);
		//rm_rsdt_tb update
		boolean rsdtResult = dao.updateRsdtRhbltInfr(vo);
		
		if(!rhbltResult || !rsdtResult){
			throw processException( "udtFail.msg");
		}

		//Update Signature Data to RM_RSDT_TB
		rsdtInfrService.updateDigitalSgnt(vo.getRsdtSeqNo(), vo.getSgnt(), "7");
		
		
		//Check Adult for PKI
		String lgSeqNo ="";
		//get PKI cert issuance count
		int crtisuceCn = rsdtInfrService.searchPkiCrtIsuceCn(vo.getRsdtSeqNo());
		
		if(0 < crtisuceCn){
			String enid = vo.getRsdtNo();	
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		    
		    //Insert PKI log
		    lgSeqNo=lgDao.insertPubKeyIfLg(user.getUserId(), enid, "25", "1", "7", "");
		}
		
		String gdrCd = vo.getGdrCd();
		
		if("1".equals(gdrCd)){
			List<String> wifeRsdtSeqNoList = vo.getWifeRsdtSeqNoList();
			List<String> bfWifeMrrgCdList = vo.getBfWifeMrrgCdList();
			List<String> afWifeMrrgCdList = vo.getAfWifeMrrgCdList();
			List<String> wifeStusCdList = vo.getWifeStusCdList();
			List<String> wifeErsrCdList = vo.getWifeErsrCdList();
			List<String> wifeHsbdRsdtSeqNoList = vo.getWifeHsbdRsdtSeqNoList();
			List<String> wifeSgntList = vo.getWifeSgntList();
			
			vo.setTye("1");
			if(wifeRsdtSeqNoList != null){
				boolean delFlag = false;
				String wifeSgnt = "";
				String wifersdtSeqNo = "";
				String afWifeMrrgCd = "";
				String bfWifeMrrgCd = "";
				String wifeStusCd = "";
				String wifeErsrCd = "";
				String wifeHsbdRsdtSeqNo = "";
				
				for(int i = 0; i<wifeRsdtSeqNoList.size(); i++){
					
					wifersdtSeqNo = wifeRsdtSeqNoList.get(i);
					afWifeMrrgCd = afWifeMrrgCdList.get(i);
					bfWifeMrrgCd = bfWifeMrrgCdList.get(i);
					wifeStusCd = wifeStusCdList.get(i);
					wifeErsrCd = wifeErsrCdList.get(i);
					wifeHsbdRsdtSeqNo= wifeHsbdRsdtSeqNoList.get(i);
					
					//check wife Status
					delFlag = false;
					if(null != wifeStusCd && !"".equals(wifeStusCd) && !"1".equals(wifeStusCd) && !"2".equals(wifeErsrCd) ){
						log.debug(wifeRsdtSeqNoList.get(i)+" IS Revocation :");
						delFlag = true;
					}else if(!vo.getRsdtSeqNo().equals(wifeHsbdRsdtSeqNo) ){
						log.debug(wifeRsdtSeqNoList.get(i)+" IS married with another person :");
						delFlag = true;
					}
					
					if(!delFlag){
						vo.setSpusRsdtSeqNo(wifersdtSeqNo);
						vo.setAfMrrgCd(afWifeMrrgCd);
						vo.setBfMrrgCd(bfWifeMrrgCd);						
						vo.setSpusRsdtStusCd(wifeStusCd);
						vo.setSpusErsrCd(wifeErsrCd);
						dao.insertRhbltMrrgInfr(vo);
					}
					
					wifeSgnt = wifeSgntList.get(i);
					if(!"".equals(wifeSgnt) && !delFlag){

						log.debug(i+".wifeRsdtSeqNo :" + wifersdtSeqNo);
						//rm_rsdt_tb history 
						rsdtDao.insertRsdtInfrHst(wifersdtSeqNo, vo.getUserId() );
						
						//rm_rsdt_tb update
						int wifeResult = dao.updateRsdtMrrgCd(vo);
						log.debug(i+".wife update Result :" + wifeResult);
						
						if(wifeResult != 1){
							throw processException( "udtFail.msg");
						}
						
						//Update Signature Data to RM_RSDT_TB
						rsdtInfrService.updateDigitalSgnt(wifersdtSeqNo, wifeSgnt, "7");
						log.debug(i+".wife Sgnt Date :" + wifeSgnt);
					}
					
					wifeSgnt = "";
					wifersdtSeqNo = "";
					afWifeMrrgCd = "";
					bfWifeMrrgCd = "";
					wifeStusCd = "";
					wifeErsrCd = "";
					wifeHsbdRsdtSeqNo = "";
				}		
			}	
		}else{
			String bfHsbdRsdtSeqNo = vo.getBfHsbdRsdtSeqNo();
			String afHsbdRsdtSeqNo = vo.getAfHsbdRsdtSeqNo();
			String bfHsbdMrrgCd = vo.getBfHsbdMrrgCd();
			String afHsbdMrrgCd = vo.getAfHsbdMrrgCd();
			
			String hsbdStusCd = vo.getHsbdStusCd();
			String hsbdErsrcd = vo.getHsbdErsrCd();
			
			if(null != bfHsbdRsdtSeqNo && !"".equals(bfHsbdRsdtSeqNo)){
				
				//check husband Status
				boolean delFlag = false;
				if(null != hsbdStusCd && !"".equals(hsbdStusCd) && !"1".equals(hsbdStusCd) && !"2".equals(hsbdErsrcd) ){
					log.debug(bfHsbdRsdtSeqNo+" IS Revocation :");
					delFlag = true;
				}else if(!bfHsbdRsdtSeqNo.equals(afHsbdRsdtSeqNo) ){
					log.debug(bfHsbdRsdtSeqNo+" IS married with another person :");
					delFlag = true;
				}
				
				if(!delFlag){
					vo.setTye("1");
					vo.setSpusRsdtSeqNo(bfHsbdRsdtSeqNo);
					vo.setBfMrrgCd(bfHsbdMrrgCd);
					vo.setAfMrrgCd(afHsbdMrrgCd);
					vo.setSpusRsdtStusCd(hsbdStusCd);
					vo.setSpusErsrCd(hsbdErsrcd);
					dao.insertRhbltMrrgInfr(vo);
					
					List<String> hsbdWifeRsdtSeqNoList = vo.getHsbdWifeRsdtSeqNoList();
					if(hsbdWifeRsdtSeqNoList != null){
						vo.setBfMrrgCd("");
						vo.setAfMrrgCd("");
						vo.setSpusRsdtStusCd("");
						vo.setSpusErsrCd("");
						vo.setTye("2");
						
						for(int i = 0; i<hsbdWifeRsdtSeqNoList.size(); i++){
							vo.setSpusRsdtSeqNo(hsbdWifeRsdtSeqNoList.get(i));
							dao.insertRhbltMrrgInfr(vo);
						}
					}
				}
				
				String hsbdSgnt = vo.getHsbdSgnt();
				if(!"".equals(hsbdSgnt)){
					log.debug("hsbdRsdtSeqNo :" + bfHsbdRsdtSeqNo);
					
					//rm_rsdt_tb history 
					rsdtDao.insertRsdtInfrHst(bfHsbdRsdtSeqNo, vo.getUserId() );
					
					vo.setAfMrrgCd(afHsbdMrrgCd);
					vo.setSpusRsdtSeqNo(bfHsbdRsdtSeqNo);
					//rm_rsdt_tb update
					int hsbdResult = dao.updateRsdtMrrgCd(vo);
					
					log.debug("hsbd update Result :" + hsbdResult);

					if(hsbdResult != 1){
						throw processException( "udtFail.msg");
					}
					
					//Update Signature Data to RM_RSDT_TB
					rsdtInfrService.updateDigitalSgnt(bfHsbdRsdtSeqNo, hsbdSgnt, "7");
					
					log.debug("hsbd sgnt date :" + hsbdSgnt);
				}	
			}
		}
		
		return lgSeqNo;
	}
	
	/**
	 * Biz-method for request Citizen Reactivation (PKI Interface Call). <br>
	 * 
	 * @param vo Input item for request Citizen Reactivation(CcltRhbltVO).
	 * @return result
	 * @exception Exception
	 */
	public String approveRhbltPkiIf(CcltRhbltVO vo) throws Exception {
		
		String status = "";
		String erorYn ="Y";
		log.debug("Citizen No for Rhblt : "+vo.getRsdtNo());
		//Citizen Account Revocation 
		CpkiRmWSService orws= new CpkiRmWSService();
		CpkiRmWS orw = orws.getCpkiRmWSPort();		
			
		PkiRsWsResponse prwr = orw.cpkiIFaccountCitizenReactivate(vo.getRsdtNo());
		status= prwr.getStatusCode();
		log.debug("status ====> " + status);
		if("0".equals(status)){
			erorYn ="N";
		}
		lgDao.updatePubKeyIfLg(vo.getLgSeqNo(), status, erorYn);			
		
    	return status;
    	
	}
	
	   
    /**
	 * Biz-method for retrieving detail Information of Revocation citizen. <br>
	 * 
	 * @param ccltRhbltVO Input item for retrieving detail information of Revocation citizen(CcltRhbltVO).
	 * @return RsdtRbildVO detail information of Revocation citizen
	 * @exception Exception
	 */
	public CcltRhbltVO searchCcltCfmRcpt(CcltRhbltVO ccltRhbltVO) throws Exception{		
		/** Loading session information */
    	return (CcltRhbltVO)dao.selectCcltCfmRcpt(ccltRhbltVO);
	}
	
   	/**
   	 * Biz-method for retrieving list of wife of Revocation citizen. <br>
   	 *
   	 * @param vo Input item for retrieving list of wife of Revocation citizen(CcltRhbltVO).
   	 * @return List Retrieve list of wife of Revocation citizen
   	 * @exception Exception
   	 */    
    public List<CcltRhbltVO> searchListCcltSpus(CcltRhbltVO ccltRhbltVO) throws Exception{    	
    	return dao.selectListCcltSpus(ccltRhbltVO);
    } 
    
    /**
	 * Biz-method for retrieving detail Information of Rehabilitation citizen. <br>
	 * 
	 * @param ccltRhbltVO Input item for retrieving detail information of Rehabilitation citizen(RsdtRbildVO).
	 * @return RsdtRbildVO detail information of Rehabilitation citizen
	 * @exception Exception
	 */
	public CcltRhbltVO searchRhbltCfmRcpt(CcltRhbltVO ccltRhbltVO) throws Exception{		
    	return (CcltRhbltVO)dao.selectRhbltCfmRcpt(ccltRhbltVO);
	}	
	
   	/**
   	 * Biz-method for retrieving list of wife of Rehabilitation citizen. <br>
   	 *
   	 * @param vo Input item for retrieving list of wife of Rehabilitation citizen(CcltRhbltVO).
   	 * @return List Retrieve list of wife of Rehabilitation citizen
   	 * @exception Exception
   	 */    
    public List<CcltRhbltVO>  searchListRhbltSpus(CcltRhbltVO ccltRhbltVO) throws Exception{    	
    	return dao.selectListRhbltSpus(ccltRhbltVO);
    }
    
    /**
   	 * Biz-method for retrieving discard information. <br>
   	 *
   	 * @param vo Input item for retrieving discard information.(CcltRhbltVO).
   	 * @return List<CcltRhbltVO>
   	 * @exception Exception
   	 */
    public List<CcltRhbltVO> searchListDrcd(CcltRhbltVO vo) throws Exception {
		return dao.selectListDrcd(vo);
	}    
}