package afnid.rm.clrt.web;

/* java API */
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.clrt.service.CcltRhbltService;
import afnid.rm.clrt.service.CcltRhbltVO;

import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;



/** 
 * This Controller class processes request of Citizen-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Team Ha Na YIM
 * @since 2011.04.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.04.19  		Ha Na YIM          		                    Create
 *
 * </pre>
 */

@Controller
public class CcltRhbltController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** NidProgrmManageService */
	@Resource(name = "ccltRhbltService")
    private CcltRhbltService service;
	
    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdManagerService;
	
	/** NidCommonService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCommonService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** LogService */
    @Resource(name="lgService")
    private LgService lgService;
  
    /**
     * Moved to regstration-screen of Citizen Revocationlation / Rehabilitation <br>
     *
     * @param vo Value-object of Citizen to be parsed request(CcltRhbitVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/clrt/CcltRhbltIns.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/clrt/addCcltRhbltView.do")
    public String addCcltRhbltView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("ccltRhbltVO") CcltRhbltVO vo,
    		ModelMap model)
            throws Exception {
    	try{
  
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	//세션정보
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		
    		lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
    		
    		model.addAttribute("ccltRhbltVO",vo);
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		
    		cmCmmCd.setGrpCd("39"); 
    		List<CmCmmCdVO> revocation = cmmCdManagerService.searchListCmmCd(cmCmmCd, false, "desc");     		
    		model.addAttribute("revocation", revocation);
    		
    		cmCmmCd.setGrpCd("40"); 
    		List<CmCmmCdVO> rehabilit = cmmCdManagerService.searchListCmmCd(cmCmmCd, false, "desc");     		
    		model.addAttribute("rehabilit",rehabilit);    		
    		
    		cmCmmCd.setGrpCd("14"); 
    		List<CmCmmCdVO> newNltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, false, "desc");     		
    		model.addAttribute("newNltyCd", newNltyCd);
    		
    		cmCmmCd.setGrpCd("20"); 
    		List<CmCmmCdVO> rsdtStusCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, false, "desc");     		
    		model.addAttribute("rsdtStusCd", rsdtStusCd);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/clrt/CcltRhbltIns";
    	
    } 
    /**
     * Retrieves list of program. <br>
     *
     * @param vo Value-object of Citizen to be parsed request(CcltRhbltVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/clrt/CcltRhbltIns.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/clrt/searchRsdtInfr.do")
    public String searchRsdtInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("ccltRhbltVO") CcltRhbltVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUserId(user.getUserId());
    		vo.setUseLangCd(user.getUseLangCd());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd();
    		vo.setRgstOrgnzCd( orgnzCd );
    		
    		CcltRhbltVO vo2 = new CcltRhbltVO();
    		
    		
    		//revocation
    		if("CCLT".equals(vo.getKeyword())){
    			
    			vo2 = service.searchRsdtInfr( vo );
    			 
    			if ( null == vo2 ){
    				//not exist Citizen
	    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstEnid.msg") );
	    		 	return "/rm/clrt/CcltRhbltIns";
	    		}else if( "2".equals(vo2.getRsdtStusCd() ) ){
	    			//already revocation
					model.addAttribute("resultMsg", nidMessageSource.getMessage("nRvctgRgstByRvctg.msg") );
	    		 	return "/rm/clrt/CcltRhbltIns";
				}
    			
    			vo.setRsdtSeqNo( vo2.getRsdtSeqNo() );
    			vo2 = service.searchCcltSeqNo(vo);
    			
    			//int crdIsuceCnt = service.searchCrdIsuceCnt(vo);//card issuance count
    			
    			if( null  == vo2 ){
    				//insert mode
    				vo2 = service.searchCcltInfr(vo);
					vo2.setSearchKeyword9("insert");
					
					vo2.setUseLangCd(user.getUseLangCd());
					List<CcltRhbltVO> wifeInfr = service.searchWifeRsdtInfrForRvctgIns(vo2);
					model.addAttribute("wifeInfr", wifeInfr);
    			}else{
    				if(!vo2.getRgstOrgnzCd().startsWith(orgnzCd) ){
    					//regstration other office
    					model.addAttribute("resultMsg", nidMessageSource.getMessage("rgstOthrOfic.msg",new String[]{vo2.getRgstOrgnzCdNm()} ) );
    	    		 	return "/rm/clrt/CcltRhbltIns";    					
    				}else{
    					//modify mode
        				vo2 = service.searchCcltInfrUdt(vo);
        				
        				vo2.setUseLangCd(user.getUseLangCd());
        				
        				List<CcltRhbltVO> dcrdList = service.searchListDrcd(vo2);
        				model.addAttribute("dcrdList", dcrdList);
        				
        				
        				
        				if("1".equals(vo2.getGdrCd()) ){
        					vo2.setTye("1");
        					List<CcltRhbltVO> wifeInfr = service.searchSpusRsdtInfrForRvctgUdt(vo2);
        					model.addAttribute("wifeInfr", wifeInfr);
        					
        				}else if("2".equals(vo2.getGdrCd())){
        					vo2.setTye("1");
        					List<CcltRhbltVO> hsbdInfr = service.searchSpusRsdtInfrForRvctgUdt(vo2);
        					
        					if(null != hsbdInfr && 0 != hsbdInfr.size()){
        						CcltRhbltVO hsbd =hsbdInfr.get(0);
        						vo2.setBfHsbdMrrgCd(hsbd.getBfWifeMrrgCd());
        						vo2.setBfHsbdMrrgCdNm(hsbd.getBfWifeMrrgCdNm());
        						vo2.setAfHsbdMrrgCd(hsbd.getAfWifeMrrgCd());
        						vo2.setBfHsbdNm(hsbd.getBfWifeNm());
        						vo2.setAfHsbdNm(hsbd.getAfWifeNm());
        						vo2.setBfHsbdRsdtSeqNo(hsbd.getBfWifeRsdtSeqNo());
        						vo2.setBfHsbdRsdtNoDp(hsbd.getBfWifeRsdtNoDp());
        						vo2.setAfHsbdRsdtNoDp(hsbd.getAfWifeRsdtNoDp());
        						vo2.setHsbdStusCd(hsbd.getWifeStusCd());
        						vo2.setHsbdErsrCd(hsbd.getWifeErsrCd());
        						vo2.setHsbdStusCdNm(hsbd.getWifeStusCdNm());
        						vo2.setFrngrYn(hsbd.getFrngrYn());
        						
        						vo2.setTye("2");
        						List<CcltRhbltVO> wifeInfr = service.searchWifeRsdtInfrForRvctgIns(vo2);
        						model.addAttribute("wifeInfr", wifeInfr);
        					}
        					
        				}
        				
        				vo2.setSearchKeyword9("update");
    				}   			 
    			}
    		//rehabilitation	
    		}else if("RHBLT".equals(vo.getKeyword())){
    			
    			vo2 = service.searchRsdtInfr( vo );
    			
				if ( null == vo2 ){    			
	    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstEnid.msg") );
	    		 	return "/rm/clrt/CcltRhbltIns";
	    		}else if( "1".equals(vo2.getRsdtStusCd())  ){    					
					model.addAttribute("resultMsg", nidMessageSource.getMessage("nRvctgCtzn.msg") );
	    		 	return "/rm/clrt/CcltRhbltIns";
				}				
				
    			vo.setRsdtSeqNo( vo2.getRsdtSeqNo() );
    			vo2 = service.searchRhbltSeqNo(vo);
    			
    			if( null  == vo2 ){
    				//insert mode
    				vo2 = service.searchRhbltInfr(vo);
					
					if(null == vo2 ){
						model.addAttribute("resultMsg", nidMessageSource.getMessage("nHtsDat.msg"));
    	    		 	return "/rm/clrt/CcltRhbltIns"; 
					}
					vo2.setSearchKeyword9("insert");
					
    			}else{
    				if( !vo2.getRgstOrgnzCd().startsWith(orgnzCd)){
    					//regstration other office
    					model.addAttribute("resultMsg", nidMessageSource.getMessage("rgstOthrOfic.msg",new String[]{vo2.getRgstOrgnzCdNm()}) );
    	    		 	return "/rm/clrt/CcltRhbltIns";    					
    				}else{
    					//modify mode
        				vo.setCcltSeqNo( vo2.getCcltSeqNo() );
        				vo2 = service.searchRhbltInfrUdt(vo);
 
        				vo2.setSearchKeyword9("update");
    				}
    			}
    			
    			vo2.setUseLangCd(user.getUseLangCd());
				
				if("1".equals(vo2.getGdrCd())){
					vo2.setTye("1");
					List<CcltRhbltVO> wifeInfr= service.searchWifeRsdtInfrForRhbltIns(vo2);
					model.addAttribute("wifeInfr", wifeInfr);
				}else if("2".equals(vo2.getGdrCd())){
					vo2.setTye("1");
					List<CcltRhbltVO> hsbdInfr= service.searchWifeRsdtInfrForRhbltIns(vo2);
					
					if(null != hsbdInfr && 0 != hsbdInfr.size()){
						CcltRhbltVO hsbd =hsbdInfr.get(0);
						vo2.setBfHsbdMrrgCd(hsbd.getBfWifeMrrgCd());
						vo2.setBfHsbdMrrgCdNm(hsbd.getBfWifeMrrgCdNm());
						vo2.setAfHsbdMrrgCd(hsbd.getAfWifeMrrgCd());
						vo2.setBfHsbdNm(hsbd.getBfWifeNm());
						vo2.setAfHsbdNm(hsbd.getAfWifeNm());
						vo2.setBfHsbdRsdtSeqNo(hsbd.getBfWifeRsdtSeqNo());
						vo2.setBfHsbdRsdtNoDp(hsbd.getBfWifeRsdtNoDp());
						vo2.setAfHsbdRsdtNoDp(hsbd.getAfWifeRsdtNoDp());
						vo2.setHsbdStusCd(hsbd.getWifeStusCd());
						vo2.setHsbdErsrCd(hsbd.getWifeErsrCd());
						vo2.setHsbdStusCdNm(hsbd.getWifeStusCdNm());
						vo2.setFrngrYn(hsbd.getFrngrYn());
						
						vo2.setTye("2");
						List<CcltRhbltVO> wifeInfr = service.searchWifeRsdtInfrForRvctgIns(vo2);
						model.addAttribute("wifeInfr", wifeInfr);
					}
				}
    						   			
    		}
    		
    		model.addAttribute("vo", vo2 );
    		
    		int alwWifeNo = propertiesService.getInt("alwWifeNo");
    		model.addAttribute("alwWifeNo", alwWifeNo);
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("39"); 
    		List<CmCmmCdVO> revocation = cmmCdManagerService.searchListCmmCd(cmCmmCd, false, "desc");     		
    		model.addAttribute("revocation", revocation);

    		cmCmmCd.setGrpCd("40"); 
    		List<CmCmmCdVO> rehabilitation = cmmCdManagerService.searchListCmmCd(cmCmmCd, false, "desc"); 
    		model.addAttribute("rehabilitation",rehabilitation);
    		
    		cmCmmCd.setGrpCd("14"); 
    		List<CmCmmCdVO> newNltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, false, "desc");     		
    		model.addAttribute("newNltyCd", newNltyCd);
    		
    		cmCmmCd.setGrpCd("20"); 
    		List<CmCmmCdVO> rsdtStusCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, false, "desc");     		
    		model.addAttribute("rsdtStusCd", rsdtStusCd);
    		
    		cmCmmCd.setGrpCd("12"); 
    		List<CmCmmCdVO> mrrgCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, false, "desc");     		
    		model.addAttribute("mrrgCd", mrrgCd);
    		
    		ComDefaultVO greToday = nidCommonService.searchGreToDay( comDefaultVO );
    		model.addAttribute("greToday", greToday);
    		ComDefaultVO perToday = nidCommonService.searchPerToDay( comDefaultVO );
    		model.addAttribute("perToday", perToday);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/clrt/CcltRhbltIns";
    }
    
    /**
     * insert Citizen information for Revocation <br>
     * 
     * @param vo Value-object of Citizen to be parsed request(CcltRhbltVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "rm/clrt/CcltRhbltIns.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/clrt/addCcltInfr.do")   
    public String addCcltInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("ccltRhbltVO") CcltRhbltVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUserId(user.getUserId());
    		vo.setFstRgstUserId(user.getUserId());
    		vo.setLstUdtUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		
    		if( "1".equals(vo.getRsnCd()) && "".equals(vo.getCcltTm())){    			
    			vo.setCcltTm("000000");    			
    		}
    		
    		if("1".equals(vo.getRsnCd())){
    			vo.setNewNltyCd("");
    		}
    		
			service.addCcltInfr(vo);
			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); 
	
		} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "forward:/rm/clrt/searchRsdtInfr.do";
    }
    
    /**
     * update Citizen information for Revocation <br>
     * 
     * @param vo Value-object of family to be parsed request(CcltRhbltVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "rm/clrt/CcltRhbltIns.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/clrt/modifyCcltInfr.do")   
    public String modifyCcltInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("ccltRhbltVO") CcltRhbltVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		model.addAttribute("ccltRhbltVO", vo);
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUserId(user.getUserId());
    		vo.setFstRgstUserId(user.getUserId());
    		vo.setLstUdtUserId(user.getUserId()); 
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		
    		if( "1".equals(vo.getRsnCd()) && "".equals(vo.getCcltTm())){    			
    			vo.setCcltTm("000000");    			
    		}
    		
    		if("1".equals(vo.getRsnCd())){
    			vo.setNewNltyCd("");
    		}	  
    		
    		if(vo.getRsdtCfmYn()== null || "".equals(vo.getRsdtCfmYn())){
    			vo.setRsdtCfmYn("N");
    		} 

    		
			service.modifyCcltInfr(vo);
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datUdtScsfl.msg")); 
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}      	
      	return "forward:/rm/clrt/searchRsdtInfr.do";
    }    
    
    /**
     * insert Citizen information for Rehabilitation. <br>
     * 
     * @param vo Value-object of Citizen to be parsed request(CcltRhbltVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "rm/clrt/CcltRhbltIns.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/clrt/addRhbltInfr.do")   
    public String addRhbltInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("ccltRhbltVO") CcltRhbltVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		/** Loading session information  */
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setFstRgstUserId(user.getUserId());
    		vo.setUseLangCd(user.getUseLangCd());
    		vo.setLstUdtUserId(user.getUserId());
    		vo.setUserId(user.getUserId());
    		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm());
    		
    		service.addRhbltInfr(vo);
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); 
    		
		} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "forward:/rm/clrt/searchRsdtInfr.do";
    }
    
    /**
     * update Citizen information for Rehabilitation. <br>
     * 
     * @param vo Value-object of Citizen to be parsed request(CcltRhbltVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "rm/clrt/CcltRhbltIns.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/clrt/modifyRhbltInfr.do")   
    public String modifyRhbltInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("ccltRhbltVO") CcltRhbltVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUserId(user.getUserId());
    		vo.setFstRgstUserId(user.getUserId());
    		vo.setLstUdtUserId(user.getUserId()); 
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		
    		if(vo.getRsdtCfmYn()== null || "".equals(vo.getRsdtCfmYn())){
    			vo.setRsdtCfmYn("N");
    		}
    		
    		service.modifyRhbltInfr(vo);
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datUdtScsfl.msg"));
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));    		
    	}
    	return "forward:/rm/clrt/searchRsdtInfr.do";
    }
    
	/**
     * Moved to list-screen of Citizen Revocation / Rehabilitation <br>
     *
     * @param vo Value-object of Citizen to be parsed request(CcltRhbitVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/clrt/CcltRhbltAprvList.jsp "
     * @exception Exception
     */								
    @RequestMapping(value="/rm/clrt/searchListCcltRhbltAprvView.do")
    public String searchListCcltRhbltAprvView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("ccltRhbltVO") CcltRhbltVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		vo.setUseLangCd(user.getUseLangCd());
    		String userId = user.getUserId();   		
    		
    		vo.setUserId( userId );
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		
    		lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("26"); 
    		List<CmCmmCdVO> cfmYn = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("cfmYn", cfmYn);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/clrt/CcltRhbltAprvList";    	
    }     
    
	/**
     * Retrieves list of program. <br>
     *
     * @param vo Value-object of Citizen to be parsed request(CcltRhbltVO)
     * @return List Retrieve list of program
     * @exception Exception
     */
    @RequestMapping(value="/rm/clrt/searchListCcltRhbltAprv.do")
    public String searchListCcltRhbltAprv(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("ccltRhbltVO") CcltRhbltVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		vo.setUseLangCd(user.getUseLangCd());	
    		String userId = user.getUserId();    				    		
    		
    		vo.setUserId( userId );
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd();
    		vo.setRgstOrgnzCd( orgnzCd );

    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));

	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());
			
			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
			int aprvListTm = propertiesService.getInt("aprvListTm");
			vo.setAprvListTm(String.valueOf(aprvListTm));
			
			List<EgovMap> lstProgram = service.searchListCcltRhbltAprv(vo);			
			model.addAttribute("lstProgram", lstProgram);

			int totCnt = service.searchListTotCntCcltRhbltAprv(vo);			
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("26"); 
    		List<CmCmmCdVO> cfmYn = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("cfmYn", cfmYn);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/clrt/CcltRhbltAprvList";    	
    }    

	/**
     * Moved to screen of Citizen Revocation / Rehabilitation Approval. <br>
     *
     * @param vo Value-object of Citizen to be parsed request(CcltRhbltVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/clrt/CcltRhbltAprvUdt.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/clrt/searchCcltRhbltAprvView.do")
    public String searchCcltRhbltAprvView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("ccltRhbltVO") CcltRhbltVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());	
    		String userId = user.getUserId();    			    		
    		
    		vo.setUserId( userId );
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		int adultAge = propertiesService.getInt("adultAge");
    		vo.setAdultAge(String.valueOf(adultAge));
    		
    		String keyword = vo.getKeyword();
    		CcltRhbltVO resultVO = new CcltRhbltVO();
    		
    		if( "CCLT".equals( keyword ) ){
    			resultVO = service.searchCcltAprv(vo);
    			
				List<CcltRhbltVO> dcrdList = service.searchListDrcd(vo);
				model.addAttribute("dcrdList", dcrdList);
				
    			if("1".equals(resultVO.getGdrCd()) ){
					vo.setTye("1");
					List<CcltRhbltVO> wifeInfr  = null;
					if("Y".equals(resultVO.getTamLedrCfmYn()) ){
						wifeInfr= service.searchSpusRsdtInfrForAfAprv(vo);
					}else{
						wifeInfr= service.searchSpusRsdtInfrForRvctgUdt(vo);
						
					}
					model.addAttribute("wifeInfr", wifeInfr);
					
				}else if("2".equals(resultVO.getGdrCd())){
					vo.setTye("1");
					List<CcltRhbltVO> hsbdInfr = null;
					if("Y".equals(resultVO.getTamLedrCfmYn()) ){
						hsbdInfr = service.searchSpusRsdtInfrForAfAprv(vo);
					}else{
						hsbdInfr = service.searchSpusRsdtInfrForRvctgUdt(vo);
					}

					if(null != hsbdInfr && 0 != hsbdInfr.size()){
						CcltRhbltVO hsbd =hsbdInfr.get(0);
						resultVO.setBfHsbdMrrgCd(hsbd.getBfWifeMrrgCd());
						resultVO.setBfHsbdMrrgCdNm(hsbd.getBfWifeMrrgCdNm());
						resultVO.setAfHsbdMrrgCd(hsbd.getAfWifeMrrgCd());
						resultVO.setBfHsbdNm(hsbd.getBfWifeNm());
						resultVO.setAfHsbdNm(hsbd.getAfWifeNm());
						resultVO.setBfHsbdRsdtSeqNo(hsbd.getBfWifeRsdtSeqNo());
						resultVO.setBfHsbdRsdtNoDp(hsbd.getBfWifeRsdtNoDp());
						resultVO.setAfHsbdRsdtNoDp(hsbd.getAfWifeRsdtNoDp());
						resultVO.setFrngrYn(hsbd.getFrngrYn());
						resultVO.setHsbdStusCd(hsbd.getWifeStusCd());
						resultVO.setHsbdErsrCd(hsbd.getWifeErsrCd());
						resultVO.setHsbdStusCdNm(hsbd.getWifeStusCdNm());
						
						resultVO.setTye("2");
						List<CcltRhbltVO> wifeInfr = null;
						if("Y".equals(resultVO.getTamLedrCfmYn()) ){
							wifeInfr = service.searchSpusRsdtInfrForAfAprv(vo);
						}else{
							wifeInfr = service.searchWifeRsdtInfrForRvctgIns(resultVO);
						}
						
						model.addAttribute("wifeInfr", wifeInfr);
						
					}
					
				}
    			
    		}else if( "RHBLT".equals( keyword ) ){
    			resultVO = service.searchRhbltAprv(vo);
    			
    			vo.setUseLangCd(user.getUseLangCd());
				
				if("1".equals(resultVO.getGdrCd())){
					vo.setTye("1");
					List<CcltRhbltVO> wifeInfr = null;
					
					if("Y".equals(resultVO.getTamLedrCfmYn()) ){
						wifeInfr= service.searchSpusRsdtInfrForAfAprv(vo);
					}else{
						wifeInfr= service.searchWifeRsdtInfrForRhbltIns(vo);
					}
					model.addAttribute("wifeInfr", wifeInfr);
					
				}else if("2".equals(resultVO.getGdrCd())){
					vo.setTye("1");

					List<CcltRhbltVO> hsbdInfr = null;
					if("Y".equals(resultVO.getTamLedrCfmYn()) ){
						hsbdInfr = service.searchSpusRsdtInfrForAfAprv(vo);
					}else{
						hsbdInfr = service.searchWifeRsdtInfrForRhbltIns(vo);
					}
					
					if(null != hsbdInfr && 0 != hsbdInfr.size()){
						CcltRhbltVO hsbd =hsbdInfr.get(0);
						resultVO.setBfHsbdMrrgCd(hsbd.getBfWifeMrrgCd());
						resultVO.setBfHsbdMrrgCdNm(hsbd.getBfWifeMrrgCdNm());
						resultVO.setAfHsbdMrrgCd(hsbd.getAfWifeMrrgCd());
						resultVO.setBfHsbdNm(hsbd.getBfWifeNm());
						resultVO.setAfHsbdNm(hsbd.getAfWifeNm());
						resultVO.setBfHsbdRsdtSeqNo(hsbd.getBfWifeRsdtSeqNo());
						resultVO.setBfHsbdRsdtNoDp(hsbd.getBfWifeRsdtNoDp());
						resultVO.setAfHsbdRsdtNoDp(hsbd.getAfWifeRsdtNoDp());
						resultVO.setHsbdStusCd(hsbd.getWifeStusCd());
						resultVO.setHsbdErsrCd(hsbd.getWifeErsrCd());
						resultVO.setHsbdStusCdNm(hsbd.getWifeStusCdNm());
						resultVO.setFrngrYn(hsbd.getFrngrYn());
						
						vo.setTye("2");
						
						List<CcltRhbltVO> wifeInfr = null;
						
						if("Y".equals(resultVO.getTamLedrCfmYn()) ){
							wifeInfr= service.searchSpusRsdtInfrForAfAprv(vo);
						}else{
							wifeInfr= service.searchWifeRsdtInfrForRvctgIns(resultVO);
						}

						model.addAttribute("wifeInfr", wifeInfr);
					}
				}
    		}
    		
    		resultVO.setKeyword( vo.getKeyword());    		
    		resultVO.setSearchKeyword( vo.getSearchKeyword());
    		resultVO.setSearchKeyword2( vo.getSearchKeyword2());
    		resultVO.setSearchKeyword3( vo.getSearchKeyword3());
    		resultVO.setSearchKeyword4( vo.getSearchKeyword4());
    		resultVO.setSearchKeyword5( vo.getSearchKeyword5());
    		resultVO.setPageIndex( vo.getPageIndex() );
    		
    		model.addAttribute("resultVO", resultVO);
    		model.addAttribute("userId", userId);
    		
    		int alwWifeNo = propertiesService.getInt("alwWifeNo");
    		model.addAttribute("alwWifeNo", alwWifeNo);
    		
    		keyword = resultVO.getKeyword();
    		String ocrRsnCd = "";
    		if( "CCLT".equals( keyword ) ){
    			ocrRsnCd = "39";
    		}else if( "RHBLT".equals( keyword ) ){
    			ocrRsnCd = "40";
    		}
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd(ocrRsnCd); 
    		List<CmCmmCdVO> rsnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rsnCd", rsnCd);
    		
    		cmCmmCd.setGrpCd("26"); 
    		List<CmCmmCdVO> cfmYn = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("cfmYn", cfmYn);
    		
    		cmCmmCd.setGrpCd("26"); 
    		List<CmCmmCdVO> Yn = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("Yn", Yn);
    		
    		cmCmmCd.setGrpCd("14"); 
    		List<CmCmmCdVO> newNltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("newNltyCd", newNltyCd);
    		
    		cmCmmCd.setGrpCd("20"); 
    		List<CmCmmCdVO> rsdtStusCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rsdtStusCd", rsdtStusCd);
    		
    		cmCmmCd.setGrpCd("12"); 
    		List<CmCmmCdVO> mrrgCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, false, "desc");     		
    		model.addAttribute("mrrgCd", mrrgCd);
    		
    		ComDefaultVO greToday = nidCommonService.searchGreToDay( searchVO );
    		model.addAttribute("greToday", greToday);
    		ComDefaultVO perToday = nidCommonService.searchPerToDay( searchVO );
    		model.addAttribute("perToday", perToday);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/clrt/CcltRhbltAprvUdt";
    	
    }
    
    /**
     * update Citizen Revocation / Rehabilitation Verification. <br>
     * 
     * @param vo Value-object of Citizen to be parsed request(CcltRhbltVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return forward:/rm/clrt/searchCcltRhbltAprvView.do
     * @exception Exception
     */    
    
    @RequestMapping(value="/rm/clrt/modifyCcltRhbltInfr.do")
    public String modifyCcltRhbltInfr(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("ccltRhbltVO") CcltRhbltVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		service.modifyCcltRhbltInfr( vo );
    		
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); 
        		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "forward:/rm/clrt/searchCcltRhbltAprvView.do";    	
    }   
    
    /**
     * Approve Citizen Revocation. <br>
     * 
     * @param vo Value-object of Citizen to be parsed request(CcltRhbltVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return forward:/rm/clrt/searchListCcltRhbltAprvView.do
     * @exception Exception
     */    
    
    @RequestMapping(value="/rm/clrt/approveCcltInfr.do")
    public String approveCcltInfr(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("ccltRhbitVO") CcltRhbltVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		vo.setUseLangCd(user.getUseLangCd());
    		
    		String userId = user.getUserId();		
    		vo.setFstRgstUserId(userId);
    		vo.setLstUdtUserId(userId);
    		vo.setUserId( userId );
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		
    		vo.setOcrncDd( vo.getOcrncDd().replace("-", "") );
    		
    		Map<String, String> result = service.approveCcltInfr(vo);  
    		
    		//check result
    		String dsuseMsg = result.get("dsuseMsg");
    		if(!"".equals(dsuseMsg)){
    			model.addAttribute("dsuseMsg", dsuseMsg); //Message Setting
    		}
    		
    		String lgSeqNo = result.get("lgSeqNo");
    		vo.setLgSeqNo(lgSeqNo);
    		
    		if(!"".equals(lgSeqNo)){
    			String pkiResult = service.approveCcltPkiIf(vo);
    			
        		if(!"0".equals(pkiResult)){
        			String helpTelNo = nidMessageSource.getMessage("admTelNo");
        			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{pkiResult, helpTelNo}));
        		} else {
        			model.addAttribute("resultMsg", nidMessageSource.getMessage("apvScsfl.msg"));
        		}
        		
    		} else {
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("apvScsfl.msg"));
    		}

    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "forward:/rm/clrt/searchListCcltRhbltAprv.do";   	
    }    
    
    /**
     * Approve Citizen Rehabilitation. <br>
     * 
     * @param vo Value-object of Citizen to be parsed request(CcltRhbltVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return String str
     * @exception Exception
     */    
    
    @RequestMapping(value="/rm/clrt/approveRhbltInfr.do")
    public String approveRhbltInfr(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("ccltRhbitVO") CcltRhbltVO vo,
    		ModelMap model)
            throws Exception {
    	
    	try{
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		vo.setUseLangCd(user.getUseLangCd());	
    		String userId = user.getUserId();		
    		
    		vo.setUserId( userId );
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		
    		String crdIsucePlceCd = user.getOrgnzClsCd()+ user.getOrgnzCd();
    		vo.setCrdIsucePlceCd(crdIsucePlceCd);
    		
    		vo.setOcrncDd( vo.getOcrncDd().replace("-", "") );
    		
    		String lgSeqNo = service.approveRhbltInfr( vo );
    		vo.setLgSeqNo(lgSeqNo);
    		
    		if(!"".equals(lgSeqNo)){
    			String pkiResult = service.approveRhbltPkiIf(vo);
    			
        		if(!"0".equals(pkiResult)){
        			String helpTelNo = nidMessageSource.getMessage("admTelNo");
        			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{pkiResult, helpTelNo}));
        		} else {
        			model.addAttribute("resultMsg", nidMessageSource.getMessage("apvScsfl.msg"));
        		}
    		}else{
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("apvScsfl.msg")); 
    		}

    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "forward:/rm/clrt/searchListCcltRhbltAprv.do";   	
    } 
    
    
    /**
     * Retrieves Revocation confirmation. <br>
     *
     * @param vo Value-object of Citizen to be parsed request(CcltRhbltVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/clrt/p_CcltCfmRcpt.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/clrt/searchCcltCfmRcpt.do")
    public String searchCcltCfmRcpt(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("ccltRhbltVO") CcltRhbltVO vo,
    		ModelMap model)
            throws Exception {
    	try{   
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd()); 
    		model.addAttribute("useLangCd", user.getUseLangCd());
    		
    		CcltRhbltVO rsdtInfr = service.searchCcltCfmRcpt(vo);
    		model.addAttribute("rsdtInfr", rsdtInfr);
    		List<CcltRhbltVO> lstSpus = service.searchListCcltSpus(vo);
    		model.addAttribute("lstSpus", lstSpus);
    		model.addAttribute("lstSpusCnt", lstSpus.size());
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "/rm/clrt/p_CcltCfmRcpt";   	
    } 
    
    /**
     * Retrieves Rehabilitation confirmation. <br>
     *
     * @param vo Value-object of Citizen to be parsed request(CcltRhbltVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/clrt/p_RhbltCfmRcpt.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/clrt/searchRhbltCfmRcpt.do")
    public String searchRhbltCfmRcpt(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("ccltRhbltVO") CcltRhbltVO vo,
    		ModelMap model)
            throws Exception {
    	try{   
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd()); 
    		model.addAttribute("useLangCd", user.getUseLangCd());
    		
    		CcltRhbltVO rsdtInfr = service.searchRhbltCfmRcpt(vo);
    		model.addAttribute("rsdtInfr", rsdtInfr);
    		List<CcltRhbltVO> lstSpus = service.searchListRhbltSpus(vo);
    		model.addAttribute("lstSpus", lstSpus);
    		model.addAttribute("lstSpusCnt", lstSpus.size());
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "/rm/clrt/p_RhbltCfmRcpt";   	
    }
    
}