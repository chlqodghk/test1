package afnid.rm.mrrg.web;

import java.io.StringWriter;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.mrrg.service.MrrgService;
import afnid.rm.mrrg.service.MrrgVO;
import afnid.rm.rsdt.service.RsdtInfrService;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;



/** 
 * This Controller class processes request of MRRG and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Si Kyung Yang
 * @since 2013.05.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.05.21  		Si Kyung Yang         						Create
 *
 * </pre>
 */
@Controller
public class MrrgController{
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());
	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    //** NidProgrmManageService *//*
	@Resource(name = "mrrgService")
    private MrrgService service;
	
    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdManagerService;

	/** NidCommonService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCommonService;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;

    /** login service */
    @Resource(name="lgService")
    private LgService lgService;
    
    /** rsdtInfoService service */
    @Resource(name="rsdtInfoService")
    private RsdtInfrService rsdtInfoService;
	

    /**
     * Moved to list-screen of Marraige registration. <br>
     * 
     * @param MrrgVO Value-object of mrrg to be parsed request(MrrgVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/MrrgIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/addMrrgView.do")   
    public String addMrrgView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("mrrgVO") MrrgVO vo,
    		ModelMap model) throws Exception {
    	try {
    		//setting today date
			ComDefaultVO vos = nidCommonService.searchPerToDay(comDefaultVO);
	    	model.addAttribute("toDateP", vos != null && vos.getStartDay() != null ? vos.getStartDay().replaceAll("-", "") : "");
	    	vos = nidCommonService.searchGreToDay(comDefaultVO);
	    	model.addAttribute("toDateG", vos != null && vos.getStartDay() != null ? vos.getStartDay().replaceAll("-", "") : "");
	    	
	    	int crdDlvrDd = propertiesService.getInt("crdDlvrDd");
	    	comDefaultVO.setAddDay(String.valueOf(crdDlvrDd));
	    	vos = nidCommonService.searchGreAddingInputDay(comDefaultVO);
	    	vo.setCrdReisuceDueDd(vos.getStartDay());
	    	
	    	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		vo.setUseLangCd(user.getUseLangCd());
	    	
	    	lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());	//menu log
	    	vo.setUseLangCd(vo.getUseLangCd());

	    	int mlMrrgAge = propertiesService.getInt("mlMrrgAge");
	    	vo.setMlMrrgAge(String.valueOf(mlMrrgAge));
	    	int femlMrrgAge = propertiesService.getInt("femlMrrgAge");
	    	vo.setFemlMrrgAge(String.valueOf(femlMrrgAge));
	    	int ntMrrgDivrDm = propertiesService.getInt("ntMrrgDivrDm");
	    	vo.setNtMrrgDivrDm(String.valueOf(ntMrrgDivrDm));
	    	int alwWifeNo = propertiesService.getInt("alwWifeNo");
	    	vo.setAlwWifeNo(String.valueOf(alwWifeNo));
	    	int kochiUprAdCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("kochiUprAdCd", kochiUprAdCd);
    		
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd)); // Setting Kochi Address Code
    		EgovMap kochiAd = cmmCdManagerService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAd", kochiAd); 
	    		
    		cmCmmCd.setGrpCd("14"); 
    		List<CmCmmCdVO> NationCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("NationCd", NationCd);
    		
    		cmCmmCd.setGrpCd("9"); 
    		List<CmCmmCdVO> rlCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlCd", rlCd);
    		
	    	List<MrrgVO> rlList = service.searchListRlTbAll(vo);
	    	model.addAttribute("rlList", rlList);    		
    		
    			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/mrrg/MrrgIns";
    }    
    
    /**
     * Retrives inforamtion of Citizen for marriage. <br>
     *
     * @param MrrgVO Value-object of resident to be parsed request(MrrgVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out xml
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/selectMrrgRsdtInfo.do")
    public void searchMrrgRsdtInfr(
    		@ModelAttribute("mrrgVO") MrrgVO vo,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
       		vo.setUseLangCd(user.getUseLangCd());
       		
       		int ntMrrgDivrDm = propertiesService.getInt("ntMrrgDivrDm");
			vo.setNtMrrgDivrDm(String.valueOf(ntMrrgDivrDm));
       		int crdReisuceDmBfExpr = propertiesService.getInt("crdReisuceDmBfExpr");
       		vo.setCrdReisuceDmBfExpr(String.valueOf(crdReisuceDmBfExpr));
       		int mlMrrgAge = propertiesService.getInt("mlMrrgAge");
       		vo.setMlMrrgAge(String.valueOf(mlMrrgAge));
       		int femlMrrgAge = propertiesService.getInt("femlMrrgAge");
       		vo.setFemlMrrgAge(String.valueOf(femlMrrgAge));
       		int alwWifeNo = propertiesService.getInt("alwWifeNo");

    		EgovMap em = service.searchMrrgRsdtInfr(vo);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element flagInfo = doc.createElement("info");
			root.appendChild(flagInfo);
			Element ele = doc.createElement("flag");
			Element ele2 = doc.createElement("alwWifeMsg");
    		if(em != null){
    			//resident NID available    		
    			
    			String gdrCd = NidStringUtil.nullConvert(em.get("gdrCd"));

    			String rsdtSeqNo = NidStringUtil.nullConvert(em.get("rsdtSeqNo"));

    			vo.setRsdtSeqNo(rsdtSeqNo);

    			String flagVal = "";
    			String lstDvrcDd = "";
    			String hsbdDthDd = "";
    			String hsbdRsdtSeqNo= "";
    			String alwWifeMsg="";
    			
    			if(gdrCd != null){
    				if("1".equals(gdrCd) ){
    					int mlMrrgCn = service.searchMlMrrgCn(vo);
    					//wife check (1~4)

    					if(mlMrrgCn < alwWifeNo){
    						flagVal = "1";
    					}else{
    						flagVal = "2";
    						vo.setAlwWifeNo(String.valueOf(alwWifeNo));
    						alwWifeMsg = service.searchMrrgWifeNm(vo);	
    					}
    				}else if("2".equals(gdrCd) ){
    					//husband check (only one)
    					vo.setWifeRsdtSeqNo(rsdtSeqNo);
    					EgovMap femlResult = service.searchFemlMrrgInfr(vo);
    					
    					flagVal = NidStringUtil.nullConvert(femlResult.get("flagVal")); 
    					lstDvrcDd = NidStringUtil.nullConvert(femlResult.get("dvrcDd"));
						hsbdDthDd = NidStringUtil.nullConvert(femlResult.get("ccltDd"));
    					hsbdRsdtSeqNo = NidStringUtil.nullConvert(femlResult.get("spusRsdtSeqNo"));    				
    				}
    			}
    			
    			//check for Citizen Revocation Status
    			String rvctgStus = rsdtInfoService.searchRsdtRvctgStus(vo.getRsdtNo(), "code");

    			if(!"".equals(rvctgStus)){
    				if("rvctgApl".equals(rvctgStus)){
    					flagVal = "5";
    				}else if("rvctg".equals(rvctgStus) || "nExist".equals(rvctgStus)){
    					flagVal = "6";
    				}
    			}
    			
    			setFlagNode(doc, flagInfo, ele, flagVal);
    			setFlagNode(doc, flagInfo, ele2, alwWifeMsg);
    			
    			Element rsdtInfo = doc.createElement("rsdtInfo");
    			root.appendChild(rsdtInfo);
    			
    			Element node = doc.createElement("rsdtSeqNo");
    			node.appendChild(doc.createTextNode(rsdtSeqNo));
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("surnm");
    			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("surnm"))) );
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("givNm");
    			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("givNm"))) );
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("enSurnm");
    			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("enSurnm"))) );
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("enGivNm");
    			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("enGivNm"))) );
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("fthrNm");
    			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("fthrNm"))) );
    			rsdtInfo.appendChild(node);
    		    			
    			node = doc.createElement("gdrCd");    			
    			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("gdrCd"))) );
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("hadNm");
    			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("hadNm"))) );
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("rlCd");
    			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("rlCd"))) );
    			rsdtInfo.appendChild(node);

    			node = doc.createElement("rlCdNm");
    			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("rlCdNm"))) );
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("othrRl");
    			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("othrRl"))) );
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("mrrgAgeDd");
    			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("mrrgAgeDd"))) );
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("fmlyBokNo");
    			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("fmlyBokNo"))));
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("fmlyBokNoDp");
    			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("fmlyBokNoDp"))));
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("lstDvrcDd");
    			node.appendChild(doc.createTextNode(lstDvrcDd) );
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("hsbdDthDd");
    			node.appendChild(doc.createTextNode(hsbdDthDd) );
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("spusRsdtSeqNo");
    			node.appendChild(doc.createTextNode(hsbdRsdtSeqNo) );
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("fmlyHadSeqNo");
    			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("fmlyHadSeqNo"))) );
    			rsdtInfo.appendChild(node);
    			
    			if("1".equals(gdrCd)){
    				node = doc.createElement("hsbdPmntAdCd");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("pmntAdCd"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("hsbdPmntAdCdNm");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("pmntAdCdNm"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("hsbdPmntAdDtlCt");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("pmntAdDtlCt"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("hsbdCurtAdDiv");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("curtAdDiv"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("hsbdCurtAdCd");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("curtAdCd"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("hsbdCurtAdCdNm");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("curtAdCdNm"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("hsbdCurtAdNatCd");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("curtAdNatCd"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("hsbdCurtAdNatCdNm");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("curtAdNatCdNm"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("hsbdCurtAdDtlCt");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("curtAdDtlCt"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("hsbdSmrRsdcCd");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("smrRsdcCd"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("hsbdSmrRsdcCdNm");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("smrRsdcCdNm"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("hsbdWtrRsdcCd");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("wtrRsdcCd"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("hsbdWtrRsdcCdNm");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("wtrRsdcCdNm"))) );
        			rsdtInfo.appendChild(node);

    			}else if("2".equals(gdrCd)){
    				
        			node = doc.createElement("wifePmntAdCd");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("pmntAdCd"))) );
        			rsdtInfo.appendChild(node);

        			node = doc.createElement("wifePmntAdDtlCt");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("pmntAdDtlCt"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("wifeCurtAdDiv");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("curtAdDiv"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("wifeCurtAdCd");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("curtAdCd"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("wifeCurtAdNatCd");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("curtAdNatCd"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("wifeCurtAdDtlCt");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("curtAdDtlCt"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("wifeSmrRsdcCd");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("smrRsdcCd"))) );
        			rsdtInfo.appendChild(node);
        			
        			node = doc.createElement("wifeWtrRsdcCd");
        			node.appendChild(doc.createTextNode(NidStringUtil.nullConvert(em.get("wtrRsdcCd"))) );
        			rsdtInfo.appendChild(node);
        			
    			}
    						
    			String cardStatus = rsdtInfoService.searchRsdtCrdIsuAppStus(vo.getRsdtNo(), "msg", "m");

    			int isuCnt = rsdtInfoService.searchRsdtCrdIsuStus(vo.getRsdtNo());
    			
    			String canNameChangeYn = "N";
    			String nameChangeMsg = "";
    			
    			if("".equals(cardStatus) && "N".equals((String)em.get("isExp"))&& 0 < isuCnt){
    				canNameChangeYn = "Y";
    			}else if(0 >= isuCnt){
    				nameChangeMsg =  nidMessageSource.getMessage("fstCrdIsuceCdd.msg");
    			}else if(!"".equals(cardStatus)){
    				nameChangeMsg =  nidMessageSource.getMessage(cardStatus);
    			}else if(!"N".equals((String)em.get("isExp"))){
    				String month = vo.getCrdReisuceDmBfExpr(); 
    				if(!"3".equals(vo.getUseLangCd())){
    					month =	NidStringUtil.toNumberConvet(month, "J");
    				}
    				nameChangeMsg =  nidMessageSource.getMessage("crdExpReisuce.msg", new String[]{month});
    			}
    			
    			node = doc.createElement("canNameChangeYn");
    			node.appendChild(doc.createTextNode(canNameChangeYn));
    			rsdtInfo.appendChild(node);
    			
    			node = doc.createElement("nameChangeMsg");
    			node.appendChild(doc.createTextNode(nameChangeMsg));
    			rsdtInfo.appendChild(node);
    			
    		}else{
    			//resident NID exist
    			setFlagNode(doc, flagInfo, ele, "3");
    			setFlagNode(doc, flagInfo, ele2, "");
    		}
    		
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    //make xml node
    private void setFlagNode(Document doc, Element parentEle, Element element, String nodeValue){
    	if(doc != null && element != null && nodeValue != null){
	    	Text text = doc.createTextNode(nodeValue);
	    	element.appendChild(text);
	    	parentEle.appendChild(element);
    	}
    }    

    /**
     * New Registration of Marrage. <br>
     * 
     * @param MrrgVO Value-object of mrrg to be parsed request(MrrgVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/MrrgIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/addMrrgInfr.do")   
    public String addMrrgInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("mrrgVO") MrrgVO vo,
    		ModelMap model) throws Exception {
    	try {
    		
    		String result = service.addMrrgInfr(vo);

    		if(null != result && !"".equals(result)){
    			
    			boolean mFlag = false;
    			boolean fFlag = false;
    			//result R: reissuance, W:rewrite, N: none
    			String mResult = service.searchResultOfCrdInfrChang(vo, "M");
    			if("W".equals(mResult)){
    				mFlag = true;	
    			}
    			
    			String fResult = service.searchResultOfCrdInfrChang(vo, "F");
    			if("W".equals(fResult)){
    				fFlag = true;	
    			}

    			if(mFlag || fFlag){
    				StringBuffer argVal = new StringBuffer("");
            		String wife= nidMessageSource.getMessage("wife");
            		String hsbd= nidMessageSource.getMessage("hsbd");
            		
    				if(mFlag && fFlag){
    					argVal.append(hsbd).append(", ").append(wife);
    				}else if(mFlag){
    					argVal.append(hsbd);
    				}else if(fFlag){
    					argVal.append(wife);
    				}
    				
    				model.addAttribute("writeMsg", nidMessageSource.getMessage("datSavWithWriteVal.msg",new String[]{argVal.toString()}));
    			}
    			
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    			return "forward:/rm/mrrg/searchMrrgUdtInfr.do?mrrgSeqNo="+result;
    		}else{
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("insFail.msg"));
    		}
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "forward:/rm/mrrg/addMrrgView.do";
    }
    
    /**
     * Moved to list-screen of Marraige Modification. <br>
     * 
     * @param MrrgVO Value-object of mrrg to be parsed request(MrrgVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/MrrgUpd.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/modifyMrrgView.do")   
    public String modifyMrrgView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("mrrgVO") MrrgVO vo,
    		ModelMap model) throws Exception {
    	try {	
    			
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("14"); 
    		List<CmCmmCdVO> resultCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("NationCd", resultCd);
    		
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd)); // Setting Kochi Address Code
    		EgovMap kochiAd = cmmCdManagerService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAd", kochiAd);
    		
    		int kochiUprAdCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("kochiUprAdCd", kochiUprAdCd);
    		
    		model.addAttribute("totCnt", "-1");
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/mrrg/MrrgUdt";
    } 
    
    /**
     * Moved to list-screen of mrrg. <br>
     * 
     * @param MrrgVO Value-object of mrrg to be parsed request(MrrgVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/MrrgUpd.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/searchMrrgUdtInfr.do")   
    public String searchMrrgUdtInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("mrrgVO") MrrgVO vo,
    		ModelMap model) throws Exception {
    	try {	
    		
    		ComDefaultVO sVo = nidCommonService.searchPerToDay	(comDefaultVO);
	    	model.addAttribute("toDateP", sVo != null && sVo.getStartDay() != null ? sVo.getStartDay().replaceAll("-", "") : "");
	    	sVo = nidCommonService.searchGreToDay(comDefaultVO);
	    	model.addAttribute("toDateG", sVo != null && sVo.getStartDay() != null ? sVo.getStartDay().replaceAll("-", "") : "");
    		
	    	int kochiUprAdCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("kochiUprAdCd", kochiUprAdCd);
	    	
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd)); // Setting Kochi Address Code
    		EgovMap kochiAd = cmmCdManagerService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAd", kochiAd);
    		
    		cmCmmCd.setGrpCd("14"); 
    		List<CmCmmCdVO> resultCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("NationCd", resultCd);
    		
    		cmCmmCd.setGrpCd("9"); 
    		List<CmCmmCdVO> rlCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlCd", rlCd);
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd();
    		vo.setRgstOrgnzCd( orgnzCd );
    		vo.setUseLangCd(user.getUseLangCd());    		
    		
    		//find enid
    		MrrgVO vo2 = new MrrgVO();
    		if(null == vo.getMrrgSeqNo() || "".equals(vo.getMrrgSeqNo())){
    			vo2 = service.searchMrrgUdtRsdtInfr( vo );
        		//check Enid Number (Exist or Not)
        		if( null == vo2 ){
        			model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstEnid.msg") );
        			return "/rm/mrrg/MrrgUdt";
        		}
        		
        		vo.setRsdtSeqNo( vo2.getRsdtSeqNo() );
        		vo.setGdrCd(vo2.getGdrCd());
    		}

			// total marriage information
    		List<EgovMap> mrrgSeqList = service.searchMrrgUdtInfrTotCnt( vo );    			
			model.addAttribute("totCnt", mrrgSeqList.size());
			 
			if( 0 == mrrgSeqList.size() ){

				model.addAttribute("resultMsg", nidMessageSource.getMessage("nMrrgHst.msg") );
    			return "/rm/mrrg/MrrgUdt";
    		
			}else if( 1 == mrrgSeqList.size() ){
				
				EgovMap mrrgSeqMap = mrrgSeqList.get(0);
				vo.setMrrgSeqNo(NidStringUtil.nullConvert(mrrgSeqMap.get("mrrgSeqNo")) );

				int crdReisuceDmBfExpr = propertiesService.getInt("crdReisuceDmBfExpr");
				vo.setCrdReisuceDmBfExpr(String.valueOf(crdReisuceDmBfExpr));
				int mlMrrgAge = propertiesService.getInt("mlMrrgAge");
				vo.setMlMrrgAge(String.valueOf(mlMrrgAge));
				int femlMrrgAge = propertiesService.getInt("femlMrrgAge");
				vo.setFemlMrrgAge(String.valueOf(femlMrrgAge));
				int ntMrrgDivrDm = propertiesService.getInt("ntMrrgDivrDm");
				vo.setNtMrrgDivrDm(String.valueOf(ntMrrgDivrDm));
				int crdDlvrDd = propertiesService.getInt("crdDlvrDd");
				vo.setCrdDlvrDd(String.valueOf(crdDlvrDd));

				//get marriage information
				vo2 = service.searchMrrgUdtInfr(vo); 
				
				if( !vo2.getRgstOrgnzCd().startsWith(orgnzCd) ){
    				model.addAttribute("resultMsg", nidMessageSource.getMessage("rgstOthrOfic.msg",new String[]{vo2.getRgstOrgnzCdNm()}) );
    				model.addAttribute("totCnt", "-1"); 
    				return "/rm/mrrg/MrrgUdt";
    			}
				
				//get female divorce date
				String lstDvrcDd = "";
				String hsbdDthDd = "";
				String canNameChangeYn = "N";
    			String nameChangeMsg = "";
    			String canHsbdAdChangYn ="N";
    			String hsbdAdChangeMsg = "";
				if(null != vo2.getWifeRsdtSeqNo() && !"".equals(vo2.getWifeRsdtSeqNo())){
					vo2.setNtMrrgDivrDm(String.valueOf(ntMrrgDivrDm));
					EgovMap femlResult = service.searchFemlMrrgInfr(vo2);
					lstDvrcDd = NidStringUtil.nullConvert(femlResult.get("dvrcDd"));
					hsbdDthDd = NidStringUtil.nullConvert(femlResult.get("ccltDd"));
					
					String cardStatus = rsdtInfoService.searchRsdtCrdIsuAppStus(vo2.getWifeRsdtNo(), "msg", "m");
					int isuCnt = rsdtInfoService.searchRsdtCrdIsuStus(vo2.getWifeRsdtNo());
					
	    			if("".equals(cardStatus) && "N".equals(vo2.getIsExp())&& 0 < isuCnt){
	    				canNameChangeYn = "Y";
	    			}else if(0 >= isuCnt){
	    				nameChangeMsg =  nidMessageSource.getMessage("fstCrdIsuceCdd.msg");
	    			}else if(!"".equals(cardStatus)){
	    				nameChangeMsg =  nidMessageSource.getMessage(cardStatus);
	    			}else if(!"N".equals(vo2.getIsExp())){
	    				String month = vo.getCrdReisuceDmBfExpr(); 
	    				if(!"3".equals(vo.getUseLangCd())){
	    					month =	NidStringUtil.toNumberConvet(month, "J");
	    				}
	    				nameChangeMsg =  nidMessageSource.getMessage("crdExpReisuce.msg", new String[]{month} );
	    			}
					
				}
				
				if(null != vo2.getHsbdRsdtSeqNo() && !"".equals(vo2.getHsbdRsdtSeqNo())){
					String cardStatus = rsdtInfoService.searchRsdtCrdIsuAppStus(vo2.getHsbdRsdtNo(), "msg", "m");
					int isuCnt = rsdtInfoService.searchRsdtCrdIsuStus(vo2.getHsbdRsdtNo());
					
	    			if("".equals(cardStatus) && "N".equals(vo2.getIsHsbdExp())&& 0 < isuCnt){
	    				canHsbdAdChangYn = "Y";
	    			}else if(0 >= isuCnt){
	    				hsbdAdChangeMsg =  nidMessageSource.getMessage("fstCrdIsuceCdd.msg");
	    			}else if(!"".equals(cardStatus)){
	    				hsbdAdChangeMsg =  nidMessageSource.getMessage(cardStatus);
	    			}else if(!"N".equals(vo2.getIsHsbdExp())){
	    				String month = vo.getCrdReisuceDmBfExpr(); 
	    				if(!"3".equals(vo.getUseLangCd())){
	    					month =	NidStringUtil.toNumberConvet(month, "J");
	    				}
	    				hsbdAdChangeMsg =  nidMessageSource.getMessage("crdExpReisuce.msg", new String[]{month} );
	    			}
				}
				
				int alwWifeNo = propertiesService.getInt("alwWifeNo");
    			vo2.setAlwWifeNo(String.valueOf(alwWifeNo));	
				model.addAttribute("lstDvrcDd", lstDvrcDd);
				model.addAttribute("hsbdDthDd", hsbdDthDd);
				vo2.setCanNameChangeYn(canNameChangeYn);
				vo2.setNameChangeMsg(nameChangeMsg);
				vo2.setCanHsbdAdChangYn(canHsbdAdChangYn);
				vo2.setHsbdAdChangeMsg(hsbdAdChangeMsg);
				vo2.setUseLangCd(vo.getUseLangCd());
				vo2.setMlMrrgAge(String.valueOf(mlMrrgAge));
				vo2.setFemlMrrgAge(String.valueOf(femlMrrgAge));
				vo2.setNtMrrgDivrDm(String.valueOf(ntMrrgDivrDm));
				
				model.addAttribute("result", vo2);
			
			}else if( 1 < mrrgSeqList.size() ){
				//call popup
				model.addAttribute("result", vo2);
			}

	    	List<MrrgVO> rlList = service.searchListRlTbAll(vo);
	    	model.addAttribute("rlList", rlList);
	    	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/mrrg/MrrgUdt";
    }
    
    /**
     * Moved to popup list-screen of mrrg. <br>
     * 
     * @param MrrgVO Value-object of mrrg to be parsed request(MrrgVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/p_MrrgList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/searchListMrrgView.do")   
    public String searchListMrrgView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("mrrgVO") MrrgVO vo,
    		@RequestParam(value="rsdtSeqNo" ,required=false) String rsdtSeqNo,
    		ModelMap model) throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		vo.setUseLangCd(user.getUseLangCd());
    		vo.setRsdtSeqNo( rsdtSeqNo );
    		
    		List<MrrgVO> result = service.searchListMrrgUdt( vo );
    		
    		model.addAttribute("result", result);
    		
    		model.addAttribute( "useLangCd",user.getUseLangCd());
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/mrrg/p_MrrgList";
    }
    
    /**
     *  Modify information of Marriage <br>
     * 
     * @param MrrgVO Value-object of marriage information to be parsed request(MrrgVO).
     * @param model Object to be parsed http request(ModelMap) 
     * @return "forward:/rm/mrrg/addMrrgView.do";
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/modifyMrrgInfr.do")   
    public String modifyMrrgInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("mrrgVO") MrrgVO vo,
    		ModelMap model) throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		vo.setUseLangCd(user.getUseLangCd());
    				
    		int result = service.modifyMrrgInfr( vo );    		
    		if(1 == result){
    			
    			boolean mFlag = false;
    			boolean fFlag = false;
    			
    			//result R: reissuance, W:rewrite, N: none
    			String mResult = service.searchResultOfCrdInfrChang(vo, "M");
    			if("W".equals(mResult)){
    				mFlag = true;	
    			}
    			
    			String fResult = service.searchResultOfCrdInfrChang(vo, "F");
    			if("W".equals(fResult)){
    				fFlag = true;	
    			}
    			
    			if(mFlag || fFlag){
    				StringBuffer argVal = new StringBuffer("");
            		String wife= nidMessageSource.getMessage("wife");
            		String hsbd= nidMessageSource.getMessage("hsbd");
            		
    				if(mFlag && fFlag){
    					argVal.append(hsbd).append(", ").append(wife);
    				}else if(mFlag){
    					argVal.append(hsbd);
    				}else if(fFlag){
    					argVal.append(wife);
    				}
    				
    				model.addAttribute("writeMsg", nidMessageSource.getMessage("datSavWithWriteVal.msg",new String[]{argVal.toString()}));
    			}
    			
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}else{
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("udtFail.msg"));
    		}

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "forward:/rm/mrrg/searchMrrgUdtInfr.do";
    }

    /**
     * Moved to list-screen of marriage verification.<br>
     * 
     * @param rsdtInfoVO Value-object of family to be parsed request(mrrgVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/MrrgDvrcVfyLst.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/searchListMrrgDvrcAprvView.do")   
    public String searchListMrrgDvrcAprvView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("mrrgVO") MrrgVO vo,
    		ModelMap model) throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	//세션정보
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		vo.setUseLangCd(user.getUseLangCd());

    		lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());	//menu log
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();    		
    		cmCmmCd.setGrpCd("26"); 
    		List<CmCmmCdVO> cfmYn = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("cfmYn", cfmYn);// confirm y or n code
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/mrrg/MrrgDvrcAprvList";
    } 
    
    /**
     * Retrives List of Information of marriage/Divorce .<br>
     * 
     * @param mrrgVO Value-object of marriage to be parsed request(mrrgVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/MrrgDvrcVfyLst.jsp"
     * @exception Exception
     */    
	@RequestMapping(value="/rm/mrrg/searchListMrrgDvrcAprv.do")   
    public String searchListMrrgDvrcAprv(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("mrrgVO") MrrgVO vo,
    		ModelMap model) throws Exception {
    	try {
	    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	//세션정보
	    		vo.setUserId(user.getUserId());
	    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd();
	    		vo.setRgstOrgnzCd( orgnzCd );
	    		vo.setUseLangCd(user.getUseLangCd());

				/** Paging Setting */
	    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
	    		vo.setPageSize(propertiesService.getInt("pageSize"));
	    		
		    	/** pageing */
		    	PaginationInfo paginationInfo = new PaginationInfo();
				paginationInfo.setCurrentPageNo(vo.getPageIndex());
				paginationInfo.setRecordCountPerPage(vo.getPageUnit());
				paginationInfo.setPageSize(vo.getPageSize());
				vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
				vo.setLastIndex(paginationInfo.getLastRecordIndex());
				vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
				model.addAttribute("paginationInfo", paginationInfo);    
				
				int aprvListTm = propertiesService.getInt("aprvListTm");
				vo.setAprvListTm(String.valueOf(aprvListTm));
				
				List<MrrgVO> lstProgram = service.searchListMrrgDvrcAprv(vo);
	    		model.addAttribute("lstProgram", lstProgram);
	    		
	    		int totCnt = service.searchListTotCntMrrgDvrcAprv(vo);
				paginationInfo.setTotalRecordCount(totCnt);
				
				CmCmmCdVO cmCmmCd = new CmCmmCdVO();

	    		cmCmmCd.setGrpCd("26"); 
	    		List<CmCmmCdVO> cfmYn = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
	    		model.addAttribute("cfmYn", cfmYn);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/mrrg/MrrgDvrcAprvList";
    }    
    
    /**
     * Moved to approve of mrraiage regstration. <br>
     * 
     * @param MrrgVO Value-object of mrrg to be parsed request(MrrgVO)rr
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/MrrgIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/searchMrrgAprvView.do")   
    public String searchMrrgAprvView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("mrrgVO") MrrgVO vo,    		
       		ModelMap model) throws Exception {
    	try {
    		
    		ComDefaultVO sVo = nidCommonService.searchPerToDay	(comDefaultVO);
	    	model.addAttribute("toDateP", sVo != null && sVo.getStartDay() != null ? sVo.getStartDay().replaceAll("-", "") : "");
	    	sVo = nidCommonService.searchGreToDay(comDefaultVO);
	    	model.addAttribute("toDateG", sVo != null && sVo.getStartDay() != null ? sVo.getStartDay().replaceAll("-", "") : "");
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("14"); 
    		List<CmCmmCdVO> resultCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("NationCd", resultCd);
    		
    		cmCmmCd.setGrpCd("9"); 
    		List<CmCmmCdVO> rlCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlCd", rlCd);
    			
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("userId", user.getUserId());
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		vo.setUseLangCd(user.getUseLangCd());   
    		
    		MrrgVO vo2 = new MrrgVO();

    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd)); // Setting Kochi Address Code
    		EgovMap kochiAd = cmmCdManagerService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAd", kochiAd);
    		int kochiUprAdCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("kochiUprAdCd", kochiUprAdCd);
    		int crdReisuceDmBfExpr = propertiesService.getInt("crdReisuceDmBfExpr");
    		vo.setCrdReisuceDmBfExpr(String.valueOf(crdReisuceDmBfExpr));
    		int mlMrrgAge = propertiesService.getInt("mlMrrgAge");
    		vo.setMlMrrgAge(String.valueOf(mlMrrgAge));
    		int femlMrrgAge = propertiesService.getInt("femlMrrgAge");
    		vo.setFemlMrrgAge(String.valueOf(femlMrrgAge));
    		int ntMrrgDivrDm = propertiesService.getInt("ntMrrgDivrDm");
    		vo.setNtMrrgDivrDm(String.valueOf(ntMrrgDivrDm));
    		int crdDlvrDd = propertiesService.getInt("crdDlvrDd");
    		vo.setCrdDlvrDd(String.valueOf(crdDlvrDd));
    		
    		
    		vo2 = service.searchMrrgDtlInfr(vo);
    		
    		//get female divorce date
			String lstDvrcDd = "";
			String hsbdDthDd = "";
			String canNameChangeYn = "N";
			String nameChangeMsg = "";
			String canHsbdAdChangYn ="N";
			String hsbdAdChangeMsg = "";
			
			if(null != vo2.getWifeRsdtSeqNo() && !"".equals(vo2.getWifeRsdtSeqNo())){
				vo2.setNtMrrgDivrDm(String.valueOf(ntMrrgDivrDm));
				EgovMap femlResult = service.searchFemlMrrgInfr(vo2);
				lstDvrcDd = NidStringUtil.nullConvert(femlResult.get("dvrcDd"));
				hsbdDthDd = NidStringUtil.nullConvert(femlResult.get("ccltDd"));
				String pmntAdCd = NidStringUtil.nullConvert(femlResult.get("pmntAdCd"));
				vo2.setWifePmntAdCd(pmntAdCd);
				String cardStatus = rsdtInfoService.searchRsdtCrdIsuAppStus(vo2.getWifeRsdtNo(), "msg", "m");
				int isuCnt = rsdtInfoService.searchRsdtCrdIsuStus(vo2.getWifeRsdtNo());

				if("".equals(cardStatus) && "N".equals(vo2.getIsExp())&& 0 < isuCnt){
					canNameChangeYn = "Y";
				}else if(0 >= isuCnt){
					nameChangeMsg =  nidMessageSource.getMessage("fstCrdIsuceCdd.msg");
				}else if(!"".equals(cardStatus)){
					nameChangeMsg =  nidMessageSource.getMessage(cardStatus);
				}else if(!"N".equals(vo2.getIsExp())){
					String month = vo.getCrdReisuceDmBfExpr(); 
					if(!"3".equals(vo.getUseLangCd())){
						month =	NidStringUtil.toNumberConvet(month, "J");
					}
					nameChangeMsg =  nidMessageSource.getMessage("crdExpReisuce.msg", new String[]{month} );
				}
				
			}
			
			if(null != vo2.getHsbdRsdtSeqNo() && !"".equals(vo2.getHsbdRsdtSeqNo())){

				String cardStatus = rsdtInfoService.searchRsdtCrdIsuAppStus(vo2.getHsbdRsdtNo(), "msg", "m");
				int isuCnt = rsdtInfoService.searchRsdtCrdIsuStus(vo2.getHsbdRsdtNo());

				if("".equals(cardStatus) && "N".equals(vo2.getIsHsbdExp())&& 0 < isuCnt){
					canHsbdAdChangYn = "Y";
				}else if(0 >= isuCnt){
					hsbdAdChangeMsg =  nidMessageSource.getMessage("fstCrdIsuceCdd.msg");
				}else if(!"".equals(cardStatus)){
					hsbdAdChangeMsg =  nidMessageSource.getMessage(cardStatus);
				}else if(!"N".equals(vo2.getIsHsbdExp())){
					String month = vo.getCrdReisuceDmBfExpr(); 
					if(!"3".equals(vo.getUseLangCd())){
						month =	NidStringUtil.toNumberConvet(month, "J");
					}
					hsbdAdChangeMsg =  nidMessageSource.getMessage("crdExpReisuce.msg", new String[]{month} );
				}
			}
			int alwWifeNo = propertiesService.getInt("alwWifeNo");
			vo2.setAlwWifeNo(String.valueOf(alwWifeNo));
			vo2.setCanNameChangeYn(canNameChangeYn);
			vo2.setNameChangeMsg(nameChangeMsg);
			vo2.setCanHsbdAdChangYn(canHsbdAdChangYn);
			vo2.setHsbdAdChangeMsg(hsbdAdChangeMsg);
			vo2.setUseLangCd(vo.getUseLangCd());
			vo2.setMlMrrgAge(String.valueOf(mlMrrgAge));
			vo2.setFemlMrrgAge(String.valueOf(femlMrrgAge));
			vo2.setNtMrrgDivrDm(String.valueOf(ntMrrgDivrDm));
			
			model.addAttribute("lstDvrcDd", lstDvrcDd);
			model.addAttribute("hsbdDthDd", hsbdDthDd);
    		model.addAttribute("result", vo2);
    		
	    	List<MrrgVO> rlList = service.searchListRlTbAll(vo);
	    	model.addAttribute("rlList", rlList);
	    	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/mrrg/MrrgAprvUdt";    	
    } 
    
    /**
     * Update Marriage information in approve screen <br>
     * 
     * @param MrrgVO Value-object of mrrg to be parsed request(MrrgVO)rr
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/MrrgIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/modifyMrrgAprvInfr.do")   
    public String modifyMrrgAprvInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("mrrgVO") MrrgVO vo,
    		ModelMap model) throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		vo.setUseLangCd(user.getUseLangCd());   
    		  		
    		int result = service.modifyMrrgInfr( vo );    		
    		if(1 == result){

    			boolean mFlag = false;
    			boolean fFlag = false;
    			//result R: reissuance, W:rewrite, N: none
    			String mResult = service.searchResultOfCrdInfrChang(vo, "M");
    			if("W".equals(mResult)){
    				mFlag = true;	
    			}
    			log.debug("=======mResult : "+mResult);
    			String fResult = service.searchResultOfCrdInfrChang(vo, "F");
    			if("W".equals(fResult)){
    				fFlag = true;	
    			}
    			log.debug("=======fResult : "+fResult);
    			if(mFlag || fFlag){
    				StringBuffer argVal = new StringBuffer("");
            		String wife= nidMessageSource.getMessage("wife");
            		String hsbd= nidMessageSource.getMessage("hsbd");
            		
    				if(mFlag && fFlag){
    					argVal.append(hsbd).append(", ").append(wife);
    				}else if(mFlag){
    					argVal.append(hsbd);
    				}else if(fFlag){
    					argVal.append(wife);
    				}
    				
    				model.addAttribute("writeMsg", nidMessageSource.getMessage("datSavWithWriteVal.msg",new String[]{argVal.toString()}));
    			}

    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}else{
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("udtFail.msg"));
    		}  		
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "forward:/rm/mrrg/searchMrrgAprvView.do";
    }
    
	/**
     * Moved to list-screen of marriage verification after marriage information save.<br>
     * 
     * @param mrrgVO Value-object of family to be parsed request(mrrgVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/selectMrrgDvrcVfyLst.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/approveMrrgInfr.do")   
    public String approveMrrgInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("mrrgVO") MrrgVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		model.addAttribute("mrrgVO", vo);
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
       		vo.setKochiAdCd(String.valueOf(kochiAdCd));
       		
    		Map<String, String> result = service.approveMrrg(vo);
    	
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("apvScsfl.msg"));	

			String dsuseMsg = result.get("dsuseMsg");
			log.debug("dsuseMsg========> "+dsuseMsg);
			if(!"".equals(dsuseMsg)){
				model.addAttribute("dsuseMsg",dsuseMsg);
			}

    		String hsbdLogSeqNo = result.get("hsbdLogSeqNo");
    		String hsbdParm = result.get("hsbdParm");
    		String wifeLogSeqNo = result.get("wifeLogSeqNo");
    		String wifeParm = result.get("wifeParm");
    		String hsbdWriteResult = "OK";
    		String wifeWriteResult = "OK";
    		StringBuffer pkiResult = new StringBuffer("");
    		StringBuffer argVal = new StringBuffer("");
    		String hsbd = nidMessageSource.getMessage("hsbd");
			String wife = nidMessageSource.getMessage("wife");
    		boolean flag  = false;
			if(!"".equals(hsbdParm)){
    			hsbdWriteResult = service.approveMrrgInfrPkiIf(hsbdLogSeqNo, hsbdParm);
    			pkiResult.append(hsbd).append(":").append(hsbdWriteResult);
    			argVal.append(hsbd);
    			flag  = true;
    		}
    		
    		if(!"".equals(wifeParm)){
    			wifeWriteResult = service.approveMrrgInfrPkiIf(wifeLogSeqNo, wifeParm);
    			if(0 < pkiResult.length()){
    				pkiResult.append(", "); 
    				argVal.append(", ");
    			}
    			pkiResult.append(wife).append(":").append(wifeWriteResult); 
    			argVal.append(wife);
    			flag  = true;
    		}
    		
    		if(flag){
    			if(!"OK".equals(hsbdWriteResult)|| !"OK".equals(wifeWriteResult) ){
        			String helpTelNo = nidMessageSource.getMessage("admTelNo");
        			model.addAttribute("writeMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{pkiResult.toString(), helpTelNo}));
        		}else{
        			model.addAttribute("writeMsg", nidMessageSource.getMessage("datSavWithWriteVal.msg",new String[]{argVal.toString()}));
        		}
    		}

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "forward:/rm/mrrg/searchListMrrgDvrcAprv.do";
    } 
    
    /**
     * Replacement card receipts of program.  <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(MrrgVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/p_RsdtMdfcRcpt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/mrrg/searchMrrgCrdReisuceRcpt.do")
    public String searchRsdtMdfcRcpt (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("mrrgVO") MrrgVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
       		vo.setUseLangCd(user.getUseLangCd());
       		int kochiAdCd = propertiesService.getInt("kochiAdCd");
       		vo.setKochiAdCd(String.valueOf(kochiAdCd));
       		MrrgVO result = null;
       		List<EgovMap> othrlist = null;
       		List<EgovMap> frgnlist = null;
    		
			result = service.searchCrdReisuceRcpt(vo);
			othrlist = service.searchCrdReisuceOthrRcpt(vo);
			frgnlist = service.searchCrdReisuceFrgnRcpt(vo);

    		
    		model.addAttribute("resultVO", result);
    		model.addAttribute("othrNatLangList", othrlist);
    		model.addAttribute("frgnLangList", frgnlist);
    		model.addAttribute("useLangCd", user.getUseLangCd());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/rsdt/p_RsdtMdfcRcpt";   	
    }
	
	/**
     * Receipt for Citizen Confirmation <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(MrrgVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/mrrg/p_MrrgCfmRcpt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/mrrg/searchMrrgCfmRcpt.do")
    public String searchMrrgCfmRcpt (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("mrrgVO") MrrgVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
       		vo.setUseLangCd(user.getUseLangCd());
       		
       		MrrgVO result = service.searchMrrgCfmRcpt(vo);
			model.addAttribute("rsdtInfr", result);
			model.addAttribute("useLangCd", user.getUseLangCd());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/mrrg/p_MrrgCfmRcpt";   	
    }
	
	   /**
     * Retrives wife relationship. <br>
     *
     * @param MrrgVO Value-object of resident to be parsed request(MrrgVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out xml
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/searchListRl.do")
    public void searchListRl(
    		@ModelAttribute("mrrgVO") MrrgVO vo,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
       		vo.setUseLangCd(user.getUseLangCd());

       		List<MrrgVO> rlCdList = null;
       		
    		if( "ALL".equals(vo.getOp()) ){
    			rlCdList = service.searchListRlAll(vo);
    		} else {
    			rlCdList = service.searchListRl(vo);
    			
    			if(rlCdList == null || rlCdList.size() == 0) {
    				rlCdList = service.searchRlOthr(vo);
    			} 		
    		}

    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		
    		Element info;
			
			Element	rlCd;
			Element rlCdNm;			
			
			MrrgVO rowDat = new MrrgVO();
			for(int i=0; i<rlCdList.size(); i++){
	    		info = doc.createElement("info");
				root.appendChild(info);
				
				rowDat = rlCdList.get(i);
				rlCd= doc.createElement("rlCd");
				rlCd.appendChild(doc.createTextNode(rowDat.getAfWifeRlCd()));
				info.appendChild(rlCd);	
				
				rlCdNm= doc.createElement("rlCdNm");
				rlCdNm.appendChild(doc.createTextNode(rowDat.getAfWifeRlCdNm()));
				info.appendChild(rlCdNm);					
			}				

    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }	
}
