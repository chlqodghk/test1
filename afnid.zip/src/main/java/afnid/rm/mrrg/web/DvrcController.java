package afnid.rm.mrrg.web;

import java.io.StringWriter;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.mrrg.service.DvrcService;
import afnid.rm.mrrg.service.DvrcVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;


/** 
 * This Controller class processes request of MVG and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Si Kyung Yang
 * @since 2013.05.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.05.21  		Si Kyung Yang         						Create
 *
 * </pre>
 */
@Controller
public class DvrcController {
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /** DvrcService */
	@Resource(name = "dvrcService")
    private DvrcService service;
	
    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdManagerService;

	/** NidCommonService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCommonService;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;

    /** login service */
    @Resource(name="lgService")
    private LgService lgService;

    /**
     * Moved to list-screen of Divorce Registration. <br>
     * 
     * @param DvrcVO Value-object to be parsed request(DvrcVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/DvrcIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/addDvrcView.do")   
    public String addDvrcView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("dvrcVO") DvrcVO vo,
    		ModelMap model) throws Exception {
    	try {	

    		comDefaultVO.setSearchKeyword2("");
	    	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		vo.setUseLangCd(user.getUseLangCd());
    		
    		lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());	//menu log
    		
    		int kochiUprAdCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("kochiUprAdCd", kochiUprAdCd);
    		
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd)); // Setting Kochi Address Code
    		EgovMap kochiAd = cmmCdManagerService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAd", kochiAd); 
    		
    		cmCmmCd.setGrpCd("14"); 
    		List<CmCmmCdVO> resultCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("NationCd", resultCd);
    		
        	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/mrrg/DvrcIns";
    }
    
    /**
     * Moved to list-screen of Divorce Update. <br>
     * 
     * @param DvrcVO Value-object to be parsed request(DvrcVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/DvrcUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/modifyDvrcView.do")   
    public String modifyDvrcView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("dvrcVO") DvrcVO vo,
    		ModelMap model) throws Exception {
    	try {	
    			
    		comDefaultVO.setSearchKeyword2("");
    		int kochiUprAdCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("kochiUprAdCd", kochiUprAdCd);
    		
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd)); // Setting Kochi Address Code
    		EgovMap kochiAd = cmmCdManagerService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAd", kochiAd); 
    		
    		cmCmmCd.setGrpCd("14"); 
    		List<CmCmmCdVO> resultCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("NationCd", resultCd);
    		
        } catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/mrrg/DvrcUdt";
    }    
    
	/**
     *retrieving information of Marriage. <br>
     * 
     * @param DvrcVO Value-object of Citizen Information to be parsed request(dvrcVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/DvrcIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/searchMrrgInfr.do")   
    public String searchMrrgInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("dvrcVO") DvrcVO vo,
    		ModelMap model) throws Exception {
    	try {
    		
	    	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    		
    		DvrcVO result = new DvrcVO(); 
    		result = service.searchMrrgInfr(vo);
    		
    		if(null != result.getErrMsg() && !"".equals(result.getErrMsg()) ){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage(result.getErrMsg()));
    		}
    		
    		int crdDlvrDd = propertiesService.getInt("crdDlvrDd");
	    	comDefaultVO.setAddDay(String.valueOf(crdDlvrDd));
	    	ComDefaultVO vos = nidCommonService.searchGreAddingInputDay(comDefaultVO);
	    	result.setCrdReisuceDueDd(vos.getStartDay());
    		
    		model.addAttribute("result", result);
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("38"); // Setting Group Code
    		List<CmCmmCdVO> DivorceCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd); // Common Code Interface Call    		
    		cmCmmCd.setGrpCd("14"); 
    		List<CmCmmCdVO> resultCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("NationCd", resultCd);
    		
    		cmCmmCd.setGrpCd("9"); 
    		List<CmCmmCdVO> hsbdRlCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("lstAfHsbdRlCd", hsbdRlCd);
    		
    		cmCmmCd.setGrpCd("9"); 
    		List<CmCmmCdVO> wifeRlCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("lstAfWifeRlCd", wifeRlCd);
    		
    		int kochiUprAdCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("kochiUprAdCd", kochiUprAdCd);
    		
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd)); // Setting Kochi Address Code
    		EgovMap kochiAd = cmmCdManagerService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAd", kochiAd); 
    		
    		
    		//if is not married with foreigner, Exclude "Marriage Status Clear by Foreign  Spouse Death" divorce reason 
    		if("N".equals(result.getHsbdFrngrYn()) && "N".equals(result.getWifeFrngrYn())){
    			Object obj  = null;
    			EgovMap map  = null;
    			for(int i = 0; i < DivorceCd.size(); i++){
    				 obj = (Object)DivorceCd.get(i);
    				 map = (EgovMap)obj;
    				if("3".equals(map.get("cmmCd").toString())){
    					DivorceCd.remove(i);
    				}
    			}
    		}
    		model.addAttribute("DivorceCd", DivorceCd);//Divorce Code    		
    		
	    	//setting today date
			vos = nidCommonService.searchPerToDay	(comDefaultVO);
	    	model.addAttribute("toDateP", vos != null && vos.getStartDay() != null ? vos.getStartDay().replaceAll("-", "") : "");
	    	vos = nidCommonService.searchGreToDay(comDefaultVO);
	    	model.addAttribute("toDateG", vos != null && vos.getStartDay() != null ? vos.getStartDay().replaceAll("-", "") : "");
	    	
	    	List<DvrcVO> rlList = service.searchListRlTbAll(vo);
	    	model.addAttribute("rlList", rlList);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
     
      	return "/rm/mrrg/DvrcIns";
    } 
    
    /**
     * Moved to popup list-screen of marriage Information. <br>
     * 
     * @param DvrcVO Value-object of Citizen Information to be parsed request(DvrcVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/p_MrrgList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/searchListMrrgInfrView.do")   
    public String searchListMrrgInfrView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("dvrcVO") DvrcVO vo,    		
    		@RequestParam(value="rsdtSeqNo" ,required=false) String rsdtSeqNo,
    		ModelMap model) throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		vo.setUseLangCd(user.getUseLangCd());
    		
    		vo.setRsdtSeqNo( rsdtSeqNo );
    		
    		List<DvrcVO> result = service.searchListMrrgInfr( vo );
    		
    		model.addAttribute("result", result);
    		
    		model.addAttribute("useLangCd",user.getUseLangCd());
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/mrrg/p_MrrgList";
    }     
    
    /**
     * Register information of Divorce. <br>
     * 
     * @param DvrcVO Value-object of information of Divorce to be parsed request(dvrcVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : "/rm/mrrg/DvrcIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/addDvrcInfr.do")   
    public String addDvrcInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("dvrcVO") DvrcVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		vo.setUseLangCd(user.getUseLangCd());
    	
    		String result = service.addDvrcInfr(vo);
    		
    		if(null != result && !"".equals(result)){
    			boolean mFlag = false;
    			boolean fFlag = false;

    			//result R: reissuance, W:rewrite, N: none
    			String mResult = service.searchResultOfCrdInfrChang(vo, "M");
    			if("W".equals(mResult)){
    				mFlag = true;	
    			}
    			
    			String fResult = service.searchResultOfCrdInfrChang(vo, "F");
    			if("W".equals(fResult)){
    				fFlag = true;	
    			}
    			
    			if(mFlag || fFlag){
    				StringBuffer argVal = new StringBuffer("");
            		String wife= nidMessageSource.getMessage("wife");
            		String hsbd= nidMessageSource.getMessage("hsbd");
            		
    				if(mFlag && fFlag){
    					argVal.append(hsbd).append(", ").append(wife);
    				}else if(mFlag){
    					argVal.append(hsbd);
    				}else if(fFlag){
    					argVal.append(wife);
    				}
    				
    				model.addAttribute("writeMsg", nidMessageSource.getMessage("datSavWithWriteVal.msg",new String[]{argVal.toString()}));
    			}
    			
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    			return "forward:/rm/mrrg/searchDvrcInfr.do?dvrcSeqNo="+result;
    		}else{
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("insFail.msg"));
    		}
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}      	
      	return "forward:/rm/mrrg/addDvrcView.do";
    } 
    
	/**
     *retrieving information of Divorce. <br>
     * 
     * @param DvrcVO Value-object of Citizen to be parsed request(dvrcVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/DvrcUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/searchDvrcInfr.do")   
    public String searchDvrcInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("dvrcVO") DvrcVO vo,
    		ModelMap model) throws Exception {
    	try {
    		
	    	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    		
    		DvrcVO result = service.searchDvrcInfr(vo);
    		
    		if(null != result.getErrMsgVal() && !"".equals(result.getErrMsgVal()) ){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage(result.getErrMsg(),result.getErrMsgVal()));
    		}else if(null != result.getErrMsg() && !"".equals(result.getErrMsg()) ){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage(result.getErrMsg()));
    		}
    		model.addAttribute("result", result);
    		
    		
    		int kochiUprAdCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("kochiUprAdCd", kochiUprAdCd);
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("38"); // Setting Group Code
    		List<CmCmmCdVO> DivorceCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd); // Common Code Interface Call    		
    		
    		cmCmmCd.setGrpCd("9"); 
    		List<CmCmmCdVO> hsbdRlCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("lstAfHsbdRlCd", hsbdRlCd);
    		
    		cmCmmCd.setGrpCd("9"); 
    		List<CmCmmCdVO> wifeRlCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("lstAfWifeRlCd", wifeRlCd);
    		
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd)); // Setting Kochi Address Code
    		EgovMap kochiAd = cmmCdManagerService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAd", kochiAd); 
    		
    		cmCmmCd.setGrpCd("14"); 
    		List<CmCmmCdVO> resultCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("NationCd", resultCd);
    		
    		//if is not married with foreigner exclude "Marriage Status Clear by Foreign  Spouse Death" divorce reason 
    		if("N".equals(result.getHsbdFrngrYn()) && "N".equals(result.getWifeFrngrYn())){
    			Object obj  = null;
    			EgovMap map  = null;
    			for(int i = 0; i < DivorceCd.size(); i++){
    				 obj = (Object)DivorceCd.get(i);
    				 map = (EgovMap)obj;
    				if("3".equals(map.get("cmmCd").toString())){
    					DivorceCd.remove(i);
    				}
    			}
    		}
    		model.addAttribute("DivorceCd", DivorceCd);//Divorce Code    		
	    	
	    	//setting today date
			ComDefaultVO vos = nidCommonService.searchPerToDay	(comDefaultVO);
	    	model.addAttribute("toDateP", vos != null && vos.getStartDay() != null ? vos.getStartDay().replaceAll("-", "") : "");
	    	vos = nidCommonService.searchGreToDay(comDefaultVO);
	    	model.addAttribute("toDateG", vos != null && vos.getStartDay() != null ? vos.getStartDay().replaceAll("-", "") : "");
    		
	    	List<DvrcVO> rlList = service.searchListRlTbAll(vo);
	    	model.addAttribute("rlList", rlList);
	    	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
     
      	return "/rm/mrrg/DvrcUdt";
    }
    
    /**
     * Moved to popup list-screen of divorce. <br>
     * 
     * @param DvrcVO Value-object of divorce to be parsed request(DvrcVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/p_MrrgList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/searchListDvrcInfrView.do")   
    public String searchListDvrcInfrView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("dvrcVO") DvrcVO vo,    		
    		@RequestParam(value="rsdtSeqNo" ,required=false) String rsdtSeqNo,
    		ModelMap model) throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		vo.setUseLangCd(user.getUseLangCd());
    		
    		vo.setRsdtSeqNo( rsdtSeqNo );
    		
    		List<DvrcVO> result = service.searchListDvrcInfr( vo );
    		
    		model.addAttribute("result", result);
    		
    		model.addAttribute("useLangCd",user.getUseLangCd());
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/mrrg/p_MrrgList";
    }
    
    /**
     * Modify information of Divorce. <br>
     * 
     * @param DvrcVO Value-object of divorce information to be parsed request(dvrcVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : "/rm/mrrg/DvrcIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/modifyDvrcInfr.do")   
    public String modifyDvrcInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("dvrcVO") DvrcVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		vo.setUseLangCd(user.getUseLangCd());
    	
    		int result = service.modifyDvrcInfr(vo);
   		
    		if(1 == result){
    			boolean mFlag = false;
    			boolean fFlag = false;
  			
    			//result R: reissuance, W:rewrite, N: none
    			String mResult = service.searchResultOfCrdInfrChang(vo, "M");
    			if("W".equals(mResult)){
    				mFlag = true;	
    			}
   			
    			String fResult = service.searchResultOfCrdInfrChang(vo, "F");
    			if("W".equals(fResult)){
    				fFlag = true;	
    			}
    			
    			if(mFlag || fFlag){
    				StringBuffer argVal = new StringBuffer("");
            		String wife= nidMessageSource.getMessage("wife");
            		String hsbd= nidMessageSource.getMessage("hsbd");
            		
    				if(mFlag && fFlag){
    					argVal.append(hsbd).append(", ").append(wife);
    				}else if(mFlag){
    					argVal.append(hsbd);
    				}else if(fFlag){
    					argVal.append(wife);
    				}
    				
    				model.addAttribute("writeMsg", nidMessageSource.getMessage("datSavWithWriteVal.msg",new String[]{argVal.toString()}));
    			}
    			
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}else{
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("udtFail.msg"));
    		}
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}      	
      	return "forward:/rm/mrrg/searchDvrcInfr.do";
    }     

    /**
     * Moved to list-screen of mrrg. <br>
     * 
     * @param rsdtInfoVO Value-object of family to be parsed request(mrrgVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/DvrcAprvUdt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/mrrg/searchDvrcAprvView.do")   
	public String searchDvrcAprvView(
		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
		@ModelAttribute("dvrcVO") DvrcVO vo,		
		ModelMap model) throws Exception {
		try {
			
	    	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());			

	    	//setting today date
			ComDefaultVO vos = nidCommonService.searchPerToDay	(comDefaultVO);
	    	model.addAttribute("toDateP", vos != null && vos.getStartDay() != null ? vos.getStartDay().replaceAll("-", "") : "");
	    	vos = nidCommonService.searchGreToDay(comDefaultVO);
	    	model.addAttribute("toDateG", vos != null && vos.getStartDay() != null ? vos.getStartDay().replaceAll("-", "") : "");
	    	
	    	int kochiUprAdCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("kochiUprAdCd", kochiUprAdCd);
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("38"); // Setting Group Code
    		List<CmCmmCdVO> DivorceCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd); // Common Code Interface Call    		
    		
    		cmCmmCd.setGrpCd("9"); 
    		List<CmCmmCdVO> rlCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlCd", rlCd);
    		
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd)); // Setting Kochi Address Code
    		EgovMap kochiAd = cmmCdManagerService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAd", kochiAd); 
    		
    		model.addAttribute("userId", user.getUserId());
    		
    		cmCmmCd.setGrpCd("14"); 
    		List<CmCmmCdVO> resultCd  = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("NationCd", resultCd);    		
			
    		DvrcVO result = service.searchDvrcAprvInfr(vo);
			
			model.addAttribute("result", result);	
    		
			//if is not married with foreigner exclude "Marriage Status Clear by Foreign  Spouse Death" divorce reason 
			if("N".equals(result.getHsbdFrngrYn()) && "N".equals(result.getWifeFrngrYn())){
				Object obj  = null;
				EgovMap map  = null;
				for(int i = 0; i < DivorceCd.size(); i++){
					 obj = (Object)DivorceCd.get(i);
					 map = (EgovMap)obj;
					if("3".equals(map.get("cmmCd").toString())){
						DivorceCd.remove(i);
					}
				}
			}
			model.addAttribute("DivorceCd", DivorceCd);//Divorce Code    		
		
	    	List<DvrcVO> rlList = service.searchListRlTbAll(vo);
	    	model.addAttribute("rlList", rlList);
	    	
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		}
		
		return "/rm/mrrg/DvrcAprvUdt";
	}    
    
    /**
     * Modify information of Divorce. <br>
     * 
     * @param DvrcVO Value-object of divorce information to be parsed request(dvrcVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : "/rm/mrrg/DvrcAprvUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/modifyDvrcAprvInfr.do")   
    public String modifyDvrcAprvInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("dvrcVO") DvrcVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );
    		vo.setUseLangCd(user.getUseLangCd());
    	
    		int result = service.modifyDvrcInfr(vo);
    		
    		if(1 == result){
    			boolean mFlag = false;
    			boolean fFlag = false;
    			
    			//result R: reissuance, W:rewrite, N: none
    			String mResult = service.searchResultOfCrdInfrChang(vo, "M");
    			if("W".equals(mResult)){
    				mFlag = true;	
    			}
   			
    			String fResult = service.searchResultOfCrdInfrChang(vo, "F");
    			if("W".equals(fResult)){
    				fFlag = true;	
    			}

    			if(mFlag || fFlag){
    				StringBuffer argVal = new StringBuffer("");
            		String wife= nidMessageSource.getMessage("wife");
            		String hsbd= nidMessageSource.getMessage("hsbd");
            		
    				if(mFlag && fFlag){
    					argVal.append(hsbd).append(", ").append(wife);
    				}else if(mFlag){
    					argVal.append(hsbd);
    				}else if(fFlag){
    					argVal.append(wife);
    				}
    				
    				model.addAttribute("writeMsg", nidMessageSource.getMessage("datSavWithWriteVal.msg",new String[]{argVal.toString()}));
    			}
    			
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}else{
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("udtFail.msg"));
    		}
	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}      	
      	return "forward:/rm/mrrg/searchDvrcAprvView.do";
    }     
    
	/**
     * Moved to list-screen of marriage verification after marriage information save.<br>
     * 
     * @param mrrgVO Value-object of family to be parsed request(mrrgVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/mrrg/selectMrrgDvrcVfyLst.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/mrrg/approveDvrcInfr.do")   
    public String approveDvrcInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("dvrcVO") DvrcVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setFstRgstUserId(user.getUserId());
    		vo.setUseLangCd(user.getUseLangCd());
    		vo.setLstUdtUserId(user.getUserId());
    		vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd( orgnzCd );		
    		vo.setCfmTamLedrId(user.getUserId());
    		
    		String crdIsucePlceCd = user.getOrgnzClsCd()+ user.getOrgnzCd();
    		vo.setCrdIsucePlceCd(crdIsucePlceCd);
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
       		vo.setKochiAdCd(String.valueOf(kochiAdCd));
       		
       		Map<String, String> result = service.approveDvrcInfr(vo);
    		 		
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("apvScsfl.msg"));
    		
    		model.addAttribute("mrrgVO", vo);
    		
			String dsuseMsg = result.get("dsuseMsg");
			log.debug("dsuseMsg========> "+dsuseMsg);
			if(!"".equals(dsuseMsg)){
				model.addAttribute("dsuseMsg",dsuseMsg);
			}
    			   		  		
    		String hsbdLogSeqNo = result.get("hsbdLogSeqNo");
    		String hsbdParm = result.get("hsbdParm");
    		String wifeLogSeqNo = result.get("wifeLogSeqNo");
    		String wifeParm = result.get("wifeParm");
    		String hsbdWriteResult = "OK";
    		String wifeWriteResult = "OK";
    		StringBuffer pkiResult = new StringBuffer("");
    		StringBuffer argVal = new StringBuffer("");
    		String hsbd = nidMessageSource.getMessage("hsbd");
			String wife = nidMessageSource.getMessage("wife");
			boolean flag  = false;
			
			if(!"".equals(hsbdParm)){
    			hsbdWriteResult = service.approveDvrcInfrPkiIf(hsbdLogSeqNo, hsbdParm);
    			pkiResult.append(hsbd).append(":").append(hsbdWriteResult);
    			argVal.append(hsbd);
    			flag  = true;
    		}
			
			if(!"".equals(wifeParm)){
    			wifeWriteResult = service.approveDvrcInfrPkiIf(wifeLogSeqNo, wifeParm);
    			if(0 < pkiResult.length()){
    				pkiResult.append(", "); 
    				argVal.append(", ");
    			}
    			pkiResult.append(wife).append(":").append(wifeWriteResult); 
    			argVal.append(wife);
    			flag  = true;
    		}
			
			if(flag){
    			if(!"OK".equals(hsbdWriteResult)|| !"OK".equals(wifeWriteResult) ){
        			String helpTelNo = nidMessageSource.getMessage("admTelNo");
        			model.addAttribute("writeMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{pkiResult.toString(), helpTelNo}));
        		}else{
        			model.addAttribute("writeMsg", nidMessageSource.getMessage("datSavWithWriteVal.msg",new String[]{argVal.toString()}));
        		}
    		}
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "forward:/rm/mrrg/searchListMrrgDvrcAprv.do";
    }
    
    /**
     * Replacement card receipts of program.  <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(MrrgVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/p_RsdtMdfcRcpt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/mrrg/searchDvrcCrdReisuceRcpt.do")
    public String searchDvrcCrdReisuceRcpt (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("mrrgVO") DvrcVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
       		vo.setUseLangCd(user.getUseLangCd());
       		
       		int kochiAdCd = propertiesService.getInt("kochiAdCd");
       		vo.setKochiAdCd(String.valueOf(kochiAdCd));
       		
       		List<EgovMap> othrlist = null;
       		List<EgovMap> frgnlist = null;
    		
       		DvrcVO result = service.searchDvrcCrdReisuceRcpt(vo);
			othrlist = service.searchDvrcCrdReisuceOthrRcpt(vo);
			frgnlist = service.searchDvrcCrdReisuceFrgnRcpt(vo);

    		
    		model.addAttribute("resultVO", result);
    		model.addAttribute("othrNatLangList", othrlist);
    		model.addAttribute("frgnLangList", frgnlist);
    		model.addAttribute("useLangCd", user.getUseLangCd());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/rsdt/p_RsdtMdfcRcpt";   	
    }
	
	/**
     * Receipt for Citizen Confirmation <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(MrrgVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/mrrg/p_DvrcCfmRcpt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/mrrg/searchDvrcCfmRcpt.do")
    public String searchDvrcCfmRcpt (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("mrrgVO") DvrcVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
       		vo.setUseLangCd(user.getUseLangCd());
       		
       		//int kochiAdCd = propertiesService.getInt("kochiAdCd");
       		//model.addAttribute("kochiAdCd", kochiAdCd);
    		
       		DvrcVO result = service.searchDvrcCfmRcpt(vo);
			model.addAttribute("rsdtInfr", result);
			model.addAttribute("useLangCd", user.getUseLangCd());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/mrrg/p_DvrcCfmRcpt";   	
    }
	
	  /**
	  * Retrives wife relationship. <br>
	  *
	  * @param MrrgVO Value-object of resident to be parsed request(MrrgVO)
	  * @param model Object to be parsed http request(ModelMap)
	  * @return Printed out xml
	  * @exception Exception
	  */
	 @RequestMapping(value="/rm/mrrg/searchListAfRl.do")
	 public void searchListAfRl(
	 		@ModelAttribute("dvrcVO") DvrcVO vo,
	 		ModelMap model,
	 		HttpServletResponse response)
	         throws Exception {
	 	try{
	 		
	 		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			vo.setUseLangCd(user.getUseLangCd());
	
			List<DvrcVO> rlCdList = null;
			
			if( "ALL".equals(vo.getOp()) ){
				rlCdList = service.searchListRlAll(vo);
			} else {
				rlCdList = service.searchListRl(vo);
				
				if(rlCdList == null || rlCdList.size() == 0) {
					rlCdList = service.searchListRlOthr(vo);
				}			
			}
			
			
	 		
	 		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
	 		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
	 		Document doc = docBuilder.newDocument();
	 		Element root = doc.createElement("root");
	 		doc.appendChild(root);
	 		
	 		Element info;
				
			Element	rlCd;
			Element rlCdNm;
			
	 
			
			DvrcVO rowDat = new DvrcVO();
			for(int i=0; i<rlCdList.size(); i++){
	    		info = doc.createElement("info");
				root.appendChild(info);
				
				rowDat = rlCdList.get(i);
				rlCd= doc.createElement("rlCd");
				rlCd.appendChild(doc.createTextNode(rowDat.getRlCd()));
				info.appendChild(rlCd);	
				
				rlCdNm= doc.createElement("rlCdNm");
				rlCdNm.appendChild(doc.createTextNode(rowDat.getRlCdNm()));
				info.appendChild(rlCdNm);					
			}				
	
	 		Properties output = new Properties();
	 	    output.setProperty(OutputKeys.INDENT, "yes");
	 	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
	 	    TransformerFactory tf = TransformerFactory.newInstance();
	 		Transformer t = tf.newTransformer();
	 	    t.setOutputProperties(output);
	 		StringWriter sw = new StringWriter();
	 		StreamResult result = new StreamResult(sw);
	 		DOMSource source = new DOMSource(doc);
	 		t.transform(source, result);    		
	 		response.setContentType("text/xml; charset=utf-8");
	 		response.getWriter().write(sw.toString());
	 	}catch (Exception e) {
	 		log.error(e.getMessage(), e);
	 		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
	 	}
	 }
	 
	 /**
	 * Retrives wife relationship. <br>
	 *
	 * @param MrrgVO Value-object of resident to be parsed request(MrrgVO)
	 * @param model Object to be parsed http request(ModelMap)
	 * @return Printed out xml
	 * @exception Exception
	 */
	@RequestMapping(value="/rm/mrrg/searchMberCn.do")
	public void searchMberCn(
			@ModelAttribute("dvrcVO") DvrcVO vo,
			ModelMap model,
			HttpServletResponse response)
	        throws Exception {
		try{
			
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			vo.setUseLangCd(user.getUseLangCd());
	
	
			int	mberCn_result = service.searchMberCn(vo);
	
			
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();
			Element root = doc.createElement("root");
			doc.appendChild(root);
			
			Element info;		
			Element	mberCn;
			
	   		info = doc.createElement("info");
			root.appendChild(info);
				
			mberCn= doc.createElement("mberCn");
			mberCn.appendChild(doc.createTextNode(String.valueOf(mberCn_result)));
			info.appendChild(mberCn);	
					
	
			Properties output = new Properties();
		    output.setProperty(OutputKeys.INDENT, "yes");
		    output.setProperty(OutputKeys.ENCODING, "UTF-8");
		    TransformerFactory tf = TransformerFactory.newInstance();
			Transformer t = tf.newTransformer();
		    t.setOutputProperties(output);
			StringWriter sw = new StringWriter();
			StreamResult result = new StreamResult(sw);
			DOMSource source = new DOMSource(doc);
			t.transform(source, result);    		
			response.setContentType("text/xml; charset=utf-8");
			response.getWriter().write(sw.toString());
		}catch (Exception e) {
			log.error(e.getMessage(), e);
			model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		}
	}
}