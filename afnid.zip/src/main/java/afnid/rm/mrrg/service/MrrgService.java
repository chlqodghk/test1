package afnid.rm.mrrg.service;

import java.util.List;
import java.util.Map;
import egovframework.rte.psl.dataaccess.util.EgovMap;

public interface MrrgService {
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(MrrgVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	EgovMap searchMrrgRsdtInfr(MrrgVO vo) throws Exception;	
	
	/**
	 * Retrieve female marriage information. <br>
	 *
	 * @param vo Input item for retrieving female marriage information.(MrrgVO).
	 * @return EgovMap  Retrieve female marriage information
	 * @exception Exception
	 */
	EgovMap searchFemlMrrgInfr(MrrgVO vo) throws Exception;	
	
	/**
	 * Retrieve Count of Male Marriage<br>
	 *
	 * @param vo Input item for retrieving Count of Male Marriage.(MrrgVO).
	 * @return int counting of Male Marriage.
	 * @exception Exception
	 */
	int searchMlMrrgCn(MrrgVO vo) throws Exception;	
	
	/**
	 * Retrieve wife information<br>
	 *
	 * @param vo Input item for retrieving retrieving wife information.(MrrgVO).
	 * @return String wife's name and eNID message.
	 * @exception Exception
	 */
	String searchMrrgWifeNm(MrrgVO vo) throws Exception;	
		
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(MrrgVO).
	 * @return Marriage Seq No.
	 * @exception Exception
	 */
	String addMrrgInfr(MrrgVO vo) throws Exception;

	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(MrrgVO).
	 * @return List Retrieve list of program
	 * @exception Exception 
	 */
	List<MrrgVO> searchListMrrgDvrcAprv(MrrgVO vo) throws Exception;	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(MrrgVO)
	 * @return int Total Count of Program List
	 * @exception Exception  
	 */
	int searchListTotCntMrrgDvrcAprv(MrrgVO vo) throws Exception;
	

	

	
	/**
	 * Modifying information of marriage.<br>
	 * @param vo Input item for modifying information of marriage(MrrgVO).
	 * @return void
	 * @exception Exception 
	 */
	Map<String,String> approveMrrg(MrrgVO vo) throws Exception;
	

	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(MrrgVO).
	 * @return List<EgovMap> List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchMrrgUdtInfrTotCnt(MrrgVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(MrrgVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	MrrgVO searchMrrgUdtRsdtInfr(MrrgVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(MrrgVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	MrrgVO searchMrrgUdtInfr(MrrgVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(MrrgVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	MrrgVO searchMrrgDtlInfr(MrrgVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(MrrgVO).
	 * @return List Retrieve list of program
	 * @exception Exception 
	 */
	List<MrrgVO> searchListMrrgUdt(MrrgVO vo) throws Exception;
	
	/**
	 * Modify marriage information. <br>
	 *
	 * @param vo Input item for modifying marriage information(MrrgVO).
	 * @return int Result Count
	 * @exception Exception
	 */
	int modifyMrrgInfr(MrrgVO vo) throws Exception;	
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 * @param vo Input item for retrieving Receipt of Citizen.(MrrgVO)
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
	MrrgVO searchCrdReisuceRcpt(MrrgVO vo) throws Exception;
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 *
	 * @param vo Input item for retrieving Receipt of Citizen.(MrrgVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchCrdReisuceOthrRcpt(MrrgVO vo) throws Exception;
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 *
	 * @param vo Input item for retrieving Receipt of Citizen.(MrrgVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap>  searchCrdReisuceFrgnRcpt(MrrgVO vo) throws Exception;
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 * @param vo Input item for retrieving Receipt of Citizen Confirmation.(MrrgVO)
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
	MrrgVO searchMrrgCfmRcpt(MrrgVO vo) throws Exception;
	
	/**
	 * Retrieves of wife permanent address code. <br>
	 * @param wifeSeqNo Input item for retrieving wife permanent address code.(String)
	 * @return String wife permanent address code
	 * @exception Exception
	 */
	String searchResultOfCrdInfrChang(MrrgVO vo, String gdr) throws Exception;
	
	/**
	 * send to write citizen information request <br>
	 * @param hsbdLogSeqNo Input item for inserting log.(String).
	 * @param hsbdParm Input item for sending to write citizen information request.(String).
	 * @return status result
	 * @exception Exception
	 */
	String approveMrrgInfrPkiIf(String hsbdLogSeqNo, String hsbdParm) throws Exception;
	
	/**
	 * Retrieves wife relationship. <br>
	 *
	 * @param vo Input item for retrieving wife relationship(MrrgVO).
	 * @return relationship code
	 * @exception Exception
	 */
	List<MrrgVO> searchListRl(MrrgVO vo) throws Exception;	
	
	/**
	 * Retrieves wife relationship. <br>
	 *
	 * @param vo Input item for retrieving wife relationship(MrrgVO).
	 * @return relationship code
	 * @exception Exception
	 */
	List<MrrgVO> searchRlOthr(MrrgVO vo) throws Exception;	
	
	/**
	 * Retrieves wife relationship. <br>
	 *
	 * @param vo Input item for retrieving relationship(MrrgVO).
	 * @return relationship code
	 * @exception Exception
	 */
	List<MrrgVO> searchListRlAll(MrrgVO vo) throws Exception;
	
	/**
	 * Retrieves wife relationship. <br>
	 *
	 * @param vo Input item for retrieving relationship(MrrgVO).
	 * @return relationship code
	 * @exception Exception
	 */
	List<MrrgVO> searchListRlTbAll(MrrgVO vo) throws Exception;	
	
	/**
	 * Retrieves total count relationship in family book.. <br>
	 *
	 * @param vo Input item for retrieving total count relationship in family book.(MrrgVO).
	 * @return total count relationship in family book.
	 * @exception Exception
	 */
	int searchMberCn(MrrgVO vo) throws Exception;	
}
