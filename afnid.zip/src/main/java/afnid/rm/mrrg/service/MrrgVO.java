package afnid.rm.mrrg.service;

import afnid.cm.ComDefaultVO;

public class MrrgVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	private String rsdtSeqNo;
	private String rsdtNo;
	private String mrrgSeqNo;
	private String dvrcSeqNo;
	private String mrrgDd;
	private String hsbdGivNm;
	private String hsbdSurnm;
	private String hsbdRsdtSeqNo;
	private String hsbdFrngrYn;
	private String hsbdFrngrRgstNo;
	private String hsbdNltyCd;
	private String hsbdCurtAdChngYn;
	private String wifeRsdtSeqNo;
	private String wifeGivNm;
	private String wifeSurnm;
	private String wifeEnGivNm;
	private String wifeEnSurnm;
	private String wifeFrngrYn;
	private String wifeFrngrRgstNo;
	private String wifeNltyCd;
	private String wifeNmChngYn;
	private String afWifeSurnm;
	private String afWifeEnSurnm;
	private String wifePmntAdChngYn;
	private String afWifePmntAdCd;
	private String afWifePmntAdDtlCt;
	private String wifeCurtAdChngYn;
	private String afCurtAdCd;
	private String afCurtAdDtlCt;
	private String wifeFmlyBokMvYn;
	private String wifeFmlyBokNo;
	private String afWifeFmlyBokNo;
	private String fstWtnNm;
	private String fstWtnRsdtNo;
	private String secdWtnNm;
	private String secdWtnRsdtNo;
	private String mrrgAdCd;
	private String mrrgAdDtlCt;
	private String certNo;
	private String pbctOfic;
	private String rmk;
	private String crdReisuceDueDd;
	private String rgstOrgnzCd;
	private String tamLedrCfmYn;
	private String cfmTamLedrId;
	private String rsdtCfmYn;
	private String cntTelNo;
	private String cntTelNo2;
	private String dltYn;
	private String fstRgstUserId;
	private String fstRgstDt;
	private String lstUdtUserId;
	private String lstUdtDt;
	private String newSeqNo;
	private String ntMrrgDivrDm;
	private String crdReisuceDmBfExpr;
	private String mlMrrgAgeDd;
	private String mlMrrgAge;
	private String femlMrrgAgeDd;
	private String femlMrrgAge;
	private String alwWifeNo;
	private String userId;
	private String calTye;
	private String gdrCd;
	private String hsbdRsdtNo;
	private String wifeRsdtNo;
	private String hsbdFthrNm;
	private String wifeFthrNm;
	private String afWifePmntAdCdNm;
	private String afCurtAdCdNm;
	private String mrrgAdCdNm;
	private String rgstOrgnzCdNm;
	private String appDd;
	private String fmlyHadNm;
	private String isExp;
	private String canNameChangeYn;
	private String nameChangeMsg;
	private String crdDlvrDd;
	private String hsbdEnNm;
	private String afWifeFmlyBokNoDp;
	private String mrrgDdJ;
	private String mrrgDdG;
	private String hsbdNm;
	private String wifeNm;
	private String hsbdRsdtNoDp;
	private String wifeRsdtNoDp;
	private String seqNo;
	private String flag;
	private String aprvListTm;
	private String crdIsucePlceCd;
	private String wifeSgnt;
	private String hsbdSgnt;
	private String surnm;
	private String givNm;
	private String fmlyBokSeqNo;
	private String fmlyBokNo;
	private String fmlyMberNo;
	private String curtAdCd;
	private String curtAdDtlCt;
	private String crdIsuceYn;
	private String emlAd;
	private String afCurtAdDiv;
	private String afCurtAdNatCd;
	private String afWtrRsdcCd;
	private String afSmrRsdcCd;
	private String afWtrRsdcCdNm;
	private String afSmrRsdcCdNm;
	private String afCurtAdDtlCtD;
	private String afCurtAdDtlCtF;
	private String kochiAdCd;
	private String pmntAdCd;
	private String pmntAdDtlCt;
	private String curtAdDiv;
	private String curtAdNatCd;
	private String smrRsdcCd;
	private String wtrRsdcCd;
	private String wifePmntAdCd;
	private String canHsbdAdChangYn;
	private String hsbdAdChangeMsg;
	private String isHsbdExp;
	private String hsbdEnSurnm;
	private String hsbdFmlyBokNo;
	private String hsbdPmntAdCd;
	private String hsbdPmntAdCdNm;
	private String hsbdPmntAdDtlCt;
	private String hsbdCurtAdDiv;
	private String hsbdCurtAdCd;
	private String hsbdCurtAdCdNm;
	private String hsbdCurtAdNatCd;
	private String hsbdCurtAdNatCdNm;
	private String hsbdCurtAdDtlCt;
	private String hsbdSmrRsdcCd;
	private String hsbdSmrRsdcCdNm;
	private String hsbdWtrRsdcCd;
	private String hsbdWtrRsdcCdNm;
	private String fstWtnOldCrdNo1;
	private String fstWtnOldCrdNo2;
	private String fstWtnOldCrdNo3;
	private String fstWtnOldCrdNo4;
	private String secdWtnOldCrdNo1;
	private String secdWtnOldCrdNo2;
	private String secdWtnOldCrdNo3;
	private String secdWtnOldCrdNo4;
	private String fstWtnOldCrdIsuceDd;
	private String fstWtnOldCrdIsucePlceCd;
	private String fstWtnOldCrdIsucePlceCdNm;
	private String secdWtnOldCrdIsuceDd;
	private String secdWtnOldCrdIsucePlceCd;
	private String secdWtnOldCrdIsucePlceCdNm;
	private String mrrgCd;

	private String rsdtNoDp;
	private String fmlyBokNoDp;
	private String enNm;
	private String natLangCdNm;
	private String frgnLangCdNm;
	private String mthrNm;
	private String smrRsdcCdNm;
	private String gfthrNm;
	private String wtrRsdcCdNm;
	private String gdrCdNm;	
	private String mrrgCdNm;
	private String bthDd;
	private String hBthDd;
	private String gBthDd;
	private String ocp;
	private String bthPlceCdNm;
	private String bthNatDiv;
	private String bthNatCdNm;
	private String frgnBthCtyNm;
	private String mltSrvcCdNm;
	private String encyCdNm;
	private String dsbtCdNm;
	private String fmlyLangCdNm;
	private String poliCntrNm;
	private String pmntAdCdNm;
	private String eduCdNm;
	private String eduYn;
	private String eduLvDocYn;
	private String curtAdNatCdNm;	
	private String curtAdCdNm;
	private String bldTyeCdNm;
	private String bldTyeDocYn;
	private String rlgnCdNm;
	private String secdNltyCdNm;
	private String rlgnSectCdNm;
	private String rvctgRsn;
	private String rvctDd;
	private String rsnCdNm;
	private String rsdtRgstDd;
	private String rsdtRgstIdNm;
	private String cfmTamLedrIdNm;
    private String secdNltyYn;
	private String eduCd;
	private String oldCrdNo1;
	private String oldCrdNo2;
	private String oldCrdNo3;
	private String oldCrdNo4;
	private String oldCrdIsuceDd;
	private String oldCrdIsucePlceCd;
	private String crdIsucePlceCdNm;
	private String crdIsuDueDd;
	private String fmlyBokNum;
	private String bthPlceCd;
	private String bthNatCd;
	private String mltSrvcCd;
	private String encyCd;
	private String dsbtDtlCt;
	private String fmlyLangCd;
	private String poliCntrSeqNoNm;
	private String rlgnCd;
	private String secdNltyCd;
	private String rlgnSectCd;
	private String orgnzCd;
	private String fmlyBokNoNum;
	private String newFmlyBokYn;
	private String fthrNm;
	private String bldTyeCd;
	private String crdIsuceDd;
	private String crdExpiryDd;
	private String prntDd;
	private String validDdEx;
	
	private String wifeNewFmlyBokYn;
	private String hsbdNewFmlyBokYn;
	private String hsbdPmntAdChngYn;
	private String wifeRlChngYn;	
	private String afHsbdPmntAdCd;
	private String afHsbdPmntAdDtlCt;
	private String afHsbdCurtAdDiv;
	private String afHsbdCurtAdCd;
	private String afHsbdCurtAdDtlCt;
	private String afHsbdCurtAdNatCd;
	private String afHsbdWtrRsdcCd;
	private String afHsbdSmrRsdcCd;
	private String afWifeRlCd;
	private String afWifeOthrRl;
	private String hsbdRlCd;
	private String wifeRlCd;
	private String wifeOthrRl;
	private String hsbdOthrRl;
	private String afHsbdFmlyBokNo;
	private String afHsbdFmlyBokNoDp;
	private String wifeFmlyHadSeqNo;
	private String hsbdFmlyHadSeqNo;
	private String hsbdFmlyBokNoDp;
	private String hsbdRlCdNm;
	private String hsbdFmlyHadNm;
	private String afHsbdFmlyHadNm;
	private String wifeFmlyBokNoDp;
	private String wifeRlCdNm;
	private String wifeFmlyHadNm;
	private String afWifeFmlyHadNm;
	private String afHsbdPmntAdCdNm;
	private String afHsbdCurtAdCdNm;
	private String afHsbdSmrRsdcCdNm;
	private String afHsbdWtrRsdcCdNm;
	private String afHsbdCurtAdNatCdNm;
	private String wifePmntAdDtlCt;
	private String wifeCurtAdDiv;
	private String wifeCurtAdCd;
	private String wifeCurtAdNatCd;
	private String wifeCurtAdDtlCt;
	private String wifeSmrRsdcCd;
	private String wifeWtrRsdcCd;
	private String afHsbdCurtAdDtlCtD;
	private String afHsbdCurtAdDtlCtF;
	private String afHsbdFmlyBokSeqNo;
	private String afHsbdFmlyMberNo;
	private String afWifeRlCdNm;
	private String fmlyHadGdrCd;
	private String op;
	
	private String rlCd;
	private String rlCdNm;	
	private String agGap; 
	private String mberCn; 
	private String mberCnTyeCd;
	private String mberRstrtGdrCd;
	private String fthrAgGap;  
	private String fthrRlCd;
	private String fthrMftrYn; 
	private String gfthrAgGap; 
	private String gfthrRlCd;
	private String gfthrMftrYn; 
	private String mthrAgGap; 
	private String mthrRlCd; 
	private String mthrMftrYn;  
	private String hsbdMftrYn;

	
	public String getAfHsbdFmlyHadNm() {
		return afHsbdFmlyHadNm;
	}
	public void setAfHsbdFmlyHadNm(String afHsbdFmlyHadNm) {
		this.afHsbdFmlyHadNm = afHsbdFmlyHadNm;
	}
	public String getAfHsbdFmlyBokNoDp() {
		return afHsbdFmlyBokNoDp;
	}
	public void setAfHsbdFmlyBokNoDp(String afHsbdFmlyBokNoDp) {
		this.afHsbdFmlyBokNoDp = afHsbdFmlyBokNoDp;
	}
	public String getAfHsbdFmlyBokSeqNo() {
		return afHsbdFmlyBokSeqNo;
	}
	public void setAfHsbdFmlyBokSeqNo(String afHsbdFmlyBokSeqNo) {
		this.afHsbdFmlyBokSeqNo = afHsbdFmlyBokSeqNo;
	}
	public String getAfHsbdFmlyMberNo() {
		return afHsbdFmlyMberNo;
	}
	public void setAfHsbdFmlyMberNo(String afHsbdFmlyMberNo) {
		this.afHsbdFmlyMberNo = afHsbdFmlyMberNo;
	}
	public String getAfHsbdCurtAdDtlCtD() {
		return afHsbdCurtAdDtlCtD;
	}
	public void setAfHsbdCurtAdDtlCtD(String afHsbdCurtAdDtlCtD) {
		this.afHsbdCurtAdDtlCtD = afHsbdCurtAdDtlCtD;
	}
	public String getAfHsbdCurtAdDtlCtF() {
		return afHsbdCurtAdDtlCtF;
	}
	public void setAfHsbdCurtAdDtlCtF(String afHsbdCurtAdDtlCtF) {
		this.afHsbdCurtAdDtlCtF = afHsbdCurtAdDtlCtF;
	}
	public String getWifePmntAdDtlCt() {
		return wifePmntAdDtlCt;
	}
	public void setWifePmntAdDtlCt(String wifePmntAdDtlCt) {
		this.wifePmntAdDtlCt = wifePmntAdDtlCt;
	}
	public String getWifeCurtAdDiv() {
		return wifeCurtAdDiv;
	}
	public void setWifeCurtAdDiv(String wifeCurtAdDiv) {
		this.wifeCurtAdDiv = wifeCurtAdDiv;
	}
	public String getWifeCurtAdCd() {
		return wifeCurtAdCd;
	}
	public void setWifeCurtAdCd(String wifeCurtAdCd) {
		this.wifeCurtAdCd = wifeCurtAdCd;
	}
	public String getWifeCurtAdNatCd() {
		return wifeCurtAdNatCd;
	}
	public void setWifeCurtAdNatCd(String wifeCurtAdNatCd) {
		this.wifeCurtAdNatCd = wifeCurtAdNatCd;
	}
	public String getWifeCurtAdDtlCt() {
		return wifeCurtAdDtlCt;
	}
	public void setWifeCurtAdDtlCt(String wifeCurtAdDtlCt) {
		this.wifeCurtAdDtlCt = wifeCurtAdDtlCt;
	}
	public String getWifeSmrRsdcCd() {
		return wifeSmrRsdcCd;
	}
	public void setWifeSmrRsdcCd(String wifeSmrRsdcCd) {
		this.wifeSmrRsdcCd = wifeSmrRsdcCd;
	}
	public String getWifeWtrRsdcCd() {
		return wifeWtrRsdcCd;
	}
	public void setWifeWtrRsdcCd(String wifeWtrRsdcCd) {
		this.wifeWtrRsdcCd = wifeWtrRsdcCd;
	}
	public String getAfHsbdCurtAdCdNm() {
		return afHsbdCurtAdCdNm;
	}
	public void setAfHsbdCurtAdCdNm(String afHsbdCurtAdCdNm) {
		this.afHsbdCurtAdCdNm = afHsbdCurtAdCdNm;
	}
	public String getAfHsbdSmrRsdcCdNm() {
		return afHsbdSmrRsdcCdNm;
	}
	public void setAfHsbdSmrRsdcCdNm(String afHsbdSmrRsdcCdNm) {
		this.afHsbdSmrRsdcCdNm = afHsbdSmrRsdcCdNm;
	}
	public String getAfHsbdWtrRsdcCdNm() {
		return afHsbdWtrRsdcCdNm;
	}
	public void setAfHsbdWtrRsdcCdNm(String afHsbdWtrRsdcCdNm) {
		this.afHsbdWtrRsdcCdNm = afHsbdWtrRsdcCdNm;
	}
	public String getAfHsbdCurtAdNatCdNm() {
		return afHsbdCurtAdNatCdNm;
	}
	public void setAfHsbdCurtAdNatCdNm(String afHsbdCurtAdNatCdNm) {
		this.afHsbdCurtAdNatCdNm = afHsbdCurtAdNatCdNm;
	}
	public String getAfHsbdPmntAdCdNm() {
		return afHsbdPmntAdCdNm;
	}
	public void setAfHsbdPmntAdCdNm(String afHsbdPmntAdCdNm) {
		this.afHsbdPmntAdCdNm = afHsbdPmntAdCdNm;
	}
	public String getAfWifeFmlyHadNm() {
		return afWifeFmlyHadNm;
	}
	public void setAfWifeFmlyHadNm(String afWifeFmlyHadNm) {
		this.afWifeFmlyHadNm = afWifeFmlyHadNm;
	}
	public String getHsbdFmlyHadNm() {
		return hsbdFmlyHadNm;
	}
	public void setHsbdFmlyHadNm(String hsbdFmlyHadNm) {
		this.hsbdFmlyHadNm = hsbdFmlyHadNm;
	}
	public String getWifeFmlyBokNoDp() {
		return wifeFmlyBokNoDp;
	}
	public void setWifeFmlyBokNoDp(String wifeFmlyBokNoDp) {
		this.wifeFmlyBokNoDp = wifeFmlyBokNoDp;
	}
	public String getWifeRlCdNm() {
		return wifeRlCdNm;
	}
	public void setWifeRlCdNm(String wifeRlCdNm) {
		this.wifeRlCdNm = wifeRlCdNm;
	}
	public String getWifeFmlyHadNm() {
		return wifeFmlyHadNm;
	}
	public void setWifeFmlyHadNm(String wifeFmlyHadNm) {
		this.wifeFmlyHadNm = wifeFmlyHadNm;
	}
	public String getHsbdRlCdNm() {
		return hsbdRlCdNm;
	}
	public void setHsbdRlCdNm(String hsbdRlCdNm) {
		this.hsbdRlCdNm = hsbdRlCdNm;
	}
	public String getHsbdFmlyBokNoDp() {
		return hsbdFmlyBokNoDp;
	}
	public void setHsbdFmlyBokNoDp(String hsbdFmlyBokNoDp) {
		this.hsbdFmlyBokNoDp = hsbdFmlyBokNoDp;
	}
	public String getHsbdRlCd() {
		return hsbdRlCd;
	}
	public void setHsbdRlCd(String hsbdRlCd) {
		this.hsbdRlCd = hsbdRlCd;
	}
	public String getWifeRlCd() {
		return wifeRlCd;
	}
	public void setWifeRlCd(String wifeRlCd) {
		this.wifeRlCd = wifeRlCd;
	}
	public String getWifeOthrRl() {
		return wifeOthrRl;
	}
	public void setWifeOthrRl(String wifeOthrRl) {
		this.wifeOthrRl = wifeOthrRl;
	}
	public String getHsbdOthrRl() {
		return hsbdOthrRl;
	}
	public void setHsbdOthrRl(String hsbdOthrRl) {
		this.hsbdOthrRl = hsbdOthrRl;
	}
	public String getAfHsbdFmlyBokNo() {
		return afHsbdFmlyBokNo;
	}
	public void setAfHsbdFmlyBokNo(String afHsbdFmlyBokNo) {
		this.afHsbdFmlyBokNo = afHsbdFmlyBokNo;
	}
	public String getWifeFmlyHadSeqNo() {
		return wifeFmlyHadSeqNo;
	}
	public void setWifeFmlyHadSeqNo(String wifeFmlyHadSeqNo) {
		this.wifeFmlyHadSeqNo = wifeFmlyHadSeqNo;
	}
	public String getHsbdFmlyHadSeqNo() {
		return hsbdFmlyHadSeqNo;
	}
	public void setHsbdFmlyHadSeqNo(String hsbdFmlyHadSeqNo) {
		this.hsbdFmlyHadSeqNo = hsbdFmlyHadSeqNo;
	}
	public String getAfWifeOthrRl() {
		return afWifeOthrRl;
	}
	public void setAfWifeOthrRl(String afWifeOthrRl) {
		this.afWifeOthrRl = afWifeOthrRl;
	}
	public String getAfHsbdWtrRsdcCd() {
		return afHsbdWtrRsdcCd;
	}
	public void setAfHsbdWtrRsdcCd(String afHsbdWtrRsdcCd) {
		this.afHsbdWtrRsdcCd = afHsbdWtrRsdcCd;
	}
	public String getWifeNewFmlyBokYn() {
		return wifeNewFmlyBokYn;
	}
	public void setWifeNewFmlyBokYn(String wifeNewFmlyBokYn) {
		this.wifeNewFmlyBokYn = wifeNewFmlyBokYn;
	}
	public String getHsbdNewFmlyBokYn() {
		return hsbdNewFmlyBokYn;
	}
	public void setHsbdNewFmlyBokYn(String hsbdNewFmlyBokYn) {
		this.hsbdNewFmlyBokYn = hsbdNewFmlyBokYn;
	}
	public String getHsbdPmntAdChngYn() {
		return hsbdPmntAdChngYn;
	}
	public void setHsbdPmntAdChngYn(String hsbdPmntAdChngYn) {
		this.hsbdPmntAdChngYn = hsbdPmntAdChngYn;
	}
	public String getWifeRlChngYn() {
		return wifeRlChngYn;
	}
	public void setWifeRlChngYn(String wifeRlChngYn) {
		this.wifeRlChngYn = wifeRlChngYn;
	}
	public String getAfHsbdPmntAdCd() {
		return afHsbdPmntAdCd;
	}
	public void setAfHsbdPmntAdCd(String afHsbdPmntAdCd) {
		this.afHsbdPmntAdCd = afHsbdPmntAdCd;
	}
	public String getAfHsbdPmntAdDtlCt() {
		return afHsbdPmntAdDtlCt;
	}
	public void setAfHsbdPmntAdDtlCt(String afHsbdPmntAdDtlCt) {
		this.afHsbdPmntAdDtlCt = afHsbdPmntAdDtlCt;
	}
	public String getAfHsbdCurtAdDiv() {
		return afHsbdCurtAdDiv;
	}
	public void setAfHsbdCurtAdDiv(String afHsbdCurtAdDiv) {
		this.afHsbdCurtAdDiv = afHsbdCurtAdDiv;
	}
	public String getAfHsbdCurtAdCd() {
		return afHsbdCurtAdCd;
	}
	public void setAfHsbdCurtAdCd(String afHsbdCurtAdCd) {
		this.afHsbdCurtAdCd = afHsbdCurtAdCd;
	}
	public String getAfHsbdCurtAdDtlCt() {
		return afHsbdCurtAdDtlCt;
	}
	public void setAfHsbdCurtAdDtlCt(String afHsbdCurtAdDtlCt) {
		this.afHsbdCurtAdDtlCt = afHsbdCurtAdDtlCt;
	}
	public String getAfHsbdCurtAdNatCd() {
		return afHsbdCurtAdNatCd;
	}
	public void setAfHsbdCurtAdNatCd(String afHsbdCurtAdNatCd) {
		this.afHsbdCurtAdNatCd = afHsbdCurtAdNatCd;
	}
	public String getAfHsbdSmrRsdcCd() {
		return afHsbdSmrRsdcCd;
	}
	public void setAfHsbdSmrRsdcCd(String afHsbdSmrRsdcCd) {
		this.afHsbdSmrRsdcCd = afHsbdSmrRsdcCd;
	}
	public String getAfWifeRlCd() {
		return afWifeRlCd;
	}
	public void setAfWifeRlCd(String afWifeRlCd) {
		this.afWifeRlCd = afWifeRlCd;
	}
	public String getMrrgCd() {
		return mrrgCd;
	}
	public void setMrrgCd(String mrrgCd) {
		this.mrrgCd = mrrgCd;
	}
	public String getFstWtnOldCrdIsuceDd() {
		return fstWtnOldCrdIsuceDd;
	}
	public void setFstWtnOldCrdIsuceDd(String fstWtnOldCrdIsuceDd) {
		this.fstWtnOldCrdIsuceDd = fstWtnOldCrdIsuceDd;
	}
	public String getFstWtnOldCrdIsucePlceCd() {
		return fstWtnOldCrdIsucePlceCd;
	}
	public void setFstWtnOldCrdIsucePlceCd(String fstWtnOldCrdIsucePlceCd) {
		this.fstWtnOldCrdIsucePlceCd = fstWtnOldCrdIsucePlceCd;
	}
	public String getFstWtnOldCrdIsucePlceCdNm() {
		return fstWtnOldCrdIsucePlceCdNm;
	}
	public void setFstWtnOldCrdIsucePlceCdNm(String fstWtnOldCrdIsucePlceCdNm) {
		this.fstWtnOldCrdIsucePlceCdNm = fstWtnOldCrdIsucePlceCdNm;
	}
	public String getSecdWtnOldCrdIsuceDd() {
		return secdWtnOldCrdIsuceDd;
	}
	public void setSecdWtnOldCrdIsuceDd(String secdWtnOldCrdIsuceDd) {
		this.secdWtnOldCrdIsuceDd = secdWtnOldCrdIsuceDd;
	}
	public String getSecdWtnOldCrdIsucePlceCd() {
		return secdWtnOldCrdIsucePlceCd;
	}
	public void setSecdWtnOldCrdIsucePlceCd(String secdWtnOldCrdIsucePlceCd) {
		this.secdWtnOldCrdIsucePlceCd = secdWtnOldCrdIsucePlceCd;
	}
	public String getSecdWtnOldCrdIsucePlceCdNm() {
		return secdWtnOldCrdIsucePlceCdNm;
	}
	public void setSecdWtnOldCrdIsucePlceCdNm(String secdWtnOldCrdIsucePlceCdNm) {
		this.secdWtnOldCrdIsucePlceCdNm = secdWtnOldCrdIsucePlceCdNm;
	}
	public String getFstWtnOldCrdNo1() {
		return fstWtnOldCrdNo1;
	}
	public void setFstWtnOldCrdNo1(String fstWtnOldCrdNo1) {
		this.fstWtnOldCrdNo1 = fstWtnOldCrdNo1;
	}
	public String getFstWtnOldCrdNo2() {
		return fstWtnOldCrdNo2;
	}
	public void setFstWtnOldCrdNo2(String fstWtnOldCrdNo2) {
		this.fstWtnOldCrdNo2 = fstWtnOldCrdNo2;
	}
	public String getFstWtnOldCrdNo3() {
		return fstWtnOldCrdNo3;
	}
	public void setFstWtnOldCrdNo3(String fstWtnOldCrdNo3) {
		this.fstWtnOldCrdNo3 = fstWtnOldCrdNo3;
	}
	public String getFstWtnOldCrdNo4() {
		return fstWtnOldCrdNo4;
	}
	public void setFstWtnOldCrdNo4(String fstWtnOldCrdNo4) {
		this.fstWtnOldCrdNo4 = fstWtnOldCrdNo4;
	}
	public String getSecdWtnOldCrdNo1() {
		return secdWtnOldCrdNo1;
	}
	public void setSecdWtnOldCrdNo1(String secdWtnOldCrdNo1) {
		this.secdWtnOldCrdNo1 = secdWtnOldCrdNo1;
	}
	public String getSecdWtnOldCrdNo2() {
		return secdWtnOldCrdNo2;
	}
	public void setSecdWtnOldCrdNo2(String secdWtnOldCrdNo2) {
		this.secdWtnOldCrdNo2 = secdWtnOldCrdNo2;
	}
	public String getSecdWtnOldCrdNo3() {
		return secdWtnOldCrdNo3;
	}
	public void setSecdWtnOldCrdNo3(String secdWtnOldCrdNo3) {
		this.secdWtnOldCrdNo3 = secdWtnOldCrdNo3;
	}
	public String getSecdWtnOldCrdNo4() {
		return secdWtnOldCrdNo4;
	}
	public void setSecdWtnOldCrdNo4(String secdWtnOldCrdNo4) {
		this.secdWtnOldCrdNo4 = secdWtnOldCrdNo4;
	}
	public String getHsbdEnSurnm() {
		return hsbdEnSurnm;
	}
	public void setHsbdEnSurnm(String hsbdEnSurnm) {
		this.hsbdEnSurnm = hsbdEnSurnm;
	}
	public String getHsbdFmlyBokNo() {
		return hsbdFmlyBokNo;
	}
	public void setHsbdFmlyBokNo(String hsbdFmlyBokNo) {
		this.hsbdFmlyBokNo = hsbdFmlyBokNo;
	}
	public String getHsbdPmntAdCd() {
		return hsbdPmntAdCd;
	}
	public void setHsbdPmntAdCd(String hsbdPmntAdCd) {
		this.hsbdPmntAdCd = hsbdPmntAdCd;
	}
	public String getHsbdPmntAdCdNm() {
		return hsbdPmntAdCdNm;
	}
	public void setHsbdPmntAdCdNm(String hsbdPmntAdCdNm) {
		this.hsbdPmntAdCdNm = hsbdPmntAdCdNm;
	}
	public String getHsbdPmntAdDtlCt() {
		return hsbdPmntAdDtlCt;
	}
	public void setHsbdPmntAdDtlCt(String hsbdPmntAdDtlCt) {
		this.hsbdPmntAdDtlCt = hsbdPmntAdDtlCt;
	}
	public String getHsbdCurtAdDiv() {
		return hsbdCurtAdDiv;
	}
	public void setHsbdCurtAdDiv(String hsbdCurtAdDiv) {
		this.hsbdCurtAdDiv = hsbdCurtAdDiv;
	}
	public String getHsbdCurtAdCd() {
		return hsbdCurtAdCd;
	}
	public void setHsbdCurtAdCd(String hsbdCurtAdCd) {
		this.hsbdCurtAdCd = hsbdCurtAdCd;
	}
	public String getHsbdCurtAdCdNm() {
		return hsbdCurtAdCdNm;
	}
	public void setHsbdCurtAdCdNm(String hsbdCurtAdCdNm) {
		this.hsbdCurtAdCdNm = hsbdCurtAdCdNm;
	}
	public String getHsbdCurtAdNatCd() {
		return hsbdCurtAdNatCd;
	}
	public void setHsbdCurtAdNatCd(String hsbdCurtAdNatCd) {
		this.hsbdCurtAdNatCd = hsbdCurtAdNatCd;
	}
	public String getHsbdCurtAdNatCdNm() {
		return hsbdCurtAdNatCdNm;
	}
	public void setHsbdCurtAdNatCdNm(String hsbdCurtAdNatCdNm) {
		this.hsbdCurtAdNatCdNm = hsbdCurtAdNatCdNm;
	}
	public String getHsbdCurtAdDtlCt() {
		return hsbdCurtAdDtlCt;
	}
	public void setHsbdCurtAdDtlCt(String hsbdCurtAdDtlCt) {
		this.hsbdCurtAdDtlCt = hsbdCurtAdDtlCt;
	}
	public String getHsbdSmrRsdcCd() {
		return hsbdSmrRsdcCd;
	}
	public void setHsbdSmrRsdcCd(String hsbdSmrRsdcCd) {
		this.hsbdSmrRsdcCd = hsbdSmrRsdcCd;
	}
	public String getHsbdSmrRsdcCdNm() {
		return hsbdSmrRsdcCdNm;
	}
	public void setHsbdSmrRsdcCdNm(String hsbdSmrRsdcCdNm) {
		this.hsbdSmrRsdcCdNm = hsbdSmrRsdcCdNm;
	}
	public String getHsbdWtrRsdcCd() {
		return hsbdWtrRsdcCd;
	}
	public void setHsbdWtrRsdcCd(String hsbdWtrRsdcCd) {
		this.hsbdWtrRsdcCd = hsbdWtrRsdcCd;
	}
	public String getHsbdWtrRsdcCdNm() {
		return hsbdWtrRsdcCdNm;
	}
	public void setHsbdWtrRsdcCdNm(String hsbdWtrRsdcCdNm) {
		this.hsbdWtrRsdcCdNm = hsbdWtrRsdcCdNm;
	}
	public String getIsHsbdExp() {
		return isHsbdExp;
	}
	public void setIsHsbdExp(String isHsbdExp) {
		this.isHsbdExp = isHsbdExp;
	}
	public String getCanHsbdAdChangYn() {
		return canHsbdAdChangYn;
	}
	public void setCanHsbdAdChangYn(String canHsbdAdChangYn) {
		this.canHsbdAdChangYn = canHsbdAdChangYn;
	}
	public String getHsbdAdChangeMsg() {
		return hsbdAdChangeMsg;
	}
	public void setHsbdAdChangeMsg(String hsbdAdChangeMsg) {
		this.hsbdAdChangeMsg = hsbdAdChangeMsg;
	}
	public String getWifePmntAdCd() {
		return wifePmntAdCd;
	}
	public void setWifePmntAdCd(String wifePmntAdCd) {
		this.wifePmntAdCd = wifePmntAdCd;
	}
	public String getWifeSgnt() {
		return wifeSgnt;
	}
	public void setWifeSgnt(String wifeSgnt) {
		this.wifeSgnt = wifeSgnt;
	}
	public String getHsbdSgnt() {
		return hsbdSgnt;
	}
	public void setHsbdSgnt(String hsbdSgnt) {
		this.hsbdSgnt = hsbdSgnt;
	}
	public String getCntTelNo2() {
		return cntTelNo2;
	}
	public void setCntTelNo2(String cntTelNo2) {
		this.cntTelNo2 = cntTelNo2;
	}
	public String getPmntAdCd() {
		return pmntAdCd;
	}
	public void setPmntAdCd(String pmntAdCd) {
		this.pmntAdCd = pmntAdCd;
	}
	public String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}
	public void setPmntAdDtlCt(String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}
	public String getCurtAdDiv() {
		return curtAdDiv;
	}
	public void setCurtAdDiv(String curtAdDiv) {
		this.curtAdDiv = curtAdDiv;
	}
	public String getCurtAdNatCd() {
		return curtAdNatCd;
	}
	public void setCurtAdNatCd(String curtAdNatCd) {
		this.curtAdNatCd = curtAdNatCd;
	}
	public String getSmrRsdcCd() {
		return smrRsdcCd;
	}
	public void setSmrRsdcCd(String smrRsdcCd) {
		this.smrRsdcCd = smrRsdcCd;
	}
	public String getWtrRsdcCd() {
		return wtrRsdcCd;
	}
	public void setWtrRsdcCd(String wtrRsdcCd) {
		this.wtrRsdcCd = wtrRsdcCd;
	}
	public String getKochiAdCd() {
		return kochiAdCd;
	}
	public void setKochiAdCd(String kochiAdCd) {
		this.kochiAdCd = kochiAdCd;
	}
	public String getAfCurtAdDtlCtD() {
		return afCurtAdDtlCtD;
	}
	public void setAfCurtAdDtlCtD(String afCurtAdDtlCtD) {
		this.afCurtAdDtlCtD = afCurtAdDtlCtD;
	}
	public String getAfCurtAdDtlCtF() {
		return afCurtAdDtlCtF;
	}
	public void setAfCurtAdDtlCtF(String afCurtAdDtlCtF) {
		this.afCurtAdDtlCtF = afCurtAdDtlCtF;
	}
	public String getAfWtrRsdcCdNm() {
		return afWtrRsdcCdNm;
	}
	public void setAfWtrRsdcCdNm(String afWtrRsdcCdNm) {
		this.afWtrRsdcCdNm = afWtrRsdcCdNm;
	}
	public String getAfSmrRsdcCdNm() {
		return afSmrRsdcCdNm;
	}
	public void setAfSmrRsdcCdNm(String afSmrRsdcCdNm) {
		this.afSmrRsdcCdNm = afSmrRsdcCdNm;
	}
	public String getAfCurtAdDiv() {
		return afCurtAdDiv;
	}
	public void setAfCurtAdDiv(String afCurtAdDiv) {
		this.afCurtAdDiv = afCurtAdDiv;
	}
	public String getAfCurtAdNatCd() {
		return afCurtAdNatCd;
	}
	public void setAfCurtAdNatCd(String afCurtAdNatCd) {
		this.afCurtAdNatCd = afCurtAdNatCd;
	}
	public String getAfWtrRsdcCd() {
		return afWtrRsdcCd;
	}
	public void setAfWtrRsdcCd(String afWtrRsdcCd) {
		this.afWtrRsdcCd = afWtrRsdcCd;
	}
	public String getAfSmrRsdcCd() {
		return afSmrRsdcCd;
	}
	public void setAfSmrRsdcCd(String afSmrRsdcCd) {
		this.afSmrRsdcCd = afSmrRsdcCd;
	}
	public String getEmlAd() {
		return emlAd;
	}
	public void setEmlAd(String emlAd) {
		this.emlAd = emlAd;
	}
	public String getDvrcSeqNo() {
		return dvrcSeqNo;
	}
	public void setDvrcSeqNo(String dvrcSeqNo) {
		this.dvrcSeqNo = dvrcSeqNo;
	}
	public String getCrdIsuceYn() {
		return crdIsuceYn;
	}
	public void setCrdIsuceYn(String crdIsuceYn) {
		this.crdIsuceYn = crdIsuceYn;
	}
	public String getFmlyBokSeqNo() {
		return fmlyBokSeqNo;
	}
	public void setFmlyBokSeqNo(String fmlyBokSeqNo) {
		this.fmlyBokSeqNo = fmlyBokSeqNo;
	}
	public String getFmlyBokNo() {
		return fmlyBokNo;
	}
	public void setFmlyBokNo(String fmlyBokNo) {
		this.fmlyBokNo = fmlyBokNo;
	}
	public String getFmlyMberNo() {
		return fmlyMberNo;
	}
	public void setFmlyMberNo(String fmlyMberNo) {
		this.fmlyMberNo = fmlyMberNo;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}
	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}
	public String getSurnm() {
		return surnm;
	}
	public void setSurnm(String surnm) {
		this.surnm = surnm;
	}
	public String getGivNm() {
		return givNm;
	}
	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}
	public String getCrdIsucePlceCd() {
		return crdIsucePlceCd;
	}
	public void setCrdIsucePlceCd(String crdIsucePlceCd) {
		this.crdIsucePlceCd = crdIsucePlceCd;
	}
	public String getAprvListTm() {
		return aprvListTm;
	}
	public void setAprvListTm(String aprvListTm) {
		this.aprvListTm = aprvListTm;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	public String getHsbdRsdtNoDp() {
		return hsbdRsdtNoDp;
	}
	public void setHsbdRsdtNoDp(String hsbdRsdtNoDp) {
		this.hsbdRsdtNoDp = hsbdRsdtNoDp;
	}
	public String getWifeRsdtNoDp() {
		return wifeRsdtNoDp;
	}
	public void setWifeRsdtNoDp(String wifeRsdtNoDp) {
		this.wifeRsdtNoDp = wifeRsdtNoDp;
	}
	public String getHsbdNm() {
		return hsbdNm;
	}
	public void setHsbdNm(String hsbdNm) {
		this.hsbdNm = hsbdNm;
	}

	public String getWifeNm() {
		return wifeNm;
	}
	public void setWifeNm(String wifeNm) {
		this.wifeNm = wifeNm;
	}
	public String getMrrgDdJ() {
		return mrrgDdJ;
	}
	public void setMrrgDdJ(String mrrgDdJ) {
		this.mrrgDdJ = mrrgDdJ;
	}
	public String getMrrgDdG() {
		return mrrgDdG;
	}
	public void setMrrgDdG(String mrrgDdG) {
		this.mrrgDdG = mrrgDdG;
	}
	public String getAfWifeFmlyBokNoDp() {
		return afWifeFmlyBokNoDp;
	}
	public void setAfWifeFmlyBokNoDp(String afWifeFmlyBokNoDp) {
		this.afWifeFmlyBokNoDp = afWifeFmlyBokNoDp;
	}
	public String getHsbdEnNm() {
		return hsbdEnNm;
	}
	public void setHsbdEnNm(String hsbdEnNm) {
		this.hsbdEnNm = hsbdEnNm;
	}
	public String getCrdDlvrDd() {
		return crdDlvrDd;
	}
	public void setCrdDlvrDd(String crdDlvrDd) {
		this.crdDlvrDd = crdDlvrDd;
	}
	public String getCanNameChangeYn() {
		return canNameChangeYn;
	}
	public void setCanNameChangeYn(String canNameChangeYn) {
		this.canNameChangeYn = canNameChangeYn;
	}
	public String getNameChangeMsg() {
		return nameChangeMsg;
	}
	public void setNameChangeMsg(String nameChangeMsg) {
		this.nameChangeMsg = nameChangeMsg;
	}
	public String getFmlyHadNm() {
		return fmlyHadNm;
	}
	public void setFmlyHadNm(String fmlyHadNm) {
		this.fmlyHadNm = fmlyHadNm;
	}
	public String getIsExp() {
		return isExp;
	}
	public void setIsExp(String isExp) {
		this.isExp = isExp;
	}
	public String getMlMrrgAgeDd() {
		return mlMrrgAgeDd;
	}
	public void setMlMrrgAgeDd(String mlMrrgAgeDd) {
		this.mlMrrgAgeDd = mlMrrgAgeDd;
	}
	public String getFemlMrrgAgeDd() {
		return femlMrrgAgeDd;
	}
	public void setFemlMrrgAgeDd(String femlMrrgAgeDd) {
		this.femlMrrgAgeDd = femlMrrgAgeDd;
	}
	public String getAppDd() {
		return appDd;
	}
	public void setAppDd(String appDd) {
		this.appDd = appDd;
	}
	public String getRgstOrgnzCdNm() {
		return rgstOrgnzCdNm;
	}
	public void setRgstOrgnzCdNm(String rgstOrgnzCdNm) {
		this.rgstOrgnzCdNm = rgstOrgnzCdNm;
	}
	public String getHsbdFthrNm() {
		return hsbdFthrNm;
	}
	public void setHsbdFthrNm(String hsbdFthrNm) {
		this.hsbdFthrNm = hsbdFthrNm;
	}
	public String getWifeFthrNm() {
		return wifeFthrNm;
	}
	public void setWifeFthrNm(String wifeFthrNm) {
		this.wifeFthrNm = wifeFthrNm;
	}
	public String getAfWifePmntAdCdNm() {
		return afWifePmntAdCdNm;
	}
	public void setAfWifePmntAdCdNm(String afWifePmntAdCdNm) {
		this.afWifePmntAdCdNm = afWifePmntAdCdNm;
	}
	public String getAfCurtAdCdNm() {
		return afCurtAdCdNm;
	}
	public void setAfCurtAdCdNm(String afCurtAdCdNm) {
		this.afCurtAdCdNm = afCurtAdCdNm;
	}
	public String getMrrgAdCdNm() {
		return mrrgAdCdNm;
	}
	public void setMrrgAdCdNm(String mrrgAdCdNm) {
		this.mrrgAdCdNm = mrrgAdCdNm;
	}
	public String getHsbdRsdtNo() {
		return hsbdRsdtNo;
	}
	public void setHsbdRsdtNo(String hsbdRsdtNo) {
		this.hsbdRsdtNo = hsbdRsdtNo;
	}
	public String getWifeRsdtNo() {
		return wifeRsdtNo;
	}
	public void setWifeRsdtNo(String wifeRsdtNo) {
		this.wifeRsdtNo = wifeRsdtNo;
	}
	public String getGdrCd() {
		return gdrCd;
	}
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	public String getAfWifeEnSurnm() {
		return afWifeEnSurnm;
	}
	public void setAfWifeEnSurnm(String afWifeEnSurnm) {
		this.afWifeEnSurnm = afWifeEnSurnm;
	}
	public String getCalTye() {
		return calTye;
	}
	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getNtMrrgDivrDm() {
		return ntMrrgDivrDm;
	}
	public void setNtMrrgDivrDm(String ntMrrgDivrDm) {
		this.ntMrrgDivrDm = ntMrrgDivrDm;
	}
	public String getCrdReisuceDmBfExpr() {
		return crdReisuceDmBfExpr;
	}
	public void setCrdReisuceDmBfExpr(String crdReisuceDmBfExpr) {
		this.crdReisuceDmBfExpr = crdReisuceDmBfExpr;
	}
	public String getMlMrrgAge() {
		return mlMrrgAge;
	}
	public void setMlMrrgAge(String mlMrrgAge) {
		this.mlMrrgAge = mlMrrgAge;
	}
	public String getFemlMrrgAge() {
		return femlMrrgAge;
	}
	public void setFemlMrrgAge(String femlMrrgAge) {
		this.femlMrrgAge = femlMrrgAge;
	}
	public String getAlwWifeNo() {
		return alwWifeNo;
	}
	public void setAlwWifeNo(String alwWifeNo) {
		this.alwWifeNo = alwWifeNo;
	}
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getMrrgSeqNo() {
		return mrrgSeqNo;
	}
	public void setMrrgSeqNo(String mrrgSeqNo) {
		this.mrrgSeqNo = mrrgSeqNo;
	}
	public String getMrrgDd() {
		return mrrgDd;
	}
	public void setMrrgDd(String mrrgDd) {
		this.mrrgDd = mrrgDd;
	}
	public String getHsbdGivNm() {
		return hsbdGivNm;
	}
	public void setHsbdGivNm(String hsbdGivNm) {
		this.hsbdGivNm = hsbdGivNm;
	}
	public String getHsbdSurnm() {
		return hsbdSurnm;
	}
	public void setHsbdSurnm(String hsbdSurnm) {
		this.hsbdSurnm = hsbdSurnm;
	}
	public String getHsbdRsdtSeqNo() {
		return hsbdRsdtSeqNo;
	}
	public void setHsbdRsdtSeqNo(String hsbdRsdtSeqNo) {
		this.hsbdRsdtSeqNo = hsbdRsdtSeqNo;
	}
	public String getHsbdFrngrYn() {
		return hsbdFrngrYn;
	}
	public void setHsbdFrngrYn(String hsbdFrngrYn) {
		this.hsbdFrngrYn = hsbdFrngrYn;
	}
	public String getHsbdFrngrRgstNo() {
		return hsbdFrngrRgstNo;
	}
	public void setHsbdFrngrRgstNo(String hsbdFrngrRgstNo) {
		this.hsbdFrngrRgstNo = hsbdFrngrRgstNo;
	}
	public String getHsbdNltyCd() {
		return hsbdNltyCd;
	}
	public void setHsbdNltyCd(String hsbdNltyCd) {
		this.hsbdNltyCd = hsbdNltyCd;
	}
	public String getHsbdCurtAdChngYn() {
		return hsbdCurtAdChngYn;
	}
	public void setHsbdCurtAdChngYn(String hsbdCurtAdChngYn) {
		this.hsbdCurtAdChngYn = hsbdCurtAdChngYn;
	}
	public String getWifeRsdtSeqNo() {
		return wifeRsdtSeqNo;
	}
	public void setWifeRsdtSeqNo(String wifeRsdtSeqNo) {
		this.wifeRsdtSeqNo = wifeRsdtSeqNo;
	}
	public String getWifeGivNm() {
		return wifeGivNm;
	}
	public void setWifeGivNm(String wifeGivNm) {
		this.wifeGivNm = wifeGivNm;
	}
	public String getWifeSurnm() {
		return wifeSurnm;
	}
	public void setWifeSurnm(String wifeSurnm) {
		this.wifeSurnm = wifeSurnm;
	}
	public String getWifeEnGivNm() {
		return wifeEnGivNm;
	}
	public void setWifeEnGivNm(String wifeEnGivNm) {
		this.wifeEnGivNm = wifeEnGivNm;
	}
	public String getWifeEnSurnm() {
		return wifeEnSurnm;
	}
	public void setWifeEnSurnm(String wifeEnSurnm) {
		this.wifeEnSurnm = wifeEnSurnm;
	}
	public String getWifeFrngrYn() {
		return wifeFrngrYn;
	}
	public void setWifeFrngrYn(String wifeFrngrYn) {
		this.wifeFrngrYn = wifeFrngrYn;
	}
	public String getWifeFrngrRgstNo() {
		return wifeFrngrRgstNo;
	}
	public void setWifeFrngrRgstNo(String wifeFrngrRgstNo) {
		this.wifeFrngrRgstNo = wifeFrngrRgstNo;
	}
	public String getWifeNltyCd() {
		return wifeNltyCd;
	}
	public void setWifeNltyCd(String wifeNltyCd) {
		this.wifeNltyCd = wifeNltyCd;
	}
	public String getWifeNmChngYn() {
		return wifeNmChngYn;
	}
	public void setWifeNmChngYn(String wifeNmChngYn) {
		this.wifeNmChngYn = wifeNmChngYn;
	}
	public String getAfWifeSurnm() {
		return afWifeSurnm;
	}
	public void setAfWifeSurnm(String afWifeSurnm) {
		this.afWifeSurnm = afWifeSurnm;
	}

	public String getWifePmntAdChngYn() {
		return wifePmntAdChngYn;
	}
	public void setWifePmntAdChngYn(String wifePmntAdChngYn) {
		this.wifePmntAdChngYn = wifePmntAdChngYn;
	}
	public String getAfWifePmntAdCd() {
		return afWifePmntAdCd;
	}
	public void setAfWifePmntAdCd(String afWifePmntAdCd) {
		this.afWifePmntAdCd = afWifePmntAdCd;
	}
	public String getAfWifePmntAdDtlCt() {
		return afWifePmntAdDtlCt;
	}
	public void setAfWifePmntAdDtlCt(String afWifePmntAdDtlCt) {
		this.afWifePmntAdDtlCt = afWifePmntAdDtlCt;
	}
	public String getWifeCurtAdChngYn() {
		return wifeCurtAdChngYn;
	}
	public void setWifeCurtAdChngYn(String wifeCurtAdChngYn) {
		this.wifeCurtAdChngYn = wifeCurtAdChngYn;
	}
	public String getAfCurtAdCd() {
		return afCurtAdCd;
	}
	public void setAfCurtAdCd(String afCurtAdCd) {
		this.afCurtAdCd = afCurtAdCd;
	}
	public String getAfCurtAdDtlCt() {
		return afCurtAdDtlCt;
	}
	public void setAfCurtAdDtlCt(String afCurtAdDtlCt) {
		this.afCurtAdDtlCt = afCurtAdDtlCt;
	}
	public String getWifeFmlyBokMvYn() {
		return wifeFmlyBokMvYn;
	}
	public void setWifeFmlyBokMvYn(String wifeFmlyBokMvYn) {
		this.wifeFmlyBokMvYn = wifeFmlyBokMvYn;
	}
	public String getWifeFmlyBokNo() {
		return wifeFmlyBokNo;
	}
	public void setWifeFmlyBokNo(String wifeFmlyBokNo) {
		this.wifeFmlyBokNo = wifeFmlyBokNo;
	}
	public String getAfWifeFmlyBokNo() {
		return afWifeFmlyBokNo;
	}
	public void setAfWifeFmlyBokNo(String afWifeFmlyBokNo) {
		this.afWifeFmlyBokNo = afWifeFmlyBokNo;
	}
	public String getFstWtnNm() {
		return fstWtnNm;
	}
	public void setFstWtnNm(String fstWtnNm) {
		this.fstWtnNm = fstWtnNm;
	}
	public String getFstWtnRsdtNo() {
		return fstWtnRsdtNo;
	}
	public void setFstWtnRsdtNo(String fstWtnRsdtNo) {
		this.fstWtnRsdtNo = fstWtnRsdtNo;
	}
	public String getSecdWtnNm() {
		return secdWtnNm;
	}
	public void setSecdWtnNm(String secdWtnNm) {
		this.secdWtnNm = secdWtnNm;
	}
	public String getSecdWtnRsdtNo() {
		return secdWtnRsdtNo;
	}
	public void setSecdWtnRsdtNo(String secdWtnRsdtNo) {
		this.secdWtnRsdtNo = secdWtnRsdtNo;
	}
	public String getMrrgAdCd() {
		return mrrgAdCd;
	}
	public void setMrrgAdCd(String mrrgAdCd) {
		this.mrrgAdCd = mrrgAdCd;
	}
	public String getMrrgAdDtlCt() {
		return mrrgAdDtlCt;
	}
	public void setMrrgAdDtlCt(String mrrgAdDtlCt) {
		this.mrrgAdDtlCt = mrrgAdDtlCt;
	}
	public String getCertNo() {
		return certNo;
	}
	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}
	public String getPbctOfic() {
		return pbctOfic;
	}
	public void setPbctOfic(String pbctOfic) {
		this.pbctOfic = pbctOfic;
	}
	public String getRmk() {
		return rmk;
	}
	public void setRmk(String rmk) {
		this.rmk = rmk;
	}
	public String getCrdReisuceDueDd() {
		return crdReisuceDueDd;
	}
	public void setCrdReisuceDueDd(String crdReisuceDueDd) {
		this.crdReisuceDueDd = crdReisuceDueDd;
	}
	public String getRgstOrgnzCd() {
		return rgstOrgnzCd;
	}
	public void setRgstOrgnzCd(String rgstOrgnzCd) {
		this.rgstOrgnzCd = rgstOrgnzCd;
	}
	public String getTamLedrCfmYn() {
		return tamLedrCfmYn;
	}
	public void setTamLedrCfmYn(String tamLedrCfmYn) {
		this.tamLedrCfmYn = tamLedrCfmYn;
	}
	public String getCfmTamLedrId() {
		return cfmTamLedrId;
	}
	public void setCfmTamLedrId(String cfmTamLedrId) {
		this.cfmTamLedrId = cfmTamLedrId;
	}
	public String getRsdtCfmYn() {
		return rsdtCfmYn;
	}
	public void setRsdtCfmYn(String rsdtCfmYn) {
		this.rsdtCfmYn = rsdtCfmYn;
	}
	public String getCntTelNo() {
		return cntTelNo;
	}
	public void setCntTelNo(String cntTelNo) {
		this.cntTelNo = cntTelNo;
	}
	public String getDltYn() {
		return dltYn;
	}
	public void setDltYn(String dltYn) {
		this.dltYn = dltYn;
	}
	public String getFstRgstUserId() {
		return fstRgstUserId;
	}
	public void setFstRgstUserId(String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}
	public String getFstRgstDt() {
		return fstRgstDt;
	}
	public void setFstRgstDt(String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}
	public String getLstUdtUserId() {
		return lstUdtUserId;
	}
	public void setLstUdtUserId(String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}
	public String getLstUdtDt() {
		return lstUdtDt;
	}
	public void setLstUdtDt(String lstUdtDt) {
		this.lstUdtDt = lstUdtDt;
	}
	public String getNewSeqNo() {
		return newSeqNo;
	}
	public void setNewSeqNo(String newSeqNo) {
		this.newSeqNo = newSeqNo;
	}
	public String getFmlyBokNoDp() {
		return fmlyBokNoDp;
	}
	public void setFmlyBokNoDp(String fmlyBokNoDp) {
		this.fmlyBokNoDp = fmlyBokNoDp;
	}
	public String getEnNm() {
		return enNm;
	}
	public void setEnNm(String enNm) {
		this.enNm = enNm;
	}
	public String getNatLangCdNm() {
		return natLangCdNm;
	}
	public void setNatLangCdNm(String natLangCdNm) {
		this.natLangCdNm = natLangCdNm;
	}
	public String getFrgnLangCdNm() {
		return frgnLangCdNm;
	}
	public void setFrgnLangCdNm(String frgnLangCdNm) {
		this.frgnLangCdNm = frgnLangCdNm;
	}
	public String getMthrNm() {
		return mthrNm;
	}
	public void setMthrNm(String mthrNm) {
		this.mthrNm = mthrNm;
	}
	public String getSmrRsdcCdNm() {
		return smrRsdcCdNm;
	}
	public void setSmrRsdcCdNm(String smrRsdcCdNm) {
		this.smrRsdcCdNm = smrRsdcCdNm;
	}
	public String getGfthrNm() {
		return gfthrNm;
	}
	public void setGfthrNm(String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}
	public String getWtrRsdcCdNm() {
		return wtrRsdcCdNm;
	}
	public void setWtrRsdcCdNm(String wtrRsdcCdNm) {
		this.wtrRsdcCdNm = wtrRsdcCdNm;
	}
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	public String getMrrgCdNm() {
		return mrrgCdNm;
	}
	public void setMrrgCdNm(String mrrgCdNm) {
		this.mrrgCdNm = mrrgCdNm;
	}
	public String getBthDd() {
		return bthDd;
	}
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	public String getOcp() {
		return ocp;
	}
	public void setOcp(String ocp) {
		this.ocp = ocp;
	}
	public String getBthPlceCdNm() {
		return bthPlceCdNm;
	}
	public void setBthPlceCdNm(String bthPlceCdNm) {
		this.bthPlceCdNm = bthPlceCdNm;
	}
	public String getBthNatDiv() {
		return bthNatDiv;
	}
	public void setBthNatDiv(String bthNatDiv) {
		this.bthNatDiv = bthNatDiv;
	}
	public String getBthNatCdNm() {
		return bthNatCdNm;
	}
	public void setBthNatCdNm(String bthNatCdNm) {
		this.bthNatCdNm = bthNatCdNm;
	}
	public String getFrgnBthCtyNm() {
		return frgnBthCtyNm;
	}
	public void setFrgnBthCtyNm(String frgnBthCtyNm) {
		this.frgnBthCtyNm = frgnBthCtyNm;
	}
	public String getMltSrvcCdNm() {
		return mltSrvcCdNm;
	}
	public void setMltSrvcCdNm(String mltSrvcCdNm) {
		this.mltSrvcCdNm = mltSrvcCdNm;
	}
	public String getEncyCdNm() {
		return encyCdNm;
	}
	public void setEncyCdNm(String encyCdNm) {
		this.encyCdNm = encyCdNm;
	}
	public String getDsbtCdNm() {
		return dsbtCdNm;
	}
	public void setDsbtCdNm(String dsbtCdNm) {
		this.dsbtCdNm = dsbtCdNm;
	}
	public String getFmlyLangCdNm() {
		return fmlyLangCdNm;
	}
	public void setFmlyLangCdNm(String fmlyLangCdNm) {
		this.fmlyLangCdNm = fmlyLangCdNm;
	}
	public String getPoliCntrNm() {
		return poliCntrNm;
	}
	public void setPoliCntrNm(String poliCntrNm) {
		this.poliCntrNm = poliCntrNm;
	}
	public String getPmntAdCdNm() {
		return pmntAdCdNm;
	}
	public void setPmntAdCdNm(String pmntAdCdNm) {
		this.pmntAdCdNm = pmntAdCdNm;
	}
	public String getEduCdNm() {
		return eduCdNm;
	}
	public void setEduCdNm(String eduCdNm) {
		this.eduCdNm = eduCdNm;
	}
	public String getEduYn() {
		return eduYn;
	}
	public void setEduYn(String eduYn) {
		this.eduYn = eduYn;
	}
	public String getEduLvDocYn() {
		return eduLvDocYn;
	}
	public void setEduLvDocYn(String eduLvDocYn) {
		this.eduLvDocYn = eduLvDocYn;
	}
	public String getCurtAdNatCdNm() {
		return curtAdNatCdNm;
	}
	public void setCurtAdNatCdNm(String curtAdNatCdNm) {
		this.curtAdNatCdNm = curtAdNatCdNm;
	}
	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}
	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}
	public String getBldTyeCdNm() {
		return bldTyeCdNm;
	}
	public void setBldTyeCdNm(String bldTyeCdNm) {
		this.bldTyeCdNm = bldTyeCdNm;
	}
	public String getBldTyeDocYn() {
		return bldTyeDocYn;
	}
	public void setBldTyeDocYn(String bldTyeDocYn) {
		this.bldTyeDocYn = bldTyeDocYn;
	}
	public String getRlgnCdNm() {
		return rlgnCdNm;
	}
	public void setRlgnCdNm(String rlgnCdNm) {
		this.rlgnCdNm = rlgnCdNm;
	}
	public String getSecdNltyCdNm() {
		return secdNltyCdNm;
	}
	public void setSecdNltyCdNm(String secdNltyCdNm) {
		this.secdNltyCdNm = secdNltyCdNm;
	}
	public String getRlgnSectCdNm() {
		return rlgnSectCdNm;
	}
	public void setRlgnSectCdNm(String rlgnSectCdNm) {
		this.rlgnSectCdNm = rlgnSectCdNm;
	}
	public String getRvctgRsn() {
		return rvctgRsn;
	}
	public void setRvctgRsn(String rvctgRsn) {
		this.rvctgRsn = rvctgRsn;
	}
	public String getRvctDd() {
		return rvctDd;
	}
	public void setRvctDd(String rvctDd) {
		this.rvctDd = rvctDd;
	}
	public String getRsnCdNm() {
		return rsnCdNm;
	}
	public void setRsnCdNm(String rsnCdNm) {
		this.rsnCdNm = rsnCdNm;
	}
	public String getRsdtRgstDd() {
		return rsdtRgstDd;
	}
	public void setRsdtRgstDd(String rsdtRgstDd) {
		this.rsdtRgstDd = rsdtRgstDd;
	}
	public String getRsdtRgstIdNm() {
		return rsdtRgstIdNm;
	}
	public void setRsdtRgstIdNm(String rsdtRgstIdNm) {
		this.rsdtRgstIdNm = rsdtRgstIdNm;
	}
	public String getCfmTamLedrIdNm() {
		return cfmTamLedrIdNm;
	}
	public void setCfmTamLedrIdNm(String cfmTamLedrIdNm) {
		this.cfmTamLedrIdNm = cfmTamLedrIdNm;
	}
	public String getSecdNltyYn() {
		return secdNltyYn;
	}
	public void setSecdNltyYn(String secdNltyYn) {
		this.secdNltyYn = secdNltyYn;
	}
	public String getEduCd() {
		return eduCd;
	}
	public void setEduCd(String eduCd) {
		this.eduCd = eduCd;
	}
	public String getOldCrdNo1() {
		return oldCrdNo1;
	}
	public void setOldCrdNo1(String oldCrdNo1) {
		this.oldCrdNo1 = oldCrdNo1;
	}
	public String getOldCrdNo2() {
		return oldCrdNo2;
	}
	public void setOldCrdNo2(String oldCrdNo2) {
		this.oldCrdNo2 = oldCrdNo2;
	}
	public String getOldCrdNo3() {
		return oldCrdNo3;
	}
	public void setOldCrdNo3(String oldCrdNo3) {
		this.oldCrdNo3 = oldCrdNo3;
	}
	public String getOldCrdNo4() {
		return oldCrdNo4;
	}
	public void setOldCrdNo4(String oldCrdNo4) {
		this.oldCrdNo4 = oldCrdNo4;
	}
	public String getOldCrdIsuceDd() {
		return oldCrdIsuceDd;
	}
	public void setOldCrdIsuceDd(String oldCrdIsuceDd) {
		this.oldCrdIsuceDd = oldCrdIsuceDd;
	}
	public String getOldCrdIsucePlceCd() {
		return oldCrdIsucePlceCd;
	}
	public void setOldCrdIsucePlceCd(String oldCrdIsucePlceCd) {
		this.oldCrdIsucePlceCd = oldCrdIsucePlceCd;
	}
	public String getCrdIsucePlceCdNm() {
		return crdIsucePlceCdNm;
	}
	public void setCrdIsucePlceCdNm(String crdIsucePlceCdNm) {
		this.crdIsucePlceCdNm = crdIsucePlceCdNm;
	}
	public String getCrdIsuDueDd() {
		return crdIsuDueDd;
	}
	public void setCrdIsuDueDd(String crdIsuDueDd) {
		this.crdIsuDueDd = crdIsuDueDd;
	}
	public String getFmlyBokNum() {
		return fmlyBokNum;
	}
	public void setFmlyBokNum(String fmlyBokNum) {
		this.fmlyBokNum = fmlyBokNum;
	}
	public String getBthPlceCd() {
		return bthPlceCd;
	}
	public void setBthPlceCd(String bthPlceCd) {
		this.bthPlceCd = bthPlceCd;
	}
	public String getBthNatCd() {
		return bthNatCd;
	}
	public void setBthNatCd(String bthNatCd) {
		this.bthNatCd = bthNatCd;
	}
	public String getMltSrvcCd() {
		return mltSrvcCd;
	}
	public void setMltSrvcCd(String mltSrvcCd) {
		this.mltSrvcCd = mltSrvcCd;
	}
	public String getEncyCd() {
		return encyCd;
	}
	public void setEncyCd(String encyCd) {
		this.encyCd = encyCd;
	}
	public String getDsbtDtlCt() {
		return dsbtDtlCt;
	}
	public void setDsbtDtlCt(String dsbtDtlCt) {
		this.dsbtDtlCt = dsbtDtlCt;
	}
	public String getFmlyLangCd() {
		return fmlyLangCd;
	}
	public void setFmlyLangCd(String fmlyLangCd) {
		this.fmlyLangCd = fmlyLangCd;
	}
	public String getPoliCntrSeqNoNm() {
		return poliCntrSeqNoNm;
	}
	public void setPoliCntrSeqNoNm(String poliCntrSeqNoNm) {
		this.poliCntrSeqNoNm = poliCntrSeqNoNm;
	}
	public String getRlgnCd() {
		return rlgnCd;
	}
	public void setRlgnCd(String rlgnCd) {
		this.rlgnCd = rlgnCd;
	}
	public String getSecdNltyCd() {
		return secdNltyCd;
	}
	public void setSecdNltyCd(String secdNltyCd) {
		this.secdNltyCd = secdNltyCd;
	}
	public String getRlgnSectCd() {
		return rlgnSectCd;
	}
	public void setRlgnSectCd(String rlgnSectCd) {
		this.rlgnSectCd = rlgnSectCd;
	}
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String getFmlyBokNoNum() {
		return fmlyBokNoNum;
	}
	public void setFmlyBokNoNum(String fmlyBokNoNum) {
		this.fmlyBokNoNum = fmlyBokNoNum;
	}
	public String getNewFmlyBokYn() {
		return newFmlyBokYn;
	}
	public void setNewFmlyBokYn(String newFmlyBokYn) {
		this.newFmlyBokYn = newFmlyBokYn;
	}
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	public String getFthrNm() {
		return fthrNm;
	}
	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}
	public String getBldTyeCd() {
		return bldTyeCd;
	}
	public void setBldTyeCd(String bldTyeCd) {
		this.bldTyeCd = bldTyeCd;
	}
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}
	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}
	public String getPrntDd() {
		return prntDd;
	}
	public void setPrntDd(String prntDd) {
		this.prntDd = prntDd;
	}
	public String getValidDdEx() {
		return validDdEx;
	}
	public void setValidDdEx(String validDdEx) {
		this.validDdEx = validDdEx;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String gethBthDd() {
		return hBthDd;
	}
	public void sethBthDd(String hBthDd) {
		this.hBthDd = hBthDd;
	}
	public String getgBthDd() {
		return gBthDd;
	}
	public void setgBthDd(String gBthDd) {
		this.gBthDd = gBthDd;
	}
	public String getAfWifeRlCdNm() {
		return afWifeRlCdNm;
	}
	public void setAfWifeRlCdNm(String afWifeRlCdNm) {
		this.afWifeRlCdNm = afWifeRlCdNm;
	}
	public String getFmlyHadGdrCd() {
		return fmlyHadGdrCd;
	}
	public void setFmlyHadGdrCd(String fmlyHadGdrCd) {
		this.fmlyHadGdrCd = fmlyHadGdrCd;
	}
	public String getOp() {
		return op;
	}
	public void setOp(String op) {
		this.op = op;
	}
	public String getRlCd() {
		return rlCd;
	}
	public void setRlCd(String rlCd) {
		this.rlCd = rlCd;
	}
	public String getRlCdNm() {
		return rlCdNm;
	}
	public void setRlCdNm(String rlCdNm) {
		this.rlCdNm = rlCdNm;
	}
	public String getAgGap() {
		return agGap;
	}
	public void setAgGap(String agGap) {
		this.agGap = agGap;
	}
	public String getMberCn() {
		return mberCn;
	}
	public void setMberCn(String mberCn) {
		this.mberCn = mberCn;
	}
	public String getMberCnTyeCd() {
		return mberCnTyeCd;
	}
	public void setMberCnTyeCd(String mberCnTyeCd) {
		this.mberCnTyeCd = mberCnTyeCd;
	}
	public String getMberRstrtGdrCd() {
		return mberRstrtGdrCd;
	}
	public void setMberRstrtGdrCd(String mberRstrtGdrCd) {
		this.mberRstrtGdrCd = mberRstrtGdrCd;
	}
	public String getFthrAgGap() {
		return fthrAgGap;
	}
	public void setFthrAgGap(String fthrAgGap) {
		this.fthrAgGap = fthrAgGap;
	}
	public String getFthrRlCd() {
		return fthrRlCd;
	}
	public void setFthrRlCd(String fthrRlCd) {
		this.fthrRlCd = fthrRlCd;
	}
	public String getFthrMftrYn() {
		return fthrMftrYn;
	}
	public void setFthrMftrYn(String fthrMftrYn) {
		this.fthrMftrYn = fthrMftrYn;
	}
	public String getGfthrAgGap() {
		return gfthrAgGap;
	}
	public void setGfthrAgGap(String gfthrAgGap) {
		this.gfthrAgGap = gfthrAgGap;
	}
	public String getGfthrRlCd() {
		return gfthrRlCd;
	}
	public void setGfthrRlCd(String gfthrRlCd) {
		this.gfthrRlCd = gfthrRlCd;
	}
	public String getGfthrMftrYn() {
		return gfthrMftrYn;
	}
	public void setGfthrMftrYn(String gfthrMftrYn) {
		this.gfthrMftrYn = gfthrMftrYn;
	}
	public String getMthrAgGap() {
		return mthrAgGap;
	}
	public void setMthrAgGap(String mthrAgGap) {
		this.mthrAgGap = mthrAgGap;
	}
	public String getMthrRlCd() {
		return mthrRlCd;
	}
	public void setMthrRlCd(String mthrRlCd) {
		this.mthrRlCd = mthrRlCd;
	}
	public String getMthrMftrYn() {
		return mthrMftrYn;
	}
	public void setMthrMftrYn(String mthrMftrYn) {
		this.mthrMftrYn = mthrMftrYn;
	}
	public String getHsbdMftrYn() {
		return hsbdMftrYn;
	}
	public void setHsbdMftrYn(String hsbdMftrYn) {
		this.hsbdMftrYn = hsbdMftrYn;
	}
	
	
	
}
