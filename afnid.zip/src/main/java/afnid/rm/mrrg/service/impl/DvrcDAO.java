package afnid.rm.mrrg.service.impl;


import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.mrrg.service.DvrcVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This Controller class processes request of MVG and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Si Kyung Yang
 * @since 2013.05.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.05.21  		Si Kyung Yang         						Create
 *
 * </pre>
 */
@Repository("dvrcDAO")
public class DvrcDAO extends EgovAbstractDAO{
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	
	/**
	 * DAO-method for retrieving Information of Citizen. <br>
	 * 
	 * @param vo Input item for retrieving detail information of program(DvrcVO).
	 * @return DvrcVO Retrieve information of Citizen.
	 * @exception Exception
	 */	
	 public DvrcVO selectRsdtInfr(DvrcVO vo) throws Exception{
		
		vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		
		return (DvrcVO)selectByPk("dvrcDAO.selectRsdtInfr", vo);
	 }
	
	/**
	 * DAO-method for retrieving Wife Citizen Sequence No. <br>
	 * 
	 * @param vo Input item for retrieving Wife Citizen Sequence No.(DvrcVO).
	 * @return String Wife Citizen Sequence No.
	 * @exception Exception
	 */	
	 public String selectWifeRsdtSeqNo(DvrcVO vo) throws Exception{
		
		return (String)selectByPk("dvrcDAO.selectWifeRsdtSeqNo", vo);
	 }
	 
	 /**
		 * DAO-method for retrieving count of ongoing revocation. <br>
		 * 
		 * @param rsdtSeqNo Input item for retrieving count of ongoing revocation(String).
		 * @return int count of ongoing revocation.
		 * @exception Exception
		 */	
		 public int selectRsdtCcltStus(String rsdtSeqNo) throws Exception{
			
			return (Integer)selectByPk("dvrcDAO.selectRsdtCcltStus", rsdtSeqNo);
		 }
	
	/**
	 * DAO-method for Marriage sequence No. for Divorce Registration. <br>
	 * 
	 * @param vo Input item for Marriage sequence No.(DvrcVO).
	 * @return String marriage Sequence No.
	 * @exception Exception
	 */	
	 public DvrcVO selectMrrgSeqNo(DvrcVO vo) throws Exception{
		
		return (DvrcVO)selectByPk("dvrcDAO.selectMrrgSeqNo", vo);
	 }
	
	/**
	 * DAO-method for retrieving Information of Citizen. <br>
	 * 
	 * @param vo Input item for retrieving detail information of program(DvrcVO).
	 * @return DvrcVO Retrieve information of Citizen.
	 * @exception Exception
	 */	
	 public DvrcVO selectDvrcRsdtInfr(DvrcVO vo) throws Exception{
		return (DvrcVO)selectByPk("dvrcDAO.selectDvrcRsdtInfo", vo);
	 }
	
	/**
	 * DAO-method for retrieving list Information of Marriage. <br>
	 * 
	 * @param vo Input item for retrieving detail information of program(DvrcVO).
	 * @return DvrcVO Retrieve list information of Marriage.
	 * @exception Exception
	 */	
	 @SuppressWarnings("unchecked")
	 public List<DvrcVO> selectListMrrgInfr(DvrcVO vo) throws Exception{
		return list("dvrcDAO.selectListMrrgInfr", vo);					
	 }
	
	/**
	 * DAO-method for registering information of Divorce. <br>
	 * 
	 * @param vo Input item for registering Divorce information(DvrcVO).
	 * @return String Divorce Seq No.
	 * @exception Exception
	 */
	 public String insertDvrcInfr(DvrcVO vo) throws Exception{
	    
		return (String)insert("dvrcDAO.insertDvrcInfr", vo);
	 }
	 
	 /**
	 * DAO-method for Retrieves Divorce Information for Divorce update. <br>
	 * 
	 * @param vo Input item for retrieving Divorce Information(DvrcVO).
	 * @return DvrcVO Retrieve Divorce Information 
	 * @exception Exception
	 */	
	 public DvrcVO selectDvrcInfr(DvrcVO vo) throws Exception{
		
		return (DvrcVO)selectByPk("dvrcDAO.selectDvrcInfr", vo);
	 }
	 
	 /**
	 * DAO-method for retrieving Divorce Detail Information of Divorce. <br>
	 * 
	 * @param vo Input item for retrieving detail information of program(DvrcVO).
	 * @return DvrcVO Retrieve detail information of Divorce.
	 * @exception Exception
	 */	
	 public DvrcVO selectDvrcDtlInfr(DvrcVO vo) throws Exception{
		return (DvrcVO)selectByPk("dvrcDAO.selectDvrcDtlInfr", vo);
	 }
	 
	 /**
	 * DAO-method for retrieving list Information of Divorce. <br>
	 * 
	 * @param vo Input item for retrieving detail information of program(DvrcVO).
	 * @return DvrcVO Retrieve list information of Divorce.
	 * @exception Exception
	 */	
	 @SuppressWarnings("unchecked")
	 public List<DvrcVO> selectListDvrcInfr(DvrcVO vo) throws Exception{
		return list("dvrcDAO.selectListDvrcInfr", vo);					
	 }
	 
	/**
	 * DAO-method for modifying information of Divorce. <br>
	 * 
	 * @param vo Input item for modifying Divorce information(DvrcVO).
	 * @return int Result Count
	 * @exception Exception
	 */
	 public int updateDvrcInfr(DvrcVO vo) throws Exception{
		  return  update("dvrcDAO.updateDvrcInfr", vo);
	 }
	  
	  
	 /**
	 * DAO-method for retrieving list Information of Divorce. <br>
	 * 
	 * @param vo Input item for retrieving detail information of program(DvrcVO).
	 * @return DvrcVO Retrieve list information of Divorce.
	 * @exception Exception
	 */	
	 public DvrcVO selectDvrcAprvInfr(DvrcVO vo) throws Exception{
		return (DvrcVO)selectByPk("dvrcDAO.selectDvrcAprvInfr", vo);
	 } 
	 
	 /**
	 * DAO-method for registering information of Divorce. <br>
	 * 
	 * @param vo Input item for registering Divorce information(DvrcVO).
	 * @return 
	 * @exception Exception
	 */
	public boolean updateDvrcAprvInfr(DvrcVO vo) throws Exception{
		boolean result = false;  
		
		int Result = update("dvrcDAO.updateDvrcAprvInfr", vo);
		
		if(Result == 1){
			result = true;
		}
		
		return result;
	}
	
	/**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(RcptCardVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
   	public int selectMrrgCnt(DvrcVO vo) {
       return (Integer)selectByPk("dvrcDAO.selectMrrgCnt", vo);
   	}
	
   	/**
	 * DAO-method for registering information of Divorce. <br>
	 * 
	 * @param vo Input item for registering Divorce information(DvrcVO).
	 * @return boolean result of Update
	 * @exception Exception
	 */
	public boolean updateRsdtInfr(DvrcVO vo) throws Exception{
		boolean result = false; 
		
		int Result = update("dvrcDAO.updateRsdtInfr", vo);
		
		if(Result == 1){
			result = true;
		}
		
		return result;
	}
   		
	/**
	 * DAO-method for retrieving Family From information. <br>
	 *
	 * @param String Input item for retrieving Family From information.(afFmlyBokNo).
	 * @return DvrcVO 
	 * @exception Exception
	 */
	public DvrcVO selectFmlyBokInfr(String afFmlyBokNo) throws Exception{
		return (DvrcVO)selectByPk("dvrcDAO.selectFmlyBokInfr", afFmlyBokNo);
	}
	
	/**
	 * DAO-method for insert information for card issuance <br>
	 * 
	 * @param vo Input item for insert information(DvrcVO).
	 * @return void
	 * @exception Exception
	 */    
    public void insertCrdIsuInfr(DvrcVO vo){
    	insert("dvrcDAO.insertCrdIsuInfr", vo);
    }
	
	/**
	 * DAO-method for  retrieving Receipt of Citizen. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(DvrcVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
    public DvrcVO selectDvrcCrdReisuceRcpt(DvrcVO vo) {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm()); 
		
		if("2".equals(vo.getGdrCd())){
			return (DvrcVO)selectByPk("dvrcDAO.selectDvrcCrdReisuceReceiptW", vo);
		} else {
			return (DvrcVO)selectByPk("dvrcDAO.selectDvrcCrdReisuceReceiptH", vo);
		}

    }
    
    /**
	 * DAO-method for  retrieving Receipt of Citizen. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(DvrcVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectDvrcCrdReisuceOthrRcpt(DvrcVO vo) throws Exception{
		return list("dvrcDAO.selectDvrcCrdReisuceOthrReceipt", vo);
	}
	
	/**
	 * DAO-method for  retrieving Receipt of Citizen. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(DvrcVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")	
    public List<EgovMap> selectDvrcCrdReisuceFrgnRcpt(DvrcVO vo) {
    	return list("dvrcDAO.selectDvrcCrdReisuceFrgnReceipt", vo);
    }
	
	/**
	 * DAO-method for  retrieving Receipt of Citizen Confirmation. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(DvrcVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
    public DvrcVO selectDvrcCfmRcpt(DvrcVO vo) {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());   
		
		if("2".equals(vo.getGdrCd())){
			return (DvrcVO)selectByPk("dvrcDAO.selectDvrcCfmReceiptW", vo);
		} else {
			return (DvrcVO)selectByPk("dvrcDAO.selectDvrcCfmReceiptH", vo);
		}
    }
    
    /**
	 * DAO-method for  retrieving wife permanent address code. <br>
	 *
	 * @param wifeSeqNo Input item for  retrieving wife permanent address code.(String).
	 * @return String wife permanent address code.
	 * @exception Exception
	 */
    public String selectWifePmntAdCd(String wifeSeqNo) {    	
        return (String)selectByPk("dvrcDAO.selectWifePmntAdCd", wifeSeqNo);
    }
    
    /**
	 * DAO-method for retrieving citizen card expiration Status. <br>
	 *
	 * @param mrrgSeqNo Input item for citizen card expiration Status(String).
	 * @param gdr Input item for  select SQL (String).
	 * @return String of parameter
	 * @exception Exception
	 */
    public String selectCrdExpStus(String rsdtSeqNo) {
    
		String result =(String)selectByPk("dvrcDAO.selectCrdExpStus", rsdtSeqNo);

        return result;
    }
    
    /**
	 * DAO-method for retrieving Male Card Write Request parameter. <br>
	 *
	 * @param vo Input item for  retrieving Card Write Request parameter(DvrcVO).
	 * @param gdr Input item for  select SQL (String).
	 * @return String of parameter
	 * @exception Exception
	 */
    public String selectMaleParamWriteRqst(DvrcVO vo) {
		String param = "";
    	
		param =(String)selectByPk("dvrcDAO.selectMaleParamWriteRqst", vo);

        return param;
    }
    
    /**
	 * DAO-method for retrieving Female Card Write Request parameter. <br>
	 *
	 * @param vo Input item for retrieving Card Write Request parameter(DvrcVO).
	 * @param gdr Input item for  select SQL (String).
	 * @return String of parameter
	 * @exception Exception
	 */
    public String selectFemaleParamWriteRqst(DvrcVO vo) {
    	String param = "";

		param =(String)selectByPk("dvrcDAO.selectFemaleParamWriteRqst", vo);

        return param;
    }
    
    /**
	 * DAO-method for  retrieving wife permanent address code. <br>
	 *
	 * @param wifeSeqNo Input item for  retrieving wife permanent address code.(String).
	 * @return String wife permanent address code.
	 * @exception Exception
	 */
    public EgovMap selectResultOfCrdInfrChang(String rsdtSeqNo) {    	
        return (EgovMap)selectByPk("dvrcDAO.selectResultOfCrdInfrChang", rsdtSeqNo);
    }    
    
    
	/**
	 * DAO-method for retrieving  relationship. <br>
	 * 
	 * @param vo Input item for retrieving  relationship.(MrrgVO).
	 * @return relationship code
	 * @exception Exception
	 */  
    @SuppressWarnings("unchecked")
    public List<DvrcVO> selectListRl(DvrcVO vo){
        return list ("dvrcDAO.selectListRl", vo);
    }    
       
	/**
	 * DAO-method for retrieving  relationship. <br>
	 * 
	 * @param vo Input item for retrieving  relationship.(DvrcVO).
	 * @return relationship code
	 * @exception Exception
	 */  
    @SuppressWarnings("unchecked")
    public List<DvrcVO> selectListRlOthr(DvrcVO vo){
        return list ("dvrcDAO.selectListRlOthr", vo);
    } 
    
	/**
	 * DAO-method for retrieving  relationship. <br>
	 * 
	 * @param vo Input item for retrieving  relationship.(MrrgVO).
	 * @return relationship code
	 * @exception Exception
	 */  
    @SuppressWarnings("unchecked")
    public List<DvrcVO> selectListRlAll(DvrcVO vo){
        return list ("dvrcDAO.selectListRlAll", vo);
    }
    
	/**
	 * DAO-method for retrieving  relationship. <br>
	 * 
	 * @param vo Input item for retrieving  relationship.(MrrgVO).
	 * @return relationship code
	 * @exception Exception
	 */  
    @SuppressWarnings("unchecked")
    public List<DvrcVO> selectListRlTbAll(DvrcVO vo){
        return list ("dvrcDAO.selectListRlTbAll", vo);
    } 
    
	/**
	 * DAO-method for retrieving total count relationship in family book. <br>
	 * 
	 * @param vo Input item for retrieving total count relationship in family book(DvrcVO).
	 * @return int Total Count of relationship in family book
	 * @exception Exception
	 */
   	public int selectMberCn(DvrcVO vo) {
       return (Integer)selectByPk("dvrcDAO.selectMberCn", vo);
   	} 
   	
    /**
	 * DAO-method for  retrieving Family Head Gender. <br>
	 *
	 * @param wifeSeqNo Input item for  retrieving Family Head Gender.(String).
	 * @return String Family Head Gender code.
	 * @exception Exception
	 */
    public String selectFmlyHadGdrCd(DvrcVO vo) {    	
        return (String)selectByPk("dvrcDAO.selectFmlyHadGdrCd", vo);
    }   	
}
