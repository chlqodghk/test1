package afnid.rm.mrrg.service;

import afnid.cm.ComDefaultVO;

public class DvrcVO extends ComDefaultVO{
	private static final long serialVersionUID = 1L;

	private String rsdtSeqNo;
	private String rsdtNo;
	private String rsdtNoDp;
	private String gdrCd;
	private String spusRsdtSeqNo;
	private String spusNm;
	private String userId;
	private String cn;
	private String mrrgCn;
	private String errMsg;
	private String mrrgDd;
	private String nameChangeMsg;
	private String canNameChangeYn;
	private String crdReisuceDmBfExpr;
	private String crdDlvrDd;
	private String isExp;
	private String givNm;
	private String surnm;
	private String enSurnm;
	private String enGivNm;
	private String fthrNm;
	private String hadNm;
	private String fmlyBokNo;
	private String fmlyBokSeqNo;
	private String fmlyMberNo;
	private String frngrYn;
	private String appDd;
	private String ccltDd;
	private String hsbdFthrNm;
	private String wifeFthrNm;
	private String hsbdFmlyHadNm;
	private String hsbdFmlyBokNo;
	private String hsbdFmlyBokNoDp;
	private String wifeCcltDd;
	private String hsbdCcltDd;
	private String calTye;
	private String hsbdRgstYn;
	private String hsbdRgstCn;
	private String wifeRgstYn;
	private String wifeRgstCn;
	private String wifeSgnt;
	private String hsbdSgnt;
	private String crdIsucePlceCd;
	private String crdIsuceYn;
	
	private String mrrgCd;
	private String mrrgDdJ;
	private String mrrgDdG;
	private String wifeNm;
	private String hsbdNm;
	private String[] errMsgVal;
	private String dvrcSeqNo;
	private String dvrcDd;
	private String dvrcKndCd;
	private String dvrcKndCdNm;
	private String hsbdRsdtSeqNo;
	private String hsbdRsdtNo;
	private String hsbdRsdtNoDp;
	private String hsbdGivNm;
	private String hsbdSurnm;
	private String hsbdEnSurnm;
	private String hsbdEnGivNm;
	private String hsbdFrngrYn;
	private String hsbdFrngrRgstNo;
	private String hsbdNltyCd;
	private String hsbdNltyCdNm;
	private String hsbdRlCd;
	private String hsbdRlCdNm;
	private String hsbdOthrRl;
	private String hsbdCurtAdChngYn;
	private String hsbdCurtAdDiv;
	private String hsbdCurtAdNatCd;
	private String hsbdCurtAdCd;
	private String hsbdCurtAdCdNm;
	private String hsbdCurtAdDtlCt;	
	private String hsbdSmrRsdcCd;
	private String hsbdWtrRsdcCd;		
	private String hsbdPmntAdChngYn;
	private String hsbdPmntAdCd;
	private String hsbdPmntAdCdNm;
	private String hsbdPmntAdDtlCt;	
	private String hsbdFmlyHadSeqNo;	
	private String hsbdFmlyHadYn;
	private String afHsbdRlCd;
	private String afHsbdRlCdNm;	
	private String afHsbdOthrRl;
	private String afHsbdCurtAdCd;
	private String afHsbdCurtAdCdNm;
	private String afHsbdCurtAdDtlCt;	
	private String afHsbdPmntAdCd;
	private String afHsbdPmntAdCdNm;
	private String afHsbdPmntAdDtlCt;
	private String hsbdRlChngYn;
	
	private String wifeFmlyHadYn;
	private String wifeRsdtSeqNo;
	private String wifeRsdtNo;
	private String wifeRsdtNoDp;
	private String wifeGivNm;
	private String wifeSurnm;
	private String wifeEnGivNm;
	private String wifeEnSurnm;
	private String wifeFrngrYn;
	private String wifeFrngrRgstNo;
	private String wifeNltyCd;
	private String wifeNltyCdNm;
	private String wifeNmChngYn;
	private String wifeFmlyHadSeqNo;
	private String wifeFmlyHadNm;
	private String wifeRlCd;
	private String wifeRlCdNm;
	private String wifeOthrRl;
	private String afWifeRlCd;
	private String afWifeRlCdNm;	
	private String afWifeOthrRl;
	private String afWifeSurnm;
	private String afWifeEnSurnm;
	private String wifePmntAdChngYn;
	private String afWifePmntAdCd;
	private String afWifePmntAdCdNm;
	private String afWifePmntAdDtlCt;
	private String wifeCurtAdDiv;
	private String wifeCurtAdNatCd;
	private String wifeCurtAdCd;
	private String wifeCurtAdCdNm;
	private String wifeCurtAdDtlCt;	
	private String wifeSmrRsdcCd;
	private String wifeWtrRsdcCd;	
	private String wifeCurtAdChngYn;
	private String afWifeCurtAdCd;
	private String afWifeCurtAdCdNm;
	private String afWifeCurtAdDtlCt;
	private String wifeFmlyBokMvYn;
	private String wifeFmlyBokNo;
	private String wifeFmlyBokNoDp;
	private String afWifeFmlyBokNo;
	private String afWifeFmlyBokNoDp;
	private String afHsbdCurtAdDiv;
	private String afHsbdCurtAdNatCd;
	private String afHsbdSmrRsdcCd;
	private String afHsbdSmrRsdcCdNm;
	private String afHsbdWtrRsdcCd;
	private String afHsbdWtrRsdcCdNm;
	private String afWifeCurtAdDiv;
	private String afWifeCurtAdNatCd;
	private String afWifeSmrRsdcCd;
	private String afWifeSmrRsdcCdNm;
	private String afWifeWtrRsdcCd;
	private String afWifeWtrRsdcCdNm;
	private String afHsbdCurtAdDtlCtD;
	private String afHsbdCurtAdDtlCtF;
	private String afWifeCurtAdDtlCtD;
	private String afWifeCurtAdDtlCtF;
	private String wifeRlChngYn;
	
	private String fstWtnNm;
	private String fstWtnRsdtNo;
	private String secdWtnNm;
	private String secdWtnRsdtNo;
	private String dvrcAdCd;
	private String dvrcAdCdNm;
	private String dvrcAdDtlCt;
	private String certNo;
	private String pbctOfic;
	private String rmk;
	private String mrrgSeqNo;
	private String crdReisuceDueDd;
	private String rgstOrgnzCd;
	private String rgstOrgnzCdNm;
	private String tamLedrCfmYn;
	private String cfmTamLedrId;
	private String rsdtCfmYn;
	private String cntTelNo;
	private String cntTelNo2;
	private String dltYn;
	private String fstRgstUserId;
	private String fstRgstDt;
	private String lstUdtUserId;
	private String lstUdtDt;
	private String emlAd;

	private String kochiAdCd;
	private String canHsbdAdChangYn;
	private String hsbdAdChangeMsg;
	private String isHsbdExp;
	private String wifePmntAdCd;
	private String wifePmntAdCdNm;
	private String wifePmntAdDtlCt;
	
	private String fthrRsdtSeqNo;
	private String fthrFmlyBokNo;
	private String fthrFmlyBokNoDp;
	private String fthrSurnm;
	private String fthrEnSurnm;
	private String fthrPmntAdCd;
	private String fthrPmntAdCdNm;
	private String fthrPmntAdDtlCt;
	private String fthrCurtAdDiv;
	private String fthrCurtAdCd;
	private String fthrCurtAdCdNm;
	private String fthrCurtAdNatCd;
	private String fthrCurtAdNatCdNm;
	private String fthrCurtAdDtlCt;
	private String fthrSmrRsdcCd;
	private String fthrSmrRsdcCdNm;
	private String fthrWtrRsdcCd;
	private String fthrWtrRsdcCdNm;
	
	private String hsbdFthrFmlyBokNo;
	private String hsbdFthrFmlyBokNoDp;	
	private String hsbdFthrRsdtSeqNo;
	private String hsbdFthrPmntAdCd;
	private String hsbdFthrPmntAdCdNm;
	private String hsbdFthrPmntAdDtlCt;	
	private String hsbdFthrCurtAdDiv;
	private String hsbdFthrCurtAdCd;
	private String hsbdFthrCurtAdCdNm;
	private String hsbdFthrCurtAdNatCd;
	private String hsbdFthrCurtAdNatCdNm;
	private String hsbdFthrCurtAdDtlCt;
	private String hsbdFthrSmrRsdcCd;
	private String hsbdFthrSmrRsdcCdNm;
	private String hsbdFthrWtrRsdcCd;
	private String hsbdFthrWtrRsdcCdNm;
	private String hsbdFthrRlCd;
	private String hsbdFthrRlCdNm;
	private String hsbdFthrOthrRl;
	private String hsbdFthrFmlyHadYn;
	
	private String wifeFthrRsdtSeqNo;
	private String wifeFthrFmlyBokNo;
	private String wifeFthrFmlyBokNoDp;
	private String wifeFthrSurnm;
	private String wifeFthrEnSurnm;
	private String wifeFthrPmntAdCd;
	private String wifeFthrPmntAdCdNm;
	private String wifeFthrPmntAdDtlCt;
	private String wifeFthrCurtAdDiv;
	private String wifeFthrCurtAdCd;
	private String wifeFthrCurtAdCdNm;
	private String wifeFthrCurtAdNatCd;
	private String wifeFthrCurtAdNatCdNm;
	private String wifeFthrCurtAdDtlCt;
	private String wifeFthrSmrRsdcCd;
	private String wifeFthrSmrRsdcCdNm;
	private String wifeFthrWtrRsdcCd;
	private String wifeFthrWtrRsdcCdNm;
	private String wifeFthrRlCd;
	private String wifeFthrRlCdNm;
	private String wifeFthrOthrRl;	
	private String wifeFthrFmlyHadYn;
	
	private String fstWtnOldCrdNo1;
	private String fstWtnOldCrdNo2;
	private String fstWtnOldCrdNo3;
	private String fstWtnOldCrdNo4;
	private String secdWtnOldCrdNo1;
	private String secdWtnOldCrdNo2;
	private String secdWtnOldCrdNo3;
	private String secdWtnOldCrdNo4;
	private String nltyCdNm;
	private String fstWtnOldCrdIsuceDd;
	private String fstWtnOldCrdIsucePlceCd;
	private String fstWtnOldCrdIsucePlceCdNm;
	private String secdWtnOldCrdIsuceDd;
	private String secdWtnOldCrdIsucePlceCd ;
	private String secdWtnOldCrdIsucePlceCdNm;
	private String rsdtStusCd;
	private String ersrCd;


	private String fmlyBokNoDp;
	private String enNm;
	private String natLangCdNm;
	private String frgnLangCdNm;
	private String mthrNm;
	private String smrRsdcCdNm;
	private String gfthrNm;
	private String wtrRsdcCdNm;
	private String gdrCdNm;	
	private String mrrgCdNm;
	private String bthDd;
	private String gBthDd;
	private String hBthDd;
	private String ocp;
	private String bthPlceCdNm;
	private String bthNatDiv;
	private String bthNatCdNm;
	private String frgnBthCtyNm;
	private String mltSrvcCdNm;
	private String encyCdNm;
	private String dsbtCdNm;
	private String fmlyLangCdNm;
	private String poliCntrNm;
	private String pmntAdCdNm;
	private String pmntAdDtlCt; 
	private String eduCdNm;
	private String eduYn;
	private String eduLvDocYn;
	private String curtAdDiv;
	private String curtAdNatCdNm;
	private String curtAdCd;
	private String curtAdCdNm;
	private String curtAdDtlCt;
	private String bldTyeCdNm;
	private String bldTyeDocYn;
	private String rlgnCdNm;
	private String secdNltyCdNm;
	private String rlgnSectCdNm;
	private String rvctgRsn;
	private String rvctDd;
	private String rsnCdNm;
	private String rsdtRgstDd;
	private String rsdtRgstIdNm;
	private String cfmTamLedrIdNm;
    private String secdNltyYn;
	private String eduCd;
	private String oldCrdNo1;
	private String oldCrdNo2;
	private String oldCrdNo3;
	private String oldCrdNo4;
	private String oldCrdIsuceDd;
	private String oldCrdIsucePlceCd;
	private String crdIsucePlceCdNm;
	private String crdIsuDueDd;
	private String smrRsdcCd;
	private String wtrRsdcCd;
	private String fmlyBokNum;
	private String bthPlceCd;
	private String bthNatCd;
	private String mltSrvcCd;
	private String encyCd;
	private String dsbtDtlCt;
	private String fmlyLangCd;
	private String poliCntrSeqNoNm;
	private String rlgnCd;
	private String secdNltyCd;
	private String rlgnSectCd;
	private String orgnzCd;
	private String fmlyBokNoNum;
	private String bldTyeCd;
	private String crdIsuceDd;
	private String crdExpiryDd;
	private String prntDd;
	private String validDdEx;
	private String newFmlyBokYn;
	private String pmntAdCd;
	private String curtAdNatCd;
	private String rlCd;
	private String rlCdNm;
	private String othrRl;
	private String fmlyHadSeqNo;
	private String fmlyHadYn;
	private String fthrFmlyHadYn;
	
	private String fthrRlCd;
	private String op;
	private String afHsbdFmlyBokNoDp;
	private String afHsbdFmlyBokNo;
	private String hsbdFmlyFomChk;
	 
	private String agGap; 
	private String mberCn; 
	private String mberCnTyeCd; 
	private String fthrAgGap;  
	private String fthrMftrYn; 
	private String gfthrAgGap; 
	private String gfthrRlCd;
	private String gfthrMftrYn; 
	private String mthrAgGap; 
	private String mthrRlCd; 
	private String mthrMftrYn;
	private String hsbdAgGap;  
	private String hsbdMftrYn;
	private String hsbdFmlyBokMvYn;
	
	private String hsbdFmlyHadGdrCd;
	private String wifeFmlyHadGdrCd;
	private String fmlyHadGdrCd;
	private String mberRstrtGdrCd;
	
	public String getRsdtStusCd() {
		return rsdtStusCd;
	}
	public void setRsdtStusCd(String rsdtStusCd) {
		this.rsdtStusCd = rsdtStusCd;
	}
	public String getErsrCd() {
		return ersrCd;
	}
	public void setErsrCd(String ersrCd) {
		this.ersrCd = ersrCd;
	}
	public String getFstWtnOldCrdIsuceDd() {
		return fstWtnOldCrdIsuceDd;
	}
	public void setFstWtnOldCrdIsuceDd(String fstWtnOldCrdIsuceDd) {
		this.fstWtnOldCrdIsuceDd = fstWtnOldCrdIsuceDd;
	}
	public String getFstWtnOldCrdIsucePlceCd() {
		return fstWtnOldCrdIsucePlceCd;
	}
	public void setFstWtnOldCrdIsucePlceCd(String fstWtnOldCrdIsucePlceCd) {
		this.fstWtnOldCrdIsucePlceCd = fstWtnOldCrdIsucePlceCd;
	}
	public String getFstWtnOldCrdIsucePlceCdNm() {
		return fstWtnOldCrdIsucePlceCdNm;
	}
	public void setFstWtnOldCrdIsucePlceCdNm(String fstWtnOldCrdIsucePlceCdNm) {
		this.fstWtnOldCrdIsucePlceCdNm = fstWtnOldCrdIsucePlceCdNm;
	}
	public String getSecdWtnOldCrdIsuceDd() {
		return secdWtnOldCrdIsuceDd;
	}
	public void setSecdWtnOldCrdIsuceDd(String secdWtnOldCrdIsuceDd) {
		this.secdWtnOldCrdIsuceDd = secdWtnOldCrdIsuceDd;
	}
	public String getSecdWtnOldCrdIsucePlceCd() {
		return secdWtnOldCrdIsucePlceCd;
	}
	public void setSecdWtnOldCrdIsucePlceCd(String secdWtnOldCrdIsucePlceCd) {
		this.secdWtnOldCrdIsucePlceCd = secdWtnOldCrdIsucePlceCd;
	}
	public String getSecdWtnOldCrdIsucePlceCdNm() {
		return secdWtnOldCrdIsucePlceCdNm;
	}
	public void setSecdWtnOldCrdIsucePlceCdNm(String secdWtnOldCrdIsucePlceCdNm) {
		this.secdWtnOldCrdIsucePlceCdNm = secdWtnOldCrdIsucePlceCdNm;
	}
	public String getNltyCdNm() {
		return nltyCdNm;
	}
	public void setNltyCdNm(String nltyCdNm) {
		this.nltyCdNm = nltyCdNm;
	}
	public String getFstWtnOldCrdNo1() {
		return fstWtnOldCrdNo1;
	}
	public void setFstWtnOldCrdNo1(String fstWtnOldCrdNo1) {
		this.fstWtnOldCrdNo1 = fstWtnOldCrdNo1;
	}
	public String getFstWtnOldCrdNo2() {
		return fstWtnOldCrdNo2;
	}
	public void setFstWtnOldCrdNo2(String fstWtnOldCrdNo2) {
		this.fstWtnOldCrdNo2 = fstWtnOldCrdNo2;
	}
	public String getFstWtnOldCrdNo3() {
		return fstWtnOldCrdNo3;
	}
	public void setFstWtnOldCrdNo3(String fstWtnOldCrdNo3) {
		this.fstWtnOldCrdNo3 = fstWtnOldCrdNo3;
	}
	public String getFstWtnOldCrdNo4() {
		return fstWtnOldCrdNo4;
	}
	public void setFstWtnOldCrdNo4(String fstWtnOldCrdNo4) {
		this.fstWtnOldCrdNo4 = fstWtnOldCrdNo4;
	}
	public String getSecdWtnOldCrdNo1() {
		return secdWtnOldCrdNo1;
	}
	public void setSecdWtnOldCrdNo1(String secdWtnOldCrdNo1) {
		this.secdWtnOldCrdNo1 = secdWtnOldCrdNo1;
	}
	public String getSecdWtnOldCrdNo2() {
		return secdWtnOldCrdNo2;
	}
	public void setSecdWtnOldCrdNo2(String secdWtnOldCrdNo2) {
		this.secdWtnOldCrdNo2 = secdWtnOldCrdNo2;
	}
	public String getSecdWtnOldCrdNo3() {
		return secdWtnOldCrdNo3;
	}
	public void setSecdWtnOldCrdNo3(String secdWtnOldCrdNo3) {
		this.secdWtnOldCrdNo3 = secdWtnOldCrdNo3;
	}
	public String getSecdWtnOldCrdNo4() {
		return secdWtnOldCrdNo4;
	}
	public void setSecdWtnOldCrdNo4(String secdWtnOldCrdNo4) {
		this.secdWtnOldCrdNo4 = secdWtnOldCrdNo4;
	}
	public String getFthrFmlyBokNoDp() {
		return fthrFmlyBokNoDp;
	}
	public void setFthrFmlyBokNoDp(String fthrFmlyBokNoDp) {
		this.fthrFmlyBokNoDp = fthrFmlyBokNoDp;
	}
	public String getWifeFthrFmlyBokNoDp() {
		return wifeFthrFmlyBokNoDp;
	}
	public void setWifeFthrFmlyBokNoDp(String wifeFthrFmlyBokNoDp) {
		this.wifeFthrFmlyBokNoDp = wifeFthrFmlyBokNoDp;
	}
	public String getFthrRsdtSeqNo() {
		return fthrRsdtSeqNo;
	}
	public void setFthrRsdtSeqNo(String fthrRsdtSeqNo) {
		this.fthrRsdtSeqNo = fthrRsdtSeqNo;
	}
	public String getFthrFmlyBokNo() {
		return fthrFmlyBokNo;
	}
	public void setFthrFmlyBokNo(String fthrFmlyBokNo) {
		this.fthrFmlyBokNo = fthrFmlyBokNo;
	}
	public String getFthrSurnm() {
		return fthrSurnm;
	}
	public void setFthrSurnm(String fthrSurnm) {
		this.fthrSurnm = fthrSurnm;
	}
	public String getFthrEnSurnm() {
		return fthrEnSurnm;
	}
	public void setFthrEnSurnm(String fthrEnSurnm) {
		this.fthrEnSurnm = fthrEnSurnm;
	}
	public String getFthrPmntAdCd() {
		return fthrPmntAdCd;
	}
	public void setFthrPmntAdCd(String fthrPmntAdCd) {
		this.fthrPmntAdCd = fthrPmntAdCd;
	}
	public String getFthrPmntAdCdNm() {
		return fthrPmntAdCdNm;
	}
	public void setFthrPmntAdCdNm(String fthrPmntAdCdNm) {
		this.fthrPmntAdCdNm = fthrPmntAdCdNm;
	}
	public String getFthrPmntAdDtlCt() {
		return fthrPmntAdDtlCt;
	}
	public void setFthrPmntAdDtlCt(String fthrPmntAdDtlCt) {
		this.fthrPmntAdDtlCt = fthrPmntAdDtlCt;
	}
	public String getFthrCurtAdDiv() {
		return fthrCurtAdDiv;
	}
	public void setFthrCurtAdDiv(String fthrCurtAdDiv) {
		this.fthrCurtAdDiv = fthrCurtAdDiv;
	}
	public String getFthrCurtAdCd() {
		return fthrCurtAdCd;
	}
	public void setFthrCurtAdCd(String fthrCurtAdCd) {
		this.fthrCurtAdCd = fthrCurtAdCd;
	}
	public String getFthrCurtAdCdNm() {
		return fthrCurtAdCdNm;
	}
	public void setFthrCurtAdCdNm(String fthrCurtAdCdNm) {
		this.fthrCurtAdCdNm = fthrCurtAdCdNm;
	}
	public String getFthrCurtAdNatCd() {
		return fthrCurtAdNatCd;
	}
	public void setFthrCurtAdNatCd(String fthrCurtAdNatCd) {
		this.fthrCurtAdNatCd = fthrCurtAdNatCd;
	}
	public String getFthrCurtAdNatCdNm() {
		return fthrCurtAdNatCdNm;
	}
	public void setFthrCurtAdNatCdNm(String fthrCurtAdNatCdNm) {
		this.fthrCurtAdNatCdNm = fthrCurtAdNatCdNm;
	}
	public String getFthrCurtAdDtlCt() {
		return fthrCurtAdDtlCt;
	}
	public void setFthrCurtAdDtlCt(String fthrCurtAdDtlCt) {
		this.fthrCurtAdDtlCt = fthrCurtAdDtlCt;
	}
	public String getFthrSmrRsdcCd() {
		return fthrSmrRsdcCd;
	}
	public void setFthrSmrRsdcCd(String fthrSmrRsdcCd) {
		this.fthrSmrRsdcCd = fthrSmrRsdcCd;
	}
	public String getFthrSmrRsdcCdNm() {
		return fthrSmrRsdcCdNm;
	}
	public void setFthrSmrRsdcCdNm(String fthrSmrRsdcCdNm) {
		this.fthrSmrRsdcCdNm = fthrSmrRsdcCdNm;
	}
	public String getFthrWtrRsdcCd() {
		return fthrWtrRsdcCd;
	}
	public void setFthrWtrRsdcCd(String fthrWtrRsdcCd) {
		this.fthrWtrRsdcCd = fthrWtrRsdcCd;
	}
	public String getFthrWtrRsdcCdNm() {
		return fthrWtrRsdcCdNm;
	}
	public void setFthrWtrRsdcCdNm(String fthrWtrRsdcCdNm) {
		this.fthrWtrRsdcCdNm = fthrWtrRsdcCdNm;
	}
	public String getHsbdFthrRsdtSeqNo() {
		return hsbdFthrRsdtSeqNo;
	}
	public void setHsbdFthrRsdtSeqNo(String hsbdFthrRsdtSeqNo) {
		this.hsbdFthrRsdtSeqNo = hsbdFthrRsdtSeqNo;
	}
	public String getHsbdFthrCurtAdDiv() {
		return hsbdFthrCurtAdDiv;
	}
	public void setHsbdFthrCurtAdDiv(String hsbdFthrCurtAdDiv) {
		this.hsbdFthrCurtAdDiv = hsbdFthrCurtAdDiv;
	}
	public String getHsbdFthrCurtAdCd() {
		return hsbdFthrCurtAdCd;
	}
	public void setHsbdFthrCurtAdCd(String hsbdFthrCurtAdCd) {
		this.hsbdFthrCurtAdCd = hsbdFthrCurtAdCd;
	}
	public String getHsbdFthrCurtAdCdNm() {
		return hsbdFthrCurtAdCdNm;
	}
	public void setHsbdFthrCurtAdCdNm(String hsbdFthrCurtAdCdNm) {
		this.hsbdFthrCurtAdCdNm = hsbdFthrCurtAdCdNm;
	}
	public String getHsbdFthrCurtAdNatCd() {
		return hsbdFthrCurtAdNatCd;
	}
	public void setHsbdFthrCurtAdNatCd(String hsbdFthrCurtAdNatCd) {
		this.hsbdFthrCurtAdNatCd = hsbdFthrCurtAdNatCd;
	}
	public String getHsbdFthrCurtAdNatCdNm() {
		return hsbdFthrCurtAdNatCdNm;
	}
	public void setHsbdFthrCurtAdNatCdNm(String hsbdFthrCurtAdNatCdNm) {
		this.hsbdFthrCurtAdNatCdNm = hsbdFthrCurtAdNatCdNm;
	}
	public String getHsbdFthrCurtAdDtlCt() {
		return hsbdFthrCurtAdDtlCt;
	}
	public void setHsbdFthrCurtAdDtlCt(String hsbdFthrCurtAdDtlCt) {
		this.hsbdFthrCurtAdDtlCt = hsbdFthrCurtAdDtlCt;
	}
	public String getHsbdFthrSmrRsdcCd() {
		return hsbdFthrSmrRsdcCd;
	}
	public void setHsbdFthrSmrRsdcCd(String hsbdFthrSmrRsdcCd) {
		this.hsbdFthrSmrRsdcCd = hsbdFthrSmrRsdcCd;
	}
	public String getHsbdFthrSmrRsdcCdNm() {
		return hsbdFthrSmrRsdcCdNm;
	}
	public void setHsbdFthrSmrRsdcCdNm(String hsbdFthrSmrRsdcCdNm) {
		this.hsbdFthrSmrRsdcCdNm = hsbdFthrSmrRsdcCdNm;
	}
	public String getHsbdFthrWtrRsdcCd() {
		return hsbdFthrWtrRsdcCd;
	}
	public void setHsbdFthrWtrRsdcCd(String hsbdFthrWtrRsdcCd) {
		this.hsbdFthrWtrRsdcCd = hsbdFthrWtrRsdcCd;
	}
	public String getHsbdFthrWtrRsdcCdNm() {
		return hsbdFthrWtrRsdcCdNm;
	}
	public void setHsbdFthrWtrRsdcCdNm(String hsbdFthrWtrRsdcCdNm) {
		this.hsbdFthrWtrRsdcCdNm = hsbdFthrWtrRsdcCdNm;
	}
	public String getWifeFthrRsdtSeqNo() {
		return wifeFthrRsdtSeqNo;
	}
	public void setWifeFthrRsdtSeqNo(String wifeFthrRsdtSeqNo) {
		this.wifeFthrRsdtSeqNo = wifeFthrRsdtSeqNo;
	}
	public String getWifeFthrFmlyBokNo() {
		return wifeFthrFmlyBokNo;
	}
	public void setWifeFthrFmlyBokNo(String wifeFthrFmlyBokNo) {
		this.wifeFthrFmlyBokNo = wifeFthrFmlyBokNo;
	}
	public String getWifeFthrSurnm() {
		return wifeFthrSurnm;
	}
	public void setWifeFthrSurnm(String wifeFthrSurnm) {
		this.wifeFthrSurnm = wifeFthrSurnm;
	}
	public String getWifeFthrEnSurnm() {
		return wifeFthrEnSurnm;
	}
	public void setWifeFthrEnSurnm(String wifeFthrEnSurnm) {
		this.wifeFthrEnSurnm = wifeFthrEnSurnm;
	}
	public String getWifeFthrPmntAdCd() {
		return wifeFthrPmntAdCd;
	}
	public void setWifeFthrPmntAdCd(String wifeFthrPmntAdCd) {
		this.wifeFthrPmntAdCd = wifeFthrPmntAdCd;
	}
	public String getWifeFthrPmntAdCdNm() {
		return wifeFthrPmntAdCdNm;
	}
	public void setWifeFthrPmntAdCdNm(String wifeFthrPmntAdCdNm) {
		this.wifeFthrPmntAdCdNm = wifeFthrPmntAdCdNm;
	}
	public String getWifeFthrPmntAdDtlCt() {
		return wifeFthrPmntAdDtlCt;
	}
	public void setWifeFthrPmntAdDtlCt(String wifeFthrPmntAdDtlCt) {
		this.wifeFthrPmntAdDtlCt = wifeFthrPmntAdDtlCt;
	}
	public String getWifeFthrCurtAdDiv() {
		return wifeFthrCurtAdDiv;
	}
	public void setWifeFthrCurtAdDiv(String wifeFthrCurtAdDiv) {
		this.wifeFthrCurtAdDiv = wifeFthrCurtAdDiv;
	}
	public String getWifeFthrCurtAdCd() {
		return wifeFthrCurtAdCd;
	}
	public void setWifeFthrCurtAdCd(String wifeFthrCurtAdCd) {
		this.wifeFthrCurtAdCd = wifeFthrCurtAdCd;
	}
	public String getWifeFthrCurtAdCdNm() {
		return wifeFthrCurtAdCdNm;
	}
	public void setWifeFthrCurtAdCdNm(String wifeFthrCurtAdCdNm) {
		this.wifeFthrCurtAdCdNm = wifeFthrCurtAdCdNm;
	}
	public String getWifeFthrCurtAdNatCd() {
		return wifeFthrCurtAdNatCd;
	}
	public void setWifeFthrCurtAdNatCd(String wifeFthrCurtAdNatCd) {
		this.wifeFthrCurtAdNatCd = wifeFthrCurtAdNatCd;
	}
	public String getWifeFthrCurtAdNatCdNm() {
		return wifeFthrCurtAdNatCdNm;
	}
	public void setWifeFthrCurtAdNatCdNm(String wifeFthrCurtAdNatCdNm) {
		this.wifeFthrCurtAdNatCdNm = wifeFthrCurtAdNatCdNm;
	}
	public String getWifeFthrCurtAdDtlCt() {
		return wifeFthrCurtAdDtlCt;
	}
	public void setWifeFthrCurtAdDtlCt(String wifeFthrCurtAdDtlCt) {
		this.wifeFthrCurtAdDtlCt = wifeFthrCurtAdDtlCt;
	}
	public String getWifeFthrSmrRsdcCd() {
		return wifeFthrSmrRsdcCd;
	}
	public void setWifeFthrSmrRsdcCd(String wifeFthrSmrRsdcCd) {
		this.wifeFthrSmrRsdcCd = wifeFthrSmrRsdcCd;
	}
	public String getWifeFthrSmrRsdcCdNm() {
		return wifeFthrSmrRsdcCdNm;
	}
	public void setWifeFthrSmrRsdcCdNm(String wifeFthrSmrRsdcCdNm) {
		this.wifeFthrSmrRsdcCdNm = wifeFthrSmrRsdcCdNm;
	}
	public String getWifeFthrWtrRsdcCd() {
		return wifeFthrWtrRsdcCd;
	}
	public void setWifeFthrWtrRsdcCd(String wifeFthrWtrRsdcCd) {
		this.wifeFthrWtrRsdcCd = wifeFthrWtrRsdcCd;
	}
	public String getWifeFthrWtrRsdcCdNm() {
		return wifeFthrWtrRsdcCdNm;
	}
	public void setWifeFthrWtrRsdcCdNm(String wifeFthrWtrRsdcCdNm) {
		this.wifeFthrWtrRsdcCdNm = wifeFthrWtrRsdcCdNm;
	}
	public String getWifePmntAdCd() {
		return wifePmntAdCd;
	}
	public void setWifePmntAdCd(String wifePmntAdCd) {
		this.wifePmntAdCd = wifePmntAdCd;
	}
	public String getCanHsbdAdChangYn() {
		return canHsbdAdChangYn;
	}
	public void setCanHsbdAdChangYn(String canHsbdAdChangYn) {
		this.canHsbdAdChangYn = canHsbdAdChangYn;
	}
	public String getHsbdAdChangeMsg() {
		return hsbdAdChangeMsg;
	}
	public void setHsbdAdChangeMsg(String hsbdAdChangeMsg) {
		this.hsbdAdChangeMsg = hsbdAdChangeMsg;
	}
	public String getIsHsbdExp() {
		return isHsbdExp;
	}
	public void setIsHsbdExp(String isHsbdExp) {
		this.isHsbdExp = isHsbdExp;
	}
	public String getWifeSgnt() {
		return wifeSgnt;
	}
	public void setWifeSgnt(String wifeSgnt) {
		this.wifeSgnt = wifeSgnt;
	}
	public String getHsbdSgnt() {
		return hsbdSgnt;
	}
	public void setHsbdSgnt(String hsbdSgnt) {
		this.hsbdSgnt = hsbdSgnt;
	}
	public String getKochiAdCd() {
		return kochiAdCd;
	}
	public void setKochiAdCd(String kochiAdCd) {
		this.kochiAdCd = kochiAdCd;
	}
	public String getAfHsbdSmrRsdcCdNm() {
		return afHsbdSmrRsdcCdNm;
	}
	public void setAfHsbdSmrRsdcCdNm(String afHsbdSmrRsdcCdNm) {
		this.afHsbdSmrRsdcCdNm = afHsbdSmrRsdcCdNm;
	}
	public String getAfHsbdWtrRsdcCdNm() {
		return afHsbdWtrRsdcCdNm;
	}
	public void setAfHsbdWtrRsdcCdNm(String afHsbdWtrRsdcCdNm) {
		this.afHsbdWtrRsdcCdNm = afHsbdWtrRsdcCdNm;
	}
	public String getAfWifeSmrRsdcCdNm() {
		return afWifeSmrRsdcCdNm;
	}
	public void setAfWifeSmrRsdcCdNm(String afWifeSmrRsdcCdNm) {
		this.afWifeSmrRsdcCdNm = afWifeSmrRsdcCdNm;
	}
	public String getAfWifeWtrRsdcCdNm() {
		return afWifeWtrRsdcCdNm;
	}
	public void setAfWifeWtrRsdcCdNm(String afWifeWtrRsdcCdNm) {
		this.afWifeWtrRsdcCdNm = afWifeWtrRsdcCdNm;
	}
	public String getAfHsbdCurtAdDtlCtD() {
		return afHsbdCurtAdDtlCtD;
	}
	public void setAfHsbdCurtAdDtlCtD(String afHsbdCurtAdDtlCtD) {
		this.afHsbdCurtAdDtlCtD = afHsbdCurtAdDtlCtD;
	}
	public String getAfHsbdCurtAdDtlCtF() {
		return afHsbdCurtAdDtlCtF;
	}
	public void setAfHsbdCurtAdDtlCtF(String afHsbdCurtAdDtlCtF) {
		this.afHsbdCurtAdDtlCtF = afHsbdCurtAdDtlCtF;
	}
	public String getAfWifeCurtAdDtlCtD() {
		return afWifeCurtAdDtlCtD;
	}
	public void setAfWifeCurtAdDtlCtD(String afWifeCurtAdDtlCtD) {
		this.afWifeCurtAdDtlCtD = afWifeCurtAdDtlCtD;
	}
	public String getAfWifeCurtAdDtlCtF() {
		return afWifeCurtAdDtlCtF;
	}
	public void setAfWifeCurtAdDtlCtF(String afWifeCurtAdDtlCtF) {
		this.afWifeCurtAdDtlCtF = afWifeCurtAdDtlCtF;
	}
	public String getCntTelNo2() {
		return cntTelNo2;
	}
	public void setCntTelNo2(String cntTelNo2) {
		this.cntTelNo2 = cntTelNo2;
	}
	public String getAfHsbdCurtAdDiv() {
		return afHsbdCurtAdDiv;
	}
	public void setAfHsbdCurtAdDiv(String afHsbdCurtAdDiv) {
		this.afHsbdCurtAdDiv = afHsbdCurtAdDiv;
	}
	public String getAfHsbdCurtAdNatCd() {
		return afHsbdCurtAdNatCd;
	}
	public void setAfHsbdCurtAdNatCd(String afHsbdCurtAdNatCd) {
		this.afHsbdCurtAdNatCd = afHsbdCurtAdNatCd;
	}
	public String getAfHsbdSmrRsdcCd() {
		return afHsbdSmrRsdcCd;
	}
	public void setAfHsbdSmrRsdcCd(String afHsbdSmrRsdcCd) {
		this.afHsbdSmrRsdcCd = afHsbdSmrRsdcCd;
	}
	public String getAfHsbdWtrRsdcCd() {
		return afHsbdWtrRsdcCd;
	}
	public void setAfHsbdWtrRsdcCd(String afHsbdWtrRsdcCd) {
		this.afHsbdWtrRsdcCd = afHsbdWtrRsdcCd;
	}
	public String getAfWifeCurtAdDiv() {
		return afWifeCurtAdDiv;
	}
	public void setAfWifeCurtAdDiv(String afWifeCurtAdDiv) {
		this.afWifeCurtAdDiv = afWifeCurtAdDiv;
	}
	public String getAfWifeCurtAdNatCd() {
		return afWifeCurtAdNatCd;
	}
	public void setAfWifeCurtAdNatCd(String afWifeCurtAdNatCd) {
		this.afWifeCurtAdNatCd = afWifeCurtAdNatCd;
	}
	public String getAfWifeSmrRsdcCd() {
		return afWifeSmrRsdcCd;
	}
	public void setAfWifeSmrRsdcCd(String afWifeSmrRsdcCd) {
		this.afWifeSmrRsdcCd = afWifeSmrRsdcCd;
	}
	public String getAfWifeWtrRsdcCd() {
		return afWifeWtrRsdcCd;
	}
	public void setAfWifeWtrRsdcCd(String afWifeWtrRsdcCd) {
		this.afWifeWtrRsdcCd = afWifeWtrRsdcCd;
	}
	public String getEmlAd() {
		return emlAd;
	}
	public void setEmlAd(String emlAd) {
		this.emlAd = emlAd;
	}

	public String getCrdIsucePlceCd() {
		return crdIsucePlceCd;
	}
	public void setCrdIsucePlceCd(String crdIsucePlceCd) {
		this.crdIsucePlceCd = crdIsucePlceCd;
	}
	public String getFmlyBokSeqNo() {
		return fmlyBokSeqNo;
	}
	public void setFmlyBokSeqNo(String fmlyBokSeqNo) {
		this.fmlyBokSeqNo = fmlyBokSeqNo;
	}
	public String getFmlyMberNo() {
		return fmlyMberNo;
	}
	public void setFmlyMberNo(String fmlyMberNo) {
		this.fmlyMberNo = fmlyMberNo;
	}
	public String getMrrgCd() {
		return mrrgCd;
	}
	public void setMrrgCd(String mrrgCd) {
		this.mrrgCd = mrrgCd;
	}
	public String getDvrcKndCdNm() {
		return dvrcKndCdNm;
	}
	public void setDvrcKndCdNm(String dvrcKndCdNm) {
		this.dvrcKndCdNm = dvrcKndCdNm;
	}
	public String getAfWifeFmlyBokNoDp() {
		return afWifeFmlyBokNoDp;
	}
	public void setAfWifeFmlyBokNoDp(String afWifeFmlyBokNoDp) {
		this.afWifeFmlyBokNoDp = afWifeFmlyBokNoDp;
	}

	public String getCrdDlvrDd() {
		return crdDlvrDd;
	}
	public void setCrdDlvrDd(String crdDlvrDd) {
		this.crdDlvrDd = crdDlvrDd;
	}
	public String getRgstOrgnzCdNm() {
		return rgstOrgnzCdNm;
	}
	public void setRgstOrgnzCdNm(String rgstOrgnzCdNm) {
		this.rgstOrgnzCdNm = rgstOrgnzCdNm;
	}
	public String getDvrcAdCdNm() {
		return dvrcAdCdNm;
	}
	public void setDvrcAdCdNm(String dvrcAdCdNm) {
		this.dvrcAdCdNm = dvrcAdCdNm;
	}
	public String getAfWifePmntAdCdNm() {
		return afWifePmntAdCdNm;
	}
	public void setAfWifePmntAdCdNm(String afWifePmntAdCdNm) {
		this.afWifePmntAdCdNm = afWifePmntAdCdNm;
	}
	public String getAfHsbdCurtAdCdNm() {
		return afHsbdCurtAdCdNm;
	}
	public void setAfHsbdCurtAdCdNm(String afHsbdCurtAdCdNm) {
		this.afHsbdCurtAdCdNm = afHsbdCurtAdCdNm;
	}
	public String getAfWifeCurtAdCdNm() {
		return afWifeCurtAdCdNm;
	}
	public void setAfWifeCurtAdCdNm(String afWifeCurtAdCdNm) {
		this.afWifeCurtAdCdNm = afWifeCurtAdCdNm;
	}
	public String getHsbdRgstCn() {
		return hsbdRgstCn;
	}
	public void setHsbdRgstCn(String hsbdRgstCn) {
		this.hsbdRgstCn = hsbdRgstCn;
	}
	public String getWifeRgstCn() {
		return wifeRgstCn;
	}
	public void setWifeRgstCn(String wifeRgstCn) {
		this.wifeRgstCn = wifeRgstCn;
	}
	public String getHsbdRgstYn() {
		return hsbdRgstYn;
	}
	public void setHsbdRgstYn(String hsbdRgstYn) {
		this.hsbdRgstYn = hsbdRgstYn;
	}
	public String getWifeRgstYn() {
		return wifeRgstYn;
	}
	public void setWifeRgstYn(String wifeRgstYn) {
		this.wifeRgstYn = wifeRgstYn;
	}
	public String getWifePmntAdChngYn() {
		return wifePmntAdChngYn;
	}
	public void setWifePmntAdChngYn(String wifePmntAdChngYn) {
		this.wifePmntAdChngYn = wifePmntAdChngYn;
	}
	public String getAfWifePmntAdCd() {
		return afWifePmntAdCd;
	}
	public void setAfWifePmntAdCd(String afWifePmntAdCd) {
		this.afWifePmntAdCd = afWifePmntAdCd;
	}
	public String getAfWifePmntAdDtlCt() {
		return afWifePmntAdDtlCt;
	}
	public void setAfWifePmntAdDtlCt(String afWifePmntAdDtlCt) {
		this.afWifePmntAdDtlCt = afWifePmntAdDtlCt;
	}
	public String getMrrgDdJ() {
		return mrrgDdJ;
	}
	public void setMrrgDdJ(String mrrgDdJ) {
		this.mrrgDdJ = mrrgDdJ;
	}
	public String getMrrgDdG() {
		return mrrgDdG;
	}
	public void setMrrgDdG(String mrrgDdG) {
		this.mrrgDdG = mrrgDdG;
	}
	public String getWifeNm() {
		return wifeNm;
	}
	public void setWifeNm(String wifeNm) {
		this.wifeNm = wifeNm;
	}
	public String getHsbdNm() {
		return hsbdNm;
	}
	public void setHsbdNm(String hsbdNm) {
		this.hsbdNm = hsbdNm;
	}
	public String getCalTye() {
		return calTye;
	}
	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	public String getWifeCcltDd() {
		return wifeCcltDd;
	}
	public void setWifeCcltDd(String wifeCcltDd) {
		this.wifeCcltDd = wifeCcltDd;
	}
	public String getHsbdCcltDd() {
		return hsbdCcltDd;
	}
	public void setHsbdCcltDd(String hsbdCcltDd) {
		this.hsbdCcltDd = hsbdCcltDd;
	}
	public String getHsbdFmlyBokNo() {
		return hsbdFmlyBokNo;
	}
	public void setHsbdFmlyBokNo(String hsbdFmlyBokNo) {
		this.hsbdFmlyBokNo = hsbdFmlyBokNo;
	}

	public String getHsbdFmlyHadNm() {
		return hsbdFmlyHadNm;
	}
	public void setHsbdFmlyHadNm(String hsbdFmlyHadNm) {
		this.hsbdFmlyHadNm = hsbdFmlyHadNm;
	}
	public String getHsbdFthrNm() {
		return hsbdFthrNm;
	}
	public void setHsbdFthrNm(String hsbdFthrNm) {
		this.hsbdFthrNm = hsbdFthrNm;
	}
	public String getWifeFthrNm() {
		return wifeFthrNm;
	}
	public void setWifeFthrNm(String wifeFthrNm) {
		this.wifeFthrNm = wifeFthrNm;
	}
	public String getHsbdEnSurnm() {
		return hsbdEnSurnm;
	}
	public void setHsbdEnSurnm(String hsbdEnSurnm) {
		this.hsbdEnSurnm = hsbdEnSurnm;
	}
	public String getHsbdEnGivNm() {
		return hsbdEnGivNm;
	}
	public void setHsbdEnGivNm(String hsbdEnGivNm) {
		this.hsbdEnGivNm = hsbdEnGivNm;
	}
	public String getGivNm() {
		return givNm;
	}
	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}
	public String getSurnm() {
		return surnm;
	}
	public void setSurnm(String surnm) {
		this.surnm = surnm;
	}
	public String getEnSurnm() {
		return enSurnm;
	}
	public void setEnSurnm(String enSurnm) {
		this.enSurnm = enSurnm;
	}
	public String getEnGivNm() {
		return enGivNm;
	}
	public void setEnGivNm(String enGivNm) {
		this.enGivNm = enGivNm;
	}
	public String getFthrNm() {
		return fthrNm;
	}
	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}
	public String getHadNm() {
		return hadNm;
	}
	public void setHadNm(String hadNm) {
		this.hadNm = hadNm;
	}
	public String getFmlyBokNo() {
		return fmlyBokNo;
	}
	public void setFmlyBokNo(String fmlyBokNo) {
		this.fmlyBokNo = fmlyBokNo;
	}
	public String getFrngrYn() {
		return frngrYn;
	}
	public void setFrngrYn(String frngrYn) {
		this.frngrYn = frngrYn;
	}
	public String getAppDd() {
		return appDd;
	}
	public void setAppDd(String appDd) {
		this.appDd = appDd;
	}
	public String getCcltDd() {
		return ccltDd;
	}
	public void setCcltDd(String ccltDd) {
		this.ccltDd = ccltDd;
	}
	public String getHsbdNltyCdNm() {
		return hsbdNltyCdNm;
	}
	public void setHsbdNltyCdNm(String hsbdNltyCdNm) {
		this.hsbdNltyCdNm = hsbdNltyCdNm;
	}
	public String getWifeNltyCdNm() {
		return wifeNltyCdNm;
	}
	public void setWifeNltyCdNm(String wifeNltyCdNm) {
		this.wifeNltyCdNm = wifeNltyCdNm;
	}
	public String getIsExp() {
		return isExp;
	}
	public void setIsExp(String isExp) {
		this.isExp = isExp;
	}
	public String getHsbdRsdtNo() {
		return hsbdRsdtNo;
	}
	public void setHsbdRsdtNo(String hsbdRsdtNo) {
		this.hsbdRsdtNo = hsbdRsdtNo;
	}
	public String getHsbdRsdtNoDp() {
		return hsbdRsdtNoDp;
	}
	public void setHsbdRsdtNoDp(String hsbdRsdtNoDp) {
		this.hsbdRsdtNoDp = hsbdRsdtNoDp;
	}
	public String getWifeRsdtNo() {
		return wifeRsdtNo;
	}
	public void setWifeRsdtNo(String wifeRsdtNo) {
		this.wifeRsdtNo = wifeRsdtNo;
	}
	public String getWifeRsdtNoDp() {
		return wifeRsdtNoDp;
	}
	public void setWifeRsdtNoDp(String wifeRsdtNoDp) {
		this.wifeRsdtNoDp = wifeRsdtNoDp;
	}
	public String getCrdReisuceDmBfExpr() {
		return crdReisuceDmBfExpr;
	}
	public void setCrdReisuceDmBfExpr(String crdReisuceDmBfExpr) {
		this.crdReisuceDmBfExpr = crdReisuceDmBfExpr;
	}
	public String getNameChangeMsg() {
		return nameChangeMsg;
	}
	public void setNameChangeMsg(String nameChangeMsg) {
		this.nameChangeMsg = nameChangeMsg;
	}
	public String getCanNameChangeYn() {
		return canNameChangeYn;
	}
	public void setCanNameChangeYn(String canNameChangeYn) {
		this.canNameChangeYn = canNameChangeYn;
	}
	public String getMrrgDd() {
		return mrrgDd;
	}
	public void setMrrgDd(String mrrgDd) {
		this.mrrgDd = mrrgDd;
	}
	public String getErrMsg() {
		return errMsg;
	}
	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}
	public String getMrrgCn() {
		return mrrgCn;
	}
	public void setMrrgCn(String mrrgCn) {
		this.mrrgCn = mrrgCn;
	}
	public String getDvrcSeqNo() {
		return dvrcSeqNo;
	}
	public void setDvrcSeqNo(String dvrcSeqNo) {
		this.dvrcSeqNo = dvrcSeqNo;
	}
	public String getDvrcDd() {
		return dvrcDd;
	}
	public void setDvrcDd(String dvrcDd) {
		this.dvrcDd = dvrcDd;
	}
	public String getDvrcKndCd() {
		return dvrcKndCd;
	}
	public void setDvrcKndCd(String dvrcKndCd) {
		this.dvrcKndCd = dvrcKndCd;
	}
	public String getHsbdRsdtSeqNo() {
		return hsbdRsdtSeqNo;
	}
	public void setHsbdRsdtSeqNo(String hsbdRsdtSeqNo) {
		this.hsbdRsdtSeqNo = hsbdRsdtSeqNo;
	}
	public String getHsbdGivNm() {
		return hsbdGivNm;
	}
	public void setHsbdGivNm(String hsbdGivNm) {
		this.hsbdGivNm = hsbdGivNm;
	}
	public String getHsbdSurnm() {
		return hsbdSurnm;
	}
	public void setHsbdSurnm(String hsbdSurnm) {
		this.hsbdSurnm = hsbdSurnm;
	}
	public String getHsbdFrngrYn() {
		return hsbdFrngrYn;
	}
	public void setHsbdFrngrYn(String hsbdFrngrYn) {
		this.hsbdFrngrYn = hsbdFrngrYn;
	}
	public String getHsbdFrngrRgstNo() {
		return hsbdFrngrRgstNo;
	}
	public void setHsbdFrngrRgstNo(String hsbdFrngrRgstNo) {
		this.hsbdFrngrRgstNo = hsbdFrngrRgstNo;
	}
	public String getHsbdNltyCd() {
		return hsbdNltyCd;
	}
	public void setHsbdNltyCd(String hsbdNltyCd) {
		this.hsbdNltyCd = hsbdNltyCd;
	}
	public String getHsbdCurtAdChngYn() {
		return hsbdCurtAdChngYn;
	}
	public void setHsbdCurtAdChngYn(String hsbdCurtAdChngYn) {
		this.hsbdCurtAdChngYn = hsbdCurtAdChngYn;
	}
	public String getAfHsbdCurtAdCd() {
		return afHsbdCurtAdCd;
	}
	public void setAfHsbdCurtAdCd(String afHsbdCurtAdCd) {
		this.afHsbdCurtAdCd = afHsbdCurtAdCd;
	}
	public String getAfHsbdCurtAdDtlCt() {
		return afHsbdCurtAdDtlCt;
	}
	public void setAfHsbdCurtAdDtlCt(String afHsbdCurtAdDtlCt) {
		this.afHsbdCurtAdDtlCt = afHsbdCurtAdDtlCt;
	}
	public String getWifeRsdtSeqNo() {
		return wifeRsdtSeqNo;
	}
	public void setWifeRsdtSeqNo(String wifeRsdtSeqNo) {
		this.wifeRsdtSeqNo = wifeRsdtSeqNo;
	}
	public String getWifeGivNm() {
		return wifeGivNm;
	}
	public void setWifeGivNm(String wifeGivNm) {
		this.wifeGivNm = wifeGivNm;
	}
	public String getWifeSurnm() {
		return wifeSurnm;
	}
	public void setWifeSurnm(String wifeSurnm) {
		this.wifeSurnm = wifeSurnm;
	}
	public String getWifeEnGivNm() {
		return wifeEnGivNm;
	}
	public void setWifeEnGivNm(String wifeEnGivNm) {
		this.wifeEnGivNm = wifeEnGivNm;
	}
	public String getWifeEnSurnm() {
		return wifeEnSurnm;
	}
	public void setWifeEnSurnm(String wifeEnSurnm) {
		this.wifeEnSurnm = wifeEnSurnm;
	}
	public String getWifeFrngrYn() {
		return wifeFrngrYn;
	}
	public void setWifeFrngrYn(String wifeFrngrYn) {
		this.wifeFrngrYn = wifeFrngrYn;
	}
	public String getWifeFrngrRgstNo() {
		return wifeFrngrRgstNo;
	}
	public void setWifeFrngrRgstNo(String wifeFrngrRgstNo) {
		this.wifeFrngrRgstNo = wifeFrngrRgstNo;
	}
	public String getWifeNltyCd() {
		return wifeNltyCd;
	}
	public void setWifeNltyCd(String wifeNltyCd) {
		this.wifeNltyCd = wifeNltyCd;
	}
	public String getWifeNmChngYn() {
		return wifeNmChngYn;
	}
	public void setWifeNmChngYn(String wifeNmChngYn) {
		this.wifeNmChngYn = wifeNmChngYn;
	}
	public String getAfWifeSurnm() {
		return afWifeSurnm;
	}
	public void setAfWifeSurnm(String afWifeSurnm) {
		this.afWifeSurnm = afWifeSurnm;
	}
	public String getAfWifeEnSurnm() {
		return afWifeEnSurnm;
	}
	public void setAfWifeEnSurnm(String afWifeEnSurnm) {
		this.afWifeEnSurnm = afWifeEnSurnm;
	}

	public String getWifeCurtAdChngYn() {
		return wifeCurtAdChngYn;
	}
	public void setWifeCurtAdChngYn(String wifeCurtAdChngYn) {
		this.wifeCurtAdChngYn = wifeCurtAdChngYn;
	}
	public String getAfWifeCurtAdCd() {
		return afWifeCurtAdCd;
	}
	public void setAfWifeCurtAdCd(String afWifeCurtAdCd) {
		this.afWifeCurtAdCd = afWifeCurtAdCd;
	}
	public String getAfWifeCurtAdDtlCt() {
		return afWifeCurtAdDtlCt;
	}
	public void setAfWifeCurtAdDtlCt(String afWifeCurtAdDtlCt) {
		this.afWifeCurtAdDtlCt = afWifeCurtAdDtlCt;
	}
	public String getWifeFmlyBokMvYn() {
		return wifeFmlyBokMvYn;
	}
	public void setWifeFmlyBokMvYn(String wifeFmlyBokMvYn) {
		this.wifeFmlyBokMvYn = wifeFmlyBokMvYn;
	}
	public String getWifeFmlyBokNo() {
		return wifeFmlyBokNo;
	}
	public void setWifeFmlyBokNo(String wifeFmlyBokNo) {
		this.wifeFmlyBokNo = wifeFmlyBokNo;
	}
	public String getAfWifeFmlyBokNo() {
		return afWifeFmlyBokNo;
	}
	public void setAfWifeFmlyBokNo(String afWifeFmlyBokNo) {
		this.afWifeFmlyBokNo = afWifeFmlyBokNo;
	}
	public String getFstWtnNm() {
		return fstWtnNm;
	}
	public void setFstWtnNm(String fstWtnNm) {
		this.fstWtnNm = fstWtnNm;
	}
	public String getFstWtnRsdtNo() {
		return fstWtnRsdtNo;
	}
	public void setFstWtnRsdtNo(String fstWtnRsdtNo) {
		this.fstWtnRsdtNo = fstWtnRsdtNo;
	}
	public String getSecdWtnNm() {
		return secdWtnNm;
	}
	public void setSecdWtnNm(String secdWtnNm) {
		this.secdWtnNm = secdWtnNm;
	}
	public String getSecdWtnRsdtNo() {
		return secdWtnRsdtNo;
	}
	public void setSecdWtnRsdtNo(String secdWtnRsdtNo) {
		this.secdWtnRsdtNo = secdWtnRsdtNo;
	}
	public String getDvrcAdCd() {
		return dvrcAdCd;
	}
	public void setDvrcAdCd(String dvrcAdCd) {
		this.dvrcAdCd = dvrcAdCd;
	}
	public String getDvrcAdDtlCt() {
		return dvrcAdDtlCt;
	}
	public void setDvrcAdDtlCt(String dvrcAdDtlCt) {
		this.dvrcAdDtlCt = dvrcAdDtlCt;
	}
	public String getCertNo() {
		return certNo;
	}
	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}
	public String getPbctOfic() {
		return pbctOfic;
	}
	public void setPbctOfic(String pbctOfic) {
		this.pbctOfic = pbctOfic;
	}
	public String getRmk() {
		return rmk;
	}
	public void setRmk(String rmk) {
		this.rmk = rmk;
	}
	public String getMrrgSeqNo() {
		return mrrgSeqNo;
	}
	public void setMrrgSeqNo(String mrrgSeqNo) {
		this.mrrgSeqNo = mrrgSeqNo;
	}
	public String getCrdReisuceDueDd() {
		return crdReisuceDueDd;
	}
	public void setCrdReisuceDueDd(String crdReisuceDueDd) {
		this.crdReisuceDueDd = crdReisuceDueDd;
	}
	public String getTamLedrCfmYn() {
		return tamLedrCfmYn;
	}
	public void setTamLedrCfmYn(String tamLedrCfmYn) {
		this.tamLedrCfmYn = tamLedrCfmYn;
	}
	public String getCfmTamLedrId() {
		return cfmTamLedrId;
	}
	public void setCfmTamLedrId(String cfmTamLedrId) {
		this.cfmTamLedrId = cfmTamLedrId;
	}
	public String getRsdtCfmYn() {
		return rsdtCfmYn;
	}
	public void setRsdtCfmYn(String rsdtCfmYn) {
		this.rsdtCfmYn = rsdtCfmYn;
	}
	public String getCntTelNo() {
		return cntTelNo;
	}
	public void setCntTelNo(String cntTelNo) {
		this.cntTelNo = cntTelNo;
	}
	public String getDltYn() {
		return dltYn;
	}
	public void setDltYn(String dltYn) {
		this.dltYn = dltYn;
	}
	public String getFstRgstUserId() {
		return fstRgstUserId;
	}
	public void setFstRgstUserId(String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}
	public String getFstRgstDt() {
		return fstRgstDt;
	}
	public void setFstRgstDt(String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}
	public String getLstUdtUserId() {
		return lstUdtUserId;
	}
	public void setLstUdtUserId(String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}
	public String getLstUdtDt() {
		return lstUdtDt;
	}
	public void setLstUdtDt(String lstUdtDt) {
		this.lstUdtDt = lstUdtDt;
	}
	public String getCn() {
		return cn;
	}
	public void setCn(String cn) {
		this.cn = cn;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getRgstOrgnzCd() {
		return rgstOrgnzCd;
	}
	public void setRgstOrgnzCd(String rgstOrgnzCd) {
		this.rgstOrgnzCd = rgstOrgnzCd;
	}
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getGdrCd() {
		return gdrCd;
	}
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	public String getSpusRsdtSeqNo() {
		return spusRsdtSeqNo;
	}
	public void setSpusRsdtSeqNo(String spusRsdtSeqNo) {
		this.spusRsdtSeqNo = spusRsdtSeqNo;
	}
	public String getSpusNm() {
		return spusNm;
	}
	public void setSpusNm(String spusNm) {
		this.spusNm = spusNm;
	}
	public String getFmlyBokNoDp() {
		return fmlyBokNoDp;
	}
	public void setFmlyBokNoDp(String fmlyBokNoDp) {
		this.fmlyBokNoDp = fmlyBokNoDp;
	}
	public String getEnNm() {
		return enNm;
	}
	public void setEnNm(String enNm) {
		this.enNm = enNm;
	}
	public String getNatLangCdNm() {
		return natLangCdNm;
	}
	public void setNatLangCdNm(String natLangCdNm) {
		this.natLangCdNm = natLangCdNm;
	}
	public String getFrgnLangCdNm() {
		return frgnLangCdNm;
	}
	public void setFrgnLangCdNm(String frgnLangCdNm) {
		this.frgnLangCdNm = frgnLangCdNm;
	}
	public String getMthrNm() {
		return mthrNm;
	}
	public void setMthrNm(String mthrNm) {
		this.mthrNm = mthrNm;
	}
	public String getSmrRsdcCdNm() {
		return smrRsdcCdNm;
	}
	public void setSmrRsdcCdNm(String smrRsdcCdNm) {
		this.smrRsdcCdNm = smrRsdcCdNm;
	}
	public String getGfthrNm() {
		return gfthrNm;
	}
	public void setGfthrNm(String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}
	public String getWtrRsdcCdNm() {
		return wtrRsdcCdNm;
	}
	public void setWtrRsdcCdNm(String wtrRsdcCdNm) {
		this.wtrRsdcCdNm = wtrRsdcCdNm;
	}
	public String getMrrgCdNm() {
		return mrrgCdNm;
	}
	public void setMrrgCdNm(String mrrgCdNm) {
		this.mrrgCdNm = mrrgCdNm;
	}
	public String getOcp() {
		return ocp;
	}
	public void setOcp(String ocp) {
		this.ocp = ocp;
	}
	public String getBthPlceCdNm() {
		return bthPlceCdNm;
	}
	public void setBthPlceCdNm(String bthPlceCdNm) {
		this.bthPlceCdNm = bthPlceCdNm;
	}
	public String getBthNatDiv() {
		return bthNatDiv;
	}
	public void setBthNatDiv(String bthNatDiv) {
		this.bthNatDiv = bthNatDiv;
	}
	public String getBthNatCdNm() {
		return bthNatCdNm;
	}
	public void setBthNatCdNm(String bthNatCdNm) {
		this.bthNatCdNm = bthNatCdNm;
	}
	public String getFrgnBthCtyNm() {
		return frgnBthCtyNm;
	}
	public void setFrgnBthCtyNm(String frgnBthCtyNm) {
		this.frgnBthCtyNm = frgnBthCtyNm;
	}
	public String getMltSrvcCdNm() {
		return mltSrvcCdNm;
	}
	public void setMltSrvcCdNm(String mltSrvcCdNm) {
		this.mltSrvcCdNm = mltSrvcCdNm;
	}
	public String getEncyCdNm() {
		return encyCdNm;
	}
	public void setEncyCdNm(String encyCdNm) {
		this.encyCdNm = encyCdNm;
	}
	public String getDsbtCdNm() {
		return dsbtCdNm;
	}
	public void setDsbtCdNm(String dsbtCdNm) {
		this.dsbtCdNm = dsbtCdNm;
	}
	public String getFmlyLangCdNm() {
		return fmlyLangCdNm;
	}
	public void setFmlyLangCdNm(String fmlyLangCdNm) {
		this.fmlyLangCdNm = fmlyLangCdNm;
	}
	public String getPoliCntrNm() {
		return poliCntrNm;
	}
	public void setPoliCntrNm(String poliCntrNm) {
		this.poliCntrNm = poliCntrNm;
	}
	public String getPmntAdCdNm() {
		return pmntAdCdNm;
	}
	public void setPmntAdCdNm(String pmntAdCdNm) {
		this.pmntAdCdNm = pmntAdCdNm;
	}
	public String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}
	public void setPmntAdDtlCt(String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}
	public String getEduCdNm() {
		return eduCdNm;
	}
	public void setEduCdNm(String eduCdNm) {
		this.eduCdNm = eduCdNm;
	}
	public String getEduYn() {
		return eduYn;
	}
	public void setEduYn(String eduYn) {
		this.eduYn = eduYn;
	}
	public String getEduLvDocYn() {
		return eduLvDocYn;
	}
	public void setEduLvDocYn(String eduLvDocYn) {
		this.eduLvDocYn = eduLvDocYn;
	}
	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}
	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}
	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}
	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}
	public String getBldTyeCdNm() {
		return bldTyeCdNm;
	}
	public void setBldTyeCdNm(String bldTyeCdNm) {
		this.bldTyeCdNm = bldTyeCdNm;
	}
	public String getBldTyeDocYn() {
		return bldTyeDocYn;
	}
	public void setBldTyeDocYn(String bldTyeDocYn) {
		this.bldTyeDocYn = bldTyeDocYn;
	}
	public String getRlgnCdNm() {
		return rlgnCdNm;
	}
	public void setRlgnCdNm(String rlgnCdNm) {
		this.rlgnCdNm = rlgnCdNm;
	}
	public String getSecdNltyCdNm() {
		return secdNltyCdNm;
	}
	public void setSecdNltyCdNm(String secdNltyCdNm) {
		this.secdNltyCdNm = secdNltyCdNm;
	}
	public String getRlgnSectCdNm() {
		return rlgnSectCdNm;
	}
	public void setRlgnSectCdNm(String rlgnSectCdNm) {
		this.rlgnSectCdNm = rlgnSectCdNm;
	}
	public String getRvctgRsn() {
		return rvctgRsn;
	}
	public void setRvctgRsn(String rvctgRsn) {
		this.rvctgRsn = rvctgRsn;
	}
	public String getRvctDd() {
		return rvctDd;
	}
	public void setRvctDd(String rvctDd) {
		this.rvctDd = rvctDd;
	}
	public String getRsnCdNm() {
		return rsnCdNm;
	}
	public void setRsnCdNm(String rsnCdNm) {
		this.rsnCdNm = rsnCdNm;
	}
	public String getRsdtRgstDd() {
		return rsdtRgstDd;
	}
	public void setRsdtRgstDd(String rsdtRgstDd) {
		this.rsdtRgstDd = rsdtRgstDd;
	}
	public String getRsdtRgstIdNm() {
		return rsdtRgstIdNm;
	}
	public void setRsdtRgstIdNm(String rsdtRgstIdNm) {
		this.rsdtRgstIdNm = rsdtRgstIdNm;
	}
	public String getCfmTamLedrIdNm() {
		return cfmTamLedrIdNm;
	}
	public void setCfmTamLedrIdNm(String cfmTamLedrIdNm) {
		this.cfmTamLedrIdNm = cfmTamLedrIdNm;
	}
	public String getSecdNltyYn() {
		return secdNltyYn;
	}
	public void setSecdNltyYn(String secdNltyYn) {
		this.secdNltyYn = secdNltyYn;
	}
	public String getCurtAdDiv() {
		return curtAdDiv;
	}
	public void setCurtAdDiv(String curtAdDiv) {
		this.curtAdDiv = curtAdDiv;
	}
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	public String getBthDd() {
		return bthDd;
	}
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	public String getEduCd() {
		return eduCd;
	}
	public void setEduCd(String eduCd) {
		this.eduCd = eduCd;
	}
	public String getOldCrdNo1() {
		return oldCrdNo1;
	}
	public void setOldCrdNo1(String oldCrdNo1) {
		this.oldCrdNo1 = oldCrdNo1;
	}
	public String getOldCrdNo2() {
		return oldCrdNo2;
	}
	public void setOldCrdNo2(String oldCrdNo2) {
		this.oldCrdNo2 = oldCrdNo2;
	}
	public String getOldCrdNo3() {
		return oldCrdNo3;
	}
	public void setOldCrdNo3(String oldCrdNo3) {
		this.oldCrdNo3 = oldCrdNo3;
	}
	public String getOldCrdNo4() {
		return oldCrdNo4;
	}
	public void setOldCrdNo4(String oldCrdNo4) {
		this.oldCrdNo4 = oldCrdNo4;
	}
	public String getOldCrdIsuceDd() {
		return oldCrdIsuceDd;
	}
	public void setOldCrdIsuceDd(String oldCrdIsuceDd) {
		this.oldCrdIsuceDd = oldCrdIsuceDd;
	}

	public String getOldCrdIsucePlceCd() {
		return oldCrdIsucePlceCd;
	}
	public void setOldCrdIsucePlceCd(String oldCrdIsucePlceCd) {
		this.oldCrdIsucePlceCd = oldCrdIsucePlceCd;
	}
	public String getRlgnCd() {
		return rlgnCd;
	}
	public void setRlgnCd(String rlgnCd) {
		this.rlgnCd = rlgnCd;
	}
	public String getSecdNltyCd() {
		return secdNltyCd;
	}
	public void setSecdNltyCd(String secdNltyCd) {
		this.secdNltyCd = secdNltyCd;
	}
	public String getRlgnSectCd() {
		return rlgnSectCd;
	}
	public void setRlgnSectCd(String rlgnSectCd) {
		this.rlgnSectCd = rlgnSectCd;
	}
	public String getCrdIsucePlceCdNm() {
		return crdIsucePlceCdNm;
	}
	public void setCrdIsucePlceCdNm(String crdIsucePlceCdNm) {
		this.crdIsucePlceCdNm = crdIsucePlceCdNm;
	}
	public String getCrdIsuDueDd() {
		return crdIsuDueDd;
	}
	public void setCrdIsuDueDd(String crdIsuDueDd) {
		this.crdIsuDueDd = crdIsuDueDd;
	}
	public String getCurtAdNatCdNm() {
		return curtAdNatCdNm;
	}
	public void setCurtAdNatCdNm(String curtAdNatCdNm) {
		this.curtAdNatCdNm = curtAdNatCdNm;
	}
	public String getSmrRsdcCd() {
		return smrRsdcCd;
	}
	public void setSmrRsdcCd(String smrRsdcCd) {
		this.smrRsdcCd = smrRsdcCd;
	}
	public String getWtrRsdcCd() {
		return wtrRsdcCd;
	}
	public void setWtrRsdcCd(String wtrRsdcCd) {
		this.wtrRsdcCd = wtrRsdcCd;
	}
	public String getFmlyBokNum() {
		return fmlyBokNum;
	}
	public void setFmlyBokNum(String fmlyBokNum) {
		this.fmlyBokNum = fmlyBokNum;
	}
	public String getBthPlceCd() {
		return bthPlceCd;
	}
	public void setBthPlceCd(String bthPlceCd) {
		this.bthPlceCd = bthPlceCd;
	}
	public String getBthNatCd() {
		return bthNatCd;
	}
	public void setBthNatCd(String bthNatCd) {
		this.bthNatCd = bthNatCd;
	}
	public String getMltSrvcCd() {
		return mltSrvcCd;
	}
	public void setMltSrvcCd(String mltSrvcCd) {
		this.mltSrvcCd = mltSrvcCd;
	}
	public String getEncyCd() {
		return encyCd;
	}
	public void setEncyCd(String encyCd) {
		this.encyCd = encyCd;
	}
	public String getDsbtDtlCt() {
		return dsbtDtlCt;
	}
	public void setDsbtDtlCt(String dsbtDtlCt) {
		this.dsbtDtlCt = dsbtDtlCt;
	}
	public String getFmlyLangCd() {
		return fmlyLangCd;
	}
	public void setFmlyLangCd(String fmlyLangCd) {
		this.fmlyLangCd = fmlyLangCd;
	}
	public String getPoliCntrSeqNoNm() {
		return poliCntrSeqNoNm;
	}
	public void setPoliCntrSeqNoNm(String poliCntrSeqNoNm) {
		this.poliCntrSeqNoNm = poliCntrSeqNoNm;
	}
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String getFmlyBokNoNum() {
		return fmlyBokNoNum;
	}
	public void setFmlyBokNoNum(String fmlyBokNoNum) {
		this.fmlyBokNoNum = fmlyBokNoNum;
	}
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}
	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}
	public String getPrntDd() {
		return prntDd;
	}
	public void setPrntDd(String prntDd) {
		this.prntDd = prntDd;
	}
	public String getValidDdEx() {
		return validDdEx;
	}
	public void setValidDdEx(String validDdEx) {
		this.validDdEx = validDdEx;
	}
	public String getBldTyeCd() {
		return bldTyeCd;
	}
	public void setBldTyeCd(String bldTyeCd) {
		this.bldTyeCd = bldTyeCd;
	}
	public String getNewFmlyBokYn() {
		return newFmlyBokYn;
	}
	public void setNewFmlyBokYn(String newFmlyBokYn) {
		this.newFmlyBokYn = newFmlyBokYn;
	}
	public String getPmntAdCd() {
		return pmntAdCd;
	}
	public void setPmntAdCd(String pmntAdCd) {
		this.pmntAdCd = pmntAdCd;
	}
	public String getCurtAdNatCd() {
		return curtAdNatCd;
	}
	public void setCurtAdNatCd(String curtAdNatCd) {
		this.curtAdNatCd = curtAdNatCd;
	}
	public String getHsbdRlCd() {
		return hsbdRlCd;
	}
	public void setHsbdRlCd(String hsbdRlCd) {
		this.hsbdRlCd = hsbdRlCd;
	}
	public String getHsbdRlCdNm() {
		return hsbdRlCdNm;
	}
	public void setHsbdRlCdNm(String hsbdRlCdNm) {
		this.hsbdRlCdNm = hsbdRlCdNm;
	}
	public String getHsbdCurtAdCd() {
		return hsbdCurtAdCd;
	}
	public void setHsbdCurtAdCd(String hsbdCurtAdCd) {
		this.hsbdCurtAdCd = hsbdCurtAdCd;
	}
	public String getHsbdCurtAdCdNm() {
		return hsbdCurtAdCdNm;
	}
	public void setHsbdCurtAdCdNm(String hsbdCurtAdCdNm) {
		this.hsbdCurtAdCdNm = hsbdCurtAdCdNm;
	}
	public String getHsbdCurtAdDtlCt() {
		return hsbdCurtAdDtlCt;
	}
	public void setHsbdCurtAdDtlCt(String hsbdCurtAdDtlCt) {
		this.hsbdCurtAdDtlCt = hsbdCurtAdDtlCt;
	}
	public String getHsbdPmntAdChngYn() {
		return hsbdPmntAdChngYn;
	}
	public void setHsbdPmntAdChngYn(String hsbdPmntAdChngYn) {
		this.hsbdPmntAdChngYn = hsbdPmntAdChngYn;
	}
	public String getHsbdPmntAdCd() {
		return hsbdPmntAdCd;
	}
	public void setHsbdPmntAdCd(String hsbdPmntAdCd) {
		this.hsbdPmntAdCd = hsbdPmntAdCd;
	}
	public String getHsbdPmntAdCdNm() {
		return hsbdPmntAdCdNm;
	}
	public void setHsbdPmntAdCdNm(String hsbdPmntAdCdNm) {
		this.hsbdPmntAdCdNm = hsbdPmntAdCdNm;
	}

	public String getHsbdPmntAdDtlCt() {
		return hsbdPmntAdDtlCt;
	}
	public void setHsbdPmntAdDtlCt(String hsbdPmntAdDtlCt) {
		this.hsbdPmntAdDtlCt = hsbdPmntAdDtlCt;
	}
	public String getAfHsbdRlCd() {
		return afHsbdRlCd;
	}
	public void setAfHsbdRlCd(String afHsbdRlCd) {
		this.afHsbdRlCd = afHsbdRlCd;
	}
	public String getAfHsbdRlCdNm() {
		return afHsbdRlCdNm;
	}
	public void setAfHsbdRlCdNm(String afHsbdRlCdNm) {
		this.afHsbdRlCdNm = afHsbdRlCdNm;
	}

	public String getAfHsbdPmntAdCd() {
		return afHsbdPmntAdCd;
	}
	public void setAfHsbdPmntAdCd(String afHsbdPmntAdCd) {
		this.afHsbdPmntAdCd = afHsbdPmntAdCd;
	}

	public String getAfHsbdPmntAdCdNm() {
		return afHsbdPmntAdCdNm;
	}
	public void setAfHsbdPmntAdCdNm(String afHsbdPmntAdCdNm) {
		this.afHsbdPmntAdCdNm = afHsbdPmntAdCdNm;
	}
	public String getAfHsbdPmntAdDtlCt() {
		return afHsbdPmntAdDtlCt;
	}
	public void setAfHsbdPmntAdDtlCt(String afHsbdPmntAdDtlCt) {
		this.afHsbdPmntAdDtlCt = afHsbdPmntAdDtlCt;
	}
	public String getHsbdFmlyBokNoDp() {
		return hsbdFmlyBokNoDp;
	}
	public void setHsbdFmlyBokNoDp(String hsbdFmlyBokNoDp) {
		this.hsbdFmlyBokNoDp = hsbdFmlyBokNoDp;
	}
	public String getHsbdFmlyHadSeqNo() {
		return hsbdFmlyHadSeqNo;
	}
	public void setHsbdFmlyHadSeqNo(String hsbdFmlyHadSeqNo) {
		this.hsbdFmlyHadSeqNo = hsbdFmlyHadSeqNo;
	}
	public String getWifeFmlyHadSeqNo() {
		return wifeFmlyHadSeqNo;
	}
	public void setWifeFmlyHadSeqNo(String wifeFmlyHadSeqNo) {
		this.wifeFmlyHadSeqNo = wifeFmlyHadSeqNo;
	}
	public String getWifeRlCd() {
		return wifeRlCd;
	}
	public void setWifeRlCd(String wifeRlCd) {
		this.wifeRlCd = wifeRlCd;
	}
	public String getWifeRlCdNm() {
		return wifeRlCdNm;
	}
	public void setWifeRlCdNm(String wifeRlCdNm) {
		this.wifeRlCdNm = wifeRlCdNm;
	}
	public String getAfWifeRlCd() {
		return afWifeRlCd;
	}
	public void setAfWifeRlCd(String afWifeRlCd) {
		this.afWifeRlCd = afWifeRlCd;
	}
	public String getAfWifeRlCdNm() {
		return afWifeRlCdNm;
	}
	public void setAfWifeRlCdNm(String afWifeRlCdNm) {
		this.afWifeRlCdNm = afWifeRlCdNm;
	}
	public String getWifeFmlyBokNoDp() {
		return wifeFmlyBokNoDp;
	}
	public void setWifeFmlyBokNoDp(String wifeFmlyBokNoDp) {
		this.wifeFmlyBokNoDp = wifeFmlyBokNoDp;
	}
	public String getWifeFmlyHadYn() {
		return wifeFmlyHadYn;
	}
	public void setWifeFmlyHadYn(String wifeFmlyHadYn) {
		this.wifeFmlyHadYn = wifeFmlyHadYn;
	}
	public String getHsbdFthrRlCd() {
		return hsbdFthrRlCd;
	}
	public void setHsbdFthrRlCd(String hsbdFthrRlCd) {
		this.hsbdFthrRlCd = hsbdFthrRlCd;
	}
	public String getHsbdFthrRlCdNm() {
		return hsbdFthrRlCdNm;
	}
	public void setHsbdFthrRlCdNm(String hsbdFthrRlCdNm) {
		this.hsbdFthrRlCdNm = hsbdFthrRlCdNm;
	}
	public String getHsbdFthrOthrRl() {
		return hsbdFthrOthrRl;
	}
	public void setHsbdFthrOthrRl(String hsbdFthrOthrRl) {
		this.hsbdFthrOthrRl = hsbdFthrOthrRl;
	}
	public String getWifeFthrRlCd() {
		return wifeFthrRlCd;
	}
	public void setWifeFthrRlCd(String wifeFthrRlCd) {
		this.wifeFthrRlCd = wifeFthrRlCd;
	}
	public String getWifeFthrRlCdNm() {
		return wifeFthrRlCdNm;
	}
	public void setWifeFthrRlCdNm(String wifeFthrRlCdNm) {
		this.wifeFthrRlCdNm = wifeFthrRlCdNm;
	}
	public String getWifeFthrOthrRl() {
		return wifeFthrOthrRl;
	}
	public void setWifeFthrOthrRl(String wifeFthrOthrRl) {
		this.wifeFthrOthrRl = wifeFthrOthrRl;
	}
	public String getHsbdFthrPmntAdCd() {
		return hsbdFthrPmntAdCd;
	}
	public void setHsbdFthrPmntAdCd(String hsbdFthrPmntAdCd) {
		this.hsbdFthrPmntAdCd = hsbdFthrPmntAdCd;
	}
	public String getHsbdFthrPmntAdCdNm() {
		return hsbdFthrPmntAdCdNm;
	}
	public void setHsbdFthrPmntAdCdNm(String hsbdFthrPmntAdCdNm) {
		this.hsbdFthrPmntAdCdNm = hsbdFthrPmntAdCdNm;
	}
	public String getHsbdFthrPmntAdDtlCt() {
		return hsbdFthrPmntAdDtlCt;
	}
	public void setHsbdFthrPmntAdDtlCt(String hsbdFthrPmntAdDtlCt) {
		this.hsbdFthrPmntAdDtlCt = hsbdFthrPmntAdDtlCt;
	}
	public String getRlCd() {
		return rlCd;
	}
	public void setRlCd(String rlCd) {
		this.rlCd = rlCd;
	}
	public String getRlCdNm() {
		return rlCdNm;
	}
	public void setRlCdNm(String rlCdNm) {
		this.rlCdNm = rlCdNm;
	}
	public String getOthrRl() {
		return othrRl;
	}
	public void setOthrRl(String othrRl) {
		this.othrRl = othrRl;
	}
	public String getHsbdOthrRl() {
		return hsbdOthrRl;
	}
	public void setHsbdOthrRl(String hsbdOthrRl) {
		this.hsbdOthrRl = hsbdOthrRl;
	}
	public String getWifeOthrRl() {
		return wifeOthrRl;
	}
	public void setWifeOthrRl(String wifeOthrRl) {
		this.wifeOthrRl = wifeOthrRl;
	}
	public String getFmlyHadSeqNo() {
		return fmlyHadSeqNo;
	}
	public void setFmlyHadSeqNo(String fmlyHadSeqNo) {
		this.fmlyHadSeqNo = fmlyHadSeqNo;
	}
	public String getWifePmntAdCdNm() {
		return wifePmntAdCdNm;
	}
	public void setWifePmntAdCdNm(String wifePmntAdCdNm) {
		this.wifePmntAdCdNm = wifePmntAdCdNm;
	}
	public String getWifePmntAdDtlCt() {
		return wifePmntAdDtlCt;
	}
	public void setWifePmntAdDtlCt(String wifePmntAdDtlCt) {
		this.wifePmntAdDtlCt = wifePmntAdDtlCt;
	}
	public String getHsbdCurtAdDiv() {
		return hsbdCurtAdDiv;
	}
	public void setHsbdCurtAdDiv(String hsbdCurtAdDiv) {
		this.hsbdCurtAdDiv = hsbdCurtAdDiv;
	}
	public String getHsbdCurtAdNatCd() {
		return hsbdCurtAdNatCd;
	}
	public void setHsbdCurtAdNatCd(String hsbdCurtAdNatCd) {
		this.hsbdCurtAdNatCd = hsbdCurtAdNatCd;
	}
	public String getWifeFmlyHadNm() {
		return wifeFmlyHadNm;
	}
	public void setWifeFmlyHadNm(String wifeFmlyHadNm) {
		this.wifeFmlyHadNm = wifeFmlyHadNm;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getWifeCurtAdDiv() {
		return wifeCurtAdDiv;
	}
	public void setWifeCurtAdDiv(String wifeCurtAdDiv) {
		this.wifeCurtAdDiv = wifeCurtAdDiv;
	}
	public String getWifeCurtAdNatCd() {
		return wifeCurtAdNatCd;
	}
	public void setWifeCurtAdNatCd(String wifeCurtAdNatCd) {
		this.wifeCurtAdNatCd = wifeCurtAdNatCd;
	}
	public String getWifeCurtAdCd() {
		return wifeCurtAdCd;
	}
	public void setWifeCurtAdCd(String wifeCurtAdCd) {
		this.wifeCurtAdCd = wifeCurtAdCd;
	}
	public String getWifeCurtAdCdNm() {
		return wifeCurtAdCdNm;
	}
	public void setWifeCurtAdCdNm(String wifeCurtAdCdNm) {
		this.wifeCurtAdCdNm = wifeCurtAdCdNm;
	}
	public String getWifeCurtAdDtlCt() {
		return wifeCurtAdDtlCt;
	}
	public void setWifeCurtAdDtlCt(String wifeCurtAdDtlCt) {
		this.wifeCurtAdDtlCt = wifeCurtAdDtlCt;
	}
	public String getHsbdSmrRsdcCd() {
		return hsbdSmrRsdcCd;
	}
	public void setHsbdSmrRsdcCd(String hsbdSmrRsdcCd) {
		this.hsbdSmrRsdcCd = hsbdSmrRsdcCd;
	}
	public String getHsbdWtrRsdcCd() {
		return hsbdWtrRsdcCd;
	}
	public void setHsbdWtrRsdcCd(String hsbdWtrRsdcCd) {
		this.hsbdWtrRsdcCd = hsbdWtrRsdcCd;
	}
	public String getWifeSmrRsdcCd() {
		return wifeSmrRsdcCd;
	}
	public void setWifeSmrRsdcCd(String wifeSmrRsdcCd) {
		this.wifeSmrRsdcCd = wifeSmrRsdcCd;
	}
	public String getWifeWtrRsdcCd() {
		return wifeWtrRsdcCd;
	}
	public void setWifeWtrRsdcCd(String wifeWtrRsdcCd) {
		this.wifeWtrRsdcCd = wifeWtrRsdcCd;
	}
	public String getHsbdFmlyHadYn() {
		return hsbdFmlyHadYn;
	}
	public void setHsbdFmlyHadYn(String hsbdFmlyHadYn) {
		this.hsbdFmlyHadYn = hsbdFmlyHadYn;
	}
	public String getFmlyHadYn() {
		return fmlyHadYn;
	}
	public void setFmlyHadYn(String fmlyHadYn) {
		this.fmlyHadYn = fmlyHadYn;
	}
	public String getHsbdFthrFmlyHadYn() {
		return hsbdFthrFmlyHadYn;
	}
	public void setHsbdFthrFmlyHadYn(String hsbdFthrFmlyHadYn) {
		this.hsbdFthrFmlyHadYn = hsbdFthrFmlyHadYn;
	}
	public String getWifeFthrFmlyHadYn() {
		return wifeFthrFmlyHadYn;
	}
	public void setWifeFthrFmlyHadYn(String wifeFthrFmlyHadYn) {
		this.wifeFthrFmlyHadYn = wifeFthrFmlyHadYn;
	}
	public String getFthrFmlyHadYn() {
		return fthrFmlyHadYn;
	}
	public void setFthrFmlyHadYn(String fthrFmlyHadYn) {
		this.fthrFmlyHadYn = fthrFmlyHadYn;
	}
	public String getHsbdRlChngYn() {
		return hsbdRlChngYn;
	}
	public void setHsbdRlChngYn(String hsbdRlChngYn) {
		this.hsbdRlChngYn = hsbdRlChngYn;
	}
	public String getWifeRlChngYn() {
		return wifeRlChngYn;
	}
	public void setWifeRlChngYn(String wifeRlChngYn) {
		this.wifeRlChngYn = wifeRlChngYn;
	}
	public String getAfHsbdOthrRl() {
		return afHsbdOthrRl;
	}
	public void setAfHsbdOthrRl(String afHsbdOthrRl) {
		this.afHsbdOthrRl = afHsbdOthrRl;
	}
	public String getAfWifeOthrRl() {
		return afWifeOthrRl;
	}
	public void setAfWifeOthrRl(String afWifeOthrRl) {
		this.afWifeOthrRl = afWifeOthrRl;
	}
	public String getCrdIsuceYn() {
		return crdIsuceYn;
	}
	public void setCrdIsuceYn(String crdIsuceYn) {
		this.crdIsuceYn = crdIsuceYn;
	}
	public String[] getErrMsgVal() {
		return errMsgVal;
	}
	public void setErrMsgVal(String[] errMsgVal) {
		this.errMsgVal = errMsgVal;
	}
	public String getgBthDd() {
		return gBthDd;
	}
	public void setgBthDd(String gBthDd) {
		this.gBthDd = gBthDd;
	}
	public String gethBthDd() {
		return hBthDd;
	}
	public void sethBthDd(String hBthDd) {
		this.hBthDd = hBthDd;
	}
	public String getHsbdFthrFmlyBokNo() {
		return hsbdFthrFmlyBokNo;
	}
	public void setHsbdFthrFmlyBokNo(String hsbdFthrFmlyBokNo) {
		this.hsbdFthrFmlyBokNo = hsbdFthrFmlyBokNo;
	}
	public String getHsbdFthrFmlyBokNoDp() {
		return hsbdFthrFmlyBokNoDp;
	}
	public void setHsbdFthrFmlyBokNoDp(String hsbdFthrFmlyBokNoDp) {
		this.hsbdFthrFmlyBokNoDp = hsbdFthrFmlyBokNoDp;
	}
	public String getFthrRlCd() {
		return fthrRlCd;
	}
	public void setFthrRlCd(String fthrRlCd) {
		this.fthrRlCd = fthrRlCd;
	}
	public String getOp() {
		return op;
	}
	public void setOp(String op) {
		this.op = op;
	}
	public String getAfHsbdFmlyBokNoDp() {
		return afHsbdFmlyBokNoDp;
	}
	public void setAfHsbdFmlyBokNoDp(String afHsbdFmlyBokNoDp) {
		this.afHsbdFmlyBokNoDp = afHsbdFmlyBokNoDp;
	}
	public String getAfHsbdFmlyBokNo() {
		return afHsbdFmlyBokNo;
	}
	public void setAfHsbdFmlyBokNo(String afHsbdFmlyBokNo) {
		this.afHsbdFmlyBokNo = afHsbdFmlyBokNo;
	}
	public String getHsbdFmlyFomChk() {
		return hsbdFmlyFomChk;
	}
	public void setHsbdFmlyFomChk(String hsbdFmlyFomChk) {
		this.hsbdFmlyFomChk = hsbdFmlyFomChk;
	}
	public String getAgGap() {
		return agGap;
	}
	public void setAgGap(String agGap) {
		this.agGap = agGap;
	}
	public String getMberCn() {
		return mberCn;
	}
	public void setMberCn(String mberCn) {
		this.mberCn = mberCn;
	}
	public String getMberCnTyeCd() {
		return mberCnTyeCd;
	}
	public void setMberCnTyeCd(String mberCnTyeCd) {
		this.mberCnTyeCd = mberCnTyeCd;
	}
	public String getFthrAgGap() {
		return fthrAgGap;
	}
	public void setFthrAgGap(String fthrAgGap) {
		this.fthrAgGap = fthrAgGap;
	}
	public String getFthrMftrYn() {
		return fthrMftrYn;
	}
	public void setFthrMftrYn(String fthrMftrYn) {
		this.fthrMftrYn = fthrMftrYn;
	}
	public String getGfthrAgGap() {
		return gfthrAgGap;
	}
	public void setGfthrAgGap(String gfthrAgGap) {
		this.gfthrAgGap = gfthrAgGap;
	}
	public String getGfthrRlCd() {
		return gfthrRlCd;
	}
	public void setGfthrRlCd(String gfthrRlCd) {
		this.gfthrRlCd = gfthrRlCd;
	}
	public String getGfthrMftrYn() {
		return gfthrMftrYn;
	}
	public void setGfthrMftrYn(String gfthrMftrYn) {
		this.gfthrMftrYn = gfthrMftrYn;
	}
	public String getMthrAgGap() {
		return mthrAgGap;
	}
	public void setMthrAgGap(String mthrAgGap) {
		this.mthrAgGap = mthrAgGap;
	}
	public String getMthrRlCd() {
		return mthrRlCd;
	}
	public void setMthrRlCd(String mthrRlCd) {
		this.mthrRlCd = mthrRlCd;
	}
	public String getMthrMftrYn() {
		return mthrMftrYn;
	}
	public void setMthrMftrYn(String mthrMftrYn) {
		this.mthrMftrYn = mthrMftrYn;
	}
	public String getHsbdAgGap() {
		return hsbdAgGap;
	}
	public void setHsbdAgGap(String hsbdAgGap) {
		this.hsbdAgGap = hsbdAgGap;
	}
	public String getHsbdMftrYn() {
		return hsbdMftrYn;
	}
	public void setHsbdMftrYn(String hsbdMftrYn) {
		this.hsbdMftrYn = hsbdMftrYn;
	}
	public String getHsbdFmlyBokMvYn() {
		return hsbdFmlyBokMvYn;
	}
	public void setHsbdFmlyBokMvYn(String hsbdFmlyBokMvYn) {
		this.hsbdFmlyBokMvYn = hsbdFmlyBokMvYn;
	}
	public String getHsbdFmlyHadGdrCd() {
		return hsbdFmlyHadGdrCd;
	}
	public void setHsbdFmlyHadGdrCd(String hsbdFmlyHadGdrCd) {
		this.hsbdFmlyHadGdrCd = hsbdFmlyHadGdrCd;
	}
	public String getWifeFmlyHadGdrCd() {
		return wifeFmlyHadGdrCd;
	}
	public void setWifeFmlyHadGdrCd(String wifeFmlyHadGdrCd) {
		this.wifeFmlyHadGdrCd = wifeFmlyHadGdrCd;
	}
	public String getFmlyHadGdrCd() {
		return fmlyHadGdrCd;
	}
	public void setFmlyHadGdrCd(String fmlyHadGdrCd) {
		this.fmlyHadGdrCd = fmlyHadGdrCd;
	}
	public String getMberRstrtGdrCd() {
		return mberRstrtGdrCd;
	}
	public void setMberRstrtGdrCd(String mberRstrtGdrCd) {
		this.mberRstrtGdrCd = mberRstrtGdrCd;
	}


	
}
