package afnid.rm.mrrg.service;

import java.util.List;
import java.util.Map;

import egovframework.rte.psl.dataaccess.util.EgovMap;

public interface DvrcService {
	
	
	/**
	 * Retrieves retrieving Marriage information. <br>
	 * 
	 * @param vo Input item for retrieving Marriage information(DvrcVO).
	 * @return DvrcVO Retrieve retrieving Marriage information.
	 * @exception Exception
	 */
	DvrcVO searchMrrgInfr(DvrcVO vo) throws Exception;	
	
	/**
	 * Retrieves list of Marriage information. <br>
	 * 
	 * @param vo Input item for retrieving list of Marriage information(DvrcVO).
	 * @return List Retrieve list of Marriage information
	 * @exception Exception
	 */
	List<DvrcVO> searchListMrrgInfr(DvrcVO vo) throws Exception;	
	
	/**
	 * Register information of Divorce. <br>
	 * 
	 * @param vo Input item for Register information of Divorce.(DvrcVO).
	 * @return String Divorce Seq No.
	 * @exception Exception
	 */
	String addDvrcInfr(DvrcVO vo) throws Exception;
	
	/**
	 * Retrieves Divorce Information for Divorce update. <br>
	 * 
	 * @param vo Input item for retrieving Marriage RSDT_SEQ_NO(DvrcVO).
	 * @return DvrcVO Retrieve Divorce Information
	 * @exception Exception
	 */
	DvrcVO searchDvrcInfr(DvrcVO vo) throws Exception;
	
	/**
	 * Retrieves list of Divorce information. <br>
	 * 
	 * @param vo Input item for retrieving list of Divorce information(DvrcVO).
	 * @return List Retrieve list of Divorce information
	 * @exception Exception
	 */
	List<DvrcVO> searchListDvrcInfr(DvrcVO vo) throws Exception;
	
	/**
	 * Modify Divorce information. <br>
	 * 
	 * @param vo Input item for modifying divorce information(DvrcVO).
	 * @return int Result Count
	 * @exception Exception
	 */
	int modifyDvrcInfr(DvrcVO vo) throws Exception;
	
	/**
	 * Retrieves list of Divorce information. <br>
	 * 
	 * @param vo Input item for retrieving list of Divorce information(DvrcVO).
	 * @return List Retrieve list of Divorce information
	 * @exception Exception
	 */
	DvrcVO searchDvrcAprvInfr(DvrcVO vo) throws Exception;	
	
	/**
	 * Retrieves list of Divorce information. <br>
	 * 
	 * @param vo Input item for retrieving list of Divorce information(DvrcVO).
	 * @return Map<String,String> List Retrieve list of Divorce information
	 * @exception Exception
	 */
	Map<String,String> approveDvrcInfr(DvrcVO vo) throws Exception;
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 * @param vo Input item for retrieving Receipt of Citizen.(DvrcVO)
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
	DvrcVO searchDvrcCrdReisuceRcpt(DvrcVO vo) throws Exception;
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 *
	 * @param vo Input item for retrieving Receipt of Citizen.(DvrcVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchDvrcCrdReisuceOthrRcpt(DvrcVO vo) throws Exception;
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 *
	 * @param vo Input item for retrieving Receipt of Citizen.(DvrcVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap>  searchDvrcCrdReisuceFrgnRcpt(DvrcVO vo) throws Exception;
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 * @param vo Input item for retrieving Receipt of Citizen Confirmation.(DvrcVO)
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
	DvrcVO searchDvrcCfmRcpt(DvrcVO vo) throws Exception;
	
	/**
	 * Retrieves of wife permanent address code. <br>
	 * @param wifeSeqNo Input item for retrieving wife permanent address code.(String)
	 * @return String wife permanent address code
	 * @exception Exception
	 */
	String searchWifePmntAdCd(String wifeSeqNo) throws Exception;
	
	/**
	 * send to write citizen information request <br>
	 * @param hsbdLogSeqNo Input item for inserting log.(String).
	 * @param hsbdParm Input item for sending to write citizen information request.(String).
	 * @return status result
	 * @exception Exception
	 */
	String approveDvrcInfrPkiIf(String hsbdLogSeqNo, String hsbdParm) throws Exception;
	
	/**
	 * Retrieves of wife permanent address code. <br>
	 * @param wifeSeqNo Input item for retrieving wife permanent address code.(String)
	 * @return String wife permanent address code
	 * @exception Exception
	 */
	String searchResultOfCrdInfrChang(DvrcVO vo, String gdr) throws Exception;	
	
	/**
	 * Retrieves wife relationship. <br>
	 *
	 * @param vo Input item for retrieving relationship(DvrcVO).
	 * @return relationship code
	 * @exception Exception
	 */
	List<DvrcVO> searchListRl(DvrcVO vo) throws Exception;	
	
	/**
	 * Retrieves wife relationship. <br>
	 *
	 * @param vo Input item for retrieving  relationship(DvrcVO).
	 * @return relationship code
	 * @exception Exception
	 */
	List<DvrcVO> searchListRlOthr(DvrcVO vo) throws Exception;	
	
	/**
	 * Retrieves wife relationship. <br>
	 *
	 * @param vo Input item for retrieving relationship(DvrcVO).
	 * @return relationship code
	 * @exception Exception
	 */
	List<DvrcVO> searchListRlAll(DvrcVO vo) throws Exception;	
	
	/**
	 * Retrieves wife relationship. <br>
	 *
	 * @param vo Input item for retrieving relationship(DvrcVO).
	 * @return relationship code
	 * @exception Exception
	 */
	List<DvrcVO> searchListRlTbAll(DvrcVO vo) throws Exception;	
	
	/**
	 * Retrieves total count relationship in family book.. <br>
	 *
	 * @param vo Input item for retrieving total count relationship in family book.(DvrcVO).
	 * @return total count relationship in family book.
	 * @exception Exception
	 */
	int searchMberCn(DvrcVO vo) throws Exception;	
}
