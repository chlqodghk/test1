package afnid.rm.mrrg.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.mrrg.service.MrrgVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This Controller class processes request of MRRG and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Si Kyung Yang
 * @since 2013.05.21
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.05.21  		Si Kyung Yang         						Create
 *
 * </pre>
 */
@Repository("mrrgDAO")
public class MrrgDAO extends EgovAbstractDAO{
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(MrrgVO).
	 * @return EgovMap Object
	 * @exception Exception
	 *
	 */
	public EgovMap selectRsdtInfr(MrrgVO vo) throws Exception{
		return (EgovMap)selectByPk("mrrgDAO.selectMrrgRsdtInfo", vo);
	}	
	
	/**
	 * DAO-method for counting Male Marriage information. <br>
	 * 
	 * @param vo Input item for modifying program(MrrgVO).
	 * @return int counting of Male Marriage.
	 * @exception Exception
	 */
	public int selectMlMrrgCn(MrrgVO vo) throws Exception{
		return (Integer)selectByPk("mrrgDAO.selectMlMrrgCn", vo);
	}
	
	/**
	 * DAO-method for retrieving wife information. <br>
	 * 
	 * @param vo Input item for retrieving wife information(MrrgVO).
	 * @return List<EgovMap> wife's name and eNID information. 
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectMrrgWifeNm(MrrgVO vo) throws Exception{
		return list("mrrgDAO.selectMrrgWifeNm", vo);
	}
	
	/**
	 * DAO-method for retrieving female marriage information. <br>
	 *
	 * @param vo Input item for retrieving female marriage information.(MrrgVO).
	 * @return EgovMap  Retrieve female marriage information
	 * @exception Exception
	 */	
	public EgovMap selectFemlMrrgInfr(MrrgVO vo) throws Exception{
		return (EgovMap)selectByPk("mrrgDAO.selectFemlMrrgInfr", vo);
	}
		
	/**
	 * DAO-method for register information of program. <br>
	 * 
	 * @param vo Input item for modifying program(MrrgVO).
	 * @return String 
	 * @exception Exception
	 */
	public  String insertMrrg(MrrgVO vo) {
		String result = "";
		synchronized( this ){
			result = (String)insert("mrrgDAO.insertMrrg", vo); 
		}
        return result;
    } 
	
	/**
	 * DAO-method for register information of New family book. <br>
	 * 
	 * @param vo Input item for registering program(MrrgVO).
	 * @return String 
	 * @exception Exception
	 */
	public  String insertFmlyBokByMrrg(MrrgVO vo) {
		String result = "";
		synchronized( this ){
			result = (String)insert("mrrgDAO.insertFmlyBokByMrrg", vo); 
		}
        return result;
    }
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(MrrgVO).
	 * @return MrrgVO
	 * @exception Exception
	 *
	 */	
	public MrrgVO selectMrrgUdtRsdtInfr(MrrgVO vo) throws Exception{
		
		vo.setSearchKeyword4(NidStringUtil.toNumberConvet(vo.getSearchKeyword4(), "g"));
		
		return (MrrgVO)selectByPk("mrrgDAO.selectMrrgUdtRsdtInfr", vo);
	}
		
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(MrrgVO).
	 * @return List<EgovMap> 
	 * @exception Exception
	 *
	 */	
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectMrrgUdtInfrTotCnt(MrrgVO vo) throws Exception{
		
		vo.setSearchKeyword4(NidStringUtil.toNumberConvet(vo.getSearchKeyword4(), "g"));
		
		return list("mrrgDAO.selectMrrgUdtInfrTotCnt", vo);
	}
	     
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(MrrgVO).
	 * @return MrrgVO 
	 * @exception Exception
	 *
	 */	
	public MrrgVO selectMrrgUdtInfr(MrrgVO vo) throws Exception{
		return (MrrgVO)selectByPk("mrrgDAO.selectMrrgUdtInfr", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(MrrgVO).
	 * @return MrrgVO 
	 * @exception Exception
	 *
	 */	
	public MrrgVO selectMrrgDtlInfr(MrrgVO vo) throws Exception{
		return (MrrgVO)selectByPk("mrrgDAO.selectMrrgDtlInfr", vo);
	}
	
	/**
	 * DAO-method for retrieving list of program.<br>
	 * 
	 * @param vo Input item for retrieving list of program(MrrgVO).
	 * @return List Retrieve list of program
	 * @exception Exception 
	 */	
	@SuppressWarnings("unchecked")
	public List<MrrgVO> selectListMrrgUdt(MrrgVO vo) throws Exception{
		return list("mrrgDAO.selectListMrrgUdt", vo);
	}
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(MrrgVO).
	 * @return int Result Count
	 * @exception Exception
	 */
	public int updateMrrgInfr(MrrgVO vo){
		return update("mrrgDAO.updateMrrgInfr", vo);
	}
	
	/**
	 * DAO-method for retrieving list of program.<br>
	 * 
	 * @param vo Input item for retrieving list of program(MrrgVO).
	 * @return List Retrieve list of program
	 * @exception Exception 
	 */		
	@SuppressWarnings("unchecked")
	public List<MrrgVO> selectListMrrgDvrcAprv(MrrgVO vo) throws Exception{
		
		vo.setSearchKeyword6(NidStringUtil.toNumberConvet(vo.getSearchKeyword6(), "g"));
		
		return list("mrrgDAO.selectMrrgDvrcVfyLst", vo);
	}
	
	/**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(MrrgVO).
	 * @return int Total Count of Program List
	 * @exception Exception 
	 */
    public int selectListTotCntMrrgDvrcAprv(MrrgVO vo) {
        
    	vo.setSearchKeyword6(NidStringUtil.toNumberConvet(vo.getSearchKeyword6(), "g"));
    	
    	return (Integer)selectByPk("mrrgDAO.selectMrrgDvrcVfyLstTotCnt", vo);
    }	
	
	 /**
	 * DAO-method for modifying information of marriage.  <br>
	 *
	 * @param vo Input item for modifying information of marriage(MrrgVO).
	 * @return boolean result of update
	 * @exception Exception 
	 */
	public boolean approveMrrg(MrrgVO vo) throws Exception{
		boolean result = false; 
		
		int Result =  update("mrrgDAO.updateVerification", vo);
		
		if(Result == 1){
			result = true;
		}
		
		return result;
		
	}	
	
    /**
	 * DAO-method for modifying information of resident. <br>
	 *
	 * @param vo Input item for modifying information of resident.(MrrgVO).
	 * @return void	 *
	 * @exception Exception
	 */
	public boolean updateRsdtInfr(MrrgVO vo) throws Exception{
		boolean result = false; 
		
		int Result =  update("mrrgDAO.updateRsdtInfo", vo);
		
		if(Result == 1){
			result = true;
		}
		
		return result;
	}
	
	/**
	 * DAO-method for modifying information of resident. <br>
	 *
	 * @param vo Input item for modifying information of resident.(MrrgVO).
	 * @return void	 *
	 * @exception Exception
	 */
	public boolean updateWifeHsbdRsdtSeqNo(MrrgVO vo) throws Exception{
		boolean result = false; 
		
		int Result =  update("mrrgDAO.updateWifeHsbdRsdtSeqNo", vo);
		
		if(Result == 1){
			result = true;
		}
		
		return result;
	}
	
	/**
	 * DAO-method for retrieving spouse information for insert foreigner. <br>
	 *
	 * @param vo Input item for retrieving spouse information for insert foreigner.(MrrgVO).
	 * @return MrrgVO 
	 * @exception Exception
	 */
	public MrrgVO selectSpusInfr(MrrgVO vo) throws Exception{
		return (MrrgVO)selectByPk("mrrgDAO.selectSpusInfr", vo);
	}
	
	/**
	 * DAO-method for retrieving Family From information. <br>
	 *
	 * @param vo Input item for retrieving Family From information.(MrrgVO).
	 * @return MrrgVO 
	 * @exception Exception
	 */
	public MrrgVO selectFmlyBokInfr(String fmlyBokNo) throws Exception{
		return (MrrgVO)selectByPk("mrrgDAO.selectFmlyBokInfr", fmlyBokNo);
	}
	
	/**
	 * DAO-method for insert information of foreigner <br>
	 * 
	 * @param vo Input item for insert information of foreigner(MrrgVO).
	 * @return int result of RSDT_SEQ_NO
	 * @exception Exception
	 */    
    public String insertRsdtInfrForForeigner(MrrgVO vo){
        return (String)insert("mrrgDAO.insertRsdtInfrForForeigner", vo);
    }
	
    /**
	 * DAO-method for modifying information of Marriage <br>
	 * 
	 * @param vo Input item for modifying marriage(MrrgVO).
	 * @return int result of update
	 * @exception Exception
	 */    
    public void insertCrdIsuInfr(MrrgVO vo){
    	insert("mrrgDAO.insertCrdIsuInfr", vo);
    }	
	
    /**
	 * DAO-method for  retrieving Receipt of Citizen. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(MrrgVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
    public MrrgVO selectCrdReisuceRcpt(MrrgVO vo) {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());  
		
		if("2".equals(vo.getGdrCd())){
			return (MrrgVO)selectByPk("mrrgDAO.selectCrdReisuceReceiptW", vo);
		} else {
			return (MrrgVO)selectByPk("mrrgDAO.selectCrdReisuceReceiptH", vo);
		}

    }
    
    /**
	 * DAO-method for  retrieving Receipt of Citizen. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(MrrgVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectCrdReisuceOthrRcpt(MrrgVO vo) throws Exception{
		return list("mrrgDAO.selectCrdReisuceOthrReceipt", vo);
	}
	
	/**
	 * DAO-method for  retrieving Receipt of Citizen. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(MrrgVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")	
    public List<EgovMap> selectCrdReisuceFrgnRcpt(MrrgVO vo) {
    	return list("mrrgDAO.selectCrdReisuceFrgnReceipt", vo);
    }
	
	/**
	 * DAO-method for  retrieving Receipt of Citizen Confirmation. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(MrrgVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
    public MrrgVO selectMrrgCfmRcpt(MrrgVO vo) {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());  
		
		if("2".equals(vo.getGdrCd())){
			return (MrrgVO)selectByPk("mrrgDAO.selectMrrgCfmReceiptW", vo);
		} else {
			return (MrrgVO)selectByPk("mrrgDAO.selectMrrgCfmReceiptH", vo);
		}

    }
    
    /**
	 * DAO-method for  retrieving wife permanent address code. <br>
	 *
	 * @param wifeSeqNo Input item for  retrieving wife permanent address code.(String).
	 * @return String wife permanent address code.
	 * @exception Exception
	 */
    public EgovMap selectResultOfCrdInfrChang(String wifeSeqNo) {    	
        return (EgovMap)selectByPk("mrrgDAO.selectResultOfCrdInfrChang", wifeSeqNo);
    }
    
    /**
	 * DAO-method for retrieving Male Card Write Request parameter. <br>
	 *
	 * @param vo Input item for  retrieving Card Write Request parameter(MrrgVO).
	 * @return String of parameter
	 * @exception Exception
	 */
    public String selectMaleParamWriteRqst(MrrgVO vo) {
		String param = "";
    	
		param =(String)selectByPk("mrrgDAO.selectMaleParamWriteRqst", vo);

        return param;
    }
    
    /**
	 * DAO-method for retrieving Female Card Write Request parameter. <br>
	 *
	 * @param vo Input item for retrieving Card Write Request parameter(MrrgVO).
	 * @return String of parameter
	 * @exception Exception
	 */
    public String selectFemaleParamWriteRqst(MrrgVO vo) {
    	String param = "";

		param =(String)selectByPk("mrrgDAO.selectFemaleParamWriteRqst", vo);

        return param;
    }
    
    /**
	 * DAO-method for retrieving citizen card expiration Status. <br>
	 *
	 * @param mrrgSeqNo Input item for citizen card expiration Status(String).
	 * @param gdr Input item for  select SQL (String).
	 * @return String of parameter
	 * @exception Exception
	 */
    public String selectCrdExpStus(String rsdtSeqNo) {
    
		String result =(String)selectByPk("mrrgDAO.selectCrdExpStus", rsdtSeqNo);

        return result;
    }
    
	/**
	 * DAO-method for retrieving wife relationship. <br>
	 * 
	 * @param vo Input item for retrieving wife relationship.(MrrgVO).
	 * @return relationship code
	 * @exception Exception
	 */  
    @SuppressWarnings("unchecked")
    public List<MrrgVO> searchListRl(MrrgVO vo){
        return list ("mrrgDAO.searchListRl", vo);
    }    
       
	/**
	 * DAO-method for retrieving wife relationship. <br>
	 * 
	 * @param vo Input item for retrieving wife relationship.(MrrgVO).
	 * @return relationship code
	 * @exception Exception
	 */  
    @SuppressWarnings("unchecked")
    public List<MrrgVO> selectRlOthr(MrrgVO vo){
        return list ("mrrgDAO.selectRlOthr", vo);
    } 
    
	/**
	 * DAO-method for retrieving  relationship. <br>
	 * 
	 * @param vo Input item for retrieving  relationship.(MrrgVO).
	 * @return relationship code
	 * @exception Exception
	 */  
    @SuppressWarnings("unchecked")
    public List<MrrgVO> selectListRlAll(MrrgVO vo){
        return list ("mrrgDAO.selectListRlAll", vo);
    }    
    
    /**
	 * DAO-method for  retrieving Family Head Gender. <br>
	 *
	 * @param wifeSeqNo Input item for  retrieving Family Head Gender.(String).
	 * @return String Family Head Gender code.
	 * @exception Exception
	 */
    public String selectFmlyHadGdrCd(MrrgVO vo) {    	
        return (String)selectByPk("mrrgDAO.selectFmlyHadGdrCd", vo);
    }  
    
	/**
	 * DAO-method for retrieving  relationship. <br>
	 * 
	 * @param vo Input item for retrieving  relationship.(MrrgVO).
	 * @return relationship code
	 * @exception Exception
	 */  
    @SuppressWarnings("unchecked")
    public List<MrrgVO> selectListRlTbAll(MrrgVO vo){
        return list ("mrrgDAO.selectListRlTbAll", vo);
    } 
    
	/**
	 * DAO-method for retrieving total count relationship in family book. <br>
	 * 
	 * @param vo Input item for retrieving total count relationship in family book(RcptCardVO).
	 * @return int Total Count of relationship in family book
	 * @exception Exception
	 */
   	public int selectMberCn(MrrgVO vo) {
       return (Integer)selectByPk("mrrgDAO.selectMberCn", vo);
   	}    
}
