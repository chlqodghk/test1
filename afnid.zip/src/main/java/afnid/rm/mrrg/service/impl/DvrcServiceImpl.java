package afnid.rm.mrrg.service.impl;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.pkiif.ccm.RMCCM;
import afnid.pkiif.ccm.RMCCM_Service;
import afnid.rm.crd.service.CrdFndService;
import afnid.rm.mrrg.service.DvrcService;
import afnid.rm.mrrg.service.DvrcVO;
import afnid.rm.rsdt.service.RsdtInfrService;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Service("dvrcService")
public class DvrcServiceImpl extends AbstractServiceImpl implements DvrcService{
	/** dvrcDAO */
    @Resource(name="dvrcDAO")
    private DvrcDAO dao;

    @Resource(name="lgDAO")
    private LgDAO lgDao;
    
    /** rsdtInfoDAO */
    @Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtInfoDAO;
    
    /** crdFndService */
	@Resource(name = "crdFndService")
    private CrdFndService crdFndService;
    
    /** rsdtInfoService service */
    @Resource(name="rsdtInfoService")
    private RsdtInfrService rsdtInfoService;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /**
	 * Biz-method for retrieving Marriage information. <br>
	 * 
	 * @param vo Input item for retrieving Marriage information(DvrcVO).
	 * @return List Retrieve Marriage information
	 * @exception Exception
	 */
	public DvrcVO searchMrrgInfr(DvrcVO dvrcVO) throws Exception {		
		
		DvrcVO vo2 = new DvrcVO(); 
		vo2 = dao.selectRsdtInfr(dvrcVO);
		
		DvrcVO vo = new DvrcVO();
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUserId(user.getUserId());
		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
		vo.setRgstOrgnzCd( orgnzCd );
		vo.setUseLangCd(user.getUseLangCd()); 
		int crdReisuceDmBfExpr = propertiesService.getInt("crdReisuceDmBfExpr");
		vo.setCrdReisuceDmBfExpr(String.valueOf(crdReisuceDmBfExpr));
		
		//check Enid Number (Exist or Not)
		if( null == vo2 ){
			vo.setErrMsg("nRgstEnid.msg");
			return vo;
		}
		
		//check citizen status code
		if("2".equals(vo2.getRsdtStusCd())){
			if(!"1".equals(vo2.getErsrCd()) && !"2".equals(vo2.getErsrCd())){
				vo.setErrMsg("dcrdCtznNo.msg");
				return vo;
			}
		}

		//check Citizen marriage status 
		if("1".equals(vo2.getGdrCd())){//mail
			vo.setHsbdRsdtSeqNo(vo2.getRsdtSeqNo());
			int mrrgCn = Integer.parseInt(vo2.getCn());
			vo.setMrrgCn(String.valueOf(mrrgCn));
			
			if(1< mrrgCn){
				return vo;
			}else if(1 == mrrgCn){
				
				String wifeRsdtSeqNo = dao.selectWifeRsdtSeqNo(vo);
				vo.setWifeRsdtSeqNo(wifeRsdtSeqNo);
			}else{
				
				if("Y".equals(vo2.getHsbdRgstYn()) ){
					vo.setErrMsg("nRgstGoMdfct.msg");
				}else{
					vo.setErrMsg("nMrrgHst.msg");
				}
				return vo;
			}
		}else{//female
			
    		if( null == vo2.getSpusRsdtSeqNo() || "".equals(vo2.getSpusRsdtSeqNo()) ){
    			if(null == vo2.getSpusNm() || "".equals(vo2.getSpusNm())){
    				vo.setErrMsg("nMrrgHst.msg");
    			}else{
    				vo.setErrMsg("nDvrcPrcssByNExistSpusEnid.msg");
    			}
    			return vo;
    		}else if("Y".equals(vo2.getWifeRgstYn())){
    				vo.setErrMsg("nRgstGoMdfct.msg");
    				return vo;
    		}else{
    			vo.setMrrgCn("1");
    			vo.setWifeRsdtSeqNo(vo2.getRsdtSeqNo());
        		vo.setHsbdRsdtSeqNo(vo2.getSpusRsdtSeqNo());
    		}
		}
		
		//Search the MRRG_SEQ_NO On RM_MRRG_TB
		vo2 = dao.selectMrrgSeqNo(vo);
		
		//setting Marriage Date and Foreigner information
		if(null != vo2){
			vo.setMrrgDd(vo2.getMrrgDd());
			vo.setMrrgSeqNo(vo2.getMrrgSeqNo());
			vo.setHsbdNltyCdNm(vo2.getHsbdNltyCdNm());
			vo.setWifeNltyCdNm(vo2.getWifeNltyCdNm());
			if("Y".equals(vo2.getHsbdFrngrYn()) ){
				vo.setHsbdFrngrYn(vo2.getHsbdFrngrYn());
				vo.setHsbdFrngrRgstNo(vo2.getHsbdFrngrRgstNo());
				vo.setHsbdNltyCd(vo2.getHsbdNltyCd());
			}
			if("Y".equals(vo2.getWifeFrngrYn()) ){
				vo.setWifeFrngrYn(vo2.getWifeFrngrYn());
				vo.setWifeFrngrRgstNo(vo2.getWifeFrngrRgstNo());
				vo.setWifeNltyCd(vo2.getWifeNltyCd());
			}
		}
		
		//get husband information
		vo.setRsdtSeqNo(vo.getHsbdRsdtSeqNo());
		vo2 = dao.selectDvrcRsdtInfr(vo);
		//setting husband information
		if(null != vo2){
			vo.setHsbdFmlyBokNo(vo2.getFmlyBokNo());
			vo.setHsbdFmlyBokNoDp(vo2.getFmlyBokNoDp());			
			vo.setHsbdRsdtSeqNo(vo2.getRsdtSeqNo());
			vo.setHsbdRsdtNo(vo2.getRsdtNo());
			vo.setHsbdRsdtNoDp(vo2.getRsdtNoDp());
			vo.setHsbdGivNm(vo2.getGivNm());
			vo.setHsbdSurnm(vo2.getSurnm());
			vo.setHsbdEnGivNm(vo2.getEnGivNm());
			vo.setHsbdEnSurnm(vo2.getEnSurnm());
			vo.setHsbdFthrNm(vo2.getFthrNm());
			vo.setHsbdFmlyHadNm(vo2.getHadNm());			
			vo.setHsbdCcltDd(vo2.getCcltDd());
			vo.setHsbdFrngrYn(vo2.getFrngrYn());
			vo.setAppDd(vo2.getAppDd());
			vo.setIsHsbdExp(vo2.getIsExp());
			vo.setHsbdPmntAdCd(vo2.getPmntAdCd());
			vo.setHsbdPmntAdCdNm(vo2.getPmntAdCdNm());
			vo.setHsbdPmntAdDtlCt(vo2.getPmntAdDtlCt());
			vo.setHsbdCurtAdDiv(vo2.getCurtAdDiv());
			vo.setHsbdCurtAdCd(vo2.getCurtAdCd());
			vo.setHsbdCurtAdNatCd(vo2.getCurtAdNatCd());
			vo.setHsbdCurtAdDtlCt(vo2.getCurtAdDtlCt());
			vo.setHsbdSmrRsdcCd(vo2.getSmrRsdcCd());
			vo.setHsbdWtrRsdcCd(vo2.getWtrRsdcCd());			
			vo.setHsbdRlCd(vo2.getRlCd());
			vo.setHsbdRlCdNm(vo2.getRlCdNm());
			vo.setHsbdOthrRl(vo2.getOthrRl());
			vo.setHsbdFmlyHadSeqNo(vo2.getFmlyHadSeqNo());
			vo.setHsbdFmlyHadYn(vo2.getFmlyHadYn());
			
			vo.setHsbdFthrRsdtSeqNo(vo2.getFthrRsdtSeqNo());
			log.debug("입력전 vo.getHsbdNltyCdNm() : "+vo.getHsbdNltyCdNm());
			if(null == vo.getHsbdNltyCdNm() || "".equals(vo.getHsbdNltyCdNm())){
				vo.setHsbdNltyCdNm(vo2.getNltyCdNm());
			}
			log.debug("입력후 vo.getHsbdNltyCdNm() : "+vo.getHsbdNltyCdNm());
			if(null != vo2.getFthrRsdtSeqNo() && !"".equals(vo2.getFthrRsdtSeqNo())){
				vo.setHsbdFthrRlCd(vo2.getFthrRlCd());
				vo.setHsbdFthrFmlyBokNo(vo2.getFthrFmlyBokNo());
				vo.setHsbdFthrFmlyBokNoDp(vo2.getFthrFmlyBokNoDp());				
				vo.setHsbdFthrPmntAdCd(vo2.getFthrPmntAdCd());
				vo.setHsbdFthrPmntAdCdNm(vo2.getFthrPmntAdCdNm());
				vo.setHsbdFthrPmntAdDtlCt(vo2.getFthrPmntAdDtlCt());				
				vo.setHsbdFthrCurtAdDiv(vo2.getFthrCurtAdDiv());
				vo.setHsbdFthrCurtAdCd(vo2.getFthrCurtAdCd());
				vo.setHsbdFthrCurtAdCdNm(vo2.getFthrCurtAdCdNm());
				vo.setHsbdFthrCurtAdNatCd(vo2.getFthrCurtAdNatCd());
				vo.setHsbdFthrCurtAdNatCdNm(vo2.getFthrCurtAdNatCdNm());
				vo.setHsbdFthrCurtAdDtlCt(vo2.getFthrCurtAdDtlCt());
				vo.setHsbdFthrSmrRsdcCd(vo2.getFthrSmrRsdcCd());
				vo.setHsbdFthrSmrRsdcCdNm(vo2.getFthrSmrRsdcCdNm());
				vo.setHsbdFthrWtrRsdcCd(vo2.getFthrWtrRsdcCd());
				vo.setHsbdFthrWtrRsdcCdNm(vo2.getFthrWtrRsdcCdNm());	
				vo.setHsbdFthrFmlyHadYn(vo2.getFthrFmlyHadYn());					
			}
		}
		
		//get wife information
		vo.setRsdtSeqNo(vo.getWifeRsdtSeqNo());
		vo2 = dao.selectDvrcRsdtInfr(vo);
		//setting wife information
		if(null != vo2){
			vo.setWifeFmlyBokNo(vo2.getFmlyBokNo());
			vo.setWifeFmlyBokNoDp(vo2.getFmlyBokNoDp());			
			vo.setWifeRsdtSeqNo(vo2.getRsdtSeqNo());
			vo.setWifeRsdtNo(vo2.getRsdtNo());
			vo.setWifeRsdtNoDp(vo2.getRsdtNoDp());
			vo.setWifeGivNm(vo2.getGivNm());
			vo.setWifeSurnm(vo2.getSurnm());
			vo.setWifeEnGivNm(vo2.getEnGivNm());
			vo.setWifeEnSurnm(vo2.getEnSurnm());
			vo.setWifeFthrNm(vo2.getFthrNm());
			vo.setWifeFmlyHadNm(vo2.getHadNm());
			vo.setWifeCcltDd(vo2.getCcltDd());
			vo.setWifeFrngrYn(vo2.getFrngrYn());
			vo.setAppDd(vo2.getAppDd());
			vo.setIsExp(vo2.getIsExp());
			vo.setWifePmntAdCd(vo2.getPmntAdCd());
			vo.setWifePmntAdCdNm(vo2.getPmntAdCdNm());
			vo.setWifePmntAdDtlCt(vo2.getPmntAdDtlCt());
			vo.setWifeCurtAdDiv(vo2.getCurtAdDiv());
			vo.setWifeCurtAdCd(vo2.getCurtAdCd());
			vo.setWifeCurtAdNatCd(vo2.getCurtAdNatCd());
			vo.setWifeCurtAdDtlCt(vo2.getCurtAdDtlCt());
			vo.setWifeSmrRsdcCd(vo2.getSmrRsdcCd());
			vo.setWifeWtrRsdcCd(vo2.getWtrRsdcCd());			
			vo.setWifeRlCd(vo2.getRlCd());
			vo.setWifeRlCdNm(vo2.getRlCdNm());
			vo.setWifeOthrRl(vo2.getOthrRl());
			vo.setWifeFmlyHadSeqNo(vo2.getFmlyHadSeqNo());	
			vo.setWifeFmlyHadYn(vo2.getFmlyHadYn());
						
			vo.setWifeFthrRsdtSeqNo(vo2.getFthrRsdtSeqNo());
			if(null == vo.getWifeNltyCdNm() || "".equals(vo.getWifeNltyCdNm())){
				vo.setWifeNltyCdNm(vo2.getNltyCdNm());
			}
			if(null != vo2.getFthrRsdtSeqNo() && !"".equals(vo2.getFthrRsdtSeqNo())){
				vo.setWifeFthrRlCd(vo2.getFthrRlCd());
				vo.setWifeFthrFmlyBokNo(vo2.getFthrFmlyBokNo());
				vo.setWifeFthrFmlyBokNoDp(vo2.getFthrFmlyBokNoDp());
				vo.setWifeFthrSurnm(vo2.getFthrSurnm());
				vo.setWifeFthrEnSurnm(vo2.getFthrEnSurnm());
				vo.setWifeFthrPmntAdCd(vo2.getFthrPmntAdCd());
				vo.setWifeFthrPmntAdCdNm(vo2.getFthrPmntAdCdNm());
				vo.setWifeFthrPmntAdDtlCt(vo2.getFthrPmntAdDtlCt());
				vo.setWifeFthrCurtAdDiv(vo2.getFthrCurtAdDiv());
				vo.setWifeFthrCurtAdCd(vo2.getFthrCurtAdCd());
				vo.setWifeFthrCurtAdCdNm(vo2.getFthrCurtAdCdNm());
				vo.setWifeFthrCurtAdNatCd(vo2.getFthrCurtAdNatCd());
				vo.setWifeFthrCurtAdNatCdNm(vo2.getFthrCurtAdNatCdNm());
				vo.setWifeFthrCurtAdDtlCt(vo2.getFthrCurtAdDtlCt());
				vo.setWifeFthrSmrRsdcCd(vo2.getFthrSmrRsdcCd());
				vo.setWifeFthrSmrRsdcCdNm(vo2.getFthrSmrRsdcCdNm());
				vo.setWifeFthrWtrRsdcCd(vo2.getFthrWtrRsdcCd());
				vo.setWifeFthrWtrRsdcCdNm(vo2.getFthrWtrRsdcCdNm());
				vo.setWifeFthrFmlyHadYn(vo2.getFthrFmlyHadYn());
			}
		}
		
		String canHsbdAdChangYn = "N";
		String hsbdAdChangeMsg = "";
		
		if("N".equals(vo.getHsbdFrngrYn())){
			
			//check Revocation Apply status
			log.debug("남편 주민 시퀀스 넘버 : "+ vo.getHsbdRsdtSeqNo());
			int ccltCnt = dao.selectRsdtCcltStus(vo.getHsbdRsdtSeqNo());
			if(ccltCnt != 0){
				vo = new DvrcVO();
				vo.setErrMsg("nRgstByHsbdCcltApl.msg");
				return vo;
			}
			
			//check Husband Apply status
			String cardStatus = rsdtInfoService.searchRsdtCrdIsuAppStus(vo.getHsbdRsdtNo(), "msg", "");
			
			//check Husband Card Issuance history
			int isuCnt = rsdtInfoService.searchRsdtCrdIsuStus(vo.getHsbdRsdtNo());
			
			if("".equals(cardStatus) && "N".equals(vo.getIsHsbdExp())&& 0 < isuCnt){
				canHsbdAdChangYn = "Y";
			}else if(0 >= isuCnt){
				hsbdAdChangeMsg =  nidMessageSource.getMessage("fstCrdIsuceCdd.msg");
			}else if(!"".equals(cardStatus)){
				hsbdAdChangeMsg =  nidMessageSource.getMessage(cardStatus);
			}else if(!"N".equals(vo.getIsHsbdExp())){
				String month = vo.getCrdReisuceDmBfExpr(); 
				if(!"3".equals(vo.getUseLangCd())){
					month =	NidStringUtil.toNumberConvet(month, "J");
				}
				hsbdAdChangeMsg =  nidMessageSource.getMessage("crdExpReisuce.msg", new String[]{month});
			}
		}
		
		String canNameChangeYn = "N";
		String nameChangeMsg = "";
		
		if("N".equals(vo.getWifeFrngrYn())){
			
			//check Revocation Apply status
			log.debug("Wife 주민 시퀀스 넘버 : "+ vo.getWifeRsdtSeqNo());
			int ccltCnt = dao.selectRsdtCcltStus(vo.getWifeRsdtSeqNo());
			if(ccltCnt != 0){
				vo = new DvrcVO();
				vo.setErrMsg("nRgstByWifeCcltApl.msg");
				return vo;
			}
			
			//check Apply status
			String cardStatus = rsdtInfoService.searchRsdtCrdIsuAppStus(vo.getWifeRsdtNo(), "msg", "");
			
			//check Card Issuance history
			int isuCnt = rsdtInfoService.searchRsdtCrdIsuStus(vo.getWifeRsdtNo());

			if("".equals(cardStatus) && "N".equals(vo.getIsExp())&& 0 < isuCnt){
				canNameChangeYn = "Y";
			}else if(0 >= isuCnt){
				nameChangeMsg =  nidMessageSource.getMessage("fstCrdIsuceCdd.msg");
			}else if(!"".equals(cardStatus)){
				nameChangeMsg =  nidMessageSource.getMessage(cardStatus);
			}else if(!"N".equals(vo2.getIsExp())){
				String month = vo.getCrdReisuceDmBfExpr(); 
				if(!"3".equals(vo.getUseLangCd())){
					month =	NidStringUtil.toNumberConvet(month, "J");
				}
				nameChangeMsg =  nidMessageSource.getMessage("crdExpReisuce.msg", new String[]{month});
			}
		}
		
		vo.setCanHsbdAdChangYn(canHsbdAdChangYn);
		vo.setHsbdAdChangeMsg(hsbdAdChangeMsg);
		vo.setCanNameChangeYn(canNameChangeYn);
		vo.setNameChangeMsg(nameChangeMsg);
					
		return vo;
	}    
	
	/**
	 * Biz-method for retrieving list of Divorce information. <br>
	 * 
	 * @param vo Input item for retrieving list of Divorce information(DvrcVO).
	 * @return List Retrieve list of Divorce information
	 * @exception Exception
	 */
	public List<DvrcVO> searchListMrrgInfr(DvrcVO vo) throws Exception {		
   		return dao.selectListMrrgInfr(vo);
	}
	
	/**
	 * Biz-method for Register information of Divorce. <br>
	 * 
	 * @param vo Input item for Register information of Divorce.(DvrcVO).
	 * @return String Divorce Seq No.
	 * @exception Exception
	 */
	public String addDvrcInfr(DvrcVO vo) throws Exception {		
   		
		boolean flag = false;

		//result R: reissuance, W:rewrite, N: none
		String mResult = searchResultOfCrdInfrChang(vo, "M");
		if("R".equals(mResult)){
			flag = true;	
		}
		
		String fResult = searchResultOfCrdInfrChang(vo, "F");
		if("R".equals(fResult)){
			flag = true;	
		}
		
		if(!flag){
			vo.setCrdReisuceDueDd("");
		}
		
		
		return dao.insertDvrcInfr(vo);
	}
	
	/**
	 * Biz-method for Retrieves Divorce Information for Divorce update. <br>
	 * 
	 * @param vo Input item for retrieving Marriage RSDT_SEQ_NO(DvrcVO).
	 * @return DvrcVO Retrieve Divorce Information
	 * @exception Exception
	 */
	public DvrcVO searchDvrcInfr(DvrcVO dvrcVO) throws Exception {		
		
		String dvrcSeqNo = dvrcVO.getDvrcSeqNo();
		DvrcVO vo2 = dao.selectDvrcInfr(dvrcVO);
		
		DvrcVO vo = new DvrcVO();
		vo.setDvrcSeqNo(dvrcSeqNo);
		//check Enid Number (Exist or Not)
		if( null == vo2 ){
			vo.setErrMsg("nRgstEnid.msg");
			return vo;
		}
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUserId(user.getUserId());
		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd();
		vo.setRgstOrgnzCd( orgnzCd );
		vo.setUseLangCd(user.getUseLangCd()); 
		int crdReisuceDmBfExpr = propertiesService.getInt("crdReisuceDmBfExpr");
		vo.setCrdReisuceDmBfExpr(String.valueOf(crdReisuceDmBfExpr));
		int crdDlvrDd = propertiesService.getInt("crdDlvrDd");
		vo.setCrdDlvrDd(String.valueOf(crdDlvrDd));
		
		vo.setRsdtSeqNo(vo2.getRsdtSeqNo());
		vo.setGdrCd(vo2.getGdrCd());
		
		//Check Count of Divorce Application
		if("1".equals(vo2.getGdrCd())){
			
			int hsbdRgstCn = Integer.parseInt(vo2.getHsbdRgstCn());
			
			if(hsbdRgstCn == 1 || !"".equals(dvrcSeqNo)){
				vo = dao.selectDvrcDtlInfr(vo);
			}else if(hsbdRgstCn > 1){
				vo.setMrrgCn(vo2.getHsbdRgstCn());
				vo.setHsbdRsdtSeqNo(vo2.getRsdtSeqNo());
				return vo;
			}else{
				vo.setErrMsg("nDvrcHst.msg");
				return vo;
			}
			
		}else{
			int wifeRgstCn = Integer.parseInt(vo2.getWifeRgstCn());
			
			if(wifeRgstCn == 1){
				vo = dao.selectDvrcDtlInfr(vo);
			}else{
				vo.setErrMsg("nDvrcHst.msg");
				return vo;
			}
		}
		
		if( !vo.getRgstOrgnzCd().startsWith(orgnzCd)  ){
			vo.setErrMsg("rgstOthrOfic.msg");
			vo.setErrMsgVal(new String[]{vo2.getRgstOrgnzCdNm()});
			vo.setMrrgCn("0");
			return vo;
		}
		vo.setMrrgCn("1");
		vo.setUseLangCd(user.getUseLangCd());
		vo.setCrdReisuceDmBfExpr(String.valueOf(crdReisuceDmBfExpr));
		
		//Setting husband's father information
		vo.setRsdtSeqNo(vo.getHsbdRsdtSeqNo());
		vo2 = dao.selectDvrcRsdtInfr(vo);
		vo.setHsbdPmntAdCd(vo2.getPmntAdCd());
		vo.setHsbdPmntAdCdNm(vo2.getPmntAdCdNm());
		vo.setHsbdPmntAdDtlCt(vo2.getPmntAdDtlCt());
		vo.setHsbdCurtAdDiv(vo2.getCurtAdDiv());
		vo.setHsbdCurtAdCd(vo2.getCurtAdCd());
		vo.setHsbdCurtAdNatCd(vo2.getCurtAdNatCd());
		vo.setHsbdCurtAdDtlCt(vo2.getCurtAdDtlCt());
		vo.setHsbdSmrRsdcCd(vo2.getSmrRsdcCd());
		vo.setHsbdWtrRsdcCd(vo2.getWtrRsdcCd());
		
		vo.setHsbdFthrRsdtSeqNo(vo2.getFthrRsdtSeqNo());
		if(null != vo2.getFthrRsdtSeqNo() && !"".equals(vo2.getFthrRsdtSeqNo())){
			vo.setHsbdFthrRlCd(vo2.getFthrRlCd());
			vo.setHsbdFthrFmlyBokNo(vo2.getFthrFmlyBokNo());
			vo.setHsbdFthrFmlyBokNoDp(vo2.getFthrFmlyBokNoDp());			
			vo.setHsbdFthrPmntAdCd(vo2.getFthrPmntAdCd());
			vo.setHsbdFthrPmntAdCdNm(vo2.getFthrPmntAdCdNm());
			vo.setHsbdFthrPmntAdDtlCt(vo2.getFthrPmntAdDtlCt());			
			vo.setHsbdFthrCurtAdDiv(vo2.getFthrCurtAdDiv());
			vo.setHsbdFthrCurtAdCd(vo2.getFthrCurtAdCd());
			vo.setHsbdFthrCurtAdCdNm(vo2.getFthrCurtAdCdNm());
			vo.setHsbdFthrCurtAdNatCd(vo2.getFthrCurtAdNatCd());
			vo.setHsbdFthrCurtAdNatCdNm(vo2.getFthrCurtAdNatCdNm());
			vo.setHsbdFthrCurtAdDtlCt(vo2.getFthrCurtAdDtlCt());
			vo.setHsbdFthrSmrRsdcCd(vo2.getFthrSmrRsdcCd());
			vo.setHsbdFthrSmrRsdcCdNm(vo2.getFthrSmrRsdcCdNm());
			vo.setHsbdFthrWtrRsdcCd(vo2.getFthrWtrRsdcCd());
			vo.setHsbdFthrWtrRsdcCdNm(vo2.getFthrWtrRsdcCdNm());
			vo.setHsbdFthrFmlyHadYn(vo2.getFthrFmlyHadYn());
		}
		
		//Setting wife's father information
		vo.setRsdtSeqNo(vo.getWifeRsdtSeqNo());
		vo2 = dao.selectDvrcRsdtInfr(vo);
		vo.setWifePmntAdCd(vo2.getPmntAdCd());
		vo.setWifePmntAdCdNm(vo2.getPmntAdCdNm());
		vo.setWifePmntAdDtlCt(vo2.getPmntAdDtlCt());
		vo.setWifeCurtAdDiv(vo2.getCurtAdDiv());
		vo.setWifeCurtAdCd(vo2.getCurtAdCd());
		vo.setWifeCurtAdNatCd(vo2.getCurtAdNatCd());
		vo.setWifeCurtAdDtlCt(vo2.getCurtAdDtlCt());
		vo.setWifeSmrRsdcCd(vo2.getSmrRsdcCd());
		vo.setWifeWtrRsdcCd(vo2.getWtrRsdcCd());	
		
		vo.setWifeFthrRsdtSeqNo(vo2.getFthrRsdtSeqNo());
		if(null != vo2.getFthrRsdtSeqNo() && !"".equals(vo2.getFthrRsdtSeqNo())){
			vo.setWifeFthrRlCd(vo2.getFthrRlCd());
			vo.setWifeFthrFmlyBokNo(vo2.getFthrFmlyBokNo());
			vo.setWifeFthrFmlyBokNoDp(vo2.getFthrFmlyBokNoDp());
			vo.setWifeFthrSurnm(vo2.getFthrSurnm());
			vo.setWifeFthrEnSurnm(vo2.getFthrEnSurnm());
			vo.setWifeFthrPmntAdCd(vo2.getFthrPmntAdCd());
			vo.setWifeFthrPmntAdCdNm(vo2.getFthrPmntAdCdNm());
			vo.setWifeFthrPmntAdDtlCt(vo2.getFthrPmntAdDtlCt());
			vo.setWifeFthrCurtAdDiv(vo2.getFthrCurtAdDiv());
			vo.setWifeFthrCurtAdCd(vo2.getFthrCurtAdCd());
			vo.setWifeFthrCurtAdCdNm(vo2.getFthrCurtAdCdNm());
			vo.setWifeFthrCurtAdNatCd(vo2.getFthrCurtAdNatCd());
			vo.setWifeFthrCurtAdNatCdNm(vo2.getFthrCurtAdNatCdNm());
			vo.setWifeFthrCurtAdDtlCt(vo2.getFthrCurtAdDtlCt());
			vo.setWifeFthrSmrRsdcCd(vo2.getFthrSmrRsdcCd());
			vo.setWifeFthrSmrRsdcCdNm(vo2.getFthrSmrRsdcCdNm());
			vo.setWifeFthrWtrRsdcCd(vo2.getFthrWtrRsdcCd());
			vo.setWifeFthrWtrRsdcCdNm(vo2.getFthrWtrRsdcCdNm());
			vo.setWifeFthrFmlyHadYn(vo2.getFthrFmlyHadYn());
		}
		
		String canHsbdAdChangYn ="N";
		String hsbdAdChangeMsg = "";
		
		if("N".equals(vo.getHsbdFrngrYn())){
			String cardStatus = rsdtInfoService.searchRsdtCrdIsuAppStus(vo.getHsbdRsdtNo(), "msg", "d");
			int isuCnt = rsdtInfoService.searchRsdtCrdIsuStus(vo.getHsbdRsdtNo());

			if("".equals(cardStatus) && "N".equals(vo.getIsHsbdExp())&& 0 < isuCnt){
				canHsbdAdChangYn = "Y";
			}else if(0 >= isuCnt){
				hsbdAdChangeMsg =  nidMessageSource.getMessage("fstCrdIsuceCdd.msg");
			}else if(!"".equals(cardStatus)){
				hsbdAdChangeMsg =  nidMessageSource.getMessage(cardStatus);
			}else if(!"N".equals(vo.getIsHsbdExp())){
				String month = vo.getCrdReisuceDmBfExpr(); 
				if(!"3".equals(vo.getUseLangCd())){
					month =	NidStringUtil.toNumberConvet(month, "J");
				}
				hsbdAdChangeMsg =  nidMessageSource.getMessage("crdExpReisuce.msg", new String[]{month});
			}
		}
		
		String canNameChangeYn = "N";
		String nameChangeMsg = "";
		if("N".equals(vo.getWifeFrngrYn())){
			String pmntAdCd= searchWifePmntAdCd(vo.getWifeRsdtSeqNo());
			vo.setWifePmntAdCd(pmntAdCd);
			
			String cardStatus = rsdtInfoService.searchRsdtCrdIsuAppStus(vo.getWifeRsdtNo(), "msg", "d");
			int isuCnt = rsdtInfoService.searchRsdtCrdIsuStus(vo.getWifeRsdtNo());
			
			if("".equals(cardStatus) && "N".equals(vo.getIsExp())&& 0 < isuCnt){
				canNameChangeYn = "Y";
			}else if(0 >= isuCnt){
				nameChangeMsg =  nidMessageSource.getMessage("fstCrdIsuceCdd.msg");
			}else if(!"".equals(cardStatus)){
				nameChangeMsg =  nidMessageSource.getMessage(cardStatus);
			}else if(!"N".equals(vo.getIsExp())){
				String month = vo.getCrdReisuceDmBfExpr(); 
				if(!"3".equals(vo.getUseLangCd())){
					month =	NidStringUtil.toNumberConvet(month, "J");
				}
				nameChangeMsg =  nidMessageSource.getMessage("crdExpReisuce.msg", new String[]{month});
			}
		}
		
		vo.setCanHsbdAdChangYn(canHsbdAdChangYn);
		vo.setHsbdAdChangeMsg(hsbdAdChangeMsg);
		vo.setCanNameChangeYn(canNameChangeYn);
		vo.setNameChangeMsg(nameChangeMsg);
	  					
		return vo;
	} 
	
	/**
	 * Biz-method for retrieving list of Divorce information. <br>
	 * 
	 * @param vo Input item for retrieving list of Divorce information(DvrcVO).
	 * @return List Retrieve list of Divorce information
	 * @exception Exception
	 */
	public List<DvrcVO> searchListDvrcInfr(DvrcVO vo) throws Exception {		
   		return dao.selectListDvrcInfr(vo);
	}
	
	/**
	 * Biz-method for modifying divorce information. <br>
	 * 
	 * @param vo Input item for modifying divorce information(DvrcVO).
	 * @return int Result Count
	 * @exception Exception
	 */
	public int modifyDvrcInfr(DvrcVO vo) throws Exception {		
		int result = 0;
		
		boolean flag = false;

		//result R: reissuance, W:rewrite, N: none
		String mResult = searchResultOfCrdInfrChang(vo, "M");
		if("R".equals(mResult)){
			flag = true;	
		}
		
		String fResult = searchResultOfCrdInfrChang(vo, "F");
		if("R".equals(fResult)){
			flag = true;	
		}
		
		if(!flag){
			vo.setCrdReisuceDueDd("");
		}
		
		result = dao.updateDvrcInfr(vo);
		
		return result;
	}
	
	/**
	 * Biz-method for retrieving list of Divorce information. <br>
	 * 
	 * @param vo Input item for retrieving list of Divorce information(DvrcVO).
	 * @return List Retrieve list of Divorce information
	 * @exception Exception
	 */
	public DvrcVO searchDvrcAprvInfr(DvrcVO vo) throws Exception {		
   		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUserId(user.getUserId());
		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
		vo.setRgstOrgnzCd( orgnzCd );
		vo.setUseLangCd(user.getUseLangCd());
		
		int crdReisuceDmBfExpr = propertiesService.getInt("crdReisuceDmBfExpr");
		vo.setCrdReisuceDmBfExpr(String.valueOf(crdReisuceDmBfExpr));
		int crdDlvrDd = propertiesService.getInt("crdDlvrDd");
		vo.setCrdDlvrDd(String.valueOf(crdDlvrDd));
		
		DvrcVO result = dao.selectDvrcAprvInfr(vo);

		//Setting husband's father information
		vo.setRsdtSeqNo(result.getHsbdRsdtSeqNo());
		DvrcVO vo2 = dao.selectDvrcRsdtInfr(vo);
		result.setHsbdPmntAdCd(vo2.getPmntAdCd());
		result.setHsbdPmntAdCdNm(vo2.getPmntAdCdNm());
		result.setHsbdPmntAdDtlCt(vo2.getPmntAdDtlCt());
		result.setHsbdCurtAdDiv(vo2.getCurtAdDiv());
		result.setHsbdCurtAdCd(vo2.getCurtAdCd());
		result.setHsbdCurtAdNatCd(vo2.getCurtAdNatCd());
		result.setHsbdCurtAdDtlCt(vo2.getCurtAdDtlCt());
		result.setHsbdSmrRsdcCd(vo2.getSmrRsdcCd());
		result.setHsbdWtrRsdcCd(vo2.getWtrRsdcCd());
		result.setHsbdFthrRsdtSeqNo(vo2.getFthrRsdtSeqNo());
		
		if(null != vo2.getFthrRsdtSeqNo() && !"".equals(vo2.getFthrRsdtSeqNo())){
			result.setHsbdFthrRlCd(vo2.getFthrRlCd());
			result.setHsbdFthrFmlyBokNo(vo2.getFthrFmlyBokNo());
			result.setHsbdFthrFmlyBokNoDp(vo2.getFthrFmlyBokNoDp());			
			result.setHsbdFthrPmntAdCd(vo2.getFthrPmntAdCd());
			result.setHsbdFthrPmntAdCdNm(vo2.getFthrPmntAdCdNm());
			result.setHsbdFthrPmntAdDtlCt(vo2.getFthrPmntAdDtlCt());
			result.setHsbdFthrCurtAdDiv(vo2.getFthrCurtAdDiv());
			result.setHsbdFthrCurtAdCd(vo2.getFthrCurtAdCd());
			result.setHsbdFthrCurtAdCdNm(vo2.getFthrCurtAdCdNm());
			result.setHsbdFthrCurtAdNatCd(vo2.getFthrCurtAdNatCd());
			result.setHsbdFthrCurtAdNatCdNm(vo2.getFthrCurtAdNatCdNm());
			result.setHsbdFthrCurtAdDtlCt(vo2.getFthrCurtAdDtlCt());
			result.setHsbdFthrSmrRsdcCd(vo2.getFthrSmrRsdcCd());
			result.setHsbdFthrSmrRsdcCdNm(vo2.getFthrSmrRsdcCdNm());
			result.setHsbdFthrWtrRsdcCd(vo2.getFthrWtrRsdcCd());
			result.setHsbdFthrWtrRsdcCdNm(vo2.getFthrWtrRsdcCdNm());
			result.setHsbdFthrFmlyHadYn(vo2.getFthrFmlyHadYn());
		}
		
		vo.setRsdtSeqNo(result.getWifeRsdtSeqNo());
		vo2 = dao.selectDvrcRsdtInfr(vo);
		result.setWifePmntAdCd(vo2.getPmntAdCd());
		result.setWifePmntAdCdNm(vo2.getPmntAdCdNm());
		result.setWifePmntAdDtlCt(vo2.getPmntAdDtlCt());
		result.setWifeCurtAdDiv(vo2.getCurtAdDiv());
		result.setWifeCurtAdCd(vo2.getCurtAdCd());
		result.setWifeCurtAdNatCd(vo2.getCurtAdNatCd());
		result.setWifeCurtAdDtlCt(vo2.getCurtAdDtlCt());
		result.setWifeSmrRsdcCd(vo2.getSmrRsdcCd());
		result.setWifeWtrRsdcCd(vo2.getWtrRsdcCd());
		
		result.setWifeFthrRsdtSeqNo(vo2.getFthrRsdtSeqNo());
		
		if(null != vo2.getFthrRsdtSeqNo() && !"".equals(vo2.getFthrRsdtSeqNo())){	
			result.setWifeFthrRlCd(vo2.getFthrRlCd());
			result.setWifeFthrFmlyBokNo(vo2.getFthrFmlyBokNo());
			result.setWifeFthrFmlyBokNoDp(vo2.getFthrFmlyBokNoDp());
			result.setWifeFthrSurnm(vo2.getFthrSurnm());
			result.setWifeFthrEnSurnm(vo2.getFthrEnSurnm());
			result.setWifeFthrPmntAdCd(vo2.getFthrPmntAdCd());
			result.setWifeFthrPmntAdCdNm(vo2.getFthrPmntAdCdNm());
			result.setWifeFthrPmntAdDtlCt(vo2.getFthrPmntAdDtlCt());
			result.setWifeFthrCurtAdDiv(vo2.getFthrCurtAdDiv());
			result.setWifeFthrCurtAdCd(vo2.getFthrCurtAdCd());
			result.setWifeFthrCurtAdCdNm(vo2.getFthrCurtAdCdNm());
			result.setWifeFthrCurtAdNatCd(vo2.getFthrCurtAdNatCd());
			result.setWifeFthrCurtAdNatCdNm(vo2.getFthrCurtAdNatCdNm());
			result.setWifeFthrCurtAdDtlCt(vo2.getFthrCurtAdDtlCt());
			result.setWifeFthrSmrRsdcCd(vo2.getFthrSmrRsdcCd());
			result.setWifeFthrSmrRsdcCdNm(vo2.getFthrSmrRsdcCdNm());
			result.setWifeFthrWtrRsdcCd(vo2.getFthrWtrRsdcCd());
			result.setWifeFthrWtrRsdcCdNm(vo2.getFthrWtrRsdcCdNm());
			result.setWifeFthrFmlyHadYn(vo2.getFthrFmlyHadYn());
		}

		String canHsbdAdChangYn ="N";
		String hsbdAdChangeMsg = "";
		if("N".equals(result.getHsbdFrngrYn())){
			String cardStatus = rsdtInfoService.searchRsdtCrdIsuAppStus(result.getHsbdRsdtNo(), "msg", "d");
			int isuCnt = rsdtInfoService.searchRsdtCrdIsuStus(result.getHsbdRsdtNo());

			if("".equals(cardStatus) && "N".equals(result.getIsHsbdExp())&& 0 < isuCnt){
				canHsbdAdChangYn = "Y";
			}else if(0 >= isuCnt){
				hsbdAdChangeMsg =  nidMessageSource.getMessage("fstCrdIsuceCdd.msg");
			}else if(!"".equals(cardStatus)){
				hsbdAdChangeMsg =  nidMessageSource.getMessage(cardStatus);
			}else if(!"N".equals(result.getIsHsbdExp())){
				String month = vo.getCrdReisuceDmBfExpr(); 
				if(!"3".equals(vo.getUseLangCd())){
					month =	NidStringUtil.toNumberConvet(month, "J");
				}
				hsbdAdChangeMsg =  nidMessageSource.getMessage("crdExpReisuce.msg", new String[]{month});
			}
		}
		
		String canNameChangeYn = "N";
		String nameChangeMsg = "";
		if("N".equals(result.getWifeFrngrYn())){
			String pmntAdCd= searchWifePmntAdCd(result.getWifeRsdtSeqNo());
			result.setWifePmntAdCd(pmntAdCd);
			
			String cardStatus = rsdtInfoService.searchRsdtCrdIsuAppStus(result.getWifeRsdtNo(), "msg", "d");
			int isuCnt = rsdtInfoService.searchRsdtCrdIsuStus(result.getWifeRsdtNo());

			if("".equals(cardStatus) && "N".equals(result.getIsExp())&& 0 < isuCnt){
				canNameChangeYn = "Y";
			}else if(0 >= isuCnt){
				nameChangeMsg =  nidMessageSource.getMessage("fstCrdIsuceCdd.msg");
			}else if(!"".equals(cardStatus)){
				nameChangeMsg =  nidMessageSource.getMessage(cardStatus);
			}else if(!"N".equals(result.getIsExp())){
				String month = vo.getCrdReisuceDmBfExpr(); 
				if(!"3".equals(vo.getUseLangCd())){
					month =	NidStringUtil.toNumberConvet(month, "J");
				}
				nameChangeMsg =  nidMessageSource.getMessage("crdExpReisuce.msg", new String[]{month});
			}
		}
		
		result.setCanHsbdAdChangYn(canHsbdAdChangYn);
		result.setHsbdAdChangeMsg(hsbdAdChangeMsg);
		result.setCanNameChangeYn(canNameChangeYn);
		result.setNameChangeMsg(nameChangeMsg);			
		
		return result;
	} 	
	
	/**
	 * Biz-method for retrieving list of Divorce information. <br>
	 * 
	 * @param vo Input item for retrieving list of Divorce information(DvrcVO).
	 * @return List Retrieve list of Divorce information
	 * @exception Exception
	 */
	public Map<String,String> approveDvrcInfr(DvrcVO vo) throws Exception {		

		//Update 
		int resultUpdate = modifyDvrcInfr( vo );    		
		if(1 != resultUpdate){
			throw processException( "udtFail.msg");
		} 
		
		//divorce table update
		boolean dvrcResult = dao.updateDvrcAprvInfr( vo );
		
		if(!dvrcResult){
			throw processException( "udtFail.msg");
		}
		
		Map<String,String> map = new HashMap<String,String>(); 
		boolean updateResult = false;
		boolean isCadIsuce = false;
		String rvctgStusH = "";
		String rvctgStusW = "";
		String crdExpYnH = "N";
		String crdExpYnW = "N";
		String mResult = "";
		String fResult = "";
		
		log.debug("vo.getDvrcKndCd() : " + vo.getDvrcKndCd());
		
		if("N".equals(vo.getHsbdFrngrYn())){			
			
			//husband:domestic		
			int mrrgCnt = dao.selectMrrgCnt(vo);
		
			if(mrrgCnt == 0|| "Y".equals(vo.getHsbdCurtAdChngYn()) || "Y".equals(vo.getHsbdPmntAdChngYn())|| "Y".equals(vo.getHsbdRlChngYn()) || "Y".equals(vo.getHsbdFmlyBokMvYn()) ) {	// husband information modify				
				String hsbdRsdtSeqNo = vo.getHsbdRsdtSeqNo();
				//resident history update
				rsdtInfoDAO.insertRsdtInfrHst(hsbdRsdtSeqNo, vo.getUserId() );
				log.debug("=======Husband is Domestic ====");
				
				if(mrrgCnt == 0){
					if("3".equals(vo.getDvrcKndCd())){
						vo.setMrrgCd("3");
					}else{
						vo.setMrrgCd("4");
					}
				}else{
					vo.setMrrgCd("1");
				}
				
				//Getting family form information
				if("Y".equals(vo.getHsbdFmlyBokMvYn())){
					DvrcVO result= dao.selectFmlyBokInfr(vo.getAfHsbdFmlyBokNo());
					if(null != result){
						vo.setFmlyBokSeqNo(result.getFmlyBokSeqNo());
						vo.setFmlyMberNo(result.getFmlyMberNo());
						vo.setFmlyBokNo(result.getFmlyBokNo());
					}
				}
				
				//result R: reissuance, W:rewrite, N: none
				mResult = searchResultOfCrdInfrChang(vo, "M");
				
				//check for  husband Citizen Revocation Status
				if(!"N".equals(mResult)){	
					rvctgStusH = rsdtInfoService.searchRsdtRvctgStus(vo.getHsbdRsdtNo(), "code");	
				}
				
				//check husband card expiration Status.
				crdExpYnH = dao.selectCrdExpStus(vo.getHsbdRsdtSeqNo());
				vo.setCrdIsuceYn("N");
				if("R".equals(mResult) ){
					if("".equals(rvctgStusH) &&"N".equals(crdExpYnH)){
						isCadIsuce = true;
						vo.setCrdIsuceYn("Y");
					}else{
						log.debug("=======NO Insert husband card reissuance==== by : "+rvctgStusH);
						isCadIsuce = false;
						vo.setCrdIsuceYn("N");
					}
				}
				
				//resident table update
				vo.setRsdtSeqNo(hsbdRsdtSeqNo);
				vo.setSearchKeyword10("N");
				updateResult = dao.updateRsdtInfr(vo);
				vo.setSearchKeyword10("");
				
				if(!updateResult){
					throw processException( "udtFail.msg");
				}
				
				//Check card issuance
				if("R".equals(mResult)){
					if(isCadIsuce){
						log.debug("=======Insert husband card reissuance infromation====");
						vo.setRsdtNo( vo.getHsbdRsdtNo() );					
						dao.insertCrdIsuInfr( vo );
					}
				}
				
				//Update Signature Data to RM_RSDT_TB
				rsdtInfoService.updateDigitalSgnt(hsbdRsdtSeqNo, vo.getHsbdSgnt(), "5");	
			}
		}
		
		if("N".equals(vo.getWifeFrngrYn())){
			//wife: domestic
			log.debug("=======Wife is Domestic ====");
			
			String wifeRsdtSeqNo = vo.getWifeRsdtSeqNo();

			//resident history update
			rsdtInfoDAO.insertRsdtInfrHst(wifeRsdtSeqNo, vo.getUserId() );
			
			vo.setRsdtSeqNo(wifeRsdtSeqNo);
			if("3".equals(vo.getDvrcKndCd())){
				vo.setMrrgCd("3");
			}else{
				vo.setMrrgCd("4");
			}
			
			//Getting family form information
			if("Y".equals(vo.getWifeFmlyBokMvYn())){
				DvrcVO result= dao.selectFmlyBokInfr(vo.getAfWifeFmlyBokNo());
				if(null != result){
					vo.setFmlyBokSeqNo(result.getFmlyBokSeqNo());
					vo.setFmlyMberNo(result.getFmlyMberNo());
					vo.setFmlyBokNo(result.getFmlyBokNo());
				}
			}
			
			//result R: reissuance, W:rewrite, N: none
			fResult = searchResultOfCrdInfrChang(vo, "F");
			
			//check for  wife Citizen Revocation Status
			if(!"N".equals(fResult)){			
				rvctgStusW = rsdtInfoService.searchRsdtRvctgStus(vo.getWifeRsdtNo(), "code");
			}
			
			//check wife card expiration Status.
			crdExpYnW = dao.selectCrdExpStus(vo.getWifeRsdtSeqNo());
			vo.setCrdIsuceYn("N");
			isCadIsuce = false;
			if("R".equals(fResult) ){
				if("".equals(rvctgStusW) &&"N".equals(crdExpYnW)){
					isCadIsuce = true;
					vo.setCrdIsuceYn("Y");
				}else{
					log.debug("=======NO Insert wife card reissuance==== by : "+rvctgStusW);
					isCadIsuce = false;
					vo.setCrdIsuceYn("N");
				}
			}

			//resident table update
			vo.setSearchKeyword10("Y");
			updateResult = dao.updateRsdtInfr(vo);
			vo.setSearchKeyword10("");
			
			if(!updateResult){
				throw processException( "udtFail.msg");
			}
				
			//Update Signature Data to RM_RSDT_TB
			rsdtInfoService.updateDigitalSgnt(wifeRsdtSeqNo, vo.getWifeSgnt(), "5");

			if("R".equals(fResult)){
				if(isCadIsuce){
					log.debug("=======Insert wife card reissuance infromation====");
					vo.setRsdtNo( vo.getWifeRsdtNo() );
					dao.insertCrdIsuInfr( vo );
				}
				
			}

		}else{
			//wife: foreign
			log.debug("=======Wife is foreigner ====");
			vo.setMrrgCd("");
			vo.setRsdtSeqNo( vo.getWifeRsdtSeqNo());
			//resident table update
			vo.setSearchKeyword10("Y");
			updateResult = dao.updateRsdtInfr(vo);
			vo.setSearchKeyword10("");
		}
		
		map.put("dsuseMsg","");
		StringBuffer strBf = null;
		StringBuffer flMsg = new StringBuffer();
		if("R".equals(mResult)){
			log.debug("==========Husband Start kill card=======================");
			strBf = new StringBuffer();
			List<String> OrgList =crdFndService.modifyCrdFndPrcssStus(vo.getHsbdRsdtNo(), "4", "", "47");
			for(int i=0; i < OrgList.size(); i++){
				if(i == 0){
					strBf.append(OrgList.get(i));
				}else{
					strBf.append(", ").append(OrgList.get(i));
				}	
			}
			
			if(0 < OrgList.size()){
				flMsg.append(nidMessageSource.getMessage("hsbd")).append(" : " );
				flMsg.append(nidMessageSource.getMessage("rgstDuseObjt.msg",new String[]{strBf.toString()})); //Message Setting
			}
		}
		
		//Wife's found card Kill by card reissuance 
		if("R".equals(fResult)){
			log.debug("==========Wife Start kill card=======================");
			strBf = new StringBuffer();
			List<String> OrgList =crdFndService.modifyCrdFndPrcssStus(vo.getWifeRsdtNo(), "4", "", "47");
			for(int i=0; i < OrgList.size(); i++){
				if(i == 0){
					strBf.append(OrgList.get(i));
				}else{
					strBf.append(", ").append(OrgList.get(i));
				}	
			}
			
			if(0 < OrgList.size()){
				if(0 < flMsg.length()){
					flMsg.append("\\r\\n\\r\\n");
				}
				flMsg.append(nidMessageSource.getMessage("wife")).append(" : " );
				flMsg.append(nidMessageSource.getMessage("rgstDuseObjt.msg",new String[]{strBf.toString()}));			
			}
		}
		log.debug("==========Full flMsg :" +flMsg.toString());
		map.put("dsuseMsg", flMsg.toString() ); //Message Setting
		
		
		if("N".equals(vo.getHsbdFrngrYn())){
			String hsbdLgSeqNo ="";
			String hsbdParm = "";
			if("W".equals(mResult) && "".equals(rvctgStusH) && "N".equals(crdExpYnH)){
				hsbdParm = dao.selectMaleParamWriteRqst(vo);
				log.debug("wifeParm : "+ hsbdParm);
				hsbdLgSeqNo=lgDao.insertPubKeyIfLg(vo.getUserId(), vo.getHsbdRsdtNo(), "20", "1", "5", hsbdParm);		
			}
			map.put("hsbdLogSeqNo", hsbdLgSeqNo);
			map.put("hsbdParm", hsbdParm);
		}else{
			map.put("hsbdLogSeqNo", "");
			map.put("hsbdParm", "");
		}
		
		
		if("N".equals(vo.getWifeFrngrYn())){
			String wifeLogSeqNo="";
			String wifeParm = "";
			if("W".equals(fResult) && "".equals(rvctgStusW) && "N".equals(crdExpYnW)){
				if("Y".equals(vo.getWifeCurtAdChngYn())|| "Y".equals(vo.getWifePmntAdChngYn())){	
					wifeParm = dao.selectFemaleParamWriteRqst(vo);
					log.debug("wifeParm : "+ wifeParm);
					wifeLogSeqNo=lgDao.insertPubKeyIfLg(vo.getUserId(), vo.getWifeRsdtNo(), "20", "1", "5", wifeParm);
				}
			}
			map.put("wifeLogSeqNo", wifeLogSeqNo);
			map.put("wifeParm", wifeParm);
		}else{
			map.put("wifeLogSeqNo", "");
			map.put("wifeParm", "");
		}
		
		return map;
	
	}

	/**
	 * Biz-method for retrieving Receipt of Citizen. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(DvrcVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
   	public DvrcVO searchDvrcCrdReisuceRcpt(DvrcVO vo) throws Exception {
        return dao.selectDvrcCrdReisuceRcpt(vo);
	}
	
   	/**
   	 * Biz-method for retrieving Receipt of Citizen. <br>
   	 *
   	 * @param vo Input item for  retrieving Receipt of Citizen (DvrcVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchDvrcCrdReisuceOthrRcpt(DvrcVO vo) throws Exception {
      		return dao.selectDvrcCrdReisuceOthrRcpt(vo);
   	}
   	
   	/**
   	 * Biz-method for retrieving Receipt of Citizen. <br>
   	 *
   	 * @param vo Input item for  retrieving Receipt of Citizen (DvrcVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchDvrcCrdReisuceFrgnRcpt(DvrcVO vo) throws Exception {
      		return dao.selectDvrcCrdReisuceFrgnRcpt(vo);
   	}
   	
   	/**
	 * Biz-method for retrieving Receipt of Citizen Confirmation. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(DvrcVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
   	public DvrcVO searchDvrcCfmRcpt(DvrcVO vo) throws Exception {
        return dao.selectDvrcCfmRcpt(vo);
	}
	
   	/**
	 * Biz-method for retrieving wife permanent address code. <br>
	 *
	 * @param wifeSeqNo Input item for  retrieving wife permanent address code.(String).
	 * @return String wife permanent address code.
	 * @exception Exception
	 */
   	public String searchWifePmntAdCd(String wifeSeqNo) throws Exception{
        return dao.selectWifePmntAdCd(wifeSeqNo);
	}
   	
   	/**
	 * Biz-method for sending to write citizen information request. <br>
	 * 
	 * @param hsbdLogSeqNo Input item for inserting log.(String).
	 * @param hsbdParm Input item for sending to write citizen information request.(String).
	 * @return status result
	 * @exception Exception
	 */
	public String approveDvrcInfrPkiIf(String logSeqNo, String parm) throws Exception {

		String status = "";
		String erorYn ="Y";
		log.debug("=====Marriage Card Write Interface ====");
		
		RMCCM_Service ccmse= new RMCCM_Service();
		RMCCM ccm = ccmse.getRMCCMPort();
		
		if(!"".equals(parm)){
			status = ccm.registerCardChanges(parm);
		}
		log.debug("status ====> " + status);
		 
		if("OK".equals(status)){
			erorYn ="N";
		}
		
		lgDao.updatePubKeyIfLg(logSeqNo, status, erorYn);			
		
		
    	return status;
    	
	}
	
	/**
	 * Biz-method for retrieving wife permanent address code. <br>
	 *
	 * @param wifeSeqNo Input item for  retrieving wife permanent address code.(String).
	 * @return String wife permanent address code.
	 * @exception Exception
	 */
   	public String searchResultOfCrdInfrChang(DvrcVO vo, String gdr) throws Exception{
   		String rsdtSeqNo = "";
   		String result = "N";
   		String pmntChngYn = "";
   		String afPmntAdCd ="";
   		String curtAdChngYn = "";
   		String afCurtAdDiv = "";
   		String afCurtAdCd = "";
   		String afCurtAdNatCd = "";
   		String afWifeNmChngYn = "";
   		if("M".equals(gdr)){
   			rsdtSeqNo     = vo.getHsbdRsdtSeqNo();
   			pmntChngYn    = vo.getHsbdPmntAdChngYn();
   			afPmntAdCd    = vo.getAfHsbdPmntAdCd();
   			curtAdChngYn  = vo.getHsbdCurtAdChngYn();
   			afCurtAdDiv   = vo.getAfHsbdCurtAdDiv();
   			afCurtAdCd    = vo.getAfHsbdCurtAdCd();
   			afCurtAdNatCd = vo.getAfHsbdCurtAdNatCd();
   			afWifeNmChngYn = "N";
   		}else if("F".equals(gdr)){	
   			rsdtSeqNo      = vo.getWifeRsdtSeqNo();
   			pmntChngYn     = vo.getWifePmntAdChngYn();
   			afPmntAdCd     = vo.getAfWifePmntAdCd();
   			curtAdChngYn   = vo.getWifeCurtAdChngYn();
   			afCurtAdDiv    = vo.getAfWifeCurtAdDiv();
   			afCurtAdCd     = vo.getAfWifeCurtAdCd();
   			afCurtAdNatCd  = vo.getAfWifeCurtAdNatCd();
   			afWifeNmChngYn = vo.getWifeNmChngYn();
   		}
   		
   		if(null == rsdtSeqNo || "".equals(rsdtSeqNo)){
   			result = "N";
   			return result;
   		}
   		
   		EgovMap em = dao.selectResultOfCrdInfrChang(rsdtSeqNo);
   		
		if("Y".equals(afWifeNmChngYn) ){
			result = "R";
			return result;
		} 
		
		if("Y".equals(pmntChngYn)){

			String pmntAdCd = NidStringUtil.nullConvert(em.get("pmntAdCd"));
			
			if( 1 < pmntAdCd.length()){
				pmntAdCd = pmntAdCd.substring(0,2);
			}else{
				pmntAdCd ="XX";
			}			
			if(!afPmntAdCd.startsWith(pmntAdCd)){
				result = "R";
				return result;
			}else{
				result = "W";
			}
		}
		
		if("Y".equals(curtAdChngYn)){

			String curtAdDiv = NidStringUtil.nullConvert(em.get("curtAdDiv"));
			String curtAdCd = NidStringUtil.nullConvert(em.get("curtAdCd"));
			String curtAdNatCd = NidStringUtil.nullConvert(em.get("curtAdNatCd"));
			
			if(!curtAdDiv.equals(afCurtAdDiv)){
				result = "R";
				return result;
			}
			
			if("Y".equals(afCurtAdDiv)){
				if(!curtAdNatCd.equals(afCurtAdNatCd)){
					result = "R";
					return result;
				}else{
					result = "W";
				}
				
			}else if("N".equals(afCurtAdDiv)){
				if( 1 < curtAdCd.length()){
					curtAdCd = curtAdCd.substring(0,2);
				}else{
					curtAdCd ="XX";
				}
				
				if(!afCurtAdCd.startsWith(curtAdCd)){
					result = "R";
					return result;
				}else{
					result = "W";
				}
			}		
		}
   		
   		return result;
	}	
   	
  	/**
   	 * Biz-method for retrieving wife relationship. <br>
   	 *
   	 * @param vo Input item for retrieving wife relationshipMrrgVO).
   	 * @return relationship code
   	 * @exception Exception
   	 */
   	public List<DvrcVO> searchListRl(DvrcVO vo) throws Exception {

   		if(vo.getFmlyBokNo() != null && !"".equals(vo.getFmlyBokNo())){
			String fmlyHadGdrCd =  dao.selectFmlyHadGdrCd(vo);
			vo.setFmlyHadGdrCd(fmlyHadGdrCd);
   		}
   		
   		List<DvrcVO>  rlcd = dao.selectListRl(vo);
    	
   		return rlcd;
   	} 
   	
  	/**
   	 * Biz-method for retrieving wife relationship. <br>
   	 *
   	 * @param vo Input item for retrieving wife relationshipMrrgVO).
   	 * @return relationship code
   	 * @exception Exception
   	 */
   	public List<DvrcVO> searchListRlOthr(DvrcVO vo) throws Exception {

   		if(vo.getFmlyBokNo() != null && !"".equals(vo.getFmlyBokNo())){
			String fmlyHadGdrCd =  dao.selectFmlyHadGdrCd(vo);
			vo.setFmlyHadGdrCd(fmlyHadGdrCd);
   		}
   		
   		List<DvrcVO>  rlcd = dao.selectListRlOthr(vo);
    	
   		return rlcd;
   	}   
   	
  	/**
   	 * Biz-method for retrieving wife relationship. <br>
   	 *
   	 * @param vo Input item for retrieving wife relationshipMrrgVO).
   	 * @return relationship code
   	 * @exception Exception
   	 */
   	public List<DvrcVO> searchListRlAll(DvrcVO vo) throws Exception {

   		if(vo.getFmlyBokNo() != null && !"".equals(vo.getFmlyBokNo())){
			String fmlyHadGdrCd =  dao.selectFmlyHadGdrCd(vo);
			vo.setFmlyHadGdrCd(fmlyHadGdrCd);
   		}
   		
   		List<DvrcVO>  rlcd = dao.selectListRlAll(vo);
    	
   		return rlcd;
   	}
   	
  	/**
   	 * Biz-method for retrieving wife relationship. <br>
   	 *
   	 * @param vo Input item for retrieving wife relationshipMrrgVO).
   	 * @return relationship code
   	 * @exception Exception
   	 */
   	public List<DvrcVO> searchListRlTbAll(DvrcVO vo) throws Exception {

   		List<DvrcVO>  rlcd = dao.selectListRlTbAll(vo);
    	
   		return rlcd;
   	}   
   	
	/**
	 * Biz-method for retrieving total count relationship in family book.. <br>
	 * 
	 * @param vo Input item for retrieving total count relationship in family book.(DvrcVO).
	 * @return List Retrieve total count relationship in family book.
	 * @exception Exception
	 */
	public int searchMberCn(DvrcVO vo) throws Exception {		
   		return dao.selectMberCn(vo);
	}   	
}
