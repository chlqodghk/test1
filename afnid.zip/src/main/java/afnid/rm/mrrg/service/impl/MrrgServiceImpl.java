package afnid.rm.mrrg.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.pkiif.ccm.RMCCM;
import afnid.pkiif.ccm.RMCCM_Service;
import afnid.rm.crd.service.CrdFndService;
import afnid.rm.mrrg.service.MrrgService;
import afnid.rm.mrrg.service.MrrgVO;
import afnid.rm.rsdt.service.RsdtInfrService;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Service("mrrgService")
public class MrrgServiceImpl extends AbstractServiceImpl implements MrrgService{
	/** mrrgDAO */
    @Resource(name="mrrgDAO")
    private MrrgDAO dao;
    
    @Resource(name="lgDAO")
    private LgDAO lgDao;
    
    /** crdFndService */
	@Resource(name = "crdFndService")
    private CrdFndService crdFndService;
    
    @Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtInfoDao;
    
    /** rsdtInfoService service */
    @Resource(name="rsdtInfoService")
    private RsdtInfrService rsdtInfoService;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
       
	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(MrrgVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public EgovMap searchMrrgRsdtInfr(MrrgVO vo) throws Exception {
   		EgovMap result = null;
   		result = dao.selectRsdtInfr(vo);
   		return result;
   	}   
   	
   	/**
   	 * Biz-method for retrieving Count of Male Marriage. <br>
   	 *
   	 * @param vo Input item for retrieving Count of Male Marriage.(MrrgVO).
   	 * @return int Retrieve Count of Male Marriage.
   	 * @exception Exception
   	 */
   	public int searchMlMrrgCn(MrrgVO vo) throws Exception {
   		int result = 0;
   		result = dao.selectMlMrrgCn(vo);
   		return result;
   	}
   	
   	/**
   	 * Biz-method for  retrieving wife information. <br>
   	 *
   	 * @param vo Input item for retrieving wife information(MrrgVO).
   	 * @return String wife's name and eNID information.
   	 * @exception Exception
   	 */
   	public String searchMrrgWifeNm(MrrgVO vo) throws Exception {
   		StringBuffer msgBf = new StringBuffer();
   						
   		List<EgovMap> wifeNmList = dao.selectMrrgWifeNm(vo);
   		
   		if(wifeNmList != null ){
   			EgovMap map = null;
   			for(int i = 0; i < wifeNmList.size(); i++){
   				map = wifeNmList.get(i);
   				if(msgBf.length() <= 0){
   					msgBf.append("\r\n");
   				}else{
   					msgBf.append(",\r\n");
   				}

   				msgBf.append(NidStringUtil.nullConvert(map.get("rsdtNo"))).append(" ").append(NidStringUtil.nullConvert(map.get("rsdtNm")));
   				if("2".equals(NidStringUtil.nullConvert(map.get("mrrgFlag"))) ){
   					msgBf.append(" - ").append(nidMessageSource.getMessage("waitForApp"));
   				}
   			}			
   		}

   		String msg =  nidMessageSource.getMessage("nMrrgByCn.msg",new String[]{vo.getAlwWifeNo(),msgBf.toString()});
   		return msg;
   	}
    
   	/**
   	 * Biz-method for retrieving female marriage information. <br>
   	 *
   	 * @param vo Input item for retrieving female marriage information.(MrrgVO).
   	 * @return EgovMap  Retrieve female marriage information
   	 * @exception Exception
   	 */
   	public EgovMap searchFemlMrrgInfr(MrrgVO vo) throws Exception {
   		EgovMap result = dao.selectFemlMrrgInfr(vo);

   		String hsbdRsdtSeqNo =  NidStringUtil.nullConvert(result.get("spusRsdtSeqNo")); 

		String spusNm =   NidStringUtil.nullConvert(result.get("spusNm"));

		String ccltDd = NidStringUtil.nullConvert(result.get("ccltDd"));

		BigDecimal  cnt = (BigDecimal)result.get("cnt");
		int cntInt = cnt.intValue();

		String flagVal = null;
		
		if(hsbdRsdtSeqNo == null || "".equals(hsbdRsdtSeqNo)){
			if(spusNm == null || "".equals(spusNm)){
				flagVal = "1";		
			}else{
				flagVal = "4";
			}
		}else{
			if(ccltDd == null || "".equals(ccltDd)){
				flagVal = "4";
			}else{
				flagVal = "1";
			}
		}
		
		if(0 < cntInt){
			flagVal = "4";
		}
		result.put("flagVal", flagVal);
   		return result;
   	}
   		
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(MrrgVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public String addMrrgInfr(MrrgVO vo) throws Exception {
   		String mrrgSeqNo = "";
   		if(vo != null){
   			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
   			
			vo.setUserId(user.getUserId());
    		String orgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
    		vo.setRgstOrgnzCd(orgnzCd);
    		vo.setUseLangCd(user.getUseLangCd()); 
    		
    		boolean flag = false;
    		//result R: reissuance, W:rewrite, N: none
    		String mResult = searchResultOfCrdInfrChang(vo, "M");
    		if("R".equals(mResult)){
				flag = true;	
			}
    		String fResult = searchResultOfCrdInfrChang(vo, "F");
    		if("R".equals(fResult)){
				flag = true;	
			}
			
			if(!flag){
				vo.setCrdReisuceDueDd("");
			}
    		mrrgSeqNo = dao.insertMrrg(vo);
    		
   
   		}
   		return mrrgSeqNo;
   	}
   	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(MrrgVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public MrrgVO searchMrrgUdtRsdtInfr(MrrgVO vo) throws Exception {   		
   		return dao.selectMrrgUdtRsdtInfr(vo);
   	}
   	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(MrrgVO).
   	 * @return List<EgovMap> List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchMrrgUdtInfrTotCnt(MrrgVO vo) throws Exception {	
   		List<EgovMap> result = dao.selectMrrgUdtInfrTotCnt(vo);
   		return result;
   	}
	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(MrrgVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public MrrgVO searchMrrgUdtInfr(MrrgVO vo) throws Exception {   		
   		return dao.selectMrrgUdtInfr(vo);
   	} 
   	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(MrrgVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public MrrgVO searchMrrgDtlInfr(MrrgVO vo) throws Exception {   		
   		return dao.selectMrrgDtlInfr(vo);
   	} 
   	
    /**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(MrrgVO).
	 * @return List Retrieve list of program
	 * @exception Exception 
	 */
	public List<MrrgVO> searchListMrrgUdt(MrrgVO vo) throws Exception {
		vo.setTamLedrCfmYn("N");
   		return dao.selectListMrrgUdt(vo);
	}   
	
   	/**
	 * Biz-method for modifying marriage information. <br>
	 *
	 * @param vo Input item for modifying marriage information(MrrgVO).
	 * @return int Result Count
	 * @exception Exception
	 */
	public int modifyMrrgInfr(MrrgVO vo) throws Exception {
		int result = 0;

		boolean flag = false;
		//result R: reissuance, W:rewrite, N: none
		String mResult = searchResultOfCrdInfrChang(vo, "M");
		if("R".equals(mResult)){
			flag = true;	
		}
		String fResult = searchResultOfCrdInfrChang(vo, "F");
		if("R".equals(fResult)){
			flag = true;	
		}
		
		if(!flag){
			vo.setCrdReisuceDueDd("");
		}
		
		result = dao.updateMrrgInfr(vo);

		return result;
	}    	
   	
    /**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(MrrgVO).
	 * @return List Retrieve list of program
	 * @exception Exception 
	 */
	public List<MrrgVO> searchListMrrgDvrcAprv(MrrgVO vo) throws Exception {
   		return dao.selectListMrrgDvrcAprv(vo);
	}
	
	/**
	 * Biz-method for retrieving total count list of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(MrrgVO).
	 * @return int Total Count of Program List
	 * @exception Exception 
	 */
    public int searchListTotCntMrrgDvrcAprv(MrrgVO vo) throws Exception {
        return dao.selectListTotCntMrrgDvrcAprv(vo);
	}  	
	
	/**    
	 * Biz-method for modifying information of marriage <br>
	 * 
	 * @param vo Input item for modifying information of marriage(MrrgVO).
	 * @return void
	 * @exception Exception 
	 */
	public Map<String,String> approveMrrg(MrrgVO vo) throws Exception {
		Map<String,String> map = new HashMap<String,String>(); 
		boolean isCadIsuce = false;
		String rvctgStusH = "";
		String rvctgStusW = "";
		String crdExpYnH = "N";
		String crdExpYnW = "N";
		String mResult = "";
		String fResult = "";
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setFstRgstUserId(user.getUserId());
		vo.setUseLangCd(user.getUseLangCd());
		vo.setLstUdtUserId(user.getUserId());
		vo.setUserId(user.getUserId());
		String flOrgnzCd = user.getOrgnzClsCd()+ user.getOrgnzCd()+user.getTamCdNm();
		vo.setRgstOrgnzCd( flOrgnzCd );	
		
		String fmlyBokNo = "";
		String newbokYnH = vo.getHsbdNewFmlyBokYn();
		String newbokYnW = vo.getWifeNewFmlyBokYn();
		if("Y".equals(newbokYnH) ||"Y".equals(newbokYnW) ){
			String orgnzCd = user.getOrgnzCd();
	 		String district = orgnzCd.substring(0, 4);
	 		String tamCdNm = user.getTamCdNm();
			if(tamCdNm == null || "".equals(tamCdNm)){
				tamCdNm = "00";
			}
			vo.setFmlyBokNoNum(district+tamCdNm);
			fmlyBokNo = dao.insertFmlyBokByMrrg(vo);
		}
		
		if("Y".equals(newbokYnH)){
			vo.setAfHsbdFmlyBokNo(fmlyBokNo);
			if("newBok".equals(vo.getAfWifeFmlyBokNo()) ){
				vo.setAfWifeFmlyBokNo(fmlyBokNo);
			}
		}
		
		if("Y".equals(newbokYnW)){
			vo.setAfWifeFmlyBokNo(fmlyBokNo);
		}
		
		//Update 
		int resultUpdate = modifyMrrgInfr( vo );    		
		if(1 != resultUpdate){
			throw processException( "udtFail.msg");
		}  
		
		vo.setCfmTamLedrId(user.getUserId());	
		String crdIsucePlceCd = user.getOrgnzClsCd()+ user.getOrgnzCd();
		vo.setCrdIsucePlceCd(crdIsucePlceCd);
		
		boolean updateResult = false;
		String newSeqNo = "";
		MrrgVO result = null;
		MrrgVO fmlyInfr = null;
		
		//husband : domestic		
		if("N".equals(vo.getHsbdFrngrYn())){
			vo.setSearchKeyword4(vo.getHsbdRsdtNo());
			MrrgVO mrrgVo = dao.selectMrrgUdtRsdtInfr(vo);
			String mrrgCd = mrrgVo.getMrrgCd();
			if(!"1".equals(mrrgCd) || "Y".equals(vo.getHsbdCurtAdChngYn()) || "Y".equals(newbokYnH) || "Y".equals(vo.getHsbdPmntAdChngYn())){
					
				vo.setRsdtSeqNo(vo.getHsbdRsdtSeqNo());
				rsdtInfoDao.insertRsdtInfrHst(vo.getRsdtSeqNo(), vo.getUserId() );
				log.debug("=======Husband is Domestic ====");
				
				//result R: reissuance, W:rewrite, N: none
				mResult = searchResultOfCrdInfrChang(vo, "M");
				
				//check for  husband Citizen Revocation Status
				if(!"N".equals(mResult)){	
					rvctgStusH = rsdtInfoService.searchRsdtRvctgStus(vo.getHsbdRsdtNo(), "code");	
				}

				//check husband card expiration Status.
				crdExpYnH = dao.selectCrdExpStus(vo.getHsbdRsdtSeqNo());
				vo.setCrdIsuceYn("N");
				if("R".equals(mResult) ){
					if("".equals(rvctgStusH) &&"N".equals(crdExpYnH)){
						isCadIsuce = true;
						vo.setCrdIsuceYn("Y");
					}else{
						log.debug("=======NO Insert husband card reissuance==== by : "+rvctgStusH);
						isCadIsuce = false;
						vo.setCrdIsuceYn("N");
					}
				}
				
				if("Y".equals(newbokYnH)){
					fmlyInfr = dao.selectFmlyBokInfr(fmlyBokNo);
					if(null != fmlyInfr){
						vo.setAfHsbdFmlyBokSeqNo(fmlyInfr.getFmlyBokSeqNo());
						vo.setAfHsbdFmlyMberNo(fmlyInfr.getFmlyMberNo());
						vo.setAfHsbdFmlyBokNo(fmlyInfr.getFmlyBokNo());
					}
				}
				
				//resident table update
				vo.setSearchKeyword10("N");
				updateResult = dao.updateRsdtInfr(vo);
				vo.setSearchKeyword10("");
				
				if(!updateResult){
					throw processException( "udtFail.msg");
				}
				
				//Check card issuance
				if("R".equals(mResult)){
					if(isCadIsuce){
						log.debug("=======Insert husband card reissuance infromation====");
						vo.setRsdtNo( vo.getHsbdRsdtNo() );					
						dao.insertCrdIsuInfr( vo );
					}
				}
				
				//Update Signature Data to RM_RSDT_TB
				rsdtInfoService.updateDigitalSgnt(vo.getRsdtSeqNo(), vo.getHsbdSgnt(), "4");
			}
		}
		
		//wife : domestic		
		if("N".equals(vo.getWifeFrngrYn())){
			log.debug("=======Wife is Domestic ====");
			
			vo.setRsdtSeqNo( vo.getWifeRsdtSeqNo());				
			rsdtInfoDao.insertRsdtInfrHst(vo.getRsdtSeqNo(), vo.getUserId() );
			
			if("Y".equals(vo.getWifeFmlyBokMvYn())|| "Y".equals(newbokYnW)){
				fmlyInfr= dao.selectFmlyBokInfr(vo.getAfWifeFmlyBokNo());
				if(null != fmlyInfr){
					vo.setFmlyBokSeqNo(fmlyInfr.getFmlyBokSeqNo());
					vo.setFmlyMberNo(fmlyInfr.getFmlyMberNo());
					vo.setFmlyBokNo(fmlyInfr.getFmlyBokNo());
				}
			}
					
			
			//result R: reissuance, W:rewrite, N: none
			fResult = searchResultOfCrdInfrChang(vo, "F");
			
			//check for  wife Citizen Revocation Status
			if(!"N".equals(fResult)){	
				rvctgStusW = rsdtInfoService.searchRsdtRvctgStus(vo.getWifeRsdtNo(), "code");	
			}

			//check wife card expiration Status.
			crdExpYnW = dao.selectCrdExpStus(vo.getWifeRsdtSeqNo());
			vo.setCrdIsuceYn("N");
			isCadIsuce = false;
			if("R".equals(fResult) ){
				if("".equals(rvctgStusW) &&"N".equals(crdExpYnW)){
					isCadIsuce = true;
					vo.setCrdIsuceYn("Y");
				}else{
					log.debug("=======NO Insert wife card reissuance==== by : "+rvctgStusW);
					isCadIsuce = false;
					vo.setCrdIsuceYn("N");
				}
			}
			
			//resident table update
			vo.setSearchKeyword10("Y");
			updateResult = dao.updateRsdtInfr(vo);
			vo.setSearchKeyword10("");
			
			if(!updateResult){
				throw processException( "udtFail.msg");
			}

			//Check card issuance
			if("R".equals(fResult)){
				if(isCadIsuce){
					log.debug("=======Insert wife card reissuance infromation====");
					vo.setRsdtNo( vo.getWifeRsdtNo() );					
					dao.insertCrdIsuInfr( vo );
				}
			}		
		}
		
		//husband : foreigner
		if("Y".equals(vo.getHsbdFrngrYn())){
			log.debug("=======Husband is foreigner ====");
			vo.setRsdtSeqNo(vo.getWifeRsdtSeqNo());
			result = dao.selectSpusInfr(vo);
			result.setGdrCd("1");
			result.setSurnm(vo.getHsbdSurnm());
			result.setGivNm(vo.getHsbdGivNm());
			result.setUserId(user.getUserId());
			result.setRgstOrgnzCd(vo.getRgstOrgnzCd());
			newSeqNo = dao.insertRsdtInfrForForeigner(result);
			vo.setHsbdRsdtSeqNo(newSeqNo);	

			//wife's husband RSDT_SEQ_NO update 
			updateResult = dao.updateWifeHsbdRsdtSeqNo(vo);
						
			if(!updateResult){
				throw processException( "udtFail.msg");
			}
		}
		
		//wife : domestic for signature
		if("N".equals(vo.getWifeFrngrYn()) ){

			//Update Signature Data to RM_RSDT_TB
			rsdtInfoService.updateDigitalSgnt(vo.getRsdtSeqNo(), vo.getWifeSgnt(), "4");
		}
		
		//wife : foreigner
		if("Y".equals(vo.getWifeFrngrYn())){
			log.debug("=======Wife is foreigner ====");
			result = dao.selectSpusInfr(vo);
			result.setGdrCd("2");
			result.setUserId(user.getUserId());
			result.setSurnm(vo.getWifeSurnm());
			result.setGivNm(vo.getWifeGivNm());
			result.setHsbdRsdtSeqNo(vo.getHsbdRsdtSeqNo());
			result.setRgstOrgnzCd(vo.getRgstOrgnzCd());
			newSeqNo = dao.insertRsdtInfrForForeigner(result);
			vo.setWifeRsdtSeqNo(newSeqNo);
		}

		boolean mrrgResult = dao.approveMrrg(vo);
		
		if(!mrrgResult){
			throw processException( "udtFail.msg");
		}
		
		
		//Husband's found card Kill by card reissuance 
		map.put("dsuseMsg","");
		StringBuffer strBf = null;
		StringBuffer flMsg = new StringBuffer();
		if("R".equals(mResult)){
			log.debug("==========Husband Start kill card=======================");
			strBf = new StringBuffer();
			List<String> OrgList =crdFndService.modifyCrdFndPrcssStus(vo.getHsbdRsdtNo(), "4", "", "47");
			for(int i=0; i < OrgList.size(); i++){
				if(i == 0){
					strBf.append(OrgList.get(i));
				}else{
					strBf.append(", ").append(OrgList.get(i));
				}	
			}
			
			if(0 < OrgList.size()){
				flMsg.append(nidMessageSource.getMessage("hsbd")).append(" : " );
				flMsg.append(nidMessageSource.getMessage("rgstDuseObjt.msg",new String[]{strBf.toString()})); //Message Setting
			}
			log.debug("==========Husband flMsg :" +flMsg.toString());
		}
		
		//Wife's found card Kill by card reissuance 
		if("R".equals(fResult)){
			log.debug("==========Wife Start kill card=======================");
			strBf = new StringBuffer();
			List<String> OrgList =crdFndService.modifyCrdFndPrcssStus(vo.getWifeRsdtNo(), "4", "", "47");
			for(int i=0; i < OrgList.size(); i++){
				if(i == 0){
					strBf.append(OrgList.get(i));
				}else{
					strBf.append(", ").append(OrgList.get(i));
				}	
			}
			
			if(0 < OrgList.size()){
				if(0 < flMsg.length()){
					flMsg.append("\\r\\n\\r\\n");
				}
				flMsg.append(nidMessageSource.getMessage("wife")).append(" : " );
				flMsg.append(nidMessageSource.getMessage("rgstDuseObjt.msg",new String[]{strBf.toString()}));			
			}
		}
		log.debug("==========Full flMsg :" +flMsg.toString());
		map.put("dsuseMsg", flMsg.toString() ); //Message Setting
		
		if("N".equals(vo.getHsbdFrngrYn())){
			String hsbdLgSeqNo ="";
			String hsbdParm = "";
			if("W".equals(mResult) && "".equals(rvctgStusH) && "N".equals(crdExpYnH)){
				hsbdParm = dao.selectMaleParamWriteRqst(vo);
				log.debug("wifeParm : "+ hsbdParm);
				hsbdLgSeqNo=lgDao.insertPubKeyIfLg(user.getUserId(), vo.getHsbdRsdtNo(), "20", "1", "4", hsbdParm);
				
			}
			map.put("hsbdLogSeqNo", hsbdLgSeqNo);
			map.put("hsbdParm", hsbdParm);
		}else{
			map.put("hsbdLogSeqNo", "");
			map.put("hsbdParm", "");
		}
		
		
		if("N".equals(vo.getWifeFrngrYn())){
			String wifeLogSeqNo="";
			String wifeParm = "";
			if("W".equals(fResult) && "".equals(rvctgStusW) && "N".equals(crdExpYnW)){
				if("Y".equals(vo.getWifeCurtAdChngYn())|| "Y".equals(vo.getWifePmntAdChngYn())){	
					wifeParm = dao.selectFemaleParamWriteRqst(vo);
					log.debug("wifeParm : "+ wifeParm);
					wifeLogSeqNo=lgDao.insertPubKeyIfLg(user.getUserId(), vo.getWifeRsdtNo(), "20", "1", "4", wifeParm);
				}
			}
			map.put("wifeLogSeqNo", wifeLogSeqNo);
			map.put("wifeParm", wifeParm);
		}else{
			map.put("wifeLogSeqNo", "");
			map.put("wifeParm", "");
		}
	
		return map;
		
	}	
	
	/**
	 * Biz-method for sending to write citizen information request. <br>
	 * 
	 * @param hsbdLogSeqNo Input item for inserting log.(String).
	 * @param hsbdParm Input item for sending to write citizen information request.(String).
	 * @return status result
	 * @exception Exception
	 */
	public String approveMrrgInfrPkiIf(String logSeqNo, String parm) throws Exception {

		String status = "";
		String erorYn ="Y";
		log.debug("=====Marriage Card Write Interface ====");
		
		RMCCM_Service ccmse= new RMCCM_Service();
		RMCCM ccm = ccmse.getRMCCMPort();
		
		if(!"".equals(parm)){
			status = ccm.registerCardChanges(parm);
		}
		log.debug("status ====> " + status);
		 
		if("OK".equals(status)){
			erorYn ="N";
		}

		lgDao.updatePubKeyIfLg(logSeqNo, status, erorYn);			
		
		
    	return status;
    	
	}
	
	/**
	 * Biz-method for retrieving Receipt of Citizen. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(MrrgVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
   	public MrrgVO searchCrdReisuceRcpt(MrrgVO vo) throws Exception {
        return dao.selectCrdReisuceRcpt(vo);
	}
	
   	/**
   	 * Biz-method for retrieving Receipt of Citizen. <br>
   	 *
   	 * @param vo Input item for  retrieving Receipt of Citizen (MrrgVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchCrdReisuceOthrRcpt(MrrgVO vo) throws Exception {
      		return dao.selectCrdReisuceOthrRcpt(vo);
   	}
   	
   	/**
   	 * Biz-method for retrieving Receipt of Citizen. <br>
   	 *
   	 * @param vo Input item for  retrieving Receipt of Citizen (MrrgVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchCrdReisuceFrgnRcpt(MrrgVO vo) throws Exception {
      		return dao.selectCrdReisuceFrgnRcpt(vo);
   	}
   	
   	/**
	 * Biz-method for retrieving Receipt of Citizen Confirmation. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(MrrgVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
   	public MrrgVO searchMrrgCfmRcpt(MrrgVO vo) throws Exception {
        return dao.selectMrrgCfmRcpt(vo);
	}
   	
   	/**
	 * Biz-method for retrieving wife permanent address code. <br>
	 *
	 * @param wifeSeqNo Input item for  retrieving wife permanent address code.(String).
	 * @return String wife permanent address code.
	 * @exception Exception
	 */
   	public String searchResultOfCrdInfrChang(MrrgVO vo, String gdr) throws Exception{
   		String rsdtSeqNo = "";
   		String result = "N";
   		String pmntChngYn = "";
   		String afPmntAdCd ="";
   		String curtAdChngYn = "";
   		String afCurtAdDiv = "";
   		String afCurtAdCd = "";
   		String afCurtAdNatCd = "";
   		String afWifeNmChngYn = "";
   		if("M".equals(gdr)){
   			rsdtSeqNo = vo.getHsbdRsdtSeqNo();
   			pmntChngYn = vo.getHsbdPmntAdChngYn();
   			afPmntAdCd = vo.getAfHsbdPmntAdCd();
   			curtAdChngYn = vo.getHsbdCurtAdChngYn();
   			afCurtAdDiv = vo.getAfHsbdCurtAdDiv();
   			afCurtAdCd= vo.getAfHsbdCurtAdCd();
   			afCurtAdNatCd = vo.getAfHsbdCurtAdNatCd();
   			afWifeNmChngYn = "N";
   		}else if("F".equals(gdr)){	
   			rsdtSeqNo = vo.getWifeRsdtSeqNo();
   			pmntChngYn = vo.getWifePmntAdChngYn();
   			afPmntAdCd = vo.getAfWifePmntAdCd();
   			curtAdChngYn = vo.getWifeCurtAdChngYn();
   			afCurtAdDiv = vo.getAfCurtAdDiv();
   			afCurtAdCd= vo.getAfCurtAdCd();
   			afCurtAdNatCd = vo.getAfCurtAdNatCd();
   			afWifeNmChngYn = vo.getWifeNmChngYn();
   		}
   		
   		if(null == rsdtSeqNo || "".equals(rsdtSeqNo)){
   			result = "N";
   			return result;
   		}
   		
   		EgovMap em = dao.selectResultOfCrdInfrChang(rsdtSeqNo);
   		
		if("Y".equals(afWifeNmChngYn) ){
			result = "R";
			return result;
		} 
		
		if("Y".equals(pmntChngYn)){

			String pmntAdCd = NidStringUtil.nullConvert(em.get("pmntAdCd"));
			
			if( 1 < pmntAdCd.length()){
				pmntAdCd = pmntAdCd.substring(0,2);
			}else{
				pmntAdCd ="XX";
			}
			
			if(!afPmntAdCd.startsWith(pmntAdCd)){
				result = "R";
				return result;
			}else{
				result = "W";
			}	
		}
		
		if("Y".equals(curtAdChngYn)){

			String curtAdDiv = NidStringUtil.nullConvert(em.get("curtAdDiv"));
			String curtAdCd = NidStringUtil.nullConvert(em.get("curtAdCd"));
			String curtAdNatCd = NidStringUtil.nullConvert(em.get("curtAdNatCd"));
			
			if(!curtAdDiv.equals(afCurtAdDiv)){
				result = "R";
				return result;
			}
			
			if("Y".equals(afCurtAdDiv)){
				if(!curtAdNatCd.equals(afCurtAdNatCd)){
					result = "R";
					return result;
				}else{
					result = "W";
				}
				
			}else if("N".equals(afCurtAdDiv)){
				if( 1 < curtAdCd.length()){
					curtAdCd = curtAdCd.substring(0,2);
				}else{
					curtAdCd ="XX";
				}
				
				if(!afCurtAdCd.startsWith(curtAdCd)){
					result = "R";
					return result;
				}else{
					result = "W";
				}
			}		
		}
   		
   		return result;
	}
   	
  	/**
   	 * Biz-method for retrieving wife relationship. <br>
   	 *
   	 * @param vo Input item for retrieving wife relationshipMrrgVO).
   	 * @return relationship code
   	 * @exception Exception
   	 */
   	public List<MrrgVO> searchListRl(MrrgVO vo) throws Exception {

   		if(vo.getFmlyBokNo() != null && !"".equals(vo.getFmlyBokNo())){
			String fmlyHadGdrCd =  dao.selectFmlyHadGdrCd(vo);
			vo.setFmlyHadGdrCd(fmlyHadGdrCd);
   		}
   		
   		List<MrrgVO>  rlcd = dao.searchListRl(vo);
    	
   		return rlcd;
   	} 
   	
  	/**
   	 * Biz-method for retrieving wife relationship. <br>
   	 *
   	 * @param vo Input item for retrieving wife relationshipMrrgVO).
   	 * @return relationship code
   	 * @exception Exception
   	 */
   	public List<MrrgVO> searchRlOthr(MrrgVO vo) throws Exception {

   		List<MrrgVO>  rlcd = dao.selectRlOthr(vo);
    	
   		return rlcd;
   	}
   	
  	/**
   	 * Biz-method for retrieving wife relationship. <br>
   	 *
   	 * @param vo Input item for retrieving wife relationshipMrrgVO).
   	 * @return relationship code
   	 * @exception Exception
   	 */
   	public List<MrrgVO> searchListRlAll(MrrgVO vo) throws Exception {

   		if(vo.getFmlyBokNo() != null && !"".equals(vo.getFmlyBokNo())){
			String fmlyHadGdrCd =  dao.selectFmlyHadGdrCd(vo);
			vo.setFmlyHadGdrCd(fmlyHadGdrCd);
   		}
   		
   		List<MrrgVO>  rlcd = dao.selectListRlAll(vo);
    	
   		return rlcd;
   	}   
   	
   	
  	/**
   	 * Biz-method for retrieving wife relationship. <br>
   	 *
   	 * @param vo Input item for retrieving wife relationshipMrrgVO).
   	 * @return relationship code
   	 * @exception Exception
   	 */
   	public List<MrrgVO> searchListRlTbAll(MrrgVO vo) throws Exception {

   		List<MrrgVO>  rlcd = dao.selectListRlTbAll(vo);
    	
   		return rlcd;
   	}   
   	
	/**
	 * Biz-method for retrieving total count relationship in family book.. <br>
	 * 
	 * @param vo Input item for retrieving total count relationship in family book.(DvrcVO).
	 * @return List Retrieve total count relationship in family book.
	 * @exception Exception
	 */
	public int searchMberCn(MrrgVO vo) throws Exception {		
   		return dao.selectMberCn(vo);
	} 
	
}
