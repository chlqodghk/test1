package afnid.rm.batch.service.impl;


import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Repository;

import afnid.rm.batch.service.RsdtBatchVO;

import com.ibatis.sqlmap.client.SqlMapClient;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;



/** 
 * This class is Database Access Object of common
 * 
 * @author Afghanistan National ID Card System Application Team  MS Kim 
 * @since 2013.01.04`
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           	    Revisions
 *   2013.08.07    		MS Kim          			Create
 *
 * </pre>
 */
@Repository("crdBatchDAO")
public class CrdBatchDAO extends EgovAbstractDAO {
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	
	/**
	 * DAO-method for retrieving list of card expire citizen<br>
	 *
	 * @param vo Input item for retrieving list of card expire citizen(String).
	 * @return List Retrieve list of card expire citizen
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtBatchVO> selectListCrdExpiry(String ymd) throws Exception{
		return list("crdBatchDAO.selectListCrdExpiry",ymd);
	}
	

	/**
	 * DAO-method for Citizen eNID Card Expiry . <br>
	 *
	 * @param String Input item for Citizen eNID Card Expiry(ymd).
	 * @return void
	 * @exception Exception
	 */
    public void updateCrdExpiry(RsdtBatchVO rsdtDat) throws Exception {
        update("crdBatchDAO.updateCrdExpiry", rsdtDat);
    }


}
