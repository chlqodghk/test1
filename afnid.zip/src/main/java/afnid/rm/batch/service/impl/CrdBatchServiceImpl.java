package afnid.rm.batch.service.impl;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.impl.CmmDAO;
import afnid.rm.batch.service.CrdBatchService;
import afnid.rm.batch.service.RsdtBatchVO;
import afnid.rm.rsdt.service.RsdtInfrVO;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of Card Lost/ Damage/ Renewal
 * and implements NidAuthorManageService class.
 * 
 * @author Afghanistan National ID Card System Application Team  MS Kim 
 * @since 2013.08.07
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           	    Revisions
 *   2013.08.07    		MS Kim          			Create
 *
 * </pre>
 */
@Service("crdBatchService")
public class CrdBatchServiceImpl extends AbstractServiceImpl implements CrdBatchService {
	
	@Resource(name="crdBatchDAO")
    private CrdBatchDAO dao;
    
	@Resource(name="rsdtBatchDAO")
    private RsdtBatchDAO rsdtBatchDAO;
	
	/** cmmDAO */
	@Resource(name="cmmDAO")
    private CmmDAO cmmDAO;
    
    @Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtInfrDAO;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /**
	 * Biz-method for Resident eNID Card Expiry <br>
	 *
	 * @param N/A
	 * @return void
	 * @exception Exception
	 */
	public void crdExpiry() throws Exception {

   		RsdtBatchVO  vo = new RsdtBatchVO();
   		RsdtBatchVO  rsdtDat = new RsdtBatchVO();
   		RsdtInfrVO   rsdtVo = new RsdtInfrVO();
		String resultSgnt = "";   		
   		int resultCnt = 0;
   		String hash ="";
   		
        String ymd ="";
		
		ComDefaultVO comVo = new ComDefaultVO();		
		comVo = cmmDAO.selectGreToDay(comVo);
		
		ymd= comVo.getStartDay().replaceAll("-", "");
		
   		//get start time
   		String wrkStDt = rsdtBatchDAO.selectJobDt("");
   		
   		List<RsdtBatchVO> rsdtList = dao.selectListCrdExpiry(ymd);

		resultCnt = rsdtList.size();

		for(int i = 0; i<resultCnt; i++) {
			rsdtDat = rsdtList.get(i);
			rsdtDat.setUserId("SYSTEM");
   		   	//insert citizen history
			rsdtInfrDAO.insertRsdtInfrHst(rsdtDat.getRsdtSeqNo(), rsdtDat.getUserId());
   			
	   		//update citizen status (rm_rsdt_tb table)
			dao.updateCrdExpiry(rsdtDat);
			
			//select citizen
			EgovMap em = rsdtInfrDAO.selectRsdtInfrDat(rsdtDat.getRsdtSeqNo());
			
	   		//get server signature
			hash  = rsdtInfrDAO.selectRsdtInfrHashDat(em, "19");
								
	   		//cut server signature
			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
			if(hash != null && hash.indexOf(reg) == -1){
				String admTelNo = nidMessageSource.getMessage("admTelNo");
				throw processException("pki.websrvcEror.msg", new String[]{hash, admTelNo});
			}
			
   			resultSgnt = getXmlData(hash, "ds:Signature");	

   			//update server signature (rm_rsdt_tb table)
	   		if(resultSgnt != null && resultSgnt.length() > 0){
	   			rsdtVo.setRsdtSeqNo(rsdtDat.getRsdtSeqNo());
	   			rsdtVo.setSysSgnt(resultSgnt);
	   			rsdtInfrDAO.updateRsdtInfrSysSgnt(rsdtVo);
	   		}
	   		
		}
		
		//get finish time
   		String wrkEdDt = rsdtBatchDAO.selectJobDt("");
   		
   		//insert batch process log
   		vo.setUserId("SYSTEM");
   		vo.setWrkStt(wrkStDt);
   		vo.setWrkEdDt(wrkEdDt);
   		vo.setResultCnt(resultCnt);
   		vo.setWrkSysCd("2");   
   		vo.setWrkCd("14");

   		rsdtBatchDAO.insertJobLog(vo);
	}
	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param String, String
   	 * @return String
   	 * @exception Exception
   	 */
   	public String getXmlData(String xml, String tag) throws Exception{
    	String result = "";
    	if(xml != null && tag != null && xml.length() > 0 && tag.length() > 0){
        	result = xml;
        	int str = result.indexOf("<"+tag);
        	int end = result.lastIndexOf("</"+tag+">");
        	result = result.substring(str, end+3+tag.length());
    	}
    	return result;
    }	
	
}
