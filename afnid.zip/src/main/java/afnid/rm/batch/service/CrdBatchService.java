package afnid.rm.batch.service;

/** 
 * This service interface is biz-class of Resident eNID Card Expiry. <br>
 * 
 * @author Afghanistan National ID Card System Application Team  MS Kim
 * @since 2013.08.07 
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           	    Revisions
 *   2013.08.07    		MS Kim          			Create
 *
 * </pre>
 */

public interface CrdBatchService {
	
	/**
	 * Resident eNID Card Expiry<br>
	 *
	 * @param N/A
	 * @return void
	 * @exception Exception
	 */
	void crdExpiry() throws Exception;	
	
}

