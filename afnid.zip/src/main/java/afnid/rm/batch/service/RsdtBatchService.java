package afnid.rm.batch.service;

import afnid.rm.rsdt.service.RsdtInfrVO;
import egovframework.rte.psl.dataaccess.util.EgovMap;


/** 
 * This service interface is biz-class of common. <br>
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2013.01.04  		BH Choi				Create
 *
 * </pre>
 */
public interface RsdtBatchService {

    /**
	 * Biz-method for Bio Dup Citizen Revocation <br>
	 *
	 * @param N/A
	 * @return void
	 * @exception Exception
	 */
	public void rvctgRsdtBioDup() throws Exception ;


    /**
	 * Biz-method for citizen status change <br>
	 *
	 * @param N/A
	 * @return void
	 * @exception Exception
	 */
	public void rsdtStusAtv() throws Exception ; 
	
	/**
	 * Card issuing new data generation of program. <br>
	 * @param void
	 * @return EgovMap object of Program
	 * @exception Exception
	 */

	int modifyRsdtStusAtv(String userId) throws Exception;	

	
	/**
	 * Checking Card issuance Result File <br>
	 * @param void
	 * @return int
	 * @exception Exception
	 */
	int searchResultFile() throws Exception;	
	
	/**
	 * Card issuance Result Upload <br>
	 * @param void
	 * @return void
	 * @exception Exception
	 */
	void addRcivXmlGenerate() throws Exception;	

	/**
	 * fmly tree of program <br>
	 * @param void
	 * @return void
	 * @exception Exception
	 */
	void addFmlyTreeRqst() throws Exception;
	
	
	/**
	 * Flexible Report Generation of program <br>
	 * @param void
	 * @return void
	 * @exception Exception
	 */
	void addRpotRqstGnr() throws Exception;
	

	// ======================================== RM1 ==================================================	
	
	/**
	 * Card issuing new data generation of program. <br>
	 * @param void
	 * @return EgovMap object of Program
	 * @exception Exception
	 */

	EgovMap actionXmlGenerateDpp() throws Exception;	
	
	/**
	 * Card issuing new data generation of program. <br>
	 * @param vo Input item for retrieving  of program.(RsdtInfrVO)
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
	EgovMap actionXmlGenerateDpp(RsdtInfrVO vo) throws Exception;	
	
	
}
