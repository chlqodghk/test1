package afnid.rm.batch.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import afnid.rm.batch.service.RsdtBatchVO;
import afnid.rm.fmly.service.FmlyRlVO;
import afnid.rm.rsdt.service.RsdtInfrVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;



/** 
 * This class is Database Access Object of common
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04`
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.04  		BH Choi         		Create
 *
 * </pre>
 */
@Repository("rsdtBatchDAO")
public class RsdtBatchDAO extends EgovAbstractDAO {
	
	protected Log log = LogFactory.getLog(this.getClass());
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }

	
	/**
	 * DAO-method for get job time   <br>
	 *
	 * @param vo Input item for get job time(gYmd).
	 * @return String Year
	 * @exception Exception
	 */
	public String  selectJobDt(String  gYmd) throws Exception{
		return (String)selectByPk("rsdtBatchDAO.selectJobDt", gYmd);
	}
	
	/**
	 * DAO-method for retrieving list of citizen to activate<br>
	 *
	 * @param vo Input item for retrieving list of citizen to activate(String).
	 * @return List Retrieve list of citizen to activate
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtBatchVO> selectListRsdtStusAtv(String key) throws Exception{
		return list("rsdtBatchDAO.selectListRsdtStusAtv",key);
	}	
	
	/**
	 * DAO-method for modifying  Citizen Status. <br>
	 *
	 * @param vo Input item for modifying program(RsdtBatchVO).
	 * @return 
	 * @exception Exception
	 */
	public void updateRsdtStusAtv(RsdtBatchVO  rsdtDat) throws Exception{
		update("rsdtBatchDAO.updateRsdtStusAtv", rsdtDat);
	}

	/**
	 * DAO-method for citizen Status process. <br>
	 *
	 * @param vo Input item for citizen Status process(RsdtBatchVO).
	 * @return 
	 * @exception Exception
	 */
	public void updateRsdtStusAtvPrcss(String  bioSeqNo) throws Exception{
		update("rsdtBatchDAO.updateRsdtStusAtvPrcss", bioSeqNo);
	}	
	
	/**
	 * DAO-method for retrieving list of BIO Duplication Citizen<br>
	 *
	 * @param vo Input item for retrieving list of BIO Duplication Citizen(String).
	 * @return List Retrieve list of BIO Duplication Citizen
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtBatchVO> selectListBioDupRsdt(String key) throws Exception{
		return list("rsdtBatchDAO.selectListBioDupRsdt",key);
	}	
	
	/**
	 * DAO-method for insert citizen's cancellation <br>
	 *
	 * @param vo Input item for insert citizen's cancellation(RsdtBatchVO).
	 * @return 
	 * @exception Exception
	 */
	public String insertRsdtCctl(RsdtBatchVO rsdtDat) throws Exception{
		String ccltSeqNo ="";
		
		ccltSeqNo = (String)insert("rsdtBatchDAO.insertRsdtCctl", rsdtDat);
		
		return ccltSeqNo;
	}
	
	
	/**
	 * DAO-method for modifying  Status for Bio Dup Citizen. <br>
	 *
	 * @param vo Input item for modifying program(RsdtBatchVO).
	 * @return 
	 * @exception Exception
	 */
	public void updateBioDupRsdt(RsdtBatchVO  rsdtDat) throws Exception{
		update("rsdtBatchDAO.updateBioDupRsdt", rsdtDat);
	}
	
	/**
	 * DAO-method for citizen Status process. <br>
	 *
	 * @param vo Input item for citizen Status process(RsdtBatchVO).
	 * @return 
	 * @exception Exception
	 */
	public void updateBioDupRsdtPrcss(String  bioDptSeqNo) throws Exception{
		update("rsdtBatchDAO.updateBioDupRsdtPrcss", bioDptSeqNo);
	}
	
	/**
	 * DAO-method for insert Log of batch process.<br>
	 *
	 * @param String Input item for Log of batch process(StsLogVO).
	 * @return 
	 * @exception Exception
	 */	
    public void insertJobLog(RsdtBatchVO rsdtBatchVO) throws Exception{
        insert("rsdtBatchDAO.insertJobLog", rsdtBatchVO);
    }
    
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListXmlGenerateDpp(RsdtInfrVO vo) throws Exception{
		return list("rsdtBatchDAO.selectXmlGenerateDppList", vo);
	}

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectXmlGenerateDpp(RsdtInfrVO vo) throws Exception{
		return list("rsdtBatchDAO.selectXmlGenerateDpp", vo);
	}


    /**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtInfrVO).
	 * @return String  Registration number placed
	 * @exception Exception
	 */
    public String selectDppDbDatTime(RsdtInfrVO vo) {
        return (String)selectByPk("rsdtBatchDAO.selectDppDbDatTime", vo);
    }

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving  of program(RsdtInfrVO).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 */
	public EgovMap selectXmlBlobDpp(RsdtInfrVO vo) throws Exception{
		return (EgovMap)selectByPk("rsdtBatchDAO.selectXmlBlobDpp", vo);
	}




	/**
	 * DAO-method for modifying information of program. <br>
	 *
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateImCrdIsuTbFleNm(RsdtInfrVO vo){
		return update("rsdtBatchDAO.updateImCrdIsuTbFleNm", vo);
	}

	/**
	 * DAO-method for modifying information of program. <br>
	 *
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updatePubKeyIfLg(RsdtInfrVO vo){
		return update("rsdtBatchDAO.updatePubKeyIfLg", vo);
	}
	
	/**
	 * DAO-method for registering information of new resident. <br>
	 *
	 * @param vo Input item for registering new program(RsdtInfrVO).
	 * @return void
	 * @exception Exception
	 */
	public void insertIntoXmlBatchSnd(RsdtInfrVO vo) throws Exception{
		insert("rsdtBatchDAO.insertIntoXmlBatchSend", vo);
	}

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return RsdtInfrVO Retrieve of program
	 * @exception Exception
	 *
	 */
	public RsdtInfrVO selectCrdIsuIfTb(RsdtInfrVO vo) throws Exception{
		return (RsdtInfrVO)selectByPk("rsdtBatchDAO.selectCrdIsuImTable", vo);
	}

	/**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return String
	 * @exception Exception
	 *
	 */
	public String selectSeqImCrdDitbTbSeqNo(RsdtInfrVO vo) throws Exception{
		return (String)selectByPk("rsdtBatchDAO.selectSeqImCrdDitbTbSeqNo", vo);
	}

	/**
	 * DAO-method for modifying information of program. <br>
	 *
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateCrdIsuIfTb(RsdtInfrVO vo){
		return update("rsdtBatchDAO.updateCrdIsuImTable", vo);
	}

	/**
	 * DAO-method for registering information of new Interface Table. <br>
	 *
	 * @param vo Input item for registering new program(RsdtInfrVO).
	 * @return String
	 * @exception Exception
	 */
	public String insertIfCrdIsuTb(RsdtInfrVO vo) throws Exception{
		String result = null;
    	result = (String)insert("rsdtBatchDAO.insertImCrdIsuTb", vo);
        return result;
	}

	/**
	 * DAO-method for registering information of new family book history. <br>
	 *
	 * @param vo Input item for registering new program(RsdtInfrVO).
	 * @return void
	 * @exception Exception
	 */
	public void insertIfCrdDlvrTbInfr(RsdtInfrVO vo) throws Exception{
		insert("rsdtBatchDAO.insertImCrdDlvrTbInfo", vo);
	}


    /**
	 * DAO-method for modifying information of program. <br>
	 *
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateCmDppFlePrcssLgTbFleNm(RsdtInfrVO vo){
		return update("rsdtBatchDAO.updateCmDppFlePrcssLgTbFleNm", vo);
	}

	/**
	 * DAO-method for The resulting file processing. <br>
	 *
	 * @param vo Input item for modifying program(RsdtBatchVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateImCrdDitbTbReadErr(RsdtInfrVO vo){
		return update("rsdtBatchDAO.updateImCrdDitbTbReadErr", vo);
	}

	/**
	 * DAO-method for The resulting file processing. <br>
	 *
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return void
	 * @exception Exception
	 */
	public void insertImCrdIsuTbReadErr(RsdtInfrVO vo){
		insert("rsdtBatchDAO.insertImCrdIsuTbReadErr", vo);
	}

	/**
	 * DAO-method for The resulting file processing. <br>
	 *
	 * @param vo Input item for modifying program(RsdtBatchVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateImCrdDitbTbPkiDppErr(RsdtInfrVO vo){
		return update("rsdtBatchDAO.updateImCrdDitbTbPkiDpperr", vo);
	}

	/**
	 * DAO-method for The resulting file processing. <br>
	 *
	 * @param vo Input item for modifying program(RsdtBatchVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateImCrdIsuTbDppErr(RsdtInfrVO vo){
		return update("rsdtBatchDAO.updateImCrdIsuTbDppErr", vo);
	}




    
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateRsdtInfrCrdIsu(RsdtInfrVO vo){
		return update("rsdtBatchDAO.updateRsdtInfoCrdIsu", vo);
	}
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateIfCrdDlvrTb(RsdtInfrVO vo){
		return update("rsdtBatchDAO.updateImCrdDlvrTb", vo);
	}

	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return int update of program
	 * @exception Exception--
	 */
	public int updateIfCrdFleSndTb(RsdtInfrVO vo){
		return update("rsdtBatchDAO.updateImCrdFleSndTb", vo);
	}	
	
	
	/**
	 * DAO-method for The resulting file processing. <br>
	 *
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return void
	 * @exception Exception
	 */
	public void insertImCrdIsuTbCmsErrB(RsdtInfrVO vo){
		insert("rsdtBatchDAO.insertImCrdIsuTbCmsErrB", vo);
	}
	
	/**
	 * DAO-method for The family tree delete <br>
	 *
	 * @param vo Input item for modifying program(FmlyRlVO).
	 * @return void
	 * @exception Exception
	 */
	public void deleteFmlyTreeRqstPrc(FmlyRlVO vo){
		delete("rsdtBatchDAO.deleteFmlyTreeRqstPrc", vo);
	}
	
	/**
	 * DAO-method for The family tree update <br>
	 *
	 * @param vo Input item for modifying program(FmlyRlVO).
	 * @return void
	 * @exception Exception
	 */
	public int updateFmlyTreeRqstPrc(FmlyRlVO vo){
		return update("rsdtBatchDAO.updateFmlyTreeRqstPrc", vo);
	}
	
	/**
	 * DAO-method for The family tree select <br>
	 *
	 * @param vo Input item for modifying program(FmlyRlVO).
	 * @return void
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListFmlyTreeRqstPrc(FmlyRlVO vo) throws Exception{
		return list("rsdtBatchDAO.selectListFmlyTreeRqstPrc", vo);
	}
	
	/**
	 * DAO-method for The family tree insert <br>
	 *
	 * @param vo Input item for modifying program(FmlyRlVO).
	 * @return void
	 * @exception Exception
	 */
	public void insertFmlyTreeRqstPrc(FmlyRlVO vo){
		insert("rsdtBatchDAO.insertFmlyTreeRqstPrc", vo);
	}
	
	/**
	 * DAO-method for The resulting file processing. <br>
	 *
	 * @param vo Input item for modifying program(RsdtBatchVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateImCrdIsuTbReadErr(RsdtInfrVO vo){
		return update("rsdtBatchDAO.updateImCrdIsuTbReadErr", vo);
	}
	
	
	/**
	 * DAO-method for retrieving list of wife information. <br>
	 *
	 * @param vo Input item for retrieving list of wife information(RsdtBatchVO).
	 * @return List Retrieve list of wife information
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtBatchVO> selectListMrrgMaleInfr(RsdtBatchVO vo) throws Exception{
		return list("rsdtBatchDAO.selectListMrrgMaleInfr", vo);
	}
	
	/**
	 * DAO-method for retrieving list of husband and  husband's wife information. <br>
	 *
	 * @param vo Input item for retrieving list of husband and  husband's wife information(RsdtBatchVO).
	 * @return List Retrieve  list of husband and  husband's wife information
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtBatchVO> selectListMrrgFeMaleInfr(RsdtBatchVO vo) throws Exception{
		return list("rsdtBatchDAO.selectListMrrgFeMaleInfr", vo);
	}
	
	/**
	 * DAO-method for insert marriage information <br>
	 *
	 * @param vo Input item for insert marriage information(RsdtBatchVO).
	 * @return 
	 * @exception Exception
	 */
	public void insertMrrgInfr(RsdtBatchVO rsdtDat) throws Exception{
		insert("rsdtBatchDAO.insertMrrgInfr", rsdtDat);

	}
	
	
	/**
	 * DAO-method for family tree count <br>
	 *
	 * @param vo Input item for count information(FmlyRlVO).
	 * @return int
	 * @exception Exception
	 */
	public int selectFmlyTreeRqstPrc(FmlyRlVO vo) throws Exception{
		return (Integer)selectByPk("rsdtBatchDAO.selectFmlyTreeRqstPrc", vo);
	}
	
	
	/**
	 * DAO-method for Flexible Report Generation <br>
	 *
	 * @param Map
	 * @return Map
	 * @exception Exception
	 */
	public Map<String, String> addRpotRqstGnr(Map<String, String> map) throws Exception{
		update("rsdtBatchDAO.insertRpotRqstGnr", map);
		return map;
	}
	
	/**
	 * DAO-method for checking code length and province length  <br>
	 *
	 * @param 
	 * @return String
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtBatchVO> selectListLnthChek(RsdtBatchVO vo) throws Exception{
		return list("rsdtBatchDAO.selectListLnthChek", vo);
	}	
}
