package afnid.rm.batch.service;

import afnid.cm.ComDefaultVO;

public class RsdtBatchVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	private String crnDd;
	private String wrkCd;
	private String wrkStt;
	private String wrkEdDt;
	private String tableNm;	
	private String yy;
	private String tgtCn;
	private String errCn;
	private String errYn;
	private String msg;
	private String wrkSysCd;
	private String userId;
	private String gYmd;
	private int resultCnt;
	private String bioKey;
	private String rsdtNo;
	private String rsdtSeqNo;
	private String bioSeqNo;
	private String bioDptSeqNo;	
	private String gdrCd;
	private String ccltSeqNo;
	private String spusRsdtSeqNo;
	private String spusMrrgCd;
	private String tye;
	private String rsdtStusCd;
	private String ersrCd;
	
	private String grpCdnm;
	private String cdNm;
	private String erorMsg;
	
	public String getCrnDd() {
		return crnDd;
	}
	public void setCrnDd(String crnDd) {
		this.crnDd = crnDd;
	}
	public String getWrkCd() {
		return wrkCd;
	}
	public void setWrkCd(String wrkCd) {
		this.wrkCd = wrkCd;
	}
	public String getWrkStt() {
		return wrkStt;
	}
	public void setWrkStt(String wrkStt) {
		this.wrkStt = wrkStt;
	}
	public String getWrkEdDt() {
		return wrkEdDt;
	}
	public void setWrkEdDt(String wrkEdDt) {
		this.wrkEdDt = wrkEdDt;
	}
	public String getTableNm() {
		return tableNm;
	}
	public void setTableNm(String tableNm) {
		this.tableNm = tableNm;
	}
	public String getYy() {
		return yy;
	}
	public void setYy(String yy) {
		this.yy = yy;
	}
	public String getTgtCn() {
		return tgtCn;
	}
	public void setTgtCn(String tgtCn) {
		this.tgtCn = tgtCn;
	}
	public String getErrCn() {
		return errCn;
	}
	public void setErrCn(String errCn) {
		this.errCn = errCn;
	}
	public String getErrYn() {
		return errYn;
	}
	public void setErrYn(String errYn) {
		this.errYn = errYn;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getWrkSysCd() {
		return wrkSysCd;
	}
	public void setWrkSysCd(String wrkSysCd) {
		this.wrkSysCd = wrkSysCd;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getgYmd() {
		return gYmd;
	}
	public void setgYmd(String gYmd) {
		this.gYmd = gYmd;
	}
	public int getResultCnt() {
		return resultCnt;
	}
	public void setResultCnt(int resultCnt) {
		this.resultCnt = resultCnt;
	}
	public String getBioKey() {
		return bioKey;
	}
	public void setBioKey(String bioKey) {
		this.bioKey = bioKey;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getBioSeqNo() {
		return bioSeqNo;
	}
	public void setBioSeqNo(String bioSeqNo) {
		this.bioSeqNo = bioSeqNo;
	}
	public String getBioDptSeqNo() {
		return bioDptSeqNo;
	}
	public void setBioDptSeqNo(String bioDptSeqNo) {
		this.bioDptSeqNo = bioDptSeqNo;
	}
	public String getGdrCd() {
		return gdrCd;
	}
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	public String getCcltSeqNo() {
		return ccltSeqNo;
	}
	public void setCcltSeqNo(String ccltSeqNo) {
		this.ccltSeqNo = ccltSeqNo;
	}
	public String getSpusRsdtSeqNo() {
		return spusRsdtSeqNo;
	}
	public void setSpusRsdtSeqNo(String spusRsdtSeqNo) {
		this.spusRsdtSeqNo = spusRsdtSeqNo;
	}
	public String getSpusMrrgCd() {
		return spusMrrgCd;
	}
	public void setSpusMrrgCd(String spusMrrgCd) {
		this.spusMrrgCd = spusMrrgCd;
	}
	public String getTye() {
		return tye;
	}
	public void setTye(String tye) {
		this.tye = tye;
	}
	public String getRsdtStusCd() {
		return rsdtStusCd;
	}
	public void setRsdtStusCd(String rsdtStusCd) {
		this.rsdtStusCd = rsdtStusCd;
	}
	public String getErsrCd() {
		return ersrCd;
	}
	public void setErsrCd(String ersrCd) {
		this.ersrCd = ersrCd;
	}
	public String getGrpCdnm() {
		return grpCdnm;
	}
	public void setGrpCdnm(String grpCdnm) {
		this.grpCdnm = grpCdnm;
	}
	public String getCdNm() {
		return cdNm;
	}
	public void setCdNm(String cdNm) {
		this.cdNm = cdNm;
	}
	public String getErorMsg() {
		return erorMsg;
	}
	public void setErorMsg(String erorMsg) {
		this.erorMsg = erorMsg;
	}	
		
}
