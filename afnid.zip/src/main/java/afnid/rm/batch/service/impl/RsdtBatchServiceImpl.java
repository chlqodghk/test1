package afnid.rm.batch.service.impl;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.codec.binary.Base64;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import si.osi.dsig.XMLDsigValidate;
import si.osi.dsig.XMLSignerP11;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.error.NidException;
import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.batch.service.RsdtBatchService;
import afnid.rm.batch.service.RsdtBatchVO;
import afnid.rm.fmly.service.FmlyRlVO;
import afnid.rm.rsdt.service.RsdtInfrVO;
import afnid.rm.rsdt.service.impl.MRZUtil;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;

import com.dongdo.etazkira.Common.commonUtil;

import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of common
 * and implements FmlyInfoService class.
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.04  		BH Choi         		Create
 *
 * </pre>
 */
@Service("rsdtBatchService")
public class RsdtBatchServiceImpl extends AbstractServiceImpl implements RsdtBatchService {
	/** rsdtBatchDAO */
    @Resource(name="rsdtBatchDAO")
    private RsdtBatchDAO dao;
    
    /** ID Generation */
    //@Resource(name="egovIdGnrService")    
    //private EgovIdGnrService egovIdGnrService;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    @Resource(name="lgDAO")
    private LgDAO lgDao;

    @Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtInfrDAO;
    
    /**
 	 * Biz-method for Bio Dup Citizen Revocation <br>
 	 *
 	 * @param N/A
 	 * @return void
 	 * @exception Exception
 	 */
 	public void rvctgRsdtBioDup() throws Exception {

   		RsdtBatchVO  vo = new RsdtBatchVO();
   		RsdtBatchVO  rsdtDat = new RsdtBatchVO();
   		RsdtInfrVO   rsdtVo = new RsdtInfrVO();
		String resultSgnt = "";   		
   		int resultCnt = 0;
   		String hash ="";
   		String ccltSeqNo = "";
   		//get start time
   		String wrkStDt = dao.selectJobDt("");
   		
   		List<RsdtBatchVO> rsdtList = dao.selectListBioDupRsdt("");

		resultCnt = rsdtList.size();
		
		for(int i = 0; i<resultCnt; i++) {
			rsdtDat = rsdtList.get(i);
			rsdtDat.setUserId("SYSTEM");
   		   	//insert citizen history		
			rsdtInfrDAO.insertRsdtInfrHst(rsdtDat.getRsdtSeqNo(), rsdtDat.getUserId());
   			
			//insert revocation(RM_CCLT_TB)
			ccltSeqNo = dao.insertRsdtCctl(rsdtDat);

	   		//update citizen status (rm_rsdt_tb)	   				
			dao.updateBioDupRsdt(rsdtDat);
			
			//select citizen		
			EgovMap em = rsdtInfrDAO.selectRsdtInfrDat(rsdtDat.getRsdtSeqNo());
			
	   		//get server signature
			hash  = rsdtInfrDAO.selectRsdtInfrHashDat(em, "21");
								
	   		//cut server signature
			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
			if(hash != null && hash.indexOf(reg) == -1){
				String admTelNo = nidMessageSource.getMessage("admTelNo");
				throw processException("pki.websrvcEror.msg", new String[]{hash, admTelNo});
			}
			
   			resultSgnt = getXmlData(hash, "ds:Signature");	

   			//update server signature (rm_rsdt_tb table)
	   		if(resultSgnt != null && resultSgnt.length() > 0){
	   			rsdtVo.setRsdtSeqNo(rsdtDat.getRsdtSeqNo());
	   			rsdtVo.setSysSgnt(resultSgnt);		   			
	   			rsdtInfrDAO.updateRsdtInfrSysSgnt(rsdtVo);
	   		}
	   		
	   		// update citizen status processing(IM_BIO_DPT_TB table)	   		
   			dao.updateBioDupRsdtPrcss(rsdtDat.getBioDptSeqNo());
   			
   			RsdtBatchVO mrrgDat = new RsdtBatchVO();
   			if( "1".equals(rsdtDat.getGdrCd()) ){  				
   				List <RsdtBatchVO> mrrgLst = dao.selectListMrrgMaleInfr(rsdtDat);
   				
   				for(int j=0; j<mrrgLst.size(); j++){
   					mrrgDat = mrrgLst.get(j);
   					mrrgDat.setCcltSeqNo(ccltSeqNo);
   					mrrgDat.setRsdtSeqNo(rsdtDat.getRsdtSeqNo());
   					dao.insertMrrgInfr(mrrgDat);
   				}
   			} else {    				
   				List <RsdtBatchVO> mrrgLst = dao.selectListMrrgFeMaleInfr(rsdtDat);
   				
   				for(int j=0; j<mrrgLst.size(); j++){
   					mrrgDat = mrrgLst.get(j);
   					mrrgDat.setCcltSeqNo(ccltSeqNo);
   					mrrgDat.setRsdtSeqNo(rsdtDat.getRsdtSeqNo());
   					dao.insertMrrgInfr(mrrgDat);
   				}   				
   			}
	   		
		}
		
		//get finish time
   		String wrkEdDt = dao.selectJobDt("");
   		
   		//insert batch process log   		
		vo.setUserId("SYSTEM");		
   		vo.setWrkStt(wrkStDt);
   		vo.setWrkEdDt(wrkEdDt);
   		vo.setResultCnt(resultCnt);
   		vo.setWrkSysCd("2");   
   		vo.setWrkCd("17");

   		dao.insertJobLog(vo);
 	}

     /**
 	 * Biz-method for citizen status change<br>
 	 *
 	 * @param N/A
 	 * @return void
 	 * @exception Exception
 	 */
 	public void rsdtStusAtv() throws Exception {

   		RsdtBatchVO  vo = new RsdtBatchVO();
   		RsdtBatchVO  rsdtDat = new RsdtBatchVO();
   		RsdtInfrVO   rsdtVo = new RsdtInfrVO();
		String resultSgnt = "";   		
   		int resultCnt = 0;
   		String hash ="";
   		
   		//get start time
   		String wrkStDt = dao.selectJobDt("");
   		
   		List<RsdtBatchVO> rsdtList = dao.selectListRsdtStusAtv("");

		resultCnt = rsdtList.size();

		for(int i = 0; i<resultCnt; i++) {
			rsdtDat = rsdtList.get(i);
			rsdtDat.setUserId("SYSTEM");
   		   	//insert citizen history
			rsdtInfrDAO.insertRsdtInfrHst(rsdtDat.getRsdtSeqNo(), rsdtDat.getUserId());
   			
	   		//update citizen status (rm_rsdt_tb table)
			rsdtDat.setUserId("SYSTEM");
			dao.updateRsdtStusAtv(rsdtDat);
			
			//select citizen
			EgovMap em = rsdtInfrDAO.selectRsdtInfrDat(rsdtDat.getRsdtSeqNo());
			
	   		//get server signature
			hash  = rsdtInfrDAO.selectRsdtInfrHashDat(em, "20");
								
	   		//cut server signature
			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
			if(hash != null && hash.indexOf(reg) == -1){
				String admTelNo = nidMessageSource.getMessage("admTelNo");
				throw processException("pki.websrvcEror.msg", new String[]{hash, admTelNo});
			}
			
   			resultSgnt = getXmlData(hash, "ds:Signature");	

   			//update server signature (rm_rsdt_tb table)
	   		if(resultSgnt != null && resultSgnt.length() > 0){
	   			rsdtVo.setRsdtSeqNo(rsdtDat.getRsdtSeqNo());
	   			rsdtVo.setSysSgnt(resultSgnt);
	   			rsdtInfrDAO.updateRsdtInfrSysSgnt(rsdtVo);
	   		}
	   		
	   		// update citizen status processing(IM_BIO_CRD_ISU_TB table)
   			dao.updateRsdtStusAtvPrcss(rsdtDat.getBioSeqNo());
	   		
		}
		
		//get finish time
   		String wrkEdDt = dao.selectJobDt("");
   		
   		//insert batch process log
   		vo.setUserId("SYSTEM");
   		vo.setWrkStt(wrkStDt);
   		vo.setWrkEdDt(wrkEdDt);
   		vo.setResultCnt(resultCnt);
   		vo.setWrkSysCd("2");   
   		vo.setWrkCd("16");

   		dao.insertJobLog(vo);
 	}

    /**
	 * Biz-method for citizen status change<br>
	 *
	 * @param N/A
	 * @return void
	 * @exception Exception
	 */
   	public int modifyRsdtStusAtv(String userId) throws Exception {

   		RsdtBatchVO  vo = new RsdtBatchVO();
   		RsdtBatchVO  rsdtDat = new RsdtBatchVO();
   		RsdtInfrVO   rsdtVo = new RsdtInfrVO();
		String resultSgnt = "";   		
   		int resultCnt = 0;
   		String hash ="";
   		
   		//get start time
   		String wrkStDt = dao.selectJobDt("");
   		
   		List<RsdtBatchVO> rsdtList = dao.selectListRsdtStusAtv("");

		resultCnt = rsdtList.size();

		for(int i = 0; i<resultCnt; i++) {
			rsdtDat = rsdtList.get(i);
			//insert citizen history
			rsdtInfrDAO.insertRsdtInfrHst(rsdtDat.getRsdtSeqNo(), userId);
   			
	   		//update citizen status (rm_rsdt_tb table)
			rsdtDat.setUserId(userId);
			dao.updateRsdtStusAtv(rsdtDat);
			
			//select citizen
			EgovMap em = rsdtInfrDAO.selectRsdtInfrDat(rsdtDat.getRsdtSeqNo());
			
	   		//get server signature
			hash  = rsdtInfrDAO.selectRsdtInfrHashDat(em, "20");
								
	   		//cut server signature
			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
			if(hash != null && hash.indexOf(reg) == -1){
				String admTelNo = nidMessageSource.getMessage("admTelNo");
				throw processException("pki.websrvcEror.msg", new String[]{hash, admTelNo});
			}
			
   			resultSgnt = getXmlData(hash, "ds:Signature");	

   			//update server signature (rm_rsdt_tb table)
	   		if(resultSgnt != null && resultSgnt.length() > 0){	   			
	   			rsdtVo.setRsdtSeqNo(rsdtDat.getRsdtSeqNo());
	   			rsdtVo.setSysSgnt(resultSgnt);
	   			rsdtInfrDAO.updateRsdtInfrSysSgnt(rsdtVo);
	   		}
	   		
	   		// update citizen status processing(IM_BIO_CRD_ISU_TB table)
   			dao.updateRsdtStusAtvPrcss(rsdtDat.getBioSeqNo());
	   		
		}
		
		//get finish time
   		String wrkEdDt = dao.selectJobDt("");
   		
   	//insert batch process log 
   		vo.setUserId(userId);
   		vo.setWrkStt(wrkStDt);
   		vo.setWrkEdDt(wrkEdDt);
   		vo.setResultCnt(resultCnt);
   		vo.setWrkSysCd("2");   
   		vo.setWrkCd("16");

   		dao.insertJobLog(vo);
   		
   		return resultCnt;
   		
   	}

	   
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param String, String
   	 * @return String
   	 * @exception Exception
   	 */
   	public String getXmlData(String xml, String tag) throws Exception{
    	String result = "";
    	if(xml != null && tag != null && xml.length() > 0 && tag.length() > 0){
        	result = xml;
        	int str = result.indexOf("<"+tag);
        	int end = result.lastIndexOf("</"+tag+">");
        	result = result.substring(str, end+3+tag.length());
    	}
    	return result;
    }
  	 
   	/**
   	 * Biz-method for Card issuing new data generation of program. <br>
   	 *
   	 * @param void
   	 * @return EgovMap object of program
   	 * @exception Exception
   	 */
   	public EgovMap actionXmlGenerateDpp() throws Exception {
   		return actionXmlGenerateDpp(null);
   	}
   	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vos Input item for retrieving of program(RsdtInfrVO).
   	 * @return EgovMap object of program
   	 * @exception Exception
   	 */
   	public EgovMap actionXmlGenerateDpp(RsdtInfrVO vos) throws Exception {
   		
   		EgovMap resultLnthChk = new EgovMap();   		
   		RsdtBatchVO batchVo = new RsdtBatchVO();
   		
   		//length 체크
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();

		if(user == null){
			batchVo.setUseLangCd("3");
		} else {
			if("".equals(user.getUserId())){
				batchVo.setUseLangCd("3");
			} else{
				batchVo.setUseLangCd(user.getUseLangCd());
			}    			    		    			
		}

   		List<RsdtBatchVO> lnthChkList = dao.selectListLnthChek(batchVo);
   		
   		RsdtInfrVO vo = vos;
   		if(vo == null){
   			vo = new RsdtInfrVO();
   		}
   		String ddMmYyyy = "";
   		String yyyyMmDd = "";
   		String hhMm = "";
   		String hhMmSi = "";
   		String yyyyMmDdHhMiSs = getYyyyMmDdHhMiSs();
   		if(yyyyMmDdHhMiSs != null && yyyyMmDdHhMiSs.length() == 14){
   			yyyyMmDd = yyyyMmDdHhMiSs.substring(0, 8);
   			ddMmYyyy = yyyyMmDd.substring(6,8)+yyyyMmDd.substring(4,6)+yyyyMmDd.substring(0,4);
   			hhMmSi = yyyyMmDdHhMiSs.substring(8, 14);
   			hhMm = hhMmSi.substring(0, 4);
   		}

   		if(lnthChkList != null ){
   			if(lnthChkList.size() > 0){
   				RsdtBatchVO rowDat = new RsdtBatchVO();
   				String erorMsg ="";
   				String pviceNm ="";
   				String codeNm ="";
   				String[] arg = {"",""};
   				int tye1Cnt = 0;
	   			for(int i=0; i<lnthChkList.size(); i++){
	   				rowDat = lnthChkList.get(i);
	   				//generate error message
	   				if("1".equals(rowDat.getTye()) ){
	   					tye1Cnt = tye1Cnt+1;
	   				}
	   			}
	   			
	   			tye1Cnt = tye1Cnt -1;
	   			
	   			for(int i=0; i<lnthChkList.size(); i++){
	   				rowDat = lnthChkList.get(i);
	   				//generate error message
	   				if("1".equals(rowDat.getTye()) ){
	   					if(i == tye1Cnt){
	   						pviceNm = pviceNm + rowDat.getNm();
	   					}else {
	   						pviceNm = pviceNm + rowDat.getNm() + " , ";
	   					}
	   					
	   				} else {
	   					arg[0] =rowDat.getNm();
	   					arg[1] =rowDat.getCdNm();
	   					codeNm = codeNm + nidMessageSource.getMessage(batchVo.getUseLangCd(), "cdLnthOver.msg", arg) + " ";
	   				}
	   			}
	   			
	   			//log insert
	   			if(pviceNm.length() > 1){
	   				String[] argNm = {"["+pviceNm+"]"};
	   				erorMsg = nidMessageSource.getMessage(batchVo.getUseLangCd(), "araLnthOver.msg", argNm) + " ";
	   			}
	   			
	   			if(codeNm.length() > 1){
	   				erorMsg = erorMsg + " " + codeNm;
	   			}

	   			if(erorMsg.length() > 2000){
	   				erorMsg = nidMessageSource.getMessage(batchVo.getUseLangCd(), "araCdLnthOver.msg");
	   			} 
	   			
		   		RsdtInfrVO sendFilevo = new RsdtInfrVO();
		        sendFilevo.setWrkSttDt(yyyyMmDdHhMiSs);
		   		sendFilevo.setWrkEdDt(yyyyMmDdHhMiSs);
		   		sendFilevo.setOrgnzCd("2");
		   		sendFilevo.setFleLc("");
		   		sendFilevo.setTgtCn("");
		   		sendFilevo.setScsCn("");
		   		sendFilevo.setErorCn("");
		   		sendFilevo.setErorYn("Y");
		   		sendFilevo.setMsg(erorMsg);
		   		sendFilevo.setPrcssDivCd("3");
	    		//crdIsuceStusCd	    		
	    		if(user == null){
	    			sendFilevo.setUserId("SYSTEM");
	    		} else {
	    			if("".equals(user.getUserId())){
	    				sendFilevo.setUserId("SYSTEM");
	    			} else{
	    				sendFilevo.setUserId(user.getUserId());
	    			}    			    		    			
	    		}

		   		dao.insertIntoXmlBatchSnd(sendFilevo);
		   		
	   			resultLnthChk.put("erorMsg", "erorMsg");
	   			return resultLnthChk;
   			}
   		} 
   		
   		String xmlImg = propertiesService.getString("dpp.local.xml.send.base");
   		int addCnt = 0;
   		List<EgovMap> resultDpp = dao.selectListXmlGenerateDpp(vo);
   		if(resultDpp != null && !resultDpp.isEmpty()){
   			for(int i = 0 ; i < resultDpp.size(); i++){
   				EgovMap em = resultDpp.get(i);
   				em.put("ddMmYyyy", ddMmYyyy);
   				em.put("hhMm", hhMm);
   				em.put("xmlImg", xmlImg);
   				em.put("yyyyMmDd", yyyyMmDd);
   				em.put("hhMmSi", hhMmSi);
   				setXmlFileGen(em);
   				addCnt = addCnt + (Integer)em.get("addCnt");
   			}
   		}
		
   		// Bak files to a folder and then copy the generated

   		// Transfer to a separate file as a relay or control impl method will be written to.
   		// Increases, the amount of files that are sent Saved delay.
   		EgovMap result = new EgovMap();
   		result.put("ddMmYyyy", ddMmYyyy);
   		result.put("hhMm", hhMm);
   		result.put("yyyyMmDd", yyyyMmDd);
   		result.put("hhMmSi", hhMmSi);

   		if(resultDpp != null && !resultDpp.isEmpty()){
   			result.put("cnt", addCnt);
   		}else{
   			result.put("cnt", addCnt);
   		}

   		//File copy
   		if(addCnt > 0){
   			//boolean flag = setSndXmlDat(result);
   			boolean flag = setSndXmlDatCopy(result);
   			result.put("flag", flag);
   		}

   		result.put("erorMsg", "");
   		
   		return result;
	}   	
   	
   	/**
	 * yyyyMmDd String make of program. <br>
	 *
	 * @param void
	 * @return String object of program
	 * @exception Exception
	 */
   	private String getYyyyMmDdHhMiSs() {
   		StringBuffer calString = new StringBuffer();
   		Calendar cal = Calendar.getInstance();
   		calString.append(cal.get(Calendar.YEAR));
   		String month = ""+(cal.get(Calendar.MONTH)+1);
   		calString.append(month.length() == 1 ? "0"+month : month);
   		String date = ""+cal.get(Calendar.DATE);
   		calString.append(date.length() == 1 ? "0"+date : date);
   		String hour = ""+cal.get(Calendar.HOUR_OF_DAY);
   		calString.append(hour.length() == 1 ? "0"+hour : hour);
   		String minute = ""+cal.get(Calendar.MINUTE);
   		calString.append(minute.length() == 1 ? "0"+minute : minute);
   		String second = ""+cal.get(Calendar.SECOND);
   		calString.append(second.length() == 1 ? "0"+second : second);
   		return calString.toString();
   	}   	
   	
   	/**
   	 * xml make of program. <br>
   	 *
   	 * @param egov Input item for retrieving of program(EgovMap).
   	 * @return boolean Whether to generate
   	 * @exception Exception
   	 */
   	private boolean setXmlFileGen(EgovMap egov) throws Exception {
   		String rsdtRgstId = (String)egov.get("code");
   		StringBuffer sb = new StringBuffer();
   		sb.append((String)egov.get("yyyyMmDd")).append((String)egov.get("hhMm"));
		RsdtInfrVO vo = new RsdtInfrVO();
		vo.setRsdtRgstIdNm(rsdtRgstId);
		List<EgovMap> resultLst = dao.selectXmlGenerateDpp(vo);
		if(resultLst != null && !resultLst.isEmpty()){
			int count = 0;
			int seq = 1;
			String seqNm = "01";
			String xmlImg = (String)egov.get("xmlImg");
			String yyyyMmDd = (String)egov.get("yyyyMmDd");
			String code = (String)egov.get("code");
			String hhMm = (String)egov.get("hhMm");

			File file = new File(xmlImg+File.separator+yyyyMmDd);
			File[] list = file.listFiles();
			//Check that the name of the file and then rounded up sequence.
			StringBuffer sbseqNm = new StringBuffer();
			if(list != null){
				StringBuffer buff = new StringBuffer();
				for(int i = 0; i < list.length; i++){
					String fileNm = list[i].getName();
					buff.setLength(0);
					buff.append(code).append("_").append(yyyyMmDd).append(hhMm).append("_").append(seqNm);
					if(fileNm.equals(buff.toString())){
						i = 0;
						seq++;
						seqNm = String.valueOf(seq);
						sbseqNm.setLength(0);
						if(seqNm != null && seqNm.length() == 1){
							seqNm = sbseqNm.append("0").append(seqNm).toString();
						}
					}
				}
			}
			while(count < resultLst.size()){
				count = setFileGen(resultLst, sb.toString(), count, egov, seqNm);
				seq++;
				seqNm = String.valueOf(seq);
				sbseqNm.setLength(0);
				if(seqNm != null && seqNm.length() == 1){
					seqNm = sbseqNm.append("0").append(seqNm).toString();
				}
			}
		}
   		return true;
   	}   	
   	
	/**
   	 * Biz-method for sftp  send of program. <br>
   	 *
   	 * @param egov Input item for retrieving list of program(EgovMap).
   	 * @return boolean For transmission
   	 * @exception Exception
   	 */
   	public boolean setSndXmlDatCopy(EgovMap egov) throws Exception {
   		String localSendBasePath = propertiesService.getString("dpp.local.xml.send.base");
   		String localSendBasePathBak = propertiesService.getString("dpp.local.xml.send.base.bak");
   		return actionSndDatCopy(localSendBasePath, localSendBasePathBak, egov);
   	}
   	   	
  	/**
	 * xml make of program. <br>
	 *
	 * @param list Input item for retrieving of program(List).
	 * @param yyyyMmDdHhMm Input item for retrieving of program(String).
	 * @param counts Input item for retrieving of program(int).
	 * @param emap Input item for retrieving of program(EgovMap).
	 * @param seqNm Input item for retrieving of program(String).
	 * @return int Whether to generate a number
	 * @exception Exception
	 */
	private int setFileGen(List<EgovMap>list, String yyyyMmDdHhMm, int counts, EgovMap emap, String seqNm) throws Exception {
   		int count = counts;
   		String cardProdType = propertiesService.getString("dpp.card.prod.type");
   		int cardRecode = propertiesService.getInt("dpp.card.recode");
   		Document doc = null;
   		Transformer transformer = null;
   		int limit = cardRecode;
   		int cnt = list.size()-count;
   		if(cnt > limit ){
   			limit = cardRecode;
   		}else{
   			limit = cnt;
   		}
   		String code = (String)emap.get("code");
		String codeNm = (String)emap.get("codeNm");
		String yyyyMmDd = (String)emap.get("yyyyMmDd");
		String hhMmSi = (String)emap.get("hhMmSi");

   		StringBuffer sb = new StringBuffer();
   		sb.append(code);
   		sb.append("_");
   		sb.append(yyyyMmDdHhMm);
   		sb.append("_").append(seqNm);
   		String imageDir = sb.toString();
   		sb.append(".tmp");

   		// Save the file and create directories
		String xmlImg = (String)emap.get("xmlImg");
		//String xmlFile = xmlImg + File.separator +  yyyyMmDd;
		String xmlFile = xmlImg;
		xmlImg = xmlImg + File.separator + yyyyMmDd + File.separator + imageDir;

		String wrkSttDt = dao.selectDppDbDatTime(new RsdtInfrVO());

		String base = propertiesService.getString("xmlEncode");

		File xmlImgDir = new File(xmlImg);
		//If there is data to send generated directory
		if(list != null && !list.isEmpty()){

			xmlImgDir = new File(xmlFile);

			//Delete the existing file
			//if(count == 0){
				//isDltDir(xmlImgDir);
			//}

			if(!xmlImgDir.isDirectory()){
				xmlImgDir.mkdir();
	  	   	}
			//StringBuffer sbXml = new StringBuffer();
			//sbXml.setLength(0);
			//sbXml.append(xmlFile).append(File.separator).append(yyyyMmDd).append(hhMmSi);
			//xmlFile = sbXml.toString();
			//xmlImgDir = new File(xmlFile);
			//if(!xmlImgDir.isDirectory()){
			//	xmlImgDir.mkdir();
	  	   	//}

			if(base != null && "none".equals(base)){
				xmlImg = xmlFile + File.separator +  imageDir;
				xmlImgDir = new File(xmlImg);

				if(!xmlImgDir.isDirectory()){
					xmlImgDir.mkdir();
		  	   	}
			}
		}

   		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
   	   	DocumentBuilder docBuilder = null;
   	   	docBuilder = docFactory.newDocumentBuilder();
   	   	doc = docBuilder.newDocument();
   	   	TransformerFactory transformerFactory = TransformerFactory.newInstance();
   	   	transformer = transformerFactory.newTransformer();
   	   	transformer.setOutputProperty(OutputKeys.ENCODING,"UTF-8");
   	   	transformer.setOutputProperty(OutputKeys.INDENT,"yes");

   	   	Element rootElement = doc.createElement("root");
   	   	doc.appendChild(rootElement);

   	   	Element element = addElement(doc, rootElement,  "Header", null);

   	   	addElement(doc, element,  "Date", yyyyMmDdHhMm.substring(0, 8));
   		addElement(doc, element,  "File_Name", imageDir+".xml");
   		addElement(doc, element,  "Data_Count", String.valueOf(limit));
   		addElement(doc, element,  "IssuanceOffice", code +" " + codeNm);
   		addElement(doc, element,  "CardProdType", cardProdType);

   		StringBuffer pasd = new StringBuffer();

   		int xmlAddCnt = 0;
   		RsdtInfrVO vos = new RsdtInfrVO();

   		//imsi start
   		//Transformer transformers = null;
   		Document docs = null;
   		DocumentBuilderFactory docFactorys = DocumentBuilderFactory.newInstance();
   	   	DocumentBuilder docBuilders = null;
   	   	docBuilders = docFactorys.newDocumentBuilder();
   	   	docs = docBuilders.newDocument();

   	   	Document doch = null;
		DocumentBuilderFactory docFactoryh = DocumentBuilderFactory.newInstance();
	   	DocumentBuilder docBuilderh = null;
	   	docBuilderh = docFactoryh.newDocumentBuilder();
	   	doch = docBuilderh.newDocument();
   	   	/*TransformerFactory transformerFactorys = TransformerFactory.newInstance();
   	   	transformers = transformerFactorys.newTransformer();
   	   	transformers.setOutputProperty(OutputKeys.ENCODING,"UTF-8");
   	   	transformers.setOutputProperty(OutputKeys.INDENT,"yes");*/

   	   	Element rootElements = docs.createElement("root");
	   	docs.appendChild(rootElements);

	   	Element rootElementh = doch.createElement("root");
	   	doch.appendChild(rootElementh);
   	   	//imsi end

   		for(int i = 0; i < limit; i ++, count++){
   			EgovMap egov = list.get(count);

   			vos = vos.init();
   			vos.setRsdtNo((String)egov.get("rsdtNo"));
   			vos.setBioKey((String)egov.get("bioKey"));

			xmlAddCnt++;
   			EgovMap eBlob = dao.selectXmlBlobDpp(vos);

   			element = addElement(doc, rootElement,  "Person", null);

   			addElement(doc, element,  "Record_Number", String.valueOf(xmlAddCnt));

   			addElement(doc, element,  "e-TazkeraNumber", toNumPerConvet((String)egov.get("rsdtNoDp")));

  			String surnm = (String)egov.get("surnm");
   			String givNm = (String)egov.get("givNm");

   			if(surnm != null){
   				if("null".equals(surnm)){
   					surnm = "";
   				}
   			}else{
   				surnm = "";
   			}

   			if(surnm != null && !"".equals(surnm)){
   				surnm = "\"" + surnm;
   				givNm = "\"" + givNm;
   			}

   			String fullName = surnm.length() > 0 ? givNm + surnm : givNm;

   			addElement(doc, element,  "FullName", fullName);
   			addElement(doc, element,  "EnglishName", (String)egov.get("enNm"));
   			addElement(doc, element,  "FatherName", (String)egov.get("fthrNm"));
   			addElement(doc, element,  "DateOfBirth", toNumPerConvet((String)egov.get("bthDdFa")));
   			addElement(doc, element,  "DateOfBirth_EN", (String)egov.get("bthDdD"));
   			addElement(doc, element,  "PermanentAddress", (String)egov.get("pmntAdCDCr"));
   			addElement(doc, element,  "PresentAddress", (String)egov.get("curtAdCdPro"));
   			addElement(doc, element,  "DateOfIssue_EN", (String)egov.get("crdIsuceDdD"));
   			addElement(doc, element,  "DateOfIssue", toNumPerConvet((String)egov.get("crdIsuceDdFa")));
   			addElement(doc, element,  "GrandfatherName", (String)egov.get("gfthrNm"));
   			addElement(doc, element,  "Gender_EN", (String)egov.get("gdrCdEn"));
   			addElement(doc, element,  "PlaceOfBirth", (String)egov.get("bthPlceCdCr"));
   			addElement(doc, element,  "PlaceOfBirth_EN", (String)egov.get("bthPlceCdCrEn"));

   			String rsdtNo = (String)egov.get("rsdtNoDp");
   			String ext = ".bmp";
   			String phImg = "";
   	   		if(eBlob != null && eBlob.get("phImg") != null){
   	   			phImg = rsdtNo + "_Photo";
   	   			if(base != null && "none".equals(base)){
   	   				setFileMake((byte[])eBlob.get("phImg"), xmlImg + File.separator + phImg, ext);
   	   			}

   	   		}
   	   		String sgntImg = "";
   	   		if(eBlob != null && eBlob.get("sgntImg") != null){
   	   			sgntImg = rsdtNo + "_Signature";
   	   			if(base != null && "none".equals(base)){
   	   				setFileMake((byte[])eBlob.get("sgntImg"), xmlImg + File.separator + sgntImg, ext);
   	   			}
   	   		}
   	   		//imsi
   	   		if(eBlob != null && eBlob.get("phImg") != null){
	   	   		byte [] arrays = (byte[])eBlob.get("phImg");
	   	   		if(base != null && "base64".equals(base)){
	   	   			if(arrays != null){
	   	   				arrays = Base64.encodeBase64(arrays);
	   	   				phImg = new String(arrays);
	   	   			}
	   	   		}else if(base != null && "hex".equals(base)){
	   	   			if(arrays != null){
	   	   				phImg = getByteToHexStr(arrays);
		   			}
	   	   		}else{
	   	   			phImg = phImg.length() > 0 ? phImg+ext : phImg;
	   	   		}
   	   		}else{
   	   			phImg = "";
   	   		}
	   	   	if(eBlob != null && eBlob.get("sgntImg") != null){
	   	   		byte [] arrays = (byte[])eBlob.get("sgntImg");
	   	   		if(base != null && "base64".equals(base)){
	   	   			if(arrays != null){
	   	   				arrays = Base64.encodeBase64(arrays);
	   	   				sgntImg = new String(arrays);
	   	   			}
	   	   		}else if(base != null && "hex".equals(base)){
	   	   			if(arrays != null){
	   	   				sgntImg = getByteToHexStr(arrays);
		   			}
	   	   		}else{
	   	   			sgntImg = sgntImg.length() > 0 ? sgntImg+ext : sgntImg;
	   	   		}
	   		}else{
	   			sgntImg = "";
	   		}
   			addElement(doc, element,  "PhotographOfCardHolder", phImg);
   			addElement(doc, element,  "SignatureOfCardHolder", sgntImg);
   			//addElement(doc, element,  "PhotographOfCardHolder", phImg.length() > 0 ? phImg+ext : phImg);
   			//addElement(doc, element,  "SignatureOfCardHolder", sgntImg.length() > 0 ? sgntImg+ext : sgntImg);
   	   		//addElement(doc, element,  "PhotographOfCardHolder", eBlob.get("phImg") != null ? byteArrToHexStr((byte[])eBlob.get("phImg")) : null);
   			//addElement(doc, element,  "SignatureOfCardHolder", eBlob.get("sgntImg") != null ? byteArrToHexStr((byte[])eBlob.get("sgntImg")) : null);
   			addElement(doc, element,  "e-TazkeraNumber_EN",  (String)egov.get("rsdtNoDp"));

   			String mrz = MRZUtil.getMrzStr(
   					"AFG"
   					,(String)egov.get("mrzNid1")
   					,(String)egov.get("mrzNid2")
   					,(String)egov.get("mrzDateOfBirth")
   					,(String)egov.get("mrzSex")
   					,(String)egov.get("mrzDateOfExpiry")
   					,(String)egov.get("mrzSurName")
   					,(String)egov.get("mrzGivenName")
   				);
   			//String cdata = "<![CDATA[";
   			//String cdataend = "]]>";
   			String cdata = "";
   			String cdataend = "";

   			addElement(doc, element,  "MRZ1", cdata+mrz.substring(0, 30)+cdataend);
   			addElement(doc, element,  "MRZ2", cdata+mrz.substring(30, 60)+cdataend);
   			addElement(doc, element,  "MRZ3", cdata+mrz.substring(60, 90)+cdataend);
   			addElement(doc, element,  "BloodGroup", (String)egov.get("bldTyeCd"));
   			addElement(doc, element,  "ChipGender", (String)egov.get("gdrCd"));
   			addElement(doc, element,  "Ethnicity", (String)egov.get("encyCd"));
   			addElement(doc, element,  "MotherTongue", (String)egov.get("fmlyLangCd"));
   			addElement(doc, element,  "TypeOfDisabilities", (String)egov.get("dsbtDtlCt"));
   			addElement(doc, element,  "SummerResidence", (String)egov.get("smrRsdcCd"));
   			addElement(doc, element,  "WinterResidence", (String)egov.get("wtrRsdcCd"));
   			addElement(doc, element,  "Religion", (String)egov.get("rlgnCd"));
   			addElement(doc, element,  "ReligionSect", (String)egov.get("rlgnSectCd"));

   			String crdIsuceSrlNo = getEgovMapValue(egov, "crdIsuceSrlNo");
   			if(crdIsuceSrlNo != null){
   				if(crdIsuceSrlNo.length() == 1){
   					crdIsuceSrlNo = "0"+crdIsuceSrlNo;
   				}
   			}
   			
   			addElement(doc, element,  "SequenceOfIssuance", crdIsuceSrlNo);
   			addElement(doc, element,  "email", (String)egov.get("emlAd"));
   			//2015.03.14 add
   		    addElement(doc, element,  "DateOfExpiry_EN", (String)egov.get("crdExpiryDdD"));
   			String fgpCt = "";
			byte [] extArray = null;
   			if(eBlob != null && eBlob.get("fgpCt") != null){
   				fgpCt = rsdtNo + "_Fingerprint";
   				ext = ".bin";

   				byte [] array = (byte[])eBlob.get("fgpCt");
   				short len = (short)array.length;

   				byte [] lenArry = commonUtil.GetBytes(len);
 
   				byte[] fingerArry = new byte[len+lenArry.length];

   				System.arraycopy( lenArry, 0, fingerArry, 0, lenArry.length);
   				System.arraycopy( array, 0, fingerArry, lenArry.length, array.length);
   				if(base != null && "none".equals(base)){
   					setFileMake(fingerArry, xmlImg + File.separator + fgpCt, ext);
   				}
   	   			extArray = fingerArry;
   	   		}
   			if(eBlob != null && eBlob.get("fgpCt") != null){
	   	   		//byte [] arrays = (byte[])eBlob.get("fgpCt");
   				byte [] arrays = extArray;
	   	   		if(base != null && "base64".equals(base)){
	   	   			if(arrays != null){
	   	   				arrays = Base64.encodeBase64(arrays);
	   	   				fgpCt = new String(arrays);
	   	   			}
	   	   		}else if(base != null && "hex".equals(base)){
	   	   			if(arrays != null){
	   	   				fgpCt = getByteToHexStr(arrays);
		   			}
	   	   		}else{
	   	   			fgpCt = fgpCt.length() > 0 ? fgpCt+ext : fgpCt;
	   	   		}
	   		}else{
	   			fgpCt = "";
	   		}

   	   		addElement(doc, element,  "FingerPrint", fgpCt);
   			//addElement(doc, element,  "FingerPrint", fgpCt.length() > 0 ? fgpCt+ext : fgpCt);
   			//addElement(doc, element,  "FingerPrint", eBlob.get("fgpCt") != null ? byteArrToHexStr(extArray) : null);
   			addElement(doc, element,  "ChipPermanentAddress", (String)egov.get("pmntAdCd"));

   			String presentAddress = (String)egov.get("curtAdCd");
   			pasd.setLength(0);
   			pasd.append(presentAddress);
   			String curtAdDtlCt = (String)egov.get("curtAdDtlCt");
   			if (curtAdDtlCt != null) {
   				pasd.setLength(0);
   				pasd.append(curtAdDtlCt).append("/").append(presentAddress);
   			}
   			addElement(doc, element,  "ChipPresentAddress", pasd.toString());
   			addElement(doc, element,  "ChipDateOfExpiry", toNumPerConvet((String)egov.get("crdExpiryDdFa")));
   			addElement(doc, element,  "ChipPlaceOfBirth", (String)egov.get("bthPlceCd"));

   			addElement(doc, element,  "PkiRequestType", (String)egov.get("isuType"));
   			//Registered in the interface table
			setCrdIsuIfTb(egov, xmlFile+File.separator+sb.toString(), String.valueOf(xmlAddCnt) );

   		}

   		StreamResult result = null;
		DOMSource source = null;
   		FileOutputStream fos = null;
   		FileInputStream fis = null;

   		//StringBuffer sbb= new StringBuffer();
   		//StringBuffer sbh= new StringBuffer();
   		try{
   			fos = new FileOutputStream(new File(xmlFile, sb.toString()));
    		result = new StreamResult(fos);
    		source = new DOMSource(doc);
    		transformer.transform(source, result);
    		fos.close();


   		}catch(Exception e){
   			log.error(e);
   		}finally{
   			try{
   				if(fos != null){
   					fos.close();
   				}
   				if(fis != null){
   					fis.close();
   				}
   			}catch(Exception fe){
   				log.error(fe);
   			}
   		}

   		emap.put("addCnt", new Integer(xmlAddCnt));
   		if(xmlAddCnt == 0){
   			// Delete Folder xxxx
			File delFile = new File(xmlImg);
			delFile.delete();
			// Delete files xxxx.tmp
			delFile = new File(xmlFile+File.separator+sb.toString());
			delFile.delete();
			// If there is no file in the folder delete folder YYYYMMDDHHMISS
			delFile = new File(xmlFile);
			File[] filelist = delFile.listFiles();
			if(filelist != null && filelist.length == 0){
				delFile.delete();
			}
			// If there is no file in the folder delete folder YYYYMMDD
			String rootDel = (String)emap.get("xmlImg");
			StringBuffer sbRoot = new StringBuffer();
			sbRoot.append(rootDel).append(File.separator).append(yyyyMmDd);
			delFile = new File(sbRoot.toString());
			filelist = delFile.listFiles();
			if(filelist != null && filelist.length == 0){
				delFile.delete();
				System.gc();
			}
		}else{

			File dir = new File(xmlFile);
	        if(dir != null && dir.isDirectory()){
	        	File [] dirList = dir.listFiles();
	        	if(dirList != null && dirList.length > 0){
	        		File arry = null;
	        		File [] fileArry = null;
	        		for(int i = 0; i < dirList.length; i++){
	        			arry = dirList[i];
	        			if(arry != null && arry.isDirectory()){
	        				fileArry = arry.listFiles();
	        				if(fileArry != null && fileArry.length == 0){
	        					arry.delete();
	        					System.gc();
	        				}
	        			}
	        		}
	        	}
	        }

			String xmlFileNm = xmlFile+File.separator+sb.toString();

			//modified count data in xml file
			doc = docBuilder.parse(xmlFileNm);
			rootElement = doc.getDocumentElement();
			NodeList memberList = rootElement.getChildNodes();
			for(int i=0; i < memberList.getLength(); i++){
				Node node = memberList.item(i);
				if(node.getNodeType() == Node.ELEMENT_NODE) {
					if(node.getNodeName().equals("Header")){
						NodeList childNodeList = node.getChildNodes();
						for(int k=0; k < childNodeList.getLength(); k++){
			   				Node childNode = childNodeList.item(k);
			   				if(childNode.getNodeType() == Node.ELEMENT_NODE) {
			   					if(childNode.getNodeName().equals("Data_Count")){
			   						setXmlNodeVal(childNode, String.valueOf(xmlAddCnt));
			   					}
			   				}
						}
					}
				}
			}
			transformerFactory = TransformerFactory.newInstance();
	        transformer = transformerFactory.newTransformer();
	        source = new DOMSource(doc);
	        result = new StreamResult(new File(xmlFileNm));
	        transformer.transform(source, result);
	        // The end of the modified xml file save

	        try{
				File tmp = new File(xmlFile, sb.toString());
				if(tmp.isFile()){
					String oldFileNm = tmp.getAbsolutePath();
					fis = new FileInputStream(tmp);
					byte [] array = new byte[fis.available()];
					fis.read(array);
					
					Object obj = NidUserDetailsHelper.getAuthenticatedUser();
		   			String userId = "SYSTEM";
		   			if(obj != null && obj instanceof LgnVO){
		   				LgnVO user = (LgnVO)obj;
		   				userId = user.getUserId();
		   			}
		   			
					String lgSeqNo = lgDao.insertPubKeyIfLg(userId, oldFileNm, "18", "1", "14", "");
					
					String signature = XMLSignerP11.spkiIFDigitalSignature(array);
					
					String erorYn = "Y";
					String ccmResult = "";
					if(signature != null){
						String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
						if(signature.indexOf(reg) == -1){
							ccmResult = "ERROR";
						}else{
							ccmResult = "OK";
							erorYn = "N";
						}
					}
					lgDao.updatePubKeyIfLg(lgSeqNo, ccmResult, erorYn);
					
					fis.close();
					if(signature != null){
						String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
						if(signature.indexOf(reg) == -1){
							File exDelete = new File(xmlFile, sb.toString());
							exDelete.delete();
							System.gc();
							/*int limCnt = sb.toString().lastIndexOf(".tmp");
							String delDir = sb.toString().substring(0, limCnt);
							StringBuffer delBuffer = new StringBuffer();
							delBuffer.append(xmlFile);
							delBuffer.append(File.separator);
							delBuffer.append(delDir);
							delDir = delBuffer.toString();
							removeDIR(delDir);
							exDelete = new File(delDir);
							exDelete.delete();
							exDelete = new File(xmlFile);
							File[] filelist = exDelete.listFiles();
							if(filelist != null && filelist.length == 0){
								exDelete.delete();
							}
							// If there is no file in the folder delete folder YYYYMMDD
							String rootDel = (String)emap.get("xmlImg");
							StringBuffer sbRoot = new StringBuffer();
							sbRoot.append(rootDel).append(File.separator).append(yyyyMmDd);
							exDelete = new File(sbRoot.toString());
							filelist = exDelete.listFiles();
							if(filelist != null && filelist.length == 0){
								exDelete.delete();
								System.gc();
							}*/
							throw new NidException(signature);
						}
					}
					String xmlSendBak = propertiesService.getString("dpp.local.xml.send.base.bak");
		    		File xmlSendBakFile = new File(xmlSendBak);
		    		if(xmlSendBakFile != null && !xmlSendBakFile.isDirectory()){
		    			xmlSendBakFile.mkdir();
		    		}
		    		xmlSendBakFile = new File(xmlSendBak+File.separator+yyyyMmDd);
		    		if(xmlSendBakFile != null && !xmlSendBakFile.isDirectory()){
		    			xmlSendBakFile.mkdir();
		    		}
		    		xmlSendBakFile = new File(xmlSendBak+File.separator+yyyyMmDd+File.separator+yyyyMmDd+hhMmSi);
		    		if(xmlSendBakFile != null && !xmlSendBakFile.isDirectory()){
		    			xmlSendBakFile.mkdir();
		    		}

					fos = new FileOutputStream(new File(xmlSendBakFile, sb.toString()));
					fos.write(array);
					fos.close();
					File delete = new File(xmlFile, sb.toString());
					delete.delete();
					sb.setLength(0);
					sb.append(imageDir).append(".xml");
					File xmlNm = new File(xmlSendBak+File.separator+yyyyMmDd+File.separator+yyyyMmDd+hhMmSi, sb.toString());
					fos = new FileOutputStream(xmlNm);
					fos.write(signature.getBytes("UTF8"));
					fos.close();

					if(xmlNm != null && xmlNm.isFile() && oldFileNm != null){
						RsdtInfrVO reFileNm = new RsdtInfrVO();
						StringBuffer fleNm = new StringBuffer();
						fleNm.append(xmlFile).append(File.separator).append(sb.toString());
						reFileNm.setFleNm(fleNm.toString());
						reFileNm.setDescFleNm(oldFileNm);
						dao.updateImCrdIsuTbFleNm(reFileNm);
					}
				}

	   		}catch(Exception e){
	   			File exDelete = new File(xmlFile+File.separator+sb.toString());
	   			if(exDelete != null && exDelete.isFile()){
	   				exDelete.delete();
	   			}
				
				System.gc();
	   			log.error(e);
	   			throw e;
	   		}finally{
	   			try{
	   				if(fos != null){
	   					fos.close();
	   				}
	   				if(fis != null){
	   					fis.close();
	   				}
	   			}catch(Exception fe){
	   				log.error(fe);
	   			}
	   		}


		}

   		String wrkEdDt = dao.selectDppDbDatTime(new RsdtInfrVO());
   		//batch log chip
   		if(xmlAddCnt > 0){
	   		RsdtInfrVO sendFilevo = new RsdtInfrVO();
	        sendFilevo.setWrkSttDt(wrkSttDt);
	   		sendFilevo.setWrkEdDt(wrkEdDt);
	   		sendFilevo.setOrgnzCd(code);
	   		sendFilevo.setFleLc(xmlFile+File.separator+sb.toString());
	   		sendFilevo.setTgtCn(String.valueOf(limit));
	   		sendFilevo.setScsCn(String.valueOf(xmlAddCnt));
	   		sendFilevo.setErorCn(String.valueOf(limit-xmlAddCnt));
	   		sendFilevo.setErorYn("N");
	   		sendFilevo.setMsg("");
	   		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		if(user == null){
    			sendFilevo.setUserId("SYSTEM");
    		} else {
    			if("".equals(user.getUserId())){
    				sendFilevo.setUserId("SYSTEM");
    			} else{
    				sendFilevo.setUserId(user.getUserId());
    			}    			    		    			
    		}
    		
	   		sendFilevo.setPrcssDivCd("1");
	   		dao.insertIntoXmlBatchSnd(sendFilevo);
   		}
   		// You must create a list of file transfer.

   		return count;
   	}
   	
   	/**
	 * send file copy of program. <br>
	 *
	 * @param localSendBasePath Input item for retrieving list of program(String).
	 * @param remoteRecvBasePath Input item for retrieving list of program(String).
	 * @param egov Input item for retrieving list of program(EgovMap).
	 * @return void
	 * @exception Exception
	 */
   	private boolean actionSndDatCopy(String localSendBasePath, String localSendBasePathBak, EgovMap egov) throws Exception {
   		boolean flag = false;
   		String yyyyMmDd = (String)egov.get("yyyyMmDd");
   		String hhMmSi = (String)egov.get("hhMmSi");
   		//String dirPath = localSendBasePath + File.separator + yyyyMmDd + File.separator + yyyyMmDd + hhMmSi;
   		String dirPath = localSendBasePathBak + File.separator + yyyyMmDd + File.separator + yyyyMmDd + hhMmSi;
		File dir = new File(dirPath);
		if(dir.isDirectory()){
			File [] lists = dir.listFiles();
			if(lists != null && lists.length > 0){
				mkdir(localSendBasePathBak, "");
				mkdir(localSendBasePathBak, yyyyMmDd);
				mkdir(localSendBasePathBak, yyyyMmDd + File.separator+ yyyyMmDd+hhMmSi);
				String localSendBasePathBaks = localSendBasePathBak + File.separator + yyyyMmDd + File.separator + yyyyMmDd+hhMmSi;
				isDirFile(dir, localSendBasePathBaks, localSendBasePath);
				flag = true;
			}
		}
   		return flag;
   	}   	
   	
   	
   	/**
	 * xml Adding a node. <br>
	 *
	 * @param doc Input item for retrieving of program(Document).
	 * @param parElement Input item for retrieving of program(Element).
	 * @param eleName Input item for retrieving of program(String).
	 * @param eleValue Input item for retrieving of program(Object).
	 * @return Element object of Program
	 * @exception Exception
	 */
   	private Element addElement(Document doc, Element parElement, String eleName, Object eleValue){
   		Element element = doc.createElement(eleName);
   		if(eleValue != null){
   				String strEleValue = (String)eleValue;
   				if("null".equals(strEleValue)){
   					strEleValue = "";
   				}else if("null null".equals(strEleValue)){
   					strEleValue = "";
   				}
   			element.appendChild(doc.createTextNode(strEleValue));
   		}
   		parElement.appendChild(element);
   		return element;
   	}   	
   	
   	/**
	 * Change the digit local number. <br>
	 *
	 * @param number Input item for retrieving of program(String).
	 * @return String object of program
	 * @exception Exception
	 */
   	private String toNumPerConvet(String number){
   		String [] persianNumberArray = new String[]{"۰","۱","۲","۳","۴","۵","۶","۷","۸","۹"};
   		StringBuffer sb = new StringBuffer();
   		if(number != null){
	   		for(int i = 0;  i < number.length(); i++){
	   			String numChat = number.substring(i,i+1);
	   			if(Pattern.matches("^[0-9]*$", numChat)){
	   				sb.append(persianNumberArray[Integer.parseInt(numChat)]);
	   			}else{
	   				sb.append(numChat);
	   			}
	   		}
   		}
   		return sb.toString();
   	}

	private void setXmlNodeVal(Node node, String value){
		if(node.getFirstChild() != null){
			node.getFirstChild().setNodeValue(value);
		}
	}   	
   	
   	/**
	 * File is created of program. <br>
	 *
	 * @param arr Input item for retrieving of program(byte[]).
	 * @param file Input item for retrieving of program(String).
	 * @param ext Input item for retrieving of program(String).
	 * @return void
	 * @exception Exception
	 */
   	private void setFileMake(byte[] arr, String file, String ext){
   		FileOutputStream outstream = null;
		try {
			String files = file + ext;
			outstream = new FileOutputStream(new File(files));
			outstream.write(arr);
			outstream.close();
		} catch (FileNotFoundException fe) {
			log.error(fe);
		} catch (IOException ie) {
			log.error(ie);
		}finally{
			try{
				if(outstream != null) {
					outstream.close();
				}
			}catch(Exception e){
				log.error(e);
			}
		}
   	}   	
   	
	/**
	 * byte array to hex string. <br>
	 *
	 * @param arr Input item for retrieving of program(byte[]).
	 * @return String object of program
	 * @exception Exception
	 */
   	private String getByteToHexStr(byte[] arr){
   		 String result = "";
   		if(arr != null){
   			StringBuffer hexStr = new StringBuffer(arr.length*2);
   			if(arr != null && arr.length > 0){
   				for( int x=0;x<arr.length;x++ ){
   					String tmp = "0"+Integer.toHexString( 0xff & arr[x] );
   					String hexaDecimal = "";
   					if(tmp != null){
   						hexaDecimal = tmp.substring(tmp.length()-2);
   					}
   					hexStr.append( hexaDecimal );
   				}
   			}
   			result = hexStr.toString();
   		}
		return result;
	}   	
   	
   	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param EgovMap, String
	 * @return String
	 * @exception Exception
	 */
	private String getEgovMapValue(EgovMap obj, String value){
		String result = "";
		if(obj != null && !obj.isEmpty() && value != null){
			Object object = obj.get(value);
			if(object != null){
				if(object instanceof BigDecimal){
					BigDecimal big = (BigDecimal)object;
					int bigInt = big.intValue();
					result = String.valueOf(bigInt);
				}else if(object instanceof String){
					result = (String)object;
				}
			}
		}
		return result;
	}   	
   	
   	
  	/**
	 * Apply for a registration card and update the data in the interface table of program. <br>
	 *
	 * @param egov Input item for retrieving list of program(EgovMap).
	 * @param fleNm Input item for retrieving list of program(String).
	 * @return void
	 * @exception Exception
	 */
   	private void setCrdIsuIfTb(EgovMap egov, String fleNm, String nb) throws Exception{
   		if(egov != null && !egov.isEmpty() && egov.get("rsdtNo") != null && egov.get("rsdtSeqNo") != null){
   			String rsdtNo = (String)egov.get("rsdtNo");
   			BigDecimal rsdtSeqNoBig = (BigDecimal)egov.get("rsdtSeqNo");
   			String sndRsut = (String)egov.get("sndRsut");
   			String rsdtSeqNo = rsdtSeqNoBig.toString();
   			String crdIsuceSrlNo = getEgovMapValue(egov, "crdIsuceSrlNo");
   			String crdIsuceDd = getEgovMapValue(egov, "crdIsuceDd");
   			if(rsdtNo != null && rsdtSeqNo != null && !rsdtNo.equals("") && !rsdtSeqNo.equals("")){
   				String crdDitbSeqNo = "";
	   			RsdtInfrVO vo = new RsdtInfrVO();
	   			vo.setRsdtNo(rsdtNo);
	   			vo = dao.selectCrdIsuIfTb(vo);
	   			if(vo != null && vo.getRsdtNo() != null && vo.getCrdIsuSeqNo() != null
	   					&& !vo.getRsdtNo().equals("") && vo.getFleNm() == null){
	   				//update
	   				if(sndRsut == null || (sndRsut != null && sndRsut.equals("Y"))){
	   					vo.setFleNm(fleNm);
	   				}
	   				crdDitbSeqNo = dao.selectSeqImCrdDitbTbSeqNo(vo);
	   				vo.setCrdDitbSeqNo(crdDitbSeqNo);
	   				vo.setFleRcdNo(nb);
	   				dao.updateCrdIsuIfTb(vo);
	   			}else{
	   				//Registered in the interface table
	   				vo = new RsdtInfrVO();
	   				vo.setRsdtNo(rsdtNo);
	   				vo.setCrdCd("1");
	   				vo.setAplCd("1");
	   				vo.setAplDd("");
	   				vo.setCrdDitbCd("");
	   				vo.setCrdDitbDd("");

	   				vo.setBsnCd("1");
	   				vo.setBsnSeqNo(rsdtSeqNo);
	   				if(sndRsut == null || (sndRsut != null && sndRsut.equals("Y"))){
	   					vo.setFleNm(fleNm);
	   				}
	   				vo.setFleRcdNo(nb);
	   				crdDitbSeqNo = dao.insertIfCrdIsuTb(vo);

	   			}

	   			Object obj = NidUserDetailsHelper.getAuthenticatedUser();
	   			String userId = "SYSTEM";
	   			if(obj != null && obj instanceof LgnVO){
	   				LgnVO user = (LgnVO)obj;
	   				userId = user.getUserId();
	   			}
	   			vo.setUserId(userId);

   				// Issued registration data in tables
   				if(sndRsut == null || (sndRsut != null && sndRsut.equals("Y"))){
   					vo.setCrdDitbSeqNo(crdDitbSeqNo);
   					vo.setCrdIsuStusCd("");
   					vo.setCrdIsuceDd(crdIsuceDd);
   					vo.setCrdIsuceSrlNo(crdIsuceSrlNo);
   					
   					vo.setCrdIsuDueDd(getEgovMapValue(egov, "crdIsuDueDd"));
   					dao.insertIfCrdDlvrTbInfr(vo);
   				}
   			}
   		}
   	}   	
   	
   	/**
	 * Biz-method for directory  <br>
	 *
	 * @param File, String, String
	 * @return void
	 */
   	private void mkdir(String base, String dir){
   		if(base != null && dir != null){
   			File make = new File(base+ File.separator+dir);
   			if(!make.isDirectory()){
   				make.mkdir();
   			}
   		}
   	}
   	
   	/**
	 * Biz-method for isDirFile <br>
	 *
	 * @param File, String, String
	 * @return void
	 */
	private void isDirFile(File source, String base, String dest){
		if(source != null){
			File[] listFile = source.listFiles();
			if(listFile != null && listFile.length > 0){
				for(int i = 0; i < listFile.length; i++){
					File tmp = listFile[i];
					String src = tmp.getAbsolutePath();
					String destFile = null;
					int cnt = src.indexOf(base);
					if(cnt == 0){
						cnt = base.length();
					}
					destFile = src.substring(cnt);
					if(tmp.isDirectory()){
						mkdir(dest, destFile);
						isDirFile(tmp, base, dest);
					}else if(tmp.isFile()){
						if(tmp.getAbsolutePath().lastIndexOf(".xml") != -1){
							copy(src, dest, destFile);
						}
					}
				}
			}
		}
	}   	
   	
	/**
	 * Biz-method for copy <br>
	 *
	 * @param String, String, String
	 * @return void
	 */
   	private void copy(String src, String dest, String file){
   		log.debug(dest);
   		if(src != null && dest != null){
   			File source = new File(src);
   			String oldFile = file;
   			String files = file;
   			if(files != null && files.lastIndexOf(".xml") != -1){
   				files = files.substring(0, files.lastIndexOf(".xml"));
   				StringBuffer sb = new StringBuffer();
   				sb.append(files).append(".tmp");
   				files = sb.toString();
   			}
   			File targetSource = new File(dest, files);
   			log.debug(dest);
   			FileInputStream fis = null;
   			FileOutputStream fos = null;
   			BufferedInputStream bis = null;
   			BufferedOutputStream bos = null;
   			
   			try{
   				fis = new FileInputStream(source);
   				fos = new FileOutputStream(targetSource);
   				bis = new BufferedInputStream(fis, 2048);
   				bos = new BufferedOutputStream(fos, 2048);
   				int readBytes = 0;
   				while((readBytes = bis.read()) != -1){
   					bos.write(readBytes);
   				}
   				bos.flush();
   				fis.close();
   				fos.close();
   				bis.close();
   				bos.close();
   				File af = new File(dest +  files);
   				File bf = new File(dest + oldFile);
   				if(!af.renameTo(bf)){
   					log.debug("af.renameTo(bf) flase");
   					fis = new FileInputStream(af);
   	   				fos = new FileOutputStream(bf);
	   	   			bis = new BufferedInputStream(fis, 2048);
	   				bos = new BufferedOutputStream(fos, 2048);
	   				readBytes = 0;
	   				while((readBytes = bis.read()) != -1){
	   					bos.write(readBytes);
	   				}
	   				bos.flush();
	   				fis.close();
	   				fos.close();
	   				bis.close();
	   				bos.close();
	   				System.gc();
	   				af.delete();
   				}
   			}catch(Exception e){
   				log.error(e);
   			}finally{
   				try{
   					if(bis != null){
   						bis.close();
   					}
   					if(bos != null){
   						bos.close();
   					}
   					if(fis != null){
   						fis.close();
   					}
   					if(fos != null){
   						fos.close();
   					}
   				}catch(Exception e){
   					log.error(e);
   				}
   			}
   		}
   	}
   	
   	
   	/**
	 * Checking Receive File. <br>
	 *
	 * @param void
	 * @return int
	 * @exception Exception
	 */
   	public int searchResultFile() throws Exception {
   		int result = 0;
   		String localRecvBasePath = propertiesService.getString("dpp.local.xml.recv.base"); 
   		
   		File sour = new File(localRecvBasePath);
   		
   		if(sour != null && sour.isDirectory()){
   			File [] list = sour.listFiles();

   			if(list != null && list.length > 0){
   				result = 1;
   			}
   		}
   		return result;
   	}
   	
   	
   	/**
	 * Receive File. <br>
	 *
	 * @param void
	 * @return void
	 * @exception Exception
	 */
   	public void addRcivXmlGenerate() throws Exception {
   		String yyyyMmDd = getDdMmYyyy();
		//actionRcivChDat(ddMmYyyy);
   		actionRcivChDatCopy(yyyyMmDd);
   	}


   	/**
	 * ddMmYyyy String make. <br>
	 *
	 * @param void
	 * @return String object of Program
	 * @exception Exception
	 */
   	private String getDdMmYyyy() {
   		StringBuffer calString = new StringBuffer();
   		Calendar cal = Calendar.getInstance();
   		calString.append(cal.get(Calendar.YEAR));
   		String month = ""+(cal.get(Calendar.MONTH)+1);
   		calString.append(month.length() == 1 ? "0"+month : month);
   		String date = ""+cal.get(Calendar.DATE);
   		calString.append(date.length() == 1 ? "0"+date : date);
   		return calString.toString();
   	}   		
   		
  	/**
	 * sftp card is received. <br>
	 *
	 * @param dirNm Input item for retrieving list of program(String).
	 * @return void
	 * @exception Exception
	 */
   	private void actionRcivChDatCopy(String dirNm) throws Exception {
   		String localRecvBasePath = propertiesService.getString("dpp.local.xml.recv.base");
   		actionRcivDatParsing(localRecvBasePath, dirNm);
   	}  
   	
   	/**
	 * The resulting file processing. <br>
	 *
	 * @param localRecvBasePath Input item for retrieving list of program(String).
	 * @param dirNm Input item for retrieving list of program(String).
	 * @return void
	 * @exception Exception
	 */
   	private void actionRcivDatParsing(String localRecvBasePath, String dirNm) throws Exception {
   		File sour = new File(localRecvBasePath);
   		if(sour != null && sour.isDirectory()){
   			File [] list = sour.listFiles();
   			if(list != null){
				String [] readErr = searchFileType(list, 0, "ReadErr_");
				String [] signErr = searchFileType(list, 0, "SignErr_");
				String [] keyErr = searchFileType(list, 0, "FeedbackCMS_");
				String [] dppErr = searchFileType(list, 0, "FeedbackDPP_");
				String [] exception = searchFileType(list, 0, "ExceptionCMS_");
				log.debug("actionRcivDatParsing" + (readErr == null ? "null" : readErr.length));
				log.debug("actionRcivDatParsing" + (signErr == null ? "null" : signErr.length));
				log.debug("actionRcivDatParsing" + (keyErr == null ? "null" : keyErr.length));
				log.debug("actionRcivDatParsing" + (dppErr == null ? "null" : dppErr.length));
				log.debug("actionRcivDatParsing" + (exception == null ? "null" : exception.length));

				EgovMap em = new EgovMap();
				em.put("readErr", readErr);
				em.put("signErr", signErr);
				em.put("feedbackCMS", keyErr);
				em.put("feedbackDPP", dppErr);
				em.put("exception",exception);

   				setFileReadProc(sour.getAbsolutePath(), em, dirNm);
   			}
   		}
   	}
   	
   	/**
	 * Sort results by file. <br>
	 *
	 * @param File [], int, String
	 * @return String []
	 */
   	private String [] searchFileType(File [] list, int count, String tye){
   		String [] result = null;
   		if(list != null && tye != null){
   			if(count != 0){
   				result = new String[count];
   				for(int i = 0; i < result.length; i++){
   	   				result[i] = "";
   	   			}
   			}
   			int cnt = 0;
   			for(int i = 0;i < list.length; i++){
   				File tmp = list[i];
   				String fleFul = tmp.getName();
   				if(fleFul.startsWith(tye) && fleFul.indexOf(".xml") != -1){
   					if(count > 0){
   						result[cnt] = fleFul;
   					}
   					cnt++;
   				}
   			}
   			if(count == 0 && cnt > 0){
   				result = searchFileType(list, cnt, tye);
   			}
   		}
   		return result;
   	}
   	
   	/**
	 * The resulting file processing. <br>
	 *
	 * @param String, EgovMap, String
	 * @return void
	 * @exception Exception
	 */
   	private void setFileReadProc(String dir, EgovMap em, String dirNm) throws Exception {
   		if(dir != null && em != null){
   			
   			Object obj = NidUserDetailsHelper.getAuthenticatedUser();
   			String userId = "SYSTEM";
   			if(obj != null && obj instanceof LgnVO){
   				LgnVO user = (LgnVO)obj;
   				userId = user.getUserId();
   			}
   			
   			String batchErrMsg = "";
   			String batchErrYn = "N";
   			int totCnt = 0;
			int xmlAddCnt = 0;
			String wrkSttDt = null;
			String wrkEdDt = null;
   			String [] readErr = (String [])em.get("readErr");
   			String [] signErr = (String [])em.get("signErr");
   			String [] feedbackCMS = (String [])em.get("feedbackCMS");
   			String [] feedbackDPP = (String [])em.get("feedbackDPP");
   			String [] exception = (String [])em.get("exception");
   			String [] readErrs = searchFileType(readErr, "_");
   			String [] signErrs = searchFileType(signErr, "_");
   			String [] feedbackCMSs = searchFileType(feedbackCMS, "_");
   			String [] feedbackDPPs = searchFileType(feedbackDPP, "_");
   			String [] exceptions = searchFileType(exception, "_");
   			// read file err
   			totCnt = 0;
			xmlAddCnt = 0;
			batchErrMsg = "";
   			batchErrYn = "N";
   			if(readErrs != null){
   				RsdtInfrVO vo = new RsdtInfrVO();
   				for(int i = 0 ; i < readErrs.length; i++){
   					wrkSttDt = dao.selectDppDbDatTime(new RsdtInfrVO());
   					batchErrMsg = "";
   		   			batchErrYn = "N";
   		   			totCnt = 0;
   					xmlAddCnt = 0;
   					String str = readErrs[i];
   					vo = vo.init();
   					vo.setFleNm(str);
   					vo.setRcivFleNm(dir+File.separator+readErr[i]);
   					vo.setCrdIsuceStusCd("2");
   					vo.setErorCd("1");
   					//vo.setErorMsg("Unable to Read");
   					vo.setErorPrcssYn("Y");
   					vo.setErorPrcssUserId("SYSTEM");
   					dao.updateImCrdDitbTbReadErr(vo);
   					dao.updateImCrdIsuTbReadErr(vo);
   					dao.insertImCrdIsuTbReadErr(vo);
   					wrkEdDt = dao.selectDppDbDatTime(new RsdtInfrVO());
   					String crdIsuceStusCd = "1";
   					setRecvFileProc(dir, readErr[i], wrkSttDt, wrkEdDt, batchErrMsg, batchErrYn, totCnt, xmlAddCnt, crdIsuceStusCd);
   				}
   			}
   			// Digital Signature err
   			if(signErrs != null){
   				RsdtInfrVO vo = new RsdtInfrVO();
   				boolean flag = false;
   				for(int i = 0 ; i < signErrs.length; i++){
   					batchErrMsg = "";
   		   			batchErrYn = "N";
   		   			totCnt = 0;
   					xmlAddCnt = 0;
   					wrkSttDt = dao.selectDppDbDatTime(new RsdtInfrVO());
   					String str = signErrs[i];
   					if(readErrs != null){
   						for(int j = 0; j < readErrs.length; j++){
   							if(str.equals(readErrs[j])){
   								flag = true;
   							}
   						}
   					}
   					if(flag){
   						flag = false;
   						continue;
   					}
   					vo = vo.init();
   					vo.setFleNm(str);
   					vo.setRcivFleNm(dir+File.separator+signErr[i]);
   					vo.setCrdIsuceStusCd("3");
   					vo.setErorCd("1");
   					//vo.setErorMsg("Invalid Digital Signature");
   					vo.setErorPrcssYn("N");
   					vo.setErorPrcssUserId("");
   					dao.updateImCrdDitbTbReadErr(vo);
   					wrkEdDt = dao.selectDppDbDatTime(new RsdtInfrVO());
   					String crdIsuceStusCd = "1";
   					setRecvFileProc(dir, signErr[i], wrkSttDt, wrkEdDt, batchErrMsg, batchErrYn, totCnt, xmlAddCnt, crdIsuceStusCd);
   				}
   			}
   			// cms error
   			if(feedbackCMSs != null){
   				RsdtInfrVO vo = new RsdtInfrVO();
   				boolean flag = false;
   				String crdIsuceStusCd = "1";
   				for(int i = 0 ; i < feedbackCMSs.length; i++){
   					crdIsuceStusCd = "1";
   					batchErrMsg = "";
   		   			batchErrYn = "N";
   		   			totCnt = 0;
   					xmlAddCnt = 0;
   					wrkSttDt = dao.selectDppDbDatTime(new RsdtInfrVO());
   					String str = feedbackCMSs[i];
   					if(readErrs != null){
   						for(int j = 0; j < readErrs.length; j++){
   							if(str.equals(readErrs[j])){
   								flag = true;
   							}
   						}
   					}
   					if(flag){
   						flag = false;
   						continue;
   					}
   					if(signErrs != null){
   						for(int j = 0; j < signErrs.length; j++){
   							if(str.equals(signErrs[j])){
   								flag = true;
   							}
   						}
   					}
   					if(flag){
   						flag = false;
   						continue;
   					}
   					FileInputStream fis = null;
   					try{
   						log.debug("cms error read file : " + dir + File.separator + feedbackCMS[i]);
   						fis = new FileInputStream(dir + File.separator + feedbackCMS[i]);
   						byte [] arry = new byte[fis.available()];
   						fis.read(arry);
   						
   						DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
   						dbf.setNamespaceAware(true);
   						@SuppressWarnings("unused")
						Document docTmp = null;
   						InputStream is = new ByteArrayInputStream(arry);
   						docTmp = dbf.newDocumentBuilder().parse(is);
   						
   						String lgSeqNo = lgDao.insertPubKeyIfLg(userId, (dir + File.separator + feedbackCMS[i]), "19", "1", "15", "");
   						int result = XMLDsigValidate.spkiIFDigitalSignatureValidation(arry);
   						String erorYn = "N";
   						if(result != 0){
   							erorYn = "Y";
   						}
   						lgDao.updatePubKeyIfLg(lgSeqNo, String.valueOf(result), erorYn);
   						
   						fis.close();
   						log.debug("XMLDsigValidate.spkiIFDigitalSignatureValidation : " + result);
   						if(result == 0){
		   					DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		   					DocumentBuilder parser = factory.newDocumentBuilder();
		   					Document doc = parser.parse(dir + File.separator + feedbackCMS[i]);
		   					Element rootElement = doc.getDocumentElement();
		   					NodeList memberList = rootElement.getChildNodes();
		   					@SuppressWarnings("unused")
							String personCnt = "";
		   					for(int j=0; j < memberList.getLength(); j++){
		   						Node node = memberList.item(j);
		   						if(node.getNodeType() == Node.ELEMENT_NODE) {
		   							if(node.getNodeName().equals("Header")){
		   								NodeList childNodeList = node.getChildNodes();
		   								for(int k=0; k < childNodeList.getLength(); k++){
		   					   				Node childNode = childNodeList.item(k);
		   					   				if(childNode.getNodeType() == Node.ELEMENT_NODE) {
		   					   					if(childNode.getNodeName().equals("Data_count")){
		   					   						personCnt = getXmlNodeVal(childNode);
		   					   					}
		   					   				}
		   								}
		   							}else if(node.getNodeName().equals("Record")){
		   								String number = null;
		   								String enid = null;
		   								String shipmentDate = null;
		   								String status = null;
		   								String errorCode = null;
		   								String errorDes = null;
		   								totCnt++;
		   								NodeList childNodeList = node.getChildNodes();
		   								for(int k=0; k < childNodeList.getLength(); k++){
		   					   				Node childNode = childNodeList.item(k);
		   					   				if(childNode.getNodeType() == Node.ELEMENT_NODE) {
		   					   					if(childNode.getNodeName().equals("Nb")){
		   					   						number = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("e-TazkeraNumber_Eng")){
		   					   						enid = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("Shipment_Date")){
		   					   						shipmentDate = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("Status")){
		   					   						status = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("Error_Code")){
		   					   						errorCode = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("Error_Description")){
		   					   						errorDes = getXmlNodeVal(childNode);
		   					   					}
		   					   				}
		   								}
		   								String rexStr = "CMS.";
		   								int codeLen = errorCode.indexOf(rexStr);
		   								if(enid != null && !"".equals(enid) && errorCode != null && codeLen != -1){
		   									log.debug(number + " : " + enid + " : " + shipmentDate + " : "+ status + " : "+ errorCode + " : " + errorDes);
		   									String codeVal = errorCode.substring(codeLen+rexStr.length(), errorCode.length());
		   									log.debug("codeVal : "  + " : " + codeVal);
		   									
		   									xmlAddCnt++;
		   									enid = toPersianConvetNo(enid).replaceAll("-", "");
		   									vo = vo.init();
		   									vo.setRsdtNo(enid);
		   				   					vo.setFleNm(str);
		   				   					vo.setRcivFleNm(dir+File.separator+feedbackCMS[i]);
		   				   					vo.setErorCd(errorCode);
		   				   					vo.setErorMsg(errorDes);
		   				   					vo.setErorPrcssYn("N");
		   				   					vo.setErorPrcssUserId("");
		   									if(codeVal != null && !"".equals(codeVal)){
		   										String tye = codeVal.substring(0, 1);
		   										log.debug("tye : "  + " : " + tye);
		   										//String code = codeVal.substring(1, codeVal.length());
		   										if(tye != null && "A".equals(tye)){
		   											vo.setCrdIsuceStusCd("5");
		   											vo.setErorPrcssYn("N");
		   											vo.setErorPrcssUserId("");
		   										}else if(tye != null && "B".equals(tye)){
		   											vo.setCrdIsuceStusCd("4");
		   											vo.setErorPrcssYn("Y");
		   											vo.setErorPrcssUserId("SYSTEM");
		   											dao.insertImCrdIsuTbCmsErrB(vo);
		   										}
		   									}
		   									dao.updateImCrdDitbTbPkiDppErr(vo);
		   								}
		   							}
		   						}
		   					}
   						}else{
   							//DigitalSignatureValidation error
   							log.debug("DigitalSignatureValidation error");
   							//batchErrMsg = "DigitalSignatureValidation error";
   							crdIsuceStusCd = "9";
   							batchErrYn = "Y";
   						}
   					}catch(SAXException sax){
   						log.debug(sax);
   						//batchErrMsg = "File Read Fail";
   						crdIsuceStusCd = "10";
   						batchErrYn = "Y";
   					}catch(Exception e){
   						log.debug(e);
   					}finally{
   						try{
   							if(fis != null){
   								fis.close();
   							}
   						}catch(Exception e){
   							log.debug(e);
   						}
   					}
   					wrkEdDt = dao.selectDppDbDatTime(new RsdtInfrVO());
   					
   					setRecvFileProc(dir, feedbackCMS[i], wrkSttDt, wrkEdDt, batchErrMsg, batchErrYn, totCnt, xmlAddCnt, crdIsuceStusCd);
   				}
   			}
   			// dpp error
   			if(feedbackDPPs != null){
   				RsdtInfrVO vo = new RsdtInfrVO();
   				boolean flag = false;
   				String crdIsuceStusCd = "1";
   				for(int i = 0 ; i < feedbackDPPs.length; i++){
   					crdIsuceStusCd = "1";
   					batchErrMsg = "";
   		   			batchErrYn = "N";
   		   			totCnt = 0;
   					xmlAddCnt = 0;
   					wrkSttDt = dao.selectDppDbDatTime(new RsdtInfrVO());
   					String str = feedbackDPPs[i];
   					if(readErrs != null){
   						for(int j = 0; j < readErrs.length; j++){
   							if(str.equals(readErrs[j])){
   								flag = true;
   							}
   						}
   					}
   					if(flag){
   						flag = false;
   						continue;
   					}
   					if(signErrs != null){
   						for(int j = 0; j < signErrs.length; j++){
   							if(str.equals(signErrs[j])){
   								flag = true;
   							}
   						}
   					}
   					if(flag){
   						flag = false;
   						continue;
   					}
   					FileInputStream fis = null;
   					try{
   						log.debug("dpp error read file : " + dir + File.separator + feedbackDPP[i]);
   						fis = new FileInputStream(dir + File.separator + feedbackDPP[i]);
   						byte [] arry = new byte[fis.available()];
   						fis.read(arry);
   						
   						DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
   						dbf.setNamespaceAware(true);
   						@SuppressWarnings("unused")
						Document docTmp = null;
   						InputStream is = new ByteArrayInputStream(arry);
   						docTmp = dbf.newDocumentBuilder().parse(is);

   						String lgSeqNo = lgDao.insertPubKeyIfLg(userId, (dir + File.separator + feedbackDPP[i]), "19", "1", "15", "");
   						int result = XMLDsigValidate.spkiIFDigitalSignatureValidation(arry);
   						String erorYn = "N";
   						if(result != 0){
   							erorYn = "Y";
   						}
   						lgDao.updatePubKeyIfLg(lgSeqNo, String.valueOf(result), erorYn);
   						
   						fis.close();
   						log.debug("XMLDsigValidate.spkiIFDigitalSignatureValidation : " + result);
   						if(result == 0){
		   					DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		   					DocumentBuilder parser = factory.newDocumentBuilder();
		   					Document doc = parser.parse(dir + File.separator + feedbackDPP[i]);
		   					Element rootElement = doc.getDocumentElement();
		   					NodeList memberList = rootElement.getChildNodes();
		   					@SuppressWarnings("unused")
							String personCnt = "";
		   					for(int j=0; j < memberList.getLength(); j++){
		   						Node node = memberList.item(j);
		   						if(node.getNodeType() == Node.ELEMENT_NODE) {
		   							if(node.getNodeName().equals("Header")){
		   								NodeList childNodeList = node.getChildNodes();
		   								for(int k=0; k < childNodeList.getLength(); k++){
		   					   				Node childNode = childNodeList.item(k);
		   					   				if(childNode.getNodeType() == Node.ELEMENT_NODE) {
		   					   					if(childNode.getNodeName().equals("Data_count")){
		   					   						personCnt = getXmlNodeVal(childNode);
		   					   					}
		   					   				}
		   								}
		   							}else if(node.getNodeName().equals("Record")){
		   								String number = null;
		   								String enid = null;
		   								String shipmentDate = null;
		   								String status = null;
		   								String errorCode = null;
		   								String errorDes = null;
		   								String pkiCert = null;
		   								totCnt++;
		   								NodeList childNodeList = node.getChildNodes();
		   								for(int k=0; k < childNodeList.getLength(); k++){
		   					   				Node childNode = childNodeList.item(k);
		   					   				if(childNode.getNodeType() == Node.ELEMENT_NODE) {
		   					   					if(childNode.getNodeName().equals("Nb")){
		   					   						number = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("e-TazkeraNumber_Eng")){
		   					   						enid = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("Shipment_Date")){
		   					   						shipmentDate = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("Status")){
		   					   						status = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("Error_Code")){
		   					   						errorCode = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("Error_Description")){
		   					   						errorDes = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("PKICert")){
		   					   						pkiCert = getXmlNodeVal(childNode);
		   					   					}
		   					   				}
		   								}
		   								//String rexStr = "DPP.";
		   								//int codeLen = errorCode.indexOf(rexStr);
		   								if(enid != null && !"".equals(enid)){
		   									log.debug(number + " : " + enid + " : " + shipmentDate + " : "+ status + " : "+ errorCode + " : " + errorDes);
		   									
		   									xmlAddCnt++;
		   									enid = toPersianConvetNo(enid).replaceAll("-", "");
		   									vo = vo.init();
		   									vo.setRsdtNo(enid);
		   				   					vo.setFleNm(str);
		   				   					vo.setRcivFleNm(dir+File.separator+feedbackDPP[i]);
		   				   					vo.setErorCd(errorCode);
		   				   					vo.setErorMsg(errorDes);
		   				   					vo.setErorPrcssYn("");
		   				   					vo.setCrdIsuceStusCd("6");
		   				   					vo.setErorPrcssUserId("");
		   				   					vo.setPkiCert(pkiCert);
		   									if(status != null && !"".equals(status)){
		   										if("OK".equals(status)){
		   											vo.setCrdIsuceStusCd("1");
		   											vo.setErorPrcssYn("");
		   										}else if("Rejected".equals(status)){
		   											vo.setCrdIsuceStusCd("7");
		   											vo.setErorPrcssYn("N");
		   										}else if("Aborted".equals(status)){
		   											vo.setCrdIsuceStusCd("6");
		   											vo.setErorPrcssYn("N");
		   										}
		   									}
		   									dao.updateImCrdDitbTbPkiDppErr(vo);
		   								}
		   							}
		   						}
		   					}
   						}else{
   							//DigitalSignatureValidation error
   							log.debug("DigitalSignatureValidation error");
   							//batchErrMsg = "DigitalSignatureValidation error";
   							crdIsuceStusCd = "9";
   							batchErrYn = "Y";
   						}
   					}catch(SAXException sax){
   						log.debug(sax);
   						//batchErrMsg = "File Read Fail";
   						crdIsuceStusCd = "10";
   						batchErrYn = "Y";
   					}catch(Exception e){
   						log.debug(e);
   					}finally{
   						try{
   							if(fis != null){
   								fis.close();
   							}
   						}catch(Exception e){
   							log.debug(e);
   						}
   					}
   					wrkEdDt = dao.selectDppDbDatTime(new RsdtInfrVO());
   	   		   		setRecvFileProc(dir, feedbackDPP[i], wrkSttDt, wrkEdDt, batchErrMsg, batchErrYn, totCnt, xmlAddCnt, crdIsuceStusCd);

   				}
   			}
   			
   			if(exceptions != null){
   				RsdtInfrVO vo = new RsdtInfrVO();
   				boolean flag = false;
   				String crdIsuceStusCd = "8";
   				for(int i = 0 ; i < exceptions.length; i++){
   					crdIsuceStusCd = "8";
   					batchErrMsg = "";
   		   			batchErrYn = "N";
   		   			totCnt = 0;
   					xmlAddCnt = 0;
   					wrkSttDt = dao.selectDppDbDatTime(new RsdtInfrVO());
   					String str = exceptions[i];
   					if(readErrs != null){
   						for(int j = 0; j < readErrs.length; j++){
   							if(str.equals(readErrs[j])){
   								flag = true;
   							}
   						}
   					}
   					if(flag){
   						flag = false;
   						continue;
   					}
   					if(signErrs != null){
   						for(int j = 0; j < signErrs.length; j++){
   							if(str.equals(signErrs[j])){
   								flag = true;
   							}
   						}
   					}
   					if(flag){
   						flag = false;
   						continue;
   					}
   					
   					FileInputStream fis = null;
   					try{
   						log.debug("exceptions error read file : " + dir + File.separator + exception[i]);
   						fis = new FileInputStream(dir + File.separator + exception[i]);
   						byte [] arry = new byte[fis.available()];
   						fis.read(arry);
   						
   						DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
   						dbf.setNamespaceAware(true);
   						@SuppressWarnings("unused")
						Document docTmp = null;
   						InputStream is = new ByteArrayInputStream(arry);
   						docTmp = dbf.newDocumentBuilder().parse(is);
   						
   						String lgSeqNo = lgDao.insertPubKeyIfLg(userId, (dir + File.separator + exception[i]), "19", "1", "15", "");
   						int result = XMLDsigValidate.spkiIFDigitalSignatureValidation(arry);
   						String erorYn = "N";
   						if(result != 0){
   							erorYn = "Y";
   						}
   						lgDao.updatePubKeyIfLg(lgSeqNo, String.valueOf(result), erorYn);
   						
   						fis.close();
   						log.debug("XMLDsigValidate.spkiIFDigitalSignatureValidation : " + result);
   						if(result == 0){
		   					DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		   					DocumentBuilder parser = factory.newDocumentBuilder();
		   					Document doc = parser.parse(dir + File.separator + exception[i]);
		   					Element rootElement = doc.getDocumentElement();
		   					NodeList memberList = rootElement.getChildNodes();
		   					@SuppressWarnings("unused")
							String personCnt = "";
		   					for(int j=0; j < memberList.getLength(); j++){
		   						Node node = memberList.item(j);
		   						if(node.getNodeType() == Node.ELEMENT_NODE) {
		   							if(node.getNodeName().equals("Header")){
		   								NodeList childNodeList = node.getChildNodes();
		   								for(int k=0; k < childNodeList.getLength(); k++){
		   					   				Node childNode = childNodeList.item(k);
		   					   				if(childNode.getNodeType() == Node.ELEMENT_NODE) {
		   					   					if(childNode.getNodeName().equals("Data_count")){
		   					   						personCnt = getXmlNodeVal(childNode);
		   					   					}
		   					   				}
		   								}
		   							}else if(node.getNodeName().equals("Record")){
		   								String number = null;
		   								String enid = null;
		   								String shipmentDate = null;
		   								String status = null;
		   								String errorCode = null;
		   								String errorDes = null;
		   								totCnt++;
		   								NodeList childNodeList = node.getChildNodes();
		   								for(int k=0; k < childNodeList.getLength(); k++){
		   					   				Node childNode = childNodeList.item(k);
		   					   				if(childNode.getNodeType() == Node.ELEMENT_NODE) {
		   					   					if(childNode.getNodeName().equals("Nb")){
		   					   						number = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("e-TazkeraNumber_Eng")){
		   					   						enid = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("Shipment_Date")){
		   					   						shipmentDate = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("Status")){
		   					   						status = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("Error_Code")){
		   					   						errorCode = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("Error_Description")){
		   					   						errorDes = getXmlNodeVal(childNode);
		   					   					}
		   					   				}
		   								}
		   								//String rexStr = "DPP.";
		   								//int codeLen = errorCode.indexOf(rexStr);
		   								xmlAddCnt++;
		   								if(enid != null && !"".equals(enid)){
		   									log.debug(number + " : " + enid + " : " + shipmentDate + " : "+ status + " : "+ errorCode + " : " + errorDes);
		   									enid = toPersianConvetNo(enid).replaceAll("-", "");
		   									vo = vo.init();
		   									vo.setRsdtNo(enid);
		   				   					vo.setFleNm(str);
		   				   					vo.setRcivFleNm(dir+File.separator+exception[i]);
		   				   					vo.setErorCd(errorCode);
		   				   					vo.setErorMsg(errorDes);
		   				   					vo.setErorPrcssYn("N");
		   				   					vo.setCrdIsuceStusCd(crdIsuceStusCd);
		   				   					vo.setErorPrcssUserId("");
		   									dao.updateImCrdDitbTbPkiDppErr(vo);
		   								}
		   							}
		   						}
		   					}
   						}else{
   							//DigitalSignatureValidation error
   							log.debug("DigitalSignatureValidation error");
   							//batchErrMsg = "DigitalSignatureValidation error";
   							crdIsuceStusCd = "9";
   							batchErrYn = "Y";
   						}
   					}catch(SAXException sax){
   						log.debug(sax);
   						//batchErrMsg = "File Read Fail";
   						crdIsuceStusCd = "10";
   						batchErrYn = "Y";
   					}catch(Exception e){
   						log.debug(e);
   					}finally{
   						try{
   							if(fis != null){
   								fis.close();
   							}
   						}catch(Exception e){
   							log.debug(e);
   						}
   					}
   					
   					wrkEdDt = dao.selectDppDbDatTime(new RsdtInfrVO());
   					setRecvFileProcCmsEx(dir, exception[i], wrkSttDt, wrkEdDt, batchErrMsg, batchErrYn, totCnt, xmlAddCnt, crdIsuceStusCd);
   				}
   			}
   			
   			/*
   			// card print result
   			if(cardResults != null){
   				RsdtInfrVO vo = new RsdtInfrVO();
   				boolean flag = false;
   				for(int i = 0 ; i < cardResults.length; i++){
   					batchErrMsg = "";
   		   			batchErrYn = "N";
   		   			totCnt = 0;
   					xmlAddCnt = 0;
   					wrkSttDt = dao.selectDppDbDatTime(new RsdtInfrVO());
   					String str = cardResults[i];
   					if(readErrs != null){
   						for(int j = 0; j < readErrs.length; j++){
   							if(str.equals(readErrs[j])){
   								flag = true;
   							}
   						}
   					}
   					if(flag){
   						flag = false;
   						continue;
   					}
   					if(signErrs != null){
   						for(int j = 0; j < signErrs.length; j++){
   							if(str.equals(signErrs[j])){
   								flag = true;
   							}
   						}
   					}
   					if(flag){
   						flag = false;
   						continue;
   					}
   					FileInputStream fis = null;
   					try{
   						log.debug("cardResults read file : " + dir + File.separator + cardResult[i]);
   						fis = new FileInputStream(dir + File.separator + cardResult[i]);
   						byte [] arry = new byte[fis.available()];
   						fis.read(arry);
   						int result = XMLDsigValidate.spkiIFDigitalSignatureValidation(arry);
   						fis.close();
   						log.debug("XMLDsigValidate.spkiIFDigitalSignatureValidation : " + result);
   						if(result == 0){
		   					DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		   					DocumentBuilder parser = factory.newDocumentBuilder();
		   					Document doc = parser.parse(dir + File.separator + cardResult[i]);
		   					Element rootElement = doc.getDocumentElement();
		   					NodeList memberList = rootElement.getChildNodes();
		   					@SuppressWarnings("unused")
							String personCnt = "";
		   					for(int j=0; j < memberList.getLength(); j++){
		   						Node node = memberList.item(j);
		   						if(node.getNodeType() == Node.ELEMENT_NODE) {
		   							if(node.getNodeName().equals("Header")){
		   								NodeList childNodeList = node.getChildNodes();
		   								for(int k=0; k < childNodeList.getLength(); k++){
		   					   				Node childNode = childNodeList.item(k);
		   					   				if(childNode.getNodeType() == Node.ELEMENT_NODE) {
		   					   					if(childNode.getNodeName().equals("Data_count")){
		   					   						personCnt = getXmlNodeVal(childNode);
		   					   					}
		   					   				}
		   								}
		   							}else if(node.getNodeName().equals("Record")){
		   								@SuppressWarnings("unused")
		   								String number = null;
		   								String enid = null;
		   								String Status = null;
		   								String ShipmentDate = null;
		   								String errCode = null;
		   								String errMsg = null;
		   								NodeList childNodeList = node.getChildNodes();
		   								for(int k=0; k < childNodeList.getLength(); k++){
		   					   				Node childNode = childNodeList.item(k);
		   					   				if(childNode.getNodeType() == Node.ELEMENT_NODE) {
		   					   					if(childNode.getNodeName().equals("Nb")){
		   					   						number = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("e-TazkeraNumber_Eng")){
		   					   						enid = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("Status")){
		   					   						Status = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("Shipment_Date")){
		   					   						ShipmentDate = getXmlNodeVal(childNode);
		   					   					}else if(childNode.getNodeName().equals("Error_Code")){
		   					   						errCode = getXmlNodeVal(childNode);
			   					   				}else if(childNode.getNodeName().equals("Error_Description")){
			   					   					errMsg = getXmlNodeVal(childNode);
		   					   					}
		   					   				}
		   								}

		   								enid = toPersianConvetNo(enid).replaceAll("-", "");
	   									vo = vo.init();
	   									vo.setRsdtNo(enid);
	   				   					vo.setFleNm(str);
	   				   					vo.setRcivFleNm(dir+File.separator+cardResult[i]);
	   				   					vo.setErorCd(errCode);
	   				   					vo.setErorMsg(errMsg);
	   				   					vo.setErorPrcssUserId("SYSTEM");
	   				   					totCnt++;
		   								if(enid != null && Status != null && ("Rejected".equals(Status) || "Aborted".equals(Status)) ){
		   									vo.setCrdIsuceStusCd("6");
		   									vo.setErorPrcssYn("Y");
		   								}else if(enid != null && Status != null && "OK".equals(Status)){
		   									vo.setCrdIsuceDd(ShipmentDate);
		   									vo.setCrdIsuceStusCd("1");
		   									vo.setErorPrcssYn("N");
		   									xmlAddCnt++;
		   								}
		   								dao.updateImCrdDitbTbPkiDppErr(vo);
		   								if(enid != null && Status != null && "Rejected".equals(Status)){
		   									dao.updateImCrdIsuTbDppErr(vo);
		   								}
		   							}
		   						}
		   					}
   						}else{
   							//DigitalSignatureValidation error
   							log.debug("DigitalSignatureValidation error");
   							batchErrMsg = "DigitalSignatureValidation error";
   							batchErrYn = "Y";
   						}
   					}catch(SAXException sax){
   						log.debug(sax);
   						batchErrMsg = "File Read Fail";
   						batchErrYn = "Y";

   					}catch(Exception e){
   						log.debug(e);
   					}finally{
   						try{
   							if(fis != null){
   								fis.close();
   							}
   						}catch(Exception e){
   							log.debug(e);
   						}
   					}
   					wrkEdDt = dao.selectDppDbDatTime(new RsdtInfrVO());
   	   		   		setRecvFileProc(dir, cardResult[i], wrkSttDt, wrkEdDt, batchErrMsg, batchErrYn, totCnt, xmlAddCnt);
   				}
   			}*/
   			//file move
	   		File localDir = new File(dir);
	   		if(localDir != null){
	   			File [] list = localDir.listFiles();
	   			int count = getFileCntAndFileCopy(list, "count", null, null);
	   			if(count > 0){
	   				Calendar cal = Calendar.getInstance();
	   				int hour = cal.get(Calendar.HOUR_OF_DAY);
	   				int mi = cal.get(Calendar.MINUTE);
	   				String strHour = String.valueOf(hour);
	   				if(strHour != null){
	   					strHour = strHour.length() > 1 ? strHour : "0"+ strHour;
	   				}
	   				String strMi = String.valueOf(mi);
	   				if(strMi != null){
	   					strMi = strMi.length() > 1 ? strMi : "0"+ strMi;
	   				}
	   				String localRecvBaseBak = propertiesService.getString("dpp.local.xml.recv.base.bak");
	   				File recvBak = new File(localRecvBaseBak);
	   				if(!recvBak.isDirectory()){
	   					recvBak.mkdir();
	   				}
	   				recvBak = new File(localRecvBaseBak + File.separator + dirNm);
	   				if(!recvBak.isDirectory()){
	   					recvBak.mkdir();
	   				}
	   				recvBak = new File(localRecvBaseBak + File.separator + dirNm + File.separator + dirNm+strHour+strMi + "_OK");
	   		   		if(!recvBak.isDirectory()){
	   		   			recvBak.mkdir();
	   		  	   	}
	   		   		getFileCntAndFileCopy(list, "move", recvBak, "d");
	   			}
	   		}
   		}
   	}  
   	
   	/**
	 * Load the resulting file in the original file name. <br>
	 *
	 * @param String [] , String
	 * @return String []
	 */
   	private String [] searchFileType(String [] arr, String tye){
   		String [] result = null;
   		if(arr != null && tye != null){
   			result = new String[arr.length];
   			for(int i = 0; i < arr.length; i++){
   				String tmp = arr[i];
   				int cnt = tmp.indexOf(tye);
   				if(cnt != -1){
	   				tmp = tmp.substring(cnt+1, tmp.length());
	   				result[i] = tmp;
   				}
   			}
   		}
   		return result;
   	}
   	
   	
   	/**
	 * Log file processing results. <br>
	 *
	 * @param String, String, String, String, String, String, int, int, String
	 * @return void
	 * @exception Exception
	 */
   	private void setRecvFileProc(String dir, String fileNm , String wrkSttDt, String wrkEdDt, String batchErrMsg, String batchErrYn, int totCnt, int xmlAddCnt, String crdIsuceStusCd ) throws Exception{
   		if(dir != null && fileNm != null && wrkSttDt != null && wrkEdDt != null && batchErrYn != null){
	   		String fleNm = fileNm;
			String code = "";
			if(fleNm != null && fleNm.length() > 0){
				int limit = fleNm.indexOf("_");
				if(limit != -1){
					code = fleNm.substring(limit+1, fleNm.length());
					limit = code.indexOf("_");
					if(limit != -1){
						code = code.substring(0, limit);
					}
					limit = code.lastIndexOf(File.separator);
					if(limit != -1){
						code = code.substring(limit+1, code.length());
					}
				}
			}
			RsdtInfrVO recvVo = new RsdtInfrVO();
			recvVo.setWrkSttDt(wrkSttDt);
			recvVo.setWrkEdDt(wrkEdDt);
			recvVo.setOrgnzCd(code);
			recvVo.setFleLc(dir+File.separator+fileNm);
			recvVo.setTgtCn(String.valueOf(totCnt));
			recvVo.setScsCn(String.valueOf(xmlAddCnt));
			recvVo.setErorCn(String.valueOf(totCnt-xmlAddCnt));
			recvVo.setErorYn(batchErrYn);
			recvVo.setMsg(batchErrMsg);

    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		if(user == null){
    			recvVo.setUserId("SYSTEM");
    		} else {
    			if("".equals(user.getUserId())){
    				recvVo.setUserId("SYSTEM");
    			} else{
    				recvVo.setUserId(user.getUserId());
    			}    			    		    			
    		}
    			
			recvVo.setPrcssDivCd("2");
			recvVo.setCrdIsuceStusCd(crdIsuceStusCd);
	   		dao.insertIntoXmlBatchSnd(recvVo);
   		}
   	}
   	
   	
   	/**
	 * Log file processing results. <br>
	 *
	 * @param String, String, String, String, String, String, int, int, String
	 * @return void
	 * @exception Exception
	 */
   	private void setRecvFileProcCmsEx(String dir, String fileNm , String wrkSttDt, String wrkEdDt, String batchErrMsg, String batchErrYn, int totCnt, int xmlAddCnt, String crdIsuceStusCd ) throws Exception{
   		if(dir != null && fileNm != null && wrkSttDt != null && wrkEdDt != null && batchErrYn != null){
	   		String fleNm = fileNm;
			String code = "";
			if(fleNm != null && fleNm.length() > 0){
				int limit = fleNm.indexOf("_");
				if(limit != -1){
					code = fleNm.substring(limit+1, fleNm.length());
					if(code != null && !"".equals(code)){
						limit = code.indexOf("_");
						code = code.substring(limit+1, code.length());
					}
					limit = code.indexOf("_");
					if(limit != -1){
						code = code.substring(0, limit);
					}
					limit = code.lastIndexOf(File.separator);
					if(limit != -1){
						code = code.substring(limit+1, code.length());
					}
				}
			}
			RsdtInfrVO recvVo = new RsdtInfrVO();
			recvVo.setWrkSttDt(wrkSttDt);
			recvVo.setWrkEdDt(wrkEdDt);
			recvVo.setOrgnzCd(code);
			recvVo.setFleLc(dir+File.separator+fileNm);
			recvVo.setTgtCn(String.valueOf(totCnt));
			recvVo.setScsCn(String.valueOf(xmlAddCnt));
			recvVo.setErorCn(String.valueOf(totCnt-xmlAddCnt));
			recvVo.setErorYn(batchErrYn);
			recvVo.setMsg(batchErrMsg);
			
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		if(user == null){
    			recvVo.setUserId("SYSTEM");
    		} else {
    			if("".equals(user.getUserId())){
    				recvVo.setUserId("SYSTEM");
    			} else{
    				recvVo.setUserId(user.getUserId());
    			}    			    		    			
    		}

			recvVo.setPrcssDivCd("2");
			recvVo.setCrdIsuceStusCd(crdIsuceStusCd);
	   		dao.insertIntoXmlBatchSnd(recvVo);
   		}
   	}
   	
	/**
	 * xml node value. <br>
	 *
	 * @param node Input item for retrieving of program(Node).
	 * @return String object of program
	 * @exception Exception
	 */
	private String getXmlNodeVal(Node node){
		String result = null;
		if(node.getFirstChild() != null){
			result = node.getFirstChild().getNodeValue();
		}else{
			result = "";
		}
		return result;
	}
	
   	

   	
   	/**
   	 * File object. <br>
   	 *
   	 * @param egov Input item for retrieving list of program(EgovMap).
   	 * @return boolean For transmission
   	 * @exception Exception
   	 */
   	public File getFileObj(String dirNm) throws Exception {
   		return new File(dirNm);
   	}
   	
	/**
	 * Localized change the number in Arabic numerals. <br>
	 *
	 * @param number Input item for retrieving of program(String).
	 * @return String object of program
	 * @exception Exception
	 */
	private String toPersianConvetNo(String number){
		String [] persianNumberArray = new String[]{"۰","۱","۲","۳","۴","۵","۶","۷","۸","۹"};
   		StringBuffer sb = new StringBuffer();
   		if(number != null){
   			boolean flag = false;
	   		for(int i = 0;  i < number.length(); i++){
	   			String numChat = number.substring(i,i+1);
	   			for(int j = 0; j < persianNumberArray.length; j++){
	   				if(numChat.equals(persianNumberArray[j])){
	   					sb.append(String.valueOf(j));
	   					flag = true;
	   					break;
	   				}
	   			}
	   			if(!flag){
	   				sb.append(numChat);
	   			}
	   			flag = false;
	   		}
   		}
   		return sb.toString();
   	}
  
   	/**
	 * Biz-method for  Navigate to the folder where the backup file results. <br>
	 *
	 * @param File [], String, File, String
	 * @return int
	 * @exception Exception
	 */
	private int getFileCntAndFileCopy(File [] list, String ret, File desc, String type){
   		int result = 0;
   		if(list != null && ret != null){
   			for(int i = 0; i < list.length; i++){
   				File tmp = list[i];
   				if(tmp.isFile()){
   					if(tmp.getAbsolutePath().indexOf(".xml") != -1){
	   					result++;
	   					if("move".equals(ret) && desc != null){
	   						FileInputStream fis = null;
	   						FileOutputStream fos = null;
	   						try{
		   						fis = new FileInputStream(tmp.getAbsoluteFile());
		   						fos = new FileOutputStream(desc.getAbsolutePath()+File.separator+tmp.getName());
								int data = 0;
								while((data=fis.read())!=-1) {
									fos.write(data);
								}
								fis.close();
								fos.close();
	   						}catch(Exception e){
	   							log.debug(e);
	   						}finally{
	   							try{
	   								if(fis != null){
	   									fis.close();
	   								}
	   								if(fos != null){
	   									fos.close();
	   								}
	   							}catch(Exception e){
	   								log.debug(e);
	   							}
	   						}
	   					}
	   					if(type != null && "d".equals(type)){
	   						boolean flag = tmp.delete();
	   						log.debug("file delete : " + tmp.getAbsolutePath() + " : " + flag);
	   						if(!flag){
	   							System.gc();
	   							flag = tmp.delete();
	    						log.debug("file deletes : " + tmp.getAbsolutePath() + " : " + flag);
	   						}
	   					}
   					}
   				}
   			}
   		}
   		return result;
   	}

   	
   	/**
	 * Biz-method for Delete directories and files <br>
	 *
	 * @param String
	 * @return void
	 */
	@SuppressWarnings("unused")
	private void removeDIR(String source){
		File[] listFile = new File(source).listFiles(); 
		try{
			if(listFile.length > 0){
				for(int i = 0 ; i < listFile.length ; i++){
					if(listFile[i].isFile()){
						listFile[i].delete(); 
					}else{
						removeDIR(listFile[i].getPath());
					}
					listFile[i].delete();
				}
			}
		}catch(Exception e){
			log.error(e);
		}
	}



	/**
	 * Family tree generation <br>
	 * @return void
	 * @exception Exception
	 */
	public void addFmlyTreeRqst() throws Exception {
		String wrkStDt = dao.selectJobDt("");
		Object obj = NidUserDetailsHelper.getAuthenticatedUser();
		String userId = "SYSTEM";
		int resultCnt = 0;
		if(obj != null && obj instanceof LgnVO){
			LgnVO user = (LgnVO)obj;
			userId = user.getUserId();
		}
		FmlyRlVO vo = new FmlyRlVO();
		vo.setUserId(userId);
		List<EgovMap> list = dao.selectListFmlyTreeRqstPrc(vo);
		if(list != null && !list.isEmpty()){
			for(int i = 0; i < list.size(); i++){
				EgovMap em = list.get(i);
				String seqNo = null;
				String rsdtNo = null;
				if(em != null && !em.isEmpty()){
					seqNo = NidStringUtil.nullConvert(em.get("seqNo"));
					rsdtNo = NidStringUtil.nullConvert(em.get("rsdtNo"));
				}
				if(seqNo != null && rsdtNo != null && !"".equals(seqNo) && !"".equals(rsdtNo)){
					vo.setSeqNo(seqNo);
					vo.setRsdtNo(rsdtNo);
					vo.setTye("N");
					dao.deleteFmlyTreeRqstPrc(vo);
					dao.insertFmlyTreeRqstPrc(vo);
					int result = dao.updateFmlyTreeRqstPrc(vo);
					
					resultCnt = dao.selectFmlyTreeRqstPrc(vo);
					if(result < 1){
						throw new NidException("family tree fail");
					}
				}
			}
		}
		RsdtBatchVO  vos = new RsdtBatchVO();
		String wrkEdDt = dao.selectJobDt("");
   		vos.setUserId("SYSTEM");
   		vos.setWrkStt(wrkStDt);
   		vos.setWrkEdDt(wrkEdDt);
   		vos.setResultCnt(resultCnt);
   		vos.setWrkSysCd("2");   
   		vos.setWrkCd("18");
		dao.insertJobLog(vos);
		
	}
	
	
	
	/**
 	 * Biz-method for Flexible Report Generation <br>
 	 *
 	 * @param void
 	 * @return void
 	 * @exception Exception
 	 */
 	public void addRpotRqstGnr() throws Exception {
		String wrkStDt = dao.selectJobDt("");
		Map<String, String> map = new HashMap<String, String>();
		Object obj = NidUserDetailsHelper.getAuthenticatedUser();
		String userId = "SYSTEM";
		if(obj != null && obj instanceof LgnVO){
			LgnVO user = (LgnVO)obj;
			userId = user.getUserId();
		}
		map.put("userId", userId);
		map.put("result", "KO");
		map.put("result2", "KO");
		map.put("totCnt", "0");
		
		dao.addRpotRqstGnr(map);
 		log.debug(map.get("result"));
 		log.debug(map.get("result2"));
 		RsdtBatchVO  vos = new RsdtBatchVO();
		String wrkEdDt = dao.selectJobDt("");
   		vos.setUserId(userId);
   		vos.setWrkStt(wrkStDt);
   		vos.setWrkEdDt(wrkEdDt);
   		vos.setResultCnt(Integer.parseInt(map.get("totCnt")));
   		vos.setWrkSysCd("2");   
   		vos.setWrkCd("28");
		dao.insertJobLog(vos);
 	}
 	
 	
}