package afnid.rm.batch.web;

/* java API */
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.error.ErrorHandler;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.batch.service.RsdtBatchService;
import afnid.rm.rsdt.service.RsdtInfrVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;


/** 
 * This Controller class processes request of resident-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Team Ha Na YIM
 * @since 2011.04.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.04.19  		Ha Na YIM          		                    Create
 *
 * </pre>
 */

@Controller
public class RsdtBatchController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** NidProgrmManageService */
	@Resource(name = "rsdtBatchService")
    private RsdtBatchService service;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
   
    /** LgService */
	@Resource(name = "lgService")
    private LgService lgService;

    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
    /**
     * Call Batch Screen <br>
     *
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "RsdtStusAtvBatch.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/batch/rsdtMualBatchView.do")
    public String searchListRsdtStusAtvView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try{
        	LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	        	
        	lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());

        	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("71"); 
    		List<CmCmmCdVO> batchLst = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("batchLst", batchLst);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "/rm/batch/RsdtMualBatch";
    }    
    
    /**
     * Citizen Status Activation <br>
     *
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "RsdtStusAtvBatch.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/batch/modifyRsdtStusAtv.do")
    public String modifyRsdtStusAtv(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
        	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("71"); 
    		List<CmCmmCdVO> batchLst = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("batchLst", batchLst);
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		int cnt = service.modifyRsdtStusAtv(user.getUserId());
    		
    		if (cnt == 0){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nDat"));
    		} else {
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("bachPrcss.msg"));
    		}

    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "/rm/batch/RsdtMualBatch";
    }
 
    
    /**
     * Shall issue a new card processing.. <br>
     *
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "RsdtMualBatch.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/batch/gnrCrdXmlDpp.do")
    public String gnrCrdXmlDpp(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try{

        	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("71"); 
    		List<CmCmmCdVO> batchLst = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("batchLst", batchLst);
    		
    		EgovMap egov = service.actionXmlGenerateDpp(vo);

    		if( egov != null && !"".equals(egov.get("erorMsg")) ){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("araCdLnthOver.msg"));
    		}else if(egov != null && (Integer)egov.get("cnt") == 0){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nDat"));
    		}else{
    			if(egov != null){
    				if((Boolean)egov.get("flag")){
    					model.addAttribute("resultMsg", nidMessageSource.getMessage("crdIsuceAplScsfl.msg"));
    				}else{
    					model.addAttribute("resultMsg", nidMessageSource.getMessage("crdIsuceAplFleTrsfFail.msg"));
    				}
    			}
    		}
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "/rm/batch/RsdtMualBatch";
    }

    /**
     * Card issuing process should result. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "RsdtMualBatch.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/batch/getXmlGenerate.do")
    public String getXmlGenerate(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
        	CmCmmCdVO cmCmmCd = new CmCmmCdVO(); 
    		cmCmmCd.setGrpCd("71"); 
    		List<CmCmmCdVO> batchLst = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("batchLst", batchLst);
    		
    		int result = service.searchResultFile();

    		if(result != 0) {
    			service.addRcivXmlGenerate();
    			
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("bachPrcss.msg"));
    		} else {
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nDat"));
    		}
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
    	
    	return "/rm/batch/RsdtMualBatch";
    }

    /**
     * Card issuing process should result. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/batch/gnrFmlyTreeRqst.do")
    public void gnrFmlyTreeRqst(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		service.addFmlyTreeRqst();
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
    }
    
    
    
    
    
    /**
     * Flexible Report Generation. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/batch/gnrRpotRqst.do")
    public void gnrRpotRqst(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		ModelMap model)
            throws Exception {
    	try{
    		service.addRpotRqstGnr();
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
    }
    
}