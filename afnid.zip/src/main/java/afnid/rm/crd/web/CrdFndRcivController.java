package afnid.rm.crd.web;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.crd.service.CrdFndRcivService;
import afnid.rm.crd.service.CrdFndRcivVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;



/** 
 * This Controller class processes request of Found Card Receive-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Team Daesung Kim
 * @since 2011.04.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.09.30  		Daesung Kim          		                Create
 *
 * </pre>
 */

@Controller
public class CrdFndRcivController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** NidProgrmManageService */
	@Resource(name = "crdFndRcivService")
    private CrdFndRcivService service;
	
    /** CmmCdMngServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** NidCmmService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCmmService;
    
	@Resource(name="lgService")
	private LgService lgService;
 	/**
     * Moved to Found Card Receive Registration-screen. <br>
     *
     * @param vo Value-object of information to be parsed request(CrdFndRcivVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/crd/CrdFndRcivIns.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchCrdFndRcivInfrView.do")
    public String searchCrdFndRcivInfrView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndRcivVO") CrdFndRcivVO vo,
    		ModelMap model)
            throws Exception {
    	
    	try{
    		searchVO.setSearchKeyword("");
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(),vo.getCurMnId());
    		
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		}
        return "/rm/crd/CrdFndRcivIns";
    }
    
    /**
     * Retrieves Information of Found Card receiving . <br>
     *
     * @param vo Value-object of information to be parsed request(CrdFndRcivVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/crd/CrdFndRcivIns.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchCrdFndRcivInfr.do")
    public String searchCrdFndRcivInfr(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndRcivVO") CrdFndRcivVO vo,
    		ModelMap model)
            throws Exception {
    	
    	try {
    		
    		CrdFndRcivVO result = service.searchCrdFndRcivInfr(vo);
			if( result == null){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nHtsDat.msg")); // Message Setting
    		}else{
    			model.addAttribute("result", result);
    		}
	    			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
        return "/rm/crd/CrdFndRcivIns";
    	
    }
    
    /**
     * Retrieves Found Card Information List.  <br>
     * 
     * @param vo Value-object of Found Card Information to be parsed request(CrdFndRcivVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/p_CrdMoveList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchListCrdFndRcivInfr.do")
    public String searchListCrdFndRcivInfr (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdFndRcivVO") CrdFndRcivVO vo,
    		ModelMap model)
            throws Exception {
		
		try{
			
    		List<CrdFndRcivVO> result = service.searchListCrdFndRcivInfr( vo );
    		
    		model.addAttribute("result", result);
			
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute( "useLangCd",user.getUseLangCd());
    		model.addAttribute( "pupFlag","RCIV");
											
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

   		return "/rm/crd/p_CrdMoveList";
    }
    
    /**
     * registering information of Card receiving. <br>
     *
     * @param vo Value-object of information to be parsed request(CrdFndRcivVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/crd/CrdFndRcivIns.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/addCrdFndRcivInfr.do")
    public String addCrdFndRcivInfr(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndRcivVO") CrdFndRcivVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		

    		service.addCrdFndRcivInfr(vo);
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));   	
    		searchVO.setSearchKeyword("");
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		}
        return "/rm/crd/CrdFndRcivIns";
    	
    }
    
    /**
     * Moved to list-screen of Found Card Receive Approval. <br>
     *
     * @param vo Value-object of information to be parsed request(CrdFndRcivVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/crd/CrdFndRcivAprvList.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchListCrdFndRcivView.do")
    public String searchListCrdFndRcivView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndRcivVO") CrdFndRcivVO vo,
    		ModelMap model)
            throws Exception {
    	
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(),vo.getCurMnId());
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();// Common Code Value Object
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> cfmYn = cmmCdMngService.searchListCmmCdDesc(cmCmmCd); // Common Code Interface Call    		
    		model.addAttribute("cfmYn", cfmYn);//Yes No Code List
	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
        return "/rm/crd/CrdFndRcivAprvList";
    	
    }
    
    /**
     * Retrieves Information List of Found Card Receiving. <br>
     *
     * @param vo Value-object of information to be parsed request(CrdFndRcivVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/crd/CrdFndRcivAprvList.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchListCrdFndRciv.do")
    public String searchListCrdFndRciv(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndRcivVO") CrdFndRcivVO vo,
    		ModelMap model)
            throws Exception {
    	
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    		vo.setRcivOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
    		
    		if("".equals(searchVO.getSearchKeyword6())){
        		searchVO.setSearchKeyword6("j");    			
    		}
    		
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));
	    	
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());

			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			CmCmmCdVO cmCmmCd = new CmCmmCdVO();// Common Code Value Object
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> cfmYn = cmmCdMngService.searchListCmmCdDesc(cmCmmCd); // Common Code Interface Call    		
    		model.addAttribute("cfmYn", cfmYn);//Yes No Code List
    		List<CrdFndRcivVO> lstProgram = service.searchListCrdFndRcivAprv(vo);			
			model.addAttribute("lstProgram", lstProgram);	
			
			int totCnt = service.searchListCrdFndRcivAprvTotCn(vo);			
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
        return "/rm/crd/CrdFndRcivAprvList";
    	
    }
    
    /**
     * Retrieves Detail Information of Found Card Receiving.  <br>
     *
     * @param vo Value-object of information to be parsed request(CrdFndRcivVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/crd/CrdFndRcivAprvUdt.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchCrdFndRcivDtlAprv.do")
    public String searchCrdFndRcivDtlAprv(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndRcivVO") CrdFndRcivVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		CrdFndRcivVO result = service.searchCrdFndRcivDtlAprv(vo);
    		model.addAttribute("result", result);
    		
    	
    		ComDefaultVO greToday = nidCmmService.searchGreToDay( searchVO );
    		model.addAttribute("greToday", greToday.getStartDay());
    		
    		// Common Code Interface Call
 			CmCmmCdVO cmCmmCd = new CmCmmCdVO();	
    		cmCmmCd.setGrpCd("47");
    		List<CmCmmCdVO> prcssStus = cmmCdMngService.searchListCmmCd(cmCmmCd, false, "desc");
    		model.addAttribute("prcssStus", prcssStus);
    		
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
		}
    	
    	
    	
        return "/rm/crd/CrdFndRcivAprvUdt";
    	
    }
    /**
     * Approve Card Found Receiving information. <br>
     * 
     * @param vo Value-object of Card Found Receiving information to be parsed request(CrdFndRcivVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdFndRcivAprvList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/approveCrdFndRcivInfr.do")
    public String approveCrdFndRcivInfr(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndRcivVO") CrdFndRcivVO vo,
    		ModelMap model)
            throws Exception {    	
    	try {

  			service.approveCrdFndRcivInfr(vo);
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));			
    		    		
    	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "forward:/rm/crd/searchListCrdFndRciv.do";
    }
    
}