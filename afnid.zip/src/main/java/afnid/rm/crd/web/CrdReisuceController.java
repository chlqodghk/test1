package afnid.rm.crd.web;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.bioif.service.BioIfInfrService;
import afnid.rm.crd.service.CrdReisuceService;
import afnid.rm.crd.service.CrdReisuceVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/** 
 * This Controller class processes request of Card Lost/ Damage/ Renewal-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Daesung Kim 
 * @since 2013.06.14
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *  2013.06.14    		Daesung Kim          			Create
 *
 * </pre>
 */

@Controller
public class CrdReisuceController {
	
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());
	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /** CrdReisuceService */
	@Resource(name = "crdReisuceService")
    private CrdReisuceService service;
	
	/** CmmCdMngServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
	/** LgService */
	@Resource(name = "lgService")
	private LgService lgService;
	
	/** BioIfInfrService */
	@Resource(name="bioIfInfrService")
    private BioIfInfrService bioIfService;

	
	/** NidCmmService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCmmService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /**
     * Moved to Cord Lost/Damage/Renewal-screen. <br>
     * 
     * @param crdReisuceVO Value-object of  Cord Lost/Damage/Renewal to be parsed request(CrdReisuceVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdReisuceIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchCrdReisuceInfrView.do")
    public String searchCrdReisuceInfrView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdReisuceVO") CrdReisuceVO crdReisuceVO,
    		ModelMap model)
            throws Exception { 
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			lgService.addUserWrkLg(user.getUserId(), crdReisuceVO.getCurMnId());
			
			//Initiate Search Value
			comDefaultVO.setSearchKeyword("");
			comDefaultVO.setSearchKeyword4("");
			crdReisuceVO.setSearchKeyword("");
			crdReisuceVO.setSearchKeyword4("");
			
    		
    		List<CmCmmCdVO> ocrncRsnCd = service.searchRsnCd(crdReisuceVO); // Common Code Interface Call    		
    		model.addAttribute("ocrncRsnCd", ocrncRsnCd);//Code List
    		
	    	if("".equals(comDefaultVO.getSearchKeyword2())){
	    		//setting today date
	    		ComDefaultVO time = nidCmmService.searchPerToDay(comDefaultVO);
	    		comDefaultVO.setSearchKeyword2(time.getStartDay());
	    	}
    	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
      	return "/rm/crd/CrdReisuceIns";

    }
    
    /**
     * Retrieves Resident Information.  <br>
     * 
     * @param crdReisuceVO Value-object of Resident Information to be parsed request(CrdReisuceVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdReisuceIns.jsp"
     * @exception Exception
     */
    @SuppressWarnings("unchecked")
	@RequestMapping(value="/rm/crd/searchCrdReisuceInfr.do")
    public String searchCrdReisuceInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdReisuceVO") CrdReisuceVO crdReisuceVO,
    		ModelMap model)
            throws Exception { 
    	try {
    		CmCmmCdVO cmmCd = new CmCmmCdVO();
    		cmmCd.setGrpCd("74"); // Setting Group Code
    		List<CmCmmCdVO> reisuceRsnCd = cmmCdMngService.searchListCmmCd(cmmCd);    		
    		model.addAttribute("reisuceRsnCd", reisuceRsnCd);
    		List<CmCmmCdVO> ocrncRsnCd = service.searchRsnCd(crdReisuceVO); // Common Code Interface Call    		
    		model.addAttribute("ocrncRsnCd", ocrncRsnCd);//Code List
    		//setting today date
			ComDefaultVO time = nidCmmService.searchPerToDay(comDefaultVO);
			String toDayPer = time.getStartDay();
	    	model.addAttribute("toDayPer", toDayPer);
	    	time = nidCmmService.searchGreToDay(comDefaultVO);
	    	String toDayGre = time.getStartDay();
	    	model.addAttribute("toDayGre", toDayGre);
	    	int crdReisuceDmBfExpr = propertiesService.getInt("crdReisuceDmBfExpr");
	    	crdReisuceVO.setCrdReisuceDmBfExpr(String.valueOf(crdReisuceDmBfExpr));
	    	int adultAge = propertiesService.getInt("adultAge");
	    	crdReisuceVO.setAdultAge(String.valueOf(adultAge));
	    	int crdDlvrDd = propertiesService.getInt("crdDlvrDd");
	    	crdReisuceVO.setCrdDlvrDd(String.valueOf(crdDlvrDd));
	    	int crdExprProd = propertiesService.getInt("crdExprProd");
	    	crdReisuceVO.setCrdExprProd(String.valueOf(crdExprProd));
			
	    	String pageFlag= crdReisuceVO.getPageFlag();
    		if(pageFlag.length()>1){
    			crdReisuceVO.setPageFlag("E");
    			comDefaultVO.setSearchKeyword5("E");
    		}
	    	
	    	CrdReisuceVO result =  service.searchCrdReisuceInfr(crdReisuceVO);
    		
    		String month = crdReisuceVO.getCrdReisuceDmBfExpr(); 
			if(!"3".equals(result.getUseLangCd())){
				month =	NidStringUtil.toNumberConvet(month, "J");
			}
			
    		//check error Code
    		String errCd = result.getErrCd();
			if("ERR01".equals(errCd)){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstEnid.msg")); // Message Setting
			}else if("ERR02".equals(errCd)){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("rvctgCtzn.msg")); // Message Setting
			}else if("ERR03".equals(errCd)){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("fstCrdIsuceCdd.msg")); // Message Setting
			}else if("ERR04".equals(errCd)){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstByIsuce.msg")); // Message Setting
			}else if("ERR05".equals(errCd)){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstByCcltApl.msg")); // Message Setting
			}else if("ERR06".equals(errCd)){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("rgstOthrOfic.msg", new String[]{result.getRgstOrgnzCdNm()})); // Message Setting
			}else if("ERR07".equals(errCd)){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nHtsDat.msg")); // Message Setting
			}else if("ERR08".equals(errCd)){
				String expMd = result.getExpMd(); 
				if(!"3".equals(result.getUseLangCd())){
					expMd =	NidStringUtil.toNumberConvet(expMd, "J");
				}
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nRnwlByNExp.msg", new String[]{expMd, month})); // Message Setting
			}else if("ERR09".equals(errCd)){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstGoMdfct.msg")); // Message Setting
			}else if("ERR10".equals(errCd)){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("crdExpReisuce.msg", new String[]{month} )); // Message Setting
			}else if("ERR11".equals(errCd)){
				model.addAttribute("resultMsg", nidMessageSource.getMessage(result.getErrMsg())); // Message Setting
			}else{
				result.setCrdReisuceDmBfExpr(crdReisuceVO.getCrdReisuceDmBfExpr());
				model.addAttribute("rsdtInfo", result);
					        
        		// renew
        		if( (comDefaultVO != null && comDefaultVO.getSearchKeyword4() != null && "3".equals(comDefaultVO.getSearchKeyword4())) || result != null && result.getRsnCd() != null && "3".equals(result.getRsnCd())){
        			CmCmmCdVO cmCmmCd = new CmCmmCdVO();
            		cmCmmCd.setGrpCd("2"); // Setting Group Code
            		List<CmCmmCdVO> bldTyeCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("bldTyeCd", bldTyeCd);
            		cmCmmCd.setGrpCd("5"); // Setting Group Code
    	    		List<CmCmmCdVO> eduCd = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
    	    		model.addAttribute("eduCd", eduCd);
            		cmCmmCd.setGrpCd("12"); // Setting Group Code
            		List<CmCmmCdVO> mrrgCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("mrrgCd", mrrgCd); 
            		cmCmmCd.setGrpCd("10"); // Setting Group Code
            		List<CmCmmCdVO> gdrCd = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);    		
            		model.addAttribute("gdrCd", gdrCd);
            		cmCmmCd.setGrpCd("6"); // Setting Group Code
            		List<CmCmmCdVO> etncityCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("etncityCd", etncityCd);
            		cmCmmCd.setGrpCd("11"); // Setting Group Code
            		List<CmCmmCdVO> fmlyLangCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("fmlyLangCd", fmlyLangCd);
            		cmCmmCd.setGrpCd("11"); // Setting Group Code
            		List<CmCmmCdVO> nallangCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("nallangCd", nallangCd);
            		cmCmmCd.setGrpCd("17"); // Setting Group Code
            		List<CmCmmCdVO> rlgnCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("rlgnCd", rlgnCd);
            		cmCmmCd.setGrpCd("18"); // Setting Group Code
            		List<CmCmmCdVO> rlgnSect = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("rlgnSect", rlgnSect);
            		cmCmmCd.setGrpCd("13"); // Setting Group Code
            		List<CmCmmCdVO> mltSrvcCd = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);    		
            		model.addAttribute("mltSrvcCd", mltSrvcCd);
            		cmCmmCd.setGrpCd("14"); // Setting Group Code
            		List<CmCmmCdVO> nltyCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("nltyCd", nltyCd);
            		cmCmmCd.setGrpCd("8"); // Setting Group Code
            		List<CmCmmCdVO> frgnLang = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("frgnLang", frgnLang);
            		cmCmmCd.setGrpCd("9"); // Setting Group Code
            		List<CmCmmCdVO> codeLst = cmmCdMngService.searchListCmmCd(cmCmmCd);
            		model.addAttribute("rlCd", codeLst); 
            		cmCmmCd.setGrpCd("64"); // Setting Group Code
            		List<CmCmmCdVO> rsdtTypCd = cmmCdMngService.searchListCmmCd(cmCmmCd);
            		model.addAttribute("rsdtTypCd", rsdtTypCd); 
            		cmCmmCd.setGrpCd("68"); // Setting Group Code
    	    		List<CmCmmCdVO> dsbtCd = cmmCdMngService.searchListCmmCd(cmCmmCd);  
    	    		model.addAttribute("dsbtCd", dsbtCd); 
    	    		
    	    		int frgnLangOthrLangRgstNo = propertiesService.getInt("frgnLangOthrLangRgstNo");
    	    		model.addAttribute("frgnLangOthrLangRgstNo", frgnLangOthrLangRgstNo); 
    	    		int kochiUprAdCd = propertiesService.getInt("kochiUprAdCd");
    	    		model.addAttribute("kochiUprAdCd", kochiUprAdCd);
    	    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
    	    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd)); // Setting Kochi Address Code
    	    		EgovMap kochiAd = cmmCdMngService.searchAdCdNm(cmCmmCd);
    	    		model.addAttribute("kochiAd", kochiAd); 
    	    		
            		crdReisuceVO.setCrdReisuSeqNo(result.getCrdReisuSeqNo());
            		crdReisuceVO.setRsdtSeqNo(result.getRsdtSeqNo());
        			CrdReisuceVO vo = service.searchCrdRsdtInfrView(crdReisuceVO);
        			model.addAttribute("rsdtInfoVO", vo);
        			crdReisuceVO.setMdfctSeqNo(vo.getMdfctSeqNo());
        			EgovMap item = service.searchCrdRsdtInfrFrgnOthrView(crdReisuceVO);
					List<EgovMap> list = (List<EgovMap>)item.get("frgn");
        			if(list != null){
        				model.addAttribute("frgnLangList", list);
        			}
        			list = (List<EgovMap>)item.get("othrnat");
        			if(list != null){
        				model.addAttribute("othrNatLangList", list);
        			}
        			list = (List<EgovMap>)item.get("afFrgn");
        			if(list != null){
        				model.addAttribute("afFrgnLangList", list);
        			}
        			list = (List<EgovMap>)item.get("afOthrnat");
        			if(list != null){
        				model.addAttribute("afOthrNatLangList", list);
        			}
        		}
			}
	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
      	return "/rm/crd/CrdReisuceIns";

    }
    
    /**
     * registering information for Card Reissuing.  <br>
     * 
     * @param crdReisuceVO Value-object of Card Reissuing Information to be parsed request(CrdReisuceVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdReIsuIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/addCrdReisuceInfr.do")
    public String addCrdReisuceInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdReisuceVO") CrdReisuceVO crdReisuceVO,
    		ModelMap model)
            throws Exception { 
    	try {
    		service.addCrdReisuceInfr(crdReisuceVO);
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); //Message Setting
    		return "forward:/rm/crd/searchCrdReisuceInfr.do?pageFlag=E";
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
    	return "forward:/rm/crd/searchCrdReisuceInfrView.do";
    }
    
    /**
     * Moved to Cord Lost/Damage/Renewal List-screen. <br>
     * 
     * @param crdReisuceVO Value-object of  Cord Lost/Damage/Renewal to be parsed request(CrdReisuceVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdReisuceAprvList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchListCrdReisuceView.do")
    public String searchListCrdReisuceView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdReisuceVO") CrdReisuceVO crdReisuceVO,
    		ModelMap model)
            throws Exception { 
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			lgService.addUserWrkLg(user.getUserId(), crdReisuceVO.getCurMnId());
			
    		comDefaultVO.setSearchKeyword2("N");
	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
      	return "/rm/crd/CrdReisuceAprvList";

    }
    
    /**
     * Retrieves list of Reissuing Resident Information.  <br>
     * 
     * @param crdReisuceVO Value-object of Cord Lost/Damage/Renewal to be parsed request(CrdReisuceVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdReisuceAprvList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchListCrdReisuceAprv.do")
    public String searchListCrdReisuceAprv(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdReisuceVO") CrdReisuceVO crdReisuceVO,
    		ModelMap model)
            throws Exception { 
    	try{
    		
    	
    	/** Paging Setting */
    	crdReisuceVO.setPageUnit(propertiesService.getInt("pageUnit"));
    	crdReisuceVO.setPageSize(propertiesService.getInt("pageSize"));
    	
    	/** pageing */
    	PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(crdReisuceVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(crdReisuceVO.getPageUnit());
		paginationInfo.setPageSize(crdReisuceVO.getPageSize());

		crdReisuceVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		crdReisuceVO.setLastIndex(paginationInfo.getLastRecordIndex());
		crdReisuceVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
		
		//Setting user Language
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		crdReisuceVO.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
		crdReisuceVO.setUseLangCd(user.getUseLangCd());
		
		int aprvListTm = propertiesService.getInt("aprvListTm");
    	crdReisuceVO.setAprvListTm(String.valueOf(aprvListTm));
		//get Resident Information list
		List<CrdReisuceVO> lstReisuInfo = service.searchListCrdReisuceAprv(crdReisuceVO);
		model.addAttribute("lstReisuInfo", lstReisuInfo);
		
		//get list total count
		int totCnt = service.searchListCrdReisuceAprvTotCn(crdReisuceVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);
		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/crd/CrdReisuceAprvList";

    }
    
    /**
     * Moved to Cord Lost/Damage/Renewal Approval screen. <br>
     * 
     * @param crdReisuceVO Value-object of  Cord Lost/Damage/Renewal to be parsed request(crdReisuceVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdReisuceAprvUdt.jsp"
     * @exception Exception
     */
    @SuppressWarnings("unchecked")
	@RequestMapping(value="/rm/crd/searchCrdReisuceDtlAprv.do")
    public String searchCrdReisuceDtlAprv(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdReisuceVO") CrdReisuceVO crdReisuceVO,
    		ModelMap model)
            throws Exception { 
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("userId", user.getUserId());
    		
    		CmCmmCdVO cmmCd = new CmCmmCdVO();
    		cmmCd.setGrpCd("74"); // Setting Group Code
    		List<CmCmmCdVO> reisuceRsnCd = cmmCdMngService.searchListCmmCd(cmmCd);    		
    		model.addAttribute("reisuceRsnCd", reisuceRsnCd);
    		
    		int adultAge = propertiesService.getInt("adultAge");
    		crdReisuceVO.setAdultAge(String.valueOf(adultAge));
    		int crdReisuceDmBfExpr = propertiesService.getInt("crdReisuceDmBfExpr");
	    	crdReisuceVO.setCrdReisuceDmBfExpr(String.valueOf(crdReisuceDmBfExpr));

    		CrdReisuceVO result =service.searchCrdReisuceDtlAprv(crdReisuceVO);
    		
    		result.setUseLangCd(user.getUseLangCd());
    		result.setUserId(user.getUserId());
    		model.addAttribute("useOrgnzCd", user.getOrgnzClsCd()+user.getOrgnzCd());
    		model.addAttribute("reissueInfo", result);
    		
	    	//setting today date
			ComDefaultVO time = nidCmmService.searchPerToDay(comDefaultVO);
	    	model.addAttribute("toDayPer", time.getStartDay());
	    	time = nidCmmService.searchGreToDay(comDefaultVO);
	    	model.addAttribute("toDayGre", time.getStartDay());
	    	
	    	if(result != null){
	    		if(result.getRsdtSeqNo() != null && !"".equals(result.getRsdtSeqNo()) && result.getRsnCd() != null && "3".equals(result.getRsnCd())  ){
	    			CmCmmCdVO cmCmmCd = new CmCmmCdVO();
            		cmCmmCd.setGrpCd("2"); // Setting Group Code
            		List<CmCmmCdVO> bldTyeCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("bldTyeCd", bldTyeCd);
            		cmCmmCd.setGrpCd("5"); // Setting Group Code
    	    		List<CmCmmCdVO> eduCd = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
    	    		model.addAttribute("eduCd", eduCd);
            		cmCmmCd.setGrpCd("12"); // Setting Group Code
            		List<CmCmmCdVO> mrrgCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("mrrgCd", mrrgCd); 
            		cmCmmCd.setGrpCd("10"); // Setting Group Code
            		List<CmCmmCdVO> gdrCd = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);    		
            		model.addAttribute("gdrCd", gdrCd);
            		cmCmmCd.setGrpCd("6"); // Setting Group Code
            		List<CmCmmCdVO> etncityCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("etncityCd", etncityCd);
            		cmCmmCd.setGrpCd("11"); // Setting Group Code
            		List<CmCmmCdVO> fmlyLangCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("fmlyLangCd", fmlyLangCd);
            		cmCmmCd.setGrpCd("11"); // Setting Group Code
            		List<CmCmmCdVO> nallangCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("nallangCd", nallangCd);
            		cmCmmCd.setGrpCd("17"); // Setting Group Code
            		List<CmCmmCdVO> rlgnCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("rlgnCd", rlgnCd);
            		cmCmmCd.setGrpCd("18"); // Setting Group Code
            		List<CmCmmCdVO> rlgnSect = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("rlgnSect", rlgnSect);
            		cmCmmCd.setGrpCd("13"); // Setting Group Code
            		List<CmCmmCdVO> mltSrvcCd = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);    		
            		model.addAttribute("mltSrvcCd", mltSrvcCd);
            		cmCmmCd.setGrpCd("14"); // Setting Group Code
            		List<CmCmmCdVO> nltyCd = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("nltyCd", nltyCd);
            		cmCmmCd.setGrpCd("8"); // Setting Group Code
            		List<CmCmmCdVO> frgnLang = cmmCdMngService.searchListCmmCd(cmCmmCd);    		
            		model.addAttribute("frgnLang", frgnLang);
            		cmCmmCd.setGrpCd("9"); // Setting Group Code
            		List<CmCmmCdVO> codeLst = cmmCdMngService.searchListCmmCd(cmCmmCd);
            		model.addAttribute("rlCd", codeLst); 
            		cmCmmCd.setGrpCd("64"); // Setting Group Code
            		List<CmCmmCdVO> rsdtTypCd = cmmCdMngService.searchListCmmCd(cmCmmCd);
            		model.addAttribute("rsdtTypCd", rsdtTypCd);
            		cmCmmCd.setGrpCd("68"); // Setting Group Code
    	    		List<CmCmmCdVO> dsbtCd = cmmCdMngService.searchListCmmCd(cmCmmCd);  
    	    		model.addAttribute("dsbtCd", dsbtCd); 
    	    		
    	    		int frgnLangOthrLangRgstNo = propertiesService.getInt("frgnLangOthrLangRgstNo");
    	    		model.addAttribute("frgnLangOthrLangRgstNo", frgnLangOthrLangRgstNo);
    	    		int kochiUprAdCd = propertiesService.getInt("kochiUprAdCd");
    	    		model.addAttribute("kochiUprAdCd", kochiUprAdCd);
    	    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
    	    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd)); // Setting Kochi Address Code
    	    		EgovMap kochiAd = cmmCdMngService.searchAdCdNm(cmCmmCd);
    	    		model.addAttribute("kochiAd", kochiAd);
    	    		
            		CrdReisuceVO vo = new CrdReisuceVO();
            		vo.setRsdtSeqNo(result.getRsdtSeqNo());
            		vo.setRsdtNo(result.getRsdtNo());
            		vo.setCrdReisuSeqNo(result.getCrdReisuSeqNo());
            		vo.setUserId(user.getUserId());
            		vo.setUseLangCd(user.getUseLangCd());
        	    	vo.setCrdReisuceDmBfExpr(String.valueOf(crdReisuceDmBfExpr));
        	    	
        			CrdReisuceVO vos = service.searchCrdRsdtInfrView(vo);
        			model.addAttribute("rsdtInfoVO", vos);
        			vo.setMdfctSeqNo(vos.getMdfctSeqNo());
        			EgovMap item = service.searchCrdRsdtInfrFrgnOthrView(vo);
					List<EgovMap> list = (List<EgovMap>)item.get("frgn");
        			if(list != null){
        				model.addAttribute("frgnLangList", list);
        			}
        			list = (List<EgovMap>)item.get("othrnat");
        			if(list != null){
        				model.addAttribute("othrNatLangList", list);
        			}
        			list = (List<EgovMap>)item.get("afFrgn");
        			if(list != null){
        				model.addAttribute("afFrgnLangList", list);
        			}
        			list = (List<EgovMap>)item.get("afOthrnat");
        			if(list != null){
        				model.addAttribute("afOthrNatLangList", list);
        			}
	    		}
	    	}
    		
    	
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
      	return "/rm/crd/CrdReisuceAprvUdt";

    }
    
    /**
     * Update information for Card Reissuing.  <br>
     * 
     * @param crdReisuceVO Value-object of Card Update Information to be parsed request(CrdReisuceVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdReisuceAprvUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/modifyCrdReisuceDtlAprv.do")
    public String modifyCrdReisuceDtlAprv(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdReisuceVO") CrdReisuceVO crdReisuceVO,
    		ModelMap model)
            throws Exception { 
    	try {
    		
    		service.modifyCrdReisuceDtlAprv(crdReisuceVO);
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); //Message Setting
    		   		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
      	return "forward:/rm/crd/searchCrdReisuceDtlAprv.do";

    }
    
    /**
     * Approval for Card Reissuing.  <br>
     * 
     * @param crdReisuceVO Value-object of verification Information to be parsed request(CrdReisuceVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdReisuceAprvUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/ApproveCrdReisuceInfr.do")
    public String approveCrdReisuceInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdReisuceVO") CrdReisuceVO crdReisuceVO,
    		ModelMap model)
            throws Exception { 
    	try {
    		
    		//for approve
    		CrdReisuceVO result = service.approveCrdReisuceInfr(crdReisuceVO);
    		crdReisuceVO.setLgSeqNo(result.getLgSeqNo());
    		
    		String errCd = result.getErrCd();
			if("ERR04".equals(errCd)){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstByIsuce.msg")); // Message Setting
			}else if("ERR06".equals(errCd)){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nAprvByApvd.msg")); // Message Setting
			}else{
				
				if("Y".equals(crdReisuceVO.getCrdIsuceYn())){
					
					if("APVMSG".equals(errCd)){
						model.addAttribute("resultMsg", nidMessageSource.getMessage("apvrWtoutCrdReisuce.msg")); //Message Setting	
					}else{
						model.addAttribute("resultMsg", nidMessageSource.getMessage("apvScsfl.msg")); //Message Setting	
					}
					
					String dsuseMsg = result.getDsuseMsg();
	    			if(!"".equals(dsuseMsg)){
	    				model.addAttribute("dsuseMsg",dsuseMsg);
	    			}
	    			
	    			if(result.getBioMap() != null && "3".equals(crdReisuceVO.getRsnCd())){
	    				log.debug("==========insert Bio Log==========");
	    				bioIfService.addBioInterfaceLog(result.getBioMap());
	    			}
	    			
	    		}else if("1".equals(crdReisuceVO.getRsnCd())&& "N".equals(crdReisuceVO.getCrdIsuceYn()) ){
					if(null != result.getLgSeqNo() &&!"".equals(result.getLgSeqNo()) ){
		    			String pkiResult = service.approveCrdReisuceInfrPkiIf(crdReisuceVO);
		    			
		        		if(!"0".equals(pkiResult)){
		        			String helpTelNo = nidMessageSource.getMessage("admTelNo");
		        			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{pkiResult, helpTelNo}));
		        		} else {
		        			model.addAttribute("resultMsg", nidMessageSource.getMessage("apvScsfl.msg"));
		        		}						
					}else{
						model.addAttribute("resultMsg", nidMessageSource.getMessage("apvScsfl.msg")); //Message Setting	
					}
					
				}else{
					model.addAttribute("resultMsg", nidMessageSource.getMessage("apvScsfl.msg")); //Message Setting	
				}		
			}  		
    	} catch (Exception e) {
    		
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
      	return "forward:/rm/crd/searchListCrdReisuceAprv.do";

    }
    
    /**
     * Receipt for Citizen Confirmation <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/p_RsdtMdfcCfmRcpt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchCrdReisuceCfmRcpt.do")
    public String searchCrdReisuceCfmRcpt (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdReisuceVO") CrdReisuceVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
       		vo.setUseLangCd(user.getUseLangCd());
    		
    		EgovMap result = service.searchCrdReisuceCfmRcpt(vo);
			model.addAttribute("resultVO", result);
			
			List<EgovMap> list = service.searchCrdReisuceOthrCfmRcpt(vo);
			model.addAttribute("othrNatLangList", list);
			
			list = service.searchCrdReisuceFrgnCfmRcpt(vo);
			model.addAttribute("frgnLangList", list);
			
			model.addAttribute("useLangCd", user.getUseLangCd());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/rsdt/p_RsdtMdfcCfmRcpt";   	
    }
    
	/**
     * Replacement card receipts of program.  <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(CrdReisuceVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/p_RsdtMdfcRcpt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchCrdReisuceRcpt.do")
    public String searchCrdReisuceRcpt (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdReisuceVO") CrdReisuceVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
       		vo.setUseLangCd(user.getUseLangCd());
       		EgovMap result = null;
       		List<EgovMap> othrlist = null;
       		List<EgovMap> frgnlist = null;
    		if("3".equals(vo.getRsnCd())){
    			result = service.searchCrdReisuceCfmRcpt(vo);
    			othrlist = service.searchCrdReisuceOthrCfmRcpt(vo);
    			frgnlist = service.searchCrdReisuceFrgnCfmRcpt(vo);
    			
    		}else{
    			result = service.searchCrdReisuceRcpt(vo);
    			othrlist = service.searchCrdReisuceOthrRcpt(vo);
    			frgnlist = service.searchCrdReisuceFrgnRcpt(vo);

    		}
    		model.addAttribute("resultVO", result);
    		model.addAttribute("othrNatLangList", othrlist);
    		model.addAttribute("frgnLangList", frgnlist);
    		model.addAttribute("useLangCd", user.getUseLangCd());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/rsdt/p_RsdtMdfcRcpt";   	
    }
}
