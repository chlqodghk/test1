package afnid.rm.crd.web;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.crd.service.CrdDitbService;
import afnid.rm.crd.service.CrdDitbVO;
import afnid.rm.rsdt.service.RsdtInfrService;
import egovframework.rte.fdl.property.EgovPropertyService;



/** 
 * This Controller class processes request of Card distribution-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Team Daesung Kim
 * @since 2013.09.26
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.09.26  		Daesung Kim          		                  Create
 *
 * </pre>
 */

@Controller
public class CrdDitbController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** CrdDitbService */
	@Resource(name = "crdDitbService")
    private CrdDitbService service;
		
	/** LgService */
	@Resource(name = "lgService")
	private LgService lgService;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
	
    /** rsdtInfoService service */
    @Resource(name="rsdtInfoService")
    private RsdtInfrService rsdtInfoService;
    
    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
    
    /**
     * Moved to screen of eNID Card Identification Individual.  <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param crdDitbVO Value-object of program to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crd/CrdDitbIdfcIndiUdt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchCrdDitbIdfcIndiInfrView.do")
    public String searchCrdDitbIdfcIndiInfrView (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdDitbVO") CrdDitbVO vo,
    		ModelMap model)
            throws Exception {
		try{
			
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
			
			//Initiate Search Value
			comDefaultVO.setSearchKeyword("");
			comDefaultVO.setSearchKeyword4("");
			vo.setSearchKeyword("");
			vo.setSearchKeyword4("");
			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/crd/CrdDitbIdfcIndiUdt";
    }
	
	/**
     * Retrieves Resident Information.  <br>
     * 
     * @param crdDitbVO Value-object of Resident Information to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdDitbIdfcIndiUdt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchCrdDitbIdfcIndiInfr.do")
    public String searchCrdDitbIdfcIndiInfr (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdDitbVO") CrdDitbVO vo,
    		ModelMap model)
            throws Exception {
		
		try{
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
			vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
			
			CrdDitbVO stusResult =  service.searchRsdtCrdApplyStus(vo);

			CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("78"); // Setting Group Code
    		List<CmCmmCdVO> crdDsuseRsnCd = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("crdDsuseRsnCd", crdDsuseRsnCd);
			
			
			if(stusResult == null){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstEnid.msg"));
			}else{
				
				String crdIsuSeqNo = stusResult.getCrdIsuSeqNo();
				String fleNm = stusResult.getFleNm();
				String crdDitbSeqNo = stusResult.getCrdDitbSeqNo();
				String crdIsuceStusCd = stusResult.getCrdIsuceStusCd();
				String crdArvlFailYn = stusResult.getCrdArvlFailYn();
				
				if("2".equals(stusResult.getRsdtStusCd()) && ("3".equals(stusResult.getErsrCd()) ||"4".equals(stusResult.getErsrCd()))){
					model.addAttribute("resultMsg", nidMessageSource.getMessage("rvctgByBioDpt.msg"));
				}else if("1".equals(stusResult.getRsdtStusCd()) && "Y".equals(stusResult.getTamLedrCfmYn()) && "0".equals(stusResult.getIsuCnt())){
					model.addAttribute("resultMsg", nidMessageSource.getMessage("crdApplying.msg"));
				}else if((null != crdIsuSeqNo && !"".equals(crdIsuSeqNo) )&&( null == fleNm ||"".equals(fleNm))){
					model.addAttribute("resultMsg", nidMessageSource.getMessage("crdApplying.msg"));
				}else if((null != crdDitbSeqNo && !"".equals(crdDitbSeqNo)) && (null == crdIsuceStusCd || "".equals(crdIsuceStusCd))){
					model.addAttribute("resultMsg", nidMessageSource.getMessage("crdIssuing.msg"));
				}else if((null != crdDitbSeqNo && !"".equals(crdDitbSeqNo)) && (null != crdIsuceStusCd && !"".equals(crdIsuceStusCd))){

					if("1".equals(crdIsuceStusCd) && (null == crdArvlFailYn || "".equals(crdArvlFailYn))){
						model.addAttribute("resultMsg", nidMessageSource.getMessage("crdMoving.msg")); 
					}else{
						
						CrdDitbVO crdIdfcInfr =  service.searchCrdDitbIdfcIndiInfr(vo);
						
						if(crdIdfcInfr == null){
							//No data is queried.
							model.addAttribute("resultMsg", nidMessageSource.getMessage("nHtsDat.msg"));
						}else{
							
							//check for Citizen Revocation Apply Status
							String  RvctgMsg =  service.searchRsdtRvctgStus(vo);
							
							//check for Citizen Rehabilitation Status
							if("".equals(RvctgMsg) && "1".equals(crdIdfcInfr.getCrdIsuceStusCd())){
								if("Y".equals(crdIdfcInfr.getIsExp())){
									RvctgMsg = nidMessageSource.getMessage("expCrd.msg");
								}else{
									String  isRhblt =  service.searchRsdtRhbltInfr(crdIdfcInfr.getRsdtSeqNo());
									if("Y".equals(isRhblt)){
										RvctgMsg = nidMessageSource.getMessage("rqstBfCcltRhblt");
									}
								}
							}
	
							crdIdfcInfr.setIdfcUserId(user.getUserId());
							crdIdfcInfr.setUseLangCd(user.getUseLangCd());
							crdIdfcInfr.setIdfcUserIdNm(user.getNm());
							crdIdfcInfr.setCrdDitbOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());
							model.addAttribute("RvctgMsg", RvctgMsg);	
							model.addAttribute("crdIdfcInfr", crdIdfcInfr);		
						}
					}
				}else{
					model.addAttribute("resultMsg", nidMessageSource.getMessage("nHtsDat.msg"));
				}
			}

		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
		
   		return "/rm/crd/CrdDitbIdfcIndiUdt";
    }
	
	 /**
     * registering information of Card Identification.  <br>
     * 
     * @param crdDitbVO Value-object of Card Identification Information to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdDitbIdfcIndiUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/modifyCrdDitbIdfcIndiInfr.do")
    public String modifyCrdDitbIdfcIndiInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdDitbVO") CrdDitbVO vo,
    		ModelMap model)
            throws Exception { 
    	try {
    		
    		service.modifyCrdDitbIdfcIndiInfr(vo);
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); //Message Setting
    		   		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
      	return "forward:/rm/crd/searchCrdDitbIdfcIndiInfrView.do";

    }
	
    /**
     * registering information of Card Disuse.  <br>
     * 
     * @param crdDitbVO Value-object of Card Disuse Information to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdDitbIdfcIndiUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/modifyCrdDisuseOnIdfcIndi.do")
    public String modifyCrdDisuseOnIdfcIndi(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdDitbVO") CrdDitbVO vo,
    		ModelMap model)
            throws Exception { 
    	try {
    		service.modifyCrdDisuseOnIdfcIndi(vo);
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); //Message Setting
    		if("fmly".equals(vo.getPageFlag())){
    			return "forward:/rm/crd/searchCrdDitbIdfcFmlyInfrView.do";
    		}   		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
      	return "forward:/rm/crd/searchCrdDitbIdfcIndiInfrView.do";

    }
    
	/**
     * Moved to screen of eNID Card Distribution Individual.  <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param crdDitbVO Value-object of program to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crd/CrdDitbIndiUdt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchCrdDitbIndiInfrView.do")
    public String searchCrdDitbIndiInfrView (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdDitbVO") CrdDitbVO vo,
    		ModelMap model)
            throws Exception {
		
		try{
			
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
		
   		return "/rm/crd/CrdDitbIndiUdt";
    }
	
	/**
     * Retrieves Resident Information.  <br>
     * 
     * @param crdDitbVO Value-object of Resident Information to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdDitbIndiUdt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchCrdDitbIndiInfr.do")
    public String searchCrdDitbIndiInfr (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdDitbVO") CrdDitbVO vo,
    		ModelMap model)
            throws Exception {
		
		try{
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			model.addAttribute("userId", user.getUserId());
			vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
			vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
			int adultAge = propertiesService.getInt("adultAge");
			vo.setAdultAge(String.valueOf(adultAge));
			
			CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("78"); // Setting Group Code
    		List<CmCmmCdVO> crdDsuseRsnCd = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("crdDsuseRsnCd", crdDsuseRsnCd);
    		
			CrdDitbVO crdDitbInfr =  service.searchCrdDitbIndiInfr(vo);
			
			if(crdDitbInfr == null){
				//No data is queried.
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nHtsDat.msg"));
			}else if("2".equals(crdDitbInfr.getCrdIdfcBy())){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("idfcByFmly.msg"));
			}else{
				//check for Citizen Revocation Apply Status
				String  RvctgMsg =  service.searchRsdtRvctgStus(vo);
				if("".equals(RvctgMsg) && "Y".equals(crdDitbInfr.getIsExp())){
					RvctgMsg = nidMessageSource.getMessage("expCrd.msg");
				}
				
				model.addAttribute("RvctgMsg", RvctgMsg);	
				model.addAttribute("crdDitbInfr", crdDitbInfr);		
			}
	
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
		
   		return "/rm/crd/CrdDitbIndiUdt";
    }
	
	/**
     * registering information of Card Identification.  <br>
     * 
     * @param crdDitbVO Value-object of Card Identification Information to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdDitbIdfcIndiUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/modifyCrdDitbIndiInfr.do")
    public String modifyCrdDitbIndiInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdDitbVO") CrdDitbVO vo,
    		ModelMap model)
            throws Exception { 
    	try {
    		
    		String lgSeqNo = service.modifyCrdDitbIndiInfr(vo);
    		vo.setLgSeqNo(lgSeqNo);
    		
    		if(!"".equals(lgSeqNo)){
    			String pkiResult = service.modifyCrdDitbIndiInfrPkiIf(vo);
    			
        		if(!"0".equals(pkiResult)){
        			String helpTelNo = nidMessageSource.getMessage("admTelNo");
        			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{pkiResult, helpTelNo}));
        		} else {
        			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
        		}
        		
    		} else {
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}

    		comDefaultVO.setSearchKeyword("");//initialization SearchKeyword value
    		
    		   		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
      	return "/rm/crd/CrdDitbIndiUdt";

    }

	
	/**
     * Moved to screen of eNID Card Identification Family.  <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param crdDitbVO Value-object of program to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crd/CrdDitbIdfcFmlyUdt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchCrdDitbIdfcFmlyInfrView.do")
    public String searchCrdDitbIdfcFmlyInfrView (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdDitbVO") CrdDitbVO vo,
    		ModelMap model)
            throws Exception {
		try{
			
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
			
			//Initiate Search Value
			comDefaultVO.setSearchKeyword("");
			comDefaultVO.setSearchKeyword4("");
			vo.setSearchKeyword("");
			vo.setSearchKeyword4("");
			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/crd/CrdDitbIdfcFmlyUdt";
    }
	
	
	/**
     * Retrieves Resident Information.  <br>
     * 
     * @param crdDitbVO Value-object of Resident Information to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdDitbIdfcFmlyUdt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchCrdDitbIdfcFmlyInfr.do")
    public String searchCrdDitbIdfcFmlyInfr (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdDitbVO") CrdDitbVO vo,
    		ModelMap model)
            throws Exception {
		
		try{

			CrdDitbVO hadInfr =  service.searchFmlyHadInfr(vo);
			
			if(hadInfr == null){
				//Citizen eNID Number does not exist 
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstEnid.msg"));
			}else if(!"Y".equals(hadInfr.getFmlyHadYn()) ){
				//Citizen eNID Number is not head of family
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nFmlyHadEnid.msg"));
			}else if("2".equals(hadInfr.getRsdtStusCd()) && ("3".equals(hadInfr.getErsrCd()) ||"4".equals(hadInfr.getErsrCd()))){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("rvctgByBioDpt.msg"));
			}else{
				
				//check for Citizen Revocation Status
    			String rvctgStus = rsdtInfoService.searchRsdtRvctgStus(hadInfr.getRsdtNo(), "msg");

    			if(!"".equals(rvctgStus)){
    				model.addAttribute("resultMsg", nidMessageSource.getMessage(rvctgStus));
    				return "/rm/crd/CrdDitbIdfcFmlyUdt";
    			}
    			
    			int adultAge = propertiesService.getInt("adultAge");
    			hadInfr.setAdultAge(String.valueOf(adultAge));
    			
    			//get Card Applying Candidate List
    			List<CrdDitbVO> appInfr = service.searchFmlyMberCrdApplyStus(hadInfr);
				
    			//get Disuse Candidate List
				hadInfr.setRsdtStusFlag("2");
				hadInfr.setIsuceStusFlag("isNormal");
				List<CrdDitbVO> dsuseInfr = service.searchCrdDitbIdfcFmlyInfr(hadInfr);
				
				//get Error Card List
				hadInfr.setRsdtStusFlag("");
				hadInfr.setIsuceStusFlag("isErr");
				List<CrdDitbVO> errInfr = service.searchCrdDitbIdfcFmlyInfr(hadInfr);
				
				//get Distribution Candidate List
				hadInfr.setRsdtStusFlag("1");
				hadInfr.setIsuceStusFlag("isNormal");
				List<CrdDitbVO> fmlyInfr = service.searchCrdDitbIdfcFmlyInfr(hadInfr);
				
				//check for Head of family Rehabilitation Status
				String  hadDitbSeqNo =  service.searchFmlyHadRhbltInfr(hadInfr.getRsdtNo(), fmlyInfr);
				if(!"".equals(hadDitbSeqNo)){
					model.addAttribute("resultMsg", nidMessageSource.getMessage("crdDuseByCcltRhblt.msg"));
    				return "/rm/crd/CrdDitbIdfcFmlyUdt";
				}
				//setting officer information
				LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		
				hadInfr.setIdfcUserId(user.getUserId());
				hadInfr.setUseLangCd(user.getUseLangCd());
				hadInfr.setIdfcUserIdNm(user.getNm());
				hadInfr.setCrdDitbOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());
				
				
				model.addAttribute("hadDitbSeqNo", hadDitbSeqNo);	
				model.addAttribute("hadInfr", hadInfr);
				model.addAttribute("appInfr", appInfr);
				model.addAttribute("fmlyInfr", fmlyInfr);
				model.addAttribute("dsuseInfr", dsuseInfr);
				model.addAttribute("errInfr", errInfr);
			}
	
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
		
   		return "/rm/crd/CrdDitbIdfcFmlyUdt";
    }
	
	 /**
     * registering information of Card Identification.  <br>
     * 
     * @param crdDitbVO Value-object of Card Identification Information to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdDitbIdfcFmlyUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/modifyCrdDitbIdfcFmlyInfr.do")
    public String modifyCrdDitbIdfcFmlyInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdDitbVO") CrdDitbVO vo,
    		ModelMap model)
            throws Exception { 
    	try {
    		
    		service.modifyCrdDitbIdfcFmlyInfr(vo);
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); //Message Setting
    		   		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
      	return "forward:/rm/crd/searchCrdDitbIdfcFmlyInfrView.do";

    }
	
	/**
     * Moved to screen of eNID Card Distribution Family.  <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param crdDitbVO Value-object of program to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crd/CrdDitbFmlyUdt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchCrdDitbFmlyInfrView.do")
    public String searchCrdDitbFmlyInfrView (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdDitbVO") CrdDitbVO vo,
    		ModelMap model)
            throws Exception {
		try{	
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());	
			
			//Initiate Search Value
			comDefaultVO.setSearchKeyword("");
			comDefaultVO.setSearchKeyword4("");
			vo.setSearchKeyword("");
			vo.setSearchKeyword4("");
			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/crd/CrdDitbFmlyUdt";
    }
	
	/**
     * Moved to screen of eNID Card Distribution Family.  <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param crdDitbVO Value-object of program to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crd/CrdDitbFmlyUdt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchCrdDitbFmlyInfr.do")
    public String searchCrdDitbFmlyInfr (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdDitbVO") CrdDitbVO vo,
    		ModelMap model)
            throws Exception {
		try{
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			model.addAttribute("userId", user.getUserId());
			
			CrdDitbVO hadInfr =  service.searchFmlyHadInfr(vo);
			
			if(hadInfr == null){
				//Citizen eNID Number does not exist 
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstEnid.msg"));
			}else if(!"Y".equals(hadInfr.getFmlyHadYn()) ){
				//Citizen eNID Number is not head of family
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nFmlyHadEnid.msg"));
			}else{
				
				//check for Citizen Revocation Status
    			String rvctgStus = rsdtInfoService.searchRsdtRvctgStus(hadInfr.getRsdtNo(), "msg");

    			if(!"".equals(rvctgStus)){
    				model.addAttribute("resultMsg", nidMessageSource.getMessage(rvctgStus));
    				return "/rm/crd/CrdDitbFmlyUdt";
    			}
    			
    			int adultAge = propertiesService.getInt("adultAge");
    			hadInfr.setAdultAge(String.valueOf(adultAge));
    			
    			//get Disuse Candidate List
				hadInfr.setRsdtStusFlag("2");
				List<CrdDitbVO> dsuseInfr = service.searchCrdDitbFmlyInfr(hadInfr);
				
				//get Individual Distribution Candidate List
				hadInfr.setRsdtStusFlag("1");
				hadInfr.setCrdIdfcBy("1");
				List<CrdDitbVO> indiInfr = service.searchCrdDitbFmlyInfr(hadInfr);
				
				//get Distribution Candidate List
				hadInfr.setRsdtStusFlag("1");
				hadInfr.setCrdIdfcBy("2");
				List<CrdDitbVO> fmlyInfr = service.searchCrdDitbFmlyInfr(hadInfr);
			
				model.addAttribute("dsuseInfr", dsuseInfr);
				model.addAttribute("hadInfr", hadInfr);	
				model.addAttribute("indiInfr", indiInfr);
				model.addAttribute("fmlyInfr", fmlyInfr);
				model.addAttribute("fmlyCnt", fmlyInfr.size());
			}
	
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/crd/CrdDitbFmlyUdt";
    }
	
	/**
     * registering information of Card Identification.  <br>
     * 
     * @param crdDitbVO Value-object of Card Identification Information to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdDitbFmlyUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/modifyCrdDitbFmlyInfr.do")
    public String modifyCrdDitbFmlyInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdDitbVO") CrdDitbVO vo,
    		ModelMap model)
            throws Exception { 
    	try {
    		
    		CrdDitbVO result = service.modifyCrdDitbFmlyInfr(vo);
    		
    		List<String> list           = result.getRsdtNoList();
    		List<String> lgSeqNoList    = result.getLgSeqNoList();
    		
    		String msgTye = "0";
    		String pkiResult ="";
    		
    		if(null != list && 0 != list.size()){
    			for(int i=0;i < list.size(); i++ ){ 
	    			vo.setLgSeqNo(lgSeqNoList.get(i));
	    			vo.setRsdtNo(list.get(i));
	    			pkiResult = service.modifyCrdDitbFmlyInfrPkiIf(vo);
	    			
	        		if(!"0".equals(pkiResult)){
	        			msgTye = pkiResult;		        			
	        		}
    			}
    		}
    		 
    		if(msgTye.equals("0")){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		} else {
    			String helpTelNo = nidMessageSource.getMessage("admTelNo");
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{pkiResult, helpTelNo}));    			
    		}
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
      	return "forward:/rm/crd/searchCrdDitbFmlyInfrView.do";

    }

}