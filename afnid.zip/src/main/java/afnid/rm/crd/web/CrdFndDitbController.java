package afnid.rm.crd.web;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.crd.service.CrdFndDitbService;
import afnid.rm.crd.service.CrdFndDitbVO;
import egovframework.rte.fdl.property.EgovPropertyService;



/** 
 * This Controller class processes request of Found Card Distribution-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Team Daesung Kim
 * @since 2011.04.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.09.30  		Daesung Kim          		                Create
 *
 * </pre>
 */

@Controller
public class CrdFndDitbController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** crdFndDitbService */
	@Resource(name = "crdFndDitbService")
    private CrdFndDitbService service;
	
	/** LgService */
	@Resource(name = "lgService")
	private LgService lgService;


	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;

 	/**
     * Moved to list-screen of resident. <br>
     *
     * @param crdFndDitbVO Value-object of resident to be parsed request(CrdFndDitbVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/crd/CrdFndDitbIdfcUdt.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchCrdFndDitbIdfcInfrView.do")
    public String searchCrdFndDitbIdfcInfrView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdFndDitbVO") CrdFndDitbVO vo,
    		ModelMap model)
            throws Exception {
    	try{	
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
			
			comDefaultVO.setSearchKeyword("");
			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
        return "/rm/crd/CrdFndDitbIdfcUdt";
    	
    }
    
    /**
     * Retrieves Resident Information.  <br>
     * 
     * @param crdFndDitbVO Value-object of Resident Information to be parsed request(CrdFndDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdFndDitbIdfcUdt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchCrdFndDitbIdfcInfr.do")
    public String searchCrdFndDitbIdfcInfr (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdFndDitbVO") CrdFndDitbVO vo,
    		ModelMap model)
            throws Exception {
		
		try{
			
			CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("78"); // Setting Group Code
    		List<CmCmmCdVO> crdDsuseRsnCd = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("crdDsuseRsnCd", crdDsuseRsnCd);
			
			CrdFndDitbVO crdFondIdfc =  service.searchCrdFndDitbIdfcInfr(vo);
			
			if(crdFondIdfc == null){
				//No data is queried.
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nHtsDat.msg"));
				return "/rm/crd/CrdFndDitbIdfcUdt";
				
			}else if("N".equals(crdFondIdfc.getCallPopupYn()) ){
				LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
				crdFondIdfc.setIdfcUserId(user.getUserId());
				crdFondIdfc.setUseLangCd(user.getUseLangCd());
				crdFondIdfc.setIdfcUserIdNm(user.getNm());
				crdFondIdfc.setCrdDitbOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());
				
			}
				model.addAttribute("crdFondIdfc", crdFondIdfc);		
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
		
   		return "/rm/crd/CrdFndDitbIdfcUdt";
    }
    
	/**
     * Retrieves Resident Information List.  <br>
     * 
     * @param crdFndDitbVO Value-object of Resident Information to be parsed request(CrdFndDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/p_CrdFndList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchListCrdFndDitbInfr.do")
    public String searchListCrdFndDitbInfr (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdFndDitbVO") CrdFndDitbVO vo,
    		ModelMap model)
            throws Exception {
		
		try{
			
    		List<CrdFndDitbVO> result = service.searchListCrdFndDitbInfr( vo );
    		
    		model.addAttribute("result", result);
			
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute( "useLangCd",user.getUseLangCd());
											
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

   		return "/rm/crd/p_CrdFndList";
    }
	
	/**
     * registering information of Card Identification.  <br>
     * 
     * @param crdFndDitbVO Value-object of Card Identification Information to be parsed request(CrdFndDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdFndDitbIdfcUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/addCrdFndDitbIdfcInfr.do")
    public String addCrdDitbIdfcIndiInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdFndDitbVO") CrdFndDitbVO vo,
    		ModelMap model)
            throws Exception { 
    	try {
    		
    		service.addCrdFndDitbIdfcInfr(vo);
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); //Message Setting
    		   		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
      	return "forward:/rm/crd/searchCrdFndDitbIdfcInfrView.do";

    }
    
    /**
     * Moved to list-screen of Found Card Distribution. <br>
     *
     * @param CardInfoVO Value-object of resident to be parsed request(CrdFndDitbVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/crd/CardInfoLst.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchCrdFndDitbInfrView.do")  							   
    public String searchCrdFndDitbInfrView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("CrdFndDitbVO") CrdFndDitbVO vo,
    		ModelMap model)
            throws Exception {
    	try{	
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());		
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
        return "/rm/crd/CrdFndDitbUdt";
    	
    }
    
    /**
     * Retrieves Resident Information.  <br>
     * 
     * @param crdFndDitbVO Value-object of Resident Information to be parsed request(CrdFndDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdFndDitbUdt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchCrdFndDitbInfr.do")
    public String searchCrdFndDitbInfr (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdFndDitbVO") CrdFndDitbVO vo,
    		ModelMap model)
            throws Exception {
		
		try{
			
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			model.addAttribute("userId", user.getUserId());
			
			CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("78"); // Setting Group Code
    		List<CmCmmCdVO> crdDsuseRsnCd = cmmCdMngService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("crdDsuseRsnCd", crdDsuseRsnCd);
			
			CrdFndDitbVO crdFondDitb =  service.searchCrdFndDitbInfr(vo);
			
			if(crdFondDitb == null){
				//No data is queried.
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nHtsDat.msg"));
				return "/rm/crd/CrdFndDitbUdt";
				
			}
			
			model.addAttribute("crdFondDitb", crdFondDitb);	
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
		
   		return "/rm/crd/CrdFndDitbUdt";
    }
	
	/**
     * registering information of Card Identification.  <br>
     * 
     * @param crdFndDitbVO Value-object of Card Identification Information to be parsed request(CrdFndDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdFndDitbUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/modifyCrdFndDitbInfr.do")
    public String modifyCrdFndDitbInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdFndDitbVO") CrdFndDitbVO vo,
    		ModelMap model)
            throws Exception { 
    	try {
    		
    		String lgSeqNo = service.modifyCrdFndDitbInfr(vo);
    		vo.setLgSeqNo(lgSeqNo);
    		
    		if(!"".equals(lgSeqNo)){
				String pkiResult = service.modifyCrdFndDitbInfrPkiIf(vo);
				
	    		if(!"0".equals(pkiResult)){
	    			String helpTelNo = nidMessageSource.getMessage("admTelNo");
	    			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{pkiResult, helpTelNo}));
	    		} else {
	    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
	    		}
    		} else {
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); //Message Setting
    		}
	    		    		
    		comDefaultVO.setSearchKeyword("");// initialization SearchKeyword value
    		   		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	
    	
      	return "forward:/rm/crd/searchCrdFndDitbInfrView.do";

    }
    
    /**
     * modify information of Card Process Status.  <br>
     * 
     * @param crdFndDitbVO Value-object of Card Information to be parsed request(CrdFndDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdFndDitbIdfcUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/modifyCrdFndPrcssStusForDitbFndCrd.do")
    public String modifyCrdFndPrcssStusForDitbFndCrd(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdFndDitbVO") CrdFndDitbVO vo,
    		ModelMap model)
            throws Exception { 
    	try {
    		
    		service.modifyCrdFndPrcssStusForDitbFndCrd(vo);
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); //Message Setting
    		
    		if("ditb".equals(vo.getReturnFlag())){
    			return "forward:/rm/crd/searchCrdFndDitbInfrView.do";
    		}
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}	

      	return "forward:/rm/crd/searchCrdFndDitbIdfcInfrView.do";

    }
    
}