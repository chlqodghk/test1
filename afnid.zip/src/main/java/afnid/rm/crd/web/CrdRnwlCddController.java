package afnid.rm.crd.web;

/* java API */
import java.io.OutputStream;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.error.ErrorHandler;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.crd.service.CrdRnwlCddService;
import afnid.rm.crd.service.CrdRnwlCddVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;



/** 
 * This Controller class processes request of Card Renewal Candidate List and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Team Ha Na YIM
 * @since 2011.04.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.04.19  		Ha Na YIM          		                    Create
 *
 * </pre>
 */

@Controller
public class CrdRnwlCddController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** NidProgrmManageService */
	@Resource(name = "crdRnwlCddService")
    private CrdRnwlCddService service;
	
    /** CmmCdMngServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
	/** LgService */
	@Resource(name = "lgService")
	private LgService lgService;
	
	/** nidCmmService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCmmService;
	
 	/**
     * Moved to list-screen of Card Renewal Candidate List. <br>
     *
     * @param crdRnwlCddVO Value-object of resident to be parsed request(CrdRnwlCddVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crd/CrdRnwlCddList.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchListCrdRnwlCddView.do")
    public String searchListCrdRnwlCddView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdRnwlCddVO") CrdRnwlCddVO vo,
    		ModelMap model)
            throws Exception {
    	try{ 		
    		    	
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
			
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCmmService.searchGreToDay(searchVO);
    		searchVO.setSearchKeyword(comVo.getStartDay().replaceAll("-", ""));
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("10"); 
    		List<CmCmmCdVO> gdrCd = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
        return "/rm/crd/CrdRnwlCddList";
    	
    }

    /**
     * Retrieves list of program.  <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param crdRnwlCddVO Value-object of program to be parsed request(CrdRnwlCddVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crd/CrdRnwlCddList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchListCrdRnwlCdd.do")
    public String searchListCrdRnwlCdd (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdRnwlCddVO") CrdRnwlCddVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());

    		
    		String orgnzCls = user.getOrgnzClsCd();
    		String orgnzCd = user.getOrgnzCd();			  
    		String teamCd  = user.getTamCdNm();			
    		
    		String authSeqNo = user.getOfcalPsnCd();
    		
    		if(!"4".equals(authSeqNo)){
    			vo.setOfficerNo(orgnzCls + orgnzCd + teamCd);
    		} else {
    			vo.setOfficerNo("");
    		}
    		    		    		
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));
	    	
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());

			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());			

			List<EgovMap> lstProgram = service.searchListCrdRnwlCdd(vo);			
			model.addAttribute("lstProgram", lstProgram);			
			
			int totCnt = service.searchListCrdRnwlCddTotCn(vo);			
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);	        
	        
	        //vo.setExpiryDate(searchVO.getSearchKeyword4());
	        //searchVO.setSearchKeyword( service.searchDdCvt(vo) );
	        	        	        
	        CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("10"); 
    		List<CmCmmCdVO> gdrCd = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
   		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
   		return "/rm/crd/CrdRnwlCddList";   		
    }    
	
	
    /**
     * Download Card Renewal Candidate List to Excel. <br>
     * 
     * @param crdRnwlCddVO Value-object of Card Renewal Candidate List to be parsed request(CrdRnwlCddVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchListCrdRnwlCddExcel.do")
    public void searchListCrdRnwlCddExcel(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdRnwlCddVO") CrdRnwlCddVO vo,
    		HttpServletResponse response,    		
			ModelMap model)
            throws Exception {
		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFCell cell = null;
		
    	try {

    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		vo.setUseLangCd(user.getUseLangCd());
    		String orgnzCls = user.getOrgnzClsCd();
    		String orgnzCd  = user.getOrgnzCd();			  
    		String teamCd   = user.getTamCdNm();			
    		
    		vo.setOfficerNo(orgnzCls + orgnzCd + teamCd);

    		String stsTitle = nidMessageSource.getMessage("nidCrdExprList");

    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 15 * 256);
    		sheet.setColumnWidth(1, 25 * 256);    		
    		sheet.setColumnWidth(2, 14 * 256);
    		sheet.setColumnWidth(3, 10 * 256);
    		sheet.setColumnWidth(4, 25 * 256);
    		sheet.setColumnWidth(5, 40 * 256);
    		sheet.setColumnWidth(6, 10 * 256);
    		sheet.setColumnWidth(7, 14 * 256);

    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 5) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);

    		//title : enrollment date
			cell = row1.createCell(0);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("ctznEnid")); 

			cell = row1.createCell(1);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("nm"));
			
			cell = row1.createCell(2);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("bthDd"));

			cell = row1.createCell(3);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("gdr"));
			
			
			cell = row1.createCell(4);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("fthrNm"));
			

			cell = row1.createCell(5);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("prsntAd"));
			
			
			cell = row1.createCell(6);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("exprDd"));

    		
    		int totCnt = service.searchListCrdRnwlCddTotCn(vo);
    		
    		int totPage = (int)Math.ceil((double)totCnt/1000); 
    		

    		//DATA Display
    		for(int j=0; j<totPage; j++){
    			vo.setFirstIndex(j*1000);
    			vo.setLastIndex(j+1);    			
    			vo.setRecordCountPerPage(1000);    			
    			
    			List<CrdRnwlCddVO> lstProgram = service.searchListCrdRnwlCddExcel(vo);
    			
	    		for(int k=0; k<lstProgram.size(); k++){
	    			
	    			CrdRnwlCddVO rowData = lstProgram.get(k);
	    			row = sheet.createRow(k+2);	  
	    			
	    		    cell  = row.createCell(0);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, false));
	    		    cell.setCellValue(rowData.getRsdtNoDp());
	    			
	    		    cell  = row.createCell(1);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, true));
	    		    cell.setCellValue(rowData.getNm());
	    		    
	    		    cell  = row.createCell(2);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, true));
	    		    cell.setCellValue(rowData.getBthDd());
	    		    
	    		    cell  = row.createCell(3);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, true));
	    		    cell.setCellValue(rowData.getGdrCdNm());
	    		    
	    		    cell  = row.createCell(4);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, true));
	    		    cell.setCellValue(rowData.getFthrNm());
	    		    
	    		    cell  = row.createCell(5);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, true));
	    		    
	    		    String curtDtlCt ="";
	    		    if(rowData.getCurtAdDtlCt()!= null && !"".equals(rowData.getCurtAdDtlCt()) ){
	    		    	curtDtlCt = rowData.getCurtAdDtlCt() + "/";
	    		    } 
	
	    		    cell.setCellValue(curtDtlCt + rowData.getCurtAdCdNm());
	    		    
	    		    cell  = row.createCell(6);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, true));
	    		    cell.setCellValue(rowData.getCrdExpiryDd());
	    		}
	    		
	    		lstProgram.clear();    			
    		}

    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		
    		if("j".equals(vo.getSearchKeyword6())){
    			comVo = nidCmmService.searchPerToDay(comVo);
    			fileDate = NidStringUtil.toNumberConvet(comVo.getStartDay(), "g");
    		} else {
    			comVo = nidCmmService.searchGreToDay(comVo);
    			fileDate = comVo.getStartDay();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"eNID_Card_Expired_List.xls");
    		workbook.write(os);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }	
    
    //Get Font
    public  HSSFFont getFont(HSSFWorkbook workbook, int fontSize, boolean isBold){
   	      HSSFFont font = null;
          font = workbook.createFont();
          font.setFontHeightInPoints((short)fontSize);
          if(isBold) font.setBoldweight(Font.BOLDWEIGHT_BOLD);
   	      font.setColor(HSSFColor.BLACK.index);
   	      return font; 
   }	    
    	 
    //Get Title Style
    public  HSSFCellStyle getTitleStyle(HSSFWorkbook workbook){
    	 HSSFCellStyle style = null;
    	 style = workbook.createCellStyle();
    	 style.setFont(getFont(workbook, 14, true));
    	 style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
    	 style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
    	 
    	 return style;
    }	
    
    //Get Colum Title Style
    public  HSSFCellStyle getColumTitleStyle(HSSFWorkbook workbook,  boolean isBold, boolean isBG){
    	 HSSFCellStyle style = null;

    	 style = workbook.createCellStyle();

    	 style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
    	 style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
    	 
    	  if (isBG){
    		  style.setFillForegroundColor(HSSFColor.AQUA.index);
    		  style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    	  }
    	  
    	  style.setBorderBottom(CellStyle.BORDER_THIN);
    	  style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
    	  style.setBorderLeft(CellStyle.BORDER_THIN);
    	  style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
    	  style.setBorderRight(CellStyle.BORDER_THIN);
    	  style.setRightBorderColor(IndexedColors.BLACK.getIndex());
    	  style.setBorderTop(CellStyle.BORDER_THIN);
    	  style.setTopBorderColor(IndexedColors.BLACK.getIndex());
    	
    	 return style;
    }	    
    
	 
    //Get Column Data Style
    public  HSSFCellStyle getColumDataStyle(HSSFWorkbook workbook,  String langType, boolean isBold, boolean isBG, boolean isNum){
    	HSSFCellStyle style = null;

    	style = workbook.createCellStyle();

    	style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);		
	 
    	if(isNum){
    		style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
    	} else {
    		if ("3".equals(langType)) {
    			style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
    		} else {
    			style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
    		}
    	}
	 
    	if (isBG){
		  style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		  style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    	}
	  
	
    	style.setBorderBottom(CellStyle.BORDER_THIN);
    	style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
    	style.setBorderLeft(CellStyle.BORDER_THIN);
    	style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
    	style.setBorderRight(CellStyle.BORDER_THIN);
    	style.setRightBorderColor(IndexedColors.BLACK.getIndex());
    	style.setBorderTop(CellStyle.BORDER_THIN);
    	style.setTopBorderColor(IndexedColors.BLACK.getIndex());

	  return style;
    }	     
}
