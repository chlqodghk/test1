package afnid.rm.crd.web;


import java.io.File;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.error.ErrorHandler;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.uss.service.UserMngService;
import afnid.cm.uss.service.UserMngVO;
import afnid.rm.crd.service.CrdArvlService;
import afnid.rm.crd.service.CrdArvlVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;



/** 
 * This Controller class processes request of Card Delivery. <br>
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2014.11.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers				Revisions
 *   2014.11.17  		MoonSoo Kim             Create
 *
 * </pre>
 */
@Controller
public class CrdArvlController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** NidProgrmManageService */
	@Resource(name = "crdArvlService")
    private CrdArvlService service;

    /** UserMngServiceImpl */
	@Resource(name = "userMngService")
    private UserMngService userMngService;	
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
	/** LgService */
	@Resource(name = "lgService")
	private LgService lgService;
	
	/** nidCmmService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCmmService;
	
 	/**
     * Moved to list-screen of eNID Card Arrival List. <br>
     *
     * @param CrdArvlVO Value-object of resident to be parsed request(CrdArvlVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crd/CrdArvlList.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchListCrdArvlView.do")
    public String searchListCrdArvlView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdArvlVO") CrdArvlVO crdArvlVO,
    		ModelMap model)
            throws Exception {
    	try{ 		
    		    	
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			lgService.addUserWrkLg(user.getUserId(), crdArvlVO.getCurMnId());

			UserMngVO userMngVo = new UserMngVO();
			userMngVo.setUserId(user.getUserId());
			
			UserMngVO userAthr = userMngService.searchUserMainAthr(userMngVo);
					
			crdArvlVO.setAthrSeqNo(userAthr.getAthrSeqNo());
			
			if(!"4".equals(userAthr.getAthrSeqNo()) ){
				crdArvlVO.setSrchOrgnzNm(userAthr.getOrgnzCdNm());
				crdArvlVO.setSrchOrgnzCd(userAthr.getOrgnzCd());
			}
			
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo.setAddDay("-13");
    		comVo = nidCmmService.searchGreAddingInputDay(comVo);	    		
    		searchVO.setSearchKeyword(comVo.getStartDay().replaceAll("-", ""));
    		
    		comVo = nidCmmService.searchGreToDay(comVo);	    			    			    		
    		searchVO.setSearchKeyword2(comVo.getStartDay().replaceAll("-", ""));    		    		

    		searchVO.setSearchKeyword4("2");    		
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
        return "/rm/crd/CrdArvlList";
    	
    }

    /**
     * Retrieves list of eNID Card Arrival.  <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param CrdArvlVO Value-object of program to be parsed request(CrdArvlVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crdCrdArvlList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchListCrdArvl.do")
    public String searchListCrdArvl (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdArvlVO") CrdArvlVO crdArvlVO,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		crdArvlVO.setUseLangCd(user.getUseLangCd());

			UserMngVO userMngVo = new UserMngVO();
			userMngVo.setUserId(user.getUserId());
			
			UserMngVO userAthr = userMngService.searchUserMainAthr(userMngVo);
					
			crdArvlVO.setAthrSeqNo(userAthr.getAthrSeqNo());  		
    		
			crdArvlVO.setPageUnit(propertiesService.getInt("pageUnit"));
			crdArvlVO.setPageSize(propertiesService.getInt("pageSize"));
	    	
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(crdArvlVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(crdArvlVO.getPageUnit());
			paginationInfo.setPageSize(crdArvlVO.getPageSize());

			crdArvlVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			crdArvlVO.setLastIndex(paginationInfo.getLastRecordIndex());
			crdArvlVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());	
			
			String remoteRecvBasePath = propertiesService.getString("dpp.local.xml.recv.base")+File.separator+"FeedbackDPP_";
			
		    if(!"".equals(crdArvlVO.getSrchOrgnzCd())){
		    	
	            if( "00".equals(crdArvlVO.getSrchOrgnzCd().substring(2, 4)) ){
	            	crdArvlVO.setOficTye("1");
	            } else{
	            	crdArvlVO.setOficTye("2");
	            }		    	
		    }
		    
			crdArvlVO.setRplcStr(remoteRecvBasePath);
			List<CrdArvlVO> lstCrdArvl= service.searchListCrdArvl(crdArvlVO);			
			model.addAttribute("lstCrdArvl", lstCrdArvl);			
			
			int totCnt = service.searchListCrdArvlTotCn(crdArvlVO);			
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);	        

   		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
   		return "/rm/crd/CrdArvlList";   		
    }    
	
    /**
     * Moved to list-screen of eNID Card Arrival Citizens List.  <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param CrdArvlVO Value-object of program to be parsed request(CrdArvlVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crdCrdArvlList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchListCrdArvlRsdtView.do")
    public String searchListCrdArvlRsdtView (
    		@ModelAttribute("searchVO")  ComDefaultVO searchVO,
    		@ModelAttribute("crdArvlVO") CrdArvlVO crdArvlVO,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		crdArvlVO.setUseLangCd(user.getUseLangCd());

			UserMngVO userMngVo = new UserMngVO();
			userMngVo.setUserId(user.getUserId());
			
			UserMngVO userAthr = userMngService.searchUserMainAthr(userMngVo);
					
			crdArvlVO.setAthrSeqNo(userAthr.getAthrSeqNo());  		
    		
			crdArvlVO.setPageUnit(propertiesService.getInt("pageUnit"));
			crdArvlVO.setPageSize(propertiesService.getInt("pageSize"));
	    	
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(crdArvlVO.getPageIndex2());
			paginationInfo.setRecordCountPerPage(crdArvlVO.getPageUnit());
			paginationInfo.setPageSize(crdArvlVO.getPageSize());

			crdArvlVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			crdArvlVO.setLastIndex(paginationInfo.getLastRecordIndex());
			crdArvlVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());	

		    crdArvlVO.setSearchKeyword6("2");//Arrival Condition		    
		    crdArvlVO.setSearchKeyword7(crdArvlVO.getSearchKeyword5());//Citizen Number
		    crdArvlVO.setSearchKeyword8(crdArvlVO.getSearchKeyword3());//Calendar Type
						
			int totCnt = service.searchListCrdArvlRsdtTotCn(crdArvlVO);			
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);	        

	        CrdArvlVO rsdtCnt = service.searchCrdArvlRsdtCn(crdArvlVO);
	        model.addAttribute("rsdtCnt", rsdtCnt);	
   		
			List<CrdArvlVO> lstCrdArvlRsdt= service.searchListCrdArvlRsdt(crdArvlVO);			
			model.addAttribute("lstCrdArvlRsdt", lstCrdArvlRsdt);
			
			List<CrdArvlVO> lstCrdArvlRsdtAll= service.searchListCrdArvlRsdtCrdReisuce(crdArvlVO);			
			model.addAttribute("lstCrdArvlRsdtAll", lstCrdArvlRsdtAll);	
			
	        model.addAttribute("userId", user.getUserId());	
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
   		return "/rm/crd/CrdArvlUdt";   		
    }	

    /**
     * Retrieves list of eNID Card Arrival Citizens.  <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param CrdArvlVO Value-object of program to be parsed request(CrdArvlVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crdCrdArvlList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchListCrdArvlRsdt.do")
    public String searchListCrdArvlRsdt (
    		@ModelAttribute("searchVO")  ComDefaultVO searchVO,
    		@ModelAttribute("crdArvlVO") CrdArvlVO crdArvlVO,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		crdArvlVO.setUseLangCd(user.getUseLangCd());

			UserMngVO userMngVo = new UserMngVO();
			userMngVo.setUserId(user.getUserId());
			
			UserMngVO userAthr = userMngService.searchUserMainAthr(userMngVo);
					
			crdArvlVO.setAthrSeqNo(userAthr.getAthrSeqNo());  		
    		
			crdArvlVO.setPageUnit(propertiesService.getInt("pageUnit"));
			crdArvlVO.setPageSize(propertiesService.getInt("pageSize"));
	    	
			int totCnt = service.searchListCrdArvlRsdtTotCn(crdArvlVO);			

			PaginationInfo paginationInfo = new PaginationInfo();
	        int pageVal = totCnt % 10;
	        
	        if(pageVal == 0){
	        	paginationInfo.setCurrentPageNo(totCnt/10);
	        } else {
	        	paginationInfo.setCurrentPageNo(crdArvlVO.getPageIndex2());
	        }
	    	
			paginationInfo.setRecordCountPerPage(crdArvlVO.getPageUnit());
			paginationInfo.setPageSize(crdArvlVO.getPageSize());

			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        
			crdArvlVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			crdArvlVO.setLastIndex(paginationInfo.getLastRecordIndex());
			crdArvlVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());	
			
			List<CrdArvlVO> lstCrdArvlRsdt= service.searchListCrdArvlRsdt(crdArvlVO);			
			model.addAttribute("lstCrdArvlRsdt", lstCrdArvlRsdt);			
			
	        

	        CrdArvlVO rsdtCnt = service.searchCrdArvlRsdtCn(crdArvlVO);
	        model.addAttribute("rsdtCnt", rsdtCnt);
	        
			List<CrdArvlVO> lstCrdArvlRsdtAll= service.searchListCrdArvlRsdtCrdReisuce(crdArvlVO);			
			model.addAttribute("lstCrdArvlRsdtAll", lstCrdArvlRsdtAll);	
			
	        if(!"link_page".equals(crdArvlVO.getPrcssTye())){
	        	crdArvlVO.setSlcAllYn("");
	        }
	        
	        model.addAttribute("userId", user.getUserId());	
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
   		return "/rm/crd/CrdArvlUdt";   		
    }
	
	/**
     * Reissuance eNID Card <br>
     * 
     * @param crdArvlVO Value-object for eNID Card reissuance(crdArvlVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdArvlUdt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/modifyArvlCadReisuce.do")
    public String modifyArvlCadReisuce (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdArvlVO") CrdArvlVO vo,
    		ModelMap model)
            throws Exception {
		
		try{            
			service.modifyArvlCadReisuce(vo);   
			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));    		
    	}
   		return "forward:/rm/crd/searchListCrdArvlRsdt.do";
    }
	
	/**
     * Processing eNID Card Arrival<br>
     * 
     * @param crdArvlVO Value-object for eProcessing eNID Card Arrival(crdArvlVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdArvlUdt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/modifyArvl.do")
    public String modifyArvl (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdArvlVO") CrdArvlVO vo,
    		ModelMap model)
            throws Exception {
		
		try{            
			service.modifyArvl(vo);  
			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));    		
    	}
   		return "forward:/rm/crd/searchListCrdArvlRsdt.do";
    }
	
	/**
     * Processing eNID Card Arrival Clear <br>
     * 
     * @param crdArvlVO Value-object for Processing eNID Card Arrival Clear(crdArvlVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdArvlUdt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/modifyArvlClar.do")
    public String modifyArvlClar (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdArvlVO") CrdArvlVO vo,
    		ModelMap model)
            throws Exception {
		
		try{            
			service.modifyArvlClar(vo);
			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));    		
    	}
   		return "forward:/rm/crd/searchListCrdArvlRsdt.do";
    }	
	
	/**
     * Moved to list-screen of Issuance Failed Citizens List. <br>
     *
     * @param CrdArvlVO Value-object of resident to be parsed request(CrdArvlVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crd/CrdFailRsdtList.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchListCrdFailRsdtView.do")
    public String searchListCrdFailRsdtView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdArvlVO") CrdArvlVO crdArvlVO,
    		ModelMap model)
            throws Exception {
    	try{ 		
    		    	
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			lgService.addUserWrkLg(user.getUserId(), crdArvlVO.getCurMnId());

			UserMngVO userMngVo = new UserMngVO();
			userMngVo.setUserId(user.getUserId());
			
			UserMngVO userAthr = userMngService.searchUserMainAthr(userMngVo);
					
			crdArvlVO.setAthrSeqNo(userAthr.getAthrSeqNo());
			
			if(!"4".equals(userAthr.getAthrSeqNo()) ){
				crdArvlVO.setSrchOrgnzNm(userAthr.getOrgnzCdNm());
				crdArvlVO.setSrchOrgnzCd(userAthr.getOrgnzCd());
			}
			
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCmmService.searchGreAddToDay("-1"); 	    		
    		searchVO.setSearchKeyword(comVo.getStartDay().replaceAll("-", ""));	    			    			    		
    		searchVO.setSearchKeyword2(comVo.getEndDay().replaceAll("-", "")); 
    		
    		comVo = nidCmmService.searchPerToDay(searchVO);
    		crdArvlVO.sethPrsntDd(comVo.getStartDay());
    		
    		comVo = nidCmmService.searchGreToDay1(searchVO);
    		crdArvlVO.sethPrsntDd(comVo.getStartDay());
    		
    		searchVO.setSearchKeyword4("1"); 
    		
    		model.addAttribute("userId", user.getUserId());	
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
        return "/rm/crd/CrdFailRsdtList";
    	
    }	
    
    /**
     * Retrieves list of Issuance Failed Citizens.  <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param CrdArvlVO Value-object of program to be parsed request(CrdArvlVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crd/CrdArvlList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchListCrdFailRsdt.do")
    public String searchListCrdFailRsdt (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdArvlVO") CrdArvlVO crdArvlVO,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		crdArvlVO.setUseLangCd(user.getUseLangCd());

			UserMngVO userMngVo = new UserMngVO();
			userMngVo.setUserId(user.getUserId());
			
			UserMngVO userAthr = userMngService.searchUserMainAthr(userMngVo);
					
			crdArvlVO.setAthrSeqNo(userAthr.getAthrSeqNo());  		
    		
			crdArvlVO.setPageUnit(propertiesService.getInt("pageUnit"));
			crdArvlVO.setPageSize(propertiesService.getInt("pageSize"));
	    	
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(crdArvlVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(crdArvlVO.getPageUnit());
			paginationInfo.setPageSize(crdArvlVO.getPageSize());

			crdArvlVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			crdArvlVO.setLastIndex(paginationInfo.getLastRecordIndex());
			crdArvlVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());	
			
		    if(!"".equals(crdArvlVO.getSrchOrgnzCd())){
		    	
	            if( "00".equals(crdArvlVO.getSrchOrgnzCd().substring(2, 4)) ){
	            	crdArvlVO.setOficTye("1");
	            } else{
	            	crdArvlVO.setOficTye("2");
	            }		    	
		    }
		    
		    ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCmmService.searchPerToDay(searchVO);
    		crdArvlVO.sethPrsntDd(comVo.getStartDay());
    		
    		comVo = nidCmmService.searchGreToDay1(searchVO);
    		crdArvlVO.setgPrsntDd(comVo.getStartDay());
    		
		    String remoteRecvBasePath = propertiesService.getString("dpp.local.xml.recv.base")+"/FeedbackDPP_";
		    crdArvlVO.setRplcStr(remoteRecvBasePath);
		    
			List<CrdArvlVO> lstCrdFailRsdt= service.searchListCrdFailRsdt(crdArvlVO);			
			model.addAttribute("lstCrdFailRsdt", lstCrdFailRsdt);			
			
			int totCnt = service.searchListCrdFailRsdtTotCn(crdArvlVO);			
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);	        
	        model.addAttribute("userId", user.getUserId());	
   		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
   		return "/rm/crd/CrdFailRsdtList";   		
    }    
	
	/**
     * Reissuance eNID Card <br>
     * 
     * @param crdArvlVO Value-object for modify Citizen Contact Y/N(crdArvlVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "rm/crd/CrdArvlList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/modifyCrdFailRsdt.do")
    public String modifyCrdFailRsdt (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdArvlVO") CrdArvlVO vo,
    		ModelMap model)
            throws Exception {
		
		try{ 
			
			service.modifyCrdFailRsdt(vo);   
			
			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));    		
    	}
   		return "forward:/rm/crd/searchListCrdFailRsdt.do";
    }
	

	
}
