package afnid.rm.crd.web;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.crd.service.CrdDsuseService;
import afnid.rm.crd.service.CrdDsuseVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;



/** 
 * This Controller class processes request of Card Disuse Processing. <br>
 * 
 * @author Afghanistan National ID RM Application Team MS Kim
 * @since 2013.12.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           				  Revisions
 *   2013.12.17  		MS Kim         		                  Create
 *
 * </pre>
 */

@Controller
public class CrdDsuseController{

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** CrdDitbService */
	@Resource(name = "crdDsuseService")
    private CrdDsuseService crdDsuseService;
		
	/** LgService */
	@Resource(name = "lgService")
	private LgService lgService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;

    /** CmmCdMngService */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
    /**
     * Moved to screen of eNId Card Issuance Error List.  <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param crdDitbVO Value-object of program to be parsed request(CrdIsuErrPrcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crd/CrdDsuseList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchListCrdDsuseInfrView.do")
    public String searchListCrdDsuseInfrView (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdDsuseVO") CrdDsuseVO vo,
    		ModelMap model)
            throws Exception {
		try{
						
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());

			searchVO.setSearchKeyword2("2");
			
			CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("26"); 
    		List<CmCmmCdVO> deuseYn = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("deuseYn", deuseYn);
			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg",  new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/crd/CrdDsuseList";
    }
	
	/**
     * Retrieves Resident Information.  <br>
     * 
     * @param crdDitbVO Value-object of Resident Information to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdDsuseList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchListCrdDsuseInfr.do")
    public String searchListCrdDsuseInfr (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdDsuseVO") CrdDsuseVO vo,
    		ModelMap model)
            throws Exception {
		
		try{
			
    		if("".equals(searchVO.getSearchKeyword6())){
        		searchVO.setSearchKeyword6("j");    			
    		}
    		
			vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));

	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());
			
			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

			CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("26"); 
    		List<CmCmmCdVO> deuseYn = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("deuseYn", deuseYn);
    		
            List<CrdDsuseVO> lstCrdDsuse = crdDsuseService.searchListCrdDsuse(vo);
            model.addAttribute("lstCrdDsuse",  lstCrdDsuse); 
            	
    	    int totCnt = crdDsuseService.searchListCrdDsuseTotCnt(vo);
    		paginationInfo.setTotalRecordCount(totCnt);            	
  
			model.addAttribute("paginationInfo", paginationInfo);
			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg",  new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
		
   		return "/rm/crd/CrdDsuseList";
    }

	
	/**
     * update citizen card Disuse request.  <br>
     * 
     * @param crdDitbVO Value-object of citizen card information to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdDsuseList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/modifyCrdDsuseRqst.do")
    public String modifyCrdDsuseRqst (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdDsuseVO") CrdDsuseVO vo,
    		ModelMap model)
            throws Exception {
		
		try{            
			String lgSeqNo = crdDsuseService.modifyCrdDsuseRqst(vo);   
    		vo.setLgSeqNo(lgSeqNo);
			
			String ccmResult = crdDsuseService.modifyCrdDsuseRqstPkiIf(vo);
			
    		if(!"1".equals(ccmResult)){
    			String helpTelNo = nidMessageSource.getMessage("admTelNo");
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{ccmResult, helpTelNo}));
    		} else {
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}

			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg",  new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "forward:/rm/crd/searchListCrdDsuseInfr.do";
    }	
	
	/**
     * update disuse Result Information.  <br>
     * 
     * @param vo Value-object of Citizen Card Information to be parsed request(CrdDitbVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdDsuseList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/modifyCrdDsuseRsutChk.do")
    public String modifyCrdDsuseRsutChk (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdDsuseVO") CrdDsuseVO vo,
    		ModelMap model)
            throws Exception {
		
		try{            
			int result = crdDsuseService.modifyCrdDsuseRsutChk(vo);    		
			
			if(result == 4){
				String helpTelNo = nidMessageSource.getMessage("admTelNo");	
				model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{String.valueOf(result), helpTelNo}));
			}else if(result == 1){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("crdKillRqstNotFinish.msg"));
			}else if(result == 2){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("crdDsuseScsfl.msg"));
			}

		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg",  new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "forward:/rm/crd/searchListCrdDsuseInfr.do";
    }
	
	
}