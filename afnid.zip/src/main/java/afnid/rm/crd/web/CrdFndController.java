package afnid.rm.crd.web;

/* java API */
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.crd.service.CrdFndService;
import afnid.rm.crd.service.CrdFndVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;



/** 
 * This Controller class processes request of Found Card-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Team Daesung Kim
 * @since 2011.04.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.09.30  		Daesung Kim          		                Create
 *
 * </pre>
 */

@Controller
public class CrdFndController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** CrdFndService */
	@Resource(name = "crdFndService")
    private CrdFndService service;
	
    /** CmmCdMngServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
	/** NidCmmService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCmmService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** lgService service */
    @Resource(name="lgService")
    private LgService lgService;
    
 	/**
     * Moved to list-screen of Card Found. <br>
     *
     * @param CrdFndVO Value-object of resident to be parsed request(CrdFndVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/crd/CardFndIns.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchCrdFndInfrView.do")
    public String searchCrdFndInfrView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndVO") CrdFndVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(),vo.getCurMnId());
    		
    		
    		searchVO.setSearchKeyword("");
    		
    		ComDefaultVO greToday = nidCmmService.searchGreToDay( searchVO );
    		model.addAttribute("greToday", greToday.getStartDay());
    		ComDefaultVO perToday = nidCmmService.searchPerToDay( searchVO );
    		model.addAttribute("perToday", perToday.getStartDay());
	   
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/crd/CrdFndIns";
    	
    }
    
    /**
     * Retrieves Found Card Information of program. <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param CrdFndVO Value-object of resident to be parsed request(CrdFndVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/crd/CardFndIns.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchCrdFndInfr.do")
    public String searchCrdFndInfr(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndVO") CrdFndVO vo,
    		ModelMap model)
            throws Exception {
    	try{

    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    		int adultAge = propertiesService.getInt("adultAge");
	    	vo.setAdultAge(String.valueOf(adultAge));
    		
    		ComDefaultVO greToday = nidCmmService.searchGreToDay( searchVO );
    		model.addAttribute("greToday", greToday.getStartDay());
    		ComDefaultVO perToday = nidCmmService.searchPerToDay( searchVO );
    		model.addAttribute("perToday", perToday.getStartDay());
    			
    		//search information 
    		CrdFndVO crdFondInfo = service.searchCrdFndInfr(vo);
	 		if( crdFondInfo == null ){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstEnid.msg") );
    	
	 		}else{
	 			
	 			//check Card Issue History
	    		int cnt = service.searchCrdIssuedCn(vo);
	    		if(cnt <= 0){
	    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nCrdIsuceHst.msg")); // Message Setting
	    			return "/rm/crd/CrdFndIns";
	    		}
	 			
	 			// check card Issue status
	 			String isIsuce = "";
	 			int cardStatusCn = service.searchCrdIsuceStusCn(crdFondInfo.getRsdtNo());
	 			if(cardStatusCn > 0 ){
	 				isIsuce = "Y";
	 			}else{
	 				isIsuce = "N";
	 			}
	 			
	 			model.addAttribute("isIsuce", isIsuce);	
	 			model.addAttribute("crdFondInfo", crdFondInfo);	
	 		}	
	 		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/crd/CrdFndIns";
    	
    }
    
    /**
     * insert Card Found information. <br>
     * 
     * @param CrdFndVO Value-object of Card Found information to be parsed request(CrdFndVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CardFndIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/addCrdFndInfr.do")
    public String addCrdFndInfr(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndVO") CrdFndVO vo,
    		ModelMap model)
            throws Exception {    	
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		vo.setUseLangCd(user.getUseLangCd());	
    		vo.setFstRgstUserId(user.getUserId());
    		vo.setLstUdtUserId(user.getUserId());   		
    		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm()); 
    		vo.setFondDd(NidStringUtil.toNumberConvet(vo.getFondDd(), "g"));
    		vo.setPrntCrdIsuceSrlNo(NidStringUtil.toNumberConvet(vo.getPrntCrdIsuceSrlNo(), "g"));
    		
    		CrdFndVO resultVo = service.addCrdFndInfr(vo);

			String ccmResult = service.addCrdFndInfrPkiIf(resultVo);
			
    		if(!"1".equals(ccmResult)){
    			String helpTelNo = nidMessageSource.getMessage("admTelNo");
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("pki.websrvcEror.msg", new String[]{ccmResult, helpTelNo}));
    		} else {
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}
    		
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));   			
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "forward:/rm/crd/searchCrdFndInfrView.do";
    }

    
 	/**
     * Moved to list-screen of Card Found List. <br>
     *
     * @param CrdFndVO Value-object of resident to be parsed request(CrdFndVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/crd/CrdFndAprvList.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchListCrdFndView.do")
    public String searchListCrdFndView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndVO") CrdFndVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(),vo.getCurMnId());

    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("26"); 
    		List<CmCmmCdVO> cfmYn = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);    		
    		model.addAttribute("cfmYn", cfmYn);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/crd/CrdFndAprvList";
    	
    }
    
    /**
     * Retrieves list of program.  <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param CrdFndVO Value-object of program to be parsed request(CrdFndVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crd/CrdFndAprvList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchListCrdFndAprv.do")
    public String searchListCrdFndAprv (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndVO") CrdFndVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
    		vo.setUseLangCd(user.getUseLangCd());   		
    		vo.setUserId( user.getUserId() );
    		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());   		

    		if("".equals(searchVO.getSearchKeyword6())){
        		searchVO.setSearchKeyword6("j");    			
    		}
    		
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));

	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());

			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
			List<EgovMap> lstProgram = service.searchListCrdFndAprv(vo);			
			model.addAttribute("lstProgram", lstProgram);	
			
			int totCnt = service.searchListCrdFndAprvTotCn(vo);			
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);	
	            
	        CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("26"); 
    		List<CmCmmCdVO> cfmYn = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("cfmYn", cfmYn);
   		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/crd/CrdFndAprvList";   		
    }
	
 	/**
     * Moved to list-screen of Card Found approval. <br>
     *
     * @param CrdFndVO Value-object of resident to be parsed request(CrdFndVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/crd/CrdFndAprvUdt.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchCrdFndDtlAprv.do")
    public String searchCrdFndDtlAprv(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndVO") CrdFndVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("userId", user.getUserId());
    		vo.setUseLangCd(user.getUseLangCd());
    		String orgnzCd = user.getOrgnzCd();
    		String orgnzCls = user.getOrgnzClsCd();
    		vo.setRgstOrgnzCd(orgnzCd+orgnzCls);
    		int adultAge = propertiesService.getInt("adultAge");
	    	vo.setAdultAge(String.valueOf(adultAge));
    		
    		CrdFndVO resultVO = service.searchCrdFndDtlAprv(vo);
    		model.addAttribute("CrdFndDtlInfr", resultVO);
    		
 			// check card Issue status
 			String isIsuce = "";
 			int cardStatusCn = service.searchCrdIsuceStusCn(resultVO.getRsdtNo());
 			if(cardStatusCn > 0 ){
 				isIsuce = "Y";
 			}else{
 				isIsuce = "N";
 			}
 			model.addAttribute("isIsuce", isIsuce);	
 			
 			// Common Code Interface Call
 			CmCmmCdVO cmCmmCd = new CmCmmCdVO();	
    		cmCmmCd.setGrpCd("47");
    		List<CmCmmCdVO> prcssStus = cmmCdMngService.searchListCmmCd(cmCmmCd, false, "desc");
    		model.addAttribute("prcssStus", prcssStus);
    		
    		ComDefaultVO greToday = nidCmmService.searchGreToDay( searchVO );
    		model.addAttribute("greToday", greToday.getStartDay());
    		ComDefaultVO perToday = nidCmmService.searchPerToDay( searchVO );
    		model.addAttribute("perToday", perToday.getStartDay());
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/crd/CrdFndAprvUdt";
    	
    }

    /**
     * modify Printed Card Sequence No. <br>
     * 
     * @param CrdFndVO Value-object of Card Found information to be parsed request(CrdFndVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdFndAprvUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/modifyPrntCrdSrlNo.do")
    public String modifyPrntCrdSrlNo(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndVO") CrdFndVO vo,
    		ModelMap model)
            throws Exception {    	
    	try {
    		 
    		vo.setPrntCrdIsuceSrlNo(NidStringUtil.toNumberConvet(vo.getPrntCrdIsuceSrlNo(), "g"));
    		service.modifyPrntCrdSrlNo(vo);
    		    			
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("rqstCpltdScsfl.msg"));    			
    		

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "forward:/rm/crd/searchCrdFndDtlAprv.do";
    } 
    
    /**
     * modify Card Found information. <br>
     * 
     * @param CrdFndVO Value-object of Card Found information to be parsed request(CrdFndVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdFndAprvUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/modifyCrdFndDtlAprv.do")
    public String modifyCrdFndDtlAprv(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndVO") CrdFndVO vo,
    		ModelMap model)
            throws Exception {    	
    	try {
    		 
    		
    		service.modifyCrdFndDtlAprv( vo );
    		    			
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));    			
    		

    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "forward:/rm/crd/searchCrdFndDtlAprv.do";
    } 
    
    /**
     * Approve Card Found information. <br>
     * 
     * @param CrdFndVO Value-object of Card Found information to be parsed request(CrdFndVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdFndAprvList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/ApproveCrdFndInfr.do")
    public String ApproveCrdFndInfr(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdFndVO") CrdFndVO vo,
    		ModelMap model)
            throws Exception {    	
    	try {
    		
    		String lgSeqNo = service.approveCrdFndInfr(vo);
    		vo.setLgSeqNo(lgSeqNo);
    		
    		if(!"".equals(lgSeqNo)){
    			String ccmResult = service.approveCrdFndInfrPkiIf(vo);
    			
        		if(!"0".equals(ccmResult)){
        			String helpTelNo = nidMessageSource.getMessage("admTelNo");
        			model.addAttribute("resultMsg", nidMessageSource.getMessage("websrvcEror.msg", new String[]{ccmResult, helpTelNo}));
        		} else {
        			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
        		}
        		
    		} else {
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}
			
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "forward:/rm/crd/searchListCrdFndAprv.do";
    }     
}
