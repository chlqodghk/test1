package afnid.rm.crd.web;

/* java API */
import java.util.List;
import java.io.OutputStream;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.error.ErrorHandler;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.crd.service.CrdNewIsuceCddService;
import afnid.rm.crd.service.CrdNewIsuceCddVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;

/** 
 * This Controller class processes request of eNID Card New Issuance Candidate List and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Team Moon Soo Kim
 * @since 2013.06.10
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           				Revisions
 *   2013.06.10  		Moon Soo Kim                          Create
 *
 * </pre>
 */

@Controller
public class CrdNewIsuceCddController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** NidProgrmManageService */
	@Resource(name = "crdNewIsuceCddService")
    private CrdNewIsuceCddService service;
	
    /** CmmCdMngServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
	/** LgService */
	@Resource(name = "lgService")
	private LgService lgService;
	
	/** NidCommonService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCmmService;	
	
 	/**
     * Moved to list-screen of Card New Issuance Candidate List. <br>
     *
     * @param crdNewIsuCddVO Value-object of resident to be parsed request(CrdNewIsuceCddVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/crd/CrdNewIsuceCddList.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/crd/searchListCrdNewIsuceCddView.do")
    public String searchListCrdNewIsuceCddView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdNewIsuCddVO") CrdNewIsuceCddVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
			
    		searchVO.setSearchKeyword2("j");
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("10"); 
    		List<CmCmmCdVO> gdrCd = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		
    		cmCmmCd.setGrpCd("70"); 
    		List<CmCmmCdVO> bioRgstStusCd = cmmCdMngService.searchListCmmCd(cmCmmCd, false, "");     		
    		model.addAttribute("bioRgstStusCd", bioRgstStusCd);
    		
			ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCmmService.searchGreToDay(vo);
    		searchVO.setSearchKeyword2(comVo.getStartDay().replaceAll("-", ""));
    		comVo = nidCmmService.searchGreBfAfMonDay("-1");    		
    		searchVO.setSearchKeyword(comVo.getStartDay().replaceAll("-", ""));

    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
        return "/rm/crd/CrdNewIsuceCddList";
    	
    }

    /**
     * Retrieves list of program.  <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param crdNewIsuCddVO Value-object of program to be parsed request(CrdNewIsuceCddVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crd/CrdNewIsuceCddList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchListCrdNewIsuceCdd.do")
    public String searchListCrdNewIsuceCdd (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdNewIsuCddVO") CrdNewIsuceCddVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    		
    		String orgnzCls = user.getOrgnzClsCd();
    		String orgnzCd = user.getOrgnzCd();			  
    		String teamCd  = user.getTamCdNm();			
    		
    		vo.setOfficerNo(orgnzCls + orgnzCd + teamCd);
   		    		
    		if("".equals(searchVO.getSearchKeyword6())){
        		searchVO.setSearchKeyword6("j");    			
    		}
    		
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));

	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());

			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

			List<EgovMap> lstProgram = service.searchListCrdNewIsuceCdd(vo);			
			model.addAttribute("lstProgram", lstProgram);

			int totCnt = service.searchListCrdNewIsuceCddTotCn(vo);			
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
  		
	        CmCmmCdVO cmCmmCd = new CmCmmCdVO();// 공통코드 Value Object 생성
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdMngService.searchListCmmCdDesc(cmCmmCd); // Common Code 조회 Interface Call    		
    		model.addAttribute("gdrCd", gdrCd);//성별코드
    		cmCmmCd.setGrpCd("70"); 
    		List<CmCmmCdVO> bioRgstStusCd = cmmCdMngService.searchListCmmCd(cmCmmCd, false, "");     		
    		model.addAttribute("bioRgstStusCd", bioRgstStusCd);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new ErrorHandler(e).getLoadMessage());
    	}
   		return "/rm/crd/CrdNewIsuceCddList";   		
    }    

    /**
     * Download Card New Issuance Candidate List to Excel. <br>
     * 
     * @param crdNewIsuCddVO Value-object of Card New Issuance Candidate List to be parsed request(CrdNewIsuceCddVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out : ""
     * @exception Exception
     */						
    @RequestMapping(value="/rm/crd/searchListCrdNewIsuceCddExcel.do")
    public void searchListCrdNewIsuceCddExcel(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("crdNewIsuCddVO") CrdNewIsuceCddVO vo,
    		HttpServletResponse response,
			ModelMap model)
            throws Exception {

		OutputStream os = null;
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		HSSFRow row = null;
		HSSFRow row1 = null;
		HSSFRow row2 = null;
		HSSFCell cell = null;
		
    	try {

    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		vo.setUseLangCd(user.getUseLangCd());
    		String orgnzCls = user.getOrgnzClsCd();
    		String orgnzCd  = user.getOrgnzCd();			  
    		String teamCd   = user.getTamCdNm();			
    		
    		vo.setOfficerNo(orgnzCls + orgnzCd + teamCd);

    		String stsTitle = nidMessageSource.getMessage("icpltCtznList");

    		workbook = new HSSFWorkbook();
    		sheet = workbook.createSheet("sheet1");
    		
    		sheet.setColumnWidth(0, 15 * 256);
    		sheet.setColumnWidth(1, 25 * 256);
    		sheet.setColumnWidth(2, 10 * 256);
    		sheet.setColumnWidth(3, 14 * 256);    		
    		sheet.setColumnWidth(4, 25 * 256);
    		sheet.setColumnWidth(5, 40 * 256);
    		sheet.setColumnWidth(6, 10 * 256);
    		sheet.setColumnWidth(7, 10 * 256);
    		sheet.setColumnWidth(8, 14 * 256);

    		row = sheet.createRow((short)0);
    		row.setHeightInPoints(25);
    		
    		sheet.addMergedRegion(new CellRangeAddress(0,0, 0, 5) );
    		cell = row.createCell(0);    		
    		cell.setCellStyle(getTitleStyle(workbook));
    		cell.setCellValue(stsTitle); 
    		
    		row1 = sheet.createRow((short)1);
    		row1.setHeightInPoints(18);
    		row2 = sheet.createRow((short)2);
    		row2.setHeightInPoints(18);

    		//title : enrollment date
			cell = row1.createCell(0);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("fmlyfomNo")); 
			
			cell = row1.createCell(1);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("nm"));
			
			cell = row1.createCell(2);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("gdr"));
			
			cell = row1.createCell(3);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("bthDd"));
			
			cell = row1.createCell(4);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("fthrNm"));
			

			cell = row1.createCell(5);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("prsntAd"));
			
			
			cell = row1.createCell(6);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("indiFomErold"));
			
			cell = row1.createCell(7);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("bioCapt"));

			cell = row1.createCell(8);   
			cell.setCellStyle(getColumTitleStyle(workbook, true, true));
			cell.setCellValue(nidMessageSource.getMessage("cntTelNo"));
			
    		int totCnt = service.searchListCrdNewIsuceCddTotCn(vo);
    		
    		int totPage = (int)Math.ceil((double)totCnt/1000); 
    		

    		//DATA Display
    		for(int j=0; j<totPage; j++){
    			vo.setFirstIndex(j*1000);
    			vo.setLastIndex(j+1);    			
    			vo.setRecordCountPerPage(1000);    			
    			
    			List<CrdNewIsuceCddVO> lstProgram = service.searchListCrdNewIsuceCddExcel(vo);
    			
	    		for(int k=0; k<lstProgram.size(); k++){
	    			
	    			CrdNewIsuceCddVO rowData = lstProgram.get(k);
	    			row = sheet.createRow(k+2);	  
	    			
	    		    cell  = row.createCell(0);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, false));
	    		    cell.setCellValue(rowData.getFmlyBokNoDp());
	    				    		   
	    		    cell  = row.createCell(1);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, true));
	    		    cell.setCellValue(rowData.getNm());
	    		    
	    		    cell  = row.createCell(2);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, true));
	    		    cell.setCellValue(rowData.getGdrCdNm());
	    		    
	    		    cell  = row.createCell(3);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, false));
	    		    cell.setCellValue(rowData.getBthDd());
	    		    
	    		    cell  = row.createCell(4);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, true));
	    		    cell.setCellValue(rowData.getFthrNm());
	    		    
	    		    cell  = row.createCell(5);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, true));
	    		    
	    		    String curtDtlCt ="";
	    		    if(rowData.getCurtAdDtlCt()!= null && !"".equals(rowData.getCurtAdDtlCt()) ){
	    		    	curtDtlCt = rowData.getCurtAdDtlCt() + "/"  ;
	    		    } 
	
	    		    cell.setCellValue(curtDtlCt + rowData.getCurtAdCdNm() );
	    		    
	    		    cell  = row.createCell(6);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, true));
	    		    cell.setCellValue(rowData.getRsdtRgstYn());
	    		    
	    		    cell  = row.createCell(7);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, true));
	    		    cell.setCellValue(rowData.getBioCdNm());
	    		    
	    		    cell  = row.createCell(8);	
	    		    cell.setCellStyle(getColumDataStyle(workbook, vo.getUseLangCd(), false, false, true));
	    		    cell.setCellValue(rowData.getCntTelNo());	    		    
	    		    
	    		}
    			
	    		lstProgram.clear();  
    		}

    		os = response.getOutputStream();
    		
    		String fileDate = "";
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		
    		if("j".equals(vo.getSearchKeyword6())){
    			comVo = nidCmmService.searchPerToDay(comVo);
    			fileDate = NidStringUtil.toNumberConvet(comVo.getStartDay(), "g");
    		} else {
    			comVo = nidCmmService.searchGreToDay(comVo);
    			fileDate = comVo.getStartDay();
    		}
    		
    		response.setHeader("Content-Disposition", "attachment; filename=" +fileDate+"_"+"Performace_By_User.xls");
    		workbook.write(os);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
    
    //Get Font
    public  HSSFFont getFont(HSSFWorkbook workbook, int fontSize, boolean isBold){
   	      HSSFFont font = null;
          font = workbook.createFont();
          font.setFontHeightInPoints((short)fontSize);
          if(isBold) font.setBoldweight(Font.BOLDWEIGHT_BOLD);
   	      font.setColor(HSSFColor.BLACK.index);
   	      return font; 
   }	    
    	 
    //Get Title Style
    public  HSSFCellStyle getTitleStyle(HSSFWorkbook workbook){
    	 HSSFCellStyle style = null;
    	 style = workbook.createCellStyle();
    	 style.setFont(getFont(workbook, 14, true));
    	 style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
    	 style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
    	 
    	 return style;
    }	
    
    //Get Column Title Style
    public  HSSFCellStyle getColumTitleStyle(HSSFWorkbook workbook,  boolean isBold, boolean isBG){
    	 HSSFCellStyle style = null;

    	 style = workbook.createCellStyle();

    	 style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
    	 style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
    	 
    	  if (isBG){
    		  style.setFillForegroundColor(HSSFColor.AQUA.index);
    		  style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    	  }
    	  
    	  style.setBorderBottom(CellStyle.BORDER_THIN);
    	  style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
    	  style.setBorderLeft(CellStyle.BORDER_THIN);
    	  style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
    	  style.setBorderRight(CellStyle.BORDER_THIN);
    	  style.setRightBorderColor(IndexedColors.BLACK.getIndex());
    	  style.setBorderTop(CellStyle.BORDER_THIN);
    	  style.setTopBorderColor(IndexedColors.BLACK.getIndex());
    	
    	 return style;
    }	    
    
	 
    //Get Colum Data Style
    public  HSSFCellStyle getColumDataStyle(HSSFWorkbook workbook,  String langType, boolean isBold, boolean isBG, boolean isNum){
    	HSSFCellStyle style = null;

    	style = workbook.createCellStyle();

    	style.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);		
	 
    	if(isNum){
    		style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
    	} else {
    		if ("3".equals(langType)) {
    			style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
    		} else {
    			style.setAlignment(HSSFCellStyle.ALIGN_RIGHT);
    		}
    	}
	 
    	if (isBG){
		  style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		  style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    	}
	  
	
    	style.setBorderBottom(CellStyle.BORDER_THIN);
    	style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
    	style.setBorderLeft(CellStyle.BORDER_THIN);
    	style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
    	style.setBorderRight(CellStyle.BORDER_THIN);
    	style.setRightBorderColor(IndexedColors.BLACK.getIndex());
    	style.setBorderTop(CellStyle.BORDER_THIN);
    	style.setTopBorderColor(IndexedColors.BLACK.getIndex());

	  return style;
    }	        
}
