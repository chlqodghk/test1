package afnid.rm.crd.web;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.crd.service.CrdIsuErrPrcService;
import afnid.rm.crd.service.CrdIsuErrPrcVO;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;



/** 
 * This Controller class processes request of Card Issuance Error Processing. <br>
 * 
 * @author Afghanistan National ID RM Application Team MS Kim
 * @since 2013.12.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           				  Revisions
 *   2013.12.17  		MS Kim         		                  Create
 *
 * </pre>
 */

@Controller
public class CrdIsuErrPrcController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** CrdDitbService */
	@Resource(name = "crdIsuErrPrcService")
    private CrdIsuErrPrcService crdIsuErrPrcService;
		
	/** LgService */
	@Resource(name = "lgService")
	private LgService lgService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
	
	/** nidCmmService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCmmService;
    
    /** CmmCdMngService */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	
    /**
     * Moved to screen of eNId Card Issuance Error List.  <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param crdDitbVO Value-object of program to be parsed request(CrdIsuErrPrcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/crd/CrdIsuErrList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchListCrdIsuErrInfrView.do")
    public String searchListCrdIsuErrInfrView (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdIsuErrPrcVO") CrdIsuErrPrcVO vo,
    		ModelMap model)
            throws Exception {
		try{
						
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());

			vo.setUseLangCd(user.getUseLangCd());

			ComDefaultVO comVo = new ComDefaultVO();
			vo.setAddDay("1");
    		comVo = nidCmmService.searchAddToDay1(vo);
    		comDefaultVO.setSearchKeyword(comVo.getStartDay().replaceAll("-", ""));
    		comDefaultVO.setSearchKeyword2(comVo.getEndDay().replaceAll("-", ""));
    		comDefaultVO.setSearchKeyword6("2");
    		
			CmCmmCdVO cmCmmCd = new CmCmmCdVO();

    		cmCmmCd.setGrpCd("26"); 
    		List<CmCmmCdVO> prcYn = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("prcYn", prcYn);
    		
    		
    		
    		cmCmmCd.setGrpCd("29"); 
    		cmCmmCd.setOrgnzClsCd(user.getOrgnzClsCd());

    		List<CmCmmCdVO> crdStus =crdIsuErrPrcService.searchListCrdStusCmmCd(cmCmmCd);     		
    		model.addAttribute("crdStus", crdStus);
    		
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/crd/CrdIsuErrList";
    }
	
	/**
     * Retrieves eNId Card Issuance Error List.  <br>
     * 
     * @param CrdIsuErrPrcVO Retrieves of eNId Card Issuance Error List(CrdIsuErrPrcVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdIsuErrList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/searchListCrdIsuErrInfr.do")
    public String searchListCrdIsuErrInfr (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdIsuErrPrcVO") CrdIsuErrPrcVO vo,
    		ModelMap model)
            throws Exception {
		
		try{
			List<CrdIsuErrPrcVO> lstCrdIsuErr = null;
    		int totCnt = 0;	
    		int erorCnt =0;
    		
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			vo.setUseLangCd(user.getUseLangCd());
			vo.setOrgnzClsCd(user.getOrgnzClsCd());
			
			vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));

	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());
			
			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

			CmCmmCdVO cmCmmCd = new CmCmmCdVO();
			cmCmmCd.setGrpCd("29"); // Population Statistics Code Group Code
			cmCmmCd.setCmmCd(vo.getSearchKeyword4());
			CmCmmCdVO crdStusTle = cmmCdMngService.searchCmmCd(cmCmmCd); // Common Code 조회 Interface Call
			model.addAttribute("crdStusTle", crdStusTle);

    		cmCmmCd.setGrpCd("26"); 
    		List<CmCmmCdVO> prcYn = cmmCdMngService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("prcYn", prcYn);
    		
    		cmCmmCd.setGrpCd("29"); 
    		cmCmmCd.setOrgnzClsCd(user.getOrgnzClsCd());    		
    		List<CmCmmCdVO> crdStus = crdIsuErrPrcService.searchListCrdStusCmmCd(cmCmmCd);     		
    		model.addAttribute("crdStus", crdStus);

			if(!"1".equals(vo.getOrgnzClsCd())) {
				vo.setOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());
			}    
			
            if("".equals(vo.getSearchKeyword4())){//All
            	lstCrdIsuErr = crdIsuErrPrcService.searchListCrdIsuErr(vo);
            	model.addAttribute("lstCrdIsuErr",  lstCrdIsuErr); 
    	        totCnt = crdIsuErrPrcService.searchListCrdIsuErrTotCnt(vo);
    			paginationInfo.setTotalRecordCount(totCnt);            	
            } else if("2".equals(vo.getSearchKeyword4())){// File Error
            	lstCrdIsuErr = crdIsuErrPrcService.searchListCrdIsuErrFle(vo);
            	model.addAttribute("lstCrdIsuErr",  lstCrdIsuErr); 
    	        totCnt = crdIsuErrPrcService.searchListCrdIsuErrFleTotCnt(vo);
    			paginationInfo.setTotalRecordCount(totCnt);            	
            } else if("3".equals(vo.getSearchKeyword4())){// Signature Error
            	lstCrdIsuErr = crdIsuErrPrcService.searchListCrdIsuErrSgnt(vo);
            	model.addAttribute("lstCrdIsuErr",  lstCrdIsuErr);
    	        totCnt = crdIsuErrPrcService.searchListCrdIsuErrSgntTotCnt(vo);
    			paginationInfo.setTotalRecordCount(totCnt);             	
            } else if("4".equals(vo.getSearchKeyword4()) || "5".equals(vo.getSearchKeyword4()) || 
            		  "6".equals(vo.getSearchKeyword4()) || "7".equals(vo.getSearchKeyword4())){//PKI Error before CMS Import, Error after CMS Import , Citizen information Error, Print Error
            	
            	if( "5".equals(vo.getSearchKeyword4()) ){
            		vo.setSearchKeyword6("X");
            	}
            	
            	lstCrdIsuErr = crdIsuErrPrcService.searchListCrdIsuErrPkiRsdtInfrPrnt(vo); 
            	model.addAttribute("lstCrdIsuErr",  lstCrdIsuErr);
    	        totCnt = crdIsuErrPrcService.searchListCrdIsuErrPkiRsdtInfrPrntTotCnt(vo);
    			paginationInfo.setTotalRecordCount(totCnt);  
            } else if("8".equals(vo.getSearchKeyword4()) )  {//CMS Exception
            	lstCrdIsuErr = crdIsuErrPrcService.searchListCrdIsuErrCmsEcpt(vo); 
            	model.addAttribute("lstCrdIsuErr",  lstCrdIsuErr);
    	        totCnt = crdIsuErrPrcService.searchListCrdIsuErrCmsEcptTotCnt(vo);
    			paginationInfo.setTotalRecordCount(totCnt);               	
            } else if("9".equals(vo.getSearchKeyword4()) || "10".equals(vo.getSearchKeyword4())) {//CMS Feedback File Error, DPP Feedback File Error)
            	lstCrdIsuErr = crdIsuErrPrcService.searchListCrdIsuErrCmsFeedback(vo); 
            	model.addAttribute("lstCrdIsuErr",  lstCrdIsuErr);
    	        totCnt = crdIsuErrPrcService.searchListCrdIsuErrCmsFeedbackTotCnt(vo);
    			paginationInfo.setTotalRecordCount(totCnt);             	
            }
            
            int cnt = lstCrdIsuErr.size();
            CrdIsuErrPrcVO lst = new CrdIsuErrPrcVO();
            
            for(int i=0; i<cnt; i++ ){
            	lst = lstCrdIsuErr.get(i);
            	
            	if("3".equals(lst.getCrdIsuStusCd()) || "4".equals(lst.getCrdIsuStusCd())|| 
            	   "6".equals(lst.getCrdIsuStusCd()) || "7".equals(lst.getCrdIsuStusCd())||
            	   "8".equals(lst.getCrdIsuStusCd())){
            		
            		if("N".equals(lst.getErorPrcssYn())){
            			 erorCnt = 1;
            			 break;
            		}
            	}

            }
            
			log.debug("=======================================================");
			log.debug("erorCnt: " + erorCnt);
			log.debug("=======================================================");
			
			model.addAttribute("paginationInfo", paginationInfo);
			model.addAttribute("erorCnt", erorCnt);
			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
		
   		return "/rm/crd/CrdIsuErrList";
    }

	/**
     * card Issuance error processing(CMS Exception Clear)<br>
     * 
     * @param crdDitbVO Value-object for card Issuance error processing(CrdIsuErrPrcVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdIsuErrList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/modifyCrdIsuErrRpotdCrtn.do")
    public String modifyCrdIsuErrRpotdCrtn (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdIsuErrPrcVO") CrdIsuErrPrcVO vo,
    		ModelMap model)
            throws Exception {
		
		try{            
			crdIsuErrPrcService.modifyCrdIsuErrRpotdCrtn(vo);    		
			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));    		
    	}
   		return "forward:/rm/crd/searchListCrdIsuErrInfr.do";
    }
	
	/**
     * card Issuance error processing  <br>
     * 
     * @param CrdIsuErrPrcVO Value-object for card Issuance error processing(CrdIsuErrPrcVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdIsuErrList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/modifyCrdIsuErrLca.do")
    public String modifyCrdIsuErrLca (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdIsuErrPrcVO") CrdIsuErrPrcVO vo,
    		ModelMap model)
            throws Exception {
		
		try{            
			crdIsuErrPrcService.modifyCrdIsuErrLca(vo);    		
			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));    		
    	}
   		return "forward:/rm/crd/searchListCrdIsuErrInfr.do";
    }	
	
	/**
     * card Issuance error processing  <br>
     * 
     * @param CrdIsuErrPrcVO Value-object for card Issuance error processing(CrdIsuErrPrcVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/crd/CrdIsuErrList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/crd/modifyCrdIsuErrRetry.do")
    public String modifyCrdIsuErrRetry (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("crdIsuErrPrcVO") CrdIsuErrPrcVO vo,
    		ModelMap model)
            throws Exception {
		
		try{            
			crdIsuErrPrcService.modifyCrdIsuErrRetry(vo);    		
			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
			
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));    		
    	}
   		return "forward:/rm/crd/searchListCrdIsuErrInfr.do";
    }
	
	
	
	
}