package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.rm.crd.service.CrdNewIsuceCddVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;



/** 
 * This class is Database Access Object of eNID Card New Issuance Candidate List
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.06.10`
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.06.10  		Moon Soo Kim                          Create
 *
 * </pre>
 */
@Repository("crdNewIsuceCddDAO")
public class CrdNewIsuceCddDAO extends EgovAbstractDAO {
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }

	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(CrdNewIsuceCddVO).
	 * @return List<EgovMap> Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListCrdNewIsuceCdd(CrdNewIsuceCddVO vo) throws Exception{
		return list("crdNewIsuceCddDAO.selectListCrdNewIsuceCdd", vo);
	}

	/**
	 * DAO-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdNewIsuceCddVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListCrdNewIsuceCddTotCn(CrdNewIsuceCddVO vo) {
        return (Integer)selectByPk("crdNewIsuceCddDAO.selectListCrdNewIsuceCddTotCn", vo);
    }
	/**
	 * DAO-method for retrieving convert New Issuance Criteria date for search list as calendar type. <br>
	 *
	 * @param vo Input item for retrieving convert New Issuance Criteria date for search list as calendar type.(CrdNewIsuceCddVO).
	 * @return String converted date
	 * @exception Exception
	 */  
    public String selectDdCvt(CrdNewIsuceCddVO vo) {
        return (String)selectByPk("crdNewIsuceCddDAO.selectDdCvt", vo);
    }
    
    /**
	 * DAO-method for Card New Issuance Candidate List to download Excel. <br>
	 * 
	 * @param vo Input item for retrieving Card New Issuance Candidate List(CrdNewIsuceCddVO).
	 * @return List<EgovMap> Retrieve list information of program
	 * @exception Exception
	 */    
    @SuppressWarnings("unchecked")
	public List<CrdNewIsuceCddVO> selectListCrdNewIsuceCddExcel(CrdNewIsuceCddVO vo) {
        return list("crdNewIsuceCddDAO.selectListCrdNewIsuceCddExcel", vo);
    }  
}
