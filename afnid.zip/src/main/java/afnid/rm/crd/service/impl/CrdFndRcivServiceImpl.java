package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.crd.service.CrdFndRcivService;
import afnid.rm.crd.service.CrdFndRcivVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;

/** 
 * This service class is biz-class of Found Card Receive
 * and implements CrdFndRcivService class.
 * 
 * @author Afghanistan National ID Card System Application Team Daesung Kim
 * @since 2013.11.18
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           	Revisions
 *   2013.11.18  		Daesung Kim         		Create
 *
 * </pre>
 */

@Service("crdFndRcivService")
public class CrdFndRcivServiceImpl extends AbstractServiceImpl implements CrdFndRcivService{
	/** crdFndDAO */
    @Resource(name="crdFndRcivDAO")
    private CrdFndRcivDAO dao;
    /**
   	 * Biz-method for retrieving information of found card receiving. <br>
   	 *
   	 * @param vo Input item for retrieving information for found card receiving(CrdFndRcivVO).
   	 * @return CrdFndRcivVO Retrieve information for found card receiving. 
   	 * @exception Exception
   	 */
   	public CrdFndRcivVO searchCrdFndRcivInfr(CrdFndRcivVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
		
		CrdFndRcivVO crdMoveInfr = null;
		
		List<CrdFndRcivVO> crdMoveList= dao.selectCrdFndRcivInfr(vo);
		
		if(1 == crdMoveList.size() ){
			crdMoveInfr = crdMoveList.get(0);
		}else if(1 < crdMoveList.size()){
			crdMoveInfr = new CrdFndRcivVO();
			crdMoveInfr.setCallPopupYn("Y");
			crdMoveInfr.setRsdtNo(vo.getSearchKeyword());
		}
   		
   		return crdMoveInfr;
   	}
   	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CrdFndRcivVO).
   	 * @return List<CrdFndRcivVO> Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<CrdFndRcivVO> searchListCrdFndRcivInfr(CrdFndRcivVO vo) throws Exception {
      	
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		vo.setOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
		
		List<CrdFndRcivVO> crdMoveList = dao.selectListCrdFndRcivInfr(vo);
		
   		return crdMoveList;
   	}
   	
   	/**
	 * Biz-method for registering information of found card receiving. <br>
	 * 
	 * @param vo Input item for retrieving list of program(CrdFndRcivVO).
	 * @return 
	 * @exception Exception
	 */
	public void addCrdFndRcivInfr(CrdFndRcivVO vo) throws Exception {   	
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setRcivRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
		
		boolean result = dao.updateCrdFndRcivInfr(vo);
		
		if(!result){
			throw processException( "udtFail.msg");
		} 
		
	}
	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CrdFndRcivVO).
   	 * @return List<CrdFndRcivVO> Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<CrdFndRcivVO> searchListCrdFndRcivAprv(CrdFndRcivVO vo) throws Exception {
      		return dao.selectListCrdFndRcivAprv(vo);
   	}
   	
    /**
	 * Biz-method for retrieving total count of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdFndRcivVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
   	public int searchListCrdFndRcivAprvTotCn(CrdFndRcivVO vo) throws Exception {
        return dao.selectListCrdFndRcivAprvTotCn(vo);
	}
   	/**
   	 * Biz-method for retrieving detail information of found card receiving. <br>
   	 *
   	 * @param vo Input item for retrieving detail information of found card receiving(CrdFndRcivVO).
   	 * @return CrdFndRcivVO Retrieve detail information of found card receiving.
   	 * @exception Exception
   	 */
   	public CrdFndRcivVO searchCrdFndRcivDtlAprv(CrdFndRcivVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setRcivOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
   		return dao.selectCrdFndRcivDtlAprv(vo);
   	}
  	
	/**
	 * Biz-method for approval information of program. <br>
	 *
	 * @param vo Input item for approval information of program(CrdFndRcivVO).
	 * @return
	 * @exception Exception
	 */
   	public void approveCrdFndRcivInfr(CrdFndRcivVO  vo) throws Exception {
   		
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
		vo.setRcivCfmTamLedrId(user.getUserId());
		
		vo.setOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());

		if((vo.getDsuseCrdRsnCd() != null) && (!"".equals(vo.getDsuseCrdRsnCd()))){
			vo.setDsuseCrdRsnCt("");
			vo.setMnSeqNo("57");
		}
		
   		boolean result = dao.mergeCrdFndRcivInfr(vo);
   		
   		if(!result){
			throw processException( "udtFail.msg");
		} 

   	}
}
