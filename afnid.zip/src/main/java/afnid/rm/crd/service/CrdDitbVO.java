package afnid.rm.crd.service;

import java.util.List;

import afnid.cm.ComDefaultVO;

public class CrdDitbVO extends ComDefaultVO {


	private static final long serialVersionUID = 1L;
	
	private String crdDsuseRsnCd;
	private String crdDsuseRsnCt;
	private String mnSeqNo;
	private String rsdtSeqNo;
	private String userId;
	private String fmlyBokNo;
	private String fmlyBokNoDp;
	private String rsdtNo;
	private String rsdtNoDp;
	private String fthrNm;
	private String rsdtNm;
	private String bthDd;
	private String bthPlceCd;
	private String bthPlceCdNm;
	private String gdrCd;
	private String gdrCdNm;
	private String pmntAdCd;
	private String pmntAdCdNm;
	private String pmntAdDtlCt;
	private String crdIsuceDd;
	private String crdExpiryDd;
	private String rsdtRgstId;
	private String rsdtRgstIdNm;
	private String crdIsucePlceCd;
	private String crdIsucePlceCdNm;
	private String rsdtRgstDd;
	private String rsdtStusCd;
	private String rsdtStusCdNm;
	private String idfcYn;
	private String fstRgstUserId;
	private String fstRgstUserIdNm;
	private String lstUdtUserId;
	private String fmlyHadYn;
	private String bthNatDiv;
	private String bthNatCd;
	private String bthNatCdNm;
	private String frgnBthCtyNm;
	private List<String> rsdtNoList;
	private List<String> rsdtSeqNoList;
	private List<String> ditbSeqList;
	private List<String> dsuseRsdtList;
	private List<String> dsuseDitbSeqList;
	private String crdDitbCd;
	private String crdDitbDd;
	private String crdDitbOrgnzCd;
	private String crdDitbOrgnzCdNm;
	private String crdDitbUserId;
	private String crdDitbUserIdNm;
	private String crdRcivRsdtNo;
	private String idfcDd;
	private String idfcUserId;
	private String idfcUserIdNm;
	private String sgntDat;
	private List<String> sgntList;
	private String bioKey;
	private String ersrCd;
	private String ersrCdNm;
	private String crdIsuceStusCd;
	private String crdIsuceStusCdNm;
	private String isuceStusFlag;
	private String rsdtStusFlag;
	private String crdDitbSeqNo;
	private String isAdult;
	private List<String> isAdultList;
	private String pageFlag;
	private String crdIsuceSrlNo;
	private String adultAge;
	private String isExp;
	private List<String> lgSeqNoList;
	private String lgSeqNo;
	private String tamLedrCfmYn;
	private String crdIsuSeqNo;
	private String fleNm;
	private String isuCnt;
	private String appFlag;
	private String crdIdfcBy;	
	private String crdArvlFailYn;
	private String fgpChkYn;
	private String idfcDsCt;
	
	public String getCrdArvlFailYn() {
		return crdArvlFailYn;
	}
	public void setCrdArvlFailYn(String crdArvlFailYn) {
		this.crdArvlFailYn = crdArvlFailYn;
	}
	public String getCrdIdfcBy() {
		return crdIdfcBy;
	}
	public void setCrdIdfcBy(String crdIdfcBy) {
		this.crdIdfcBy = crdIdfcBy;
	}
	public String getAppFlag() {
		return appFlag;
	}
	public void setAppFlag(String appFlag) {
		this.appFlag = appFlag;
	}
	public String getTamLedrCfmYn() {
		return tamLedrCfmYn;
	}
	public void setTamLedrCfmYn(String tamLedrCfmYn) {
		this.tamLedrCfmYn = tamLedrCfmYn;
	}
	public String getCrdIsuSeqNo() {
		return crdIsuSeqNo;
	}
	public void setCrdIsuSeqNo(String crdIsuSeqNo) {
		this.crdIsuSeqNo = crdIsuSeqNo;
	}
	public String getFleNm() {
		return fleNm;
	}
	public void setFleNm(String fleNm) {
		this.fleNm = fleNm;
	}
	public String getIsuCnt() {
		return isuCnt;
	}
	public void setIsuCnt(String isuCnt) {
		this.isuCnt = isuCnt;
	}
	public List<String> getSgntList() {
		return sgntList;
	}
	public void setSgntList(List<String> sgntList) {
		this.sgntList = sgntList;
	}
	public String getIsExp() {
		return isExp;
	}
	public void setIsExp(String isExp) {
		this.isExp = isExp;
	}
	public String getAdultAge() {
		return adultAge;
	}
	public void setAdultAge(String adultAge) {
		this.adultAge = adultAge;
	}
	public String getCrdIsuceSrlNo() {
		return crdIsuceSrlNo;
	}
	public void setCrdIsuceSrlNo(String crdIsuceSrlNo) {
		this.crdIsuceSrlNo = crdIsuceSrlNo;
	}
	public String getPageFlag() {
		return pageFlag;
	}
	public void setPageFlag(String pageFlag) {
		this.pageFlag = pageFlag;
	}
	public List<String> getDsuseDitbSeqList() {
		return dsuseDitbSeqList;
	}
	public void setDsuseDitbSeqList(List<String> dsuseDitbSeqList) {
		this.dsuseDitbSeqList = dsuseDitbSeqList;
	}
	public List<String> getIsAdultList() {
		return isAdultList;
	}
	public void setIsAdultList(List<String> isAdultList) {
		this.isAdultList = isAdultList;
	}
	public String getIsAdult() {
		return isAdult;
	}
	public void setIsAdult(String isAdult) {
		this.isAdult = isAdult;
	}
	public List<String> getDitbSeqList() {
		return ditbSeqList;
	}
	public void setDitbSeqList(List<String> ditbSeqList) {
		this.ditbSeqList = ditbSeqList;
	}
	public List<String> getDsuseRsdtList() {
		return dsuseRsdtList;
	}
	public void setDsuseRsdtList(List<String> dsuseRsdtList) {
		this.dsuseRsdtList = dsuseRsdtList;
	}
	public String getCrdDitbSeqNo() {
		return crdDitbSeqNo;
	}
	public void setCrdDitbSeqNo(String crdDitbSeqNo) {
		this.crdDitbSeqNo = crdDitbSeqNo;
	}
	public String getRsdtStusFlag() {
		return rsdtStusFlag;
	}
	public void setRsdtStusFlag(String rsdtStusFlag) {
		this.rsdtStusFlag = rsdtStusFlag;
	}

	public String getIsuceStusFlag() {
		return isuceStusFlag;
	}
	public void setIsuceStusFlag(String isuceStusFlag) {
		this.isuceStusFlag = isuceStusFlag;
	}
	public String getCrdIsuceStusCd() {
		return crdIsuceStusCd;
	}
	public void setCrdIsuceStusCd(String crdIsuceStusCd) {
		this.crdIsuceStusCd = crdIsuceStusCd;
	}
	public String getCrdIsuceStusCdNm() {
		return crdIsuceStusCdNm;
	}
	public void setCrdIsuceStusCdNm(String crdIsuceStusCdNm) {
		this.crdIsuceStusCdNm = crdIsuceStusCdNm;
	}
	public String getErsrCd() {
		return ersrCd;
	}
	public void setErsrCd(String ersrCd) {
		this.ersrCd = ersrCd;
	}
	public String getErsrCdNm() {
		return ersrCdNm;
	}
	public void setErsrCdNm(String ersrCdNm) {
		this.ersrCdNm = ersrCdNm;
	}
	public String getBioKey() {
		return bioKey;
	}
	public void setBioKey(String bioKey) {
		this.bioKey = bioKey;
	}
	public String getSgntDat() {
		return sgntDat;
	}
	public void setSgntDat(String sgntDat) {
		this.sgntDat = sgntDat;
	}
	public List<String> getRsdtSeqNoList() {
		return rsdtSeqNoList;
	}
	public void setRsdtSeqNoList(List<String> rsdtSeqNoList) {
		this.rsdtSeqNoList = rsdtSeqNoList;
	}
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getCrdDitbCd() {
		return crdDitbCd;
	}
	public void setCrdDitbCd(String crdDitbCd) {
		this.crdDitbCd = crdDitbCd;
	}
	public String getIdfcUserIdNm() {
		return idfcUserIdNm;
	}
	public void setIdfcUserIdNm(String idfcUserIdNm) {
		this.idfcUserIdNm = idfcUserIdNm;
	}
	public String getIdfcDd() {
		return idfcDd;
	}
	public void setIdfcDd(String idfcDd) {
		this.idfcDd = idfcDd;
	}
	public String getIdfcUserId() {
		return idfcUserId;
	}
	public void setIdfcUserId(String idfcUserId) {
		this.idfcUserId = idfcUserId;
	}
	public String getCrdRcivRsdtNo() {
		return crdRcivRsdtNo;
	}
	public void setCrdRcivRsdtNo(String crdRcivRsdtNo) {
		this.crdRcivRsdtNo = crdRcivRsdtNo;
	}
	public String getCrdDitbOrgnzCdNm() {
		return crdDitbOrgnzCdNm;
	}
	public void setCrdDitbOrgnzCdNm(String crdDitbOrgnzCdNm) {
		this.crdDitbOrgnzCdNm = crdDitbOrgnzCdNm;
	}
	public String getCrdDitbDd() {
		return crdDitbDd;
	}
	public void setCrdDitbDd(String crdDitbDd) {
		this.crdDitbDd = crdDitbDd;
	}
	public String getCrdDitbOrgnzCd() {
		return crdDitbOrgnzCd;
	}
	public void setCrdDitbOrgnzCd(String crdDitbOrgnzCd) {
		this.crdDitbOrgnzCd = crdDitbOrgnzCd;
	}
	public String getCrdDitbUserId() {
		return crdDitbUserId;
	}
	public void setCrdDitbUserId(String crdDitbUserId) {
		this.crdDitbUserId = crdDitbUserId;
	}
	public String getCrdDitbUserIdNm() {
		return crdDitbUserIdNm;
	}
	public void setCrdDitbUserIdNm(String crdDitbUserIdNm) {
		this.crdDitbUserIdNm = crdDitbUserIdNm;
	}
	public List<String> getRsdtNoList() {
		return rsdtNoList;
	}
	public void setRsdtNoList(List<String> rsdtNoList) {
		this.rsdtNoList = rsdtNoList;
	}
	public String getBthPlceCd() {
		return bthPlceCd;
	}
	public void setBthPlceCd(String bthPlceCd) {
		this.bthPlceCd = bthPlceCd;
	}
	public String getBthPlceCdNm() {
		return bthPlceCdNm;
	}
	public void setBthPlceCdNm(String bthPlceCdNm) {
		this.bthPlceCdNm = bthPlceCdNm;
	}
	public String getBthNatCdNm() {
		return bthNatCdNm;
	}
	public void setBthNatCdNm(String bthNatCdNm) {
		this.bthNatCdNm = bthNatCdNm;
	}
	public String getBthNatDiv() {
		return bthNatDiv;
	}
	public void setBthNatDiv(String bthNatDiv) {
		this.bthNatDiv = bthNatDiv;
	}
	public String getBthNatCd() {
		return bthNatCd;
	}
	public void setBthNatCd(String bthNatCd) {
		this.bthNatCd = bthNatCd;
	}
	public String getFrgnBthCtyNm() {
		return frgnBthCtyNm;
	}
	public void setFrgnBthCtyNm(String frgnBthCtyNm) {
		this.frgnBthCtyNm = frgnBthCtyNm;
	}
	public String getFmlyHadYn() {
		return fmlyHadYn;
	}
	public void setFmlyHadYn(String fmlyHadYn) {
		this.fmlyHadYn = fmlyHadYn;
	}
	public String getLstUdtUserId() {
		return lstUdtUserId;
	}
	public void setLstUdtUserId(String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFmlyBokNo() {
		return fmlyBokNo;
	}
	public void setFmlyBokNo(String fmlyBokNo) {
		this.fmlyBokNo = fmlyBokNo;
	}
	public String getFmlyBokNoDp() {
		return fmlyBokNoDp;
	}
	public void setFmlyBokNoDp(String fmlyBokNoDp) {
		this.fmlyBokNoDp = fmlyBokNoDp;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	public String getFthrNm() {
		return fthrNm;
	}
	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}
	public String getRsdtNm() {
		return rsdtNm;
	}
	public void setRsdtNm(String rsdtNm) {
		this.rsdtNm = rsdtNm;
	}
	public String getBthDd() {
		return bthDd;
	}
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	public String getGdrCd() {
		return gdrCd;
	}
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	public String getPmntAdCd() {
		return pmntAdCd;
	}
	public void setPmntAdCd(String pmntAdCd) {
		this.pmntAdCd = pmntAdCd;
	}
	public String getPmntAdCdNm() {
		return pmntAdCdNm;
	}
	public void setPmntAdCdNm(String pmntAdCdNm) {
		this.pmntAdCdNm = pmntAdCdNm;
	}
	public String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}
	public void setPmntAdDtlCt(String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}
	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}
	public String getFstRgstUserId() {
		return fstRgstUserId;
	}
	public void setFstRgstUserId(String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}
	public String getFstRgstUserIdNm() {
		return fstRgstUserIdNm;
	}
	public void setFstRgstUserIdNm(String fstRgstUserIdNm) {
		this.fstRgstUserIdNm = fstRgstUserIdNm;
	}
	public String getRsdtRgstId() {
		return rsdtRgstId;
	}
	public void setRsdtRgstId(String rsdtRgstId) {
		this.rsdtRgstId = rsdtRgstId;
	}
	public String getRsdtRgstIdNm() {
		return rsdtRgstIdNm;
	}
	public void setRsdtRgstIdNm(String rsdtRgstIdNm) {
		this.rsdtRgstIdNm = rsdtRgstIdNm;
	}
	public String getCrdIsucePlceCd() {
		return crdIsucePlceCd;
	}
	public void setCrdIsucePlceCd(String crdIsucePlceCd) {
		this.crdIsucePlceCd = crdIsucePlceCd;
	}
	public String getCrdIsucePlceCdNm() {
		return crdIsucePlceCdNm;
	}
	public void setCrdIsucePlceCdNm(String crdIsucePlceCdNm) {
		this.crdIsucePlceCdNm = crdIsucePlceCdNm;
	}
	public String getRsdtRgstDd() {
		return rsdtRgstDd;
	}
	public void setRsdtRgstDd(String rsdtRgstDd) {
		this.rsdtRgstDd = rsdtRgstDd;
	}
	public String getRsdtStusCd() {
		return rsdtStusCd;
	}
	public void setRsdtStusCd(String rsdtStusCd) {
		this.rsdtStusCd = rsdtStusCd;
	}
	public String getRsdtStusCdNm() {
		return rsdtStusCdNm;
	}
	public void setRsdtStusCdNm(String rsdtStusCdNm) {
		this.rsdtStusCdNm = rsdtStusCdNm;
	}
	public String getIdfcYn() {
		return idfcYn;
	}
	public void setIdfcYn(String idfcYn) {
		this.idfcYn = idfcYn;
	}
	public List<String> getLgSeqNoList() {
		return lgSeqNoList;
	}
	public void setLgSeqNoList(List<String> lgSeqNoList) {
		this.lgSeqNoList = lgSeqNoList;
	}
	public String getLgSeqNo() {
		return lgSeqNo;
	}
	public void setLgSeqNo(String lgSeqNo) {
		this.lgSeqNo = lgSeqNo;
	}
	public String getCrdDsuseRsnCd() {
		return crdDsuseRsnCd;
	}
	public void setCrdDsuseRsnCd(String crdDsuseRsnCd) {
		this.crdDsuseRsnCd = crdDsuseRsnCd;
	}
	public String getCrdDsuseRsnCt() {
		return crdDsuseRsnCt;
	}
	public void setCrdDsuseRsnCt(String crdDsuseRsnCt) {
		this.crdDsuseRsnCt = crdDsuseRsnCt;
	}
	public String getMnSeqNo() {
		return mnSeqNo;
	}
	public void setMnSeqNo(String mnSeqNo) {
		this.mnSeqNo = mnSeqNo;
	}
	public String getFgpChkYn() {
		return fgpChkYn;
	}
	public void setFgpChkYn(String fgpChkYn) {
		this.fgpChkYn = fgpChkYn;
	}
	public String getIdfcDsCt() {
		return idfcDsCt;
	}
	public void setIdfcDsCt(String idfcDsCt) {
		this.idfcDsCt = idfcDsCt;
	}

	
}
