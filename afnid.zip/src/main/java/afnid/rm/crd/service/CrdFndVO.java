package afnid.rm.crd.service;

import afnid.cm.ComDefaultVO;

public class CrdFndVO extends ComDefaultVO {
	
	private static final long serialVersionUID = 1L;
	
	//pk
	private String fondCrdSeqNo;
	//resident no
	private String rsdtNo;
	//resident number for screen display
	private String rsdtNoDp;
	//given name
	private String givNm;
	// surname
	private String surnm;
	//father name
	private String fthrNm;
	//grandfather name
	private String gfthrNm;
	//birthday
	private String bthDd;
	//gender code
	private String gdrCd;
	//gender code name
	private String gdrCdNm;
	//permanent address code
	private String pmntAdCd;
	//current address code
	private String curtAdCd;
	//1:active 2: deactive
	private String rsdtStusCd;
	//Citizen Status Code Name
	private String rsdtStusCdNm;
	// found date
	private String fondDd;
	private String hFndDd;
	private String gFndDd;
	//found place
	private String fondPlce;
	//crud mode
	private String crudMode;
	//organization code + team code
	private String officerNo;
	//organization code + team code
	private String rgstOrgnzCd;
	//organization name
	private String rgstOrgnzCdNm;
	//team leader confirm yn
	private String tamLedrCfmYn;
	//confirm team leader id
	private String cfmTamLedrId;
	//user id
	private String userId;
	//calendar type
	private String calTye;
	// card delivery
	private String crdDlvrCd;
	// card crdPrcssStusCd
	private String crdPrcssStusCd;
	//fondCrdStusCd
	private String fondCrdStusCd;
	//fstRgstUserId
	private String fstRgstUserId;
	//fstRgstDt
	private String fstRgstDt;
	//lstUdtUserId
	private String lstUdtUserId;
	//lstUdtDt
	private String lstUdtDt;
	//toDate
	private String toDate;
	//RSDT_SEQ_NO
	private String rsdtSeqNo;
	//sgnt Data
	private String sgntDat;
	//CRD_EXPIRY_DD Data
	private String crdExpiryDd;
	//AGE
	private String isAdult;
	//RCIV_ORGNZ_CD
	private String rcivOrgnzCd;
	//RCIV_ORGNZ_CD name
	private String rcivOrgnzCdNm;
	//SND_FOND_CRD_STUS_CD
	private String sndFondCrdStusCd;
	//IDFC_YN 
	private String idfcYn;
	//ERSR_CD 
	private String ersrCd;
	//ERSR_CD Name 
	private String ersrCdNm;
	// card crdPrcssStusCd Name
	private String crdPrcssStusCdNm;
	
	private String crdIsuceSrlNo;	
	private String crdIsuceDd;
	private String hCrdIsuceDd;
	private String gCrdIsuceDd;
	private String adultAge;
	private String rqstTye;
	private String cmsCrdIsuceSrlNo;
	private String cmsCrdIsuceDd;
	private String cmsWorkRsut;
	private String tamLedrCfmDd;
	private String chipCrdIsuceDd;
	private String chipCrdIsuceSrlNo;
	private String prntCrdIsuceSrlNo;
	private String lgSeqNo;
	private String rptSeqNo;
	private String maxSrlNo;
	
	private String dsuseCrdRsnCd;
	private String dsuseCrdRsnCt;
	private String mnSeqNo;
	
	public String getMaxSrlNo() {
		return maxSrlNo;
	}
	public void setMaxSrlNo(String maxSrlNo) {
		this.maxSrlNo = maxSrlNo;
	}
	public String getPrntCrdIsuceSrlNo() {
		return prntCrdIsuceSrlNo;
	}
	public void setPrntCrdIsuceSrlNo(String prntCrdIsuceSrlNo) {
		this.prntCrdIsuceSrlNo = prntCrdIsuceSrlNo;
	}
	public String getChipCrdIsuceDd() {
		return chipCrdIsuceDd;
	}
	public void setChipCrdIsuceDd(String chipCrdIsuceDd) {
		this.chipCrdIsuceDd = chipCrdIsuceDd;
	}
	public String getChipCrdIsuceSrlNo() {
		return chipCrdIsuceSrlNo;
	}
	public void setChipCrdIsuceSrlNo(String chipCrdIsuceSrlNo) {
		this.chipCrdIsuceSrlNo = chipCrdIsuceSrlNo;
	}
	public String getTamLedrCfmDd() {
		return tamLedrCfmDd;
	}
	public void setTamLedrCfmDd(String tamLedrCfmDd) {
		this.tamLedrCfmDd = tamLedrCfmDd;
	}
	public String getCmsWorkRsut() {
		return cmsWorkRsut;
	}
	public void setCmsWorkRsut(String cmsWorkRsut) {
		this.cmsWorkRsut = cmsWorkRsut;
	}
	public String getCmsCrdIsuceSrlNo() {
		return cmsCrdIsuceSrlNo;
	}
	public void setCmsCrdIsuceSrlNo(String cmsCrdIsuceSrlNo) {
		this.cmsCrdIsuceSrlNo = cmsCrdIsuceSrlNo;
	}
	public String getCmsCrdIsuceDd() {
		return cmsCrdIsuceDd;
	}
	public void setCmsCrdIsuceDd(String cmsCrdIsuceDd) {
		this.cmsCrdIsuceDd = cmsCrdIsuceDd;
	}
	public String getRqstTye() {
		return rqstTye;
	}
	public void setRqstTye(String rqstTye) {
		this.rqstTye = rqstTye;
	}
	public String getAdultAge() {
		return adultAge;
	}
	public void setAdultAge(String adultAge) {
		this.adultAge = adultAge;
	}
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public String gethCrdIsuceDd() {
		return hCrdIsuceDd;
	}
	public void sethCrdIsuceDd(String hCrdIsuceDd) {
		this.hCrdIsuceDd = hCrdIsuceDd;
	}
	public String getgCrdIsuceDd() {
		return gCrdIsuceDd;
	}
	public void setgCrdIsuceDd(String gCrdIsuceDd) {
		this.gCrdIsuceDd = gCrdIsuceDd;
	}
	public String getCrdIsuceSrlNo() {
		return crdIsuceSrlNo;
	}
	public void setCrdIsuceSrlNo(String crdIsuceSrlNo) {
		this.crdIsuceSrlNo = crdIsuceSrlNo;
	}	
	public String getCrdPrcssStusCdNm() {
		return crdPrcssStusCdNm;
	}
	public void setCrdPrcssStusCdNm(String crdPrcssStusCdNm) {
		this.crdPrcssStusCdNm = crdPrcssStusCdNm;
	}
	public String getErsrCd() {
		return ersrCd;
	}
	public void setErsrCd(String ersrCd) {
		this.ersrCd = ersrCd;
	}
	public String getErsrCdNm() {
		return ersrCdNm;
	}
	public void setErsrCdNm(String ersrCdNm) {
		this.ersrCdNm = ersrCdNm;
	}
	public String getRgstOrgnzCdNm() {
		return rgstOrgnzCdNm;
	}
	public void setRgstOrgnzCdNm(String rgstOrgnzCdNm) {
		this.rgstOrgnzCdNm = rgstOrgnzCdNm;
	}
	public String getRcivOrgnzCdNm() {
		return rcivOrgnzCdNm;
	}
	public void setRcivOrgnzCdNm(String rcivOrgnzCdNm) {
		this.rcivOrgnzCdNm = rcivOrgnzCdNm;
	}
	public String getRcivOrgnzCd() {
		return rcivOrgnzCd;
	}
	public void setRcivOrgnzCd(String rcivOrgnzCd) {
		this.rcivOrgnzCd = rcivOrgnzCd;
	}
	public String getSndFondCrdStusCd() {
		return sndFondCrdStusCd;
	}
	public void setSndFondCrdStusCd(String sndFondCrdStusCd) {
		this.sndFondCrdStusCd = sndFondCrdStusCd;
	}

	public String getIdfcYn() {
		return idfcYn;
	}
	public void setIdfcYn(String idfcYn) {
		this.idfcYn = idfcYn;
	}
	public String getIsAdult() {
		return isAdult;
	}
	public void setIsAdult(String isAdult) {
		this.isAdult = isAdult;
	}
	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}
	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}
	public String getSgntDat() {
		return sgntDat;
	}
	public void setSgntDat(String sgntDat) {
		this.sgntDat = sgntDat;
	}
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getRsdtStusCdNm() {
		return rsdtStusCdNm;
	}
	public void setRsdtStusCdNm(String rsdtStusCdNm) {
		this.rsdtStusCdNm = rsdtStusCdNm;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	/**
	*@return the fstRgstUserId
	*/
	
	public String getFstRgstUserId() {
		return fstRgstUserId;
	}
	public void setFstRgstUserId(String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}
	/**
	*@return the fstRgstDt
	*/
	public String getFstRgstDt() {
		return fstRgstDt;
	}
	public void setFstRgstDt(String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}
	/**
	*@return the lstUdtUserId
	*/
	public String getLstUdtUserId() {
		return lstUdtUserId;
	}
	
	public void setLstUdtUserId(String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}
	/**
	*@return the lstUdtDt
	*/
	public String getLstUdtDt() {
		return lstUdtDt;
	}
	public void setLstUdtDt(String lstUdtDt) {
		this.lstUdtDt = lstUdtDt;
	}
	/**
	*@return the fondCrdStusCd
	*/
	public String getFondCrdStusCd() {
		return fondCrdStusCd;
	}
	public void setFondCrdStusCd(String fondCrdStusCd) {
		this.fondCrdStusCd = fondCrdStusCd;
	}
	/**
	*@return the crdPrcssStusCd
	*/
	public String getCrdPrcssStusCd() {
		return crdPrcssStusCd;
	}
	public void setCrdPrcssStusCd(String crdPrcssStusCd) {
		this.crdPrcssStusCd = crdPrcssStusCd;
	}
	/**
	 * @return the fondCrdSeqNo
	 */
	
	public String getFondCrdSeqNo() {
		return fondCrdSeqNo;
	}
	public void setFondCrdSeqNo(String fondCrdSeqNo) {
		this.fondCrdSeqNo = fondCrdSeqNo;
	}
	/**
	 * @return the rsdtNo
	 */
	public String getRsdtNo() {
		return rsdtNo;
	}
	/**
	 * @param rsdtNo the rsdtNo to set
	 */
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	/**
	 * @return the givNm
	 */
	public String getGivNm() {
		return givNm;
	}
	/**
	 * @param givNm the givNm to set
	 */
	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}
	/**
	 * @return the surnm
	 */
	public String getSurnm() {
		return surnm;
	}
	/**
	 * @param surnm the surnm to set
	 */
	public void setSurnm(String surnm) {
		this.surnm = surnm;
	}
	/**
	 * @return the fthrGivNm
	 */
	
	/**
	 * @return the bthDd
	 */
	public String getBthDd() {
		return bthDd;
	}
	public String getFthrNm() {
		return fthrNm;
	}
	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}
	public String getGfthrNm() {
		return gfthrNm;
	}
	public void setGfthrNm(String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}
	/**
	 * @param bthDd the bthDd to set
	 */
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	/**
	 * @return the gdrCd
	 */
	public String getGdrCd() {
		return gdrCd;
	}
	/**
	 * @param gdrCd the gdrCd to set
	 */
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	/**
	 * @return the pmntAdCd
	 */
	public String getPmntAdCd() {
		return pmntAdCd;
	}
	/**
	 * @param pmntAdCd the pmntAdCd to set
	 */
	public void setPmntAdCd(String pmntAdCd) {
		this.pmntAdCd = pmntAdCd;
	}
	/**
	 * @return the curtAdCd
	 */
	public String getCurtAdCd() {
		return curtAdCd;
	}
	/**
	 * @param curtAdCd the curtAdCd to set
	 */
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	/**
	 * @return the rsdtStusCd
	 */
	public String getRsdtStusCd() {
		return rsdtStusCd;
	}
	/**
	 * @param rsdtStusCd the rsdtStusCd to set
	 */
	public void setRsdtStusCd(String rsdtStusCd) {
		this.rsdtStusCd = rsdtStusCd;
	}
	/**
	 * @return the fondDd
	 */
	public String getFondDd() {
		return fondDd;
	}
	/**
	 * @param fondDd the fondDd to set
	 */
	public void setFondDd(String fondDd) {
		this.fondDd = fondDd;
	}
	/**
	 * @return the fondPlce
	 */
	public String getFondPlce() {
		return fondPlce;
	}
	/**
	 * @param fondPlce the fondPlce to set
	 */
	public void setFondPlce(String fondPlce) {
		this.fondPlce = fondPlce;
	}
	/**
	 * @return the crudMode
	 */
	public String getCrudMode() {
		return crudMode;
	}
	/**
	 * @param crudMode the crudMode to set
	 */
	public void setCrudMode(String crudMode) {
		this.crudMode = crudMode;
	}
	/**
	 * @return the officerNo
	 */
	public String getOfficerNo() {
		return officerNo;
	}
	/**
	 * @param officerNo the officerNo to set
	 */
	public void setOfficerNo(String officerNo) {
		this.officerNo = officerNo;
	}
	/**
	 * @return the rgstOrgnzCd
	 */
	public String getRgstOrgnzCd() {
		return rgstOrgnzCd;
	}
	/**
	 * @param rgstOrgnzCd the rgstOrgnzCd to set
	 */
	public void setRgstOrgnzCd(String rgstOrgnzCd) {
		this.rgstOrgnzCd = rgstOrgnzCd;
	}
	/**
	 * @return the tamLedrCfmYn
	 */
	public String getTamLedrCfmYn() {
		return tamLedrCfmYn;
	}
	/**
	 * @param tamLedrCfmYn the tamLedrCfmYn to set
	 */
	public void setTamLedrCfmYn(String tamLedrCfmYn) {
		this.tamLedrCfmYn = tamLedrCfmYn;
	}
	/**
	 * @return the cfmTamLedrId
	 */
	public String getCfmTamLedrId() {
		return cfmTamLedrId;
	}
	/**
	 * @param cfmTamLedrId the cfmTamLedrId to set
	 */
	public void setCfmTamLedrId(String cfmTamLedrId) {
		this.cfmTamLedrId = cfmTamLedrId;
	}
	/**
	 * @return the gdrCdNm
	 */
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	/**
	 * @param gdrCdNm the gdrCdNm to set
	 */
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the rsdtNoDp
	 */
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	/**
	 * @param rsdtNoDp the rsdtNoDp to set
	 */
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	/**
	 * @return the calTye
	 */
	public String getCalTye() {
		return calTye;
	}
	/**
	 * @param calTye the calTye to set
	 */
	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}
	/**
	 * @return the crdDlvrCd
	 */
	public String getCrdDlvrCd() {
		return crdDlvrCd;
	}
	/**
	 * @param crdDlvrCd the crdDlvrCd to set
	 */
	public void setCrdDlvrCd(String crdDlvrCd) {
		this.crdDlvrCd = crdDlvrCd;
	}
	public String gethFndDd() {
		return hFndDd;
	}
	public void sethFndDd(String hFndDd) {
		this.hFndDd = hFndDd;
	}
	public String getgFndDd() {
		return gFndDd;
	}
	public void setgFndDd(String gFndDd) {
		this.gFndDd = gFndDd;
	}
	public String getLgSeqNo() {
		return lgSeqNo;
	}
	public void setLgSeqNo(String lgSeqNo) {
		this.lgSeqNo = lgSeqNo;
	}
	public String getRptSeqNo() {
		return rptSeqNo;
	}
	public void setRptSeqNo(String rptSeqNo) {
		this.rptSeqNo = rptSeqNo;
	}
	public String getDsuseCrdRsnCd() {
		return dsuseCrdRsnCd;
	}
	public void setDsuseCrdRsnCd(String dsuseCrdRsnCd) {
		this.dsuseCrdRsnCd = dsuseCrdRsnCd;
	}
	public String getDsuseCrdRsnCt() {
		return dsuseCrdRsnCt;
	}
	public void setDsuseCrdRsnCt(String dsuseCrdRsnCt) {
		this.dsuseCrdRsnCt = dsuseCrdRsnCt;
	}
	public String getMnSeqNo() {
		return mnSeqNo;
	}
	public void setMnSeqNo(String mnSeqNo) {
		this.mnSeqNo = mnSeqNo;
	}
	
	
}
