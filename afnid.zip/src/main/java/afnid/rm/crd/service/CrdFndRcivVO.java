package afnid.rm.crd.service;

import afnid.cm.ComDefaultVO;

public class CrdFndRcivVO extends ComDefaultVO {
	
	private static final long serialVersionUID = 1L;

	private String rsdtSeqNo;
	private String rsdtNo;
	private String rsdtNoDp;
	private String rsdtName;
	private String fthrNm;
	private String gfthrNm;
	private String bthDd;
	private String bthDdJ;
	private String bthDdG;
	private String gdrCd;
	private String gdrCdNm;
	private String pmntAdCd;
	private String pmntAdCdNm;
	private String pmntAdDtlCt;
	private String curtAdCd;
	private String curtAdCdNm;
	private String curtAdDtlCt;
	private String rsdtStusCd;
	private String rsdtStusCdNm;
	
	private String lstUdtUserId;
	private String fstRgstUserId;
	private String sndRgstUserId;
	private String rcivRgstUserId;
	private String fondCrdSeqNo;
	private String sndOrgnzCd;
	private String sndOrgnzCdNm;
	private String rcivOrgnzCd;
	private String rcivRgstDd;
	private String rcivTamLedrCfmYn;
	private String rcivCfmDd;
	private String rcivCfmTamLedrId;
	private String today;
	private String newCrdFondSeqNo;
	
	private String orgnzCd;
	private String orgnzCdNm;
	private String callPopupYn = "N";
	private String popFlag;
	private String fondDd;
	private String fondDdJ;
	private String fondDdG;
	private String sndFondCrdStusCd;
	private String sndFondCrdStusCdNm;
	private String ersrCd;
	private String ersrCdNm;
	private String crdIsuceDd;
	private String crdIsuceDdJ;
	private String crdIsuceDdG;
	private String crdIsuceSrlNo;
	private String crdExpiryDd;
	private String sndCfmDd;
	
	private String dsuseCrdRsnCd;
	private String dsuseCrdRsnCt;
	private String mnSeqNo;
	
	public String getSndCfmDd() {
		return sndCfmDd;
	}
	public void setSndCfmDd(String sndCfmDd) {
		this.sndCfmDd = sndCfmDd;
	}
	public String getErsrCd() {
		return ersrCd;
	}
	public void setErsrCd(String ersrCd) {
		this.ersrCd = ersrCd;
	}
	public String getErsrCdNm() {
		return ersrCdNm;
	}
	public void setErsrCdNm(String ersrCdNm) {
		this.ersrCdNm = ersrCdNm;
	}
	public String getSndFondCrdStusCdNm() {
		return sndFondCrdStusCdNm;
	}
	public void setSndFondCrdStusCdNm(String sndFondCrdStusCdNm) {
		this.sndFondCrdStusCdNm = sndFondCrdStusCdNm;
	}
	public String getSndFondCrdStusCd() {
		return sndFondCrdStusCd;
	}
	public void setSndFondCrdStusCd(String sndFondCrdStusCd) {
		this.sndFondCrdStusCd = sndFondCrdStusCd;
	}
	public String getFondDd() {
		return fondDd;
	}
	public void setFondDd(String fondDd) {
		this.fondDd = fondDd;
	}
	public String getCallPopupYn() {
		return callPopupYn;
	}
	public void setCallPopupYn(String callPopupYn) {
		this.callPopupYn = callPopupYn;
	}
	public String getPopFlag() {
		return popFlag;
	}
	public void setPopFlag(String popFlag) {
		this.popFlag = popFlag;
	}
	public String getNewCrdFondSeqNo() {
		return newCrdFondSeqNo;
	}
	public void setNewCrdFondSeqNo(String newCrdFondSeqNo) {
		this.newCrdFondSeqNo = newCrdFondSeqNo;
	}
	public String getRcivCfmTamLedrId() {
		return rcivCfmTamLedrId;
	}
	public void setRcivCfmTamLedrId(String rcivCfmTamLedrId) {
		this.rcivCfmTamLedrId = rcivCfmTamLedrId;
	}
	public String getRcivCfmDd() {
		return rcivCfmDd;
	}
	public void setRcivCfmDd(String rcivCfmDd) {
		this.rcivCfmDd = rcivCfmDd;
	}
	public String getRcivTamLedrCfmYn() {
		return rcivTamLedrCfmYn;
	}
	public void setRcivTamLedrCfmYn(String rcivTamLedrCfmYn) {
		this.rcivTamLedrCfmYn = rcivTamLedrCfmYn;
	}
	public String getRcivRgstUserId() {
		return rcivRgstUserId;
	}
	public void setRcivRgstUserId(String rcivRgstUserId) {
		this.rcivRgstUserId = rcivRgstUserId;
	}
	public String getSndOrgnzCdNm() {
		return sndOrgnzCdNm;
	}
	public void setSndOrgnzCdNm(String sndOrgnzCdNm) {
		this.sndOrgnzCdNm = sndOrgnzCdNm;
	}
	public String getRcivRgstDd() {
		return rcivRgstDd;
	}
	public void setRcivRgstDd(String rcivRgstDd) {
		this.rcivRgstDd = rcivRgstDd;
	}
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	public String getRsdtName() {
		return rsdtName;
	}
	public void setRsdtName(String rsdtName) {
		this.rsdtName = rsdtName;
	}
	public String getFthrNm() {
		return fthrNm;
	}
	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}
	public String getGfthrNm() {
		return gfthrNm;
	}
	public void setGfthrNm(String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}
	public String getBthDd() {
		return bthDd;
	}
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	public String getGdrCd() {
		return gdrCd;
	}
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	public String getPmntAdCd() {
		return pmntAdCd;
	}
	public void setPmntAdCd(String pmntAdCd) {
		this.pmntAdCd = pmntAdCd;
	}
	public String getPmntAdCdNm() {
		return pmntAdCdNm;
	}
	public void setPmntAdCdNm(String pmntAdCdNm) {
		this.pmntAdCdNm = pmntAdCdNm;
	}
	public String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}
	public void setPmntAdDtlCt(String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}
	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}
	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}
	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}
	public String getRsdtStusCd() {
		return rsdtStusCd;
	}
	public void setRsdtStusCd(String rsdtStusCd) {
		this.rsdtStusCd = rsdtStusCd;
	}
	public String getRsdtStusCdNm() {
		return rsdtStusCdNm;
	}
	public void setRsdtStusCdNm(String rsdtStusCdNm) {
		this.rsdtStusCdNm = rsdtStusCdNm;
	}
	public String getLstUdtUserId() {
		return lstUdtUserId;
	}
	public void setLstUdtUserId(String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}
	public String getFstRgstUserId() {
		return fstRgstUserId;
	}
	public void setFstRgstUserId(String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}
	public String getSndRgstUserId() {
		return sndRgstUserId;
	}
	public void setSndRgstUserId(String sndRgstUserId) {
		this.sndRgstUserId = sndRgstUserId;
	}
	public String getFondCrdSeqNo() {
		return fondCrdSeqNo;
	}
	public void setFondCrdSeqNo(String fondCrdSeqNo) {
		this.fondCrdSeqNo = fondCrdSeqNo;
	}
	public String getSndOrgnzCd() {
		return sndOrgnzCd;
	}
	public void setSndOrgnzCd(String sndOrgnzCd) {
		this.sndOrgnzCd = sndOrgnzCd;
	}
	public String getRcivOrgnzCd() {
		return rcivOrgnzCd;
	}
	public void setRcivOrgnzCd(String rcivOrgnzCd) {
		this.rcivOrgnzCd = rcivOrgnzCd;
	}
	
	public String getToday() {
		return today;
	}
	public void setToday(String today) {
		this.today = today;
	}
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String getOrgnzCdNm() {
		return orgnzCdNm;
	}
	public void setOrgnzCdNm(String orgnzCdNm) {
		this.orgnzCdNm = orgnzCdNm;
	}
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public String getCrdIsuceSrlNo() {
		return crdIsuceSrlNo;
	}
	public void setCrdIsuceSrlNo(String crdIsuceSrlNo) {
		this.crdIsuceSrlNo = crdIsuceSrlNo;
	}
	public String getBthDdJ() {
		return bthDdJ;
	}
	public void setBthDdJ(String bthDdJ) {
		this.bthDdJ = bthDdJ;
	}
	public String getBthDdG() {
		return bthDdG;
	}
	public void setBthDdG(String bthDdG) {
		this.bthDdG = bthDdG;
	}
	public String getFondDdJ() {
		return fondDdJ;
	}
	public void setFondDdJ(String fondDdJ) {
		this.fondDdJ = fondDdJ;
	}
	public String getFondDdG() {
		return fondDdG;
	}
	public void setFondDdG(String fondDdG) {
		this.fondDdG = fondDdG;
	}

	public String getCrdIsuceDdJ() {
		return crdIsuceDdJ;
	}
	public void setCrdIsuceDdJ(String crdIsuceDdJ) {
		this.crdIsuceDdJ = crdIsuceDdJ;
	}
	public String getCrdIsuceDdG() {
		return crdIsuceDdG;
	}
	public void setCrdIsuceDdG(String crdIsuceDdG) {
		this.crdIsuceDdG = crdIsuceDdG;
	}
	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}
	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}
	public String getDsuseCrdRsnCd() {
		return dsuseCrdRsnCd;
	}
	public void setDsuseCrdRsnCd(String dsuseCrdRsnCd) {
		this.dsuseCrdRsnCd = dsuseCrdRsnCd;
	}
	public String getDsuseCrdRsnCt() {
		return dsuseCrdRsnCt;
	}
	public void setDsuseCrdRsnCt(String dsuseCrdRsnCt) {
		this.dsuseCrdRsnCt = dsuseCrdRsnCt;
	}
	public String getMnSeqNo() {
		return mnSeqNo;
	}
	public void setMnSeqNo(String mnSeqNo) {
		this.mnSeqNo = mnSeqNo;
	}
	
	
	
}
