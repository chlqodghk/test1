package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.rm.crd.service.CrdRnwlCddService;
import afnid.rm.crd.service.CrdRnwlCddVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of eNID Card Renewal Candidate List
 * and implements CrdRnwlCddService class.
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.04  		BH Choi         		Create
 *
 * </pre>
 */
@Service("crdRnwlCddService")
public class CrdRnwlCddServiceImpl extends AbstractServiceImpl implements CrdRnwlCddService {
	
	/** CrdRnwlCddDAO */
    @Resource(name="crdRnwlCddDAO")
    private CrdRnwlCddDAO dao;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;    

    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;

    /**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CrdRnwlCddVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchListCrdRnwlCdd(CrdRnwlCddVO vo) throws Exception {
      		return dao.selectListCrdRnwlCdd(vo);
   	}

   	/**
	 * Biz-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdRnwlCddVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
   	public int searchListCrdRnwlCddTotCn(CrdRnwlCddVO vo) throws Exception {
        return dao.selectListCrdRnwlCddTotCn(vo);
	}
   	
   	/**
	 * Biz-method for retrieving convert Expire date for search list as calendar type. <br>
	 *
	 * @param vo Input item for retrieving convert Expire date for search list as calendar type.(CrdRnwlCddVO).
	 * @return String converted date
	 * @exception Exception
	 */
	public String searchDdCvt(CrdRnwlCddVO vo) throws Exception {
        return dao.selectDdCvt(vo);
	}

	/**
	 * Biz-method for retrieving Card Renewal Candidate List to download Excel. <br>
	 * 
	 * @param vo Input item for retrieving Card Renewal Candidate List(CrdRnwlCddVO).
	 * @return 
	 * @exception Exception
	 */
	public List<CrdRnwlCddVO> searchListCrdRnwlCddExcel(CrdRnwlCddVO vo) throws Exception{
		
		return dao.selectListCrdRnwlCddExcel(vo);	
	}
}
