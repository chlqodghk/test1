package afnid.rm.crd.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;



/** 
 * This service interface is biz-class of common. <br>
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2013.01.04  		BH Choi				Create
 *
 * </pre>
 */
public interface CrdFndService {	
		
	/**
	 * Retrieves count of resident information for card found registration. <br>
	 * @param vo Input item for retrieving count of resident information for card found registration.(CrdFndVO)
	 * @return int Count of resident information for card found registration
	 * @exception Exception
	 */	
	int searchCrdIssuedCn(CrdFndVO vo) throws Exception;
	
	/**
	 * Retrieves resident information for card found registration <br>
	 *
	 * @param vo Input item for retrieving resident information for card found registration(CrdFndVO).
	 * @return CardFndVO Retrieve resident information
	 * @exception Exception
	 */
	CrdFndVO searchCrdFndInfr(CrdFndVO vo) throws Exception;
	
	/**
	 * Retrieves count of card issuing information. <br>
	 * @param vo Input item for retrieving count of card issuing information.(CrdFndVO)
	 * @return int Count of card issuing information.
	 * @exception Exception
	 */	
	int searchCrdIsuceStusCn(String rsdtNo) throws Exception;
	
	/**
	 * Insert card information of card found registration <br>
	 *
	 * @param vo Input item for Insert card information of card found registration(CrdFndVO).
	 * @return void
	 * @exception Exception
	 */
	CrdFndVO addCrdFndInfr(CrdFndVO vo) throws Exception;	

	
	/**
	 * user retirement(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for user retirement(CrdFndVO).
	 * @return CrdFndVO Primary Key value of user retirement
	 * @exception Exception
	 */
	String addCrdFndInfrPkiIf(CrdFndVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdFndVO).
	 * @return List<EgovMap> Retrieve list of program00]'
	 * @exception Exception
	 */
	List<EgovMap> searchListCrdFndAprv(CrdFndVO vo) throws Exception;	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * 
	 * @param vo Input item for retrieving total count of program.(CrdFndVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListCrdFndAprvTotCn(CrdFndVO vo) throws Exception;
	
	/**
	 * Retrieves Card found Information for Approval. <br>
	 *
	 * @param vo Input item for retrieving Card found Information for verifying(CrdFndVO).
	 * @return CardFndVO Card found Information for verifying
	 * @exception Exception
	 */
	CrdFndVO searchCrdFndDtlAprv(CrdFndVO vo) throws Exception;
	
	/**
	 * Update Printed Card Sequence No. <br>
	 *
	 * @param vo Input item for Update Printed Card Sequence No.(CrdFndVO).
	 * @return void
	 * @exception Exception
	 */
	void modifyPrntCrdSrlNo(CrdFndVO vo) throws Exception;
	
	/**
	 * Update card information of card found registration <br>
	 *
	 * @param vo Input item for Update card information of card found registration(CrdFndVO).
	 * @return void
	 * @exception Exception
	 */
	void modifyCrdFndDtlAprv(CrdFndVO vo) throws Exception;
	
	/**
	 * Approve card information of card found registration <br>
	 *
	 * @param vo Input item for Update card information for card found approval.(CrdFndVO).
	 * @return void
	 * @exception Exception
	 */
	String approveCrdFndInfr(CrdFndVO vo) throws Exception;
	
	/**
	 * user retirement(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for user retirement(CrdFndVO).
	 * @return CrdFndVO Primary Key value of user retirement
	 * @exception Exception
	 */
	String approveCrdFndInfrPkiIf(CrdFndVO vo) throws Exception;	
	
	
	/**
	 * Modify found card process status information of card found registration <br>
	 *
	 * @param rsdtNo Input item for Modify found card process status information for found card disuse.(String).
	 * @return List<String> result
	 * @exception Exception
	 */
	List<String> modifyCrdFndPrcssStus(String rsdtNo, String dsuseCrdRsnCd, String dsuseCrdRsnCt, String mnSeqNo) throws Exception;
}
