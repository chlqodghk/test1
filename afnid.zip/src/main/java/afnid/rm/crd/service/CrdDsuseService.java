package afnid.rm.crd.service;

import java.util.List;


/** 
 * This service interface is biz-class of Card Disuse Processing. <br>
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2013.12.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers			Revisions
 *   2013.12.17  		MS Kim		        Create
 *   
 * </pre>
 */
public interface CrdDsuseService {

	/**
   	 * Retrieves list of card disuse. <br>
   	 *
   	 * @param vo Input item for retrieving list of card disuse.
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public List<CrdDsuseVO>  searchListCrdDsuse(CrdDsuseVO vo) throws Exception;
	
   	
    /**
   	 * Retrieves total count list of card disuse. <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdDsuseVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public int searchListCrdDsuseTotCnt(CrdDsuseVO vo) throws Exception;  
   	
   	
    /**
   	 * card disuse request processing. <br>
   	 *
   	 * @param vo Input item for card disuse request processing(CrdDsuseVO).
   	 * @return void
   	 * @exception Exception
   	 */   	
	public String modifyCrdDsuseRqst(CrdDsuseVO vo) throws Exception;
	
	
	/**
	 * user retirement(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for user retirement(CrdDsuseVO).
	 * @return CrdDsuseVO Primary Key value of user retirement
	 * @exception Exception
	 */
	String modifyCrdDsuseRqstPkiIf(CrdDsuseVO vo) throws Exception;
	
	
	/**
   	 * card disuse result Check processing. <br>
   	 *
   	 * @param vo Input item for card disuse result Check processing(CrdDsuseVO).
   	 * @return void
   	 * @exception Exception
   	 */   	
	public int modifyCrdDsuseRsutChk(CrdDsuseVO vo) throws Exception;	
		
   	
}
