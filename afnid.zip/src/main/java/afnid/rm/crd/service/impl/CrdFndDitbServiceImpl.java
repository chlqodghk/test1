package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.pkiif.cpki.CpkiRmWS;
import afnid.pkiif.cpki.CpkiRmWSService;
import afnid.pkiif.cpki.PkiRsWsResponse;
import afnid.rm.crd.service.CrdFndDitbService;
import afnid.rm.crd.service.CrdFndDitbVO;
import afnid.rm.rsdt.service.RsdtInfrService;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

@Service("crdFndDitbService")
public class CrdFndDitbServiceImpl extends AbstractServiceImpl implements CrdFndDitbService{
	
	/** CrdFndDitbDAO */
    @Resource(name="crdFndDitbDAO")
    private CrdFndDitbDAO dao;
    
    /** LgDAO */
    @Resource(name="lgDAO")
    private LgDAO lgDAO;
    
    /** rsdtInfoDAO */
    @Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtDao;
    
    /** rsdtInfoService service */
    @Resource(name="rsdtInfoService")
    private RsdtInfrService rsdtInfoService;
	
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
	/**
   	 * Biz-method for retrieving information of program. <br>
   	 *
   	 * @param vo Input item for retrieving information of program(CrdDitbVO).
   	 * @return CrdFndDitbVO Retrieve information of program
   	 * @exception Exception
   	 */
   	public CrdFndDitbVO searchCrdFndDitbIdfcInfr(CrdFndDitbVO vo) throws Exception {
      	
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
		CrdFndDitbVO crdFondIdfc = null;
		List<CrdFndDitbVO> crdFondList = dao.selectCrdFndDitbIdfcInfr(vo);
		
		if(1 == crdFondList.size() ){
			
			crdFondIdfc = crdFondList.get(0);
			
			String msg = "";
			String crdDsuseRsnCd = "";
			//check for Citizen Card Expiration
			if("Y".equals(crdFondIdfc.getIsExp())){
				String duseObjt = nidMessageSource.getMessage("duseObjt"); 
				msg = nidMessageSource.getMessage("dsuseByExp.msg", new String[]{duseObjt});
				crdDsuseRsnCd = "1";
			}
			
			//check for Card Reissuance  Apply Status
			String crdIsuStus = rsdtInfoService.searchRsdtCrdIsuAppStus(crdFondIdfc.getRsdtNo(), "code", "");
			if(!"".equals(crdIsuStus)){
				String duseObjt = nidMessageSource.getMessage("duseObjt"); 
				msg = nidMessageSource.getMessage("dsuseByIsuce.msg", new String[]{duseObjt});
				crdDsuseRsnCd = "4";
			}
			
			//check for Citizen Revocation Apply Status
			EgovMap eMap  = dao.selectRsdtRvctgStus(vo);
			
			String rsdtStusCd = NidStringUtil.nullConvert(eMap.get("rsdtStusCd"));
			String isNotApl = NidStringUtil.nullConvert(eMap.get("isNotApl"));
			if(!"1".equals(rsdtStusCd)){
				msg = NidStringUtil.nullConvert(eMap.get("ersrCdNm"));
				crdDsuseRsnCd = "2";
			}else{
				if("N".equals(isNotApl)){
					msg = nidMessageSource.getMessage("rvctgApl");
					crdDsuseRsnCd = "3";
				}
			}
			crdFondIdfc.setDsuseMsg(msg);
			crdFondIdfc.setCrdDsuseRsnCd(crdDsuseRsnCd);
							
		}else if(1 < crdFondList.size()){
			crdFondIdfc = new CrdFndDitbVO();
			crdFondIdfc.setCallPopupYn("Y");
			crdFondIdfc.setRsdtNo(vo.getSearchKeyword());
		}
		
   		return crdFondIdfc;
   	}
	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CrdDitbVO).
   	 * @return List<CrdFndDitbVO> Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<CrdFndDitbVO> searchListCrdFndDitbInfr(CrdFndDitbVO vo) throws Exception {
      	
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
		
		List<CrdFndDitbVO> crdFondList = dao.selectListCrdFndDitbInfr(vo);
		
   		return crdFondList;
   	}
   	
   	/**
	 * Biz-method for registering information of program. <br>
	 * 
	 * @param vo Input item for registering information of program.(CrdDitbVO).
	 * @return 
	 * @exception Exception
	 */
	public void addCrdFndDitbIdfcInfr(CrdFndDitbVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setFstRgstUserId(user.getUserId());// Setting User ID
		vo.setLstUdtUserId(user.getUserId());
		dao.insertCrdFndDitbIdfcInfr(vo);
		
	}
	
	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CrdFndDitbVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public CrdFndDitbVO searchCrdFndDitbInfr(CrdFndDitbVO vo) throws Exception {
      	
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());// Setting Organization Code
		
		CrdFndDitbVO crdFondDitb  = null;
		
		List<CrdFndDitbVO> crdFondList = dao.selectCrdFndDitbInfr(vo);
		
			if(crdFondList != null){
				
				if(1 == crdFondList.size() ){
					crdFondDitb = crdFondList.get(0);
					
					String msg = "";
					String crdDsuseRsnCd = "";
					//check for Citizen Card Expiration
					if("Y".equals(crdFondDitb.getIsExp())){
						String duseObjt = nidMessageSource.getMessage("duseObjt"); 
						msg = nidMessageSource.getMessage("dsuseByExp.msg",  new String[]{duseObjt});
						crdDsuseRsnCd = "1";
					}
					
					//check for Card Reissuance  Apply Status
					String crdIsuStus = rsdtInfoService.searchRsdtCrdIsuAppStus(crdFondDitb.getRsdtNo(), "code", "");
					if(!"".equals(crdIsuStus)){
						String duseObjt = nidMessageSource.getMessage("duseObjt"); 
						msg = nidMessageSource.getMessage("dsuseByIsuce.msg",  new String[]{duseObjt});
						crdDsuseRsnCd = "4";
					}
					
					//check for Citizen Revocation Apply Status
					EgovMap eMap  = dao.selectRsdtRvctgStus(vo);
					
					String rsdtStusCd =  NidStringUtil.nullConvert(eMap.get("rsdtStusCd")); 
					String isNotApl = NidStringUtil.nullConvert(eMap.get("isNotApl"));
					if(!"1".equals(rsdtStusCd)){
						msg = NidStringUtil.nullConvert(eMap.get("ersrCdNm"));
						crdDsuseRsnCd = "2";
					}else{
						if("N".equals(isNotApl)){
							msg = nidMessageSource.getMessage("rvctgApl");
							crdDsuseRsnCd = "3";
						}
					}
					crdFondDitb.setDsuseMsg(msg);
					crdFondDitb.setCrdDitbOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());
					crdFondDitb.setCrdDitbUserId(user.getUserId());
					crdFondDitb.setCrdDitbUserIdNm(user.getNm());
					
					crdFondDitb.setCrdDsuseRsnCd(crdDsuseRsnCd);
				
					String userLang = user.getUseLangCd();
					if("1".equals(userLang)){
						crdFondDitb.setCrdDitbOrgnzCdNm(user.getPstOrgnzNm());
					}else if("2".equals(userLang)){
						crdFondDitb.setCrdDitbOrgnzCdNm(user.getDrOrgnzNm());
					}else if("3".equals(userLang)){
						crdFondDitb.setCrdDitbOrgnzCdNm(user.getEnOrgnzNm());
					}else{
						crdFondDitb.setCrdDitbOrgnzCdNm(user.getPstOrgnzNm());
					}
				
				}else if(1 < crdFondList.size()){
					crdFondDitb = new CrdFndDitbVO();
					crdFondDitb.setCallPopupYn("Y");
					crdFondDitb.setRsdtNo(vo.getSearchKeyword());
				}
			
		}		
		
   		return crdFondDitb;
   	}
   	
   	/**
	 * Biz-method for registering information of program. <br>
	 * 
	 * @param vo Input item for registering information of program.(CrdFndDitbVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyCrdFndDitbInfr(CrdFndDitbVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());// Setting User ID
		String lgSeqNo ="";
		String enid = vo.getRsdtNo();
		
		//Insert RM_RSDT_TB History
		rsdtDao.insertRsdtInfrHst(vo.getRsdtSeqNo(), user.getUserId());
		
		boolean result = dao.updateCrdFndDitbInfr(vo);
		
		if(!result){
			throw processException( "udtFail.msg");
		}
		
		//Update Signature Data to RM_RSDT_TB
		rsdtInfoService.updateDigitalSgnt(vo.getRsdtSeqNo(), vo.getSgntDat(), "11");

		//get PKI cert issuance count
		int crtisuceCn = rsdtInfoService.searchPkiCrtIsuceCn(vo.getRsdtSeqNo());
		//PKI Cert Unhold
		
		if(0 < crtisuceCn){		    
		    //Insert PKI log
		    lgSeqNo = lgDAO.insertPubKeyIfLg(user.getUserId(), enid, "2", "1", "10", "");
		}	
		
		return lgSeqNo;
	}
	
	/**
	 * Biz-method for registering information of new user(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for registering new user(CrdFndDitbVO).
	 * @return CrdFndDitbVO Primary Key value of registered user
	 * @exception Exception
	 */
	public String modifyCrdFndDitbInfrPkiIf(CrdFndDitbVO vo) throws Exception {
		
		String status = "";
		String erorYn ="Y";

		CpkiRmWSService orws= new CpkiRmWSService();
		CpkiRmWS orw = orws.getCpkiRmWSPort();		
			
		PkiRsWsResponse prwr = orw.cpkiIFcertUnHold(vo.getRsdtNo());
		status= prwr.getStatusCode();
	    
		log.debug("status ====> " + status);
		
		if("0".equals(status)){
			erorYn ="N";
		}
		
		lgDAO.updatePubKeyIfLg(vo.getLgSeqNo(), status, erorYn);					
		
    	return status;
    	
	}
	
	/**
	 * Biz-method for updating information of Card Disuse. <br>
	 * 
	 * @param vo Input item for updating information of Card Disuse.(CrdFndDitbVO).
	 * @return 
	 * @exception Exception
	 */
	public void modifyCrdFndPrcssStusForDitbFndCrd(CrdFndDitbVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());// Setting User ID
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code	
		
		boolean result = dao.updateCrdDsuseInfr(vo);
		
		if(!result){
			throw processException( "udtFail.msg");
		}
	}
}
