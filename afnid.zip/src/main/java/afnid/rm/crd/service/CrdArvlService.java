package afnid.rm.crd.service;

import java.util.List;


/** 
 * This service interface is biz-class of eNID Card arrival Management. <br>
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2014.11.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers				Revisions
 *   2014.11.17  		MoonSoo Kim             Create
 *
 * </pre>
 */
public interface CrdArvlService {
	/**
	 * Retrieves list of card arrival list. <br>
	 *
	 * @param vo Input item for retrieving list of card arrival(CrdArvlVO).
	 * @return List Retrieve list of card arrival 
	 * @exception Exception
	 */
	List<CrdArvlVO> searchListCrdArvl(CrdArvlVO vo) throws Exception;
	
	/**
	 * Retrieves total count of card arrival list. <br>
	 * @param vo Input item for retrieving total count list of card arrival.(CrdArvlVO)
	 * @return int Total Count of card arrival list
	 * @exception Exception
	 */
	int searchListCrdArvlTotCn(CrdArvlVO vo) throws Exception;

	/**
	 * Retrieves citizen list of card arrival. <br>
	 *
	 * @param vo Input item for retrieving citizen list of card arrival(CrdArvlVO).
	 * @return List Retrieve citizen list of card arrival 
	 * @exception Exception
	 */
	List<CrdArvlVO> searchListCrdArvlRsdt(CrdArvlVO vo) throws Exception;
	
	/**
	 * Retrieves total count of card arrival citizen list. <br>
	 * @param vo Input item for retrieving total count citizen list of card arrival.(CrdArvlVO)
	 * @return int Total Count of card arrival citizen list
	 * @exception Exception
	 */
	int searchListCrdArvlRsdtTotCn(CrdArvlVO vo) throws Exception;	
	
	/**
	 * Retrieves citizen list count of card arrival . <br>
	 *
	 * @param vo Input item for retrieving citizen list count of card arrival(CrdArvlVO).
	 * @return CrdArvlVO citizen list count of card arrival 
	 * @exception Exception
	 */
	CrdArvlVO searchCrdArvlRsdtCn(CrdArvlVO vo) throws Exception;	
	
	/**
	 * Retrieves citizen list of card arrival. <br>
	 *
	 * @param vo Input item for retrieving citizen list of card arrival(CrdArvlVO).
	 * @return List Retrieve citizen list of card arrival 
	 * @exception Exception
	 */
	List<CrdArvlVO> searchListCrdArvlRsdtCrdReisuce(CrdArvlVO vo) throws Exception;
	
	/**
	 * Reissue eNID Card. <br>
	 * @param vo Input item for  eNID Card Reissuance.(CrdArvlVO)
	 * @return 
	 * @exception Exception
	 */
	public void modifyArvlCadReisuce(CrdArvlVO vo) throws Exception ;	
	
	/**
	 * Processing eNID Card Arrival. <br>
	 * @param vo Input item for  Processing eNID Card Arrival.(CrdArvlVO)
	 * @return 
	 * @exception Exception
	 */
	public void modifyArvl(CrdArvlVO vo) throws Exception ;
	
	/**
	 * Processing eNID Card Arrival Clear. <br>
	 * @param vo Input item for  Processing eNID Card Arrival Clear.(CrdArvlVO)
	 * @return 
	 * @exception Exception
	 */
	public void modifyArvlClar(CrdArvlVO vo) throws Exception ;	
	
	/**
	 * Retrieves list of Issuance Failed Citizens. <br>
	 *
	 * @param vo Input item for retrieving list of Issuance Failed CitizensCrdArvlVO).
	 * @return List Retrieve list of Issuance Failed Citizens 
	 * @exception Exception
	 */
	List<CrdArvlVO> searchListCrdFailRsdt(CrdArvlVO vo) throws Exception;
	
	/**
	 * Retrieves total count of Issuance Failed Citizens. <br>
	 * @param vo Input item for retrieving total count list of Issuance Failed Citizens.(CrdArvlVO)
	 * @return int Total Count of Issuance Failed Citizens
	 * @exception Exception
	 */
	int searchListCrdFailRsdtTotCn(CrdArvlVO vo) throws Exception;	
	
	/**
	 * Modify Citizen Contact Y/N. <br>
	 * @param vo Input item for modify citizen contact Y/N.(CrdArvlVO)
	 * @return 
	 * @exception Exception
	 */
	public void modifyCrdFailRsdt(CrdArvlVO vo) throws Exception ;
	
}
