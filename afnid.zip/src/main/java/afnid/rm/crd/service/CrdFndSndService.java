package afnid.rm.crd.service;

import java.util.List;

/** 
 * This service interface is biz-class of Found Card Send. <br>
 * 
 * @author Afghanistan National ID Card System Application Team SiKyung Yang
 * @since 2013.09.30
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers			Revisions
 *   2013.09.30  		SiKyung Yang		  Create
 *
 * </pre>
 */
public interface CrdFndSndService {
	
	
	/**
	 * Retrieves resident information for card found registration <br>
	 *
	 * @param vo Input item for retrieving resident information for card found registration(CrdFndSndVO).
	 * @return CrdFndSndVO Retrieve resident information
	 * @exception Exception
	 */
	CrdFndSndVO searchCrdFndSndInfr(CrdFndSndVO vo) throws Exception;
	
	/**
	 * Retrieves information List of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdFndSndVO).
	 * @return List<CrdFndDitbVO> Retrieve list of program
	 * @exception Exception
	 */
	List<CrdFndSndVO> searchListCrdFndSndInfr(CrdFndSndVO vo)throws Exception;
	
	/**
	 * registering information of card found Sending. <br>
	 *
	 * @param vo Input item for registering information of program(CrdFndSndVO).
	 * @return 
	 * @exception Exception
	 */
	void addCrdFndSndInfr(CrdFndSndVO vo) throws Exception;	
	
	/**
	 * updating information of Card Disuse. <br>
	 * 
	 * @param vo Input item for updating information of Card Disuse.(CrdFndSndVO).
	 * @return 
	 * @exception Exception
	 */
	 void modifyCrdDisuseOnFndSnd(CrdFndSndVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdFndSndVO).
	 * @return List<CrdFndSndVO> Retrieve list of program
	 * @exception Exception
	 */
	List<CrdFndSndVO> searchListCrdFndSndAprv(CrdFndSndVO vo) throws Exception;	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * 
	 * @param vo Input item for retrieving total count of program.(CrdFndSndVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListCrdFndSndAprvTotCn(CrdFndSndVO vo) throws Exception;

	/**
	 * Retrieves resident detail information for card found sending <br>
	 *
	 * @param vo Input item for retrieving detail information for card found sending(CrdFndSndVO).
	 * @return CardFndVO Retrieve detail information for card found sending
	 * @exception Exception
	 */
	CrdFndSndVO searchCrdFndSndDtlAprv(CrdFndSndVO vo) throws Exception;
	/**
	 * Update information of card found sending <br>
	 *
	 * @param vo Input item for Update card information of card found sending(CrdFndSndVO).
	 * @return 
	 * @exception Exception
	 */
	void modifyCrdFndSndAprvInfr(CrdFndSndVO vo) throws Exception;
	/**
	 * Approve information of card found sending <br>
	 *
	 * @param vo Input item for Update information for card found sending.(CrdFndSndVO).
	 * @return 
	 * @exception Exception
	 */
	void approveCrdFndSndInfr(CrdFndSndVO vo) throws Exception;	
	
	/**
	 * Retrieves list of organization information. <br>
	 * 
	 * @param vo Input item for retrieving list of organization(CrdFndSndVO).
	 * @return List<CrdFndSndVO> Retrieve list of organization
	 * @exception Exception
	 */
	List<CrdFndSndVO> searchListOrgnzInfr(CrdFndSndVO vo) throws Exception;
}
