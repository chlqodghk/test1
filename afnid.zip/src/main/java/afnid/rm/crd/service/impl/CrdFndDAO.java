package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.cm.util.service.NidStringUtil;
import afnid.rm.crd.service.CrdFndVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;



/** 
 * This class is Database Access Object of Found Card
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04`
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.04  		BH Choi         		Create
 *
 * </pre>
 */
@Repository("crdFndDAO")
public class CrdFndDAO extends EgovAbstractDAO {
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	
	/**
	 * DAO-method for retrieving count Resident information of program. <br>
	 *
	 * @param vo Input item for retrieving count Resident information of program(CrdFndVO).
	 * @return int Count of Program List
	 * @exception Exception
	 */
    public int selectCrdIssuedCn(CrdFndVO vo) {
        
    	vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
    	
    	return (Integer)selectByPk("crdFndDAO.selectCrdIssuedCn", vo);
    }
    
	/**
	 * DAO-method for retrieving Resident information of program. <br>
	 *
	 * @param vo Input item for retrieving Resident information of program(CrdFndVO).
	 * @return CrdFndVO Retrieve Resident information of program
	 * @exception Exception
	 */
	public CrdFndVO selectCrdFndInfr(CrdFndVO vo) throws Exception{
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return (CrdFndVO)selectByPk("crdFndDAO.selectCrdFndInfr", vo);		
	}
	
	/**
	 * DAO-method for retrieving count of card issuing information. <br>
	 *
	 * @param vo Input item for retrieving count of card issuing information(CrdFndVO).
	 * @return int Count of Program
	 * @exception Exception
	 */
    public int selectCrdIsuceStusCn(String rsdtNo) {

    	return (Integer)selectByPk("crdFndDAO.selectCrdIsuceStusCn", rsdtNo);
    }
    
    /**
	 * DAO-method for retrieving card issue information. <br>
	 *
	 * @param vo Input item for retrieving card issuing information(CrdFndVO).
	 * @return CrdFndVO Retrieve information of program
	 * @exception Exception
	 */
    public CrdFndVO selectCrdIsuceInfr(String rsdtNo) {

    	return (CrdFndVO)selectByPk("crdFndDAO.selectCrdIsuceInfr", rsdtNo);
    }
	
    /**
	 * DAO-method for Change from PERSIAN date to GREGORIAN date. <br>
	 *
	 * @param cmsDate Input item for Change from PERSIAN date to GREGORIAN date.(string).
	 * @return String GREGORIAN date.
	 * @exception Exception
	 */
	public String selectDataChngToGre(String cmsDate) throws Exception{
		
		return (String)selectByPk("crdFndDAO.selectDataChngToGre", cmsDate);		
	}
    
	/**
	 * DAO-method for registering information of new program. <br>
	 *
	 * @param vo Input item for registering information of new program(CrdFndVO).
	 * @return String result
	 * @exception Exception
	 */
    public String insertCrdFndInfr(CrdFndVO vo) {
        return (String)insert("crdFndDAO.insertCrdFndInfr", vo);
    }
    
    
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(CrdFndVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListCrdFndAprv(CrdFndVO vo) throws Exception{		
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return list("crdFndDAO.selectListCrdFndAprv", vo);		
	}
	
	/**
	 * DAO-method for retrieving total count of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdFndVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListCrdFndAprvTotCn(CrdFndVO vo) {
        
    	vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
    	
    	return (Integer)selectByPk("crdFndDAO.selectListCrdFndAprvTotCn", vo);
    }

	/**
	 * DAO-method for retrieving detail Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(CrdFndVO).
	 * @return CrdFndVO Retrieve information of program
	 * @exception Exception
	 */
	public CrdFndVO selectCrdFndDtlAprv(CrdFndVO vo) throws Exception{
		return (CrdFndVO)selectByPk("crdFndDAO.selectCrdFndDtlAprv", vo);		
	}
	
	/**
	 * DAO-method for update information of program. <br>
	 *
	 * @param vo Input item for update information of program(CrdFndVO).
	 * @return int result
	 * @exception Exception
	 */
    public boolean updatePrntCrdSrlNo(CrdFndVO vo) {
    	
    	boolean result = false; 
    	
    	int udtResult = update("crdFndDAO.updatePrntCrdSrlNo", vo);
        
        if(udtResult == 1){
			result = true;
		}
		
		return result;
    }
	
	/**
	 * DAO-method for update information of program. <br>
	 *
	 * @param vo Input item for update information of program(CrdFndVO).
	 * @return int result
	 * @exception Exception
	 */
    public boolean updateCrdFndDtlAprv(CrdFndVO vo) {
    	
    	boolean result = false; 
    	
    	int udtResult = update("crdFndDAO.updateCrdFndDtlAprv", vo);
        
        if(udtResult == 1){
			result = true;
		}
		
		return result;
    }
    
	/**
	 * DAO-method for approval information of program. <br>
	 *
	 * @param vo Input item for approval information  of program(CrdFndVO).
	 * @return int result
	 * @exception Exception
	 */
    public boolean updateCrdFndAprv(CrdFndVO vo) {
    	boolean result = false; 
    	
    	int aprvResult = update("crdFndDAO.updateCrdFndAprv", vo);
    	 
    	int rsdtResult = update("crdFndDAO.updateRsdtInfr", vo);
    	
    	if(aprvResult == 1 && rsdtResult == 1){
 			result = true;
 		}
 		
 		return result;
    }
    
    /**
	 * DAO-method for approval information of program. <br>
	 *
	 * @param vo Input item for approval information  of program(CrdFndVO).
	 * @return int result
	 * @exception Exception
	 */
    public boolean updateCrdFndAprvOnlyFoundTb(CrdFndVO vo) {
    	boolean result = false; 
    	
    	int aprvResult = update("crdFndDAO.updateCrdFndAprv", vo);
    	 
    	if(aprvResult == 1){
 			result = true;
 		}
 		
 		return result;
    }
    
    /**
	 * DAO-method for Update Signature Data to RM_RSDT_TB. <br>
	 * 
	 * @param vo Input item for Update Signature Data.(CrdFndVO).
	 * @return CrdFndVO result of Updating Signature Data.
	 * @exception Exception
	 */
	public boolean updateSgntDat(CrdFndVO vo) throws Exception{
		
		boolean result = false; 
		int sgntResult = update("crdFndDAO.updateSgntDat", vo);
			
		if(sgntResult == 1){
			result = true;
		}
		
		return result ;
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(CrdFndVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<CrdFndVO> selectListCrdFndInfr(EgovMap map) throws Exception{		
		
		return list("crdFndDAO.selectListCrdFndInfr", map);		
		
	}
	
	/**
	 * DAO-method for Update Card Process Status Code <br>
	 * 
	 * @param vo Input item for Update Card Process Status Code.(CrdFndVO).
	 * @return CrdFndVO result of Updating Card Process Status Code.
	 * @exception Exception
	 */
	public String updateCrdPrcssStusCd(CrdFndVO vo) throws Exception{
		String orgnzNm = "";
		
		//update  Card Process Status Code
		int fondcrdResult = update("crdFndDAO.updateCrdPrcssStusCdInRmFondCrdTb", vo);
		if(fondcrdResult == 1){
			//setting organization Name in update row 
			orgnzNm = vo.getRgstOrgnzCdNm();
		}else{
			return orgnzNm ;
		}
		// check status of Identification
		if("Y".equals(vo.getIdfcYn())){
			//update  Card Distribution Code in RM_FOND_CRD_DITB_TB
			int ditbResult = update("crdFndDAO.updateCrdPrcssStusCdInRmFondCrdDitbTb", vo);
			if(ditbResult != 1){
				orgnzNm = "";
			}
		}
				
		return orgnzNm ;
	}
	
	/**
	 * DAO-method for Update Card Process Status Code <br>
	 * 
	 * @param vo Input item for Update Card Process Status Code.(CrdFndVO).
	 * @return CrdFndVO result of Updating Card Process Status Code.
	 * @exception Exception
	 */
	public boolean updateSndFondCrdStusCd(CrdFndVO vo) throws Exception{
		boolean updateResult = false; 
		
		//update send found card status code
		int Result = update("crdFndDAO.updateSndFondCrdStusCdInRmFondCrdMvTb", vo);
		if(Result == 1){
			updateResult = true;
		}
				
		return updateResult ;
	}
}
