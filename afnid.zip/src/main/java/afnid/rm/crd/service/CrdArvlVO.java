package afnid.rm.crd.service;

import afnid.cm.ComDefaultVO;

public class CrdArvlVO extends ComDefaultVO {
	
	private static final long serialVersionUID = 1L;
	
	private String athrSeqNo;
	private String rcivFleNm;
	private String rqstCn;
	private String isuceCn;
	private String isuceFailCn;
	private String arvdCn;
	private String arvdFailCn;
	private String ditbCn;
	private String rmaindCn;
	private String reisuceCn;
	private String crdPrntgCn;
	private String crdPrntgFailCn;
	private String nArvdCn;
	private String idfcCn;	
	private String slcCn;
	
	private String rsdtSeqNo;
	private String rsdtNo;
	private String rsdtNoDp;
	private String givNm;
	private String surnm;
	
	private String hCrdArvlDd;
	private String hCrdDitbDd;
	private String hCrdIsuceFailDd;
	private String hFleRcivDd;
	private String hReisuceDd;
	private String hCrdPrntgFailDd;
	private String hCrdIdfcDd;
	
	private String gCrdArvlDd;
	private String gCrdDitbDd;
	private String gCrdIsuceFailDd;
	private String gFleRcivDd;
	private String gReisuceDd;	
	private String gCrdPrntgFailDd;
	private String gCrdIdfcDd;
	
	private String srchOrgnzCd;
	private String srchOrgnzNm;
	private String rplcStr;
    private String oficTye;
	private String crdDitbSeqNo;
	private String nm;
	private String enNm;
	
	private String isuceYn;
	private String arvlYn;
	private String printYn;
	private String slcAllYn;
	private String idfcYn;
	private String ditbYn;

	
	private String rsdtArvdCn;
	private String rsdtNotArvdCn;
	private String rsdtDitbCn;
	private String rsdtReisuceCn;
	private String rsdtIdfcCn;
	private String rsdtArvdNotIdfcCn;
	private String rsdtNotPrntNotReisuceCn;
	private String prcssUserId;
	
	private String arvlStatus;	
	private String[] checkboxList;
	private String prcssTye;
	
	private String eml;
	private String cntTelNo;
	
	private String hRqstDd;
	private String hPlandDvrlDd;
	private String hErorDtctdDd;
	private String hRqstAginDd;
	private String hCrdReisuDueDd;
	
	private String gRqstDd;
	private String gPlandDvrlDd;
	private String gErorDtctdDd;
	private String gRqstAginDd;	
	private String gCrdReisuDueDd;
	
	private String reRqstDd;
	private String ctnzInfrd;
	private String userId;
	private String crdReisuDueDd;
	private String hPrsntDd;
	private String gPrsntDd;
	
	private String udtWrkCd;
	private String sgnt;
	
	private String trxID;
	private String bsnMsg;
	private String bsnMsgNo;
	private String[] oficSgntList;
	private String[] rsdtSeqNoList;
	private String[] rsdtNoList;
	private String[] crdDitbSeqNoList;
	private String[] oficSgntAllList;
	private String[] rsdtSeqNoAllList;
	private String[] rsdtNoAllList;	
	private String[] crdDitbSeqNoAllList;	
	private String[] lcaPrcssCddYn;
	private String crdDitbCdNm;

	public String getAthrSeqNo() {
		return athrSeqNo;
	}
	public void setAthrSeqNo(String athrSeqNo) {
		this.athrSeqNo = athrSeqNo;
	}
	public String getRcivFleNm() {
		return rcivFleNm;
	}
	public void setRcivFleNm(String rcivFleNm) {
		this.rcivFleNm = rcivFleNm;
	}
	public String getRqstCn() {
		return rqstCn;
	}
	public void setRqstCn(String rqstCn) {
		this.rqstCn = rqstCn;
	}
	public String getIsuceCn() {
		return isuceCn;
	}
	public void setIsuceCn(String isuceCn) {
		this.isuceCn = isuceCn;
	}
	public String getIsuceFailCn() {
		return isuceFailCn;
	}
	public void setIsuceFailCn(String isuceFailCn) {
		this.isuceFailCn = isuceFailCn;
	}
	public String getArvdCn() {
		return arvdCn;
	}
	public void setArvdCn(String arvdCn) {
		this.arvdCn = arvdCn;
	}
	public String getArvdFailCn() {
		return arvdFailCn;
	}
	public void setArvdFailCn(String arvdFailCn) {
		this.arvdFailCn = arvdFailCn;
	}
	public String getDitbCn() {
		return ditbCn;
	}
	public void setDitbCn(String ditbCn) {
		this.ditbCn = ditbCn;
	}
	public String getRmaindCn() {
		return rmaindCn;
	}
	public void setRmaindCn(String rmaindCn) {
		this.rmaindCn = rmaindCn;
	}
	public String getReisuceCn() {
		return reisuceCn;
	}
	public void setReisuceCn(String reisuceCn) {
		this.reisuceCn = reisuceCn;
	}
	public String getCrdPrntgCn() {
		return crdPrntgCn;
	}
	public void setCrdPrntgCn(String crdPrntgCn) {
		this.crdPrntgCn = crdPrntgCn;
	}
	public String getCrdPrntgFailCn() {
		return crdPrntgFailCn;
	}
	public void setCrdPrntgFailCn(String crdPrntgFailCn) {
		this.crdPrntgFailCn = crdPrntgFailCn;
	}
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	public String getGivNm() {
		return givNm;
	}
	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}
	public String getSurnm() {
		return surnm;
	}
	public void setSurnm(String surnm) {
		this.surnm = surnm;
	}
	public String gethCrdArvlDd() {
		return hCrdArvlDd;
	}
	public void sethCrdArvlDd(String hCrdArvlDd) {
		this.hCrdArvlDd = hCrdArvlDd;
	}
	public String gethCrdDitbDd() {
		return hCrdDitbDd;
	}
	public void sethCrdDitbDd(String hCrdDitbDd) {
		this.hCrdDitbDd = hCrdDitbDd;
	}
	public String gethCrdIsuceFailDd() {
		return hCrdIsuceFailDd;
	}
	public void sethCrdIsuceFailDd(String hCrdIsuceFailDd) {
		this.hCrdIsuceFailDd = hCrdIsuceFailDd;
	}

	public String gethFleRcivDd() {
		return hFleRcivDd;
	}
	public void sethFleRcivDd(String hFleRcivDd) {
		this.hFleRcivDd = hFleRcivDd;
	}
	public String gethReisuceDd() {
		return hReisuceDd;
	}
	public void sethReisuceDd(String hReisuceDd) {
		this.hReisuceDd = hReisuceDd;
	}
	public String gethCrdPrntgFailDd() {
		return hCrdPrntgFailDd;
	}
	public void sethCrdPrntgFailDd(String hCrdPrntgFailDd) {
		this.hCrdPrntgFailDd = hCrdPrntgFailDd;
	}
	public String gethCrdIdfcDd() {
		return hCrdIdfcDd;
	}
	public void sethCrdIdfcDd(String hCrdIdfcDd) {
		this.hCrdIdfcDd = hCrdIdfcDd;
	}
	public String getgCrdArvlDd() {
		return gCrdArvlDd;
	}
	public void setgCrdArvlDd(String gCrdArvlDd) {
		this.gCrdArvlDd = gCrdArvlDd;
	}
	public String getgCrdDitbDd() {
		return gCrdDitbDd;
	}
	public void setgCrdDitbDd(String gCrdDitbDd) {
		this.gCrdDitbDd = gCrdDitbDd;
	}
	public String getgCrdIsuceFailDd() {
		return gCrdIsuceFailDd;
	}
	public void setgCrdIsuceFailDd(String gCrdIsuceFailDd) {
		this.gCrdIsuceFailDd = gCrdIsuceFailDd;
	}

	public String getgFleRcivDd() {
		return gFleRcivDd;
	}
	public void setgFleRcivDd(String gFleRcivDd) {
		this.gFleRcivDd = gFleRcivDd;
	}
	public String getgReisuceDd() {
		return gReisuceDd;
	}
	public void setgReisuceDd(String gReisuceDd) {
		this.gReisuceDd = gReisuceDd;
	}
	public String getgCrdPrntgFailDd() {
		return gCrdPrntgFailDd;
	}
	public void setgCrdPrntgFailDd(String gCrdPrntgFailDd) {
		this.gCrdPrntgFailDd = gCrdPrntgFailDd;
	}
	public String getgCrdIdfcDd() {
		return gCrdIdfcDd;
	}
	public void setgCrdIdfcDd(String gCrdIdfcDd) {
		this.gCrdIdfcDd = gCrdIdfcDd;
	}
	public String getSrchOrgnzCd() {
		return srchOrgnzCd;
	}
	public void setSrchOrgnzCd(String srchOrgnzCd) {
		this.srchOrgnzCd = srchOrgnzCd;
	}
	public String getSrchOrgnzNm() {
		return srchOrgnzNm;
	}
	public void setSrchOrgnzNm(String srchOrgnzNm) {
		this.srchOrgnzNm = srchOrgnzNm;
	}
	public String getRplcStr() {
		return rplcStr;
	}
	public void setRplcStr(String rplcStr) {
		this.rplcStr = rplcStr;
	}

	public String getOficTye() {
		return oficTye;
	}
	public void setOficTye(String oficTye) {
		this.oficTye = oficTye;
	}
	public String getCrdDitbSeqNo() {
		return crdDitbSeqNo;
	}
	public void setCrdDitbSeqNo(String crdDitbSeqNo) {
		this.crdDitbSeqNo = crdDitbSeqNo;
	}
	public String getNm() {
		return nm;
	}
	public void setNm(String nm) {
		this.nm = nm;
	}
	public String getEnNm() {
		return enNm;
	}
	public void setEnNm(String enNm) {
		this.enNm = enNm;
	}
	public String getIsuceYn() {
		return isuceYn;
	}
	public void setIsuceYn(String isuceYn) {
		this.isuceYn = isuceYn;
	}
	public String getArvlYn() {
		return arvlYn;
	}
	public void setArvlYn(String arvlYn) {
		this.arvlYn = arvlYn;
	}
	public String getPrintYn() {
		return printYn;
	}
	public void setPrintYn(String printYn) {
		this.printYn = printYn;
	}
	public String getSlcAllYn() {
		return slcAllYn;
	}
	public void setSlcAllYn(String slcAllYn) {
		this.slcAllYn = slcAllYn;
	}
	public String getDitbYn() {
		return ditbYn;
	}
	public void setDitbYn(String ditbYn) {
		this.ditbYn = ditbYn;
	}
	public String getSlcCn() {
		return slcCn;
	}
	public void setSlcCn(String slcCn) {
		this.slcCn = slcCn;
	}
	public String getnArvdCn() {
		return nArvdCn;
	}
	public void setnArvdCn(String nArvdCn) {
		this.nArvdCn = nArvdCn;
	}
	public String getIdfcCn() {
		return idfcCn;
	}
	public void setIdfcCn(String idfcCn) {
		this.idfcCn = idfcCn;
	}
	public String getRsdtArvdCn() {
		return rsdtArvdCn;
	}
	public void setRsdtArvdCn(String rsdtArvdCn) {
		this.rsdtArvdCn = rsdtArvdCn;
	}
	public String getRsdtNotArvdCn() {
		return rsdtNotArvdCn;
	}
	public void setRsdtNotArvdCn(String rsdtNotArvdCn) {
		this.rsdtNotArvdCn = rsdtNotArvdCn;
	}
	public String getRsdtDitbCn() {
		return rsdtDitbCn;
	} 
	public void setRsdtDitbCn(String rsdtDitbCn) {
		this.rsdtDitbCn = rsdtDitbCn;
	}
	public String getRsdtReisuceCn() {
		return rsdtReisuceCn;
	}
	public void setRsdtReisuceCn(String rsdtReisuceCn) {
		this.rsdtReisuceCn = rsdtReisuceCn;
	}
	public String getRsdtIdfcCn() {
		return rsdtIdfcCn;
	}
	public void setRsdtIdfcCn(String rsdtIdfcCn) {
		this.rsdtIdfcCn = rsdtIdfcCn;
	}
	public String getIdfcYn() {
		return idfcYn;
	}
	public void setIdfcYn(String idfcYn) {
		this.idfcYn = idfcYn;
	}
	public String getRsdtArvdNotIdfcCn() {
		return rsdtArvdNotIdfcCn;
	}
	public void setRsdtArvdNotIdfcCn(String rsdtArvdNotIdfcCn) {
		this.rsdtArvdNotIdfcCn = rsdtArvdNotIdfcCn;
	}
	public String getRsdtNotPrntNotReisuceCn() {
		return rsdtNotPrntNotReisuceCn;
	}
	public void setRsdtNotPrntNotReisuceCn(String rsdtNotPrntNotReisuceCn) {
		this.rsdtNotPrntNotReisuceCn = rsdtNotPrntNotReisuceCn;
	}
	public String getArvlStatus() {
		return arvlStatus;
	}
	public void setArvlStatus(String arvlStatus) {
		this.arvlStatus = arvlStatus;
	}
	public String[] getCheckboxList() {
		return checkboxList;
	}
	public void setCheckboxList(String[] checkboxList) {
		this.checkboxList = checkboxList;
	}
	public String getPrcssUserId() {
		return prcssUserId;
	}
	public void setPrcssUserId(String prcssUserId) {
		this.prcssUserId = prcssUserId;
	}
	public String getPrcssTye() {
		return prcssTye;
	}
	public void setPrcssTye(String prcssTye) {
		this.prcssTye = prcssTye;
	}
	public String getEml() {
		return eml;
	}
	public void setEml(String eml) {
		this.eml = eml;
	}
	public String getCntTelNo() {
		return cntTelNo;
	}
	public void setCntTelNo(String cntTelNo) {
		this.cntTelNo = cntTelNo;
	}
	public String gethRqstDd() {
		return hRqstDd;
	}
	public void sethRqstDd(String hRqstDd) {
		this.hRqstDd = hRqstDd;
	}
	public String gethPlandDvrlDd() {
		return hPlandDvrlDd;
	}
	public void sethPlandDvrlDd(String hPlandDvrlDd) {
		this.hPlandDvrlDd = hPlandDvrlDd;
	}
	public String gethErorDtctdDd() {
		return hErorDtctdDd;
	}
	public void sethErorDtctdDd(String hErorDtctdDd) {
		this.hErorDtctdDd = hErorDtctdDd;
	}
	public String gethRqstAginDd() {
		return hRqstAginDd;
	}
	public void sethRqstAginDd(String hRqstAginDd) {
		this.hRqstAginDd = hRqstAginDd;
	}
	public String getgRqstDd() {
		return gRqstDd;
	}
	public void setgRqstDd(String gRqstDd) {
		this.gRqstDd = gRqstDd;
	}
	public String getgPlandDvrlDd() {
		return gPlandDvrlDd;
	}
	public void setgPlandDvrlDd(String gPlandDvrlDd) {
		this.gPlandDvrlDd = gPlandDvrlDd;
	}
	public String getgErorDtctdDd() {
		return gErorDtctdDd;
	}
	public void setgErorDtctdDd(String gErorDtctdDd) {
		this.gErorDtctdDd = gErorDtctdDd;
	}
	public String getgRqstAginDd() {
		return gRqstAginDd;
	}
	public void setgRqstAginDd(String gRqstAginDd) {
		this.gRqstAginDd = gRqstAginDd;
	}
	public String getReRqstDd() {
		return reRqstDd;
	}
	public void setReRqstDd(String reRqstDd) {
		this.reRqstDd = reRqstDd;
	}
	public String getCtnzInfrd() {
		return ctnzInfrd;
	}
	public void setCtnzInfrd(String ctnzInfrd) {
		this.ctnzInfrd = ctnzInfrd;
	}
	public String gethCrdReisuDueDd() {
		return hCrdReisuDueDd;
	}
	public void sethCrdReisuDueDd(String hCrdReisuDueDd) {
		this.hCrdReisuDueDd = hCrdReisuDueDd;
	}
	public String getgCrdReisuDueDd() {
		return gCrdReisuDueDd;
	}
	public void setgCrdReisuDueDd(String gCrdReisuDueDd) {
		this.gCrdReisuDueDd = gCrdReisuDueDd;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCrdReisuDueDd() {
		return crdReisuDueDd;
	}
	public void setCrdReisuDueDd(String crdReisuDueDd) {
		this.crdReisuDueDd = crdReisuDueDd;
	}
	public String gethPrsntDd() {
		return hPrsntDd;
	}
	public void sethPrsntDd(String hPrsntDd) {
		this.hPrsntDd = hPrsntDd;
	}
	public String getgPrsntDd() {
		return gPrsntDd;
	}
	public void setgPrsntDd(String gPrsntDd) {
		this.gPrsntDd = gPrsntDd;
	}
	public String getUdtWrkCd() {
		return udtWrkCd;
	}
	public void setUdtWrkCd(String udtWrkCd) {
		this.udtWrkCd = udtWrkCd;
	}
	public String getSgnt() {
		return sgnt;
	}
	public void setSgnt(String sgnt) {
		this.sgnt = sgnt;
	}
	public String getTrxID() {
		return trxID;
	}
	public void setTrxID(String trxID) {
		this.trxID = trxID;
	}
	public String getBsnMsg() {
		return bsnMsg;
	}
	public void setBsnMsg(String bsnMsg) {
		this.bsnMsg = bsnMsg;
	}
	public String getBsnMsgNo() {
		return bsnMsgNo;
	}
	public void setBsnMsgNo(String bsnMsgNo) {
		this.bsnMsgNo = bsnMsgNo;
	}
	public String[] getOficSgntList() {
		return oficSgntList;
	}
	public void setOficSgntList(String[] oficSgntList) {
		this.oficSgntList = oficSgntList;
	}
	public String[] getRsdtSeqNoList() {
		return rsdtSeqNoList;
	}
	public void setRsdtSeqNoList(String[] rsdtSeqNoList) {
		this.rsdtSeqNoList = rsdtSeqNoList;
	}
	public String[] getRsdtNoList() {
		return rsdtNoList;
	}
	public void setRsdtNoList(String[] rsdtNoList) {
		this.rsdtNoList = rsdtNoList;
	}
	public String[] getOficSgntAllList() {
		return oficSgntAllList;
	}
	public void setOficSgntAllList(String[] oficSgntAllList) {
		this.oficSgntAllList = oficSgntAllList;
	}
	public String[] getRsdtSeqNoAllList() {
		return rsdtSeqNoAllList;
	}
	public void setRsdtSeqNoAllList(String[] rsdtSeqNoAllList) {
		this.rsdtSeqNoAllList = rsdtSeqNoAllList;
	}
	public String[] getRsdtNoAllList() {
		return rsdtNoAllList;
	}
	public void setRsdtNoAllList(String[] rsdtNoAllList) {
		this.rsdtNoAllList = rsdtNoAllList;
	}
	public String[] getCrdDitbSeqNoAllList() {
		return crdDitbSeqNoAllList;
	}
	public void setCrdDitbSeqNoAllList(String[] crdDitbSeqNoAllList) {
		this.crdDitbSeqNoAllList = crdDitbSeqNoAllList;
	}
	public String[] getCrdDitbSeqNoList() {
		return crdDitbSeqNoList;
	}
	public void setCrdDitbSeqNoList(String[] crdDitbSeqNoList) {
		this.crdDitbSeqNoList = crdDitbSeqNoList;
	}
	public String[] getLcaPrcssCddYn() {
		return lcaPrcssCddYn;
	}
	public void setLcaPrcssCddYn(String[] lcaPrcssCddYn) {
		this.lcaPrcssCddYn = lcaPrcssCddYn;
	}
	public String getCrdDitbCdNm() {
		return crdDitbCdNm;
	}
	public void setCrdDitbCdNm(String crdDitbCdNm) {
		this.crdDitbCdNm = crdDitbCdNm;
	}


}
