package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.rm.crd.service.CrdRnwlCddVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This class is Database Access Object of eNID Card Renewal Candidate List
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04`
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.04  		BH Choi         		Create
 *
 * </pre>
 */
@Repository("crdRnwlCddDAO")
public class CrdRnwlCddDAO extends EgovAbstractDAO {
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }

	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(CrdRnwlCddVO).
	 * @return List<EgovMap> Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListCrdRnwlCdd(CrdRnwlCddVO vo) throws Exception{
		return list("crdRnwlCddDAO.selectListCrdRnwlCdd", vo);
	}

	/**
	 * DAO-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdRnwlCddVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListCrdRnwlCddTotCn(CrdRnwlCddVO vo) {
        return (Integer)selectByPk("crdRnwlCddDAO.selectListCrdRnwlCddTotCn", vo);
    }
	/**
	 * DAO-method for retrieving convert expire date for search list as calendar type. <br>
	 *
	 * @param vo Input item for retrieving convert expire date for search list as calendar type.(CrdRnwlCddVO).
	 * @return String converted date
	 * @exception Exception
	 */    
    public String selectDdCvt(CrdRnwlCddVO vo) {
        return (String)selectByPk("crdRnwlCddDAO.selectDdCvt", vo);
    }

    /**
	 * DAO-method for Card Renewal Candidate List to download Excel. <br>
	 * 
	 * @param vo Input item for retrieving Card Renewal Candidate List(CrdRnwlCddVO).
	 * @return List<EgovMap> Retrieve list information of program
	 * @exception Exception
	 */    
    @SuppressWarnings("unchecked")
	public List<CrdRnwlCddVO> selectListCrdRnwlCddExcel(CrdRnwlCddVO vo) {
        return list("crdRnwlCddDAO.selectListCrdRnwlCddExcel", vo);
    }
}
