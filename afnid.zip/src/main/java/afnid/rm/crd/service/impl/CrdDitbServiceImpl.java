package afnid.rm.crd.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.pkiif.cpki.CpkiRmWS;
import afnid.pkiif.cpki.CpkiRmWSService;
import afnid.pkiif.cpki.PkiRsWsResponse;
import afnid.rm.crd.service.CrdDitbService;
import afnid.rm.crd.service.CrdDitbVO;
import afnid.rm.rsdt.service.RsdtInfrService;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of Card Distribution.
 * and implements CrdDitbService class.
 * 
 * @author Afghanistan National ID Card System Application Team Daesung Kim
 * @since 2013.09.26
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           		Revisions
 *   2013.09.26  		Daesung Kim         		Create
 *
 * </pre>
 */
@Service("crdDitbService")
public class CrdDitbServiceImpl extends AbstractServiceImpl implements CrdDitbService {
	/** CrdDitbDAO */
    @Resource(name="crdDitbDAO")
    private CrdDitbDAO dao;
    
    
	@Resource(name="lgDAO")
    private LgDAO lgDAO;
	
    /** rsdtInfoDAO */
    @Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtDao;
    
    /** RsdtInfrService */
    @Resource(name = "rsdtInfoService")
    private RsdtInfrService rsdtInfrService;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
            
    
    /**
   	 * Biz-method for retrieving list of citizen card application status. <br>
   	 *
   	 * @param vo Input item for retrieving information of citizen card application status.(CrdDitbVO).
   	 * @return List Retrieve information of citizen card application status.
   	 * @exception Exception
   	 */
   	public CrdDitbVO searchRsdtCrdApplyStus(CrdDitbVO vo) throws Exception {
   	
		CrdDitbVO crdIdfcInfr = dao.selectRsdtCrdApplyStus(vo);
		
   		return crdIdfcInfr;
   	}
    
    /**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CrdDitbVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public CrdDitbVO searchCrdDitbIdfcIndiInfr(CrdDitbVO vo) throws Exception {
   	
		CrdDitbVO crdIdfcInfr = dao.selectCrdDitbIdfcIndiInfr(vo);
		
   		return crdIdfcInfr;
   	}
    
   	/**
   	 * Biz-method for retrieving Citizen Revocation Status. <br>
   	 *
   	 * @param vo Input item for retrieving Citizen Revocation Status.(CrdDitbVO).
   	 * @return String Revocation Status Message
   	 * @exception Exception
   	 */
   	public String searchRsdtRvctgStus(CrdDitbVO vo) throws Exception {
   		String msg = "";
		EgovMap eMap  = dao.selectRsdtRvctgStus(vo);
		String rsdtStusCd =NidStringUtil.nullConvert(eMap.get("rsdtStusCd"));
		String isNotApl = NidStringUtil.nullConvert(eMap.get("isNotApl"));
		if(!"1".equals(rsdtStusCd)){
			msg = NidStringUtil.nullConvert(eMap.get("ersrCdNm"));
			if("".equals(msg)){
				msg = nidMessageSource.getMessage("rvctg");
			}
		}else{
			if("N".equals(isNotApl)){
				msg = nidMessageSource.getMessage("rvctgApl");
			}
		}
				
   		return msg;
   	}
   	
   	/**
   	 * Biz-method for retrieving Citizen Rehabilitation Information. <br>
   	 *
   	 * @param rsdtSeqNo Input item for retrieving Citizen Rehabilitation Information.(String).
   	 * @return String Rehabilitation Status
   	 * @exception Exception
   	 */
   	public String searchRsdtRhbltInfr(String rsdtSeqNo) throws Exception {
		int count  = dao.selectRsdtRhbltInfr(rsdtSeqNo);
		String isRhblt  = "N";
		if( 0 < count){
			isRhblt = "Y";
		}
			
   		return isRhblt;
   	}
   	
   	/**
	 * Biz-method for registering information of program. <br>
	 * 
	 * @param vo Input item for registering information of program.(CrdDitbVO).
	 * @return 
	 * @exception Exception
	 */
	public void modifyCrdDisuseOnIdfcIndi(CrdDitbVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());// Setting User ID
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		
		vo.setCrdDitbCd("3");

		if(vo.getCrdDitbUserId() == null || "".equals(vo.getCrdDitbUserId())){

			vo.setCrdDitbDd(vo.getIdfcDd());
			vo.setCrdDitbUserId(vo.getIdfcUserId());
		}
		
		
		boolean result = dao.updateCrdDsuseInfr(vo);
		
		if(!result){
			throw processException( "udtFail.msg");
		}
	}
   	
	/**
	 * Biz-method for registering information of program. <br>
	 * 
	 * @param vo Input item for registering information of program.(CrdDitbVO).
	 * @return 
	 * @exception Exception
	 */
	public void modifyCrdDitbIdfcIndiInfr(CrdDitbVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());// Setting User ID
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		
		boolean result = dao.updateCrdDitbIdfcIndiInfr(vo);
		
		if(!result){
			throw processException( "udtFail.msg");
		}
	}
	
	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CrdDitbVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public CrdDitbVO searchCrdDitbIndiInfr(CrdDitbVO vo) throws Exception {
      	
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setCrdDitbOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()); // Setting Organization Code
		CrdDitbVO crdDitbInfr = dao.selectCrdDitbIndiInfr(vo);
		
			if(crdDitbInfr != null){
			
				crdDitbInfr.setCrdDitbOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());
				crdDitbInfr.setCrdDitbUserId(user.getUserId());
				crdDitbInfr.setCrdDitbUserIdNm(user.getNm());
			
				String userLang = user.getUseLangCd();
				if("1".equals(userLang)){
					crdDitbInfr.setCrdDitbOrgnzCdNm(user.getPstOrgnzNm());
				}else if("2".equals(userLang)){
					crdDitbInfr.setCrdDitbOrgnzCdNm(user.getDrOrgnzNm());
				}else if("3".equals(userLang)){
					crdDitbInfr.setCrdDitbOrgnzCdNm(user.getEnOrgnzNm());
				}else{
					crdDitbInfr.setCrdDitbOrgnzCdNm(user.getPstOrgnzNm());
				}
	
		}		
		
   		return crdDitbInfr;
   	}
   	
   	/**
	 * Biz-method for registering information of program. <br>
	 * 
	 * @param vo Input item for registering information of program.(CrdDitbVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyCrdDitbIndiInfr(CrdDitbVO vo) throws Exception {
		          
		String lgSeqNo ="";
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());// Setting User ID
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		
		String enid = vo.getRsdtNo();
		
		//Insert RM_RSDT_TB History
		rsdtDao.insertRsdtInfrHst(vo.getRsdtSeqNo(), user.getUserId());
		
		boolean result = dao.updateCrdDitbInfr(vo);
		
		if(!result){
			throw processException( "udtFail.msg");
		}

		//Update Signature Data to RM_RSDT_TB
		rsdtInfrService.updateDigitalSgnt(vo.getRsdtSeqNo(), vo.getSgntDat(), "10");
		
		//get PKI cert issuance count
		int crtisuceCn = rsdtInfrService.searchPkiCrtIsuceCn(vo.getRsdtSeqNo());
		
		if(0 < crtisuceCn){
		    
		    //Insert PKI log
		    lgSeqNo = lgDAO.insertPubKeyIfLg(user.getUserId(), enid, "2", "1", "10", "");
		
		}
		
		return lgSeqNo;
	}
   	
	/**
	 * Biz-method for registering information of new user(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for registering new user(CrdDitbVO).
	 * @return CrdDitbVO Primary Key value of registered user
	 * @exception Exception
	 */
	public String modifyCrdDitbIndiInfrPkiIf(CrdDitbVO vo) throws Exception {
		
		String status = "";
		String erorYn ="Y";
		
		//PKI Cert Unhold
		CpkiRmWSService orws= new CpkiRmWSService();
		CpkiRmWS orw = orws.getCpkiRmWSPort();	
			
		PkiRsWsResponse prwr = orw.cpkiIFcertUnHold(vo.getRsdtNo());
		status= prwr.getStatusCode();
		log.debug("status ====> " + status);
		
		if("0".equals(status)){
			erorYn ="N";
		}
		
		lgDAO.updatePubKeyIfLg(vo.getLgSeqNo(), status, erorYn);			
		
		
    	return status;
    	
	}	
    /**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CrdDitbVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public CrdDitbVO searchFmlyHadInfr(CrdDitbVO vo) throws Exception {
      	
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		
		CrdDitbVO hadInfr = dao.selectFmlyHadInfr(vo);
		if(hadInfr != null){
			
			hadInfr.setCrdDitbOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());
			hadInfr.setCrdDitbUserId(user.getUserId());
			hadInfr.setCrdDitbUserIdNm(user.getNm());
			
			String userLang = user.getUseLangCd();
			if("1".equals(userLang)){
				hadInfr.setCrdDitbOrgnzCdNm(user.getPstOrgnzNm());
			}else if("2".equals(userLang)){
				hadInfr.setCrdDitbOrgnzCdNm(user.getDrOrgnzNm());
			}else if("3".equals(userLang)){
				hadInfr.setCrdDitbOrgnzCdNm(user.getEnOrgnzNm());
			}else{
				hadInfr.setCrdDitbOrgnzCdNm(user.getPstOrgnzNm());
			}
	
		}		
   		return hadInfr;
   	}
	
   	
   	/**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdDitbVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<CrdDitbVO> searchFmlyMberCrdApplyStus(CrdDitbVO vo) throws Exception {
  	
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
	
		List<CrdDitbVO> fmlyInfr = dao.selectListFmlyMberCrdApplyStus(vo);
		
		return fmlyInfr;
	}
   	
   	 /**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdDitbVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<CrdDitbVO> searchCrdDitbIdfcFmlyInfr(CrdDitbVO vo) throws Exception {
  	
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
	
		List<CrdDitbVO> fmlyInfr = dao.selectListCrdDitbIdfcFmlyMber(vo);
		
		return fmlyInfr;
	}
	
	/**
	 * Biz-method for retrieving head of family rehabilitation information. <br>
	 *
	 * @param rsdtNo Citizen eNid Number for retrieving head of family rehabilitation information.(String).
	 * @param fmlyInfr Input item for retrieving head of family rehabilitation information.(List<CrdDitbVO>)
	 * @return String head of family rehabilitation status
	 * @exception Exception
	 */
	public String searchFmlyHadRhbltInfr(String RsdtNo, List<CrdDitbVO> fmlyInfr) throws Exception {
		String crdDitbSeqNo = "";
		CrdDitbVO vo= null;
		String FmlyHadRsdtSeqNo = ""; 
		for(int i = 0; i<fmlyInfr.size(); i++){
			vo = fmlyInfr.get(i);
			if(RsdtNo.equals(vo.getRsdtNo()) && !"Y".equals(vo.getIdfcYn()) && "1".equals(vo.getCrdIsuceStusCd()) ){
				FmlyHadRsdtSeqNo = vo.getRsdtSeqNo();
				crdDitbSeqNo = vo.getCrdDitbSeqNo();
				break;
			} 
		}

		if(!"".equals(FmlyHadRsdtSeqNo)){
			int count  = dao.selectRsdtRhbltInfr(FmlyHadRsdtSeqNo);

			if(0 >= count){
				crdDitbSeqNo = "";
			}
		}

		return crdDitbSeqNo;
	}
	
  	 /**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdDitbVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<CrdDitbVO> searchCrdDitbFmlyInfr(CrdDitbVO vo) throws Exception {
  	
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		vo.setCrdDitbOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()); // Setting Organization Code
	
		List<CrdDitbVO> fmlyInfr = dao.selectListCrdDitbFmlyMber(vo);
		
		return fmlyInfr;
	}
  	
    /**
	 * Biz-method for registering information of program. <br>
	 * 
	 * @param vo Input item for registering information of program.(CrdDitbVO).
	 * @return 
	 * @exception Exception
	 */
	public void modifyCrdDitbIdfcFmlyInfr(CrdDitbVO vo) throws Exception {
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());// Setting User ID
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		
		List<String> rsdtNoList = vo.getRsdtNoList();
		if(null != rsdtNoList&& 0 != rsdtNoList.size()){
			String crdDitbSeqNo ="";
			String rsdtNo = "";
			String fmlyHadYn = "";
			
			for(int i = 0; i< rsdtNoList.size(); i++ ){
				crdDitbSeqNo = rsdtNoList.get(i).split(",")[0];
				rsdtNo       = rsdtNoList.get(i).split(",")[1];
				fmlyHadYn    = rsdtNoList.get(i).split(",")[2];
				
				vo.setCrdDitbSeqNo(crdDitbSeqNo);
				vo.setRsdtNo(rsdtNo);
				vo.setFmlyHadYn(fmlyHadYn);
				boolean ditbResult = dao.updateCrdDitbIdfcFmlyInfr(vo);
				
				if(!ditbResult){
					throw processException( "udtFail.msg");
				}
			}
		}
		
		if(null != vo.getDsuseDitbSeqList()&& 0 != vo.getDsuseDitbSeqList().size()){
			
			vo.setCrdDitbCd("3");
			vo.setCrdDitbDd(vo.getIdfcDd());
			vo.setCrdDitbUserId(vo.getIdfcUserId());
			
			List<String> dsuseDitbSeqList= vo.getDsuseDitbSeqList();
			List<String> dsuseRsdtList= vo.getDsuseRsdtList();
			
			for(int i = 0; i < dsuseDitbSeqList.size();i++ ){
				vo.setCrdDitbSeqNo(dsuseDitbSeqList.get(i));
				vo.setRsdtNo(dsuseRsdtList.get(i));
				boolean dsuseResult = dao.updateCrdDsuseInfr(vo);
				
				if(!dsuseResult){
					throw processException( "udtFail.msg");
				}
			}
		}
	}
	
	/**
	 * Biz-method for registering information of program. <br>
	 * 
	 * @param vo Input item for registering information of program.(CrdDitbVO).
	 * @return 
	 * @exception Exception
	 */
	public CrdDitbVO modifyCrdDitbFmlyInfr(CrdDitbVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUserId(user.getUserId());// Setting User ID
		vo.setLstUdtUserId(user.getUserId());// Setting User ID
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		
		if(null != vo.getDsuseDitbSeqList()&& 0 != vo.getDsuseDitbSeqList().size()){
			
			vo.setCrdDitbCd("3");		
			List<String> dsuseDitbSeqList= vo.getDsuseDitbSeqList();
			List<String> dsuseRsdtList= vo.getDsuseRsdtList();
			
			for(int i = 0; i < dsuseDitbSeqList.size();i++ ){
				vo.setCrdDitbSeqNo(dsuseDitbSeqList.get(i));
				vo.setRsdtNo(dsuseRsdtList.get(i));
			
				boolean dsuseResult = dao.updateCrdDsuseInfr(vo);
				
				if(!dsuseResult){
					throw processException( "udtFail.msg");
				}
			}
		}
		
		boolean result;
		String enid;
		String rsdtSeqNo;
		List<String> list           = vo.getRsdtNoList();
		List<String> rsdtSeqList    = vo.getRsdtSeqNoList();
		List<String> crdDitbSeqList = vo.getDitbSeqList();
		List<String> sgntList       = vo.getSgntList();
		ArrayList<String> lgSeqNoList    = new ArrayList<String>() ;
		ArrayList<String> rsdtNoList    = new ArrayList<String>();
		
		vo.setCrdDitbCd("1");
		if(null != list && 0 != list.size()){
			for(int i=0;i < list.size(); i++ ){
				enid = list.get(i);
				rsdtSeqNo = rsdtSeqList.get(i);

				vo.setRsdtNo(enid);
				vo.setRsdtSeqNo(rsdtSeqNo);
				vo.setCrdDitbSeqNo(crdDitbSeqList.get(i));
				log.debug("==================SgntList["+i+"]==============");
    			log.debug(sgntList.get(i));
    			log.debug(enid);
    			log.debug(rsdtSeqNo);
    			log.debug("==================end["+i+"]==============");
				
				//Insert RM_RSDT_TB History
				rsdtDao.insertRsdtInfrHst(vo.getRsdtSeqNo(), user.getUserId());
				
				result = dao.updateCrdDitbInfr(vo);

				if(!result){
					throw processException( "udtFail.msg");
				}
				
				//Update Signature Data to RM_RSDT_TB
				rsdtInfrService.updateDigitalSgnt(vo.getRsdtSeqNo(), sgntList.get(i), "10");
				
				//get PKI cert issuance count
				int crtisuceCn = rsdtInfrService.searchPkiCrtIsuceCn(vo.getRsdtSeqNo());
				
				if( 0 < crtisuceCn){				    
				    //Insert PKI log
					String lgSeqNo=lgDAO.insertPubKeyIfLg(user.getUserId(), enid, "2", "1", "10","");						
					lgSeqNoList.add(lgSeqNo);
					rsdtNoList.add(enid);
				}
				//vo.setLgSeqNoList(lgSeqNoList);
			}
			vo.setRsdtNoList(rsdtNoList);
			vo.setLgSeqNoList(lgSeqNoList);
		}
		
		return vo;
	}
	
	
	/**
	 * Biz-method for registering information of new user(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for registering new user(CcltRhbltVO).
	 * @return CcltRhbltVO Primary Key value of registered user
	 * @exception Exception
	 */
	public String modifyCrdDitbFmlyInfrPkiIf(CrdDitbVO vo) throws Exception {

		String status = "";
		String erorYn ="Y";
		
		//Citizen Account Revocation 
		CpkiRmWSService orws= new CpkiRmWSService();
		CpkiRmWS orw = orws.getCpkiRmWSPort();		
			
		PkiRsWsResponse prwr = orw.cpkiIFcertUnHold(vo.getRsdtNo());
		status= prwr.getStatusCode();
		log.debug("status ====> " + status);
		if("0".equals(status)){
			erorYn ="N";
		}
		
		lgDAO.updatePubKeyIfLg(vo.getLgSeqNo(), status, erorYn);			

    	return status;
    	
	}
	
	
}
