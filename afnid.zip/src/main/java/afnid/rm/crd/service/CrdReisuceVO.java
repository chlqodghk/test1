package afnid.rm.crd.service;

import egovframework.rte.psl.dataaccess.util.EgovMap;
import afnid.cm.ComDefaultVO;

/** 
 * This class is Value Object of Card Lost/ Damage/ Renewal
 * 
 * @author Afghanistan National ID Card System Application Team Daesung Kim
 * @since 2013.06.14
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2013.06.14 		Daesung Kim	      		 		Create
 *
 * </pre>
 */
public class CrdReisuceVO extends ComDefaultVO{
    private static final long serialVersionUID = 1L;
    
    private String aplCd;
    private String afCrdIsucePlceCdNm;
    private String crdIsucePlceCdNm;
    private String crdReisuceYn;
    private String crdIsuceDd;
    private String chngRsnDtlCt;
    private String certNo;
    private String pbctOfic;
    
    private String [] natLangCd;
    private String [] frgnLangCd;
    private String [] natLangCds;
    private String [] frgnLangCds;
    private String lstLangCd;
    
    private String mdfctSeqNo;
    private String bsnSeqNo;
    private String fmlyBokSeqNo;
    private String fmlyBokNo;
    private String fmlyMberNo;
    private String oldCrdNo;
    private String oldCrdIsucePlceCd;
    private String oldCrdIsucePlceNm;
    private String rlCd;
    private String rlCdNm;
    private String enSurnm;
    private String enGivNm;
    private String mthrNm;
    private String fthrRsdtSeqNo;
    private String mthrRsdtSeqNo;
    private String bthPlceCd;
    private String bthPlceCdNm;
    private String bthNatDiv;
    private String bthNatCd;
    private String bthNatCdNm;
    private String frgnBthCtyNm;
    private String bldTyeCd;
    private String bldTyeCdNm;
    private String mrrgCd;
    private String mrrgCdNm;
    private String gdrCd;
    private String encyCd;
    private String encyCdNm;
    private String fmlyLangCd;
    private String fmlyLangCdNm;
    private String secdNltyCd;
    private String secdNltyCdNm;
    private String dsbtCd;
    private String dsbtCdNm;
    private String ocp;
    private String rlgnCd;
    private String rlgnCdNm;
    private String rlgnSectCd;
    private String rlgnSectCdNm;
    private String eduCd;
    private String eduCdNm;
    private String mltSrvcCd;
    private String mltSrvcCdNm;
    private String smrRsdcCd;
    private String smrRsdcCdNm;
    private String wtrRsdcCd;
    private String wtrRsdcCdNm;
    private String fmlyMberMlNo;
    private String fmlyMberFemlNo;
    private String rsdtTyeCd;
    private String rsdtTyeCdNm;
    private String poliCntrSeqNo;
    private String poliCntrSeqNoNm;
    private String oldAge;
    private String calTye;
    private String afFmlyBokNoNum;
    private String afRsdtNoDp;
    private String afPmntAdCdNm;
    private String afCurtAdCdNm;
    private String afBthPlceCdNm;
    private String afSmrRsdcCdNm;
    private String afWtrRsdcCdNm;
    private String afOldCrdIsucePlceNm;
    private String afPoliCntrSeqNoNm;
    private String afRsdtTyeCd;
    private String afRsdtSeqNo;
    private String afFmlyBokSeqNo;
    private String afFmlyBokNo;
    private String afFmlyMberNo;
    private String afOldCrdNo;
    private String afOldCrdIsucePlceCd;
    private String afRsdtNo;
    private String afRlCd;
    private String afRlCdNm;
    private String afGivNm;
    private String afSurnm;
    private String afEnSurnm;
    private String afEnGivNm;
    private String afFthrNm;
    private String afMthrNm;
    private String afFthrRsdtSeqNo;
    private String afMthrRsdtSeqNo;
    private String afGfthrNm;
    private String afBthDd;
    private String afBthPlceCd;
    private String afBthNatDiv;
    private String afBthNatCd;
    private String afFrgnBthCtyNm;
    private String afPmntAdCd;
    private String afPmntAdDtlCt;
    private String afCurtAdCd;
    private String afCurtAdDtlCt;
    private String afBldTyeCd;
    private String afMrrgCd;
    private String afGdrCd;
    private String afEncyCd;
    private String afFmlyLangCd;
    private String afSecdNltyCd;
    private String afDsbtCd;
    private String afOcp;
    private String afRlgnCd;
    private String afRlgnSectCd;
    private String afEduCd;
    private String afMltSrvcCd;
    private String afSmrRsdcCd;
    private String afWtrRsdcCd;
    private String afFmlyMberMlNo;
    private String afFmlyMberFemlNo;
    private String afCrdIsucePlceCd;
    private String afCrdIsuceDd;
    private String afCrdExpiryDd;
    private String afAdChngYn;
    private String afPoliCntrSeqNo;
    private String isAdult;
    private String isExp;
    private String crdPrcssStusCd;
    private String crdReisuceDmBfExpr;
    private String adultAge;
    private String crdExprProd;
    private String eduLvDocYn;
    private String bldTyeDocYn;
    private String afEduLvDocYn;
    private String afBldTyeDocYn;
    private String oldCrdNo1;
    private String oldCrdNo2;
    private String oldCrdNo3;
    private String oldCrdNo4;
    private String afOldCrdNo1;
    private String afOldCrdNo2;
    private String afOldCrdNo3;
    private String afOldCrdNo4;
    private String cntTelNo;
    private String cntTelNo2;
    private String othrCount;
    private String frgnCount;
    private String crdDlvrDd;
    private String rsdtCfmYn;
    private String afGfthrRsdtSeqNo;
    private String gfthrRsdtSeqNo;
    private String aprvListTm;
    private String numFlag;
    private String crdIsuceSrlNo;
    private String emlAd;
    private String curtAdDiv;
    private String curtAdNatCd;
    private String curtAdNatCdNm;
    private String afCurtAdDiv;
    private String afCurtAdNatCd;
    private String afCurtAdNatCdNm;
    private String afCurtAdDtlCtD;
    private String afCurtAdDtlCtF;
    private String eduYn;
    private String afEduYn;
    private String afSecdNltyYn;
    private String secdNltyYn;
    private String ptCd;
    private String sgntCd;
    private String fgpCd;
    private String irisCd;
    private String lgSeqNo;
    private String dsuseMsg;
    private String foundCrdFlag;
    private String fondCrdSeqNo;
    private String sndTamLedrCfmYn;
    private String enNm;
    private String othrRsnCd;
    private String oldCrdIsuceDd;
    private String afOldCrdIsuceDd;
    private EgovMap bioMap;
    private String othrRl;
    private String afOthrRl;
    
	/** RSDT_INFR_CHNG_YN */
    private String rsdtInfrChngYn;
    
    /** Check flag for page status(N:New Registration, E: Edit  ) */
    private java.lang.String pageFlag;
   
    /** Error code for check resident status*/
    private java.lang.String errCd;
    
    /** Error Message for check resident status*/
    private java.lang.String errMsg;
    
    /** RSDT_SEQ_NO */
    private java.lang.String rsdtSeqNo;
    
    /** RSDT_NO */
    private java.lang.String rsdtNo;
    
    /** Resident NID Number */
    private java.lang.String rsdtNoDp;

    /** FMLY_BOK_NO */
    private java.lang.String fmlyBokNoDp;
    
    /** SURNM */
    private java.lang.String surnm;
    
    /** GIV_NM */
    private java.lang.String givNm;
    
    /** FTHR_GIV_NM */
    private java.lang.String fthrNm;
    
    /** GFTHR_GIV_NM */
    private java.lang.String gfthrNm;
    
    /** BTH_DD */
    private java.lang.String bthDd;
    private java.lang.String hBthDd;
    private java.lang.String gBthDd;
      
    /** Gender Code Name */
    private java.lang.String gdrCdNm;
    
    /** PMNT_AD_CD */
    private java.lang.String pmntAdCd;
    
    /** Present Address Name */
    private java.lang.String pmntAdCdNm;
    
    /** PMNT_AD_DTL_CT */
    private java.lang.String pmntAdDtlCt;
    
    /** CURT_AD_CD */
    private java.lang.String curtAdCd;
    
    /** Present Address Name */
    private java.lang.String curtAdCdNm;
    
    /** CURT_AD_DTL_CT */
    private java.lang.String curtAdDtlCt;
    
    /** RSDT_STUS_CD */
    private java.lang.String rsdtStusCd;
    
    /** BIO_KEY */
    private java.lang.String bioKey;
    
    /** BIO_KEY */
    private java.lang.String nextBioKey;
        
    /** BIO_CHNG_YN */
    private java.lang.String bioChngYn;
    
    /** FST_RGST_USER_ID */
    private java.lang.String fstRgstUserId;
    
    /** FST_RGST_DT */
    private java.lang.String fstRgstDt;
    
    /** LST_UDT_USER_ID */
    private java.lang.String lstUdtUserId;
    
    /** LST_UDT_DT */
    private java.lang.String lstUdtDt;
            
    /** Card Reissuance Reason Code */
    private java.lang.String rsnCd;
    
    /** Card Reissuance Reason Code Name */
    private java.lang.String rsnCdNm;
 
    /** CRD_DITB_CD */
    private java.lang.String crdDitbCd;
    
    /** DLVR_DD */
    private java.lang.String crdDitbDd;
    
    /** CRD_REISU_SEQ_NO */
    private java.lang.String crdReisuSeqNo;
    
    /** OCRNC_DD */
    private java.lang.String ocrncDd;
    
    /** RSN_DTL_CT */
    private java.lang.String rsnDtlCt;
    
    /** RGST_ORGNZ_CD */
    private java.lang.String rgstOrgnzCd;
    
    /** RGST_ORGNZ_CD Name */
    private java.lang.String rgstOrgnzCdNm;
    
    /** RCIV_ORGNZ_CD */
    private java.lang.String rcivOrgnzCd;
    
    /** RCIV_ORGNZ_CD Name */
    private java.lang.String rcivOrgnzCdNm;
    
    /** SND_ORGNZ_CD */
    private java.lang.String sndOrgnzCd;
    
    /** SND_ORGNZ_CD Name */
    private java.lang.String sndOrgnzCdNm;
    
    /** TAM_LEDR_CFM_YN */
    private java.lang.String tamLedrCfmYn;
    
    /** CFM_TAM_LEDR_ID */
    private java.lang.String cfmTamLedrId;
    
    /** BIO Duplication flag */
    private java.lang.String dptYn;
    
    /** CRD_REISUCE_DUE_DD */
    private java.lang.String crdReisuceDueDd;
    
    /** CRD_REISUCE_DD */
    private java.lang.String crdReisuceDd;
    
    /** CRD_EXPIRY_DD */
    private java.lang.String crdExpiryDd;
  
	/** Date of application */
    private java.lang.String appDd;
    
    /** CRD_ISUCE_YN */
    private java.lang.String crdIsuceYn;
    
    /** Card Expired Month */
    private java.lang.String expMd;
    
    /** Edit Bio Information Y/n */
    private java.lang.String clickBioYn;
    
    /**Signature Data  */
    private java.lang.String sgntDat;
    
    /**Bio Information*/
    private java.lang.String bioInfr;
    
    /**User Id*/
    private java.lang.String userId;
    
    /**Duplication Check Y/N*/
    private java.lang.String dupCheckYn;
    
    /**CRD_ISUCE_PLCE_CD*/
    private java.lang.String crdIsucePlceCd;
    
    /**SND_FOND_CRD_STUS_CD*/
    private java.lang.String sndFondCrdStusCd;
    
    
	public EgovMap getBioMap() {
		return bioMap;
	}

	public void setBioMap(EgovMap bioMap) {
		this.bioMap = bioMap;
	}

	public String getOldCrdIsuceDd() {
		return oldCrdIsuceDd;
	}

	public void setOldCrdIsuceDd(String oldCrdIsuceDd) {
		this.oldCrdIsuceDd = oldCrdIsuceDd;
	}

	public String getAfOldCrdIsuceDd() {
		return afOldCrdIsuceDd;
	}

	public void setAfOldCrdIsuceDd(String afOldCrdIsuceDd) {
		this.afOldCrdIsuceDd = afOldCrdIsuceDd;
	}

	public String getOthrRsnCd() {
		return othrRsnCd;
	}

	public void setOthrRsnCd(String othrRsnCd) {
		this.othrRsnCd = othrRsnCd;
	}

	public String getFgpCd() {
		return fgpCd;
	}

	public void setFgpCd(String fgpCd) {
		this.fgpCd = fgpCd;
	}

	public String getIrisCd() {
		return irisCd;
	}

	public void setIrisCd(String irisCd) {
		this.irisCd = irisCd;
	}

	public String getEnNm() {
		return enNm;
	}

	public void setEnNm(String enNm) {
		this.enNm = enNm;
	}

	public String getSndTamLedrCfmYn() {
		return sndTamLedrCfmYn;
	}

	public void setSndTamLedrCfmYn(String sndTamLedrCfmYn) {
		this.sndTamLedrCfmYn = sndTamLedrCfmYn;
	}

	public String getFondCrdSeqNo() {
		return fondCrdSeqNo;
	}

	public void setFondCrdSeqNo(String fondCrdSeqNo) {
		this.fondCrdSeqNo = fondCrdSeqNo;
	}

	public String getFoundCrdFlag() {
		return foundCrdFlag;
	}

	public void setFoundCrdFlag(String foundCrdFlag) {
		this.foundCrdFlag = foundCrdFlag;
	}

	public String getDsuseMsg() {
		return dsuseMsg;
	}

	public void setDsuseMsg(String dsuseMsg) {
		this.dsuseMsg = dsuseMsg;
	}

	public String getCntTelNo2() {
		return cntTelNo2;
	}

	public void setCntTelNo2(String cntTelNo2) {
		this.cntTelNo2 = cntTelNo2;
	}

	public String getAfRlCdNm() {
		return afRlCdNm;
	}

	public void setAfRlCdNm(String afRlCdNm) {
		this.afRlCdNm = afRlCdNm;
	}

	public String getPtCd() {
		return ptCd;
	}

	public void setPtCd(String ptCd) {
		this.ptCd = ptCd;
	}

	public String getSgntCd() {
		return sgntCd;
	}

	public void setSgntCd(String sgntCd) {
		this.sgntCd = sgntCd;
	}

	public String getEduYn() {
		return eduYn;
	}

	public void setEduYn(String eduYn) {
		this.eduYn = eduYn;
	}

	public String getAfEduYn() {
		return afEduYn;
	}

	public void setAfEduYn(String afEduYn) {
		this.afEduYn = afEduYn;
	}

	public String getAfSecdNltyYn() {
		return afSecdNltyYn;
	}

	public void setAfSecdNltyYn(String afSecdNltyYn) {
		this.afSecdNltyYn = afSecdNltyYn;
	}

	public String getSecdNltyYn() {
		return secdNltyYn;
	}

	public void setSecdNltyYn(String secdNltyYn) {
		this.secdNltyYn = secdNltyYn;
	}

	public String getAfCurtAdDtlCtD() {
		return afCurtAdDtlCtD;
	}

	public void setAfCurtAdDtlCtD(String afCurtAdDtlCtD) {
		this.afCurtAdDtlCtD = afCurtAdDtlCtD;
	}

	public String getAfCurtAdDtlCtF() {
		return afCurtAdDtlCtF;
	}

	public void setAfCurtAdDtlCtF(String afCurtAdDtlCtF) {
		this.afCurtAdDtlCtF = afCurtAdDtlCtF;
	}

	public String getAfCurtAdDiv() {
		return afCurtAdDiv;
	}

	public void setAfCurtAdDiv(String afCurtAdDiv) {
		this.afCurtAdDiv = afCurtAdDiv;
	}

	public String getAfCurtAdNatCd() {
		return afCurtAdNatCd;
	}

	public void setAfCurtAdNatCd(String afCurtAdNatCd) {
		this.afCurtAdNatCd = afCurtAdNatCd;
	}

	public String getAfCurtAdNatCdNm() {
		return afCurtAdNatCdNm;
	}

	public void setAfCurtAdNatCdNm(String afCurtAdNatCdNm) {
		this.afCurtAdNatCdNm = afCurtAdNatCdNm;
	}

	public String getCurtAdDiv() {
		return curtAdDiv;
	}

	public void setCurtAdDiv(String curtAdDiv) {
		this.curtAdDiv = curtAdDiv;
	}

	public String getCurtAdNatCd() {
		return curtAdNatCd;
	}

	public void setCurtAdNatCd(String curtAdNatCd) {
		this.curtAdNatCd = curtAdNatCd;
	}

	public String getCurtAdNatCdNm() {
		return curtAdNatCdNm;
	}

	public void setCurtAdNatCdNm(String curtAdNatCdNm) {
		this.curtAdNatCdNm = curtAdNatCdNm;
	}

	public String getEmlAd() {
		return emlAd;
	}

	public void setEmlAd(String emlAd) {
		this.emlAd = emlAd;
	}

	public String getOldCrdIsucePlceCd() {
		return oldCrdIsucePlceCd;
	}

	public void setOldCrdIsucePlceCd(String oldCrdIsucePlceCd) {
		this.oldCrdIsucePlceCd = oldCrdIsucePlceCd;
	}

	public String getAfOldCrdIsucePlceCd() {
		return afOldCrdIsucePlceCd;
	}

	public void setAfOldCrdIsucePlceCd(String afOldCrdIsucePlceCd) {
		this.afOldCrdIsucePlceCd = afOldCrdIsucePlceCd;
	}

	public String getOldCrdNo4() {
		return oldCrdNo4;
	}

	public void setOldCrdNo4(String oldCrdNo4) {
		this.oldCrdNo4 = oldCrdNo4;
	}

	public String getAfOldCrdNo4() {
		return afOldCrdNo4;
	}

	public void setAfOldCrdNo4(String afOldCrdNo4) {
		this.afOldCrdNo4 = afOldCrdNo4;
	}

	public String getCrdIsuceSrlNo() {
		return crdIsuceSrlNo;
	}

	public void setCrdIsuceSrlNo(String crdIsuceSrlNo) {
		this.crdIsuceSrlNo = crdIsuceSrlNo;
	}

	public String getNumFlag() {
		return numFlag;
	}

	public void setNumFlag(String numFlag) {
		this.numFlag = numFlag;
	}

	public String getAprvListTm() {
		return aprvListTm;
	}

	public void setAprvListTm(String aprvListTm) {
		this.aprvListTm = aprvListTm;
	}

	public String getAfGfthrRsdtSeqNo() {
		return afGfthrRsdtSeqNo;
	}

	public void setAfGfthrRsdtSeqNo(String afGfthrRsdtSeqNo) {
		this.afGfthrRsdtSeqNo = afGfthrRsdtSeqNo;
	}

	public String getGfthrRsdtSeqNo() {
		return gfthrRsdtSeqNo;
	}

	public void setGfthrRsdtSeqNo(String gfthrRsdtSeqNo) {
		this.gfthrRsdtSeqNo = gfthrRsdtSeqNo;
	}

	public String getRsdtCfmYn() {
		return rsdtCfmYn;
	}

	public void setRsdtCfmYn(String rsdtCfmYn) {
		this.rsdtCfmYn = rsdtCfmYn;
	}

	public String getCrdDlvrDd() {
		return crdDlvrDd;
	}

	public void setCrdDlvrDd(String crdDlvrDd) {
		this.crdDlvrDd = crdDlvrDd;
	}

	public String getRlCdNm() {
		return rlCdNm;
	}

	public void setRlCdNm(String rlCdNm) {
		this.rlCdNm = rlCdNm;
	}

	public String getPoliCntrSeqNoNm() {
		return poliCntrSeqNoNm;
	}

	public void setPoliCntrSeqNoNm(String poliCntrSeqNoNm) {
		this.poliCntrSeqNoNm = poliCntrSeqNoNm;
	}

	public String getOldCrdIsucePlceNm() {
		return oldCrdIsucePlceNm;
	}

	public void setOldCrdIsucePlceNm(String oldCrdIsucePlceNm) {
		this.oldCrdIsucePlceNm = oldCrdIsucePlceNm;
	}

	public String getMltSrvcCdNm() {
		return mltSrvcCdNm;
	}

	public void setMltSrvcCdNm(String mltSrvcCdNm) {
		this.mltSrvcCdNm = mltSrvcCdNm;
	}

	public String getRlgnSectCdNm() {
		return rlgnSectCdNm;
	}

	public void setRlgnSectCdNm(String rlgnSectCdNm) {
		this.rlgnSectCdNm = rlgnSectCdNm;
	}
    public String getEncyCdNm() {
		return encyCdNm;
	}

	public void setEncyCdNm(String encyCdNm) {
		this.encyCdNm = encyCdNm;
	}

	public String getRlgnCdNm() {
		return rlgnCdNm;
	}

	public void setRlgnCdNm(String rlgnCdNm) {
		this.rlgnCdNm = rlgnCdNm;
	}

	public String getSecdNltyCdNm() {
		return secdNltyCdNm;
	}

	public void setSecdNltyCdNm(String secdNltyCdNm) {
		this.secdNltyCdNm = secdNltyCdNm;
	}

	public String getDsbtCdNm() {
		return dsbtCdNm;
	}

	public void setDsbtCdNm(String dsbtCdNm) {
		this.dsbtCdNm = dsbtCdNm;
	}

	public String getSmrRsdcCdNm() {
		return smrRsdcCdNm;
	}

	public void setSmrRsdcCdNm(String smrRsdcCdNm) {
		this.smrRsdcCdNm = smrRsdcCdNm;
	}

	public String getWtrRsdcCdNm() {
		return wtrRsdcCdNm;
	}

	public void setWtrRsdcCdNm(String wtrRsdcCdNm) {
		this.wtrRsdcCdNm = wtrRsdcCdNm;
	}

	public String getOthrCount() {
		return othrCount;
	}

	public void setOthrCount(String othrCount) {
		this.othrCount = othrCount;
	}

	public String getFrgnCount() {
		return frgnCount;
	}

	public void setFrgnCount(String frgnCount) {
		this.frgnCount = frgnCount;
	}

	public String getFmlyLangCdNm() {
		return fmlyLangCdNm;
	}

	public void setFmlyLangCdNm(String fmlyLangCdNm) {
		this.fmlyLangCdNm = fmlyLangCdNm;
	}

	public String getMrrgCdNm() {
		return mrrgCdNm;
	}

	public void setMrrgCdNm(String mrrgCdNm) {
		this.mrrgCdNm = mrrgCdNm;
	}

	public String getBldTyeCdNm() {
		return bldTyeCdNm;
	}

	public void setBldTyeCdNm(String bldTyeCdNm) {
		this.bldTyeCdNm = bldTyeCdNm;
	}

	public String getEduCdNm() {
		return eduCdNm;
	}

	public void setEduCdNm(String eduCdNm) {
		this.eduCdNm = eduCdNm;
	}

	public String getRsdtTyeCdNm() {
		return rsdtTyeCdNm;
	}

	public void setRsdtTyeCdNm(String rsdtTyeCdNm) {
		this.rsdtTyeCdNm = rsdtTyeCdNm;
	}

	public String getOldCrdNo1() {
		return oldCrdNo1;
	}

	public void setOldCrdNo1(String oldCrdNo1) {
		this.oldCrdNo1 = oldCrdNo1;
	}

	public String getOldCrdNo2() {
		return oldCrdNo2;
	}

	public void setOldCrdNo2(String oldCrdNo2) {
		this.oldCrdNo2 = oldCrdNo2;
	}

	public String getOldCrdNo3() {
		return oldCrdNo3;
	}

	public void setOldCrdNo3(String oldCrdNo3) {
		this.oldCrdNo3 = oldCrdNo3;
	}

	public String getCntTelNo() {
		return cntTelNo;
	}

	public void setCntTelNo(String cntTelNo) {
		this.cntTelNo = cntTelNo;
	}

	public String getAfOldCrdNo1() {
		return afOldCrdNo1;
	}

	public void setAfOldCrdNo1(String afOldCrdNo1) {
		this.afOldCrdNo1 = afOldCrdNo1;
	}

	public String getAfOldCrdNo2() {
		return afOldCrdNo2;
	}

	public void setAfOldCrdNo2(String afOldCrdNo2) {
		this.afOldCrdNo2 = afOldCrdNo2;
	}

	public String getAfOldCrdNo3() {
		return afOldCrdNo3;
	}

	public void setAfOldCrdNo3(String afOldCrdNo3) {
		this.afOldCrdNo3 = afOldCrdNo3;
	}
	public String getBthPlceCdNm() {
		return bthPlceCdNm;
	}

	public void setBthPlceCdNm(String bthPlceCdNm) {
		this.bthPlceCdNm = bthPlceCdNm;
	}

	public String getBthNatCdNm() {
		return bthNatCdNm;
	}

	public void setBthNatCdNm(String bthNatCdNm) {
		this.bthNatCdNm = bthNatCdNm;
	}

	public String getAfEduLvDocYn() {
		return afEduLvDocYn;
	}

	public void setAfEduLvDocYn(String afEduLvDocYn) {
		this.afEduLvDocYn = afEduLvDocYn;
	}

	public String getAfBldTyeDocYn() {
		return afBldTyeDocYn;
	}

	public void setAfBldTyeDocYn(String afBldTyeDocYn) {
		this.afBldTyeDocYn = afBldTyeDocYn;
	}

	public String getEduLvDocYn() {
		return eduLvDocYn;
	}

	public void setEduLvDocYn(String eduLvDocYn) {
		this.eduLvDocYn = eduLvDocYn;
	}

	public String getBldTyeDocYn() {
		return bldTyeDocYn;
	}

	public void setBldTyeDocYn(String bldTyeDocYn) {
		this.bldTyeDocYn = bldTyeDocYn;
	}

	public String getDsbtCd() {
		return dsbtCd;
	}

	public void setDsbtCd(String dsbtCd) {
		this.dsbtCd = dsbtCd;
	}

	public String getAfDsbtCd() {
		return afDsbtCd;
	}

	public void setAfDsbtCd(String afDsbtCd) {
		this.afDsbtCd = afDsbtCd;
	}

	public String getAfEnSurnm() {
		return afEnSurnm;
	}

	public void setAfEnSurnm(String afEnSurnm) {
		this.afEnSurnm = afEnSurnm;
	}

	public String getAfEnGivNm() {
		return afEnGivNm;
	}

	public void setAfEnGivNm(String afEnGivNm) {
		this.afEnGivNm = afEnGivNm;
	}

	public String getEnSurnm() {
		return enSurnm;
	}

	public void setEnSurnm(String enSurnm) {
		this.enSurnm = enSurnm;
	}

	public String getEnGivNm() {
		return enGivNm;
	}

	public void setEnGivNm(String enGivNm) {
		this.enGivNm = enGivNm;
	}

	public String getAdultAge() {
		return adultAge;
	}

	public void setAdultAge(String adultAge) {
		this.adultAge = adultAge;
	}

	public String getCrdExprProd() {
		return crdExprProd;
	}

	public void setCrdExprProd(String crdExprProd) {
		this.crdExprProd = crdExprProd;
	}
	
    public String getCrdReisuceDmBfExpr() {
		return crdReisuceDmBfExpr;
	}

	public void setCrdReisuceDmBfExpr(String crdReisuceDmBfExpr) {
		this.crdReisuceDmBfExpr = crdReisuceDmBfExpr;
	}
	
	public java.lang.String getExpMd() {
		return expMd;
	}

	public void setExpMd(java.lang.String expMd) {
		this.expMd = expMd;
	}

	public java.lang.String getSndOrgnzCd() {
		return sndOrgnzCd;
	}

	public void setSndOrgnzCd(java.lang.String sndOrgnzCd) {
		this.sndOrgnzCd = sndOrgnzCd;
	}

	public java.lang.String getSndOrgnzCdNm() {
		return sndOrgnzCdNm;
	}

	public void setSndOrgnzCdNm(java.lang.String sndOrgnzCdNm) {
		this.sndOrgnzCdNm = sndOrgnzCdNm;
	}

	public java.lang.String getSndFondCrdStusCd() {
		return sndFondCrdStusCd;
	}

	public void setSndFondCrdStusCd(java.lang.String sndFondCrdStusCd) {
		this.sndFondCrdStusCd = sndFondCrdStusCd;
	}

	public String getCrdPrcssStusCd() {
		return crdPrcssStusCd;
	}

	public void setCrdPrcssStusCd(String crdPrcssStusCd) {
		this.crdPrcssStusCd = crdPrcssStusCd;
	}

	public java.lang.String getRcivOrgnzCd() {
		return rcivOrgnzCd;
	}

	public void setRcivOrgnzCd(java.lang.String rcivOrgnzCd) {
		this.rcivOrgnzCd = rcivOrgnzCd;
	}

	public java.lang.String getRcivOrgnzCdNm() {
		return rcivOrgnzCdNm;
	}

	public void setRcivOrgnzCdNm(java.lang.String rcivOrgnzCdNm) {
		this.rcivOrgnzCdNm = rcivOrgnzCdNm;
	}

	public java.lang.String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(java.lang.String errMsg) {
		this.errMsg = errMsg;
	}

	public String getIsAdult() {
		return isAdult;
	}

	public void setIsAdult(String isAdult) {
		this.isAdult = isAdult;
	}

	public String getIsExp() {
		return isExp;
	}

	public void setIsExp(String isExp) {
		this.isExp = isExp;
	}
    
	public java.lang.String getCrdIsucePlceCd() {
		return crdIsucePlceCd;
	}

	public void setCrdIsucePlceCd(java.lang.String crdIsucePlceCd) {
		this.crdIsucePlceCd = crdIsucePlceCd;
	}

	public java.lang.String getDupCheckYn() {
		return dupCheckYn;
	}

	public void setDupCheckYn(java.lang.String dupCheckYn) {
		this.dupCheckYn = dupCheckYn;
	}

	public java.lang.String getUserId() {
		return userId;
	}

	public void setUserId(java.lang.String userId) {
		this.userId = userId;
	}

	public java.lang.String getBioInfr() {
		return bioInfr;
	}

	public void setBioInfr(java.lang.String bioInfr) {
		this.bioInfr = bioInfr;
	}

	public java.lang.String getSgntDat() {
		return sgntDat;
	}

	public void setSgntDat(java.lang.String sgntDat) {
		this.sgntDat = sgntDat;
	}

	public java.lang.String getAppDd() {
		return appDd;
	}

	public void setAppDd(java.lang.String appDd) {
		this.appDd = appDd;
	}

	public java.lang.String getBioKey() {
		return bioKey;
	}

	public void setBioKey(java.lang.String bioKey) {
		this.bioKey = bioKey;
	}

	public java.lang.String getClickBioYn() {
		return clickBioYn;
	}

	public void setClickBioYn(java.lang.String clickBioYn) {
		this.clickBioYn = clickBioYn;
	}

	public java.lang.String getNextBioKey() {
		return nextBioKey;
	}

	public void setNextBioKey(java.lang.String nextBioKey) {
		this.nextBioKey = nextBioKey;
	}

	public java.lang.String getRgstOrgnzCdNm() {
		return rgstOrgnzCdNm;
	}

	public void setRgstOrgnzCdNm(java.lang.String rgstOrgnzCdNm) {
		this.rgstOrgnzCdNm = rgstOrgnzCdNm;
	}

	public java.lang.String getCrdIsuceYn() {
		return crdIsuceYn;
	}

	public void setCrdIsuceYn(java.lang.String crdIsuceYn) {
		this.crdIsuceYn = crdIsuceYn;
	}

	public java.lang.String getCrdDitbCd() {
		return crdDitbCd;
	}

	public void setCrdDitbCd(java.lang.String crdDitbCd) {
		this.crdDitbCd = crdDitbCd;
	}

	public java.lang.String getCrdDitbDd() {
		return crdDitbDd;
	}

	public void setCrdDitbDd(java.lang.String crdDitbDd) {
		this.crdDitbDd = crdDitbDd;
	}

	public java.lang.String getFmlyBokNoDp() {
		return fmlyBokNoDp;
	}

	public void setFmlyBokNoDp(java.lang.String fmlyBokNoDp) {
		this.fmlyBokNoDp = fmlyBokNoDp;
	}

	public java.lang.String getFthrNm() {
		return fthrNm;
	}

	public void setFthrNm(java.lang.String fthrNm) {
		this.fthrNm = fthrNm;
	}

	public java.lang.String getGfthrNm() {
		return gfthrNm;
	}

	public void setGfthrNm(java.lang.String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}
  
	public java.lang.String getCfmTamLedrId() {
		return cfmTamLedrId;
	}

	public void setCfmTamLedrId(java.lang.String cfmTamLedrId) {
		this.cfmTamLedrId = cfmTamLedrId;
	}

	public java.lang.String getCrdExpiryDd() {
		return crdExpiryDd;
	}

	public void setCrdExpiryDd(java.lang.String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}

	public java.lang.String getBioChngYn() {
		return bioChngYn;
	}

	public void setBioChngYn(java.lang.String bioChngYn) {
		this.bioChngYn = bioChngYn;
	}

	public java.lang.String getCrdReisuceDueDd() {
		return crdReisuceDueDd;
	}

	public void setCrdReisuceDueDd(java.lang.String crdReisuceDueDd) {
		this.crdReisuceDueDd = crdReisuceDueDd;
	}

	public java.lang.String getCrdReisuceDd() {
		return crdReisuceDd;
	}

	public void setCrdReisuceDd(java.lang.String crdReisuceDd) {
		this.crdReisuceDd = crdReisuceDd;
	}

	public java.lang.String getRsnCdNm() {
		return rsnCdNm;
	}

	public void setRsnCdNm(java.lang.String rsnCdNm) {
		this.rsnCdNm = rsnCdNm;
	}

	public java.lang.String getDptYn() {
		return dptYn;
	}

	public void setDptYn(java.lang.String dptYn) {
		this.dptYn = dptYn;
	}

	public java.lang.String getCrdReisuSeqNo() {
		return crdReisuSeqNo;
	}

	public void setCrdReisuSeqNo(java.lang.String crdReisuSeqNo) {
		this.crdReisuSeqNo = crdReisuSeqNo;
	}

	public java.lang.String getOcrncDd() {
		return ocrncDd;
	}

	public void setOcrncDd(java.lang.String ocrncDd) {
		this.ocrncDd = ocrncDd;
	}

	public java.lang.String getRsnDtlCt() {
		return rsnDtlCt;
	}

	public void setRsnDtlCt(java.lang.String rsnDtlCt) {
		this.rsnDtlCt = rsnDtlCt;
	}

	public java.lang.String getRgstOrgnzCd() {
		return rgstOrgnzCd;
	}

	public void setRgstOrgnzCd(java.lang.String rgstOrgnzCd) {
		this.rgstOrgnzCd = rgstOrgnzCd;
	}

	public java.lang.String getTamLedrCfmYn() {
		return tamLedrCfmYn;
	}

	public void setTamLedrCfmYn(java.lang.String tamLedrCfmYn) {
		this.tamLedrCfmYn = tamLedrCfmYn;
	}

	public java.lang.String getRsnCd() {
		return rsnCd;
	}

	public void setRsnCd(java.lang.String rsnCd) {
		this.rsnCd = rsnCd;
	}

	public java.lang.String getRsdtNoDp() {
		return rsdtNoDp;
	}

	public void setRsdtNoDp(java.lang.String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}

	public java.lang.String getCurtAdCdNm() {
		return curtAdCdNm;
	}

	public void setCurtAdCdNm(java.lang.String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}

	public java.lang.String getGdrCdNm() {
		return gdrCdNm;
	}

	public void setGdrCdNm(java.lang.String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}

	public java.lang.String getRsdtNo() {
		return rsdtNo;
	}

	public void setRsdtNo(java.lang.String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}

	public java.lang.String getGivNm() {
		return givNm;
	}

	public void setGivNm(java.lang.String givNm) {
		this.givNm = givNm;
	}

	public java.lang.String getSurnm() {
		return surnm;
	}

	public void setSurnm(java.lang.String surnm) {
		this.surnm = surnm;
	}

	public java.lang.String getBthDd() {
		return bthDd;
	}

	public void setBthDd(java.lang.String bthDd) {
		this.bthDd = bthDd;
	}

	public java.lang.String getCurtAdCd() {
		return curtAdCd;
	}

	public void setCurtAdCd(java.lang.String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}

	public java.lang.String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}

	public void setCurtAdDtlCt(java.lang.String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}
    
    public java.lang.String getRsdtSeqNo() {
		return rsdtSeqNo;
	}

	public void setRsdtSeqNo(java.lang.String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}

	public java.lang.String getFstRgstUserId() {
		return fstRgstUserId;
	}

	public void setFstRgstUserId(java.lang.String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}

	public java.lang.String getFstRgstDt() {
		return fstRgstDt;
	}

	public void setFstRgstDt(java.lang.String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}

	public java.lang.String getLstUdtUserId() {
		return lstUdtUserId;
	}

	public void setLstUdtUserId(java.lang.String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}

	public java.lang.String getLstUdtDt() {
		return lstUdtDt;
	}

	public void setLstUdtDt(java.lang.String lstUdtDt) {
		this.lstUdtDt = lstUdtDt;
	}

	public java.lang.String getPageFlag() {
		return pageFlag;
	}

	public void setPageFlag(java.lang.String pageFlag) {
		this.pageFlag = pageFlag;
	}

	public java.lang.String getErrCd() {
		return errCd;
	}

	public void setErrCd(java.lang.String errCd) {
		this.errCd = errCd;
	}

	public java.lang.String getPmntAdCd() {
		return pmntAdCd;
	}

	public void setPmntAdCd(java.lang.String pmntAdCd) {
		this.pmntAdCd = pmntAdCd;
	}

	public java.lang.String getPmntAdCdNm() {
		return pmntAdCdNm;
	}

	public void setPmntAdCdNm(java.lang.String pmntAdCdNm) {
		this.pmntAdCdNm = pmntAdCdNm;
	}

	public java.lang.String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}

	public void setPmntAdDtlCt(java.lang.String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}

	public java.lang.String getRsdtStusCd() {
		return rsdtStusCd;
	}

	public void setRsdtStusCd(java.lang.String rsdtStusCd) {
		this.rsdtStusCd = rsdtStusCd;
	}

	public String getRsdtInfrChngYn() {
		return rsdtInfrChngYn;
	}

	public void setRsdtInfrChngYn(String rsdtInfrChngYn) {
		this.rsdtInfrChngYn = rsdtInfrChngYn;
	}

	public String getAfRsdtSeqNo() {
		return afRsdtSeqNo;
	}

	public void setAfRsdtSeqNo(String afRsdtSeqNo) {
		this.afRsdtSeqNo = afRsdtSeqNo;
	}

	public String getAfFmlyBokSeqNo() {
		return afFmlyBokSeqNo;
	}

	public void setAfFmlyBokSeqNo(String afFmlyBokSeqNo) {
		this.afFmlyBokSeqNo = afFmlyBokSeqNo;
	}

	public String getAfFmlyBokNo() {
		return afFmlyBokNo;
	}

	public void setAfFmlyBokNo(String afFmlyBokNo) {
		this.afFmlyBokNo = afFmlyBokNo;
	}

	public String getAfFmlyMberNo() {
		return afFmlyMberNo;
	}

	public void setAfFmlyMberNo(String afFmlyMberNo) {
		this.afFmlyMberNo = afFmlyMberNo;
	}

	public String getAfOldCrdNo() {
		return afOldCrdNo;
	}

	public void setAfOldCrdNo(String afOldCrdNo) {
		this.afOldCrdNo = afOldCrdNo;
	}

	public String getAfRsdtNo() {
		return afRsdtNo;
	}

	public void setAfRsdtNo(String afRsdtNo) {
		this.afRsdtNo = afRsdtNo;
	}

	public String getAfRlCd() {
		return afRlCd;
	}

	public void setAfRlCd(String afRlCd) {
		this.afRlCd = afRlCd;
	}

	public String getAfGivNm() {
		return afGivNm;
	}

	public void setAfGivNm(String afGivNm) {
		this.afGivNm = afGivNm;
	}

	public String getAfSurnm() {
		return afSurnm;
	}

	public void setAfSurnm(String afSurnm) {
		this.afSurnm = afSurnm;
	}

	public String getAfFthrNm() {
		return afFthrNm;
	}

	public void setAfFthrNm(String afFthrNm) {
		this.afFthrNm = afFthrNm;
	}

	public String getAfMthrNm() {
		return afMthrNm;
	}

	public void setAfMthrNm(String afMthrNm) {
		this.afMthrNm = afMthrNm;
	}

	public String getAfFthrRsdtSeqNo() {
		return afFthrRsdtSeqNo;
	}

	public void setAfFthrRsdtSeqNo(String afFthrRsdtSeqNo) {
		this.afFthrRsdtSeqNo = afFthrRsdtSeqNo;
	}

	public String getAfMthrRsdtSeqNo() {
		return afMthrRsdtSeqNo;
	}

	public void setAfMthrRsdtSeqNo(String afMthrRsdtSeqNo) {
		this.afMthrRsdtSeqNo = afMthrRsdtSeqNo;
	}

	public String getAfGfthrNm() {
		return afGfthrNm;
	}

	public void setAfGfthrNm(String afGfthrNm) {
		this.afGfthrNm = afGfthrNm;
	}

	public String getAfBthDd() {
		return afBthDd;
	}

	public void setAfBthDd(String afBthDd) {
		this.afBthDd = afBthDd;
	}

	public String getAfBthPlceCd() {
		return afBthPlceCd;
	}

	public void setAfBthPlceCd(String afBthPlceCd) {
		this.afBthPlceCd = afBthPlceCd;
	}

	public String getAfBthNatDiv() {
		return afBthNatDiv;
	}

	public void setAfBthNatDiv(String afBthNatDiv) {
		this.afBthNatDiv = afBthNatDiv;
	}

	public String getAfBthNatCd() {
		return afBthNatCd;
	}

	public void setAfBthNatCd(String afBthNatCd) {
		this.afBthNatCd = afBthNatCd;
	}

	public String getAfFrgnBthCtyNm() {
		return afFrgnBthCtyNm;
	}

	public void setAfFrgnBthCtyNm(String afFrgnBthCtyNm) {
		this.afFrgnBthCtyNm = afFrgnBthCtyNm;
	}

	public String getAfPmntAdCd() {
		return afPmntAdCd;
	}

	public void setAfPmntAdCd(String afPmntAdCd) {
		this.afPmntAdCd = afPmntAdCd;
	}

	public String getAfPmntAdDtlCt() {
		return afPmntAdDtlCt;
	}

	public void setAfPmntAdDtlCt(String afPmntAdDtlCt) {
		this.afPmntAdDtlCt = afPmntAdDtlCt;
	}

	public String getAfCurtAdCd() {
		return afCurtAdCd;
	}

	public void setAfCurtAdCd(String afCurtAdCd) {
		this.afCurtAdCd = afCurtAdCd;
	}

	public String getAfCurtAdDtlCt() {
		return afCurtAdDtlCt;
	}

	public void setAfCurtAdDtlCt(String afCurtAdDtlCt) {
		this.afCurtAdDtlCt = afCurtAdDtlCt;
	}

	public String getAfBldTyeCd() {
		return afBldTyeCd;
	}

	public void setAfBldTyeCd(String afBldTyeCd) {
		this.afBldTyeCd = afBldTyeCd;
	}

	public String getAfMrrgCd() {
		return afMrrgCd;
	}

	public void setAfMrrgCd(String afMrrgCd) {
		this.afMrrgCd = afMrrgCd;
	}

	public String getAfGdrCd() {
		return afGdrCd;
	}

	public void setAfGdrCd(String afGdrCd) {
		this.afGdrCd = afGdrCd;
	}

	public String getAfEncyCd() {
		return afEncyCd;
	}

	public void setAfEncyCd(String afEncyCd) {
		this.afEncyCd = afEncyCd;
	}

	public String getAfFmlyLangCd() {
		return afFmlyLangCd;
	}

	public void setAfFmlyLangCd(String afFmlyLangCd) {
		this.afFmlyLangCd = afFmlyLangCd;
	}

	public String getAfSecdNltyCd() {
		return afSecdNltyCd;
	}

	public void setAfSecdNltyCd(String afSecdNltyCd) {
		this.afSecdNltyCd = afSecdNltyCd;
	}

	public String getAfOcp() {
		return afOcp;
	}

	public void setAfOcp(String afOcp) {
		this.afOcp = afOcp;
	}

	public String getAfRlgnCd() {
		return afRlgnCd;
	}

	public void setAfRlgnCd(String afRlgnCd) {
		this.afRlgnCd = afRlgnCd;
	}

	public String getAfRlgnSectCd() {
		return afRlgnSectCd;
	}

	public void setAfRlgnSectCd(String afRlgnSectCd) {
		this.afRlgnSectCd = afRlgnSectCd;
	}

	public String getAfEduCd() {
		return afEduCd;
	}

	public void setAfEduCd(String afEduCd) {
		this.afEduCd = afEduCd;
	}

	public String getAfMltSrvcCd() {
		return afMltSrvcCd;
	}

	public void setAfMltSrvcCd(String afMltSrvcCd) {
		this.afMltSrvcCd = afMltSrvcCd;
	}

	public String getAfSmrRsdcCd() {
		return afSmrRsdcCd;
	}

	public void setAfSmrRsdcCd(String afSmrRsdcCd) {
		this.afSmrRsdcCd = afSmrRsdcCd;
	}

	public String getAfWtrRsdcCd() {
		return afWtrRsdcCd;
	}

	public void setAfWtrRsdcCd(String afWtrRsdcCd) {
		this.afWtrRsdcCd = afWtrRsdcCd;
	}

	public String getAfFmlyMberMlNo() {
		return afFmlyMberMlNo;
	}

	public void setAfFmlyMberMlNo(String afFmlyMberMlNo) {
		this.afFmlyMberMlNo = afFmlyMberMlNo;
	}

	public String getAfFmlyMberFemlNo() {
		return afFmlyMberFemlNo;
	}

	public void setAfFmlyMberFemlNo(String afFmlyMberFemlNo) {
		this.afFmlyMberFemlNo = afFmlyMberFemlNo;
	}

	public String getAfCrdIsucePlceCd() {
		return afCrdIsucePlceCd;
	}

	public void setAfCrdIsucePlceCd(String afCrdIsucePlceCd) {
		this.afCrdIsucePlceCd = afCrdIsucePlceCd;
	}

	public String getAfCrdIsuceDd() {
		return afCrdIsuceDd;
	}

	public void setAfCrdIsuceDd(String afCrdIsuceDd) {
		this.afCrdIsuceDd = afCrdIsuceDd;
	}

	public String getAfCrdExpiryDd() {
		return afCrdExpiryDd;
	}

	public void setAfCrdExpiryDd(String afCrdExpiryDd) {
		this.afCrdExpiryDd = afCrdExpiryDd;
	}

	public String getAfAdChngYn() {
		return afAdChngYn;
	}

	public void setAfAdChngYn(String afAdChngYn) {
		this.afAdChngYn = afAdChngYn;
	}

	public String getAfPoliCntrSeqNo() {
		return afPoliCntrSeqNo;
	}

	public void setAfPoliCntrSeqNo(String afPoliCntrSeqNo) {
		this.afPoliCntrSeqNo = afPoliCntrSeqNo;
	}

	public String getAfFmlyBokNoNum() {
		return afFmlyBokNoNum;
	}

	public void setAfFmlyBokNoNum(String afFmlyBokNoNum) {
		this.afFmlyBokNoNum = afFmlyBokNoNum;
	}

	public String getAfRsdtNoDp() {
		return afRsdtNoDp;
	}

	public void setAfRsdtNoDp(String afRsdtNoDp) {
		this.afRsdtNoDp = afRsdtNoDp;
	}

	public String getAfPmntAdCdNm() {
		return afPmntAdCdNm;
	}

	public void setAfPmntAdCdNm(String afPmntAdCdNm) {
		this.afPmntAdCdNm = afPmntAdCdNm;
	}

	public String getAfCurtAdCdNm() {
		return afCurtAdCdNm;
	}

	public void setAfCurtAdCdNm(String afCurtAdCdNm) {
		this.afCurtAdCdNm = afCurtAdCdNm;
	}

	public String getAfBthPlceCdNm() {
		return afBthPlceCdNm;
	}

	public void setAfBthPlceCdNm(String afBthPlceCdNm) {
		this.afBthPlceCdNm = afBthPlceCdNm;
	}

	public String getAfSmrRsdcCdNm() {
		return afSmrRsdcCdNm;
	}

	public void setAfSmrRsdcCdNm(String afSmrRsdcCdNm) {
		this.afSmrRsdcCdNm = afSmrRsdcCdNm;
	}

	public String getAfWtrRsdcCdNm() {
		return afWtrRsdcCdNm;
	}

	public void setAfWtrRsdcCdNm(String afWtrRsdcCdNm) {
		this.afWtrRsdcCdNm = afWtrRsdcCdNm;
	}

	public String getAfOldCrdIsucePlceNm() {
		return afOldCrdIsucePlceNm;
	}

	public void setAfOldCrdIsucePlceNm(String afOldCrdIsucePlceNm) {
		this.afOldCrdIsucePlceNm = afOldCrdIsucePlceNm;
	}

	public String getAfPoliCntrSeqNoNm() {
		return afPoliCntrSeqNoNm;
	}

	public void setAfPoliCntrSeqNoNm(String afPoliCntrSeqNoNm) {
		this.afPoliCntrSeqNoNm = afPoliCntrSeqNoNm;
	}

	public String getAfRsdtTyeCd() {
		return afRsdtTyeCd;
	}

	public void setAfRsdtTyeCd(String afRsdtTyeCd) {
		this.afRsdtTyeCd = afRsdtTyeCd;
	}

	public String getCalTye() {
		return calTye;
	}

	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}

	public String getOldAge() {
		return oldAge;
	}

	public void setOldAge(String oldAge) {
		this.oldAge = oldAge;
	}

	public String getFmlyBokSeqNo() {
		return fmlyBokSeqNo;
	}

	public void setFmlyBokSeqNo(String fmlyBokSeqNo) {
		this.fmlyBokSeqNo = fmlyBokSeqNo;
	}

	public String getFmlyBokNo() {
		return fmlyBokNo;
	}

	public void setFmlyBokNo(String fmlyBokNo) {
		this.fmlyBokNo = fmlyBokNo;
	}

	public String getFmlyMberNo() {
		return fmlyMberNo;
	}

	public void setFmlyMberNo(String fmlyMberNo) {
		this.fmlyMberNo = fmlyMberNo;
	}

	public String getOldCrdNo() {
		return oldCrdNo;
	}

	public void setOldCrdNo(String oldCrdNo) {
		this.oldCrdNo = oldCrdNo;
	}

	public String getRlCd() {
		return rlCd;
	}

	public void setRlCd(String rlCd) {
		this.rlCd = rlCd;
	}

	public String getMthrNm() {
		return mthrNm;
	}

	public void setMthrNm(String mthrNm) {
		this.mthrNm = mthrNm;
	}

	public String getFthrRsdtSeqNo() {
		return fthrRsdtSeqNo;
	}

	public void setFthrRsdtSeqNo(String fthrRsdtSeqNo) {
		this.fthrRsdtSeqNo = fthrRsdtSeqNo;
	}

	public String getMthrRsdtSeqNo() {
		return mthrRsdtSeqNo;
	}

	public void setMthrRsdtSeqNo(String mthrRsdtSeqNo) {
		this.mthrRsdtSeqNo = mthrRsdtSeqNo;
	}

	public String getBthPlceCd() {
		return bthPlceCd;
	}

	public void setBthPlceCd(String bthPlceCd) {
		this.bthPlceCd = bthPlceCd;
	}

	public String getBthNatDiv() {
		return bthNatDiv;
	}

	public void setBthNatDiv(String bthNatDiv) {
		this.bthNatDiv = bthNatDiv;
	}

	public String getBthNatCd() {
		return bthNatCd;
	}

	public void setBthNatCd(String bthNatCd) {
		this.bthNatCd = bthNatCd;
	}

	public String getFrgnBthCtyNm() {
		return frgnBthCtyNm;
	}

	public void setFrgnBthCtyNm(String frgnBthCtyNm) {
		this.frgnBthCtyNm = frgnBthCtyNm;
	}

	public String getBldTyeCd() {
		return bldTyeCd;
	}

	public void setBldTyeCd(String bldTyeCd) {
		this.bldTyeCd = bldTyeCd;
	}

	public String getMrrgCd() {
		return mrrgCd;
	}

	public void setMrrgCd(String mrrgCd) {
		this.mrrgCd = mrrgCd;
	}

	public String getGdrCd() {
		return gdrCd;
	}

	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}

	public String getEncyCd() {
		return encyCd;
	}

	public void setEncyCd(String encyCd) {
		this.encyCd = encyCd;
	}

	public String getFmlyLangCd() {
		return fmlyLangCd;
	}

	public void setFmlyLangCd(String fmlyLangCd) {
		this.fmlyLangCd = fmlyLangCd;
	}

	public String getSecdNltyCd() {
		return secdNltyCd;
	}

	public void setSecdNltyCd(String secdNltyCd) {
		this.secdNltyCd = secdNltyCd;
	}

	public String getOcp() {
		return ocp;
	}

	public void setOcp(String ocp) {
		this.ocp = ocp;
	}

	public String getRlgnCd() {
		return rlgnCd;
	}

	public void setRlgnCd(String rlgnCd) {
		this.rlgnCd = rlgnCd;
	}

	public String getRlgnSectCd() {
		return rlgnSectCd;
	}

	public void setRlgnSectCd(String rlgnSectCd) {
		this.rlgnSectCd = rlgnSectCd;
	}

	public String getEduCd() {
		return eduCd;
	}

	public void setEduCd(String eduCd) {
		this.eduCd = eduCd;
	}

	public String getMltSrvcCd() {
		return mltSrvcCd;
	}

	public void setMltSrvcCd(String mltSrvcCd) {
		this.mltSrvcCd = mltSrvcCd;
	}

	public String getSmrRsdcCd() {
		return smrRsdcCd;
	}

	public void setSmrRsdcCd(String smrRsdcCd) {
		this.smrRsdcCd = smrRsdcCd;
	}

	public String getWtrRsdcCd() {
		return wtrRsdcCd;
	}

	public void setWtrRsdcCd(String wtrRsdcCd) {
		this.wtrRsdcCd = wtrRsdcCd;
	}

	public String getFmlyMberMlNo() {
		return fmlyMberMlNo;
	}

	public void setFmlyMberMlNo(String fmlyMberMlNo) {
		this.fmlyMberMlNo = fmlyMberMlNo;
	}

	public String getFmlyMberFemlNo() {
		return fmlyMberFemlNo;
	}

	public void setFmlyMberFemlNo(String fmlyMberFemlNo) {
		this.fmlyMberFemlNo = fmlyMberFemlNo;
	}

	public String getRsdtTyeCd() {
		return rsdtTyeCd;
	}

	public void setRsdtTyeCd(String rsdtTyeCd) {
		this.rsdtTyeCd = rsdtTyeCd;
	}

	public String getPoliCntrSeqNo() {
		return poliCntrSeqNo;
	}

	public void setPoliCntrSeqNo(String poliCntrSeqNo) {
		this.poliCntrSeqNo = poliCntrSeqNo;
	}

	public String getBsnSeqNo() {
		return bsnSeqNo;
	}

	public void setBsnSeqNo(String bsnSeqNo) {
		this.bsnSeqNo = bsnSeqNo;
	}

	public String getMdfctSeqNo() {
		return mdfctSeqNo;
	}

	public void setMdfctSeqNo(String mdfctSeqNo) {
		this.mdfctSeqNo = mdfctSeqNo;
	}

	public String[] getNatLangCd() {
		return natLangCd;
	}

	public void setNatLangCd(String[] natLangCd) {
		this.natLangCd = natLangCd;
	}

	

	public String[] getNatLangCds() {
		return natLangCds;
	}

	public void setNatLangCds(String[] natLangCds) {
		this.natLangCds = natLangCds;
	}

	public String[] getFrgnLangCd() {
		return frgnLangCd;
	}

	public void setFrgnLangCd(String[] frgnLangCd) {
		this.frgnLangCd = frgnLangCd;
	}

	public String[] getFrgnLangCds() {
		return frgnLangCds;
	}

	public void setFrgnLangCds(String[] frgnLangCds) {
		this.frgnLangCds = frgnLangCds;
	}

	public String getLstLangCd() {
		return lstLangCd;
	}

	public void setLstLangCd(String lstLangCd) {
		this.lstLangCd = lstLangCd;
	}

	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}

	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}

	public String getChngRsnDtlCt() {
		return chngRsnDtlCt;
	}

	public void setChngRsnDtlCt(String chngRsnDtlCt) {
		this.chngRsnDtlCt = chngRsnDtlCt;
	}

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getPbctOfic() {
		return pbctOfic;
	}

	public void setPbctOfic(String pbctOfic) {
		this.pbctOfic = pbctOfic;
	}

	public String getCrdReisuceYn() {
		return crdReisuceYn;
	}

	public void setCrdReisuceYn(String crdReisuceYn) {
		this.crdReisuceYn = crdReisuceYn;
	}

	public String getCrdIsucePlceCdNm() {
		return crdIsucePlceCdNm;
	}

	public void setCrdIsucePlceCdNm(String crdIsucePlceCdNm) {
		this.crdIsucePlceCdNm = crdIsucePlceCdNm;
	}

	public String getAfCrdIsucePlceCdNm() {
		return afCrdIsucePlceCdNm;
	}

	public void setAfCrdIsucePlceCdNm(String afCrdIsucePlceCdNm) {
		this.afCrdIsucePlceCdNm = afCrdIsucePlceCdNm;
	}

	public String getAplCd() {
		return aplCd;
	}

	public void setAplCd(String aplCd) {
		this.aplCd = aplCd;
	}

	public String getLgSeqNo() {
		return lgSeqNo;
	}

	public void setLgSeqNo(String lgSeqNo) {
		this.lgSeqNo = lgSeqNo;
	}

	public String getOthrRl() {
		return othrRl;
	}

	public void setOthrRl(String othrRl) {
		this.othrRl = othrRl;
	}

	public String getAfOthrRl() {
		return afOthrRl;
	}

	public void setAfOthrRl(String afOthrRl) {
		this.afOthrRl = afOthrRl;
	}

	public java.lang.String gethBthDd() {
		return hBthDd;
	}

	public void sethBthDd(java.lang.String hBthDd) {
		this.hBthDd = hBthDd;
	}

	public java.lang.String getgBthDd() {
		return gBthDd;
	}

	public void setgBthDd(java.lang.String gBthDd) {
		this.gBthDd = gBthDd;
	}
   
}
