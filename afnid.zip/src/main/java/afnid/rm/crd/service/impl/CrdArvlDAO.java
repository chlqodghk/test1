package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.rm.crd.service.CrdArvlVO;

import com.ibatis.sqlmap.client.SqlMapClient;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

/** 
 * This class is Database Access Object of eNID Card arrival Management
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2014.11.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers				Revisions
 *   2014.11.17  		MoonSoo Kim             Create
 *
 * </pre>
 */
@Repository("crdArvlDAO")
public class CrdArvlDAO extends EgovAbstractDAO {
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }

	
	/**
	 * DAO-method for retrieving card arrival list . <br>
	 *
	 * @param vo Input item for retrieving list of card arrival(CrdArvlVO).
	 * @return List<EgovMap> Retrieve list of card arrival
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<CrdArvlVO> selectListCrdArvl(CrdArvlVO vo) throws Exception{
		return list("crdArvlDAO.selectListCrdArvl", vo);
	}

	/**
	 * DAO-method for retrieving total count list of card arrival. <br>
	 *
	 * @param vo Input item for retrieving list of card arrival(CrdArvlVO).
	 * @return int Total Count of card arrival List
	 * @exception Exception
	 */
    public int selectListCrdArvlTotCn(CrdArvlVO vo) {
        return (Integer)selectByPk("crdArvlDAO.selectListCrdArvlTotCn", vo);
    }

	/**
	 * DAO-method for retrieving card arrival citizen list . <br>
	 *
	 * @param vo Input item for retrieving citizen list of card arrival(CrdArvlVO).
	 * @return List<CrdArvlVO> Retrieve citizen list of card arrival
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<CrdArvlVO> selectListCrdArvlRsdt(CrdArvlVO vo) throws Exception{
		return list("crdArvlDAO.selectListCrdArvlRsdt", vo);
	}

	/**
	 * DAO-method for retrieving total count citizen list of card arrival. <br>
	 *
	 * @param vo Input item for retrieving citizen list of card arrival(CrdArvlVO).
	 * @return int Total Count of card arrival citizen List
	 * @exception Exception
	 */
    public int selectListCrdArvlRsdtTotCn(CrdArvlVO vo) {
        return (Integer)selectByPk("crdArvlDAO.selectListCrdArvlRsdtTotCn", vo);
                                    
    }
    
	/**
	 * DAO-method for retrieving citizen list count of card arrival by search condition. <br>
	 *
	 * @param vo Input item for retrieving citizen list count of card arrival by search condition(CrdArvlVO).
	 * @return CrdArvlVO Retrieve  citizen list count of card arrival by search condition
	 * @exception Exception
	 */
	public CrdArvlVO selectCrdArvlRsdtCn(CrdArvlVO vo) throws Exception{
		return (CrdArvlVO)selectByPk("crdArvlDAO.selectCrdArvlRsdtCn", vo);
	}    
    
	
	/**
	 * DAO-method for retrieving card arrival citizen list . <br>
	 *
	 * @param vo Input item for retrieving citizen list of card arrival(CrdArvlVO).
	 * @return List<CrdArvlVO> Retrieve citizen list of card arrival
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<CrdArvlVO> selectListCrdArvlRsdtCrdReisuce(CrdArvlVO vo) throws Exception{
		return list("crdArvlDAO.selectListCrdArvlRsdtCrdReisuce", vo);
	}
	
	
	/**
	 * DAO-method for modify citizen information. <br>
	 *
	 * @param vo Input item for modify citizen information(CrdArvlVO).
	 * @return 
	 * @exception Exception
	 */
    public void updateRsdtCrdIsuceSrlNo(CrdArvlVO vo) {
        update("crdArvlDAO.updateRsdtCrdIsuceSrlNo", vo);
    }
		
	
    /**
   	 * DAO-method for eNID Card Reissuance. <br>
   	 *
   	 * @param vo Input item for eNID Card Reissuance(CrdArvlVO).
   	 * @return 
   	 * @exception Exception
   	 */
	public void insertArvlCadReisuceAll(CrdArvlVO vo) {
		update("crdArvlDAO.insertArvlCadReisuceAll", vo);
    }
		
	
    /**
   	 * DAO-method for eNID Card Reissuance. <br>
   	 *
   	 * @param vo Input item for eNID Card Reissuance(CrdArvlVO).
   	 * @return 
   	 * @exception Exception
   	 */
	public void updateArvlCadIsuceAll(CrdArvlVO vo) {
		update("crdArvlDAO.updateArvlCadIsuceAll", vo);
    }

    /**
   	 * DAO-method for eNID Card Reissuance. <br>
   	 *
   	 * @param vo Input item for eNID Card Reissuance(CrdArvlVO).
   	 * @return 
   	 * @exception Exception
   	 */
	public void updateArvlCadReisuceAll(CrdArvlVO vo) {
		update("crdArvlDAO.updateArvlCadReisuceAll", vo);
    }
	
	
    
    /**
   	 * DAO-method for eNID Card Reissuance. <br>
   	 *
   	 * @param vo Input item for eNID Card Reissuance(CrdArvlVO).
   	 * @return 
   	 * @exception Exception
   	 */
	public void insertArvlCadReisuce(CrdArvlVO vo) {
		update("crdArvlDAO.insertArvlCadReisuce", vo);
    }
	
	
    /**
   	 * DAO-method for eNID Card Reissuance. <br>
   	 *
   	 * @param vo Input item for eNID Card Reissuance(CrdArvlVO).
   	 * @return 
   	 * @exception Exception
   	 */
	public void updateArvlCadIsuce(CrdArvlVO vo) {
		update("crdArvlDAO.updateArvlCadIsuce", vo);
    }
	
    /**
   	 * DAO-method for eNID Card Reissuance. <br>
   	 *
   	 * @param vo Input item for eNID Card Reissuance(CrdArvlVO).
   	 * @return 
   	 * @exception Exception
   	 */
	public void updateArvlCadReisuce(CrdArvlVO vo) {
		update("crdArvlDAO.updateArvlCadReisuce", vo);
    }
	
	
    /**
   	 * DAO-method for eNID Card Arrival. <br>
   	 *
   	 * @param vo Input item for eNID Card Arrival(CrdArvlVO).
   	 * @return 
   	 * @exception Exception
   	 */
	public void updateArvl(CrdArvlVO vo) {
		update("crdArvlDAO.updateArvl", vo);
    }
	
    /**
   	 * DAO-method for eNID Card Arrival. <br>
   	 *
   	 * @param vo Input item for eNID Card Arrival(CrdArvlVO).
   	 * @return 
   	 * @exception Exception
   	 */
	public void updateArvlAll(CrdArvlVO vo) {
		update("crdArvlDAO.updateArvlAll", vo);
    }
	
    /**
   	 * DAO-method for eNID Card Arrival Clear. <br>
   	 *
   	 * @param vo Input item for eNID Card Arrival Clear(CrdArvlVO).
   	 * @return 
   	 * @exception Exception
   	 */
	public void updateArvlClar(CrdArvlVO vo) {
		update("crdArvlDAO.updateArvlClar", vo);
    }	
	
    /**
   	 * DAO-method for eNID Card Arrival Clear. <br>
   	 *
   	 * @param vo Input item for eNID Card Arrival Clear(CrdArvlVO).
   	 * @return 
   	 * @exception Exception
   	 */
	public void updateArvlClarAll(CrdArvlVO vo) {
		update("crdArvlDAO.updateArvlClarAll", vo);
    }
	
	/**
	 * DAO-method for retrieving Issuance Failed Citizens list . <br>
	 *
	 * @param vo Input item for retrieving list of Issuance Failed Citizens(CrdArvlVO).
	 * @return List<EgovMap> Retrieve list of Issuance Failed Citizens
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<CrdArvlVO> selectListCrdFailRsdt(CrdArvlVO vo) throws Exception{
		return list("crdArvlDAO.selectListCrdFailRsdt", vo);
	}

	/**
	 * DAO-method for retrieving total count list of Issuance Failed Citizens. <br>
	 *
	 * @param vo Input item for retrieving list of Issuance Failed Citizens(CrdArvlVO).
	 * @return int Total Count of Issuance Failed Citizens List
	 * @exception Exception
	 */
    public int selectListCrdFailRsdtTotCn(CrdArvlVO vo) {
        return (Integer)selectByPk("crdArvlDAO.selectListCrdFailRsdtTotCn", vo);
    }
    
	/**
	 * DAO-method for modify citizen contact Y/N(. <br>
	 *
	 * @param vo Input item for (modify citizen contact Y/NCrdArvlVO).
	 * @return 
	 * @exception Exception
	 */
    public void updateCrdFailRsdt(CrdArvlVO vo) {
        update("crdArvlDAO.updateCrdFailRsdt", vo);
    }
    
	/**
	 * DAO-method for modify citizen information. <br>
	 *
	 * @param vo Input item for modify citizen information(CrdArvlVO).
	 * @return 
	 * @exception Exception
	 */
    public void updateRsdtInfr(CrdArvlVO vo) {
        update("crdArvlDAO.updateRsdtInfr", vo);
    }
    
}