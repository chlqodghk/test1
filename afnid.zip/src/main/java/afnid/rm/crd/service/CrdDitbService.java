package afnid.rm.crd.service;

import java.util.List;

/** 
 * This service interface is biz-class of Card Distribution. <br>
 * 
 * @author Afghanistan National ID Card System Application Team Daesung Kim
 * @since 2013.09.26
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers			Revisions
 *   2013.09.26  		Daesung Kim			  Create
 *
 * </pre>
 */
public interface CrdDitbService {

	
	/**
	 * Retrieves information of Citizen Card Application Status. <br>
	 *
	 * @param vo Input item for retrieving information of citizen card application status.(CrdDitbVO).
	 * @return List Retrieve information of citizen card application status.
	 * @exception Exception
	 */
	CrdDitbVO searchRsdtCrdApplyStus(CrdDitbVO vo)throws Exception;
	
	/**
	 * Retrieves information of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdDitbVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	CrdDitbVO searchCrdDitbIdfcIndiInfr(CrdDitbVO vo)throws Exception;
	
	/**
	 * Retrieves Citizen Revocation Status. <br>
	 *
	 * @param vo Input item for retrieving Citizen Revocation Status.(CrdDitbVO).
	 * @return String Revocation Status Message
	 * @exception Exception
	 */
	String searchRsdtRvctgStus(CrdDitbVO vo)throws Exception;
	
	/**
	 * Retrieves Citizen Rehabilitation Information <br>
	 *
	 * @param rsdtSeqNo Input item for retrieving Citizen Rehabilitation Information(String).
	 * @return String Citizen Rehabilitation Status
	 * @exception Exception
	 */
	String searchRsdtRhbltInfr(String rsdtSeqNo)throws Exception;
	
	/**
	 * Register information of program. <br>
	 *
	 * @param vo Input item for Registering information of program(CrdDitbVO).
	 * @return 
	 * @exception Exception
	 */
	void modifyCrdDitbIdfcIndiInfr(CrdDitbVO vo) throws Exception;
			
	/**
	 * Register information of program. <br>
	 *
	 * @param vo Input item for Registering information of program(CrdDitbVO).
	 * @return 
	 * @exception Exception
	 */
	void modifyCrdDisuseOnIdfcIndi(CrdDitbVO vo) throws Exception;
	
	/**
	 * Retrieves information of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdDitbVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	CrdDitbVO searchCrdDitbIndiInfr(CrdDitbVO vo)throws Exception;
	
	
	/**
	 * Register information of program. <br>
	 *
	 * @param vo Input item for Registering information of program(CrdDitbVO).
	 * @return 
	 * @exception Exception
	 */
	String modifyCrdDitbIndiInfr(CrdDitbVO vo) throws Exception;
	

	/**
	 * user retirement(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for user retirement(CrdDitbVO).
	 * @return CrdDitbVO Primary Key value of user retirement
	 * @exception Exception
	 */
	String modifyCrdDitbIndiInfrPkiIf(CrdDitbVO vo) throws Exception;	
	
	
	
	/**
	 * Retrieves information of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdDitbVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	CrdDitbVO searchFmlyHadInfr(CrdDitbVO vo) throws Exception;

	/**
	 * Retrieves information of program-list. <br>
	 * @param vo Input item for retrieving Card applying Status Information list of program.(CrdDitbVO)
	 * @return List<CrdDitbVO> result Information 
	 * @exception Exception
	 */
	List<CrdDitbVO> searchFmlyMberCrdApplyStus(CrdDitbVO vo) throws Exception;
	
	/**
	 * Retrieves information of program-list. <br>
	 * @param vo Input item for retrieving Citizen information list of program.(CrdDitbVO)
	 * @return List<CrdDitbVO> result Information 
	 * @exception Exception
	 */
	List<CrdDitbVO> searchCrdDitbIdfcFmlyInfr(CrdDitbVO vo) throws Exception;
	
	/**
	 * Retrieves head of family rehabilitation information. <br>
	 * @param rsdtNo Citizen eNid Number for retrieving head of family rehabilitation information.(String)
	 * @param fmlyInfr Input item for retrieving head of family rehabilitation information.(List<CrdDitbVO>)
	 * @return String Head of family Rehabilitation Status
	 * @exception Exception
	 */
	String searchFmlyHadRhbltInfr(String rsdtNo, List<CrdDitbVO> fmlyInfr) throws Exception;
	
	/**
	 * Retrieves information of program-list. <br>
	 * @param vo Input item for retrieving Citizen information list of program.(CrdDitbVO)
	 * @return List<CrdDitbVO> result Information 
	 * @exception Exception
	 */
	List<CrdDitbVO> searchCrdDitbFmlyInfr(CrdDitbVO vo) throws Exception;

	/**
	 * Register information of program. <br>
	 *
	 * @param vo Input item for Registering information of program(CrdDitbVO).
	 * @return 
	 * @exception Exception
	 */
	void modifyCrdDitbIdfcFmlyInfr(CrdDitbVO vo) throws Exception;
	
	/**
	 * Register information of program. <br>
	 *
	 * @param vo Input item for Registering information of program(CrdDitbVO).
	 * @return 
	 * @exception Exception
	 */
	CrdDitbVO modifyCrdDitbFmlyInfr(CrdDitbVO vo) throws Exception;
	
	/**
	 * user retirement(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for user retirement(CcltRhbltVO).
	 * @return CcltRhbltVO Primary Key value of user retirement
	 * @exception Exception
	 */
	String modifyCrdDitbFmlyInfrPkiIf(CrdDitbVO vo) throws Exception;	
	
	
}
