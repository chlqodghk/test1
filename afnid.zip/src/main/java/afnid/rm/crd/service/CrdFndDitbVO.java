package afnid.rm.crd.service;

import afnid.cm.ComDefaultVO;

public class CrdFndDitbVO extends ComDefaultVO {
	
	private static final long serialVersionUID = 1L;
	
	private String crdDsuseRsnCd;
	private String crdDsuseRsnCt;
	private String mnSeqNo;
	private String fondCrdSeqNo;
	private String rsdtSeqNo;
	private String rsdtNo;
	private String rsdtNoDp;
	private String fthrNm;
	private String rsdtNm;
	private String gfthrNm;
	private String bthDd;
	private String bthDdG;
	private String bthDdJ;
	private String gdrCd;
	private String gdrCdNm;
	private String pmntAdCd;
	private String pmntAdCdNm;
	private String pmntAdDtlCt;
	private String curtAdCd;
	private String curtAdCdNm;
	private String curtAdDtlCt;
	private String crdIsuceDd;
	private String crdExpiryDd;
	private String rsdtStusCd;
	private String rsdtStusCdNm;
	private String bthNatDiv;
	private String bthNatCd;
	private String bthNatCdNm;
	private String frgnBthCtyNm;
	private String idfcYn;
	private String rgstOrgnzCd;
	private String crdDitbCd;
	private String crdDitbDd;
	private String crdDitbOrgnzCd;
	private String crdDitbOrgnzCdNm;
	private String crdDitbUserId;
	private String crdDitbUserIdNm;
	private String userId;
	private String fstRgstUserId;
	private String lstUdtUserId;
	private String idfcDd;
	private String idfcUserId;
	private String idfcUserIdNm;
	private String fondCrdDitbSeqNo;
	private String sgntDat;
	private String bioKey;
	private String fondDd;
	private String fondDdG;
	private String fondDdJ;
	private String sndOrgnzCd;
	private String sndOrgnzCdNm;
	private String callPopupYn = "N";
	private String popFlag;
	private String isExp;
	private String dsuseMsg;
	private String fondCrdStusCd;
	private String returnFlag;
	private String ersrCd;
	private String ersrCdNm;

	private String crdIsuceSrlNo;	
	private String crdIsuceDdJ;
	private String crdIsuceDdG;	
	private String lgSeqNo;
	
	public String getDsuseMsg() {
		return dsuseMsg;
	}
	public void setDsuseMsg(String dsuseMsg) {
		this.dsuseMsg = dsuseMsg;
	}
	public String getErsrCd() {
		return ersrCd;
	}
	public void setErsrCd(String ersrCd) {
		this.ersrCd = ersrCd;
	}
	public String getErsrCdNm() {
		return ersrCdNm;
	}
	public void setErsrCdNm(String ersrCdNm) {
		this.ersrCdNm = ersrCdNm;
	}
	public String getReturnFlag() {
		return returnFlag;
	}
	public void setReturnFlag(String returnFlag) {
		this.returnFlag = returnFlag;
	}
	public String getFondCrdStusCd() {
		return fondCrdStusCd;
	}
	public void setFondCrdStusCd(String fondCrdStusCd) {
		this.fondCrdStusCd = fondCrdStusCd;
	}
	public String getIsExp() {
		return isExp;
	}
	public void setIsExp(String isExp) {
		this.isExp = isExp;
	}
	public String getSndOrgnzCdNm() {
		return sndOrgnzCdNm;
	}
	public void setSndOrgnzCdNm(String sndOrgnzCdNm) {
		this.sndOrgnzCdNm = sndOrgnzCdNm;
	}
	public String getPopFlag() {
		return popFlag;
	}
	public void setPopFlag(String popFlag) {
		this.popFlag = popFlag;
	}
	public String getCallPopupYn() {
		return callPopupYn;
	}
	public void setCallPopupYn(String callPopupYn) {
		this.callPopupYn = callPopupYn;
	}
	public String getFondDd() {
		return fondDd;
	}
	public void setFondDd(String fondDd) {
		this.fondDd = fondDd;
	}
	public String getSndOrgnzCd() {
		return sndOrgnzCd;
	}
	public void setSndOrgnzCd(String sndOrgnzCd) {
		this.sndOrgnzCd = sndOrgnzCd;
	}
	public String getBioKey() {
		return bioKey;
	}
	public void setBioKey(String bioKey) {
		this.bioKey = bioKey;
	}

	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getFondCrdDitbSeqNo() {
		return fondCrdDitbSeqNo;
	}
	public void setFondCrdDitbSeqNo(String fondCrdDitbSeqNo) {
		this.fondCrdDitbSeqNo = fondCrdDitbSeqNo;
	}
	public String getIdfcUserIdNm() {
		return idfcUserIdNm;
	}
	public void setIdfcUserIdNm(String idfcUserIdNm) {
		this.idfcUserIdNm = idfcUserIdNm;
	}
	public String getIdfcDd() {
		return idfcDd;
	}
	public void setIdfcDd(String idfcDd) {
		this.idfcDd = idfcDd;
	}
	public String getIdfcUserId() {
		return idfcUserId;
	}
	public void setIdfcUserId(String idfcUserId) {
		this.idfcUserId = idfcUserId;
	}
	public String getFstRgstUserId() {
		return fstRgstUserId;
	}
	public void setFstRgstUserId(String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}
	public String getLstUdtUserId() {
		return lstUdtUserId;
	}
	public void setLstUdtUserId(String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCrdDitbCd() {
		return crdDitbCd;
	}
	public void setCrdDitbCd(String crdDitbCd) {
		this.crdDitbCd = crdDitbCd;
	}
	public String getFondCrdSeqNo() {
		return fondCrdSeqNo;
	}
	public void setFondCrdSeqNo(String fondCrdSeqNo) {
		this.fondCrdSeqNo = fondCrdSeqNo;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	public String getFthrNm() {
		return fthrNm;
	}
	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}
	public String getRsdtNm() {
		return rsdtNm;
	}
	public void setRsdtNm(String rsdtNm) {
		this.rsdtNm = rsdtNm;
	}
	public String getGfthrNm() {
		return gfthrNm;
	}
	public void setGfthrNm(String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}
	public String getBthDd() {
		return bthDd;
	}
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	public String getGdrCd() {
		return gdrCd;
	}
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	public String getPmntAdCd() {
		return pmntAdCd;
	}
	public void setPmntAdCd(String pmntAdCd) {
		this.pmntAdCd = pmntAdCd;
	}
	public String getPmntAdCdNm() {
		return pmntAdCdNm;
	}
	public void setPmntAdCdNm(String pmntAdCdNm) {
		this.pmntAdCdNm = pmntAdCdNm;
	}
	public String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}
	public void setPmntAdDtlCt(String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}
	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}
	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}
	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}
	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}
	public String getRsdtStusCd() {
		return rsdtStusCd;
	}
	public void setRsdtStusCd(String rsdtStusCd) {
		this.rsdtStusCd = rsdtStusCd;
	}
	public String getRsdtStusCdNm() {
		return rsdtStusCdNm;
	}
	public void setRsdtStusCdNm(String rsdtStusCdNm) {
		this.rsdtStusCdNm = rsdtStusCdNm;
	}
	public String getBthNatDiv() {
		return bthNatDiv;
	}
	public void setBthNatDiv(String bthNatDiv) {
		this.bthNatDiv = bthNatDiv;
	}
	public String getBthNatCd() {
		return bthNatCd;
	}
	public void setBthNatCd(String bthNatCd) {
		this.bthNatCd = bthNatCd;
	}
	public String getBthNatCdNm() {
		return bthNatCdNm;
	}
	public void setBthNatCdNm(String bthNatCdNm) {
		this.bthNatCdNm = bthNatCdNm;
	}
	public String getFrgnBthCtyNm() {
		return frgnBthCtyNm;
	}
	public void setFrgnBthCtyNm(String frgnBthCtyNm) {
		this.frgnBthCtyNm = frgnBthCtyNm;
	}
	public String getIdfcYn() {
		return idfcYn;
	}
	public void setIdfcYn(String idfcYn) {
		this.idfcYn = idfcYn;
	}
	public String getRgstOrgnzCd() {
		return rgstOrgnzCd;
	}
	public void setRgstOrgnzCd(String rgstOrgnzCd) {
		this.rgstOrgnzCd = rgstOrgnzCd;
	}
	public String getCrdDitbDd() {
		return crdDitbDd;
	}
	public void setCrdDitbDd(String crdDitbDd) {
		this.crdDitbDd = crdDitbDd;
	}
	public String getCrdDitbOrgnzCd() {
		return crdDitbOrgnzCd;
	}
	public void setCrdDitbOrgnzCd(String crdDitbOrgnzCd) {
		this.crdDitbOrgnzCd = crdDitbOrgnzCd;
	}
	public String getCrdDitbOrgnzCdNm() {
		return crdDitbOrgnzCdNm;
	}
	public void setCrdDitbOrgnzCdNm(String crdDitbOrgnzCdNm) {
		this.crdDitbOrgnzCdNm = crdDitbOrgnzCdNm;
	}
	public String getCrdDitbUserId() {
		return crdDitbUserId;
	}
	public void setCrdDitbUserId(String crdDitbUserId) {
		this.crdDitbUserId = crdDitbUserId;
	}
	public String getCrdDitbUserIdNm() {
		return crdDitbUserIdNm;
	}
	public void setCrdDitbUserIdNm(String crdDitbUserIdNm) {
		this.crdDitbUserIdNm = crdDitbUserIdNm;
	}
	public String getCrdIsuceSrlNo() {
		return crdIsuceSrlNo;
	}
	public void setCrdIsuceSrlNo(String crdIsuceSrlNo) {
		this.crdIsuceSrlNo = crdIsuceSrlNo;
	}
	public String getBthDdG() {
		return bthDdG;
	}
	public void setBthDdG(String bthDdG) {
		this.bthDdG = bthDdG;
	}
	public String getBthDdJ() {
		return bthDdJ;
	}
	public void setBthDdJ(String bthDdJ) {
		this.bthDdJ = bthDdJ;
	}
	public String getFondDdG() {
		return fondDdG;
	}
	public void setFondDdG(String fondDdG) {
		this.fondDdG = fondDdG;
	}
	public String getFondDdJ() {
		return fondDdJ;
	}
	public void setFondDdJ(String fondDdJ) {
		this.fondDdJ = fondDdJ;
	}
	public String getCrdIsuceDdJ() {
		return crdIsuceDdJ;
	}
	public void setCrdIsuceDdJ(String crdIsuceDdJ) {
		this.crdIsuceDdJ = crdIsuceDdJ;
	}
	public String getCrdIsuceDdG() {
		return crdIsuceDdG;
	}
	public void setCrdIsuceDdG(String crdIsuceDdG) {
		this.crdIsuceDdG = crdIsuceDdG;
	}
	public String getSgntDat() {
		return sgntDat;
	}
	public void setSgntDat(String sgntDat) {
		this.sgntDat = sgntDat;
	}
	public String getLgSeqNo() {
		return lgSeqNo;
	}
	public void setLgSeqNo(String lgSeqNo) {
		this.lgSeqNo = lgSeqNo;
	}
	public String getCrdDsuseRsnCd() {
		return crdDsuseRsnCd;
	}
	public void setCrdDsuseRsnCd(String crdDsuseRsnCd) {
		this.crdDsuseRsnCd = crdDsuseRsnCd;
	}
	public String getCrdDsuseRsnCt() {
		return crdDsuseRsnCt;
	}
	public void setCrdDsuseRsnCt(String crdDsuseRsnCt) {
		this.crdDsuseRsnCt = crdDsuseRsnCt;
	}
	public String getMnSeqNo() {
		return mnSeqNo;
	}
	public void setMnSeqNo(String mnSeqNo) {
		this.mnSeqNo = mnSeqNo;
	}


}
