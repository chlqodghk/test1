package afnid.rm.crd.service.impl;


import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.crd.service.CrdArvlService;
import afnid.rm.crd.service.CrdArvlVO;
import afnid.rm.rsdt.service.RsdtInfrService;
import afnid.rm.rsdt.service.RsdtInfrVO;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;

import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;


/** 
 * This service interface is biz-class of eNID Card arrival Management. <br>
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2014.11.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers				Revisions
 *   2014.11.17  		MoonSoo Kim             Create
 *
 * </pre>
 */
@Service("crdArvlService")
public class CrdArvlServiceImpl extends AbstractServiceImpl implements CrdArvlService{
	
	@Resource(name="crdArvlDAO")
    private CrdArvlDAO dao ;

    @Resource(name="rsdtInfoService")
    private RsdtInfrService rsdtInfoService;
    
    @Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtDao;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /**
   	 * Biz-method for retrieving list of card arrival. <br>
   	 *
   	 * @param vo Input item for retrieving list of card arrival(CrdArvlVO).
   	 * @return List Retrieve list of card arrival
   	 * @exception Exception
   	 */
   	public List<CrdArvlVO> searchListCrdArvl(CrdArvlVO vo) throws Exception {
      		return dao.selectListCrdArvl(vo);
   	}

   	/**
	 * Biz-method for retrieving total count list of card arrival. <br>
	 *
	 * @param vo Input item for retrieving list of card arrival(CrdArvlVO).
	 * @return int Total Count of card arrival List
	 * @exception Exception
	 */
   	public int searchListCrdArvlTotCn(CrdArvlVO vo) throws Exception {
        return dao.selectListCrdArvlTotCn(vo);
	}
   	
    /**
   	 * Biz-method for retrieving citizen list of card arrival. <br>
   	 *
   	 * @param vo Input item for retrieving citizen list of card arrival(CrdArvlVO).
   	 * @return List Retrieve list of card arrival
   	 * @exception Exception
   	 */
   	public List<CrdArvlVO> searchListCrdArvlRsdt(CrdArvlVO vo) throws Exception {
  		return dao.selectListCrdArvlRsdt(vo);
   	}

   	/**
	 * Biz-method for retrieving  citizen list of card arrival . <br>
	 *
	 * @param vo Input item for retrieving citizen list of card arrival(CrdArvlVO).
	 * @return CrdArvlVO Total Count of card arrival citizen list
	 * @exception Exception
	 */
   	public int searchListCrdArvlRsdtTotCn(CrdArvlVO vo) throws Exception {
        return dao.selectListCrdArvlRsdtTotCn(vo);
	} 
   	
    /**
   	 * Biz-method for retrieving citizen list count of card arrival by search condition. <br>
   	 *
   	 * @param vo Input item for retrieving citizen list count of card arrival by search condition(CrdArvlVO).
   	 * @return CrdArvlVO Retrieve citizen list count of card arrival by search condition
   	 * @exception Exception
   	 */
   	public CrdArvlVO searchCrdArvlRsdtCn(CrdArvlVO vo) throws Exception {
  		return dao.selectCrdArvlRsdtCn(vo);
   	}  
   	
    /**
   	 * Biz-method for retrieving citizen list of card arrival. <br>
   	 *
   	 * @param vo Input item for retrieving citizen list of card arrival(CrdArvlVO).
   	 * @return List Retrieve list of card arrival
   	 * @exception Exception
   	 */
   	public List<CrdArvlVO> searchListCrdArvlRsdtCrdReisuce(CrdArvlVO vo) throws Exception {
  		return dao.selectListCrdArvlRsdtCrdReisuce(vo);
   	}
   	
   	
	/**
	 * Biz-method for eNID Card Reissuance<br>
	 * 
	 * @param vo Input item for eNID Card Reissuance(CrdArvlVO).
	 * @return 
	 * @exception Exception
	 */
	public void modifyArvlCadReisuce(CrdArvlVO vo) throws Exception {
		RsdtInfrVO rsdtVo = new RsdtInfrVO();
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		
		vo.setPrcssUserId(user.getUserId());
		log.debug("=======================================================");
		log.debug("modifyArvlCadReisuce  Stsrt");
		log.debug("=======================================================");
		
		if("Y".equals(vo.getSlcAllYn())){
			
			String [] rsdtSeqNo     = vo.getRsdtSeqNoAllList();
			String [] rsdtNo        = vo.getRsdtNoAllList();
			String [] oficSgnt      = vo.getOficSgntAllList();
			String [] crdDitbSeqNo  = vo.getCrdDitbSeqNoAllList();
			
			log.debug("=======================================================");
			log.debug("rsdtSeqNo.length : " + rsdtSeqNo.length);
			log.debug("=======================================================");
			
			for(int k=0;k<rsdtSeqNo.length; k++ ){
			
				log.debug("=======================================================");
				log.debug("rsdtSeqNo    ["+ k + "] : " + rsdtSeqNo[k]);
				log.debug("rsdtNo       ["+ k + "] : " + rsdtNo[k]);
				log.debug("crdDitbSeqNo ["+ k + "] : " + crdDitbSeqNo[k]);
				log.debug("=======================================================");
				
				//insert history
				rsdtDao.insertRsdtInfrHst(rsdtSeqNo[k], user.getUserId());	
				
				//citizen information update
				vo.setRsdtSeqNo(rsdtSeqNo[k]);
				dao.updateRsdtCrdIsuceSrlNo(vo);
				
				rsdtVo.setRsdtSeqNo(rsdtSeqNo[k]);
				//officer signature update		
				log.debug("=======================================================");
		   		log.debug("oficSgnt     ["+ k + "] | " + oficSgnt[k]);
		   		log.debug("=======================================================");
		   		String resultSgnt = rsdtInfoService.getXmlData(oficSgnt[k], "Signature");
		   		if(resultSgnt != null && resultSgnt.length() > 0){
		   			rsdtVo.setSgnt(resultSgnt);
			   		rsdtDao.updateRsdtInfrSgnt(rsdtVo);
		   		}					
				
		   		//system signature upeat
		   		EgovMap em = rsdtDao.selectRsdtInfrDat(rsdtSeqNo[k]);
		   		String hash = "";
		   		if(em != null && !em.isEmpty()){
		   			hash = rsdtDao.selectRsdtInfrHashDat(em, "24");
		   			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
					if(hash != null && hash.indexOf(reg) == -1){
						String admTel = nidMessageSource.getMessage("admTel");
						throw processException("pki.websrvcEror.msg", new String[]{hash, admTel});
					}
		   			resultSgnt = rsdtInfoService.getXmlData(hash, "ds:Signature");
		   		}
		   		
		   		if(resultSgnt != null && resultSgnt.length() > 0){
		   			rsdtVo.setSysSgnt(resultSgnt);
		   			rsdtDao.updateRsdtInfrSysSgnt(rsdtVo);
		   		}		   		
			}
			
			dao.updateArvlCadReisuceAll(vo);//IM_CRD_DITB_TB update	
			dao.updateArvlCadIsuceAll(vo);//IM_CRD_ISU_TB Update						
			dao.insertArvlCadReisuceAll(vo);//IM_CRD_ISU_TB insert
			
		} else {

			String [] array     = vo.getCheckboxList();
			String [] rsdtSeqNo = vo.getRsdtSeqNoList();
			String [] rsdtNo    = vo.getRsdtNoList();
			String [] oficSgnt  = vo.getOficSgntList();
			
			log.debug("=======================================================");
			log.debug("array.length : " + array.length);
			log.debug("=======================================================");
			if (array != null) {
				for(int k=0;k<array.length; k++ ){
					String [] rowData = array[k].split(",");
					log.debug("=======================================================");
					log.debug("Index        : " + rowData[0]);
					log.debug("CrdDitbSeqNo : " + rowData[1]);
					log.debug("rsdtSeqNo    : " + rsdtSeqNo[Integer.parseInt(rowData[0])]);
					log.debug("rsdtNo       : " + rsdtNo[Integer.parseInt(rowData[0])]);
					log.debug("=======================================================");
	
					//insert history
					rsdtDao.insertRsdtInfrHst(rsdtSeqNo[Integer.parseInt(rowData[0])], user.getUserId());
					
					//citizen information update
					vo.setRsdtSeqNo(rsdtSeqNo[Integer.parseInt(rowData[0])]);
					dao.updateRsdtCrdIsuceSrlNo(vo);
					
					rsdtVo.setRsdtSeqNo(rsdtSeqNo[Integer.parseInt(rowData[0])]);
					//officer signature update		
					log.debug("=======================================================");
			   		log.debug("oficSgnt     : " + oficSgnt[Integer.parseInt(rowData[0])]);
			   		log.debug("=======================================================");
			   		String resultSgnt = rsdtInfoService.getXmlData(oficSgnt[Integer.parseInt(rowData[0])], "Signature");
			   		if(resultSgnt != null && resultSgnt.length() > 0){			   			
			   			rsdtVo.setSgnt(resultSgnt);
				   		rsdtDao.updateRsdtInfrSgnt(rsdtVo);
			   		}	
			   		
			   		//system signature upeat
			   		EgovMap em = rsdtDao.selectRsdtInfrDat(rsdtSeqNo[Integer.parseInt(rowData[0])]);
			   		String hash = "";
			   		if(em != null && !em.isEmpty()){
			   			hash = rsdtDao.selectRsdtInfrHashDat(em, "24");
			   			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
						if(hash != null && hash.indexOf(reg) == -1){
							String admTel = nidMessageSource.getMessage("admTel");
							throw processException("pki.websrvcEror.msg", new String[]{hash, admTel});
						}
			   			resultSgnt = rsdtInfoService.getXmlData(hash, "ds:Signature");
			   		}
			   		
			   		if(resultSgnt != null && resultSgnt.length() > 0){
			   			rsdtVo.setSysSgnt(resultSgnt);
			   			rsdtDao.updateRsdtInfrSysSgnt(rsdtVo);
			   		}
			   		
					vo.setCrdDitbSeqNo(rowData[1]);
					dao.updateArvlCadReisuce(vo); //IM_CRD_DITB_TB update
					dao.updateArvlCadIsuce(vo);//IM_CRD_ISU_TB Update
					dao.insertArvlCadReisuce(vo); //IM_CRD_ISU_TB insert
				
				}//end for-k
	        }
		}

	}
	 
	/**
	 * Biz-method for Processing eNID Card Arrival<br>
	 * 
	 * @param vo Input item for Processing eNID Card Arrival(CrdArvlVO).
	 * @return 
	 * @exception Exception
	 */
	public void modifyArvl(CrdArvlVO vo) throws Exception {

		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		
		vo.setPrcssUserId(user.getUserId());
		log.debug("=======================================================");
		log.debug("modifyArvl  Stsrt");
		log.debug("=======================================================");
		
		if("Y".equals(vo.getSlcAllYn())){
			dao.updateArvlAll(vo);//IM_CRD_DITB_TB update			
		} else {			
			String [] array = vo.getCheckboxList();

			log.debug("=======================================================");
			log.debug("array.length : " + array.length);
			log.debug("=======================================================");
	
			if (array != null) {
				for(int k=0;k<array.length; k++ ){
					String [] rowData = array[k].split(",");
					log.debug("=======================================================");
					log.debug("array value : " + rowData[1]);
					log.debug("=======================================================");	
					vo.setCrdDitbSeqNo(rowData[1]);
					dao.updateArvl(vo); //IM_CRD_DITB_TB update
				}//end for-k
	        }
		}

	}	
	
	/**
	 * Biz-method for Processing eNID Card Arrival Clear<br>
	 * 
	 * @param vo Input item for Processing eNID Card Arrival Clear(CrdArvlVO).
	 * @return 
	 * @exception Exception
	 */
	public void modifyArvlClar(CrdArvlVO vo) throws Exception {

		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		
		vo.setPrcssUserId(user.getUserId());
		log.debug("=======================================================");
		log.debug("modifyArvlClar  Stsrt");
		log.debug("=======================================================");
		
		if("Y".equals(vo.getSlcAllYn())){
			dao.updateArvlClarAll(vo);//IM_CRD_DITB_TB update			
		} else {
			
			String [] array = vo.getCheckboxList();

			log.debug("=======================================================");
			log.debug("array.length : " + array.length);
			log.debug("=======================================================");
	
			if (array != null) {
				for(int k=0;k<array.length; k++ ){
					String [] rowData = array[k].split(",");
					log.debug("=======================================================");
					log.debug("array value : " + rowData[1]);
					log.debug("=======================================================");
	
					vo.setCrdDitbSeqNo(rowData[1]);
					dao.updateArvlClar(vo); //IM_CRD_DITB_TB update
				}//end for-k
	        }
		}

	}
	
    /**
   	 * Biz-method for retrieving list of Issuance Failed Citizens. <br>
   	 *
   	 * @param vo Input item for retrieving list of Issuance Failed Citizens(CrdArvlVO).
   	 * @return List Retrieve list of Issuance Failed Citizens
   	 * @exception Exception
   	 */
   	public List<CrdArvlVO> searchListCrdFailRsdt(CrdArvlVO vo) throws Exception {
      		return dao.selectListCrdFailRsdt(vo);
   	}

   	/**
	 * Biz-method for retrieving total count list of Issuance Failed Citizens. <br>
	 *
	 * @param vo Input item for retrieving list of Issuance Failed Citizens(CrdArvlVO).
	 * @return int Total Count of Issuance Failed Citizens
	 * @exception Exception
	 */
   	public int searchListCrdFailRsdtTotCn(CrdArvlVO vo) throws Exception {
        return dao.selectListCrdFailRsdtTotCn(vo);
	}
	
   	
	/**
	 * Biz-method for modify citizen contact Y/N<br>
	 * 
	 * @param vo Input item for modify citizen contact Y/N(CrdArvlVO).
	 * @return 
	 * @exception Exception
	 */
	public void modifyCrdFailRsdt(CrdArvlVO vo) throws Exception {
		RsdtInfrVO rsdtVo = new RsdtInfrVO();
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		
		vo.setPrcssUserId(user.getUserId());
		
		//update citizen contact Y/N
		dao.updateCrdFailRsdt(vo);
		rsdtVo.setRsdtSeqNo(vo.getRsdtSeqNo());
		
		//insert history
		rsdtDao.insertRsdtInfrHst(vo.getRsdtSeqNo(), user.getUserId());
		
		//citizen information update
		dao.updateRsdtInfr(vo);
		
		//officer signature update		
   		log.debug("getXmlData(vo.getSgnt(), Signature)");
   		log.debug(vo.getSgnt());
   		String resultSgnt = rsdtInfoService.getXmlData(vo.getSgnt(), "Signature");
   		if(resultSgnt != null && resultSgnt.length() > 0){
   			rsdtVo.setSgnt(resultSgnt);
	   		rsdtDao.updateRsdtInfrSgnt(rsdtVo);
   		}		
		
   		//system signature upeat
   		EgovMap em = rsdtDao.selectRsdtInfrDat(vo.getRsdtSeqNo());
   		String hash = "";
   		if(em != null && !em.isEmpty()){
   			hash = rsdtDao.selectRsdtInfrHashDat(em, "23");
   			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
			if(hash != null && hash.indexOf(reg) == -1){
				String admTel = nidMessageSource.getMessage("admTel");
				throw processException("pki.websrvcEror.msg", new String[]{hash, admTel});
			}
   			resultSgnt = rsdtInfoService.getXmlData(hash, "ds:Signature");
   		}
   		
   		if(resultSgnt != null && resultSgnt.length() > 0){
   			rsdtVo.setSysSgnt(resultSgnt);
   			rsdtDao.updateRsdtInfrSysSgnt(rsdtVo);
   		}
   		
	}  
	
	
}
