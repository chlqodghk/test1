package afnid.rm.crd.service;

import java.util.List;
import egovframework.rte.psl.dataaccess.util.EgovMap;



/** 
 * This service interface is biz-class of eNID Card New Issuance Candidate List. <br>
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.06.10
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2013.06.10  		Moon Soo Kim                          Create
 *
 * </pre>
 */
public interface CrdNewIsuceCddService {
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdNewIsuceCddVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchListCrdNewIsuceCdd(CrdNewIsuceCddVO vo) throws Exception;
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(CrdNewIsuceCddVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListCrdNewIsuceCddTotCn(CrdNewIsuceCddVO vo) throws Exception;
	
	/**
	 * Retrieves convert New Issuance Criteria date for search list as calendar type. <br>
	 * @param vo Input item for retrieving convert New Issuance Criteria date for search list as calendar type.(CrdNewIsuceCddVO)
	 * @return String converted date
	 * @exception Exception
	 */
	String searchDdCvt(CrdNewIsuceCddVO vo) throws Exception;
	
	/**
	 * Retrieves Card New Issuance Candidate List to download Excel. <br>
	 * @param vo Input item for retrieving Card New Issuance Candidate List.(CrdNewIsuceCddVO)
	 * @return ExcelVO
	 * @exception Exception
	 */
	List<CrdNewIsuceCddVO>  searchListCrdNewIsuceCddExcel(CrdNewIsuceCddVO vo) throws Exception;
}
