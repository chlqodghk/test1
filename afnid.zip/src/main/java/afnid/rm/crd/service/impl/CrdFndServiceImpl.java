package afnid.rm.crd.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.pkiif.ccm.CardKillRequestInput;
import afnid.pkiif.ccm.CardKillRequestOutput;
import afnid.pkiif.ccm.CardKillResultInput;
import afnid.pkiif.ccm.CardKillResultOutput;
import afnid.pkiif.ccm.RMCCM;
import afnid.pkiif.ccm.RMCCM_Service;
import afnid.pkiif.cpki.CpkiRmWS;
import afnid.pkiif.cpki.CpkiRmWSService;
import afnid.pkiif.cpki.PkiRsWsResponse;
import afnid.rm.crd.service.CrdFndService;
import afnid.rm.crd.service.CrdFndVO;
import afnid.rm.rsdt.service.RsdtInfrService;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of Found Card
 * and implements CrdFndService class.
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.04  		BH Choi         							Create
 *
 * </pre>
 */
@Service("crdFndService")
public class CrdFndServiceImpl extends AbstractServiceImpl implements CrdFndService{
	
	/** crdFndDAO */
    @Resource(name="crdFndDAO")
    private CrdFndDAO dao;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;  
    
    /** LgDAO */
    @Resource(name="lgDAO")
    private LgDAO lgDao;
    
    /** RsdtInfrDAO */
	@Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtDao;
	
	/** RsdtInfrService */
	@Resource(name = "rsdtInfoService")
    private RsdtInfrService rsdtInfrService;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
	
	/**
	 * Biz-method for retrieving count of resident information for card found registration. <br>
	 *
	 * @param vo Input item for retrieving count of resident information for card found registration(CrdFndVO).
	 * @return int Count of resident information for card found registration
	 * @exception Exception
	 */
   	public int searchCrdIssuedCn(CrdFndVO vo) throws Exception {
        return dao.selectCrdIssuedCn(vo);
	}

   	/**
   	 * Biz-method for retrieving resident information for card found registration. <br>
   	 *
   	 * @param vo Input item for retrieving resident information for card found registration(CrdFndVO).
   	 * @return CrdFndVO Retrieve resident information for card found registration
   	 * @exception Exception
   	 */
   	public CrdFndVO searchCrdFndInfr(CrdFndVO vo) throws Exception {
      		return dao.selectCrdFndInfr(vo);
   	}
   	
   	/**
	 * Biz-method for retrieving count of card issuing information. <br>
	 *
	 * @param vo Input item for retrieving count of card issuing information.(CrdFndVO).
	 * @return int Count of card issuing information.
	 * @exception Exception
	 */
   	public int searchCrdIsuceStusCn(String rsdtNo) throws Exception {
        return dao.selectCrdIsuceStusCn(rsdtNo);
	}
   	
    /**
	 * Biz-method for registering information of card found. <br>
	 * 
	 * @param vo Input item for retrieving list of program(CrdFndVO).
	 * @return void 
	 * @exception Exception
	 */
	public CrdFndVO addCrdFndInfr(CrdFndVO vo) throws Exception {  
		
		String seq = dao.insertCrdFndInfr( vo );
		vo.setRptSeqNo(seq);
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		

		//setting CMS web Service parameter value
		String reportNo = "091"+seq;
		String rsdtNo  = vo.getRsdtNo();
		
		CrdFndVO crdInfr = dao.selectCrdIsuceInfr(rsdtNo);
		String hCrdIsuceDd= crdInfr.gethCrdIsuceDd();
		int crdIsuceSrlNo = Integer.parseInt(crdInfr.getCrdIsuceSrlNo());
		
		CardKillRequestInput data = new CardKillRequestInput();
		data.setRequestType(1);
		data.setCardIssuanceDate(hCrdIsuceDd);
		data.setENID(rsdtNo);
		data.setReportNumber(reportNo);
		data.setLastIssuanceSequenceNo(crdIsuceSrlNo);
		data.setPrintedIssuanceSequenceNo(Integer.parseInt(vo.getPrntCrdIsuceSrlNo()));
		
		log.debug("rqstTye :1");
		log.debug("reportNo :" + reportNo);
		log.debug("rsdtNo :" + rsdtNo);
		log.debug("hCrdIsuceDd :" + hCrdIsuceDd);
		log.debug("crdIsuceSrlNo :" + crdIsuceSrlNo);
		log.debug("PrintedIssuanceSequenceNo :" + vo.getPrntCrdIsuceSrlNo());

	    //Insert PKI log
		String rqstDat  = data.getRequestType()            + ":"
	                    + data.getCardIssuanceDate()       + ":"
				        + data.getENID()                   + ":"
	                    + data.getReportNumber()           + ":"
	                    + data.getLastIssuanceSequenceNo() + ":"
				        + data.getPrintedIssuanceSequenceNo();
		
		String lgSeqNo = lgDao.insertPubKeyIfLg(user.getUserId(), vo.getRsdtNo(), "21", "1", "9", rqstDat);
		vo.setLgSeqNo(lgSeqNo);
		return vo;
	}
	
	
	/**
	 * Biz-method for registering information of new user(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for registering new user(CrdFndVO).
	 * @return CrdFndVO Primary Key value of registered user
	 * @exception Exception
	 */
	public String addCrdFndInfrPkiIf(CrdFndVO vo) throws Exception {
		
		String status = "";
		String erorYn ="Y";

		//setting CMS web Service parameter value
		String reportNo = "091"+vo.getRptSeqNo();
		String rsdtNo  = vo.getRsdtNo();
		
		CrdFndVO crdInfr = dao.selectCrdIsuceInfr(rsdtNo);
		String hCrdIsuceDd= crdInfr.gethCrdIsuceDd();
		int crdIsuceSrlNo = Integer.parseInt(crdInfr.getCrdIsuceSrlNo());
		
		CardKillRequestInput data = new CardKillRequestInput();
		data.setRequestType(1);
		data.setCardIssuanceDate(hCrdIsuceDd);
		data.setENID(rsdtNo);
		data.setReportNumber(reportNo);
		data.setLastIssuanceSequenceNo(crdIsuceSrlNo);
		data.setPrintedIssuanceSequenceNo(Integer.parseInt(vo.getPrntCrdIsuceSrlNo()));
		
		log.debug("rqstTye :1");
		log.debug("reportNo :" + reportNo);
		log.debug("rsdtNo :" + rsdtNo);
		log.debug("hCrdIsuceDd :" + hCrdIsuceDd);
		log.debug("crdIsuceSrlNo :" + crdIsuceSrlNo);
		log.debug("PrintedIssuanceSequenceNo :" + vo.getPrntCrdIsuceSrlNo());
		
		//Citizen Account Revocation 
		RMCCM_Service rmCcmWs= new RMCCM_Service();
		RMCCM rmCcm = rmCcmWs.getRMCCMPort();	
			
		CardKillRequestOutput ckro = rmCcm.cardKillRequest(data);
		
		int cmsResult = ckro.getResult(); // 1: OK 2:ERROR 
		
		status = String.valueOf(cmsResult);
		log.debug("status ====> " + status);
		
		if("1".equals(status)){//OK
			erorYn ="N";
		} else {
			if(ckro.getFailCode()!= null && "".equals(ckro.getFailCode())){
				status = ckro.getFailCode();
			} else {
				status ="None";
			}			
		}
		
		lgDao.updatePubKeyIfLg(vo.getLgSeqNo(), status, erorYn);			
				
    	return status;
    	
	}	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CrdFndVO).
   	 * @return List<EgovMap> Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchListCrdFndAprv(CrdFndVO vo) throws Exception {
      		return dao.selectListCrdFndAprv(vo);
   	}
   	
    /**
	 * Biz-method for retrieving total count of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdFndVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
   	public int searchListCrdFndAprvTotCn(CrdFndVO vo) throws Exception {
        return dao.selectListCrdFndAprvTotCn(vo);
	}
   	
   	/**
   	 * Biz-method for retrieving information of program. <br>
   	 *
   	 * @param vo Input item for retrieving information of program(CrdFndVO).
   	 * @return CrdFndVO Retrieve list of program
   	 * @exception Exception
   	 */
   	public CrdFndVO searchCrdFndDtlAprv(CrdFndVO vo) throws Exception {
   		
		String erorYn ="N";
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		
   		CrdFndVO result = dao.selectCrdFndDtlAprv(vo);

   		//Call CMS method 
		if("N".equals(result.getTamLedrCfmYn()) ){
			
			//setting CMS web Service parameter value
			String seq = "091"+result.getFondCrdSeqNo();
			String rsdtNo = result.getRsdtNo();
			
			CardKillResultInput data = new CardKillResultInput();
			data.setENID(rsdtNo);
			data.setReportNumber(seq);
			log.debug("input reportNo :" + seq);
			log.debug("input rsdtNo :" + rsdtNo);
			
			String rqstDat =data.getENID() + ":" + data.getReportNumber();
			String lgSeqNo = lgDao.insertPubKeyIfLg(user.getUserId(), rsdtNo, "22", "1", "9", rqstDat);
			
			// Call CMS Web Service
			RMCCM_Service rmCcmWs= new RMCCM_Service();
			RMCCM rmCcm = rmCcmWs.getRMCCMPort();
			
			CardKillResultOutput ckro = rmCcm.cardKillResult(data);
			
			if(ckro == null){
				String helpTelNo = nidMessageSource.getMessage("admTelNo");	
				throw processException( "pki.websrvcEror.msg", new String[]{"none", helpTelNo});
			}
		
			int cmsResult = ckro.getResult(); 
			//cmsResult : 1=Request Received, 2=Completed with kill, 3=Completed without kill, 4=Error
			
			String failCd = "";
			if(cmsResult == 1){
				result.setCmsWorkRsut(String.valueOf(cmsResult));
				result.setCmsCrdIsuceDd("");
				result.setCmsCrdIsuceSrlNo("");
			}else if(cmsResult == 2 || cmsResult == 3){
				result.setCmsWorkRsut(String.valueOf(cmsResult));
				String cmsCrdIsuceDd = dao.selectDataChngToGre(ckro.getChipIssuanceDate());
				result.setCmsCrdIsuceDd(cmsCrdIsuceDd);
				result.setCmsCrdIsuceSrlNo(String.valueOf(ckro.getChipIssuanceSeq()));
			}else if(cmsResult == 4){
				result.setCmsWorkRsut(String.valueOf(cmsResult));
				erorYn = "Y";
				failCd = ckro.getFailCode();	
			}else{
				erorYn = "Y";
				failCd = "none";
			}
			
			lgDao.updatePubKeyIfLg(lgSeqNo, String.valueOf(cmsResult), erorYn);
			
			if("Y".equals(erorYn)){
				String helpTelNo = nidMessageSource.getMessage("admTelNo");	
				throw processException( "pki.websrvcEror.msg", new String[]{failCd, helpTelNo});
			}
		}

   		return result;
   	}
   	
   	/**
	 * Biz-method for update Printed Card Sequence No. <br>
	 * 
	 * @param vo Input item for update Printed Card Sequence No.(CrdFndVO).
	 * @return void
	 * @exception Exception
	 */
	public void modifyPrntCrdSrlNo(CrdFndVO vo) throws Exception {   	
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
		vo.setUserId(user.getUserId());
		
		boolean resultDb = dao.updatePrntCrdSrlNo( vo );
		
		if(!resultDb ){
			throw processException( "udtFail.msg");
		}
		
		int cmsResult  = -1;
		
		//setting CMS web Service parameter value
		String reportNo = "091"+vo.getFondCrdSeqNo();
		String rsdtNo  = vo.getRsdtNo();
		
		CrdFndVO crdInfr = dao.selectCrdIsuceInfr(rsdtNo);
		String hCrdIsuceDd= crdInfr.gethCrdIsuceDd();
		int crdIsuceSrlNo = Integer.parseInt(crdInfr.getCrdIsuceSrlNo());
		
		CardKillRequestInput data = new CardKillRequestInput();
		data.setRequestType(1);
		data.setCardIssuanceDate(hCrdIsuceDd);
		data.setENID(rsdtNo);
		data.setReportNumber(reportNo);
		data.setLastIssuanceSequenceNo(crdIsuceSrlNo);
		data.setPrintedIssuanceSequenceNo(Integer.parseInt(vo.getPrntCrdIsuceSrlNo()));
		
		log.debug("rqstTye :1");
		log.debug("reportNo :" + reportNo);
		log.debug("rsdtNo :" + rsdtNo);
		log.debug("hCrdIsuceDd :" + hCrdIsuceDd);
		log.debug("crdIsuceSrlNo :" + crdIsuceSrlNo);
		log.debug("PrintedIssuanceSequenceNo :" + vo.getPrntCrdIsuceSrlNo());
		
		String lgSeqNo = lgDao.insertPubKeyIfLg(user.getUserId(), rsdtNo, "26", "1", "9", "");
		// Call CMS Web Service	
		RMCCM_Service rmCcmWs= new RMCCM_Service();
		RMCCM rmCcm = rmCcmWs.getRMCCMPort();
		
		CardKillRequestOutput ckro = rmCcm.cardKillChangePrintedSequenceNo(data);
		
		if(ckro == null){
			String helpTelNo = nidMessageSource.getMessage("admTelNo");	
			throw processException( "pki.websrvcEror.msg", new String[]{"none", helpTelNo});
		}
		
		cmsResult = ckro.getResult(); // 1: OK 2:ERROR 
		
		String erorYn ="N";
		if(cmsResult != 1){
			erorYn ="Y";
		}
		
		lgDao.updatePubKeyIfLg(lgSeqNo, String.valueOf(cmsResult), erorYn);
		
		if(cmsResult != 1){
			if(cmsResult == 2 ){
				String helpTelNo = nidMessageSource.getMessage("admTelNo");	
				throw processException( "pki.websrvcEror.msg", new String[]{ckro.getFailCode(), helpTelNo});				
			}else{
				String helpTelNo = nidMessageSource.getMessage("admTelNo");	
				throw processException( "pki.websrvcEror.msg", new String[]{"none", helpTelNo});
			}
		}
		
		
	}
   	
    /**
	 * Biz-method for update information of program. <br>
	 * 
	 * @param vo Input item for update information of program(CrdFndVO).
	 * @return void
	 * @exception Exception
	 */
	public void modifyCrdFndDtlAprv(CrdFndVO vo) throws Exception {   	
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());	
		vo.setUserId(user.getUserId());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());  
		vo.setFondDd(NidStringUtil.toNumberConvet(vo.getFondDd(), "g"));
		
		boolean result = dao.updateCrdFndDtlAprv(vo);
		
		if(!result ){
			throw processException( "udtFail.msg");
		}
		
		
	}  
	
    /**
	 * Biz-method for approval information of program. <br>
	 * 
	 * @param vo Input item for approval information of program(CrdFndVO).
	 * @return void
	 * @exception Exception
	 */
	public String approveCrdFndInfr(CrdFndVO vo) throws Exception {   	
		String lgSeqNo = "";
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setUserId(user.getUserId());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());
		vo.setFondDd(NidStringUtil.toNumberConvet(vo.getFondDd(), "g"));

		vo.setDsuseCrdRsnCt("");
		
		if("2".equals(vo.getCrdPrcssStusCd()) || "3".equals(vo.getCrdPrcssStusCd())){
			vo.setMnSeqNo("53");
		} 
		
		//check card statue
		if(!"1".equals(vo.getCrdPrcssStusCd()) ){//서트 사용 불가 카드 처리
			boolean aprvResult = dao.updateCrdFndAprvOnlyFoundTb(vo);
			
			if(!aprvResult){
				throw processException( "udtFail.msg");
			}
			
		}else{//서트 사용가능한 카드 정지 시기는곳
			//Insert the Citizen information on DB for history before the changing
			rsdtDao.insertRsdtInfrHst(vo.getRsdtSeqNo(), user.getUserId());
			
			boolean result = dao.updateCrdFndAprv( vo );
			
			if(!result){
				throw processException( "udtFail.msg");
			}
			
			//Update Signature Data to RM_RSDT_TB
			rsdtInfrService.updateDigitalSgnt(vo.getRsdtSeqNo(), vo.getSgntDat(), "9");
				
			//get PKI cert issuance count
			int crtisuceCn = rsdtInfrService.searchPkiCrtIsuceCn(vo.getRsdtSeqNo());
			
			if(0 < crtisuceCn){
			    //Insert PKI log
			    lgSeqNo = lgDao.insertPubKeyIfLg(user.getUserId(), vo.getRsdtNo(), "7", "1", "9", "");

			}
		}
		
		return lgSeqNo;
	}
	
	/**
	 * Biz-method for registering information of new user(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for registering new user(CrdFndVO).
	 * @return CrdFndVO Primary Key value of registered user
	 * @exception Exception
	 */
	public String approveCrdFndInfrPkiIf(CrdFndVO vo) throws Exception {
		
		String status = "";
		String erorYn ="Y";


		//PKI Cert Hold
		CpkiRmWSService orws= new CpkiRmWSService();
		CpkiRmWS orw = orws.getCpkiRmWSPort();	
			
		PkiRsWsResponse prwr = orw.cpkiIFcertHold(vo.getRsdtNo());
		status= prwr.getStatusCode();
		
		log.debug("status ====> " + status);
		if("0".equals(status)){
			erorYn ="N";
		}
		lgDao.updatePubKeyIfLg(vo.getLgSeqNo(), status, erorYn);		
		
    	return status;
    	
	}
	
	 /**
	 * Biz-method for Modify information of program. <br>
	 * 
	 * @param rsdtNo Input item for Modify information of program(String).
	 * @return List<String> result
	 * @exception Exception
	 */
	public List<String> modifyCrdFndPrcssStus(String rsdtNo, String dsuseCrdRsnCd, String dsuseCrdRsnCt, String mnSeqNo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		
		List<String> orgnzNmList = new ArrayList<String>();
		String orgnzNm = "";
		EgovMap map = new EgovMap();
		map.put("useLangCd", user.getUseLangCd()); 
		map.put("rsdtNo", rsdtNo);

		List<CrdFndVO> crdInfrList = dao.selectListCrdFndInfr(map);
		for(int i=0; i < crdInfrList.size(); i++){
			
			CrdFndVO crdInfr = crdInfrList.get(i);
			crdInfr.setUseLangCd(user.getUseLangCd());
			crdInfr.setUserId(user.getUserId());
			
			crdInfr.setDsuseCrdRsnCd(dsuseCrdRsnCd);
			crdInfr.setDsuseCrdRsnCt(dsuseCrdRsnCt);
			crdInfr.setMnSeqNo(mnSeqNo);
			
			
			if("1".equals(crdInfr.getCrdPrcssStusCd())){//distribution ready
				orgnzNm = dao.updateCrdPrcssStusCd(crdInfr);
				if(null!=orgnzNm && !"".equals(orgnzNm)){
					orgnzNmList	=setOrgnzNm(orgnzNmList, orgnzNm);
				}else{
					throw processException( "udtFail.msg");
				}
			}else if("2".equals(crdInfr.getCrdPrcssStusCd())){//move
				boolean result = dao.updateSndFondCrdStusCd(crdInfr);
				if(!result){
					throw processException( "udtFail.msg");
				}
			}
		}
		return orgnzNmList;
	}
	
	 /**
	 * Biz-method for setting Name of Organization . <br>
	 * 
	 * @param orgnzNmList Input item for check duplication (List<String>).
	 * @param orgnz Input item for add Organization Name
	 * @return List<String> result
	 * @exception Exception
	 */
	public List<String> setOrgnzNm(List<String> orgnzNmList,String orgnz) throws Exception{
		
		boolean isSame = false;
		
		for(int i=0; i < orgnzNmList.size(); i++){
			String orgnzNm = orgnzNmList.get(i);
				if(orgnz.equals(orgnzNm) ){
					isSame = true;
				}	
		}
		
		if(!isSame){
			orgnzNmList.add(orgnz);
		}
		
		return orgnzNmList;
	}
}