package afnid.rm.crd.service;

import afnid.cm.ComDefaultVO;

public class CrdFndSndVO extends ComDefaultVO {
	
	private static final long serialVersionUID = 1L;
	
	private String mnSeqNo;
	private String crdDsuseRsnCd;
	private String crdDsuseRsnCt;
	private String fondCrdSeqNo;
	private String sndOrgnzCd;
	private String rcivOrgnzCd;
	private String rcivOrgnzCdNm;
	private String sndRgstDd;
	private String sndTamLedrCfmYn;
	private String sndCfmTamLedrId;
	private String sndCfmDd;
	private String today;
	private String rcivTamLedrCfmYn;
	private String rsdtSeqNo;
	private String rsdtNo;
	private String rsdtNoDp;
	private String rsdtName;
	private String fthrNm;
	private String gfthrNm;
	private String bthDd;
	private String bthDdJ;
	private String bthDdG;
	private String gdrCd;
	private String gdrCdNm;
	private String pmntAdCd;
	private String pmntAdCdNm;
	private String pmntAdDtlCt;
	private String curtAdCd;
	private String curtAdCdNm;
	private String curtAdDtlCt;
	private String rsdtStusCd;
	private String rsdtStusCdNm;
	
	private Boolean uprOrgFlag = false;
	private Boolean udrOrgFlag = false;
	private String udrOrgnzCd;
	private String uprOrgnzCd;
	private String orgnzCd;
	private String orgnzCdNm;
	private String orgnzClsCd;
	private String callPopupYn = "N";
	private String popFlag;
	private String fondDd;
	private String fondDdJ;
	private String fondDdG;
		
	private String lstUdtUserId;
	private String fstRgstUserId;
	private String sndRgstUserId;
	private String ersrCd;
	private String ersrCdNm;
	private String sndFondCrdStusCd;
	private String crdIsuceDd;
	private String crdIsuceDdG;
	private String crdIsuceDdJ;
	private String crdIsuceSrlNo;	
	private String crdExpiryDd;
	private String rgstOrgnzCd;
	private String rgstOrgnzCdNm;
	
	
	public String getRgstOrgnzCd() {
		return rgstOrgnzCd;
	}
	public void setRgstOrgnzCd(String rgstOrgnzCd) {
		this.rgstOrgnzCd = rgstOrgnzCd;
	}
	public String getRgstOrgnzCdNm() {
		return rgstOrgnzCdNm;
	}
	public void setRgstOrgnzCdNm(String rgstOrgnzCdNm) {
		this.rgstOrgnzCdNm = rgstOrgnzCdNm;
	}
	public String getRcivTamLedrCfmYn() {
		return rcivTamLedrCfmYn;
	}
	public void setRcivTamLedrCfmYn(String rcivTamLedrCfmYn) {
		this.rcivTamLedrCfmYn = rcivTamLedrCfmYn;
	}
	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}
	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}
	public String getBthDdJ() {
		return bthDdJ;
	}
	public void setBthDdJ(String bthDdJ) {
		this.bthDdJ = bthDdJ;
	}
	public String getBthDdG() {
		return bthDdG;
	}
	public void setBthDdG(String bthDdG) {
		this.bthDdG = bthDdG;
	}
	public String getFondDdJ() {
		return fondDdJ;
	}
	public void setFondDdJ(String fondDdJ) {
		this.fondDdJ = fondDdJ;
	}
	public String getFondDdG() {
		return fondDdG;
	}
	public void setFondDdG(String fondDdG) {
		this.fondDdG = fondDdG;
	}
	public String getCrdIsuceDdG() {
		return crdIsuceDdG;
	}
	public void setCrdIsuceDdG(String crdIsuceDdG) {
		this.crdIsuceDdG = crdIsuceDdG;
	}
	public String getCrdIsuceDdJ() {
		return crdIsuceDdJ;
	}
	public void setCrdIsuceDdJ(String crdIsuceDdJ) {
		this.crdIsuceDdJ = crdIsuceDdJ;
	}
	public String getSndFondCrdStusCd() {
		return sndFondCrdStusCd;
	}
	public void setSndFondCrdStusCd(String sndFondCrdStusCd) {
		this.sndFondCrdStusCd = sndFondCrdStusCd;
	}
	public String getErsrCd() {
		return ersrCd;
	}
	public void setErsrCd(String ersrCd) {
		this.ersrCd = ersrCd;
	}
	public String getErsrCdNm() {
		return ersrCdNm;
	}
	public void setErsrCdNm(String ersrCdNm) {
		this.ersrCdNm = ersrCdNm;
	}
	public String getFondDd() {
		return fondDd;
	}
	public void setFondDd(String fondDd) {
		this.fondDd = fondDd;
	}
	public String getRcivOrgnzCdNm() {
		return rcivOrgnzCdNm;
	}
	public void setRcivOrgnzCdNm(String rcivOrgnzCdNm) {
		this.rcivOrgnzCdNm = rcivOrgnzCdNm;
	}
	public String getCallPopupYn() {
		return callPopupYn;
	}
	public void setCallPopupYn(String callPopupYn) {
		this.callPopupYn = callPopupYn;
	}
	public String getPopFlag() {
		return popFlag;
	}
	public void setPopFlag(String popFlag) {
		this.popFlag = popFlag;
	}
	public String getSndCfmDd() {
		return sndCfmDd;
	}
	public void setSndCfmDd(String sndCfmDd) {
		this.sndCfmDd = sndCfmDd;
	}
	public String getRsdtStusCd() {
		return rsdtStusCd;
	}
	public void setRsdtStusCd(String rsdtStusCd) {
		this.rsdtStusCd = rsdtStusCd;
	}
	public String getRsdtStusCdNm() {
		return rsdtStusCdNm;
	}
	public void setRsdtStusCdNm(String rsdtStusCdNm) {
		this.rsdtStusCdNm = rsdtStusCdNm;
	}
	public String getToday() {
		return today;
	}
	public void setToday(String today) {
		this.today = today;
	}
	public String getRsdtName() {
		return rsdtName;
	}
	public void setRsdtName(String rsdtName) {
		this.rsdtName = rsdtName;
	}
	public String getPmntAdCdNm() {
		return pmntAdCdNm;
	}
	public void setPmntAdCdNm(String pmntAdCdNm) {
		this.pmntAdCdNm = pmntAdCdNm;
	}
	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}
	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}
	public String getUdrOrgnzCd() {
		return udrOrgnzCd;
	}
	public void setUdrOrgnzCd(String udrOrgnzCd) {
		this.udrOrgnzCd = udrOrgnzCd;
	}
	public String getUprOrgnzCd() {
		return uprOrgnzCd;
	}
	public void setUprOrgnzCd(String uprOrgnzCd) {
		this.uprOrgnzCd = uprOrgnzCd;
	}
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String getOrgnzCdNm() {
		return orgnzCdNm;
	}
	public void setOrgnzCdNm(String orgnzCdNm) {
		this.orgnzCdNm = orgnzCdNm;
	}
	public String getOrgnzClsCd() {
		return orgnzClsCd;
	}
	public void setOrgnzClsCd(String orgnzClsCd) {
		this.orgnzClsCd = orgnzClsCd;
	}
	public Boolean getUprOrgFlag() {
		return uprOrgFlag;
	}
	public void setUprOrgFlag(Boolean uprOrgFlag) {
		this.uprOrgFlag = uprOrgFlag;
	}

	public Boolean getUdrOrgFlag() {
		return udrOrgFlag;
	}
	public void setUdrOrgFlag(Boolean udrOrgFlag) {
		this.udrOrgFlag = udrOrgFlag;
	}

	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}
	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}
	public String getBthDd() {
		return bthDd;
	}
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getFthrNm() {
		return fthrNm;
	}
	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}
	public String getGfthrNm() {
		return gfthrNm;
	}
	public void setGfthrNm(String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}
	public String getGdrCd() {
		return gdrCd;
	}
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	public String getPmntAdCd() {
		return pmntAdCd;
	}
	public void setPmntAdCd(String pmntAdCd) {
		this.pmntAdCd = pmntAdCd;
	}
	public String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}
	public void setPmntAdDtlCt(String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	
	public String getFondCrdSeqNo() {
		return fondCrdSeqNo;
	}
	public void setFondCrdSeqNo(String fondCrdSeqNo) {
		this.fondCrdSeqNo = fondCrdSeqNo;
	}
	public String getSndOrgnzCd() {
		return sndOrgnzCd;
	}
	public void setSndOrgnzCd(String sndOrgnzCd) {
		this.sndOrgnzCd = sndOrgnzCd;
	}
	public String getRcivOrgnzCd() {
		return rcivOrgnzCd;
	}
	public void setRcivOrgnzCd(String rcivOrgnzCd) {
		this.rcivOrgnzCd = rcivOrgnzCd;
	}
	public String getSndRgstDd() {
		return sndRgstDd;
	}
	public void setSndRgstDd(String sndRgstDd) {
		this.sndRgstDd = sndRgstDd;
	}
	public String getSndRgstUserId() {
		return sndRgstUserId;
	}
	public void setSndRgstUserId(String sndRgstUserId) {
		this.sndRgstUserId = sndRgstUserId;
	}

	public String getSndTamLedrCfmYn() {
		return sndTamLedrCfmYn;
	}
	public void setSndTamLedrCfmYn(String sndTamLedrCfmYn) {
		this.sndTamLedrCfmYn = sndTamLedrCfmYn;
	}
	public String getSndCfmTamLedrId() {
		return sndCfmTamLedrId;
	}
	public void setSndCfmTamLedrId(String sndCfmTamLedrId) {
		this.sndCfmTamLedrId = sndCfmTamLedrId;
	}
	
	public String getFstRgstUserId() {
		return fstRgstUserId;
	}
	public void setFstRgstUserId(String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}
	
	public String getLstUdtUserId() {
		return lstUdtUserId;
	}
	public void setLstUdtUserId(String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public String getCrdIsuceSrlNo() {
		return crdIsuceSrlNo;
	}
	public void setCrdIsuceSrlNo(String crdIsuceSrlNo) {
		this.crdIsuceSrlNo = crdIsuceSrlNo;
	}
	public String getMnSeqNo() {
		return mnSeqNo;
	}
	public void setMnSeqNo(String mnSeqNo) {
		this.mnSeqNo = mnSeqNo;
	}
	public String getCrdDsuseRsnCd() {
		return crdDsuseRsnCd;
	}
	public void setCrdDsuseRsnCd(String crdDsuseRsnCd) {
		this.crdDsuseRsnCd = crdDsuseRsnCd;
	}
	public String getCrdDsuseRsnCt() {
		return crdDsuseRsnCt;
	}
	public void setCrdDsuseRsnCt(String crdDsuseRsnCt) {
		this.crdDsuseRsnCt = crdDsuseRsnCt;
	}
	
}
