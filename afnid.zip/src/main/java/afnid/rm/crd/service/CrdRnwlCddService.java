package afnid.rm.crd.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service interface is biz-class of eNID Card Renewal Candidate List. <br>
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2013.01.04  		BH Choi				Create
 *
 * </pre>
 */
public interface CrdRnwlCddService {
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdRnwlCddVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchListCrdRnwlCdd(CrdRnwlCddVO vo) throws Exception;
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(CrdRnwlCddVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListCrdRnwlCddTotCn(CrdRnwlCddVO vo) throws Exception;
	
	/**
	 * Retrieves convert Expire date for search list as calendar type. <br>
	 * @param vo Input item for retrieving convert Expire date for search list as calendar type.(CrdRnwlCddVO)
	 * @return String converted date
	 * @exception Exception
	 */
	String searchDdCvt(CrdRnwlCddVO vo) throws Exception;
	
	/**
	 * Retrieves Card Renewal Candidate List to download Excel. <br>
	 * @param vo Input item for retrieving Card Renewal Candidate List.(CrdRnwlCddVO)
	 * @return ExcelVO
	 * @exception Exception
	 */
	List<CrdRnwlCddVO> searchListCrdRnwlCddExcel(CrdRnwlCddVO vo) throws Exception;
}
