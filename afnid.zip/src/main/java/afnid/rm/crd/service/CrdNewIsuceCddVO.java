package afnid.rm.crd.service;

import afnid.cm.ComDefaultVO;

public class CrdNewIsuceCddVO extends ComDefaultVO {
	
	private static final long serialVersionUID = 1L;
	
	//family book no
	private String fmlyBokNo;
	private String fmlyMberNo;
	//family book number for screen display
	private String fmlyBokNoDp;
	//resident no
	private String rsdtNo;
	//given name
	private String givNm;
	//surname
	private String surnm;
	//birthday
	private String bthDd;
	//gender
	private String gdrCd;
	//gender code
	private String gdrCdNm;
	//father name
	private String fthrNm;
	//grandfather name
	private String gfthrNm;
	//current address code
	private String curtAdCd;
	//current address name
	private String curtAdCdNm;
	//current address detail
	private String curtAdDtlCt;	
	//new issuance criteria date
	private String newCrtDd;
	
	//permanent address
	private String pmntAd;	
	//permanent address name
	private String pmntAdNm;
	//permanent address detail
	private String pmntAdDtlCt;	
	
	//organization code + team code
	private String officerNo;		

	private String hBthDd;
	private String gBthDd;
	
	private String bioRgstYn;
	private String rsdtRgstYn;
	private String title;
	private String cntTelNo;
	private String bioRgstStus;
	private String bioCdNm;
	
	/**
	 * @return the fmlyBokNo
	 */
	public String getFmlyBokNo() {
		return fmlyBokNo;
	}

	/**
	 * @param fmlyBokNo the fmlyBokNo to set
	 */
	public void setFmlyBokNo(String fmlyBokNo) {
		this.fmlyBokNo = fmlyBokNo;
	}

	/**
	 * @return the fmlyMberNo
	 */
	public String getFmlyMberNo() {
		return fmlyMberNo;
	}

	/**
	 * @param fmlyMberNo the fmlyMberNo to set
	 */
	public void setFmlyMberNo(String fmlyMberNo) {
		this.fmlyMberNo = fmlyMberNo;
	}

	/**
	 * @return the fmlyBokNoDp
	 */
	public String getFmlyBokNoDp() {
		return fmlyBokNoDp;
	}

	/**
	 * @param fmlyBokNoDp the fmlyBokNoDp to set
	 */
	public void setFmlyBokNoDp(String fmlyBokNoDp) {
		this.fmlyBokNoDp = fmlyBokNoDp;
	}

	/**
	 * @return the rsdtNo
	 */
	public String getRsdtNo() {
		return rsdtNo;
	}

	/**
	 * @param rsdtNo the rsdtNo to set
	 */
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}

	/**
	 * @return the givNm
	 */
	public String getGivNm() {
		return givNm;
	}

	/**
	 * @param givNm the givNm to set
	 */
	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}

	/**
	 * @return the surnm
	 */
	public String getSurnm() {
		return surnm;
	}

	/**
	 * @param surnm the surnm to set
	 */
	public void setSurnm(String surnm) {
		this.surnm = surnm;
	}

	/**
	 * @return the bthDd
	 */
	public String getBthDd() {
		return bthDd;
	}

	/**
	 * @param bthDd the bthDd to set
	 */
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}

	/**
	 * @return the gdrCd
	 */
	public String getGdrCd() {
		return gdrCd;
	}

	/**
	 * @param gdrCd the gdrCd to set
	 */
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}

	/**
	 * @return the gdrCdNm
	 */
	public String getGdrCdNm() {
		return gdrCdNm;
	}

	/**
	 * @param gdrCdNm the gdrCdNm to set
	 */
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}



	public String getFthrNm() {
		return fthrNm;
	}

	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}

	public String getGfthrNm() {
		return gfthrNm;
	}

	public void setGfthrNm(String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}

	/**
	 * @return the curtAdCd
	 */
	public String getCurtAdCd() {
		return curtAdCd;
	}

	/**
	 * @param curtAdCd the curtAdCd to set
	 */
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}


	public String getNewCrtDd() {
		return newCrtDd;
	}

	public void setNewCrtDd(String newCrtDd) {
		this.newCrtDd = newCrtDd;
	}

	/**
	 * @return the officerNo
	 */
	public String getOfficerNo() {
		return officerNo;
	}

	/**
	 * @param officerNo the officerNo to set
	 */
	public void setOfficerNo(String officerNo) {
		this.officerNo = officerNo;
	}

	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}

	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}

	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}

	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}

	public String getPmntAd() {
		return pmntAd;
	}

	public void setPmntAd(String pmntAd) {
		this.pmntAd = pmntAd;
	}

	public String getPmntAdNm() {
		return pmntAdNm;
	}

	public void setPmntAdNm(String pmntAdNm) {
		this.pmntAdNm = pmntAdNm;
	}

	public String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}

	public void setPmntAdDtlCt(String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}

	public String gethBthDd() {
		return hBthDd;
	}

	public void sethBthDd(String hBthDd) {
		this.hBthDd = hBthDd;
	}

	public String getgBthDd() {
		return gBthDd;
	}

	public void setgBthDd(String gBthDd) {
		this.gBthDd = gBthDd;
	}



	public String getBioRgstYn() {
		return bioRgstYn;
	}

	public void setBioRgstYn(String bioRgstYn) {
		this.bioRgstYn = bioRgstYn;
	}

	public String getRsdtRgstYn() {
		return rsdtRgstYn;
	}

	public void setRsdtRgstYn(String rsdtRgstYn) {
		this.rsdtRgstYn = rsdtRgstYn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCntTelNo() {
		return cntTelNo;
	}

	public void setCntTelNo(String cntTelNo) {
		this.cntTelNo = cntTelNo;
	}

	public String getBioRgstStus() {
		return bioRgstStus;
	}

	public void setBioRgstStus(String bioRgstStus) {
		this.bioRgstStus = bioRgstStus;
	}

	public String getBioCdNm() {
		return bioCdNm;
	}

	public void setBioCdNm(String bioCdNm) {
		this.bioCdNm = bioCdNm;
	}

	

}
