package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.crd.service.CrdReisuceVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This class is Database Access Object of Card Lost/ Damage/ Renewal.
 * 
 * @author Afghanistan National ID Card System Application Team Daesung Kim
 * @since 2011.05.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2013.05.15    		Daesung Kim          			Create
 *
 * </pre>
 */
@Repository("crdReisuceDAO")
public class CrdReisuceDAO extends EgovAbstractDAO{
	
	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	
	/**
	 * DAO-method for retrieving  Resident Information. <br>
	 * 
	 * @param vo Input item for retrieving Resident Information.(CrdReisuceVO).
	 * @return CrdReisuceVO Retrieve Code information of Resident Information.
	 * @exception Exception
	 */
	public CrdReisuceVO selectRsdtInfr(CrdReisuceVO vo) throws Exception{
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return (CrdReisuceVO)selectByPk("crdReisuceDAO.selectRsdtInfr", vo);
	}
	
	/**
	 * DAO-method for retrieving code of Card Reissuance Reason. <br>
	 * 
	 * @param vo Input item for retrieving code of Card Reissuance Reason(CrdReisuceVO).
	 * @return List<CmCmmCdVO> Retrieve Code information of Card Reissuance Reason.
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<CmCmmCdVO> selectRsncd(CrdReisuceVO vo) throws Exception{
		return list("crdReisuceDAO.selectRsncd", vo);
	}
	
	/**
	 * DAO-method for retrieving card issuing status. <br>
	 * 
	 * @param vo Input item for retrieving card issuing status(CrdReisuceVO).
	 * @return CrdReisuceVO Retrieve Card issuing information
	 * @exception Exception
	 */
	public CrdReisuceVO selectCrdIsuStus(CrdReisuceVO vo) throws Exception{
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return (CrdReisuceVO)selectByPk("crdReisuceDAO.selectCrdIsuStus", vo);
	}
	
	/**
	 * DAO-method for retrieving card found status. <br>
	 * 
	 * @param vo Input item for retrieving card issuing status(CrdReisuceVO).
	 * @return CrdReisuceVO Retrieve Card issuing information
	 * @exception Exception
	 */
	public CrdReisuceVO selectCrdFondStus(CrdReisuceVO vo) throws Exception{
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return (CrdReisuceVO)selectByPk("crdReisuceDAO.selectCrdFondStus", vo);
	}
	
	/**
	 * DAO-method for delete and insert BioKey to IM_BIO_TB. <br>
	 * 
	 * @param nextBioKey Input item for delete and insert BioKey to IM_BIO_TB.(String).
	 * @return CrdReisuceVO Retrieve Card issuing information
	 * @exception Exception
	 */
	public void deleteAndInsertNewBioKeyToImBioTb(String nextBioKey) throws Exception{

		int resultBioTb = delete("crdReisuceDAO.deleteNewBioKeyToImBioTb", nextBioKey);
		log.debug("resultBioTb : " + resultBioTb);
		insert("crdReisuceDAO.insertNewBioKeyToImBioTb", nextBioKey);
		int resultCaptTb = delete("crdReisuceDAO.deleteNewBioKeyToImBioCaptTb", nextBioKey);
		log.debug("resultCaptTb : " + resultCaptTb);
	}
	
	/**
	 * DAO-method for retrieving card Reissuing status. <br>
	 * 
	 * @param vo Input item for retrieving card Reissuing status(CrdReisuceVO).
	 * @return CrdReisuceVO Retrieve Card Reissuing information
	 * @exception Exception
	 */
	public CrdReisuceVO selectCrdReisuceStus(CrdReisuceVO vo) throws Exception{
		return (CrdReisuceVO)selectByPk("crdReisuceDAO.selectCrdReisuceStus", vo);
	}
	
	/**
	 * DAO-method for registering information for card Reissuing. <br>
	 * 
	 * @param vo Input item for registering for card Reissuing(CrdReisuceVO).
	 * @return String
	 * @exception Exception
	 */
    public String insertCrdReisuceInfr(CrdReisuceVO vo) throws Exception{
    	String result = null;
    	synchronized(this){
    		result = (String)insert("crdReisuceDAO.insertCrdReisuceInfr", vo);
    	}
        return result;
    	
    	
    }
    
    /**
	 * DAO-method for modifying information of card Reissuing. <br>
	 * 
	 * @param vo Input item for modifying card Reissue Information(CrdReisuceVO).
	 * @exception Exception
	 */
    public int updateCrdReisuceInfr(CrdReisuceVO vo) throws Exception{
    	return update("crdReisuceDAO.updateCrdReisuceInfr", vo);
    }
    
    /**
	 * DAO-method for retrieving list Information of Reissuing Resident Information. <br>
	 * 
	 * @param vo Input item for retrieving list information of Reissuing Resident Information(CrdReisuceVO).
	 * @return PollStaVO Retrieve list information of Reissuing Resident Information
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<CrdReisuceVO> selectListCrdReisuceAprv(CrdReisuceVO vo) throws Exception{
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return list("crdReisuceDAO.selectListCrdReisuceAprv", vo);
	}
	
	/**
	 * DAO-method for retrieving total count of Reissuing Resident Information. <br>
	 * 
	 * @param vo Input item for retrieving total count of Reissuing Resident Information(CrdReisuceVO).
	 * @return int Total Count of Reissuing Resident Information List
	 * @exception Exception
	 */
    public int selectListCrdReisuceAprvTotCn(CrdReisuceVO vo) throws Exception{
        
    	vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
    	
    	return (Integer)selectByPk("crdReisuceDAO.selectListCrdReisuceAprvTotCn", vo);
    }
    
    /**
	 * DAO-method for retrieving  Reissuing Resident Information. <br>
	 * 
	 * @param vo Input item for retrieving Resident Information.(CrdReisuceVO).
	 * @return CrdReisuceVO Retrieve information of Reissuing Resident.
	 * @exception Exception
	 */
	public CrdReisuceVO selectCrdReisuceDtlAprv(CrdReisuceVO vo) throws Exception{
		return (CrdReisuceVO)selectByPk("crdReisuceDAO.selectCrdReisuceDtlAprv", vo);
	}
	
	
	/**
	 * DAO-method for verification  without Reissuing Resident Information. <br>
	 * 
	 * @param vo Input item for verification Resident Information.(CrdReisuceVO).
	 * @return CrdReisuceVO result of verification.
	 * @exception Exception
	 */
	public boolean updateAprvWithoutReisuce(CrdReisuceVO vo) throws Exception{
		
		boolean result = false; 
		int reisuceResult = update("crdReisuceDAO.updateAprvWithoutReisuce", vo);
		
		//Update CRD_STUS_CD on RM_RSDT_TB 
		int rsdtResult = update("crdReisuceDAO.updateRsdtInfrForWithoutCrdReisuce", vo);

		if(1 == reisuceResult  && 1 == rsdtResult){
			result = true;
		}
		
		return result ;
	}
	
	/**
	 * DAO-method for verification  Reissuing Resident Information. <br>
	 * 
	 * @param vo Input item for verification Resident Information.(CrdReisuceVO).
	 * @return CrdReisuceVO result of verification.
	 * @exception Exception
	 */
	public boolean mergeCrdReisuceAprv(CrdReisuceVO vo) throws Exception{
		
		boolean result = false;
		int aprvResult = update("crdReisuceDAO.updateReisuceInfr", vo);
		log.debug("updateReisuceInfr :" + aprvResult);
		int rsdtResult = update("crdReisuceDAO.updateRsdtInfr", vo);
		log.debug("updateRsdtInfr :" + rsdtResult);
		
		if(!"APVMSG".equals(vo.getErrCd())){
			insert("crdReisuceDAO.insertCardReisuceInfr", vo);
		}
		
		if(rsdtResult == 1 && aprvResult == 1){			
			result = true;		
		}
		log.debug("DAO Result :" + result);
		return result ;
	}
	
	/**
	 * DAO-method for Update Signature Data to RM_RSDT_TB. <br>
	 * 
	 * @param vo Input item for Update Signature Data.(CrdReisuceVO).
	 * @return CrdReisuceVO result of Updating Signature Data.
	 * @exception Exception
	 */
	public boolean updateSgntDat(CrdReisuceVO vo) throws Exception{
		
		boolean result = false; 
		int sgntResult = update("crdReisuceDAO.updateSgntDat", vo);
			
		if(sgntResult == 1){
			result = true;
		}
		
		return result ;
	}
	
	/**
	 * DAO-method for retrieving  Reissuing Resident status Information. <br>
	 * 
	 * @param vo Input item for retrieving Resident status Information.(CrdReisuceVO).
	 * @return CrdReisuceVO Retrieve information of Reissuing Resident status.
	 * @exception Exception
	 */
	public CrdReisuceVO selectRsdtStusInfr(CrdReisuceVO vo) throws Exception{
		return (CrdReisuceVO)selectByPk("crdReisuceDAO.selectRsdtStusInfr", vo);
	}
	
	
	
	/**
	 * DAO-method for Resident Information Lookup. <br>
	 * 
	 * @param vo Input item for retrieving Resident status Information.(CrdReisuceVO).
	 * @return CrdReisuceVO Retrieve information of Reissuing Resident status.
	 * @exception Exception
	 */
	public CrdReisuceVO selectCrdRsdtInfrView(CrdReisuceVO vo) throws Exception{
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		return (CrdReisuceVO)selectByPk("crdReisuceDAO.selectCrdRsdtInfrView", vo);
	}
	
	/**
	 * DAO-method for Resident Information Lookup. <br>
	 * 
	 * @param vo Input item for retrieving Resident status Information.(CrdReisuceVO).
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectCrdRsdtInfrFrgnView(CrdReisuceVO vo) throws Exception{
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		return list("crdReisuceDAO.selectCrdRsdtInfrFrgnView", vo);
	}
	
	/**
	 * DAO-method for Resident Information Lookup. <br>
	 * 
	 * @param vo Input item for retrieving Resident status Information.(CrdReisuceVO).
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectCrdRsdtInfrOthrNatView(CrdReisuceVO vo) throws Exception{
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		return list("crdReisuceDAO.selectCrdRsdtInfrOthrNatView", vo);
	}
	
	
	
	/**
	 * DAO-method for registering information for card Reissuing. <br>
	 * 
	 * @param vo Input item for registering for card Reissuing(CrdReisuceVO).
	 * @return 
	 * @exception Exception
	 */
    public String insertRsdtMdfctInfr(CrdReisuceVO vo) throws Exception{
    	String result = null;
    	synchronized(this){
    		result = (String)insert("crdReisuceDAO.insertRsdtMdfctInfo", vo);
    	}
        return result;
    	
    }
    
    /**
	 * DAO-method for registering information for card Reissuing. <br>
	 * 
	 * @param vo Input item for registering for card Reissuing(CrdReisuceVO).
	 * @return 
	 * @exception Exception
	 */
    public void insertRsdtMdfctNatLangBfTb(CrdReisuceVO vo) throws Exception{
    	insert("crdReisuceDAO.insertRsdtMdfctNatLangBfTb", vo);
    }
    
    /**
	 * DAO-method for registering information for card Reissuing. <br>
	 * 
	 * @param vo Input item for registering for card Reissuing(CrdReisuceVO).
	 * @return 
	 * @exception Exception
	 */
    public void insertRsdtMdfctNatLangAfTb(CrdReisuceVO vo) throws Exception{
    	insert("crdReisuceDAO.insertRsdtMdfctNatLangAfTb", vo);
    }
    
    /**
	 * DAO-method for registering information for card Reissuing. <br>
	 * 
	 * @param vo Input item for registering for card Reissuing(CrdReisuceVO).
	 * @return 
	 * @exception Exception
	 */
    public void insertRsdtMdfctFrgnLangBfTb(CrdReisuceVO vo) throws Exception{
    	insert("crdReisuceDAO.insertRsdtMdfctFrgnLangBfTb", vo);
    }
    
    /**
	 * DAO-method for registering information for card Reissuing. <br>
	 * 
	 * @param vo Input item for registering for card Reissuing(CrdReisuceVO).
	 * @return 
	 * @exception Exception
	 */
    public void insertRsdtMdfctFrgnLangAfTb(CrdReisuceVO vo) throws Exception{
    	insert("crdReisuceDAO.insertRsdtMdfctFrgnLangAfTb", vo);
    }
    
    /**
	 * DAO-method for registering information for card Reissuing. <br>
	 * 
	 * @param vo Input item for registering for card Reissuing(CrdReisuceVO).
	 * @return 
	 * @exception Exception
	 */
    public void deleteRsdtMdfctNatLangAfTb(CrdReisuceVO vo) throws Exception{
    	delete("crdReisuceDAO.deleteRsdtMdfctNatLangAfTb", vo);
    }
    
    /**
	 * DAO-method for registering information for card Reissuing. <br>
	 * 
	 * @param vo Input item for registering for card Reissuing(CrdReisuceVO).
	 * @return 
	 * @exception Exception
	 */
    public void deleteRsdtMdfctFrgnLangAfTb(CrdReisuceVO vo) throws Exception{
    	delete("crdReisuceDAO.deleteRsdtMdfctFrgnLangAfTb", vo);
    }
    
    
    
    
    /**
	 * DAO-method for Resident Information Lookup. <br>
	 * 
	 * @param vo Input item for retrieving Resident status Information.(CrdReisuceVO).
	 * @return CrdReisuceVO Retrieve information of Reissuing Resident status.
	 * @exception Exception
	 */
	public CrdReisuceVO selectCrdRsdtInfrMdfcView(CrdReisuceVO crdReisuceVO) throws Exception{
		CrdReisuceVO vo = (CrdReisuceVO)selectByPk("crdReisuceDAO.selectCrdRsdtInfrMdfcView", crdReisuceVO);
		if(vo != null && vo.getRsdtSeqNo()!= null && vo.getMdfctSeqNo() != null){
			CrdReisuceVO vo2 = (CrdReisuceVO)selectByPk("crdReisuceDAO.selectOthrNatAndFrgnLangCn", vo);
			vo.setOthrCount(vo2.getOthrCount());
			vo.setFrgnCount(vo2.getFrgnCount());
		}	
		return vo;
	}
	
	/**
	 * DAO-method for Resident Information Lookup. <br>
	 * 
	 * @param vo Input item for retrieving Resident status Information.(CrdReisuceVO).
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectCrdRsdtInfrFrgnBfView(CrdReisuceVO vo) throws Exception{
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		return list("crdReisuceDAO.selectCrdRsdtInfrFrgnBfView", vo);
	}
	
	/**
	 * DAO-method for Resident Information Lookup. <br>
	 * 
	 * @param vo Input item for retrieving Resident status Information.(CrdReisuceVO).
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectCrdRsdtInfrFrgnAfView(CrdReisuceVO vo) throws Exception{
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		return list("crdReisuceDAO.selectCrdRsdtInfrFrgnAfView", vo);
	}
	
	/**
	 * DAO-method for Resident Information Lookup. <br>
	 * 
	 * @param vo Input item for retrieving Resident status Information.(CrdReisuceVO).
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectCrdRsdtInfrOthrNatBfView(CrdReisuceVO vo) throws Exception{
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		return list("crdReisuceDAO.selectCrdRsdtInfrOthrNatBfView", vo);
	}
	
	/**
	 * DAO-method for Resident Information Lookup. <br>
	 * 
	 * @param vo Input item for retrieving Resident status Information.(CrdReisuceVO).
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectCrdRsdtInfrOthrNatAfView(CrdReisuceVO vo) throws Exception{
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		return list("crdReisuceDAO.selectCrdRsdtInfrOthrNatAfView", vo);
	}
	
	
	/**
	 * DAO-method for modifying information of card Reissuing. <br>
	 * 
	 * @param vo Input item for modifying card Reissue Information(CrdReisuceVO).
	 * @exception Exception
	 */
    public int updateRsdtMdfctInfr(CrdReisuceVO vo) throws Exception{
    	return update("crdReisuceDAO.updateRsdtMdfctInfo", vo);
    }
	
    /**
	 * DAO-method for retrieving total count of Reissuing Resident Information. <br>
	 * 
	 * @param vo Input item for retrieving total count of Reissuing Resident Information(CrdReisuceVO).
	 * @return int 
	 * @exception Exception
	 */
    public int selectCrdRsdtInfrEnNmChng(CrdReisuceVO vo) throws Exception{
    	return (Integer)selectByPk("crdReisuceDAO.selectCrdRsdtInfrEnNmChng", vo);
    }
    
    /**
	 * DAO-method for modifying information of card Reissuing. <br>
	 * 
	 * @param vo Input item for modifying card Reissue Information(CrdReisuceVO).
	 * @exception Exception
	 */
    public int updateRsdtMdfcToRsdtInfo(CrdReisuceVO vo) throws Exception{
    	return update("crdReisuceDAO.updateRsdtMdfcToRsdtInfo", vo);
    }
    
    /**
	 * DAO-method for modifying information of card Reissuing. <br>
	 * 
	 * @param vo Input item for modifying card Reissue Information(CrdReisuceVO).
	 * @exception Exception
	 */
    public int deleteOthrNatLang(CrdReisuceVO vo) throws Exception{
    	return delete("crdReisuceDAO.deleteOthrNatLang", vo);
    }
    
    /**
	 * DAO-method for modifying information of card Reissuing. <br>
	 * 
	 * @param vo Input item for modifying card Reissue Information(CrdReisuceVO).
	 * @exception Exception
	 */
    public int deleteFrgnLang(CrdReisuceVO vo) throws Exception{
    	return delete("crdReisuceDAO.deleteFrgnLang", vo);
    }
    
    /**
	 * DAO-method for modifying information of card Reissuing. <br>
	 * 
	 * @param vo Input item for modifying card Reissue Information(CrdReisuceVO).
	 * @exception Exception
	 */
    public void insertOthrNatLangTb(CrdReisuceVO vo) throws Exception{
    	insert("crdReisuceDAO.insertOthrNatLangTb", vo);
    }
    
    /**
	 * DAO-method for modifying information of card Reissuing. <br>
	 * 
	 * @param vo Input item for modifying card Reissue Information(CrdReisuceVO).
	 * @exception Exception
	 */
    public void insertFrgnLangTb(CrdReisuceVO vo) throws Exception{
    	insert("crdReisuceDAO.insertFrgnLangTb", vo);
    }
    
    /**
	 * DAO-method for modifying information of card Reissuing. <br>
	 * 
	 * @param vo Input item for modifying card Reissue Information(CrdReisuceVO).
	 * @exception Exception
	 */
    public int updateCrdReRsdtMdfctTbApp(CrdReisuceVO vo) throws Exception{
    	return update("crdReisuceDAO.updateCrdReRsdtMdfctTbApp", vo);
    }
	
    /**
	 * DAO-method for  retrieving Receipt of Citizen Confirmation. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(CrdReisuceVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
    public EgovMap selectCrdReisuceCfmRcpt(CrdReisuceVO vo) {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());    	
        return (EgovMap)selectByPk("crdReisuceDAO.selectCrdReisuceCfmReceipt", vo);
    }
    
    /**
	 * DAO-method for  retrieving Receipt of Citizen Confirmation. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(CrdReisuceVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectCrdReisuceOthrCfmRcpt(CrdReisuceVO vo) throws Exception{
		return list("crdReisuceDAO.selectCrdReisuceOthrCfmReceipt", vo);
	}
	
	/**
	 * DAO-method for  retrieving Receipt of Citizen Confirmation. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(CrdReisuceVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")	
    public List<EgovMap> selectCrdReisuceFrgnCfmRcpt(CrdReisuceVO vo) {
    	return list("crdReisuceDAO.selectCrdReisuceFrgnCfmReceipt", vo);
    }
	
	/**
	 * DAO-method for  retrieving Receipt of Citizen. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(CrdReisuceVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
    public EgovMap selectCrdReisuceRcpt(CrdReisuceVO vo) {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());    	
        return (EgovMap)selectByPk("crdReisuceDAO.selectCrdReisuceReceipt", vo);
    }
    
    /**
	 * DAO-method for  retrieving Receipt of Citizen. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(CrdReisuceVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectCrdReisuceOthrRcpt(CrdReisuceVO vo) throws Exception{
		return list("crdReisuceDAO.selectCrdReisuceOthrReceipt", vo);
	}
	
	/**
	 * DAO-method for  retrieving Receipt of Citizen. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(CrdReisuceVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")	
    public List<EgovMap> selectCrdReisuceFrgnRcpt(CrdReisuceVO vo) {
    	return list("crdReisuceDAO.selectCrdReisuceFrgnReceipt", vo);
    }
}
