package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.crd.service.CrdFndSndService;
import afnid.rm.crd.service.CrdFndSndVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;

/** 
 * This service class is biz-class of Found Card Send
 * and implements CrdFndRcivService class.
 * 
 * @author Afghanistan National ID Card System Application Team Daesung Kim
 * @since 2013.11.18
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           		Revisions
 *   2013.11.18  		Daesung Kim         		Create
 *
 * </pre>
 */

@Service("crdFndSndService")
public class CrdFndSndServiceImpl extends AbstractServiceImpl implements CrdFndSndService {

	/** crdFndDAO */
    @Resource(name="crdFndSndDAO")
    private CrdFndSndDAO dao;
   
    /**
   	 * Biz-method for retrieving information of found card sending. <br>
   	 *
   	 * @param vo Input item for retrieving information of found card sending(CrdFndSndVO).
   	 * @return CrdFndSndVO Retrieve resident information for card found registration
   	 * @exception Exception
   	 */
   	public CrdFndSndVO searchCrdFndSndInfr(CrdFndSndVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
		
		CrdFndSndVO crdFondInfr = null;
		
		List<CrdFndSndVO> crdFondList= dao.selectCrdFndSndInfr(vo);
		
		if(1 == crdFondList.size() ){
			crdFondInfr = crdFondList.get(0);
		}else if(1 < crdFondList.size()){
			crdFondInfr = new CrdFndSndVO();
			crdFondInfr.setCallPopupYn("Y");
			crdFondInfr.setRsdtNo(vo.getSearchKeyword());
		}
		
   		return crdFondInfr;
   	}
   	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CrdFndSndVO).
   	 * @return List<CrdFndSndVO> Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<CrdFndSndVO> searchListCrdFndSndInfr(CrdFndSndVO vo) throws Exception {
      	
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		vo.setOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
		
		List<CrdFndSndVO> crdFondList = dao.selectListCrdFndSndInfr(vo);
		
   		return crdFondList;
   	}
   	
   	/**
	 * Biz-method for registering information of card found Sending. <br>
	 * 
	 * @param vo Input item for registering information of program(CrdFndSndVO).
	 * @return 
	 * @exception Exception
	 */
	public void addCrdFndSndInfr(CrdFndSndVO vo) throws Exception {  
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		
		vo.setSndOrgnzCd(vo.getRgstOrgnzCd());
		vo.setSndRgstUserId(user.getUserId());
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
		
		boolean result = dao.mergeCrdFndSndInfr(vo);
		
		if(!result){
			throw processException( "udtFail.msg");
		} 
	}
	
	/**
	 * Biz-method for updating information of Card Disuse. <br>
	 * 
	 * @param vo Input item for updating information of Card Disuse.(CrdFndSndVO).
	 * @return 
	 * @exception Exception
	 */
	public void modifyCrdDisuseOnFndSnd(CrdFndSndVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());// Setting User ID
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code	
		
		boolean result = dao.updateCrdDsuseInfr(vo);
		
		if(!result){
			throw processException( "udtFail.msg");
		}
	}
	
	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(CrdFndSndVO).
   	 * @return List<CrdFndSndVO> Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<CrdFndSndVO> searchListCrdFndSndAprv(CrdFndSndVO vo) throws Exception {
      		return dao.selectListCrdFndSndAprv(vo);
   	}
   	
    /**
	 * Biz-method for retrieving total count of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdFndSndVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
   	public int searchListCrdFndSndAprvTotCn(CrdFndSndVO vo) throws Exception {
        return dao.selectListCrdFndSndAprvTotCn(vo);
	}

   	/**
   	 * Biz-method for retrieving detail information for card found sending. <br>
   	 *
   	 * @param vo Input item for retrieving detail information of card found sending(CrdFndSndVO).
   	 * @return CrdFndSndVO Retrieve detail information for card found sending
   	 * @exception Exception
   	 */
   	public CrdFndSndVO searchCrdFndSndDtlAprv(CrdFndSndVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());	
		vo.setSndOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());		
   		
   		return dao.selectCrdFndSndDtlAprv(vo);
   	}
   	/**
	 * Biz-method for update information of program. <br>
	 * 
	 * @param vo Input item for update information of program(CrdFndSndVO).
	 * @return 
	 * @exception Exception
	 */
	public void modifyCrdFndSndAprvInfr(CrdFndSndVO vo) throws Exception {   	
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
		
		boolean result = dao.updateCrdFndSndAprvInfr(vo);
		
		if(!result){
			throw processException( "udtFail.msg");
		} 
	}  
	  /**
	 * Biz-method for approval information of program. <br>
	 * 
	 * @param vo Input item for approval information of program(CrdFndSndVO).
	 * @return 
	 * @exception Exception
	 */
	public void approveCrdFndSndInfr(CrdFndSndVO vo) throws Exception {   
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();	
		vo.setLstUdtUserId(user.getUserId());
		vo.setSndCfmTamLedrId(user.getUserId());
		boolean result = dao.updateCrdFndSndAprv( vo );
		
		if(!result){
			throw processException( "udtFail.msg");
		} 
	} 
	
	/**
	 * Biz-method for retrieving list of organization. <br>
	 * 
	 * @param vo Input item for retrieving list of organization(OrgInfoVO).
	 * @return List Retrieve list of organization
	 * @exception Exception
	 */
	public List<CrdFndSndVO> searchListOrgnzInfr(CrdFndSndVO vo) throws Exception {
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setOrgnzClsCd(user.getOrgnzClsCd());
		
		List<CrdFndSndVO> orgnzList = dao.selectListOrgnzInfr(vo);
		
		return orgnzList;
	}
}
