package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;


import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.pkiif.ccm.CardKillRequestInput;
import afnid.pkiif.ccm.CardKillRequestOutput;
import afnid.pkiif.ccm.CardKillResultInput;
import afnid.pkiif.ccm.CardKillResultOutput;
import afnid.pkiif.ccm.RMCCM;
import afnid.pkiif.ccm.RMCCM_Service;
import afnid.rm.crd.service.CrdDsuseService;
import afnid.rm.crd.service.CrdDsuseVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;

/** 
 * This service class is biz-class of Card Disuse Processing.
 * and implements CrdDsuseService class.
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2013.12.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           		Revisions
 *   2013.12.17  		MS Kim        	        	Create
 *
 * </pre>
 */

@Service("crdDsuseService")
public class CrdDsuseServiceImpl extends AbstractServiceImpl implements CrdDsuseService{
	
	/** CrdFndDitbDAO */
    @Resource(name="crdDsuseDAO")
    private CrdDsuseDAO dao;

    /** LgDAO */
    @Resource(name="lgDAO")
    private LgDAO lgDao;
    
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;

    
    /**
   	 * Biz-method for retrieving list of card disuse. <br>
   	 *
   	 * @param vo Input item for retrieving list of card disuse.
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public List<CrdDsuseVO>  searchListCrdDsuse(CrdDsuseVO vo) throws Exception {
      	
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
		if( 1 < vo.getSearchKeyword2().length()){
			vo.setSearchKeyword2("");
		}
		return dao.selectListCrdDsuse(vo);

   	}
   	

   	
    /**
   	 * Biz-method for retrieving total count list of card disuse. <br>
   	 *
   	 * @param vo Input item for retrieving list of card disuse.
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public int searchListCrdDsuseTotCnt(CrdDsuseVO vo) throws Exception {
      	
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
		return dao.selectListCrdDsuseTotCnt(vo);

   	}   
   	

   	
	/**
	 * Biz-method for card disuse request processing <br>
	 * 
	 * @param vo Input item for card disuse request processing(CrdDsuseVO).
	 * @return 
	 * @exception Exception
	 */
	public String modifyCrdDsuseRqst(CrdDsuseVO vo) throws Exception {

		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		
		vo.setCrdDsuseUserId(user.getUserId());
		
		int result = 0;
		String reportNo = "";
		vo.setCrdDsuseStusCd("7");
        if ("1".equals(vo.getTblGbn())){
        	result = dao.updateFondCrdDsuseRqst(vo);
        	reportNo = "121"+vo.getSeqNo();
        } else if ("2".equals(vo.getTblGbn())){
        	result = dao.updateDitbCrdDsuseRqst(vo);
        	reportNo = "122"+vo.getSeqNo();
        } else if ("3".equals(vo.getTblGbn())){
        	result = dao.updateDsuseRqst(vo);
        	reportNo = "123"+vo.getSeqNo();
        }
							
        if(result != 1){	
			throw processException( "udtFail.msg");	
        }
        
      //setting CMS web Service parameter value
		String rsdtNo  = vo.getRsdtNo();

		CrdDsuseVO crdInfr = dao.selectCrdIsuceInfr(rsdtNo);
		String hCrdIsuceDd= crdInfr.gethCrdIsuceDd();
		int crdIsuceSrlNo = Integer.parseInt(crdInfr.getCrdIsuceSrlNo());
		
		CardKillRequestInput data = new CardKillRequestInput();
		data.setRequestType(2);
		data.setCardIssuanceDate(hCrdIsuceDd);
		data.setENID(rsdtNo);
		data.setReportNumber(reportNo);
		data.setLastIssuanceSequenceNo(crdIsuceSrlNo);
		data.setPrintedIssuanceSequenceNo(Integer.parseInt(vo.getCrdIsuceSrlNo()));
		log.debug("rqstTye :2");
		log.debug("reportNo :" + reportNo);
		log.debug("rsdtNo :" + rsdtNo);
		log.debug("hCrdIsuceDd :" + hCrdIsuceDd);
		log.debug("LastIssuanceSequenceNo :" + crdIsuceSrlNo);
		log.debug("PrintedIssuanceSequenceNo :" + Integer.parseInt(vo.getCrdIsuceSrlNo()));
		
	    //Insert PKI log
		String rqstDat  = data.getRequestType()            + ":"
	                    + data.getCardIssuanceDate()       + ":"
				        + data.getENID()                   + ":"
	                    + data.getReportNumber()           + ":"
	                    + data.getLastIssuanceSequenceNo() + ":"
				        + data.getPrintedIssuanceSequenceNo();
		
	    String lgSeqNo=lgDao.insertPubKeyIfLg(user.getUserId(), rsdtNo, "23", "1", "12", rqstDat);		

		return lgSeqNo;
	}
	
	
	
	/**
	 * Biz-method for registering information of new user(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for registering new user(CrdDsuseVO).
	 * @return CrdDsuseVO Primary Key value of registered user
	 * @exception Exception
	 */
	public String modifyCrdDsuseRqstPkiIf(CrdDsuseVO vo) throws Exception {
		
		String status = "";
		String erorYn ="Y";

		String reportNo = "";
		vo.setCrdDsuseStusCd("7");
        if ("1".equals(vo.getTblGbn())){
        	reportNo = "121"+vo.getSeqNo();
        } else if ("2".equals(vo.getTblGbn())){
        	reportNo = "122"+vo.getSeqNo();
        } else if ("3".equals(vo.getTblGbn())){
        	reportNo = "123"+vo.getSeqNo();
        }
        
        
		//setting CMS web Service parameter value
		String rsdtNo  = vo.getRsdtNo();

		CrdDsuseVO crdInfr = dao.selectCrdIsuceInfr(rsdtNo);
		String hCrdIsuceDd= crdInfr.gethCrdIsuceDd();
		int crdIsuceSrlNo = Integer.parseInt(crdInfr.getCrdIsuceSrlNo());
			
		CardKillRequestInput data = new CardKillRequestInput();
		data.setRequestType(2);
		data.setCardIssuanceDate(hCrdIsuceDd);
		data.setENID(rsdtNo);
		data.setReportNumber(reportNo);
		data.setLastIssuanceSequenceNo(crdIsuceSrlNo);
		data.setPrintedIssuanceSequenceNo(Integer.parseInt(vo.getCrdIsuceSrlNo()));
		log.debug("rqstTye :2");
		log.debug("reportNo :" + reportNo);
		log.debug("rsdtNo :" + rsdtNo);
		log.debug("hCrdIsuceDd :" + hCrdIsuceDd);
		log.debug("LastIssuanceSequenceNo :" + crdIsuceSrlNo);
		log.debug("PrintedIssuanceSequenceNo :" + Integer.parseInt(vo.getCrdIsuceSrlNo()));
		
		//Citizen Account Revocation 
		RMCCM_Service rmCcmWs= new RMCCM_Service();
		RMCCM rmCcm = rmCcmWs.getRMCCMPort();	
			
		CardKillRequestOutput ckro = rmCcm.cardKillRequest(data);
		
		int cmsResult = ckro.getResult(); // 1: OK 2:ERROR 
		
		status = String.valueOf(cmsResult);
		log.debug("status ====> " + status);
		
		if("1".equals(status)){//OK
			erorYn ="N";
		} else {
			if(ckro.getFailCode()!= null && "".equals(ckro.getFailCode())){
				status = ckro.getFailCode();
			} else {
				status ="None";
			}
			
		}
		
		lgDao.updatePubKeyIfLg(vo.getLgSeqNo(), status, erorYn);			
				
    	return status;
    	
	}
	
	
	/**
	 * Biz-method for card disuse result Check processing <br>
	 * 
	 * @param vo Input item for card disuse result Check processing(CrdDsuseVO).
	 * @return 
	 * @exception Exception
	 */
	public int modifyCrdDsuseRsutChk(CrdDsuseVO vo) throws Exception {

		String erorYn ="N";

		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		
		vo.setCrdDsuseUserId(user.getUserId());

		String rsdtNo  = vo.getRsdtNo();
		String reportNo = "";
		if("1".equals(vo.getTblGbn())){
			reportNo = "121"+vo.getSeqNo();
		}else if("2".equals(vo.getTblGbn())){
			reportNo = "122"+vo.getSeqNo();
		}else if("3".equals(vo.getTblGbn())){
			reportNo = "123"+vo.getSeqNo();
		}

		CardKillResultInput data = new CardKillResultInput();
		data.setENID(rsdtNo);
		data.setReportNumber(reportNo);
		log.debug("input reportNo :" + reportNo);
		log.debug("input rsdtNo :" + rsdtNo);
		
		String rqstDat =data.getENID() + ":" + data.getReportNumber();
		String lgSeqNo = lgDao.insertPubKeyIfLg(user.getUserId(), rsdtNo, "24", "1", "12", rqstDat);
		
		// Call CMS Web Service
		RMCCM_Service rmCcmWs= new RMCCM_Service();
		RMCCM rmCcm = rmCcmWs.getRMCCMPort();
		
		//call method
		CardKillResultOutput ckro = rmCcm.cardKillResult(data);
		
		if(ckro == null){
			String helpTelNo = nidMessageSource.getMessage("admTelNo");	
			throw processException( "pki.websrvcEror.msg", new String[]{"none", helpTelNo});
		}
		
		int cmsResult = ckro.getResult(); 
		//cmsResult : 1=Request Received, 2=Completed with kill, 3=Completed without kill, 4=Error
		
		if(cmsResult == 4 || cmsResult == 3){
			erorYn = "Y";
		} else if(cmsResult == 2){
			
			vo.setCrdDsuseStusCd("6");
	        if ("1".equals(vo.getTblGbn())){
	        	
	        	int result = dao.updateFondCrdDsuseRsutChk(vo);
	        	if(result != 1){	
	        		processException( "udtFail.msg");	
	            }
	        	
	        } else if ("2".equals(vo.getTblGbn())){
	        	
	        	boolean result = dao.updateDitbCrdDsuseRsutChk(vo);
	        	if(result){	
	        		processException( "udtFail.msg");	
	            }
	        } else if ("3".equals(vo.getTblGbn())){
	        	int result = dao.updateDsuseRsut(vo);
	        	if(result != 1){	
	        		processException( "udtFail.msg");	
	            }	        	
	        }
	
		} else if(cmsResult != 1 ){
			String helpTelNo = nidMessageSource.getMessage("admTelNo");	
			throw processException( "pki.websrvcEror.msg", new String[]{"none", helpTelNo});
		}
		
		lgDao.updatePubKeyIfLg(lgSeqNo, String.valueOf(cmsResult), erorYn);
		
				
		return cmsResult;
	}
	

}	
