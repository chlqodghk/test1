package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.pkiif.cpki.CpkiRmWS;
import afnid.pkiif.cpki.CpkiRmWSService;
import afnid.pkiif.cpki.PkiRsWsResponse;
import afnid.rm.bioif.service.BioIfInfrService;
import afnid.rm.crd.service.CrdFndService;
import afnid.rm.crd.service.CrdReisuceService;
import afnid.rm.crd.service.CrdReisuceVO;
import afnid.rm.rsdt.service.RsdtInfrService;
import afnid.rm.rsdt.service.impl.RsdtInfrDAO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of Card Lost/ Damage/ Renewal
 * and implements CrdReisuceService class.
 * 
 * @author Afghanistan National ID Card System Application Team  Daesung Kim
 * @since 2013.06.14
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2013.05.15    		Daesung Kim          			Create
 *
 * </pre>
 */
@Service("crdReisuceService")
public class CrdReisuceServiceImpl extends AbstractServiceImpl implements CrdReisuceService{
	
	@Resource(name="crdReisuceDAO")
    private CrdReisuceDAO crdReisuceDAO;
	
	@Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtDao;
    
	@Resource(name="lgDAO")
    private LgDAO lgDao;
	
	/** crdFndService */
	@Resource(name = "crdFndService")
    private CrdFndService crdFndService;
	
	@Resource(name="bioIfInfrService")
    private BioIfInfrService bioIfService;
	
	/** rsdtInfoService service */
    @Resource(name="rsdtInfoService")
    private RsdtInfrService rsdtInfoService;
  
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
    /**
	 * Biz-method for retrieving Resident Information. <br>
	 * 
	 * @param vo Input item for retrieving Resident Information.(CrdReisuceVO).
	 * @return CrdReisuceVO Retrieve Resident Information.
	 * @exception Exception
	 */
	public CrdReisuceVO searchCrdReisuceInfr(CrdReisuceVO crdReisuceVO) throws Exception {
		CrdReisuceVO vo = crdReisuceVO;
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		if("E".equals(vo.getPageFlag())){
			vo.setRsnCd("");
		}
		CrdReisuceVO rsdtInfo = crdReisuceDAO.selectRsdtInfr(vo);
		//Check that Resident NID Number does not exist 
		if(rsdtInfo == null){
			vo.setErrCd("ERR01"); 	
			return vo;
		}
		
		rsdtInfo.setUseLangCd(user.getUseLangCd());
		rsdtInfo.setUserId(user.getUserId());
		
		//Check that Resident NID Number is disabled
		if(!"1".equals(rsdtInfo.getRsdtStusCd()) && "N".equals(vo.getPageFlag()) ){
			vo.setErrCd("ERR02");	
			return vo;
		}
		
		//check for Citizen Revocation Apply Status
		String rvctgStus = rsdtInfoService.searchRsdtRvctgStus(rsdtInfo.getRsdtNo(), "msg");
		log.debug("========rvctgStus : "+rvctgStus);
		if(!"".equals(rvctgStus) && "N".equals(vo.getPageFlag())){
			vo.setErrCd("ERR05");
			return vo;
		}
		
		//Check the card that expired  
		if("3".equals(vo.getRsnCd()) && "N".equals(rsdtInfo.getIsExp()) ){
			vo.setExpMd(rsdtInfo.getExpMd());
			vo.setErrCd("ERR08");	
			return vo;
		}else if("2".equals(vo.getRsnCd()) && "Y".equals(rsdtInfo.getIsExp()) ){
			vo.setErrCd("ERR10");	
			return vo;
		}else if("6".equals(vo.getRsnCd()) && "Y".equals(rsdtInfo.getIsExp()) ){
			vo.setErrCd("ERR10");	
			return vo;
		}
		
		CrdReisuceVO imCrdTb = crdReisuceDAO.selectCrdIsuStus(vo);	
		//Resident NID Number have no history of issuing
		if(imCrdTb == null){
			vo.setErrCd("ERR03");	
			return vo;
		}
		
		//Check that Resident NID Number Card is being issued
		if(imCrdTb.getCrdDitbCd() == null){
			vo.setErrCd("ERR04");	
			return vo;
		}
		
		vo.setRsdtSeqNo(rsdtInfo.getRsdtSeqNo());
		CrdReisuceVO rmCrdReisuce = crdReisuceDAO.selectCrdReisuceStus(vo);
		
		//Resident NID Number is already applied for reissuing by another office
		String userOrCd = user.getOrgnzClsCd()+user.getOrgnzCd();
		if(rmCrdReisuce!= null && !rmCrdReisuce.getRgstOrgnzCd().startsWith(userOrCd) ){
			vo.setRgstOrgnzCdNm(rmCrdReisuce.getRgstOrgnzCdNm());
			vo.setErrCd("ERR06");
			return vo;
		}
		// If mode is edit mode
		if("E".equals(vo.getPageFlag())){
			//No data is searched
			if(rmCrdReisuce == null ){
				vo.setErrCd("ERR07");	
				return vo;
			}
			
			rsdtInfo.setPageFlag("E");
			rsdtInfo.setCrdReisuSeqNo(rmCrdReisuce.getCrdReisuSeqNo());
			rsdtInfo.setOcrncDd(rmCrdReisuce.getOcrncDd());
			rsdtInfo.setRsnDtlCt(rmCrdReisuce.getRsnDtlCt());
			rsdtInfo.setRgstOrgnzCd(rmCrdReisuce.getRgstOrgnzCd());
			rsdtInfo.setRsnCd(rmCrdReisuce.getRsnCd());
			rsdtInfo.setBioChngYn(rmCrdReisuce.getBioChngYn());
			rsdtInfo.setCrdIsuceYn(rmCrdReisuce.getCrdIsuceYn());
			rsdtInfo.setRsdtInfrChngYn(rmCrdReisuce.getRsdtInfrChngYn());
			rsdtInfo.setAppDd(rmCrdReisuce.getAppDd());
			rsdtInfo.setCrdReisuceDueDd(rmCrdReisuce.getCrdReisuceDueDd());
			rsdtInfo.setCrdReisuceDd(rmCrdReisuce.getCrdReisuceDd());
			rsdtInfo.setAfCrdExpiryDd(rmCrdReisuce.getAfCrdExpiryDd());
			rsdtInfo.setCntTelNo(rmCrdReisuce.getCntTelNo());
			rsdtInfo.setCntTelNo2(rmCrdReisuce.getCntTelNo2());
			rsdtInfo.setEmlAd(rmCrdReisuce.getEmlAd());
			rsdtInfo.setFgpCd(rmCrdReisuce.getFgpCd());
			rsdtInfo.setIrisCd(rmCrdReisuce.getIrisCd());
			rsdtInfo.setSgntCd(rmCrdReisuce.getSgntCd());
			rsdtInfo.setPtCd(rmCrdReisuce.getPtCd());
			rsdtInfo.setOthrRsnCd(rmCrdReisuce.getOthrRsnCd());

		}else{
			//Resident NID Number is already applied for reissuing Please search on edit mode
			if(rmCrdReisuce != null ){
				vo.setErrCd("ERR09");	
				return vo;
			}
			
			rsdtInfo.setPageFlag("N");
			rsdtInfo.setRsnCd(vo.getRsnCd());
		}
		
		// If mode is not edit mode
		if(!"E".equals(vo.getPageFlag())){
			
			// Check card Issue application status
			String cardStatus = rsdtInfoService.searchRsdtCrdIsuAppStus(rsdtInfo.getRsdtNo(), "msg", "");
			if(!"".equals(cardStatus)){
				vo.setErrCd("ERR11");
				vo.setErrMsg(cardStatus);
				return vo;
			}
			
			// If reason is Lost
			if("1".equals(vo.getRsnCd()) && "N".equals(rsdtInfo.getIsExp()) ){
				
				//Check that Resident NID Number Card is registered on found card
				CrdReisuceVO rmCrdFond = crdReisuceDAO.selectCrdFondStus(vo);
				
				if(rmCrdFond != null){
					String msg = "";
					String foundCrdFlag = "";
					if("1".equals(rmCrdFond.getCrdPrcssStusCd())){
						if(rmCrdFond.getRgstOrgnzCd().startsWith(userOrCd) ){
							msg = nidMessageSource.getMessage("fondCrdInThisOfic.msg",new String[]{rmCrdFond.getRgstOrgnzCdNm()});
							foundCrdFlag = "1";
						}else{
							msg = nidMessageSource.getMessage("fondCrdInOthrOfic.msg",new String[]{rmCrdFond.getRgstOrgnzCdNm()});
							foundCrdFlag = "2";
							rsdtInfo.setFondCrdSeqNo(rmCrdFond.getFondCrdSeqNo());
						}
					}else if("2".equals(rmCrdFond.getCrdPrcssStusCd())){
						if("N".equals(rmCrdFond.getSndTamLedrCfmYn())){
							msg = nidMessageSource.getMessage("fondCrdInOthrOfic.msg",new String[]{rmCrdFond.getRgstOrgnzCdNm()});
							foundCrdFlag = "2";
							rsdtInfo.setFondCrdSeqNo(rmCrdFond.getFondCrdSeqNo());
						}else{
							msg = nidMessageSource.getMessage("fondCrdOnMv.msg",new String[]{rmCrdFond.getSndOrgnzCdNm(),rmCrdFond.getRcivOrgnzCdNm()});
							foundCrdFlag = "3";
						}
					}

					rsdtInfo.setFoundCrdFlag(foundCrdFlag);
					rsdtInfo.setErrMsg(msg);
				}
			}
		}
		
		
		String bioInfr = null;
		log.debug("==================vo.getRsnCd()================"+vo.getRsnCd());
		log.debug("==================vo.getPageFlag()================"+vo.getPageFlag());
		
		if("3".equals(vo.getRsnCd()) && "N".equals(vo.getPageFlag()) ){
			
			crdReisuceDAO.deleteAndInsertNewBioKeyToImBioTb(rsdtInfo.getNextBioKey());
			
			//get Bio Information
			log.debug("==================call bio================");
			log.debug("==================check for bio info exist ================");
			EgovMap ImCapt = rsdtDao.selectImBioCaptTbInfr(rsdtInfo.getNextBioKey());
			if(ImCapt == null || ImCapt.isEmpty() || rmCrdReisuce == null){
				int cnt = rsdtDao.selectBmBioTb(rsdtInfo.getBioKey(), rsdtInfo.getRsdtNo());
				if(cnt > 0){
					bioInfr = bioIfService.searchBioSocketIf(rsdtInfo.getBioKey(), rsdtInfo.getRsdtNo(),"Y", user.getUserId(),null);
					rsdtInfo.setBioInfr(bioInfr);	
				}	
			}
		}
			
		vo=rsdtInfo;
			
		return vo;
	}
	
	/**
	 * Biz-method for retrieving Reason Code Information. <br>
	 * 
	 * @param vo Input item for retrieving reason code list.(CrdReisuceVO).
	 * @return List<CmCmmCdVO> Retrieve reason code Information.
	 * @exception Exception
	 */
	public List<CmCmmCdVO> searchRsnCd(CrdReisuceVO vo) throws Exception {
		
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		
		return crdReisuceDAO.selectRsncd(vo);
	}
	
	/**
	 * Biz-method for registering information for card Reissuing. <br>
	 * 
	 * @param vo Input item for registering Card Reissuing Information(CrdReisuceVO).
	 * @exception Exception
	 */
	public void addCrdReisuceInfr(CrdReisuceVO vo) throws Exception {
		//vo setting for registering
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());
		log.debug("lost Date :"+vo.getOcrncDd());
		log.debug("planned issue date:"+vo.getCrdReisuceDueDd());
		log.debug("issue date  :"+vo.getCrdReisuceDd());
		log.debug("expiry date :"+vo.getAfCrdExpiryDd());
		//Lost Date setting for Card Lost application
		if("1".equals(vo.getRsnCd())){
			vo.setOcrncDd(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		}else{
			vo.setOcrncDd("");
		}
		
		// Planned Card Delivery Date setting
		if("Y".equals(vo.getCrdIsuceYn())){
			vo.setCrdReisuceDueDd(NidStringUtil.toNumberConvet(vo.getCrdReisuceDueDd(), "g"));
			vo.setCrdReisuceDd(NidStringUtil.toNumberConvet(vo.getCrdReisuceDd(), "g"));
		}else{
			vo.setCrdReisuceDueDd("");
			vo.setCrdReisuceDd("");
		}
		
		//If it is not renewal, setting Card Expire Date to null
		if(!"3".equals(vo.getRsnCd())){
			vo.setAfCrdExpiryDd("");
		}
		
		log.debug("lost Date :"+vo.getOcrncDd());
		log.debug("planned issue date:"+vo.getCrdReisuceDueDd());
		log.debug("issue date :"+vo.getCrdReisuceDd());
		log.debug("expiry date :"+vo.getAfCrdExpiryDd());
		
		if("E".equals(vo.getPageFlag())){//update mode
			if(vo != null && vo.getRsnCd() != null && !"3".equals(vo.getRsnCd()) ){
				vo.setRsdtInfrChngYn("");
			}
			int result = crdReisuceDAO.updateCrdReisuceInfr(vo);
			if(result != 1){
				throw processException( "udtFail.msg");
			}
			if(vo != null && vo.getRsnCd() != null && "3".equals(vo.getRsnCd()) ){
				
					vo.setUserId(user.getUserId());
					result = crdReisuceDAO.updateRsdtMdfctInfr(vo);
					CrdReisuceVO lst = new CrdReisuceVO();
					lst.setRsdtSeqNo(vo.getRsdtSeqNo());
					lst.setMdfctSeqNo(vo.getMdfctSeqNo());
					lst.setUserId(user.getUserId());
					
					crdReisuceDAO.deleteRsdtMdfctNatLangAfTb(vo);
					crdReisuceDAO.deleteRsdtMdfctFrgnLangAfTb(vo);
					
					String[] afNatLangCd = vo.getNatLangCds();
					if(afNatLangCd != null && afNatLangCd.length > 0){
						for(int i = 0 ; i < afNatLangCd.length; i++){
							if(afNatLangCd[i] != null && !afNatLangCd[i].equals("")){
								lst.setLstLangCd(afNatLangCd[i]);
								crdReisuceDAO.insertRsdtMdfctNatLangAfTb(lst);
							}
						}
					}
					lst.setLstLangCd("");
					String[] afFrgnLangCd = vo.getFrgnLangCds();
					if(afFrgnLangCd != null && afFrgnLangCd.length > 0){
						for(int i = 0 ; i < afFrgnLangCd.length; i++){
							if(afFrgnLangCd[i] != null && !afFrgnLangCd[i].equals("")){
	   							lst.setLstLangCd(afFrgnLangCd[i]);
	   							crdReisuceDAO.insertRsdtMdfctFrgnLangAfTb(lst);
							}
						}
					}
					
					if(result != 1){
						throw processException( "udtFail.msg");
					}
				
			}
		}else{//insert mode
			
			if("3".equals(vo.getRsnCd()) ){
				vo.setBioChngYn("Y");
				
			}else{
				vo.setNextBioKey("");
				vo.setBioChngYn("N");
			}
			
			if(vo != null && vo.getSearchKeyword4() != null && !"3".equals(vo.getSearchKeyword4()) ){
				vo.setRsdtInfrChngYn("");
			}
			 String crdReisuSeqNo = crdReisuceDAO.insertCrdReisuceInfr(vo);
			 
			 if(vo != null && vo.getSearchKeyword4() != null && "3".equals(vo.getSearchKeyword4()) ){
				vo.setCfmTamLedrId(user.getUserId());
				vo.setTamLedrCfmYn("N");
				vo.setUserId(user.getUserId());
				vo.setBsnSeqNo(crdReisuSeqNo);
				vo.setCrdReisuceYn("Y");
				
				String mdfctSeqNo = crdReisuceDAO.insertRsdtMdfctInfr(vo);
				CrdReisuceVO lst = new CrdReisuceVO();
				lst.setRsdtSeqNo(vo.getRsdtSeqNo());
				lst.setMdfctSeqNo(mdfctSeqNo);
				lst.setUserId(user.getUserId());
				String[] afNatLangCd = vo.getNatLangCds();
				if(afNatLangCd != null && afNatLangCd.length > 0){
					for(int i = 0 ; i < afNatLangCd.length; i++){
						if(afNatLangCd[i] != null && !afNatLangCd[i].equals("")){
							lst.setLstLangCd(afNatLangCd[i]);
							crdReisuceDAO.insertRsdtMdfctNatLangAfTb(lst);
						}
					}
				}
				lst.setLstLangCd("");
				String[] afFrgnLangCd = vo.getFrgnLangCds();
				if(afFrgnLangCd != null && afFrgnLangCd.length > 0){
					for(int i = 0 ; i < afFrgnLangCd.length; i++){
						if(afFrgnLangCd[i] != null && !afFrgnLangCd[i].equals("")){
   							lst.setLstLangCd(afFrgnLangCd[i]);
   							crdReisuceDAO.insertRsdtMdfctFrgnLangAfTb(lst);
						}
					}
				}
				lst.setLstLangCd("");
				String[] natLangCd = vo.getNatLangCd();
				if(natLangCd != null && natLangCd.length > 0){
					for(int i = 0 ; i < natLangCd.length; i++){
						lst.setLstLangCd(natLangCd[i]);
						crdReisuceDAO.insertRsdtMdfctNatLangBfTb(lst);
					}
				}
				lst.setLstLangCd("");
				String[] frgnLangCd = vo.getFrgnLangCd();
				if(frgnLangCd != null && frgnLangCd.length > 0){
					for(int i = 0 ; i < frgnLangCd.length; i++){
						lst.setLstLangCd(frgnLangCd[i]);
						crdReisuceDAO.insertRsdtMdfctFrgnLangBfTb(lst);
					}
				}
			 }
		}
		
	}
	
	/**
	 * Biz-method for retrieving list of Reissuing Resident Information. <br>
	 * 
	 * @param vo Input item for retrieving list of Reissuing Resident Information(CrdReisuceVO).
	 * @return List Retrieve list of Reissuing Resident Information
	 * @exception Exception
	 */
	public List<CrdReisuceVO> searchListCrdReisuceAprv(CrdReisuceVO vo) throws Exception {
		return crdReisuceDAO.selectListCrdReisuceAprv(vo);
	}
	
	/**
	 * Biz-method for retrieving total count of Reissuing Resident Information. <br>
	 * 
	 * @param vo Input item for retrieving list of Reissuing Resident Information(CrdReisuceVO).
	 * @return int Total Count of Reissuing Resident Information List
	 * @exception Exception
	 */
	public int searchListCrdReisuceAprvTotCn(CrdReisuceVO vo) throws Exception {
		return crdReisuceDAO.selectListCrdReisuceAprvTotCn(vo);
	}
	
	/**
	 * Biz-method for retrieving Reissuing Resident Information. <br>
	 * 
	 * @param vo Input item for retrieving Resident Information.(CrdReisuceVO).
	 * @return CrdReisuceVO Retrieve Reissuing Resident Information.
	 * @exception Exception
	 */
	public CrdReisuceVO searchCrdReisuceDtlAprv(CrdReisuceVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		
		return crdReisuceDAO.selectCrdReisuceDtlAprv(vo);
	}
	
	/**
	 * Biz-method for Update information for card Reissuing. <br>
	 * 
	 * @param vo Input item for Update Card Reissuing Information(CrdReisuceVO).
	 * @exception Exception
	 */
	public void modifyCrdReisuceDtlAprv(CrdReisuceVO vo) throws Exception {
		//vo setting for registering
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setLstUdtUserId(user.getUserId());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());
		
		//Lost Date setting for Card Lost application
		if("1".equals(vo.getRsnCd())){
			vo.setOcrncDd(NidStringUtil.toNumberConvet(vo.getOcrncDd(), "g"));
		}else{
			vo.setOcrncDd("");
		}
		
		// Planned Card Delivery Date setting
		if("Y".equals(vo.getCrdIsuceYn())){
			vo.setCrdReisuceDueDd(NidStringUtil.toNumberConvet(vo.getCrdReisuceDueDd(), "g"));
		}else{
			vo.setCrdReisuceDueDd("");
			vo.setCrdReisuceDd("");
		}
		
		if(vo != null && vo.getRsnCd() != null && !"3".equals(vo.getRsnCd()) ){
			vo.setRsdtInfrChngYn("");
		}
		int result = crdReisuceDAO.updateCrdReisuceInfr(vo);
		
		if(result != 1){
			throw processException( "udtFail.msg");
		}
		
		if(vo != null && vo.getRsnCd() != null && "3".equals(vo.getRsnCd()) ){
			if(vo.getRsdtInfrChngYn() != null && "Y".equals(vo.getRsdtInfrChngYn())){
				vo.setUserId(user.getUserId());
				result = crdReisuceDAO.updateRsdtMdfctInfr(vo);
				CrdReisuceVO lst = new CrdReisuceVO();
				lst.setRsdtSeqNo(vo.getRsdtSeqNo());
				lst.setMdfctSeqNo(vo.getMdfctSeqNo());
				lst.setUserId(user.getUserId());
				crdReisuceDAO.deleteRsdtMdfctNatLangAfTb(vo);
				crdReisuceDAO.deleteRsdtMdfctFrgnLangAfTb(vo);
				String[] afNatLangCd = vo.getNatLangCds();
				if(afNatLangCd != null && afNatLangCd.length > 0){
					for(int i = 0 ; i < afNatLangCd.length; i++){
						if(afNatLangCd[i] != null && !afNatLangCd[i].equals("")){
							lst.setLstLangCd(afNatLangCd[i]);
							crdReisuceDAO.insertRsdtMdfctNatLangAfTb(lst);
						}
					}
				}
				lst.setLstLangCd("");
				String[] afFrgnLangCd = vo.getFrgnLangCds();
				if(afFrgnLangCd != null && afFrgnLangCd.length > 0){
					for(int i = 0 ; i < afFrgnLangCd.length; i++){
						if(afFrgnLangCd[i] != null && !afFrgnLangCd[i].equals("")){
								lst.setLstLangCd(afFrgnLangCd[i]);
								crdReisuceDAO.insertRsdtMdfctFrgnLangAfTb(lst);
						}
					}
				}
				if(result != 1){
					throw processException( "udtFail.msg");
				}
			}
		}
		
		
	}
	
	/**
	 * Biz-method for verification information for card Reissuing. <br>
	 * 
	 * @param vo Input item for verification Card Reissuing Information(CrdReisuceVO).
	 * @exception Exception
	 */
	public CrdReisuceVO approveCrdReisuceInfr(CrdReisuceVO vo) throws Exception {
		
		//for save changing Information
		modifyCrdReisuceDtlAprv(vo);
		
		//vo setting for Verification
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setFstRgstUserId(user.getUserId());
		vo.setLstUdtUserId(user.getUserId());
		vo.setCfmTamLedrId(user.getUserId());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());
		vo.setCrdIsucePlceCd(user.getOrgnzClsCd()+user.getOrgnzCd());

		// Planned Card Delivery Date setting
		if("Y".equals(vo.getCrdIsuceYn())){
			vo.setCrdReisuceDueDd(NidStringUtil.toNumberConvet(vo.getCrdReisuceDueDd(), "g"));
		}else{
			vo.setCrdReisuceDueDd("");
			vo.setCrdReisuceDd("");
		}
		
		CrdReisuceVO rsdtStatus = crdReisuceDAO.selectRsdtStusInfr(vo);
		vo.setRsdtStusCd(rsdtStatus.getRsdtStusCd());
		vo.setCrdIsuceSrlNo(rsdtStatus.getCrdIsuceSrlNo());		
		//check for Citizen Revocation Apply Status
		String rvctgStus = rsdtInfoService.searchRsdtRvctgStus(rsdtStatus.getRsdtNo(), "msg");
		log.debug("========rvctgStus : "+rvctgStus);
		if(!"".equals(rvctgStus)){
			vo.setErrCd("APVMSG");	
		}
		
		//Resident NID Number Card is being issued
		if(rsdtStatus.getCrdDitbDd() == null || "".equals(rsdtStatus.getCrdDitbDd())){
			vo.setErrCd("ERR04");	
			return vo;
		}
		
		//Resident NID Number is already verified for reissuing by another officer
		if(!"N".equals(rsdtStatus.getTamLedrCfmYn())){
			vo.setErrCd("ERR06");	
			return vo;
		}

		//Insert the Citizen information on DB for history before the changing
		rsdtDao.insertRsdtInfrHst(vo.getRsdtSeqNo(), user.getUserId());
		
		//get PKI cert issuance count
		int crtisuceCn = rsdtInfoService.searchPkiCrtIsuceCn(vo.getRsdtSeqNo());
		
		//Lost Approve without card reissuance
		log.debug("============'1'.equals(vo.getRsnCd()) :"+"getRsnCd :  "+vo.getRsnCd()+"::::"+"1".equals(vo.getRsnCd()));
		log.debug("============'N'.equals(vo.getCrdIsuceYn() :"+ "N".equals(vo.getCrdIsuceYn()));
		if("1".equals(vo.getRsnCd())&& "N".equals(vo.getCrdIsuceYn()) ){
			log.debug("=====Lost report : approve and chang citizen card info with no issue====");
			boolean result = crdReisuceDAO.updateAprvWithoutReisuce(vo);
			
			if(!result){
				throw processException( "udtFail.msg");
			}
			
			//Update Signature Data to RM_RSDT_TB
			rsdtInfoService.updateDigitalSgnt(vo.getRsdtSeqNo(), vo.getSgntDat(), "8");
						
			//Check Adult Y/N
			if(0 < crtisuceCn){
			    //Insert PKI log
				String lgSeqNo=lgDao.insertPubKeyIfLg(user.getUserId(), vo.getRsdtNo(), "7", "1", "8", "");
				vo.setLgSeqNo(lgSeqNo);
			}else{
				vo.setLgSeqNo("");
			}

			return vo;
		}
		
		log.debug("============Lost with on issue is passed============");
		
		//Approve Card Reissuance on DB
		log.debug("============vo.getAppDd()"+vo.getAppDd());
		vo.setAplCd("");
		if(vo != null && vo.getRsnCd() != null && "1".equals(vo.getRsnCd())){
			vo.setAplCd("4");
		}else if(vo != null && vo.getRsnCd() != null && "2".equals(vo.getRsnCd())){
			vo.setAplCd("5");
		}else if(vo != null && vo.getRsnCd() != null && "3".equals(vo.getRsnCd())){
			vo.setAplCd("6");
			vo.setCrdIsuceSrlNo("1");
			
			if("Y".equals(vo.getIsAdult()) && 0 >= crtisuceCn ){
				vo.setAplCd("8");
			}
			log.debug("======vo.getIsAdult() : "+vo.getIsAdult());
			log.debug("======crtisuceCn : "+crtisuceCn);
		}else if(vo != null && vo.getRsnCd() != null && "6".equals(vo.getRsnCd())){
			vo.setAplCd("7");
		}
		
		int crdReisuceDmBfExpr = propertiesService.getInt("crdReisuceDmBfExpr");
		vo.setCrdReisuceDmBfExpr(String.valueOf(crdReisuceDmBfExpr));
		int adultAge = propertiesService.getInt("adultAge");
		vo.setAdultAge(String.valueOf(adultAge));
		int crdExprProd = propertiesService.getInt("crdExprProd");
		vo.setCrdExprProd(String.valueOf(crdExprProd));
		
		boolean aprvResult = crdReisuceDAO.mergeCrdReisuceAprv(vo);
		log.debug("aprvResult :" + aprvResult);
		if(aprvResult){
			if(vo != null && vo.getRsnCd() != null && "3".equals(vo.getRsnCd())){
				vo.setUserId(user.getUserId());
				int crdResult = crdReisuceDAO.updateCrdReRsdtMdfctTbApp(vo);
				if(crdResult > 1){
					throw processException( "udtFail.msg");
				}
				if(vo.getRsdtInfrChngYn() != null && "Y".equals(vo.getRsdtInfrChngYn())){
					crdResult = crdReisuceDAO.updateRsdtMdfcToRsdtInfo(vo);
					if(crdResult > 1){
						throw processException( "udtFail.msg");
					}
					crdReisuceDAO.deleteOthrNatLang(vo);
					crdReisuceDAO.deleteFrgnLang(vo);
					crdReisuceDAO.insertOthrNatLangTb(vo);
					crdReisuceDAO.insertFrgnLangTb(vo);
				}
			}
		}else{
			throw processException( "udtFail.msg");
		}
		
		//Update Signature Data to RM_RSDT_TB
		rsdtInfoService.updateDigitalSgnt(vo.getRsdtSeqNo(), vo.getSgntDat(), "8");
		
		if("Y".equals(vo.getCrdIsuceYn()) ){//카드 재발급으로 습득 카드 모두 죽이기
			StringBuffer strBf = new StringBuffer();
			List<String> OrgList =crdFndService.modifyCrdFndPrcssStus(vo.getRsdtNo(), "4", "", "50");
			for(int i=0; i < OrgList.size(); i++){
				if(i == 0){
					strBf.append(OrgList.get(i));
				}else{
					strBf.append(", ").append(OrgList.get(i));
				}	
			}
	
			if(0 < OrgList.size()){
				vo.setDsuseMsg(nidMessageSource.getMessage("rgstDuseObjt.msg",new String[]{strBf.toString()})); //Message Setting
			}else{
				vo.setDsuseMsg("");
			}
		}
		
		//Call Bio API
		if("3".equals(vo.getRsnCd())){
			//리뉴얼은 바이오 정보 갱신으로 바이오 서버에 입력받은 바이오 정보 전달
			log.debug("============delivery bio info to bio server ============");
			
			byte [] bioFle = null;
			EgovMap ImCapt = rsdtDao.selectImBioCaptTbInfr(vo.getNextBioKey());
			if(ImCapt != null && !ImCapt.isEmpty()){
				rsdtDao.deleteImBioCaptTb(vo.getNextBioKey());
	   			bioFle = (byte[])ImCapt.get("bioFle");
	   			if(bioFle != null){
	   				EgovMap bioMap =bioIfService.addBioSocketIf(vo.getNextBioKey(), vo.getRsdtNo(), vo.getIsAdult(), user.getUserId(), "r", bioFle);
	   				vo.setBioMap(bioMap);
	   			}
			}else{
				throw processException( "udtFail.msg");
			}
		}
		
		return vo;
	}
	
	
	/**
	 * Biz-method for registering information of new user(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for registering new user(CcltRhbltVO).
	 * @return CcltRhbltVO Primary Key value of registered user
	 * @exception Exception
	 */
	public String approveCrdReisuceInfrPkiIf(CrdReisuceVO vo) throws Exception {
		
		String status = "";
		String erorYn ="Y";
		
		log.debug("=====adult  PKI OnHold  with no issue====");

		CpkiRmWSService orws= new CpkiRmWSService();
		CpkiRmWS orw = orws.getCpkiRmWSPort();	
			
		PkiRsWsResponse prwr = orw.cpkiIFcertHold(vo.getRsdtNo());
		status= prwr.getStatusCode();
	    log.debug("status ====> " + status);
	    
		if("0".equals(status)){
			erorYn ="N";
		}
		
		lgDao.updatePubKeyIfLg(vo.getLgSeqNo(), status, erorYn);			
		
		
    	return status;
    	
	}	
	
	
	/**
	 * Biz-method for Resident Information Lookup <br>
	 * 
	 * @param vo Input item for verification Card Reissuing Information(CrdReisuceVO).
	 * @exception Exception
	 */
	public CrdReisuceVO searchCrdRsdtInfrView(CrdReisuceVO vo) throws Exception {
		CrdReisuceVO result = null;
		if(vo != null && vo.getCrdReisuSeqNo() != null && !"".equals(vo.getCrdReisuSeqNo())){
			result = crdReisuceDAO.selectCrdRsdtInfrMdfcView(vo);
		}else{
			result = crdReisuceDAO.selectCrdRsdtInfrView(vo);
		}
		return result;
	}
	
	/**
	 * Biz-method for Resident Information Lookup <br>
	 * 
	 * @param vo Input item for verification Card Reissuing Information(CrdReisuceVO).
	 * @exception Exception
	 */
	public EgovMap searchCrdRsdtInfrFrgnOthrView(CrdReisuceVO vo) throws Exception {
		EgovMap result = new EgovMap();
		if(vo != null && vo.getCrdReisuSeqNo() != null && !"".equals(vo.getCrdReisuSeqNo())){
			List<EgovMap> list = crdReisuceDAO.selectCrdRsdtInfrFrgnBfView(vo);
			if(list != null && !list.isEmpty()){
				result.put("frgn", list);
			}
			list = crdReisuceDAO.selectCrdRsdtInfrOthrNatBfView(vo);
			if(list != null && !list.isEmpty()){
				result.put("othrnat", list);
			}
			list = crdReisuceDAO.selectCrdRsdtInfrFrgnAfView(vo);
			if(list != null && !list.isEmpty()){
				result.put("afFrgn", list);
			}
			list = crdReisuceDAO.selectCrdRsdtInfrOthrNatAfView(vo);
			if(list != null && !list.isEmpty()){
				result.put("afOthrnat", list);
			}
		}else{
			List<EgovMap> list = crdReisuceDAO.selectCrdRsdtInfrFrgnView(vo);
			if(list != null && !list.isEmpty()){
				result.put("frgn", list);
				result.put("afFrgn", list);
			}
			list = crdReisuceDAO.selectCrdRsdtInfrOthrNatView(vo);
			if(list != null && !list.isEmpty()){
				result.put("othrnat", list);
				result.put("afOthrnat", list);
			}
		}
		return result;
	}

	/**
	 * Biz-method for retrieving Receipt of Citizen Confirmation. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(CrdReisuceVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
   	public EgovMap searchCrdReisuceCfmRcpt(CrdReisuceVO vo) throws Exception {
        return crdReisuceDAO.selectCrdReisuceCfmRcpt(vo);
	}
	
   	/**
   	 * Biz-method for retrieving Receipt of Citizen Confirmation. <br>
   	 *
   	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(CrdReisuceVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchCrdReisuceOthrCfmRcpt(CrdReisuceVO vo) throws Exception {
      		return crdReisuceDAO.selectCrdReisuceOthrCfmRcpt(vo);
   	}
   	
   	/**
   	 * Biz-method for retrieving Receipt of Citizen Confirmation. <br>
   	 *
   	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(CrdReisuceVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchCrdReisuceFrgnCfmRcpt(CrdReisuceVO vo) throws Exception {
      		return crdReisuceDAO.selectCrdReisuceFrgnCfmRcpt(vo);
   	}
   	
   	/**
	 * Biz-method for retrieving Receipt of Citizen. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(CrdReisuceVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
   	public EgovMap searchCrdReisuceRcpt(CrdReisuceVO vo) throws Exception {
        return crdReisuceDAO.selectCrdReisuceRcpt(vo);
	}
	
   	/**
   	 * Biz-method for retrieving Receipt of Citizen. <br>
   	 *
   	 * @param vo Input item for  retrieving Receipt of Citizen (CrdReisuceVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchCrdReisuceOthrRcpt(CrdReisuceVO vo) throws Exception {
      		return crdReisuceDAO.selectCrdReisuceOthrRcpt(vo);
   	}
   	
   	/**
   	 * Biz-method for retrieving Receipt of Citizen. <br>
   	 *
   	 * @param vo Input item for  retrieving Receipt of Citizen (CrdReisuceVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchCrdReisuceFrgnRcpt(CrdReisuceVO vo) throws Exception {
      		return crdReisuceDAO.selectCrdReisuceFrgnRcpt(vo);
   	}
}
