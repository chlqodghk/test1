package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.cm.util.service.NidStringUtil;
import afnid.rm.crd.service.CrdFndRcivVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
/** 
 * This class is Database Access Object of Found Card Receive
 * 
 * @author Afghanistan National ID Card System Application Team SK Yang 
 * @since 2013.09.30
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.09.30  		SK Yang         		Create
 *
 * </pre>
 */
@Repository("crdFndRcivDAO")
public class CrdFndRcivDAO extends EgovAbstractDAO {
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	/**
	 * DAO-method for retrieving information of program. <br>
	 *
	 * @param vo Input item for retrieving Resident information of program(CrdFndVO).
	 * @return CrdFndRcivVO Retrieve information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<CrdFndRcivVO> selectCrdFndRcivInfr(CrdFndRcivVO vo) throws Exception{
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return list("crdFndRcivDAO.selectCrdFndRcivInfr", vo);		
	}
	
	/**
	 * DAO-method for retrieving Information List of program. <br>
	 *
	 * @param vo Input item for retrieving information List of program(CrdFndRcivVO).
	 * @return List<CrdFndRcivVO> Retrieve information List of program
	 * @exception Exception
	 */

	@SuppressWarnings("unchecked")
	public List<CrdFndRcivVO> selectListCrdFndRcivInfr(CrdFndRcivVO vo) throws Exception{
				
		return list("crdFndRcivDAO.selectListCrdFndRcivInfr", vo);
	}
	
	/**
	 * DAO-method for registering information of program. <br>
	 *
	 * @param vo Input item for registering information of new program(CrdFndRcivVO).
	 * @return boolean result
	 * @exception Exception
	 */
    public boolean updateCrdFndRcivInfr(CrdFndRcivVO vo) {
    	boolean result = false;
    	int	udtResult = update("crdFndRcivDAO.updateCrdFndRcivInfr", vo);
    	
    	if(udtResult == 1){
			result = true;
		}
    	
    	return result;
    }
    
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(CrdFndRcivVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<CrdFndRcivVO> selectListCrdFndRcivAprv(CrdFndRcivVO vo) throws Exception{		
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return list("crdFndRcivDAO.selectListCrdFndRcivAprv", vo);		
	}
	/**
	 * DAO-method for retrieving total count of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdFndRcivVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListCrdFndRcivAprvTotCn(CrdFndRcivVO vo) {
       
    	vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
    	
    	return (Integer)selectByPk("crdFndRcivDAO.selectListCrdFndRcivAprvTotCn", vo);
    }
   
	/**
	 * DAO-method for retrieving detail information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(CrdFndRcivVO).
	 * @return CrdFndRcivVO Retrieve detail information of program
	 * @exception Exception
	 */
	public CrdFndRcivVO selectCrdFndRcivDtlAprv(CrdFndRcivVO vo) throws Exception{
		return (CrdFndRcivVO)selectByPk("crdFndRcivDAO.selectCrdFndRcivDtlAprv", vo);		
	}

    /**
	 * DAO-method for approval information of program. <br>
	 * 
	 * @param vo Input item for retrieving list of program(CrdFndRcivVO).
	 * @return boolean result
	 * @exception Exception
	 */
    public boolean mergeCrdFndRcivInfr(CrdFndRcivVO vo) {
    	boolean result = false;
    	
    	String newCrdFondSeqNo = (String)insert("crdFndRcivDAO.insertNewFondCrdSeqNo", vo);
    	vo.setNewCrdFondSeqNo(newCrdFondSeqNo);
    	
    	int udtMvTb = update("crdFndRcivDAO.updateCrdFndRcivAprv", vo);
    	
    	int udtFondTb = update("crdFndRcivDAO.updateCrdPrcssStus", vo);
    	
    	if(udtMvTb == 1 && udtFondTb == 1){
			result = true;
		}
    	
    	return result;
    }
}
