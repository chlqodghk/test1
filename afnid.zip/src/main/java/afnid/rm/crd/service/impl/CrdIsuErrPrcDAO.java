package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Repository;
import com.ibatis.sqlmap.client.SqlMapClient;

import afnid.cm.code.service.CmCmmCdVO;
import afnid.rm.crd.service.CrdIsuErrPrcVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;




/** 
 * This class is Database Access Object of Card Issuance Error.
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2013.12.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           		Revisions
 *   2013.12.17  		MS Kim         		        Create
 *
 * </pre>
 */
@Repository("crdIsuErrPrcDAO")
public class CrdIsuErrPrcDAO extends EgovAbstractDAO {
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }

    /**
	 * DAO-method for retrieving list of card issuance status code. <br>
	 *
	 * @param vo Input item for retrieving list of card issuance status code(CmCmmCdVO).
	 * @return List<CmCmmCdVO> Retrieve list information of card issuance status code
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<CmCmmCdVO> selectListCrdStusCmmCd(CmCmmCdVO vo) {
        return list("crdIsuErrPrcDAO.selectListCrdStusCmmCd", vo);
    }
        
    /**
   	 * DAO-method for retrieving Information of card Issuance error <br>
   	 *
   	 * @param vo Input item for retrieving list of card issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
    @SuppressWarnings("unchecked")
	public List<CrdIsuErrPrcVO> selectListCrdIsuErr(CrdIsuErrPrcVO vo) {
        return list("crdIsuErrPrcDAO.searchListCrdIsuErr", vo);
    }
    
    /**
   	 * DAO-method for retrieving total count of card Issuance error. <br>
   	 *
   	 * @param vo Input item for retrieving list of card issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
	public int selectListCrdIsuErrTotCnt(CrdIsuErrPrcVO vo) {
        return (Integer)selectByPk("crdIsuErrPrcDAO.searchListCrdIsuErrTotCnt", vo);
    } 

    /**
   	 * DAO-method for retrieving Information of card Issuance error(File Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
    @SuppressWarnings("unchecked")
	public List<CrdIsuErrPrcVO> selectListCrdIsuErrFle(CrdIsuErrPrcVO vo) {
        return list("crdIsuErrPrcDAO.selectListCrdIsuErrFle", vo);
    }    
    
    /**
   	 * DAO-method for retrieving Information of card Issuance error(Signature Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
    @SuppressWarnings("unchecked")
	public List<CrdIsuErrPrcVO> selectListListCrdIsuErrSgnt(CrdIsuErrPrcVO vo) {
        return list("crdIsuErrPrcDAO.selectListListCrdIsuErrSgnt", vo);
    }
    
    /**
   	 * DAO-method for retrieving Information of card Issuance error(Pki Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
    @SuppressWarnings("unchecked")
	public List<CrdIsuErrPrcVO> selectListCrdIsuErrPkiRsdtInfrPrnt(CrdIsuErrPrcVO vo) {
        return list("crdIsuErrPrcDAO.selectListCrdIsuErrPkiRsdtInfrPrnt", vo);
    }
    
    /**
   	 * DAO-method for retrieving total count of card Issuance error(File Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
	public int selectListCrdIsuErrFleTotCnt(CrdIsuErrPrcVO vo) {
        return (Integer)selectByPk("crdIsuErrPrcDAO.selectListCrdIsuErrFleTotCnt", vo);
    }    
    
    /**
   	 * DAO-method for retrieving total count of card Issuance error(Signature Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
	public int selectListCrdIsuErrSgntTotCnt(CrdIsuErrPrcVO vo) {
        return (Integer)selectByPk("crdIsuErrPrcDAO.selectListCrdIsuErrSgntTotCnt", vo);
    }
    
    /**
   	 * DAO-method for retrieving total count of card Issuance error(Pki Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
	public int selectListCrdIsuErrPkiRsdtInfrPrntTotCnt(CrdIsuErrPrcVO vo) {
        return (Integer)selectByPk("crdIsuErrPrcDAO.selectListCrdIsuErrPkiRsdtInfrPrntTotCnt", vo);
    }
	
    
    /**
   	 * DAO-method for retrieving Information of card Issuance error(Pki Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
    @SuppressWarnings("unchecked")
	public List<CrdIsuErrPrcVO> selectListCrdIsuErrCmsEcpt(CrdIsuErrPrcVO vo) {
        return list("crdIsuErrPrcDAO.selectListCrdIsuErrCmsEcpt", vo);
    }
    
    /**
   	 * DAO-method for retrieving total count of card Issuance error(Pki Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
	public int selectListCrdIsuErrCmsEcptTotCnt(CrdIsuErrPrcVO vo) {
        return (Integer)selectByPk("crdIsuErrPrcDAO.selectListCrdIsuErrCmsEcptTotCnt", vo);
    }
	
	
    /**
   	 * DAO-method for retrieving Information of card Issuance error(Pki Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
    @SuppressWarnings("unchecked")
	public List<CrdIsuErrPrcVO> selectListCrdIsuErrCmsFeedback(CrdIsuErrPrcVO vo) {
        return list("crdIsuErrPrcDAO.selectListCrdIsuErrCmsFeedback", vo);
    }
    
    /**
   	 * DAO-method for retrieving total count of card Issuance error(Pki Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
	public int selectListCrdIsuErrCmsFeedbackTotCnt(CrdIsuErrPrcVO vo) {
        return (Integer)selectByPk("crdIsuErrPrcDAO.selectListCrdIsuErrCmsFeedbackTotCnt", vo);
    }

	
    /**
   	 * DAO-method for retrieving Information of card Issuance error(Signature Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
	public int getCrdDitbSeqNo(String key) {
        return (Integer)selectByPk("crdIsuErrPrcDAO.getCrdDitbSeqNo", key);
    }

	
	
    /**
   	 * DAO-method for processing of card Issuance error(CMS Exception Clear). <br>
   	 *
   	 * @param vo Input item for processing of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
	public void updateCrdIsuErrRpotdCrtnLg(CrdIsuErrPrcVO vo) {
		update("crdIsuErrPrcDAO.updateCrdIsuErrRpotdCrtnLg", vo);
    }
	
    /**
   	 * DAO-method for processing of card Issuance error(CMS Exception Clear). <br>
   	 *
   	 * @param vo Input item for processing of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
	public void updateCrdIsuErrRpotdCrtn(CrdIsuErrPrcVO vo) {
		update("crdIsuErrPrcDAO.updateCrdIsuErrRpotdCrtn", vo);
    }
	
	
    /**
   	 * DAO-method for processing of card Issuance error(Pki Error). <br>
   	 *
   	 * @param vo Input item for processing of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
	public void updateCrdIsuErrLca(CrdIsuErrPrcVO vo) {
		update("crdIsuErrPrcDAO.updateCrdIsuErrLca", vo);
    }	
	
    /**
   	 * DAO-method for processing of card Issuance error(Signature Error). <br>
   	 *
   	 * @param vo Input item for processing of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
	public void updateCrdIsuErr(CrdIsuErrPrcVO vo) {
		update("crdIsuErrPrcDAO.updateCrdIsuErr", vo);
    }
		
	
    /**
   	 * DAO-method for processing of card Issuance error(Signature Error). <br>
   	 *
   	 * @param vo Input item for processing of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
	public void updateCrdIsuErrSgnt(CrdIsuErrPrcVO vo) {
		update("crdIsuErrPrcDAO.updateCrdIsuErrSgnt", vo);
    }	
	
    /**
   	 * DAO-method for retrieving Information of card Issuance error(Signature Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
    @SuppressWarnings("unchecked")
	public List<CrdIsuErrPrcVO> selectListCrdIsuErrSgntCddt(CrdIsuErrPrcVO vo) {
        return list("crdIsuErrPrcDAO.selectListCrdIsuErrSgntCddt", vo);
    }	
    
	/**
	 * DAO-method for registering information of card issuance in im_crd_tb table(in case of Signature Error). <br>
	 * 
	 * @param vo Input item for registering card issuance in im_crd_tb table(CrdIsuErrPrcVO).
	 * @exception Exception
	 */
	public void insertCrdIsuSgnt(CrdIsuErrPrcVO vo){
		insert("crdIsuErrPrcDAO.insertCrdIsuSgnt", vo);
	}    
	
	
    /**
   	 * DAO-method for processing of card Issuance error(Pki Error). <br>
   	 *
   	 * @param vo Input item for processing of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
	public void updateCrdIsuErrPkiCtznPrntEcptcms(CrdIsuErrPrcVO vo) {
		update("crdIsuErrPrcDAO.updateCrdIsuErrPkiCtznPrntEcptcms", vo);
    }	
	
	/**
	 * DAO-method for registering information of card issuance in im_crd_tb table(in case of Pki Error). <br>
	 * 
	 * @param vo Input item for registering card issuance in im_crd_tb table(CrdIsuErrPrcVO).
	 * @exception Exception
	 */
	public void insertCrdIsuPkiCtznPrntEcptcms(CrdIsuErrPrcVO vo){
		insert("crdIsuErrPrcDAO.insertCrdIsuPkiCtznPrntEcptcms", vo);
	}	
}
