package afnid.rm.crd.service;

import java.util.List;

/** 
 * This service interface is biz-class of Found Card Distribution. <br>
 * 
 * @author Afghanistan National ID Card System Application Team SiKyung Yang
 * @since 2013.09.30
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers			Revisions
 *   2013.09.26  		SiKyung Yang		  Create
 *
 * </pre>
 */
public interface CrdFndDitbService {
	
	/**
	 * Retrieves information of program. <br>
	 *
	 * @param vo Input item for retrieving Information of program(CrdFndDitbVO).
	 * @return CrdFndDitbVO Retrieve information of program
	 * @exception Exception
	 */
	CrdFndDitbVO searchCrdFndDitbIdfcInfr(CrdFndDitbVO vo)throws Exception;
	
	/**
	 * Retrieves information List of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdFndDitbVO).
	 * @return List<CrdFndDitbVO> Retrieve list of program
	 * @exception Exception
	 */
	List<CrdFndDitbVO> searchListCrdFndDitbInfr(CrdFndDitbVO vo)throws Exception;
	
	/**
	 * Register information of program. <br>
	 *
	 * @param vo Input item for Registering information of program(CrdFndDitbVO).
	 * @return 
	 * @exception Exception
	 */
	void addCrdFndDitbIdfcInfr(CrdFndDitbVO vo) throws Exception;
	
	/**
	 * Retrieves information of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdFndDitbVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	CrdFndDitbVO searchCrdFndDitbInfr(CrdFndDitbVO vo)throws Exception;
	
	/**
	 * Register information of program. <br>
	 *
	 * @param vo Input item for Registering information of program(CrdFndDitbVO).
	 * @return 
	 * @exception Exception
	 */
	String modifyCrdFndDitbInfr(CrdFndDitbVO vo) throws Exception;
	
	
	/**
	 * user retirement(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for user retirement(CrdFndDitbVO).
	 * @return CrdFndDitbVO Primary Key value of user retirement
	 * @exception Exception
	 */
	String modifyCrdFndDitbInfrPkiIf(CrdFndDitbVO vo) throws Exception;
	
	
	/**
	 * updating information of Card Disuse. <br>
	 * 
	 * @param vo Input item for updating information of Card Disuse.(CrdFndDitbVO).
	 * @return 
	 * @exception Exception
	 */
	 void modifyCrdFndPrcssStusForDitbFndCrd(CrdFndDitbVO vo) throws Exception;
}
