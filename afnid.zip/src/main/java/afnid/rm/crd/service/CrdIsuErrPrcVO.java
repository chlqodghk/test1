package afnid.rm.crd.service;

import afnid.cm.ComDefaultVO;

public class CrdIsuErrPrcVO extends ComDefaultVO {


	private static final long serialVersionUID = 1L;
	
	private String crdDitbSeqNo;
	private String rsdtSeqNo;
	private String userId;
	private String fmlyBokNo;
	private String fmlyBokNoDp;
	private String rsdtNo;
	private String rsdtNoDp;
	private String fthrNm;
	private String rsdtNm;
	private String givNm;
	private String surnm;
	private String bthDd;
	private String gdrCd;
	private String gdrCdNm;
	private String crdIsuceDd;
	private String crdExpiryDd;
    private String fleRcivDd;
    private String rcivFleNm;
    private String erorCd;
    private String erorCdNm;
    private String erorMsg;
    private String erorPrcssYn;
    private String erorprcssDd;
    private String erorPrcssUserId;    
	private String curtAdCd;
	private String curtAdCdNm;
	private String curtAdDtlCt;
	private String crdIsuStusCd;	
	private String crdIsuStusCdNm;	
	private String[] checkboxList;	
	private String crdCd;
	private String aplCd;
	private String orgnzClsCd;	
	private String orgnzCd;
	private String lcaPrcssCddYn;
	
	private String gFleRcivDd;
	private String gErorPrcssDd;
	private String hFleRcivDd;
	private String hErorPrcssDd;	
	private String gBthDd;
	private String hBthDd;
	
	private String bsnCd;
	private String bsnSeqNo;
	private String nm;
	private String[] crdIsuStusCdList;
	
	public String getCrdDitbSeqNo() {
		return crdDitbSeqNo;
	}
	public void setCrdDitbSeqNo(String crdDitbSeqNo) {
		this.crdDitbSeqNo = crdDitbSeqNo;
	}
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFmlyBokNo() {
		return fmlyBokNo;
	}
	public void setFmlyBokNo(String fmlyBokNo) {
		this.fmlyBokNo = fmlyBokNo;
	}
	public String getFmlyBokNoDp() {
		return fmlyBokNoDp;
	}
	public void setFmlyBokNoDp(String fmlyBokNoDp) {
		this.fmlyBokNoDp = fmlyBokNoDp;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	public String getFthrNm() {
		return fthrNm;
	}
	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}
	public String getRsdtNm() {
		return rsdtNm;
	}
	public void setRsdtNm(String rsdtNm) {
		this.rsdtNm = rsdtNm;
	}
	public String getGivNm() {
		return givNm;
	}
	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}
	public String getSurnm() {
		return surnm;
	}
	public void setSurnm(String surnm) {
		this.surnm = surnm;
	}
	public String getBthDd() {
		return bthDd;
	}
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	public String getGdrCd() {
		return gdrCd;
	}
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}
	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}
	public String getFleRcivDd() {
		return fleRcivDd;
	}
	public void setFleRcivDd(String fleRcivDd) {
		this.fleRcivDd = fleRcivDd;
	}
	public String getRcivFleNm() {
		return rcivFleNm;
	}
	public void setRcivFleNm(String rcivFleNm) {
		this.rcivFleNm = rcivFleNm;
	}
	public String getErorCd() {
		return erorCd;
	}
	public void setErorCd(String erorCd) {
		this.erorCd = erorCd;
	}
	public String getErorCdNm() {
		return erorCdNm;
	}
	public void setErorCdNm(String erorCdNm) {
		this.erorCdNm = erorCdNm;
	}
	public String getErorMsg() {
		return erorMsg;
	}
	public void setErorMsg(String erorMsg) {
		this.erorMsg = erorMsg;
	}
	public String getErorPrcssYn() {
		return erorPrcssYn;
	}
	public void setErorPrcssYn(String erorPrcssYn) {
		this.erorPrcssYn = erorPrcssYn;
	}
	public String getErorprcssDd() {
		return erorprcssDd;
	}
	public void setErorprcssDd(String erorprcssDd) {
		this.erorprcssDd = erorprcssDd;
	}
	public String getErorPrcssUserId() {
		return erorPrcssUserId;
	}
	public void setErorPrcssUserId(String erorPrcssUserId) {
		this.erorPrcssUserId = erorPrcssUserId;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}
	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}
	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}
	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}	
	public String getCrdIsuStusCd() {
		return crdIsuStusCd;
	}
	public void setCrdIsuStusCd(String crdIsuStusCd) {
		this.crdIsuStusCd = crdIsuStusCd;
	}
	public String getCrdIsuStusCdNm() {
		return crdIsuStusCdNm;
	}
	public void setCrdIsuStusCdNm(String crdIsuStusCdNm) {
		this.crdIsuStusCdNm = crdIsuStusCdNm;
	}
	public java.lang.String[] getCheckboxList() {
		return checkboxList;
	}
	public void setCheckboxList(java.lang.String[] checkboxList) {
		this.checkboxList = checkboxList;
	}
	public String getCrdCd() {
		return crdCd;
	}
	public void setCrdCd(String crdCd) {
		this.crdCd = crdCd;
	}
	public String getAplCd() {
		return aplCd;
	}
	public void setAplCd(String aplCd) {
		this.aplCd = aplCd;
	}
	public String getOrgnzClsCd() {
		return orgnzClsCd;
	}
	public void setOrgnzClsCd(String orgnzClsCd) {
		this.orgnzClsCd = orgnzClsCd;
	}
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String getLcaPrcssCddYn() {
		return lcaPrcssCddYn;
	}
	public void setLcaPrcssCddYn(String lcaPrcssCddYn) {
		this.lcaPrcssCddYn = lcaPrcssCddYn;
	}
	public String getgFleRcivDd() {
		return gFleRcivDd;
	}
	public void setgFleRcivDd(String gFleRcivDd) {
		this.gFleRcivDd = gFleRcivDd;
	}
	public String getgErorPrcssDd() {
		return gErorPrcssDd;
	}
	public void setgErorPrcssDd(String gErorPrcssDd) {
		this.gErorPrcssDd = gErorPrcssDd;
	}
	public String gethFleRcivDd() {
		return hFleRcivDd;
	}
	public void sethFleRcivDd(String hFleRcivDd) {
		this.hFleRcivDd = hFleRcivDd;
	}
	public String gethErorPrcssDd() {
		return hErorPrcssDd;
	}
	public void sethErorPrcssDd(String hErorPrcssDd) {
		this.hErorPrcssDd = hErorPrcssDd;
	}
	public String getgBthDd() {
		return gBthDd;
	}
	public void setgBthDd(String gBthDd) {
		this.gBthDd = gBthDd;
	}
	public String gethBthDd() {
		return hBthDd;
	}
	public void sethBthDd(String hBthDd) {
		this.hBthDd = hBthDd;
	}
	public String getBsnCd() {
		return bsnCd;
	}
	public void setBsnCd(String bsnCd) {
		this.bsnCd = bsnCd;
	}
	public String getBsnSeqNo() {
		return bsnSeqNo;
	}
	public void setBsnSeqNo(String bsnSeqNo) {
		this.bsnSeqNo = bsnSeqNo;
	}
	public String getNm() {
		return nm;
	}
	public void setNm(String nm) {
		this.nm = nm;
	}
	public String[] getCrdIsuStusCdList() {
		return crdIsuStusCdList;
	}
	public void setCrdIsuStusCdList(String[] crdIsuStusCdList) {
		this.crdIsuStusCdList = crdIsuStusCdList;
	}

	
}
