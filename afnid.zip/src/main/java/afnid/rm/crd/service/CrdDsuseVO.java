package afnid.rm.crd.service;

import afnid.cm.ComDefaultVO;

public class CrdDsuseVO extends ComDefaultVO {


	private static final long serialVersionUID = 1L;
	
	private String tblGbn;
	private String seqNo;
	private String crdDsuseDd;
	private String crdDsuseUserId;
	private String rsdtNo;
	private String rsdtNoDp;
	private String rsdtNm;
	private String givNm;
	private String surnm;
	private String bthDd;
	private String gdrCd;
	private String gdrCdNm;   
	private String curtAdCd;
	private String curtAdCdNm;
	private String curtAdDtlCt;
	private String crdDitbStusCd;	
	private String crdDitbStusCdNm;	
	private java.lang.String[] checkboxList;
	private String orgnzCd;
	private String hCrdDsuseDd;
	private String gCrdDsuseDd;
	private String hBthDd;
	private String gBthDd;
	private String crdIsuceDd;
	private String hCrdIsuceDd;
	private String gCrdIsuceDd;
	private String crdIsuceSrlNo;
	private String crdDsuseStusCd;
	private String crdDsuseStusCdNm;
	private String crdPrcssStusCd;
	private String lgSeqNo;
	private String crdDsuseRqstMnNm;
	private String crdDsuseRsnCt;
	
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public String getCrdPrcssStusCd() {
		return crdPrcssStusCd;
	}
	public void setCrdPrcssStusCd(String crdPrcssStusCd) {
		this.crdPrcssStusCd = crdPrcssStusCd;
	}
	public String getCrdDsuseStusCdNm() {
		return crdDsuseStusCdNm;
	}
	public void setCrdDsuseStusCdNm(String crdDsuseStusCdNm) {
		this.crdDsuseStusCdNm = crdDsuseStusCdNm;
	}
	public String getCrdDsuseStusCd() {
		return crdDsuseStusCd;
	}
	public void setCrdDsuseStusCd(String crdDsuseStusCd) {
		this.crdDsuseStusCd = crdDsuseStusCd;
	}
	public String gethCrdIsuceDd() {
		return hCrdIsuceDd;
	}
	public void sethCrdIsuceDd(String hCrdIsuceDd) {
		this.hCrdIsuceDd = hCrdIsuceDd;
	}
	public String getgCrdIsuceDd() {
		return gCrdIsuceDd;
	}
	public void setgCrdIsuceDd(String gCrdIsuceDd) {
		this.gCrdIsuceDd = gCrdIsuceDd;
	}
	public String getCrdIsuceSrlNo() {
		return crdIsuceSrlNo;
	}
	public void setCrdIsuceSrlNo(String crdIsuceSrlNo) {
		this.crdIsuceSrlNo = crdIsuceSrlNo;
	}
	public String gethBthDd() {
		return hBthDd;
	}
	public void sethBthDd(String hBthDd) {
		this.hBthDd = hBthDd;
	}
	public String getgBthDd() {
		return gBthDd;
	}
	public void setgBthDd(String gBthDd) {
		this.gBthDd = gBthDd;
	}
	public String getTblGbn() {
		return tblGbn;
	}
	public void setTblGbn(String tblGbn) {
		this.tblGbn = tblGbn;
	}
	public String getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	public String getCrdDsuseDd() {
		return crdDsuseDd;
	}
	public void setCrdDsuseDd(String crdDsuseDd) {
		this.crdDsuseDd = crdDsuseDd;
	}
	public String getCrdDsuseUserId() {
		return crdDsuseUserId;
	}
	public void setCrdDsuseUserId(String crdDsuseUserId) {
		this.crdDsuseUserId = crdDsuseUserId;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	public String getRsdtNm() {
		return rsdtNm;
	}
	public void setRsdtNm(String rsdtNm) {
		this.rsdtNm = rsdtNm;
	}
	public String getGivNm() {
		return givNm;
	}
	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}
	public String getSurnm() {
		return surnm;
	}
	public void setSurnm(String surnm) {
		this.surnm = surnm;
	}
	public String getBthDd() {
		return bthDd;
	}
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	public String getGdrCd() {
		return gdrCd;
	}
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}
	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}
	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}
	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}
	public String getCrdDitbStusCd() {
		return crdDitbStusCd;
	}
	public void setCrdDitbStusCd(String crdDitbStusCd) {
		this.crdDitbStusCd = crdDitbStusCd;
	}
	public String getCrdDitbStusCdNm() {
		return crdDitbStusCdNm;
	}
	public void setCrdDitbStusCdNm(String crdDitbStusCdNm) {
		this.crdDitbStusCdNm = crdDitbStusCdNm;
	}
	public java.lang.String[] getCheckboxList() {
		return checkboxList;
	}
	public void setCheckboxList(java.lang.String[] checkboxList) {
		this.checkboxList = checkboxList;
	}
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String gethCrdDsuseDd() {
		return hCrdDsuseDd;
	}
	public void sethCrdDsuseDd(String hCrdDsuseDd) {
		this.hCrdDsuseDd = hCrdDsuseDd;
	}
	public String getgCrdDsuseDd() {
		return gCrdDsuseDd;
	}
	public void setgCrdDsuseDd(String gCrdDsuseDd) {
		this.gCrdDsuseDd = gCrdDsuseDd;
	}
	public String getLgSeqNo() {
		return lgSeqNo;
	}
	public void setLgSeqNo(String lgSeqNo) {
		this.lgSeqNo = lgSeqNo;
	}
	public String getCrdDsuseRqstMnNm() {
		return crdDsuseRqstMnNm;
	}
	public void setCrdDsuseRqstMnNm(String crdDsuseRqstMnNm) {
		this.crdDsuseRqstMnNm = crdDsuseRqstMnNm;
	}
	public String getCrdDsuseRsnCt() {
		return crdDsuseRsnCt;
	}
	public void setCrdDsuseRsnCt(String crdDsuseRsnCt) {
		this.crdDsuseRsnCt = crdDsuseRsnCt;
	}	

	
}
