package afnid.rm.crd.service;

import java.util.List;

import afnid.cm.code.service.CmCmmCdVO;
import egovframework.rte.psl.dataaccess.util.EgovMap;
/** 
 * This service interface is biz-class of Card Lost/ Damage/ Renewal. <br>
 * 
 * @author Afghanistan National ID Card System Application Team  Daesung Kim
 * @since 2013.06.14
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           			Revisions
 *   2013.06.14    		Daesung Kim          			Create
 *
 * </pre>
 */

public interface CrdReisuceService {
	
	/**
	 * Retrieves Resident Information. <br>
	 * 
	 * @param vo Input item for retrieving Resident Information(CrdReIsuInsVO).
	 * @return CrdReIsuInsVO Retrieve Resident Information
	 * @exception Exception
	 */
	CrdReisuceVO searchCrdReisuceInfr(CrdReisuceVO vo) throws Exception;
	
	/**
	 * Retrieves Card Reissuance Reason Code. <br>
	 * 
	 * @param vo Input item for retrieving Card Reissuance Reason Code(CrdReisuceVO).
	 * @return List<CmCmmCdVO> Retrieve Card Reissuance Reason Cod
	 * @exception Exception
	 */
	List<CmCmmCdVO> searchRsnCd(CrdReisuceVO vo) throws Exception;
	
	
	/**
	 * Register information of  card Reissuing. <br>
	 * 
	 * @param vo Input item for registering card Reissuing.(CrdReIsuInsVO).
	 * @return 
	 * @exception Exception
	 */

	void addCrdReisuceInfr(CrdReisuceVO vo) throws Exception;
	
	/**
	 * Retrieves list of Reissuing Resident Information. <br>
	 * 
	 * @param vo Input item for retrieving list of Reissuing Resident Information(CrdReIsuInsVO).
	 * @return List Retrieve list of Reissuing Resident Information.
	 * @exception Exception
	 */
	List <CrdReisuceVO> searchListCrdReisuceAprv(CrdReisuceVO vo) throws Exception;
	
	/**
	 * Retrieves total count of Reissuing Resident Information List. <br>
	 * @param vo Input item for retrieving total count of Reissuing Resident Information.(CrdReIsuInsVO)
	 * @return int Total Count of Reissuing Resident Information List
	 * @exception Exception
	 */
	int searchListCrdReisuceAprvTotCn(CrdReisuceVO vo) throws Exception;
	
	/**
	 * Retrieves Reissuing Resident Information. <br>
	 * 
	 * @param vo Input item for retrieving  Reissuing Resident Information(CrdReIsuInsVO).
	 * @return CrdReIsuInsVO Retrieve Reissuing Resident Information
	 * @exception Exception
	 */
	CrdReisuceVO searchCrdReisuceDtlAprv(CrdReisuceVO vo) throws Exception;
	
	/**
	 * Retrieves list of Reissuing Resident Information. <br>
	 * 
	 * @param vo Input item for retrieving list of Reissuing Resident Information(CrdReIsuInsVO).
	 * @return 
	 * @exception Exception
	 */
	void modifyCrdReisuceDtlAprv(CrdReisuceVO vo) throws Exception;
	
	/**
	 * Approval of Reissuing Resident Information. <br>
	 * 
	 * @param vo Input item for approval of Reissuance Information(CrdReIsuInsVO).
	 * @return List Retrieve list of Reissuing Resident Information.
	 * @exception Exception
	 */
	CrdReisuceVO approveCrdReisuceInfr(CrdReisuceVO vo) throws Exception;
	
	
	/**
	 * user retirement(PKI Interface Call). <br>
	 * 
	 * @param vo Input item for user retirement(CrdReisuceVO).
	 * @return CrdReIsuInsVO Primary Key value of user retirement
	 * @exception Exception
	 */
	String approveCrdReisuceInfrPkiIf(CrdReisuceVO vo) throws Exception;	
	
	/**
	 * Resident Information Lookup <br>
	 * 
	 * @param vo Input item for approval of Reissuance Information(CrdReisuceVO).
	 * @return List Retrieve list of Reissuing Resident Information.
	 * @exception Exception
	 */
	CrdReisuceVO searchCrdRsdtInfrView(CrdReisuceVO vo) throws Exception;
	
	
	/**
	 * Resident Information Lookup <br>
	 * 
	 * @param vo Input item for approval of Reissuance Information(CrdReisuceVO).
	 * @return List Retrieve list of Reissuing Resident Information.
	 * @exception Exception
	 */
	EgovMap searchCrdRsdtInfrFrgnOthrView(CrdReisuceVO vo) throws Exception;
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 * @param vo Input item for retrieving Receipt of Citizen Confirmation.(CrdReisuceVO)
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
	EgovMap searchCrdReisuceCfmRcpt(CrdReisuceVO vo) throws Exception;
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 *
	 * @param vo Input item for retrieving Receipt of Citizen Confirmation(CrdReisuceVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchCrdReisuceOthrCfmRcpt(CrdReisuceVO vo) throws Exception;
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 *
	 * @param vo Input item for retrieving Receipt of Citizen Confirmation(CrdReisuceVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap>  searchCrdReisuceFrgnCfmRcpt(CrdReisuceVO vo) throws Exception;
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 * @param vo Input item for retrieving Receipt of Citizen.(CrdReisuceVO)
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
	EgovMap searchCrdReisuceRcpt(CrdReisuceVO vo) throws Exception;
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 *
	 * @param vo Input item for retrieving Receipt of Citizen.(CrdReisuceVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchCrdReisuceOthrRcpt(CrdReisuceVO vo) throws Exception;
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 *
	 * @param vo Input item for retrieving Receipt of Citizen.(CrdReisuceVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap>  searchCrdReisuceFrgnRcpt(CrdReisuceVO vo) throws Exception;
}

