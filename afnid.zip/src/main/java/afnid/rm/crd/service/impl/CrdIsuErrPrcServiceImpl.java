package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.crd.service.CrdIsuErrPrcService;
import afnid.rm.crd.service.CrdIsuErrPrcVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;

/** 
 * This service class is biz-class of Card Issuance Error Processing.
 * and implements CrdIsuErrPrcService class.
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2013.12.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           		Revisions
 *   2013.12.17  		MS Kim        	        	Create
 *
 * </pre>
 */

@Service("crdIsuErrPrcService")
public class CrdIsuErrPrcServiceImpl extends AbstractServiceImpl implements CrdIsuErrPrcService{
	
	/** CrdFndDitbDAO */
    @Resource(name="crdIsuErrPrcDAO")
    private CrdIsuErrPrcDAO dao;

    /**
   	 * Biz-method for retrieving list of card issuance status code. <br>
   	 *
   	 * @param vo Input item for retrieving list of card issuance status code(CmCmmCdVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public List<CmCmmCdVO>  searchListCrdStusCmmCd(CmCmmCdVO vo) throws Exception {
		
		return dao.selectListCrdStusCmmCd(vo);
   	}
   	    
   	
    /**
   	 * Biz-method for retrieving list of card Issuance error. <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public List<CrdIsuErrPrcVO> searchListCrdIsuErr(CrdIsuErrPrcVO vo) throws Exception {
		return dao.selectListCrdIsuErr(vo);
   	}
   	
    /**
   	 * Biz-method for retrieving total count list of card Issuance error. <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public int searchListCrdIsuErrTotCnt(CrdIsuErrPrcVO vo) throws Exception {   		       
		return dao.selectListCrdIsuErrTotCnt(vo);
   	} 
   	
    /**
   	 * Biz-method for retrieving list of card Issuance error(File Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public List<CrdIsuErrPrcVO>  searchListCrdIsuErrFle(CrdIsuErrPrcVO vo) throws Exception {
		
		return dao.selectListCrdIsuErrFle(vo);

   	}
   	
    /**
   	 * Biz-method for retrieving total count list of card Issuance error(File Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public int searchListCrdIsuErrFleTotCnt(CrdIsuErrPrcVO vo) throws Exception {
		
		return dao.selectListCrdIsuErrFleTotCnt(vo);

   	} 
   	
    /**
   	 * Biz-method for retrieving list of card Issuance error(Signature Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public List<CrdIsuErrPrcVO>  searchListCrdIsuErrSgnt(CrdIsuErrPrcVO vo) throws Exception {

		return dao.selectListListCrdIsuErrSgnt(vo);
				
   	}
   	
    /**
   	 * Biz-method for retrieving total count list of card Issuance error(Signature Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public int searchListCrdIsuErrSgntTotCnt(CrdIsuErrPrcVO vo) throws Exception {

		return dao.selectListCrdIsuErrSgntTotCnt(vo);

   	} 
   	
    /**
   	 * Biz-method for retrieving list of card Issuance error(Pki Error, Citizen information Error, Print Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public List<CrdIsuErrPrcVO>  searchListCrdIsuErrPkiRsdtInfrPrnt(CrdIsuErrPrcVO vo) throws Exception {

		return dao.selectListCrdIsuErrPkiRsdtInfrPrnt(vo);

   	}      	

    /**
   	 * Biz-method for retrieving total count list of card Issuance error(Pki Error, Citizen information Error, Print Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public int searchListCrdIsuErrPkiRsdtInfrPrntTotCnt(CrdIsuErrPrcVO vo) throws Exception {
		
		return dao.selectListCrdIsuErrPkiRsdtInfrPrntTotCnt(vo);

   	}    	   
   	
    /**
   	 * Biz-method for retrieving list of card Issuance error(CMS Exception). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public List<CrdIsuErrPrcVO>  searchListCrdIsuErrCmsEcpt(CrdIsuErrPrcVO vo) throws Exception {

		return dao.selectListCrdIsuErrCmsEcpt(vo);

   	} 
   	
    /**
   	 * Biz-method for retrieving total count list of card Issuance error(CMS Exception). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public int searchListCrdIsuErrCmsEcptTotCnt(CrdIsuErrPrcVO vo) throws Exception {
		
		return dao.selectListCrdIsuErrCmsEcptTotCnt(vo);
   	}
   	
    /**
   	 * Biz-method for retrieving list of card Issuance error(CMS Feedback File Error, DPP Feedback File Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public List<CrdIsuErrPrcVO>  searchListCrdIsuErrCmsFeedback(CrdIsuErrPrcVO vo) throws Exception {

		return dao.selectListCrdIsuErrCmsFeedback(vo);

   	} 
   	
    /**
   	 * Biz-method for retrieving total count list of card Issuance error(CMS Feedback File Error, DPP Feedback File Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public int searchListCrdIsuErrCmsFeedbackTotCnt(CrdIsuErrPrcVO vo) throws Exception {
		
		return dao.selectListCrdIsuErrCmsFeedbackTotCnt(vo);
   	}
   	
	/**
	 * Biz-method for card Issuance error processing(CMS Exception Clear) <br>
	 * 
	 * @param vo Input item for card Issuance error processing(CrdIsuErrPrcVO).
	 * @return 
	 * @exception Exception
	 */
	public void modifyCrdIsuErrRpotdCrtn(CrdIsuErrPrcVO vo) throws Exception {

		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		
		vo.setErorPrcssUserId(user.getUserId());

		log.debug("=======================================================");
		log.debug("modifyCrdIsuErrRpotdCrtn  Stsrt");
		log.debug("=======================================================");
		
		String [] array = vo.getCheckboxList();

		//String [] crdIsuStusCd = vo.getCrdIsuStusCdList();
		
		log.debug("=======================================================");
		log.debug("array.length : " + array.length);
		log.debug("=======================================================");
		String [] rowData =  null;
		
		if (array != null) {
			for(int k=0;k<array.length; k++ ){
				rowData = array[k].split(",");
				
				log.debug("=======================================================");
				log.debug("crdDitbSeqNo : " + rowData[0]);				
				log.debug("crdIsuStusCd : " + rowData[1]);
				log.debug("tye   : " + rowData[2]);
				log.debug("=======================================================");

				vo.setCrdDitbSeqNo(rowData[0]);
				vo.setCrdIsuStusCd(rowData[1]);
				
				if("1".equals(rowData[2])){
					dao.updateCrdIsuErrRpotdCrtnLg(vo); //CM_DPP_FLE_PRCSS_LG_TB UPDATE
				} else {
					dao.updateCrdIsuErrRpotdCrtn(vo); //IM_CRD_DITB_TB UPDATE
				}
			
			}//end for-k
        }

	}   	
   	
	/**
	 * Biz-method for card Issuance error processing <br>
	 * 
	 * @param vo Input item for card Issuance error processing(CrdIsuErrPrcVO).
	 * @return 
	 * @exception Exception
	 */
	public void modifyCrdIsuErrLca(CrdIsuErrPrcVO vo) throws Exception {

		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		
		vo.setErorPrcssUserId(user.getUserId());

		log.debug("=======================================================");
		log.debug("modifyCrdIsuErrLca  Stsrt");
		log.debug("=======================================================");
		
		String [] array = vo.getCheckboxList();
		
		log.debug("=======================================================");
		log.debug("array.length : " + array.length);
		log.debug("=======================================================");
		String [] rowData =  null;
		
		if (array != null) {
			
			for(int k=0;k<array.length; k++ ){
				rowData = array[k].split(",");
				log.debug("=======================================================");
				log.debug("crdDitbSeqNo : " + rowData[0]);				
				log.debug("crdIsuStusCd : " + rowData[1]);
				log.debug("tye   : " + rowData[2]);
				log.debug("=======================================================");
				
				vo.setCrdDitbSeqNo(rowData[0]);
				vo.setCrdIsuStusCd(rowData[1]);				
				
				dao.updateCrdIsuErrLca(vo);//IM_CRD_DITB_TB UPDATE
				dao.updateCrdIsuErr(vo);   //IM_CRD_ISU_TB UPDATE(crd_ditb_cd, crd_ditb_dd)
				
			}//end for-k
        }

	}
	
	
	/**
	 * Biz-method for card Issuance error processing <br>
	 * 
	 * @param vo Input item for card Issuance error processing(CrdIsuErrPrcVO).
	 * @return 
	 * @exception Exception
	 */
	public void modifyCrdIsuErrRetry(CrdIsuErrPrcVO vo) throws Exception {

		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();		
		vo.setErorPrcssUserId(user.getUserId());

		log.debug("=======================================================");
		log.debug("modifyCrdIsuErrRetry  Stsrt");
		log.debug("=======================================================");
		
		String [] array = vo.getCheckboxList();
		
		log.debug("=======================================================");
		log.debug("array.length : " + array.length);
		log.debug("=======================================================");
		String [] rowData =  null;
		
		if (array != null) {
			
			for(int k=0;k<array.length; k++ ){
				rowData = array[k].split(",");
				log.debug("=======================================================");
				log.debug("crdDitbSeqNo : " + rowData[0]);				
				log.debug("crdIsuStusCd : " + rowData[1]);
				log.debug("tye   : " + rowData[2]);
				log.debug("=======================================================");
				
				if("3".equals(rowData[1])){//Signature Error processing
					vo.setRcivFleNm(rowData[0]);

					dao.updateCrdIsuErrSgnt(vo); //IM_CRD_DITB_TB UPDATE
					
					List<CrdIsuErrPrcVO>errList = dao.selectListCrdIsuErrSgntCddt(vo);
					
					for(int j=0; j<errList.size(); j++){
						CrdIsuErrPrcVO errVo = (CrdIsuErrPrcVO)errList.get(j);

						dao.updateCrdIsuErr(errVo);	//IM_CRD_ISU_TB UPDATE(crd_ditb_cd, crd_ditb_dd)				
						dao.insertCrdIsuSgnt(errVo);//IM_CRD_ISU_TB INSERT						
					}					
				} else if("4".equals(rowData[1]) || "6".equals(rowData[1]) || "7".equals(rowData[1]) || "8".equals(rowData[1])) {
					//PKI error, Invalid citizen's information, Print error 
					vo.setCrdDitbSeqNo(rowData[0]);
					vo.setCrdIsuStusCd(rowData[1]);
					dao.updateCrdIsuErrPkiCtznPrntEcptcms(vo); //IM_CRD_DITB_TB UPDATE
					dao.updateCrdIsuErr(vo);                   //IM_CRD_ISU_TB UPDATE(crd_ditb_cd, crd_ditb_dd)
					dao.insertCrdIsuPkiCtznPrntEcptcms(vo);    //IM_CRD_ISU_TB INSERT		
				}
			}//end for-k
        }

	}
	
	
}	
