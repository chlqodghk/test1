package afnid.rm.crd.service;

import java.util.List;

import afnid.cm.code.service.CmCmmCdVO;


/** 
 * This service interface is biz-class of Card Issuance Error Processing. <br>
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2013.12.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers			Revisions
 *   2013.12.17  		MS Kim		        Create
 *   
 * </pre>
 */
public interface CrdIsuErrPrcService {

	
	/**
	 * Retrieves information of ard issuance status code. <br>
	 *
	 * @param vo Input item for retrieving list of card issuance status code(CmCmmCdVO).
	 * @return card issuance status code
	 * @exception Exception
	 */
	public List<CmCmmCdVO>  searchListCrdStusCmmCd(CmCmmCdVO vo)throws Exception;
	
	/**
   	 * Retrieves list of card Issuance error(File Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public List<CrdIsuErrPrcVO>  searchListCrdIsuErr(CrdIsuErrPrcVO vo) throws Exception;
   	

    /**
   	 * Retrieves total count list of card Issuance error. <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public int searchListCrdIsuErrTotCnt(CrdIsuErrPrcVO vo) throws Exception;  
   	
	/**
   	 * Retrieves list of card Issuance error(File Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public List<CrdIsuErrPrcVO>  searchListCrdIsuErrFle(CrdIsuErrPrcVO vo) throws Exception;
   	
    /**
   	 * Retrieves list of card Issuance error(Signature Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public List<CrdIsuErrPrcVO>  searchListCrdIsuErrSgnt(CrdIsuErrPrcVO vo) throws Exception;
   	
    /**
   	 * Retrieves list of card Issuance error(Pki Error, Citizen information Error, Print Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public List<CrdIsuErrPrcVO>  searchListCrdIsuErrPkiRsdtInfrPrnt(CrdIsuErrPrcVO vo) throws Exception;  	
 
   	
    /**
   	 * Retrieves total count list of card Issuance error(File Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public int searchListCrdIsuErrFleTotCnt(CrdIsuErrPrcVO vo) throws Exception;  
   	
    /**
   	 * Biz-method for retrieving total coun list of card Issuance error(Signature Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public int searchListCrdIsuErrSgntTotCnt(CrdIsuErrPrcVO vo) throws Exception;
   	
    /**
   	 * Retrieves total count list of card Issuance error(Pki Error, Citizen information Error, Print Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public int searchListCrdIsuErrPkiRsdtInfrPrntTotCnt(CrdIsuErrPrcVO vo) throws Exception ;

    /**
   	 * Retrieves list of card Issuance error(CMS Exception). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public List<CrdIsuErrPrcVO> searchListCrdIsuErrCmsEcpt(CrdIsuErrPrcVO vo) throws Exception;  
   	

    /**
   	 * Retrieves total count list of card Issuance error(CMS Exception). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public int searchListCrdIsuErrCmsEcptTotCnt(CrdIsuErrPrcVO vo) throws Exception ;  
   	
    /**
   	 * Retrieves list of card Issuance error(CMS Feedback File Error, DPP Feedback File Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public List<CrdIsuErrPrcVO>  searchListCrdIsuErrCmsFeedback(CrdIsuErrPrcVO vo) throws Exception;  
   	
    /**
   	 * Retrieves total count list of card Issuance error(CMS Feedback File Error, DPP Feedback File Error). <br>
   	 *
   	 * @param vo Input item for retrieving list of card Issuance error(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
   	public int searchListCrdIsuErrCmsFeedbackTotCnt(CrdIsuErrPrcVO vo) throws Exception ;
   	
    /**
   	 * card Issuance error processing(CMS Exception Clear). <br>
   	 *
   	 * @param vo Input item for card Issuance error processing(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */   	
	public void modifyCrdIsuErrRpotdCrtn(CrdIsuErrPrcVO vo) throws Exception;	
	
    /**
   	 * card Issuance error processing. <br>
   	 *
   	 * @param vo Input item for card Issuance error processing(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */   	
	public void modifyCrdIsuErrLca(CrdIsuErrPrcVO vo) throws Exception;
	
    /**
   	 * card Issuance error processing. <br>
   	 *
   	 * @param vo Input item for card Issuance error processing(CrdIsuErrPrcVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */   	
	public void modifyCrdIsuErrRetry(CrdIsuErrPrcVO vo) throws Exception;	
   	 		
   	 	
}
