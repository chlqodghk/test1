package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.cm.util.service.NidStringUtil;
import afnid.rm.crd.service.CrdFndSndVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
/** 
 * This class is Database Access Object of Found Card Send
 * 
 * @author Afghanistan National ID Card System Application Team SK Yang
 * @since 2013.09.30
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.09.30  		SK Yang         							Create
 *
 * </pre>
 */
@Repository("crdFndSndDAO")
public class CrdFndSndDAO extends EgovAbstractDAO{
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	/**
	 * DAO-method for retrieving information of program. <br>
	 *
	 * @param vo Input item for retrieving Resident information of program(CrdFndSndVO).
	 * @return CrdFndSndVO Retrieve information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<CrdFndSndVO> selectCrdFndSndInfr(CrdFndSndVO vo) throws Exception{
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return list("crdFndSndDAO.selectCrdFndSndInfr", vo);		
	}
	
	/**
	 * DAO-method for retrieving Information List of program. <br>
	 *
	 * @param vo Input item for retrieving information List of program(CrdFndSndVO).
	 * @return List<CrdFndSndVO> Retrieve information List of program
	 * @exception Exception
	 */

	@SuppressWarnings("unchecked")
	public List<CrdFndSndVO> selectListCrdFndSndInfr(CrdFndSndVO vo) throws Exception{
				
		return list("crdFndSndDAO.selectListCrdFndSndInfr", vo);
	}
	
	/**
	 * DAO-method for updating Information of program. <br>
	 *
	 * @param vo Input item for updating information of program(CrdFndSndVO).
	 * @return boolean result
	 * @exception Exception
	 */

	public boolean updateCrdDsuseInfr(CrdFndSndVO vo) throws Exception{
		boolean result = false;
		
		int udtResult = update("crdFndSndDAO.updateCrdDsuseInfr", vo);
		
		if(udtResult == 1){
			result = true;
		}
		return result;
	}
	
	/**
	 * DAO-method for registering information of program. <br>
	 *
	 * @param vo Input item for registering information of new program(CrdFndSndVO).
	 * @return boolean result
	 * @exception Exception
	 */
    public boolean mergeCrdFndSndInfr(CrdFndSndVO vo) {
    	boolean result = false;
    	
    	
    	int udtResult = update("crdFndSndDAO.updateCrdPrcssStus", vo);
    	
    	if(udtResult == 1){
			result = true;
		}
    
    	if(vo.getSndRgstDd() == null || "".equals(vo.getSndRgstDd())){
    		insert("crdFndSndDAO.insertCrdFndSndInfr", vo);	
    	}else{
    		int	sndResult = update("crdFndSndDAO.updateCrdFndSndInfr", vo);
    		
    		if(sndResult != 1){
    			result = false;
    		}
    	} 

    	return result;
    }
    
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(CrdFndSndVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<CrdFndSndVO> selectListCrdFndSndAprv(CrdFndSndVO vo) throws Exception{		
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return list("crdFndSndDAO.selectListCrdFndSndAprv", vo);		
	}
	
	/**
	 * DAO-method for retrieving total count of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdFndSndVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListCrdFndSndAprvTotCn(CrdFndSndVO vo) {
        
    	vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
    	
    	return (Integer)selectByPk("crdFndSndDAO.selectListCrdFndSndAprvTotCn", vo);
    }

	/**
	 * DAO-method for retrieving detail information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(CrdFndSndVO).
	 * @return CrdFndSndVO Retrieve detail information of program
	 * @exception Exception
	 */
	public CrdFndSndVO selectCrdFndSndDtlAprv(CrdFndSndVO vo) throws Exception{
		return (CrdFndSndVO)selectByPk("crdFndSndDAO.selectCrdFndSndAprv", vo);		
	}
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(CrdFndSndVO).
	 * @return boolean result
	 * @exception Exception
	 */
	public boolean updateCrdFndSndAprvInfr(CrdFndSndVO vo){
		boolean result = false;
		int	udtResult = update("crdFndSndDAO.updateCrdFndSndInfr", vo);
		
		if(udtResult == 1){
			result = true;
		}
		return result;
	}
	/**
	 * DAO-method for approval information of program. <br>
	 *
	 * @param vo Input item for approval information  of program(CrdFndSndVO).
	 * @return boolean result
	 * @exception Exception
	 */
    public boolean updateCrdFndSndAprv(CrdFndSndVO vo) {
    	boolean result = false;
    	int	udtResult = update("crdFndSndDAO.updateCrdFndSndAprv", vo);
    	
    	if(udtResult == 1){
			result = true;
		}
    	return result;
    }
    
    /**
	 * DAO-method for retrieving list Information of organization. <br>
	 * 
	 * @param vo Input item for retrieving list information of organization(CrdFndSndVO).
	 * @return CrdFndSndVO Retrieve list information of organization
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")	
	public List<CrdFndSndVO> selectListOrgnzInfr(CrdFndSndVO vo) throws Exception{
		
		boolean uprOrgFlag = vo.getUprOrgFlag();
		boolean udrOrgFlag = vo.getUdrOrgFlag();

		List<CrdFndSndVO> orgnzList = null;
		if(uprOrgFlag){
			orgnzList = list("crdFndSndDAO.selectUpperOrgnzInfr", vo);
		}else if(udrOrgFlag){
			orgnzList = list("crdFndSndDAO.selectUnderOrgnzInfr", vo);
		}
			
		return orgnzList;
	}
    
}
