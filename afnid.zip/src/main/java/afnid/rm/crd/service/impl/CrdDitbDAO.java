package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.cm.util.service.NidStringUtil;
import afnid.rm.crd.service.CrdDitbVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;



/** 
 * This class is Database Access Object of Card Distribution.
 * 
 * @author Afghanistan National ID Card System Application Team Daesung Kim
 * @since 2013.09.26
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           		Revisions
 *   2013.09.26  		Daesung Kim         		Create
 *
 * </pre>
 */
@Repository("crdDitbDAO")
public class CrdDitbDAO extends EgovAbstractDAO {
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	
	
	/**
	 * DAO-method for retrieving information of citizen card application status. <br>
	 *
	 * @param vo Input item for retrieving information of citizen card application status.(CrdDitbVO).
	 * @return CrdDitbVO Retrieve information of Citizen Card Application Status.
	 * @exception Exception
	 */
	public CrdDitbVO selectRsdtCrdApplyStus(CrdDitbVO vo) throws Exception{
	
		return (CrdDitbVO)selectByPk("crdDitbDAO.selectRsdtCrdApplyStus", vo);
	}
	
	/**
	 * DAO-method for retrieving Information of program. <br>
	 *
	 * @param vo Input item for retrieving information of program(CrdDitbVO).
	 * @return CrdDitbVO Retrieve information of program
	 * @exception Exception
	 */
	public CrdDitbVO selectCrdDitbIdfcIndiInfr(CrdDitbVO vo) throws Exception{
	
		return (CrdDitbVO)selectByPk("crdDitbDAO.selectCrdDitbIdfcIndiInfr", vo);
	}
	
	/**
	 * DAO-method for retrieving Citizen Revocation Status. <br>
	 *
	 * @param vo Input item for retrieving Citizen Revocation Status.(CrdDitbVO).
	 * @return EgovMap Retrieve information of Citizen Revocation Status.
	 * @exception Exception
	 */
	public EgovMap selectRsdtRvctgStus(CrdDitbVO vo) throws Exception{
	
		return (EgovMap)selectByPk("crdDitbDAO.selectRsdtRvctgStus", vo);
	}
	
	/**
	 * DAO-method for Citizen Rehabilitation Information. <br>
	 *
	 * @param rsdtSeqNo Input item for Citizen Rehabilitation Information.(String).
	 * @return EgovMap Retrieve information of Citizen Rehabilitation.
	 * @exception Exception
	 */
	public int selectRsdtRhbltInfr(String rsdtSeqNo) throws Exception{
	
		return (Integer)selectByPk("crdDitbDAO.selectRsdtRhbltInfr", rsdtSeqNo);
	}
	
	/**
	 * DAO-method for registering information of program. <br>
	 *
	 * @param vo Input item for registering new program(CrdDitbVO).
	 * @return 
	 * @exception Exception
	 */
	public boolean updateCrdDitbIdfcIndiInfr(CrdDitbVO vo) throws Exception{
		boolean result = true;
		int udtResult = update("crdDitbDAO.updateCrdDitbIdfcIndiInfr", vo);

		if(udtResult < 1){
			result = false;
		}
		return result;
	}
	
	/**
	 * DAO-method for retrieving Information of program. <br>
	 *
	 * @param vo Input item for retrieving information of program(CrdDitbVO).
	 * @return CrdDitbVO Retrieve information of program
	 * @exception Exception
	 */

	public CrdDitbVO selectCrdDitbIndiInfr(CrdDitbVO vo) throws Exception{
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return (CrdDitbVO)selectByPk("crdDitbDAO.selectCrdDitbIndiInfr", vo);
	}
	
	/**
	 * DAO-method for retrieving Head of family Information of program. <br>
	 *
	 * @param vo Input item for retrieving information of program(CrdDitbVO).
	 * @return CrdDitbVO Retrieve information of program
	 * @exception Exception
	 */

	public CrdDitbVO selectFmlyHadInfr(CrdDitbVO vo) throws Exception{
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return (CrdDitbVO)selectByPk("crdDitbDAO.selectFmlyHadInfr", vo);
	}


	/**
	 * DAO-method for retrieving family list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdDitbVO).
	 * @return List<CrdDitbVO> Retrieve list information of program
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<CrdDitbVO> selectListFmlyMberCrdApplyStus(CrdDitbVO vo) {
        return list("crdDitbDAO.selectListFmlyMberCrdApplyStus", vo);
    }
	
	/**
	 * DAO-method for retrieving family list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdDitbVO).
	 * @return List<CrdDitbVO> Retrieve list information of program
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<CrdDitbVO> selectListCrdDitbIdfcFmlyMber(CrdDitbVO vo) {
        return list("crdDitbDAO.selectListCrdDitbIdfcFmlyMber", vo);
    }
	
    /**
	 * DAO-method for retrieving family list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdDitbVO).
	 * @return List<CrdDitbVO> Retrieve list information of program
	 * @exception Exception
	 */
    @SuppressWarnings("unchecked")
	public List<CrdDitbVO> selectListCrdDitbFmlyMber(CrdDitbVO vo) {
        return list("crdDitbDAO.selectListCrdDitbFmlyMber", vo);
    }
	    
	/**
	 * DAO-method for registering information of program. <br>
	 *
	 * @param vo Input item for registering new program(CrdDitbVO).
	 * @return 
	 * @exception Exception
	 */
	public boolean updateCrdDitbIdfcFmlyInfr(CrdDitbVO vo) throws Exception{
		boolean result = true;
		int udtResult = update("crdDitbDAO.updateCrdDitbIdfcFmlyInfr", vo);
		
		if(udtResult < 1){
			result = false;
		}
		return result;
	}
	
	/**
	 * DAO-method for registering information of program. <br>
	 *
	 * @param vo Input item for registering new program(CrdDitbVO).
	 * @return boolean result
	 * @exception Exception
	 */
	public boolean updateCrdDsuseInfr(CrdDitbVO vo) throws Exception{
			
		int ditbResult = update("crdDitbDAO.updateCrdDitbInfrImCrdDitbTb", vo);
		
		int isuResult = update("crdDitbDAO.updateCrdDitbInfrImCrdIsuTb", vo);
		if(ditbResult != 1 || isuResult != 1){
			return  false;
		}
		
		return true ;
	}
	
	/**
	 * DAO-method for registering information of program. <br>
	 *
	 * @param vo Input item for registering new program(CrdDitbVO).
	 * @return 
	 * @exception Exception
	 */
	public boolean updateCrdDitbInfr(CrdDitbVO vo) throws Exception{
		
		boolean result = false;
		int ditbResult = update("crdDitbDAO.updateCrdDitbInfrImCrdDitbTb", vo);
		
		int isuResult = update("crdDitbDAO.updateCrdDitbInfrImCrdIsuTb", vo);
		
		int rsdtResult = update("crdDitbDAO.updateCrdDitbInfrRmRsdtTb", vo);
			
		if(ditbResult == 1 && isuResult == 1&& rsdtResult == 1){
			result = true;
		}
		
		return result ;
		
	}
	
	
	/**
	 * DAO-method for Update Signature Data to RM_RSDT_TB. <br>
	 * 
	 * @param vo Input item for Update Signature Data.(crdDitbDAO).
	 * @return crdDitbDAO result of Updating Signature Data.
	 * @exception Exception
	 */
	public boolean updateSgntDat(CrdDitbVO vo) throws Exception{
		
		boolean result = false; 
		int sgntResult = update("crdDitbDAO.updateSgntDat", vo);
			
		if(sgntResult == 1){
			result = true;
		}
		
		return result ;
	}
}
