package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.cm.util.service.NidStringUtil;
import afnid.rm.crd.service.CrdFndDitbVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This class is Database Access Object of Found Card Distribution
 * 
 * @author Afghanistan National ID Card System Application Team SK Yang
 * @since 2013.09.30
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.09.30  		SK Yang         		Create
 *
 * </pre>
 */
@Repository("crdFndDitbDAO")
public class CrdFndDitbDAO extends EgovAbstractDAO{
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	
	/**
	 * DAO-method for retrieving Information of program. <br>
	 *
	 * @param vo Input item for retrieving information of program(CrdFndDitbVO).
	 * @return List<CrdFndDitbVO> Retrieve information of program
	 * @exception Exception
	 */

	@SuppressWarnings("unchecked")
	public List<CrdFndDitbVO> selectCrdFndDitbIdfcInfr(CrdFndDitbVO vo) throws Exception{
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return list("crdFndDitbDAO.selectCrdFndDitbIdfcInfr", vo);
	}
	
	/**
	 * DAO-method for retrieving Information List of program. <br>
	 *
	 * @param vo Input item for retrieving information List of program(CrdFndDitbVO).
	 * @return List<CrdFndDitbVO> Retrieve information List of program
	 * @exception Exception
	 */

	@SuppressWarnings("unchecked")
	public List<CrdFndDitbVO> selectListCrdFndDitbInfr(CrdFndDitbVO vo) throws Exception{
		List<CrdFndDitbVO> resultList = null; 

		if("I".equals(vo.getPopFlag())){
			resultList = list("crdFndDitbDAO.selectListCrdFndDitbIdfcInfr", vo);
		}else if("D".equals(vo.getPopFlag())){
			resultList = list("crdFndDitbDAO.selectListCrdFndDitbInfr", vo);
		}		
		return resultList;
	}
	
	/**
	 * DAO-method for registering information for card Reissuing. <br>
	 * 
	 * @param vo Input item for registering for card Reissuing(CrdFndDitbVO).
	 * @return 
	 * @exception Exception
	 */
    public void insertCrdFndDitbIdfcInfr(CrdFndDitbVO vo) throws Exception{
    	insert("crdFndDitbDAO.insertCrdFndDitbIdfcInfr", vo);
    	
    }
    
    /**
	 * DAO-method for retrieving Information of program. <br>
	 *
	 * @param vo Input item for retrieving information of program(CrdFndDitbVO).
	 * @return CrdFndDitbVO Retrieve information of program
	 * @exception Exception
	 */

	@SuppressWarnings("unchecked")
	public List<CrdFndDitbVO> selectCrdFndDitbInfr(CrdFndDitbVO vo) throws Exception{
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		
		return list("crdFndDitbDAO.selectCrdFndDitbInfr", vo);
	}
	
	/**
	 * DAO-method for retrieving Citizen Revocation Status. <br>
	 *
	 * @param vo Input item for retrieving Citizen Revocation Status.(CrdFndDitbVO).
	 * @return EgovMap Retrieve information of Citizen Revocation Status.
	 * @exception Exception
	 */
	public EgovMap selectRsdtRvctgStus(CrdFndDitbVO vo) throws Exception{
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		return (EgovMap)selectByPk("crdFndDitbDAO.selectRsdtRvctgStus", vo);
	}
	
	/**
	 * DAO-method for registering information of program. <br>
	 *
	 * @param vo Input item for registering new program(CrdFndDitbVO).
	 * @return 
	 * @exception Exception
	 */
	public boolean updateCrdFndDitbInfr(CrdFndDitbVO vo) throws Exception{
		boolean result = true;
		int udtResult = update("crdFndDitbDAO.updateCrdFndDitbInfr", vo);
		
		int fndResult = update("crdFndDitbDAO.updateCrdFndDitbToCrdFndTb", vo);

		int rsdtResult = update("crdFndDitbDAO.updateCrdFndDitbInfrRmRsdtTb", vo);
		
		if(udtResult < 1 || rsdtResult < 1 || fndResult < 1){
			result = false;
		}
		return result;
	}
	
	/**
	 * DAO-method for Update Signature Data to RM_RSDT_TB. <br>
	 * 
	 * @param vo Input item for Update Signature Data.(crdFndDitbDAO).
	 * @return crdFndDitbDAO result of Updating Signature Data.
	 * @exception Exception
	 */
	public boolean updateSgntDat(CrdFndDitbVO vo) throws Exception{
		
		boolean result = false; 
		int sgntResult = update("crdFndDitbDAO.updateSgntDat", vo);
			
		if(sgntResult == 1){
			result = true;
		}
		
		return result ;
	}
	
	/**
	 * DAO-method for updating Information of program. <br>
	 *
	 * @param vo Input item for updating information of program(CrdFndDitbVO).
	 * @return boolean result
	 * @exception Exception
	 */

	public boolean updateCrdDsuseInfr(CrdFndDitbVO vo) throws Exception{
		boolean result = false;
		
		int udtResult = 1;
		if("ditb".equals(vo.getReturnFlag()) ){
			vo.setCrdDitbCd("3");
			udtResult = update("crdFndDitbDAO.updateCrdFndDitbInfr", vo);
		}

		int fndResult = update("crdFndDitbDAO.updateCrdDsuseInfr", vo);
		
		if(udtResult == 1 && fndResult == 1){
			result = true;
		}
		return result;
	}
}
