package afnid.rm.crd.service;

import afnid.cm.ComDefaultVO;

public class CrdRnwlCddVO extends ComDefaultVO {
	
	private static final long serialVersionUID = 1L;
	
	//family book no
	private String fmlyBokNo;
	private String fmlyMberNo;
	//family book number for screen display
	private String fmlyBokNoDp;
	//resident no
	private String rsdtNo;
	//resident no display
	private String rsdtNoDp;	
	//given name
	private String givNm;
	//surname
	private String surnm;
	//birthday
	private String bthDd;
	//gender
	private String gdrCd;
	//gender code name
	private String gdrCdNm;
	//father name
	private String fthrNm;
	//grand father name
	private String gfthrNm;
	//current address code
	private String curtAdCd;
	//current address 
	private String curtAdCdNm;	
	//current detail address 
	private String curtAdDtlCt;	
	//card expire date
	private String crdExpiryDd;
	
	//organization code + team code
	private String officerNo;
	
	//search condition - expire date
	private String expiryDate;

	private String hBthDd;
	private String gBthDd;
	private String hCrdExpiryDd;
	private String gCrdExpiryDd;
	
	private String title;
	
	/**
	 * @return the fmlyBokNo
	 */
	public String getFmlyBokNo() {
		return fmlyBokNo;
	}

	/**
	 * @param fmlyBokNo the fmlyBokNo to set
	 */
	public void setFmlyBokNo(String fmlyBokNo) {
		this.fmlyBokNo = fmlyBokNo;
	}

	/**
	 * @return the fmlyMberNo
	 */
	public String getFmlyMberNo() {
		return fmlyMberNo;
	}

	/**
	 * @param fmlyMberNo the fmlyMberNo to set
	 */
	public void setFmlyMberNo(String fmlyMberNo) {
		this.fmlyMberNo = fmlyMberNo;
	}

	/**
	 * @return the fmlyBokNoDp
	 */
	public String getFmlyBokNoDp() {
		return fmlyBokNoDp;
	}

	/**
	 * @param fmlyBokNoDp the fmlyBokNoDp to set
	 */
	public void setFmlyBokNoDp(String fmlyBokNoDp) {
		this.fmlyBokNoDp = fmlyBokNoDp;
	}

	/**
	 * @return the rsdtNo
	 */
	public String getRsdtNo() {
		return rsdtNo;
	}

	/**
	 * @param rsdtNo the rsdtNo to set
	 */
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}

	/**
	 * @return the givNm
	 */
	public String getGivNm() {
		return givNm;
	}

	/**
	 * @param givNm the givNm to set
	 */
	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}

	/**
	 * @return the surnm
	 */
	public String getSurnm() {
		return surnm;
	}

	/**
	 * @param surnm the surnm to set
	 */
	public void setSurnm(String surnm) {
		this.surnm = surnm;
	}

	/**
	 * @return the bthDd
	 */
	public String getBthDd() {
		return bthDd;
	}

	/**
	 * @param bthDd the bthDd to set
	 */
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}

	/**
	 * @return the gdrCd
	 */
	public String getGdrCd() {
		return gdrCd;
	}

	/**
	 * @param gdrCd the gdrCd to set
	 */
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}

	/**
	 * @return the gdrCdNm
	 */
	public String getGdrCdNm() {
		return gdrCdNm;
	}

	/**
	 * @param gdrCdNm the gdrCdNm to set
	 */
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}

	public String getFthrNm() {
		return fthrNm;
	}

	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}

	public String getGfthrNm() {
		return gfthrNm;
	}

	public void setGfthrNm(String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}

	/**
	 * @return the curtAdCd
	 */
	public String getCurtAdCd() {
		return curtAdCd;
	}

	/**
	 * @param curtAdCd the curtAdCd to set
	 */
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}

	/**
	 * @return the crdExpiryDd
	 */
	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}

	/**
	 * @param crdExpiryDd the crdExpiryDd to set
	 */
	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}

	/**
	 * @return the officerNo
	 */
	public String getOfficerNo() {
		return officerNo;
	}

	/**
	 * @param officerNo the officerNo to set
	 */
	public void setOfficerNo(String officerNo) {
		this.officerNo = officerNo;
	}

	/**
	 * @return the expiryDate
	 */
	public String getExpiryDate() {
		return expiryDate;
	}

	/**
	 * @param expiryDate the expiryDate to set
	 */
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String gethBthDd() {
		return hBthDd;
	}

	public void sethBthDd(String hBthDd) {
		this.hBthDd = hBthDd;
	}

	public String getgBthDd() {
		return gBthDd;
	}

	public void setgBthDd(String gBthDd) {
		this.gBthDd = gBthDd;
	}

	public String gethCrdExpiryDd() {
		return hCrdExpiryDd;
	}

	public void sethCrdExpiryDd(String hCrdExpiryDd) {
		this.hCrdExpiryDd = hCrdExpiryDd;
	}

	public String getgCrdExpiryDd() {
		return gCrdExpiryDd;
	}

	public void setgCrdExpiryDd(String gCrdExpiryDd) {
		this.gCrdExpiryDd = gCrdExpiryDd;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}

	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}

	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}

	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}

	public String getRsdtNoDp() {
		return rsdtNoDp;
	}

	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	
	
}
