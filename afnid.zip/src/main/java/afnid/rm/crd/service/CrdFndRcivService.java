package afnid.rm.crd.service;

import java.util.List;

/** 
 * This service interface is biz-class of Found Card Receive. <br>
 * 
 * @author Afghanistan National ID Card System Application Team SiKyung Yang
 * @since 2013.09.30
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers			Revisions
 *   2013.09.30  		SiKyung Yang		  Create
 *
 * </pre>
 */
public interface CrdFndRcivService {
	
	/**
	 * Retrieves information of found card receiving <br>
	 *
	 * @param vo Input item for retrieving  information of found card receiving(CrdFndRcivVO).
	 * @return CrdFndRcivVO Retrieve receiving information
	 * @exception Exception
	 */
	CrdFndRcivVO searchCrdFndRcivInfr(CrdFndRcivVO vo) throws Exception;
	
	/**
	 * Retrieves information List of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdFndRcivVO).
	 * @return List<CrdFndRcivVO> Retrieve list of program
	 * @exception Exception
	 */
	List<CrdFndRcivVO> searchListCrdFndRcivInfr(CrdFndRcivVO vo)throws Exception;
	
	/**
	 * registering information of found card receiving <br>
	 *
	 * @param vo Input item for registering information of program(CrdFndSndVO).
	 * @return 
	 * @exception Exception
	 */
	void addCrdFndRcivInfr(CrdFndRcivVO vo) throws Exception;	
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(CrdFndRcivVO).
	 * @return List<CrdFndRcivVO> Retrieve list of program
	 * @exception Exception
	 */
	List<CrdFndRcivVO> searchListCrdFndRcivAprv(CrdFndRcivVO vo) throws Exception;	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * 
	 * @param vo Input item for retrieving total count of program.(CrdFndRcivVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListCrdFndRcivAprvTotCn(CrdFndRcivVO vo) throws Exception;
	
	/**
	 * Retrieves detail information of card found receiving <br>
	 *
	 * @param vo Input item for retrieving resident information for card found registration(CrdFndSndVO).
	 * @return CrdFndRcivVO Retrieve detail information
	 * @exception Exception
	 */
	CrdFndRcivVO searchCrdFndRcivDtlAprv(CrdFndRcivVO vo) throws Exception;
		
	/**
	 * approve information of card found receiving. <br>
	 * 
	 * @param vo Input item for approving information of program.(CrdFndVO)
	 * @return 
	 * @exception Exception
	 */
	void approveCrdFndRcivInfr (CrdFndRcivVO vo) throws Exception;
	
}	
