package afnid.rm.crd.service.impl;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Repository;
import com.ibatis.sqlmap.client.SqlMapClient;

import afnid.rm.crd.service.CrdDsuseVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;




/** 
 * This class is Database Access Object of Card Disuse.
 * 
 * @author Afghanistan National ID Card System Application Team MS Kim
 * @since 2013.12.17
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           		Revisions
 *   2013.12.17  		MS Kim         		        Create
 *
 * </pre>
 */
@Repository("crdDsuseDAO")
public class CrdDsuseDAO extends EgovAbstractDAO {
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	
       
    /**
   	 * DAO-method for retrieving Information of card disuse. <br>
   	 *
   	 * @param vo Input item for retrieving list of card issuance error(CrdDsuseVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
    @SuppressWarnings("unchecked")
	public List<CrdDsuseVO> selectListCrdDsuse(CrdDsuseVO vo) {
        return list("crdDsuseDAO.selectListCrdDsuse", vo);
    }    
    

    
    /**
   	 * DAO-method for retrieving total count of card disuse. <br>
   	 *
   	 * @param vo Input item for retrieving list of card issuance error(CrdDsuseVO).
   	 * @return card issuance status code
   	 * @exception Exception
   	 */
	public int selectListCrdDsuseTotCnt(CrdDsuseVO vo) {
        return (Integer)selectByPk("crdDsuseVAO.selectListCrdDsuseTotCnt", vo);
    }    
	

	 /**
   	 * DAO-method for processing of card disuse request in im_crd_ditb_tb table. <br>
   	 *
   	 * @param vo Input item for processing of card Issuance error(CrdDsuseVO).
   	 * @return update result
   	 * @exception Exception
   	 */
	public int updateDitbCrdDsuseRqst(CrdDsuseVO vo) {
		int result = update("crdDsuseDAO.updateDitbCrdDsuseRqst", vo);
		return result;
    }
	
	
    /**
   	 * DAO-method for processing of card disuse request in rm_fond_crd_tb table <br>
   	 *
   	 * @param vo Input item for processing of card Issuance error(CrdDsuseVO).
   	 * @return update result
   	 * @exception Exception
   	 */
	public int updateFondCrdDsuseRqst(CrdDsuseVO vo) {
		int result = update("crdDsuseDAO.updateFondCrdDsuseRqst", vo);
		
		return result;
    }
	
    /**
   	 * DAO-method for processing of card disuse request in rm_dcrd_tb table <br>
   	 *
   	 * @param vo Input item for processing of card Issuance error(CrdDsuseVO).
   	 * @return update result
   	 * @exception Exception
   	 */
	public int updateDsuseRqst(CrdDsuseVO vo) {
		int result = update("crdDsuseDAO.updateDsuseRqst", vo);
		
		return result;
    }
	
    /**
   	 * DAO-method for processing of card disuse in im_crd_ditb_tb table. <br>
   	 *
   	 * @param vo Input item for processing of card Issuance error(CrdDsuseVO).
   	 * @return update result
   	 * @exception Exception
   	 */
	public boolean updateDitbCrdDsuseRsutChk(CrdDsuseVO vo) {
		boolean result = true;
		int resultDitbTb = update("crdDsuseDAO.updateDitbCrdDsuseRsutImCrdDitbTb", vo);
		
		int resultIsuTb = update("crdDsuseDAO.updateDitbCrdDsuseRsutImCrdIsuTb", vo);
		
		if(1 == resultDitbTb && 1 == resultIsuTb){
			result = false;
		}
		return result;
    }
	
	
    /**
   	 * DAO-method for processing of card disuse in rm_fond_crd_tb table <br>
   	 *
   	 * @param vo Input item for processing of card Issuance error(CrdDsuseVO).
   	 * @return update result
   	 * @exception Exception
   	 */
	public int updateFondCrdDsuseRsutChk(CrdDsuseVO vo) {
		int result = update("crdDsuseDAO.updateFondCrdDsuseRsut", vo);
		
		return result;
    }
	
    /**
   	 * DAO-method for processing of card disuse in rm_dcrd_tb table <br>
   	 *
   	 * @param vo Input item for processing of card Issuance error(CrdDsuseVO).
   	 * @return update result
   	 * @exception Exception
   	 */
	public int updateDsuseRsut(CrdDsuseVO vo) {
		int result = update("crdDsuseDAO.updateDsuseRsut", vo);
		
		return result;
    }
	
	/**
	 * DAO-method for retrieving card issue information. <br>
	 *
	 * @param vo Input item for retrieving card issuing information(CrdFndVO).
	 * @return CrdFndVO Retrieve information of program
	 * @exception Exception
	 */
    public CrdDsuseVO selectCrdIsuceInfr(String rsdtNo) {

    	return (CrdDsuseVO)selectByPk("crdDsuseDAO.selectCrdIsuceInfr", rsdtNo);
    }
	
    /**
	 * DAO-method for Change from PERSIAN date to GREGORIAN date. <br>
	 *
	 * @param cmsDate Input item for Change from PERSIAN date to GREGORIAN date.(string).
	 * @return String GREGORIAN date.
	 * @exception Exception
	 */
	public String selectDataChngToGre(String cmsDate) throws Exception{
		
		return (String)selectByPk("crdDsuseDAO.selectDataChngToGre", cmsDate);		
	}
	
}
