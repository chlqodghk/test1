package afnid.rm.rsdt.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;


/** 
 * This service interface is biz-class of common. <br>
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2013.01.04  		BH Choi				Create
 *
 * </pre>
 */
public interface RsdtInfrService {

	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<RsdtInfrVO> searchListRsdtInfr(RsdtInfrVO vo) throws Exception;

	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(RsdtInfrVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListRsdtInfrTotCn(RsdtInfrVO vo) throws Exception;
	
	

	
	 
	 //KIM ADD
	/**	 
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return RsdtInfrVO object of program
	 * @exception Exception
	 */
    RsdtInfrVO searchRsdtInfrView(RsdtInfrVO vo) throws Exception;

    
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<RsdtInfrVO> searchListOthrNatLangInfr(RsdtInfrVO vo) throws Exception;

	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<RsdtInfrVO> searchListFrgnLangInfr(RsdtInfrVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<RsdtInfrVO> searchListOthrNatLangInfrForRcpt(RsdtInfrVO vo) throws Exception;

	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<RsdtInfrVO> searchListFrgnLangInfrForRcpt(RsdtInfrVO vo) throws Exception;

	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<RsdtInfrVO> searchListSpus(RsdtInfrVO vo) throws Exception;
	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(RsdtInfrVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	String searchRsdtInfrDvrcInfr(RsdtInfrVO vo) throws Exception;
	
	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(RsdtInfrVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	String searchRsdtInfrMrrgInfrTarget(RsdtInfrVO vo) throws Exception;
	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(RsdtInfrVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	EgovMap searchRsdtInfrDat(String rsdtSeqNo) throws Exception;
	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(EgovMap)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	String searchRsdtInfrHashDat(EgovMap em, String bsnCd) throws Exception;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * Retrieves update of program. <br>
	 * @param vo Input item for retrieving of program.(RsdtInfrVO)
	 * @return int update of Program
	 * @exception Exception
	 */
	int modifyRsdtInfr(RsdtInfrVO vo) throws Exception;
	
	
	/**
	 * Retrieves Verification of program. <br>
	 * @param vo Input item for retrieving total count list of program.(RsdtInfrVO)
	 * @return EgovMap
	 * @exception Exception
	 */
	EgovMap modifyAprv(RsdtInfrVO vo) throws Exception;
	
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<RsdtInfrVO> searchListRsdtRgstAprvInfr(RsdtInfrVO vo) throws Exception;

	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(RsdtInfrVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListRsdtRgstAprvInfrTotCn(RsdtInfrVO vo) throws Exception;
	
	
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	RsdtInfrVO searchRsdtInfrPer(RsdtInfrVO vo) throws Exception;
	

	
	/**
	 * Retrieves list of program <br>
	 * @param vo Input item for retrieving total count list of program.(RsdtInfrVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	String searchRsdtBioRgstStus(RsdtInfrVO vo) throws Exception;
	
	
	/**
	 * Check Date of Birth of program. <br>
	 * @param vo Input item for retrieving total count list of program.(RsdtInfrVO)
	 * @return String object of Program
	 * @exception Exception
	 */
	String searchRsdtBthCheck(RsdtInfrVO vo) throws Exception;
	
	
	

	
	
	
	
	
	
	/**
	 * Date Conversion of program. <br>
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return String object of Program
	 * @exception Exception
	 */
	String searchDateConvert(RsdtInfrVO vo) throws Exception;
	
	
	/**	 
	 * Retrieves of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return RsdtInfrVO object of program
	 * @exception Exception
	 */
    RsdtInfrVO searchRsdtInfrRcpt(RsdtInfrVO vo) throws Exception;
    
    
    /**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchListPoliCntrCd(RsdtInfrVO vo) throws Exception;
	
	
	
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchListRsdtInfrPop(RsdtInfrVO vo) throws Exception;

	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(RsdtInfrVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListRsdtInfrPopTotCn(RsdtInfrVO vo) throws Exception;

	/**
	 * Biz-method for Check whether the card replacement application. <br>
	 *
	 * @param String, String, String
	 * @return String
	 * @exception Exception
	 */
	String searchRsdtCrdIsuAppStus(String rsdtNo, String tye, String str) throws Exception;
	
	/**
	 * Biz-method for Check card issuing status. <br>
	 *
	 * @param String
	 * @return int
	 * @exception Exception
	 */
	int searchRsdtCrdIsuStus(String rsdtNo) throws Exception;
	
	/**
	 * Biz-method for Check Citizen Revocation Status. <br>
	 *
	 * @param String, String
	 * @return String
	 * @exception Exception
	 */
	String searchRsdtRvctgStus(String rsdtNo , String tye) throws Exception; 
	
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	int searchListSpusApp(RsdtInfrVO vo) throws Exception;
	
	
    /**
	 * Retrieves  Citizen's detail information. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return RsdtInfrVO object of Citizen's detail information
	 * @exception Exception
	 */
	public RsdtInfrVO searchRsdtInfrDtlView(RsdtInfrVO vo) throws Exception ;
	
	/**
	 * Retrieves information of bio registration <br>
	 * @param vo Input item for retrieving information of bio registration
	 * @return RsdtInfrVO 
	 * @exception Exception
	 */
	public RsdtInfrVO searchRsdtBioRgstDtlStus(String bioKey) throws Exception;	
	
	
	
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchListFmlyInfrPop(RsdtInfrVO vo) throws Exception;
	
	/**
	 * Retrieves information of bio registration <br>
	 * @param vo Input item for retrieving information of bio registration
	 * @return RsdtInfrVO 
	 * @exception Exception
	 */
	public String getXmlData(String xml, String tag) throws Exception;	
	
	/**
   	 * Update Digital Signature. <br>
   	 *
   	 * @param String, String
   	 * @return void
   	 * @exception Exception
   	 */
   	public void updateDigitalSgnt(String rsdtSeqNo, String sgnt, String bsnCd) throws Exception;
   	
   	/**
   	 * Retrieves count of program. <br>
   	 *
   	 * @param String
   	 * @return int
   	 * @exception Exception
   	 */
   	public int searchPkiCrtIsuceCn(String rsdtSeqNo) throws Exception;
	
   	
	/**
	 * Retrieves list of Family Members. <br>
	 *
	 * @param vo Input item for retrieving list of Family Members(RsdtInfrVO).
	 * @return List Retrieve list of Family Members
	 * @exception Exception
	 */
	List<RsdtInfrVO> searchListFmlyMber(RsdtInfrVO vo) throws Exception;

	/**
	 * Retrieves total count of Family Members. <br>
	 * @param vo Input item for retrieving total count list of Family Members.(RsdtInfrVO)
	 * @return int Total Count of Family Members
	 * @exception Exception
	 */
	int searchListFmlyMberTotCn(RsdtInfrVO vo) throws Exception;  
	
	/**
	 * Retrieves Age Gap. <br>
	 *
	 * @param vo Input item for retrieving Age Gap(String).
	 * @return  RsdtInfrVO
	 * @exception Exception
	 */
	RsdtInfrVO searchAgGap(RsdtInfrVO vo) throws Exception;	
	
	/**
	 * Retrieves age gap <br>
	 * @param vo Input item for retrieving age gap
	 * @return String 
	 * @exception Exception
	 */
	public String searchChkAgGap(RsdtInfrVO vog) throws Exception;	
	
	/**
	 * Retrieves validation of relationship <br>
	 * @param vo Input item for retrieving validation of relationship
	 * @return String 
	 * @exception Exception
	 */
	public String searchChkRl(RsdtInfrVO vog) throws Exception;	
	
	/**
	 * Retrieves validation of relationship and citizen sequence number.<br>
	 * @param vo Input item for retrieving validation of relationship and citizen sequence number.
	 * @return String 
	 * @exception Exception
	 */
	RsdtInfrVO searchNmLink(RsdtInfrVO vo) throws Exception;
	
	/**
	 * Retrieves validation of retrieving member mapped  with me<br>
	 * @param vo Input item for retrieving member mapped  with me.
	 * @return RsdtInfrVO 
	 * @exception Exception
	 */
	List<RsdtInfrVO> searchListRlForMe(RsdtInfrVO vo) throws Exception;	
	
	/**
	 * Retrieves change Member.<br>
	 * @param vo Input item for retrieving change number.
	 * @return String 
	 * @exception Exception
	 */
	RsdtInfrVO searchChngMber(RsdtInfrVO vo) throws Exception;	
	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(RsdtInfrVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	String searchGetCtznRgstYn(RsdtInfrVO vo) throws Exception;
}
