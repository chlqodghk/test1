package afnid.rm.rsdt.service;

import afnid.cm.ComDefaultVO;

public class RsdtMdfcVO extends ComDefaultVO {
	private String othrRl;
	private String afOthrRl;
	private String spousCnt;
	private String mrrgDvrcCnt;
	private String afOldCrdIsucePlceCd;
	private String oldCrdIsucePlceCd;
	private String curtAdDiv;
	private String curtAdNatCd;
	private String curtAdNatCdNm;
	private String oldCrdNo4;
	private String fthrOldCrdNo4;
	private String mthrOldCrdNo4;
	private String gfthrOldCrdNo4;
	private String spusOldCrdNo4;
	private String emlAd;
	private String eduYn;
	private String secdNltyYn; 
	private String afCurtAdDiv;
	private String afCurtAdNatCd;
	private String afOldCrdNo4;
	private String afFthrRgstTye;
	private String afMthrRgstTye;
	private String afGfthrRgstTye;
	private String afSpusRgstTye;
	private String afFthrOldCrdNo1;
	private String afFthrOldCrdNo2;
	private String afFthrOldCrdNo3;
	private String afFthrOldCrdNo4;
	private String afMthrOldCrdNo1;
	private String afMthrOldCrdNo2;
	private String afMthrOldCrdNo3;
	private String afMthrOldCrdNo4;
	private String afGfthrOldCrdNo1;
	private String afGfthrOldCrdNo2;
	private String afGfthrOldCrdNo3;
	private String afGfthrOldCrdNo4;
	private String afSpusOldCrdNo1;
	private String afSpusOldCrdNo2;
	private String afSpusOldCrdNo3;
	private String afSpusOldCrdNo4;
	private String afEduYn;
	private String afSecdNltyYn;
	private String oldCrdIsuceDd;
	private String afOldCrdIsuceDd;

	private String adultAge;
	private String cardisuFlag;
	private String hsbdRsdtSeqNo;
	private String wifeRsdtSeqNo;
	private String afMthrRsdtSeqNo;
	
	private static final long serialVersionUID = 1L;
	
	private String crdDitbSeqNo;
	private String crdReisuceYn;
	private String afPoliCntrSeqNoNm;
	private String afPoliCntrSeqNo;
	private String oldCrdIsucePlceNm;
	private String afOldCrdIsucePlceNm;
	private String poliCntrSeqNo;
	
	private String rlCdNm;
	private String eduCdNm;
	
	private String oldAge;
	
	private String rsdtTyeCd;
	private String rsdtTyeCdNm;
	private String afRsdtTyeCd;
	
	private String tamCd;
	private String dateOfApproval;
	private String udtWrkCd;
	private String sgnt;
	
	private String rsdtSeqNo;
	private String mdfctSeqNo;
	private String fmlyBokNo;
	private String fmlyMberNo;
	private String rsdtNo;
	private String oldCrdNo;
	private String rlCd;
	private String givNm;
	private String enGivNm;
	private String surnm;
	private String fthrGivNm;
	private String gfthrGivNm;
	private String bthDd;
	private String pmntAdCd;
	private String pmntAdDtlCt;
	private String curtAdCd;
	private String curtAdDtlCt;
	private String crdIsuceDd;
	private String crdExpiryDd;
	private String bthNatDiv;
	private String bthPlceCd;
	private String bthNatCd;
	private String frgnBthCtyNm;
	private String bldTyeCd;
	private String mrrgCd;
	private String gdrCd;
	private String encyCd;
	private String fmlyLangCd;
	private String secdNltyCd;
	private String dsbtDtlCt;
	private String smrRsdcCd;
	private String wtrRsdcCd;
	private String rlgnCd;
	private String rlgnSectCd;
	private String ocp;
	private String eduCd;
	private String fmlyMberMlNo;
	private String fmlyMberFemlNo;
	private String mltSrvcCd;
	private String afOldCrdNo;
	private String afRlCd;
	private String afGivNm;
	private String afEnGivNm;
	private String afSurnm;
	private String afFthrGivNm;
	private String afGfthrGivNm;
	private String afBthDd;
	private String afPmntAdCd;
	private String afPmntAdDtlCt;
	private String afCurtAdCd;
	private String afCurtAdDtlCt;
	private String afBthNatDiv;
	private String afBthPlceCd;
	private String afBthNatCd;
	private String afFrgnBthCtyNm;
	private String afBldTyeCd;
	private String afMrrgCd;
	private String afGdrCd;
	private String afEncyCd;
	private String afFmlyLangCd;
	private String afSecdNltyCd;
	private String afDsbtDtlCt;
	private String afSmrRsdcCd;
	private String afWtrRsdcCd;
	private String afRlgnCd;
	private String afRlgnSectCd;
	private String afOcp;
	private String afEduCd;
	private String afAdChng;
	private String afFmlyMberMlNo;
	private String afFmlyMberFemlNo;
	private String afMltSrvcCd;
	private String rgstOrgnzCd;
	private String mdfctDd;
	private String rsnDtlCt;
	private String crdReisuceDd;
	private String tamLedrCfmYn;
	private String crdReisuceDueDd;
	private String cfmTamLedrId;


	private String[] natLangCd;
	private String[] afNatLangCd;
	private String[] frgnLangCd;
	private String[] afFrgnLangCd;
	
	private String afPmntAdCdNm;
	private String afCurtAdCdNm;
	private String afBthPlceCdNm;
	private String afSmrRsdcCdNm;
	private String afWtrRsdcCdNm;
	
	private String calTye;
	private String calTye1;
	private String calTye2;
	
	private String viewType;
	private String viewRsdtNo;
	
	private String descRsdtSeqNo;
	
	private String userId;
	
	private String lstLangCd;
	private String orgnzCd;
	private String numFlag;
	
	private String issueDd;
	private String validDd;
	private String leaderId;
	
	private String bioKey;
	
	
	private String oldCrdIsucePlce;
	private String enNm;
	private String fthrNm;
	private String mthrNm;
	private String gfthrNm;
	private String afOldCrdIsucePlce;
	private String afEnNm;
	private String chngRsnDtlCt;
	private String certNo;
	private String pbctOfic;
	
	private String fthrRsdtSeqNo;
	private String mthrRsdtSeqNo;	
	private String gfthrRsdtSeqNo;
	private String spusRsdtSeqNo;
	private String spusNm;
	private String dsbtCd;
	private String dsbtCdNm;
	private String frngrYn;
	private String afSpusEnSurnm;
	private String spusEnSurnm;
	private String spusEnGivNm;
	private String enSurnm;   
	
	private String afEnSurnm; 	
	private String afFthrNm;
	private String afMthrNm;
	private String afFthrRsdtSeqNo;
	private String afMfthrRsdtSeqNo;
	private String afGfthrNm;
	private String afGfthrRsdtSeqNo;
	private String afSpusNm;
	private String afSpusRsdtSeqNo;
	private String afDsbtCd;
	private String afDsbtCdNm;
	private String afFrngrYn;
	private String afBldTyeDocYn;
	private String afEduLvDocYn;
	
	private String fthrRgstTye;
	private String mthrRgstTye;
	private String gfthrRgstTye;
	private String spusRgstTye;
	private String fthrOldCrdNo;
	private String mthrOldCrdNo;
	private String gfthrOldCrdNo;
	private String spusOldCrdNo;
	private String rsdtCfmYn;
	private String bldTyeDocYn;
	private String eduLvDocYn;
	
	private String bldTyeDocVrfd;
	private String eduLvDocVrfd;
	private String afBldTyeDocVrfd;
	private String afEduLvDocVrfd;
	
	private String prntDd;
	private String rsdtRgstIdNm;
	
	private String crdIsuDueDd;
	private String crdDlvrDd;
	
	private String oldCrdNo1;
	private String oldCrdNo2;
	private String oldCrdNo3;	
    private String fthrOldCrdNo1;
    private String fthrOldCrdNo2;
    private String fthrOldCrdNo3;
    private String mthrOldCrdNo1;
    private String mthrOldCrdNo2;
    private String mthrOldCrdNo3;
    private String gfthrOldCrdNo1;
    private String gfthrOldCrdNo2;
    private String gfthrOldCrdNo3;
    private String spusOldCrdNo1;
    private String spusOldCrdNo2;
    private String spusOldCrdNo3;
    
    private String crdIsuSrlNo;
    private String bsnCd;
    private String bsnSeqNo;
    private String aprvBtnClickYn;
    private String aprvListTm;
    private String cntTelNo;
    private String cntTelNo2;
    
    private String afOldCrdNo1;
    private String afOldCrdNo2;
    private String afOldCrdNo3;
    private String appDd;
    private String fndTye;
    private String rsdtNm;
    
    private String gBthDd;
    private String hBthDd;
    private String gdrCdNm;
    private String rsdtNoDp;
    private String fmlyBokNoNum;
    private String selfRsdtSeqNo;
    
    private String rsdtStusCd;
    private String mrrgSeqNo;
    private String srchCalTye;
    private String srchBthDd;
    private String srchAgGap;
    
    private String afFthrRlCd;
    private String afMthrRlCd;
    private String afGfthrRlCd;
    private String afSpusRlCd;
    
    private String fgmhRsdtSeqNo;
    
	public String getOldCrdNo1() {
		return oldCrdNo1;
	}
	public void setOldCrdNo1(String oldCrdNo1) {
		this.oldCrdNo1 = oldCrdNo1;
	}
	public String getOldCrdNo2() {
		return oldCrdNo2;
	}
	public void setOldCrdNo2(String oldCrdNo2) {
		this.oldCrdNo2 = oldCrdNo2;
	}
	public String getOldCrdNo3() {
		return oldCrdNo3;
	}
	public void setOldCrdNo3(String oldCrdNo3) {
		this.oldCrdNo3 = oldCrdNo3;
	}
	public String getFthrOldCrdNo1() {
		return fthrOldCrdNo1;
	}
	public void setFthrOldCrdNo1(String fthrOldCrdNo1) {
		this.fthrOldCrdNo1 = fthrOldCrdNo1;
	}
	public String getFthrOldCrdNo2() {
		return fthrOldCrdNo2;
	}
	public void setFthrOldCrdNo2(String fthrOldCrdNo2) {
		this.fthrOldCrdNo2 = fthrOldCrdNo2;
	}
	public String getFthrOldCrdNo3() {
		return fthrOldCrdNo3;
	}
	public void setFthrOldCrdNo3(String fthrOldCrdNo3) {
		this.fthrOldCrdNo3 = fthrOldCrdNo3;
	}
	public String getMthrOldCrdNo1() {
		return mthrOldCrdNo1;
	}
	public void setMthrOldCrdNo1(String mthrOldCrdNo1) {
		this.mthrOldCrdNo1 = mthrOldCrdNo1;
	}
	public String getMthrOldCrdNo2() {
		return mthrOldCrdNo2;
	}
	public void setMthrOldCrdNo2(String mthrOldCrdNo2) {
		this.mthrOldCrdNo2 = mthrOldCrdNo2;
	}
	public String getMthrOldCrdNo3() {
		return mthrOldCrdNo3;
	}
	public void setMthrOldCrdNo3(String mthrOldCrdNo3) {
		this.mthrOldCrdNo3 = mthrOldCrdNo3;
	}
	public String getGfthrOldCrdNo1() {
		return gfthrOldCrdNo1;
	}
	public void setGfthrOldCrdNo1(String gfthrOldCrdNo1) {
		this.gfthrOldCrdNo1 = gfthrOldCrdNo1;
	}
	public String getGfthrOldCrdNo2() {
		return gfthrOldCrdNo2;
	}
	public void setGfthrOldCrdNo2(String gfthrOldCrdNo2) {
		this.gfthrOldCrdNo2 = gfthrOldCrdNo2;
	}
	public String getGfthrOldCrdNo3() {
		return gfthrOldCrdNo3;
	}
	public void setGfthrOldCrdNo3(String gfthrOldCrdNo3) {
		this.gfthrOldCrdNo3 = gfthrOldCrdNo3;
	}
	public String getSpusOldCrdNo1() {
		return spusOldCrdNo1;
	}
	public void setSpusOldCrdNo1(String spusOldCrdNo1) {
		this.spusOldCrdNo1 = spusOldCrdNo1;
	}
	public String getSpusOldCrdNo2() {
		return spusOldCrdNo2;
	}
	public void setSpusOldCrdNo2(String spusOldCrdNo2) {
		this.spusOldCrdNo2 = spusOldCrdNo2;
	}
	public String getSpusOldCrdNo3() {
		return spusOldCrdNo3;
	}
	public void setSpusOldCrdNo3(String spusOldCrdNo3) {
		this.spusOldCrdNo3 = spusOldCrdNo3;
	}
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getMdfctSeqNo() {
		return mdfctSeqNo;
	}
	public void setMdfctSeqNo(String mdfctSeqNo) {
		this.mdfctSeqNo = mdfctSeqNo;
	}
	public String getFmlyBokNo() {
		return fmlyBokNo;
	}
	public void setFmlyBokNo(String fmlyBokNo) {
		this.fmlyBokNo = fmlyBokNo;
	}
	public String getFmlyMberNo() {
		return fmlyMberNo;
	}
	public void setFmlyMberNo(String fmlyMberNo) {
		this.fmlyMberNo = fmlyMberNo;
	}
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getOldCrdNo() {
		return oldCrdNo;
	}
	public void setOldCrdNo(String oldCrdNo) {
		this.oldCrdNo = oldCrdNo;
	}
	public String getRlCd() {
		return rlCd;
	}
	public void setRlCd(String rlCd) {
		this.rlCd = rlCd;
	}
	public String getGivNm() {
		return givNm;
	}
	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}
	public String getEnGivNm() {
		return enGivNm;
	}
	public void setEnGivNm(String enGivNm) {
		this.enGivNm = enGivNm;
	}
	public String getSurnm() {
		return surnm;
	}
	public void setSurnm(String surnm) {
		this.surnm = surnm;
	}
	public String getFthrGivNm() {
		return fthrGivNm;
	}
	public void setFthrGivNm(String fthrGivNm) {
		this.fthrGivNm = fthrGivNm;
	}
	public String getGfthrGivNm() {
		return gfthrGivNm;
	}
	public void setGfthrGivNm(String gfthrGivNm) {
		this.gfthrGivNm = gfthrGivNm;
	}
	public String getBthDd() {
		return bthDd;
	}
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	public String getPmntAdCd() {
		return pmntAdCd;
	}
	public void setPmntAdCd(String pmntAdCd) {
		this.pmntAdCd = pmntAdCd;
	}
	public String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}
	public void setPmntAdDtlCt(String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}
	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}
	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}
	public String getBthNatDiv() {
		return bthNatDiv;
	}
	public void setBthNatDiv(String bthNatDiv) {
		this.bthNatDiv = bthNatDiv;
	}
	public String getBthPlceCd() {
		return bthPlceCd;
	}
	public void setBthPlceCd(String bthPlceCd) {
		this.bthPlceCd = bthPlceCd;
	}
	public String getBthNatCd() {
		return bthNatCd;
	}
	public void setBthNatCd(String bthNatCd) {
		this.bthNatCd = bthNatCd;
	}
	public String getFrgnBthCtyNm() {
		return frgnBthCtyNm;
	}
	public void setFrgnBthCtyNm(String frgnBthCtyNm) {
		this.frgnBthCtyNm = frgnBthCtyNm;
	}
	public String getBldTyeCd() {
		return bldTyeCd;
	}
	public void setBldTyeCd(String bldTyeCd) {
		this.bldTyeCd = bldTyeCd;
	}
	public String getMrrgCd() {
		return mrrgCd;
	}
	public void setMrrgCd(String mrrgCd) {
		this.mrrgCd = mrrgCd;
	}
	public String getGdrCd() {
		return gdrCd;
	}
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	public String getEncyCd() {
		return encyCd;
	}
	public void setEncyCd(String encyCd) {
		this.encyCd = encyCd;
	}
	public String getFmlyLangCd() {
		return fmlyLangCd;
	}
	public void setFmlyLangCd(String fmlyLangCd) {
		this.fmlyLangCd = fmlyLangCd;
	}
	public String getSecdNltyCd() {
		return secdNltyCd;
	}
	public void setSecdNltyCd(String secdNltyCd) {
		this.secdNltyCd = secdNltyCd;
	}
	public String getDsbtDtlCt() {
		return dsbtDtlCt;
	}
	public void setDsbtDtlCt(String dsbtDtlCt) {
		this.dsbtDtlCt = dsbtDtlCt;
	}
	public String getSmrRsdcCd() {
		return smrRsdcCd;
	}
	public void setSmrRsdcCd(String smrRsdcCd) {
		this.smrRsdcCd = smrRsdcCd;
	}
	public String getWtrRsdcCd() {
		return wtrRsdcCd;
	}
	public void setWtrRsdcCd(String wtrRsdcCd) {
		this.wtrRsdcCd = wtrRsdcCd;
	}
	public String getRlgnCd() {
		return rlgnCd;
	}
	public void setRlgnCd(String rlgnCd) {
		this.rlgnCd = rlgnCd;
	}
	public String getRlgnSectCd() {
		return rlgnSectCd;
	}
	public void setRlgnSectCd(String rlgnSectCd) {
		this.rlgnSectCd = rlgnSectCd;
	}
	public String getOcp() {
		return ocp;
	}
	public void setOcp(String ocp) {
		this.ocp = ocp;
	}
	public String getEduCd() {
		return eduCd;
	}
	public void setEduCd(String eduCd) {
		this.eduCd = eduCd;
	}
	public String getFmlyMberMlNo() {
		return fmlyMberMlNo;
	}
	public void setFmlyMberMlNo(String fmlyMberMlNo) {
		this.fmlyMberMlNo = fmlyMberMlNo;
	}
	public String getFmlyMberFemlNo() {
		return fmlyMberFemlNo;
	}
	public void setFmlyMberFemlNo(String fmlyMberFemlNo) {
		this.fmlyMberFemlNo = fmlyMberFemlNo;
	}
	public String getMltSrvcCd() {
		return mltSrvcCd;
	}
	public void setMltSrvcCd(String mltSrvcCd) {
		this.mltSrvcCd = mltSrvcCd;
	}
	public String getAfOldCrdNo() {
		return afOldCrdNo;
	}
	public void setAfOldCrdNo(String afOldCrdNo) {
		this.afOldCrdNo = afOldCrdNo;
	}
	public String getAfRlCd() {
		return afRlCd;
	}
	public void setAfRlCd(String afRlCd) {
		this.afRlCd = afRlCd;
	}
	public String getAfGivNm() {
		return afGivNm;
	}
	public void setAfGivNm(String afGivNm) {
		this.afGivNm = afGivNm;
	}
	public String getAfEnGivNm() {
		return afEnGivNm;
	}
	public void setAfEnGivNm(String afEnGivNm) {
		this.afEnGivNm = afEnGivNm;
	}
	public String getAfSurnm() {
		return afSurnm;
	}
	public void setAfSurnm(String afSurnm) {
		this.afSurnm = afSurnm;
	}
	public String getAfFthrGivNm() {
		return afFthrGivNm;
	}
	public void setAfFthrGivNm(String afFthrGivNm) {
		this.afFthrGivNm = afFthrGivNm;
	}
	public String getAfGfthrGivNm() {
		return afGfthrGivNm;
	}
	public void setAfGfthrGivNm(String afGfthrGivNm) {
		this.afGfthrGivNm = afGfthrGivNm;
	}
	public String getAfBthDd() {
		return afBthDd;
	}
	public void setAfBthDd(String afBthDd) {
		this.afBthDd = afBthDd;
	}
	public String getAfPmntAdCd() {
		return afPmntAdCd;
	}
	public void setAfPmntAdCd(String afPmntAdCd) {
		this.afPmntAdCd = afPmntAdCd;
	}
	public String getAfPmntAdDtlCt() {
		return afPmntAdDtlCt;
	}
	public void setAfPmntAdDtlCt(String afPmntAdDtlCt) {
		this.afPmntAdDtlCt = afPmntAdDtlCt;
	}
	public String getAfCurtAdCd() {
		return afCurtAdCd;
	}
	public void setAfCurtAdCd(String afCurtAdCd) {
		this.afCurtAdCd = afCurtAdCd;
	}
	public String getAfCurtAdDtlCt() {
		return afCurtAdDtlCt;
	}
	public void setAfCurtAdDtlCt(String afCurtAdDtlCt) {
		this.afCurtAdDtlCt = afCurtAdDtlCt;
	}
	public String getAfBthNatDiv() {
		return afBthNatDiv;
	}
	public void setAfBthNatDiv(String afBthNatDiv) {
		this.afBthNatDiv = afBthNatDiv;
	}
	public String getAfBthPlceCd() {
		return afBthPlceCd;
	}
	public void setAfBthPlceCd(String afBthPlceCd) {
		this.afBthPlceCd = afBthPlceCd;
	}
	public String getAfBthNatCd() {
		return afBthNatCd;
	}
	public void setAfBthNatCd(String afBthNatCd) {
		this.afBthNatCd = afBthNatCd;
	}
	public String getAfFrgnBthCtyNm() {
		return afFrgnBthCtyNm;
	}
	public void setAfFrgnBthCtyNm(String afFrgnBthCtyNm) {
		this.afFrgnBthCtyNm = afFrgnBthCtyNm;
	}
	public String getAfBldTyeCd() {
		return afBldTyeCd;
	}
	public void setAfBldTyeCd(String afBldTyeCd) {
		this.afBldTyeCd = afBldTyeCd;
	}
	public String getAfMrrgCd() {
		return afMrrgCd;
	}
	public void setAfMrrgCd(String afMrrgCd) {
		this.afMrrgCd = afMrrgCd;
	}
	public String getAfGdrCd() {
		return afGdrCd;
	}
	public void setAfGdrCd(String afGdrCd) {
		this.afGdrCd = afGdrCd;
	}
	public String getAfEncyCd() {
		return afEncyCd;
	}
	public void setAfEncyCd(String afEncyCd) {
		this.afEncyCd = afEncyCd;
	}
	public String getAfFmlyLangCd() {
		return afFmlyLangCd;
	}
	public void setAfFmlyLangCd(String afFmlyLangCd) {
		this.afFmlyLangCd = afFmlyLangCd;
	}
	public String getAfSecdNltyCd() {
		return afSecdNltyCd;
	}
	public void setAfSecdNltyCd(String afSecdNltyCd) {
		this.afSecdNltyCd = afSecdNltyCd;
	}
	public String getAfDsbtDtlCt() {
		return afDsbtDtlCt;
	}
	public void setAfDsbtDtlCt(String afDsbtDtlCt) {
		this.afDsbtDtlCt = afDsbtDtlCt;
	}
	public String getAfSmrRsdcCd() {
		return afSmrRsdcCd;
	}
	public void setAfSmrRsdcCd(String afSmrRsdcCd) {
		this.afSmrRsdcCd = afSmrRsdcCd;
	}
	public String getAfWtrRsdcCd() {
		return afWtrRsdcCd;
	}
	public void setAfWtrRsdcCd(String afWtrRsdcCd) {
		this.afWtrRsdcCd = afWtrRsdcCd;
	}
	public String getAfRlgnCd() {
		return afRlgnCd;
	}
	public void setAfRlgnCd(String afRlgnCd) {
		this.afRlgnCd = afRlgnCd;
	}
	public String getAfRlgnSectCd() {
		return afRlgnSectCd;
	}
	public void setAfRlgnSectCd(String afRlgnSectCd) {
		this.afRlgnSectCd = afRlgnSectCd;
	}
	public String getAfOcp() {
		return afOcp;
	}
	public void setAfOcp(String afOcp) {
		this.afOcp = afOcp;
	}
	public String getAfEduCd() {
		return afEduCd;
	}
	public void setAfEduCd(String afEduCd) {
		this.afEduCd = afEduCd;
	}
	public String getAfAdChng() {
		return afAdChng;
	}
	public void setAfAdChng(String afAdChng) {
		this.afAdChng = afAdChng;
	}
	public String getAfFmlyMberMlNo() {
		return afFmlyMberMlNo;
	}
	public void setAfFmlyMberMlNo(String afFmlyMberMlNo) {
		this.afFmlyMberMlNo = afFmlyMberMlNo;
	}
	public String getAfFmlyMberFemlNo() {
		return afFmlyMberFemlNo;
	}
	public void setAfFmlyMberFemlNo(String afFmlyMberFemlNo) {
		this.afFmlyMberFemlNo = afFmlyMberFemlNo;
	}
	public String getAfMltSrvcCd() {
		return afMltSrvcCd;
	}
	public void setAfMltSrvcCd(String afMltSrvcCd) {
		this.afMltSrvcCd = afMltSrvcCd;
	}
	public String getRgstOrgnzCd() {
		return rgstOrgnzCd;
	}
	public void setRgstOrgnzCd(String rgstOrgnzCd) {
		this.rgstOrgnzCd = rgstOrgnzCd;
	}
	public String getMdfctDd() {
		return mdfctDd;
	}
	public void setMdfctDd(String mdfctDd) {
		this.mdfctDd = mdfctDd;
	}
	public String getRsnDtlCt() {
		return rsnDtlCt;
	}
	public void setRsnDtlCt(String rsnDtlCt) {
		this.rsnDtlCt = rsnDtlCt;
	}
	public String getCrdReisuceDd() {
		return crdReisuceDd;
	}
	public void setCrdReisuceDd(String crdReisuceDd) {
		this.crdReisuceDd = crdReisuceDd;
	}
	public String getTamLedrCfmYn() {
		return tamLedrCfmYn;
	}
	public void setTamLedrCfmYn(String tamLedrCfmYn) {
		this.tamLedrCfmYn = tamLedrCfmYn;
	}
	public String getCrdReisuceDueDd() {
		return crdReisuceDueDd;
	}
	public void setCrdReisuceDueDd(String crdReisuceDueDd) {
		this.crdReisuceDueDd = crdReisuceDueDd;
	}
	public String getCfmTamLedrId() {
		return cfmTamLedrId;
	}
	public void setCfmTamLedrId(String cfmTamLedrId) {
		this.cfmTamLedrId = cfmTamLedrId;
	}
	public String[] getNatLangCd() {
		return natLangCd;
	}
	public void setNatLangCd(String[] natLangCd) {
		this.natLangCd = natLangCd;
	}
	public String[] getAfNatLangCd() {
		return afNatLangCd;
	}
	public void setAfNatLangCd(String[] afNatLangCd) {
		this.afNatLangCd = afNatLangCd;
	}
	public String[] getFrgnLangCd() {
		return frgnLangCd;
	}
	public void setFrgnLangCd(String[] frgnLangCd) {
		this.frgnLangCd = frgnLangCd;
	}
	public String[] getAfFrgnLangCd() {
		return afFrgnLangCd;
	}
	public void setAfFrgnLangCd(String[] afFrgnLangCd) {
		this.afFrgnLangCd = afFrgnLangCd;
	}
	public String getViewType() {
		return viewType;
	}
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}
	public String getViewRsdtNo() {
		return viewRsdtNo;
	}
	public void setViewRsdtNo(String viewRsdtNo) {
		this.viewRsdtNo = viewRsdtNo;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getAfPmntAdCdNm() {
		return afPmntAdCdNm;
	}
	public void setAfPmntAdCdNm(String afPmntAdCdNm) {
		this.afPmntAdCdNm = afPmntAdCdNm;
	}
	public String getAfCurtAdCdNm() {
		return afCurtAdCdNm;
	}
	public void setAfCurtAdCdNm(String afCurtAdCdNm) {
		this.afCurtAdCdNm = afCurtAdCdNm;
	}
	public String getAfBthPlceCdNm() {
		return afBthPlceCdNm;
	}
	public void setAfBthPlceCdNm(String afBthPlceCdNm) {
		this.afBthPlceCdNm = afBthPlceCdNm;
	}
	public String getAfSmrRsdcCdNm() {
		return afSmrRsdcCdNm;
	}
	public void setAfSmrRsdcCdNm(String afSmrRsdcCdNm) {
		this.afSmrRsdcCdNm = afSmrRsdcCdNm;
	}
	public String getAfWtrRsdcCdNm() {
		return afWtrRsdcCdNm;
	}
	public void setAfWtrRsdcCdNm(String afWtrRsdcCdNm) {
		this.afWtrRsdcCdNm = afWtrRsdcCdNm;
	}
	public String getCalTye() {
		return calTye;
	}
	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}
	public String getDescRsdtSeqNo() {
		return descRsdtSeqNo;
	}
	public void setDescRsdtSeqNo(String descRsdtSeqNo) {
		this.descRsdtSeqNo = descRsdtSeqNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getLstLangCd() {
		return lstLangCd;
	}
	public void setLstLangCd(String lstLangCd) {
		this.lstLangCd = lstLangCd;
	}
	public String getCalTye1() {
		return calTye1;
	}
	public void setCalTye1(String calTye1) {
		this.calTye1 = calTye1;
	}
	public String getCalTye2() {
		return calTye2;
	}
	public void setCalTye2(String calTye2) {
		this.calTye2 = calTye2;
	}
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String getNumFlag() {
		return numFlag;
	}
	public void setNumFlag(String numFlag) {
		this.numFlag = numFlag;
	}
	public String getIssueDd() {
		return issueDd;
	}
	public void setIssueDd(String issueDd) {
		this.issueDd = issueDd;
	}
	public String getValidDd() {
		return validDd;
	}
	public void setValidDd(String validDd) {
		this.validDd = validDd;
	}
	public String getLeaderId() {
		return leaderId;
	}
	public void setLeaderId(String leaderId) {
		this.leaderId = leaderId;
	}
	public String getBioKey() {
		return bioKey;
	}
	public void setBioKey(String bioKey) {
		this.bioKey = bioKey;
	}
	public String getAfPoliCntrSeqNoNm() {
		return afPoliCntrSeqNoNm;
	}
	public void setAfPoliCntrSeqNoNm(String afPoliCntrSeqNoNm) {
		this.afPoliCntrSeqNoNm = afPoliCntrSeqNoNm;
	}
	public String getAfPoliCntrSeqNo() {
		return afPoliCntrSeqNo;
	}
	public void setAfPoliCntrSeqNo(String afPoliCntrSeqNo) {
		this.afPoliCntrSeqNo = afPoliCntrSeqNo;
	}
	public String getOldCrdIsucePlceNm() {
		return oldCrdIsucePlceNm;
	}
	public void setOldCrdIsucePlceNm(String oldCrdIsucePlceNm) {
		this.oldCrdIsucePlceNm = oldCrdIsucePlceNm;
	}
	public String getAfOldCrdIsucePlceNm() {
		return afOldCrdIsucePlceNm;
	}
	public void setAfOldCrdIsucePlceNm(String afOldCrdIsucePlceNm) {
		this.afOldCrdIsucePlceNm = afOldCrdIsucePlceNm;
	}
	public String getPoliCntrSeqNo() {
		return poliCntrSeqNo;
	}
	public void setPoliCntrSeqNo(String poliCntrSeqNo) {
		this.poliCntrSeqNo = poliCntrSeqNo;
	}
	public String getRsdtTyeCd() {
		return rsdtTyeCd;
	}
	public void setRsdtTyeCd(String rsdtTyeCd) {
		this.rsdtTyeCd = rsdtTyeCd;
	}
	public String getRsdtTyeCdNm() {
		return rsdtTyeCdNm;
	}
	public void setRsdtTyeCdNm(String rsdtTyeCdNm) {
		this.rsdtTyeCdNm = rsdtTyeCdNm;
	}
	public String getAfRsdtTyeCd() {
		return afRsdtTyeCd;
	}
	public void setAfRsdtTyeCd(String afRsdtTyeCd) {
		this.afRsdtTyeCd = afRsdtTyeCd;
	}
	public String getRlCdNm() {
		return rlCdNm;
	}
	public void setRlCdNm(String rlCdNm) {
		this.rlCdNm = rlCdNm;
	}
	public String getEduCdNm() {
		return eduCdNm;
	}
	public void setEduCdNm(String eduCdNm) {
		this.eduCdNm = eduCdNm;
	}
	public String getOldAge() {
		return oldAge;
	}
	public void setOldAge(String oldAge) {
		this.oldAge = oldAge;
	}
	public String getOldCrdIsucePlce() {
		return oldCrdIsucePlce;
	}
	public void setOldCrdIsucePlce(String oldCrdIsucePlce) {
		this.oldCrdIsucePlce = oldCrdIsucePlce;
	}
	public String getEnNm() {
		return enNm;
	}
	public void setEnNm(String enNm) {
		this.enNm = enNm;
	}
	public String getFthrNm() {
		return fthrNm;
	}
	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}
	public String getMthrNm() {
		return mthrNm;
	}
	public void setMthrNm(String mthrNm) {
		this.mthrNm = mthrNm;
	}
	public String getGfthrNm() {
		return gfthrNm;
	}
	public void setGfthrNm(String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}
	public String getAfOldCrdIsucePlce() {
		return afOldCrdIsucePlce;
	}
	public void setAfOldCrdIsucePlce(String afOldCrdIsucePlce) {
		this.afOldCrdIsucePlce = afOldCrdIsucePlce;
	}
	public String getAfEnNm() {
		return afEnNm;
	}
	public void setAfEnNm(String afEnNm) {
		this.afEnNm = afEnNm;
	}
	public String getChngRsnDtlCt() {
		return chngRsnDtlCt;
	}
	public void setChngRsnDtlCt(String chngRsnDtlCt) {
		this.chngRsnDtlCt = chngRsnDtlCt;
	}
	public String getCertNo() {
		return certNo;
	}
	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}
	public String getPbctOfic() {
		return pbctOfic;
	}
	public void setPbctOfic(String pbctOfic) {
		this.pbctOfic = pbctOfic;
	}
	public String getTamCd() {
		return tamCd;
	}
	public void setTamCd(String tamCd) {
		this.tamCd = tamCd;
	}
	public String getDateOfApproval() {
		return dateOfApproval;
	}
	public void setDateOfApproval(String dateOfApproval) {
		this.dateOfApproval = dateOfApproval;
	}
	public String getUdtWrkCd() {
		return udtWrkCd;
	}
	public void setUdtWrkCd(String udtWrkCd) {
		this.udtWrkCd = udtWrkCd;
	}
	public String getSgnt() {
		return sgnt;
	}
	public void setSgnt(String sgnt) {
		this.sgnt = sgnt;
	}
	public String getCrdReisuceYn() {
		return crdReisuceYn;
	}
	public void setCrdReisuceYn(String crdReisuceYn) {
		this.crdReisuceYn = crdReisuceYn;
	}
	public String getCrdDitbSeqNo() {
		return crdDitbSeqNo;
	}
	public void setCrdDitbSeqNo(String crdDitbSeqNo) {
		this.crdDitbSeqNo = crdDitbSeqNo;
	}
	public String getGfthrRsdtSeqNo() {
		return gfthrRsdtSeqNo;
	}
	public void setGfthrRsdtSeqNo(String gfthrRsdtSeqNo) {
		this.gfthrRsdtSeqNo = gfthrRsdtSeqNo;
	}
	public String getSpusRsdtSeqNo() {
		return spusRsdtSeqNo;
	}
	public void setSpusRsdtSeqNo(String spusRsdtSeqNo) {
		this.spusRsdtSeqNo = spusRsdtSeqNo;
	}
	public String getSpusNm() {
		return spusNm;
	}
	public void setSpusNm(String spusNm) {
		this.spusNm = spusNm;
	}
	public String getDsbtCd() {
		return dsbtCd;
	}
	public void setDsbtCd(String dsbtCd) {
		this.dsbtCd = dsbtCd;
	}
	public String getDsbtCdNm() {
		return dsbtCdNm;
	}
	public void setDsbtCdNm(String dsbtCdNm) {
		this.dsbtCdNm = dsbtCdNm;
	}
	public String getFrngrYn() {
		return frngrYn;
	}
	public void setFrngrYn(String frngrYn) {
		this.frngrYn = frngrYn;
	}
	public String getAfSpusEnSurnm() {
		return afSpusEnSurnm;
	}
	public void setAfSpusEnSurnm(String afSpusEnSurnm) {
		this.afSpusEnSurnm = afSpusEnSurnm;
	}
	public String getSpusEnSurnm() {
		return spusEnSurnm;
	}
	public void setSpusEnSurnm(String spusEnSurnm) {
		this.spusEnSurnm = spusEnSurnm;
	}
	public String getSpusEnGivNm() {
		return spusEnGivNm;
	}
	public void setSpusEnGivNm(String spusEnGivNm) {
		this.spusEnGivNm = spusEnGivNm;
	}
	public String getAfFthrNm() {
		return afFthrNm;
	}
	public void setAfFthrNm(String afFthrNm) {
		this.afFthrNm = afFthrNm;
	}
	public String getAfMthrNm() {
		return afMthrNm;
	}
	public void setAfMthrNm(String afMthrNm) {
		this.afMthrNm = afMthrNm;
	}
	public String getAfFthrRsdtSeqNo() {
		return afFthrRsdtSeqNo;
	}
	public void setAfFthrRsdtSeqNo(String afFthrRsdtSeqNo) {
		this.afFthrRsdtSeqNo = afFthrRsdtSeqNo;
	}
	public String getAfMfthrRsdtSeqNo() {
		return afMfthrRsdtSeqNo;
	}
	public void setAfMfthrRsdtSeqNo(String afMfthrRsdtSeqNo) {
		this.afMfthrRsdtSeqNo = afMfthrRsdtSeqNo;
	}
	public String getAfGfthrNm() {
		return afGfthrNm;
	}
	public void setAfGfthrNm(String afGfthrNm) {
		this.afGfthrNm = afGfthrNm;
	}
	public String getAfGfthrRsdtSeqNo() {
		return afGfthrRsdtSeqNo;
	}
	public void setAfGfthrRsdtSeqNo(String afGfthrRsdtSeqNo) {
		this.afGfthrRsdtSeqNo = afGfthrRsdtSeqNo;
	}
	public String getAfSpusNm() {
		return afSpusNm;
	}
	public void setAfSpusNm(String afSpusNm) {
		this.afSpusNm = afSpusNm;
	}
	public String getAfSpusRsdtSeqNo() {
		return afSpusRsdtSeqNo;
	}
	public void setAfSpusRsdtSeqNo(String afSpusRsdtSeqNo) {
		this.afSpusRsdtSeqNo = afSpusRsdtSeqNo;
	}
	public String getAfDsbtCd() {
		return afDsbtCd;
	}
	public void setAfDsbtCd(String afDsbtCd) {
		this.afDsbtCd = afDsbtCd;
	}
	public String getAfDsbtCdNm() {
		return afDsbtCdNm;
	}
	public void setAfDsbtCdNm(String afDsbtCdNm) {
		this.afDsbtCdNm = afDsbtCdNm;
	}
	public String getFthrRgstTye() {
		return fthrRgstTye;
	}
	public void setFthrRgstTye(String fthrRgstTye) {
		this.fthrRgstTye = fthrRgstTye;
	}
	public String getMthrRgstTye() {
		return mthrRgstTye;
	}
	public void setMthrRgstTye(String mthrRgstTye) {
		this.mthrRgstTye = mthrRgstTye;
	}
	public String getGfthrRgstTye() {
		return gfthrRgstTye;
	}
	public void setGfthrRgstTye(String gfthrRgstTye) {
		this.gfthrRgstTye = gfthrRgstTye;
	}
	public String getSpusRgstTye() {
		return spusRgstTye;
	}
	public void setSpusRgstTye(String spusRgstTye) {
		this.spusRgstTye = spusRgstTye;
	}
	public String getFthrOldCrdNo() {
		return fthrOldCrdNo;
	}
	public void setFthrOldCrdNo(String fthrOldCrdNo) {
		this.fthrOldCrdNo = fthrOldCrdNo;
	}
	public String getMthrOldCrdNo() {
		return mthrOldCrdNo;
	}
	public void setMthrOldCrdNo(String mthrOldCrdNo) {
		this.mthrOldCrdNo = mthrOldCrdNo;
	}
	public String getGfthrOldCrdNo() {
		return gfthrOldCrdNo;
	}
	public void setGfthrOldCrdNo(String gfthrOldCrdNo) {
		this.gfthrOldCrdNo = gfthrOldCrdNo;
	}
	public String getSpusOldCrdNo() {
		return spusOldCrdNo;
	}
	public void setSpusOldCrdNo(String spusOldCrdNo) {
		this.spusOldCrdNo = spusOldCrdNo;
	}
	public String getRsdtCfmYn() {
		return rsdtCfmYn;
	}
	public void setRsdtCfmYn(String rsdtCfmYn) {
		this.rsdtCfmYn = rsdtCfmYn;
	}
	public String getBldTyeDocYn() {
		return bldTyeDocYn;
	}
	public void setBldTyeDocYn(String bldTyeDocYn) {
		this.bldTyeDocYn = bldTyeDocYn;
	}
	public String getEduLvDocYn() {
		return eduLvDocYn;
	}
	public void setEduLvDocYn(String eduLvDocYn) {
		this.eduLvDocYn = eduLvDocYn;
	}
	public String getEnSurnm() {
		return enSurnm;
	}
	public void setEnSurnm(String enSurnm) {
		this.enSurnm = enSurnm;
	}
	public String getAfEnSurnm() {
		return afEnSurnm;
	}
	public void setAfEnSurnm(String afEnSurnm) {
		this.afEnSurnm = afEnSurnm;
	}
	public String getAfFrngrYn() {
		return afFrngrYn;
	}
	public void setAfFrngrYn(String afFrngrYn) {
		this.afFrngrYn = afFrngrYn;
	}
	public String getAfBldTyeDocYn() {
		return afBldTyeDocYn;
	}
	public void setAfBldTyeDocYn(String afBldTyeDocYn) {
		this.afBldTyeDocYn = afBldTyeDocYn;
	}
	public String getAfEduLvDocYn() {
		return afEduLvDocYn;
	}
	public void setAfEduLvDocYn(String afEduLvDocYn) {
		this.afEduLvDocYn = afEduLvDocYn;
	}
	public String getFthrRsdtSeqNo() {
		return fthrRsdtSeqNo;
	}
	public void setFthrRsdtSeqNo(String fthrRsdtSeqNo) {
		this.fthrRsdtSeqNo = fthrRsdtSeqNo;
	}
	public String getMthrRsdtSeqNo() {
		return mthrRsdtSeqNo;
	}
	public void setMthrRsdtSeqNo(String mthrRsdtSeqNo) {
		this.mthrRsdtSeqNo = mthrRsdtSeqNo;
	}
	public String getBldTyeDocVrfd() {
		return bldTyeDocVrfd;
	}
	public void setBldTyeDocVrfd(String bldTyeDocVrfd) {
		this.bldTyeDocVrfd = bldTyeDocVrfd;
	}
	public String getEduLvDocVrfd() {
		return eduLvDocVrfd;
	}
	public void setEduLvDocVrfd(String eduLvDocVrfd) {
		this.eduLvDocVrfd = eduLvDocVrfd;
	}
	public String getAfBldTyeDocVrfd() {
		return afBldTyeDocVrfd;
	}
	public void setAfBldTyeDocVrfd(String afBldTyeDocVrfd) {
		this.afBldTyeDocVrfd = afBldTyeDocVrfd;
	}
	public String getAfEduLvDocVrfd() {
		return afEduLvDocVrfd;
	}
	public void setAfEduLvDocVrfd(String afEduLvDocVrfd) {
		this.afEduLvDocVrfd = afEduLvDocVrfd;
	}
	public String getPrntDd() {
		return prntDd;
	}
	public void setPrntDd(String prntDd) {
		this.prntDd = prntDd;
	}
	public String getRsdtRgstIdNm() {
		return rsdtRgstIdNm;
	}
	public void setRsdtRgstIdNm(String rsdtRgstIdNm) {
		this.rsdtRgstIdNm = rsdtRgstIdNm;
	}
	public String getCrdIsuDueDd() {
		return crdIsuDueDd;
	}
	public void setCrdIsuDueDd(String crdIsuDueDd) {
		this.crdIsuDueDd = crdIsuDueDd;
	}
	public String getCrdDlvrDd() {
		return crdDlvrDd;
	}
	public void setCrdDlvrDd(String crdDlvrDd) {
		this.crdDlvrDd = crdDlvrDd;
	}
	public String getCrdIsuSrlNo() {
		return crdIsuSrlNo;
	}
	public void setCrdIsuSrlNo(String crdIsuSrlNo) {
		this.crdIsuSrlNo = crdIsuSrlNo;
	}
	public String getBsnCd() {
		return bsnCd;
	}
	public void setBsnCd(String bsnCd) {
		this.bsnCd = bsnCd;
	}
	public String getBsnSeqNo() {
		return bsnSeqNo;
	}
	public void setBsnSeqNo(String bsnSeqNo) {
		this.bsnSeqNo = bsnSeqNo;
	}
	public String getAprvBtnClickYn() {
		return aprvBtnClickYn;
	}
	public void setAprvBtnClickYn(String aprvBtnClickYn) {
		this.aprvBtnClickYn = aprvBtnClickYn;
	}
	public String getAprvListTm() {
		return aprvListTm;
	}
	public void setAprvListTm(String aprvListTm) {
		this.aprvListTm = aprvListTm;
	}
	public String getCntTelNo() {
		return cntTelNo;
	}
	public void setCntTelNo(String cntTelNo) {
		this.cntTelNo = cntTelNo;
	}
	public String getAfOldCrdNo1() {
		return afOldCrdNo1;
	}
	public void setAfOldCrdNo1(String afOldCrdNo1) {
		this.afOldCrdNo1 = afOldCrdNo1;
	}
	public String getAfOldCrdNo2() {
		return afOldCrdNo2;
	}
	public void setAfOldCrdNo2(String afOldCrdNo2) {
		this.afOldCrdNo2 = afOldCrdNo2;
	}
	public String getAfOldCrdNo3() {
		return afOldCrdNo3;
	}
	public void setAfOldCrdNo3(String afOldCrdNo3) {
		this.afOldCrdNo3 = afOldCrdNo3;
	}
	public String getAppDd() {
		return appDd;
	}
	public void setAppDd(String appDd) {
		this.appDd = appDd;
	}
	public String getFndTye() {
		return fndTye;
	}
	public void setFndTye(String fndTye) {
		this.fndTye = fndTye;
	}
	public String getRsdtNm() {
		return rsdtNm;
	}
	public void setRsdtNm(String rsdtNm) {
		this.rsdtNm = rsdtNm;
	}
	public String getgBthDd() {
		return gBthDd;
	}
	public void setgBthDd(String gBthDd) {
		this.gBthDd = gBthDd;
	}
	public String gethBthDd() {
		return hBthDd;
	}
	public void sethBthDd(String hBthDd) {
		this.hBthDd = hBthDd;
	}
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	public String getFmlyBokNoNum() {
		return fmlyBokNoNum;
	}
	public void setFmlyBokNoNum(String fmlyBokNoNum) {
		this.fmlyBokNoNum = fmlyBokNoNum;
	}
	public String getSelfRsdtSeqNo() {
		return selfRsdtSeqNo;
	}
	public void setSelfRsdtSeqNo(String selfRsdtSeqNo) {
		this.selfRsdtSeqNo = selfRsdtSeqNo;
	}
	public String getRsdtStusCd() {
		return rsdtStusCd;
	}
	public void setRsdtStusCd(String rsdtStusCd) {
		this.rsdtStusCd = rsdtStusCd;
	}
	public String getMrrgSeqNo() {
		return mrrgSeqNo;
	}
	public void setMrrgSeqNo(String mrrgSeqNo) {
		this.mrrgSeqNo = mrrgSeqNo;
	}
	public String getHsbdRsdtSeqNo() {
		return hsbdRsdtSeqNo;
	}
	public void setHsbdRsdtSeqNo(String hsbdRsdtSeqNo) {
		this.hsbdRsdtSeqNo = hsbdRsdtSeqNo;
	}
	public String getWifeRsdtSeqNo() {
		return wifeRsdtSeqNo;
	}
	public void setWifeRsdtSeqNo(String wifeRsdtSeqNo) {
		this.wifeRsdtSeqNo = wifeRsdtSeqNo;
	}
	public String getAfMthrRsdtSeqNo() {
		return afMthrRsdtSeqNo;
	}
	public void setAfMthrRsdtSeqNo(String afMthrRsdtSeqNo) {
		this.afMthrRsdtSeqNo = afMthrRsdtSeqNo;
	}
	public String getCardisuFlag() {
		return cardisuFlag;
	}
	public void setCardisuFlag(String cardisuFlag) {
		this.cardisuFlag = cardisuFlag;
	}
	public String getAdultAge() {
		return adultAge;
	}
	public void setAdultAge(String adultAge) {
		this.adultAge = adultAge;
	}
	public String getCurtAdDiv() {
		return curtAdDiv;
	}
	public void setCurtAdDiv(String curtAdDiv) {
		this.curtAdDiv = curtAdDiv;
	}
	public String getCurtAdNatCd() {
		return curtAdNatCd;
	}
	public void setCurtAdNatCd(String curtAdNatCd) {
		this.curtAdNatCd = curtAdNatCd;
	}
	public String getCurtAdNatCdNm() {
		return curtAdNatCdNm;
	}
	public void setCurtAdNatCdNm(String curtAdNatCdNm) {
		this.curtAdNatCdNm = curtAdNatCdNm;
	}
	public String getOldCrdNo4() {
		return oldCrdNo4;
	}
	public void setOldCrdNo4(String oldCrdNo4) {
		this.oldCrdNo4 = oldCrdNo4;
	}
	public String getFthrOldCrdNo4() {
		return fthrOldCrdNo4;
	}
	public void setFthrOldCrdNo4(String fthrOldCrdNo4) {
		this.fthrOldCrdNo4 = fthrOldCrdNo4;
	}
	public String getMthrOldCrdNo4() {
		return mthrOldCrdNo4;
	}
	public void setMthrOldCrdNo4(String mthrOldCrdNo4) {
		this.mthrOldCrdNo4 = mthrOldCrdNo4;
	}
	public String getGfthrOldCrdNo4() {
		return gfthrOldCrdNo4;
	}
	public void setGfthrOldCrdNo4(String gfthrOldCrdNo4) {
		this.gfthrOldCrdNo4 = gfthrOldCrdNo4;
	}
	public String getSpusOldCrdNo4() {
		return spusOldCrdNo4;
	}
	public void setSpusOldCrdNo4(String spusOldCrdNo4) {
		this.spusOldCrdNo4 = spusOldCrdNo4;
	}
	public String getEmlAd() {
		return emlAd;
	}
	public void setEmlAd(String emlAd) {
		this.emlAd = emlAd;
	}
	public String getEduYn() {
		return eduYn;
	}
	public void setEduYn(String eduYn) {
		this.eduYn = eduYn;
	}
	public String getSecdNltyYn() {
		return secdNltyYn;
	}
	public void setSecdNltyYn(String secdNltyYn) {
		this.secdNltyYn = secdNltyYn;
	}
	public String getAfCurtAdDiv() {
		return afCurtAdDiv;
	}
	public void setAfCurtAdDiv(String afCurtAdDiv) {
		this.afCurtAdDiv = afCurtAdDiv;
	}
	public String getAfCurtAdNatCd() {
		return afCurtAdNatCd;
	}
	public void setAfCurtAdNatCd(String afCurtAdNatCd) {
		this.afCurtAdNatCd = afCurtAdNatCd;
	}
	public String getAfOldCrdNo4() {
		return afOldCrdNo4;
	}
	public void setAfOldCrdNo4(String afOldCrdNo4) {
		this.afOldCrdNo4 = afOldCrdNo4;
	}
	public String getAfFthrRgstTye() {
		return afFthrRgstTye;
	}
	public void setAfFthrRgstTye(String afFthrRgstTye) {
		this.afFthrRgstTye = afFthrRgstTye;
	}
	public String getAfMthrRgstTye() {
		return afMthrRgstTye;
	}
	public void setAfMthrRgstTye(String afMthrRgstTye) {
		this.afMthrRgstTye = afMthrRgstTye;
	}
	public String getAfGfthrRgstTye() {
		return afGfthrRgstTye;
	}
	public void setAfGfthrRgstTye(String afGfthrRgstTye) {
		this.afGfthrRgstTye = afGfthrRgstTye;
	}
	public String getAfSpusRgstTye() {
		return afSpusRgstTye;
	}
	public void setAfSpusRgstTye(String afSpusRgstTye) {
		this.afSpusRgstTye = afSpusRgstTye;
	}
	public String getAfFthrOldCrdNo1() {
		return afFthrOldCrdNo1;
	}
	public void setAfFthrOldCrdNo1(String afFthrOldCrdNo1) {
		this.afFthrOldCrdNo1 = afFthrOldCrdNo1;
	}
	public String getAfFthrOldCrdNo2() {
		return afFthrOldCrdNo2;
	}
	public void setAfFthrOldCrdNo2(String afFthrOldCrdNo2) {
		this.afFthrOldCrdNo2 = afFthrOldCrdNo2;
	}
	public String getAfFthrOldCrdNo3() {
		return afFthrOldCrdNo3;
	}
	public void setAfFthrOldCrdNo3(String afFthrOldCrdNo3) {
		this.afFthrOldCrdNo3 = afFthrOldCrdNo3;
	}
	public String getAfFthrOldCrdNo4() {
		return afFthrOldCrdNo4;
	}
	public void setAfFthrOldCrdNo4(String afFthrOldCrdNo4) {
		this.afFthrOldCrdNo4 = afFthrOldCrdNo4;
	}
	public String getAfMthrOldCrdNo1() {
		return afMthrOldCrdNo1;
	}
	public void setAfMthrOldCrdNo1(String afMthrOldCrdNo1) {
		this.afMthrOldCrdNo1 = afMthrOldCrdNo1;
	}
	public String getAfMthrOldCrdNo2() {
		return afMthrOldCrdNo2;
	}
	public void setAfMthrOldCrdNo2(String afMthrOldCrdNo2) {
		this.afMthrOldCrdNo2 = afMthrOldCrdNo2;
	}
	public String getAfMthrOldCrdNo3() {
		return afMthrOldCrdNo3;
	}
	public void setAfMthrOldCrdNo3(String afMthrOldCrdNo3) {
		this.afMthrOldCrdNo3 = afMthrOldCrdNo3;
	}
	public String getAfMthrOldCrdNo4() {
		return afMthrOldCrdNo4;
	}
	public void setAfMthrOldCrdNo4(String afMthrOldCrdNo4) {
		this.afMthrOldCrdNo4 = afMthrOldCrdNo4;
	}
	public String getAfGfthrOldCrdNo1() {
		return afGfthrOldCrdNo1;
	}
	public void setAfGfthrOldCrdNo1(String afGfthrOldCrdNo1) {
		this.afGfthrOldCrdNo1 = afGfthrOldCrdNo1;
	}
	public String getAfGfthrOldCrdNo2() {
		return afGfthrOldCrdNo2;
	}
	public void setAfGfthrOldCrdNo2(String afGfthrOldCrdNo2) {
		this.afGfthrOldCrdNo2 = afGfthrOldCrdNo2;
	}
	public String getAfGfthrOldCrdNo3() {
		return afGfthrOldCrdNo3;
	}
	public void setAfGfthrOldCrdNo3(String afGfthrOldCrdNo3) {
		this.afGfthrOldCrdNo3 = afGfthrOldCrdNo3;
	}
	public String getAfGfthrOldCrdNo4() {
		return afGfthrOldCrdNo4;
	}
	public void setAfGfthrOldCrdNo4(String afGfthrOldCrdNo4) {
		this.afGfthrOldCrdNo4 = afGfthrOldCrdNo4;
	}
	public String getAfSpusOldCrdNo1() {
		return afSpusOldCrdNo1;
	}
	public void setAfSpusOldCrdNo1(String afSpusOldCrdNo1) {
		this.afSpusOldCrdNo1 = afSpusOldCrdNo1;
	}
	public String getAfSpusOldCrdNo2() {
		return afSpusOldCrdNo2;
	}
	public void setAfSpusOldCrdNo2(String afSpusOldCrdNo2) {
		this.afSpusOldCrdNo2 = afSpusOldCrdNo2;
	}
	public String getAfSpusOldCrdNo3() {
		return afSpusOldCrdNo3;
	}
	public void setAfSpusOldCrdNo3(String afSpusOldCrdNo3) {
		this.afSpusOldCrdNo3 = afSpusOldCrdNo3;
	}
	public String getAfSpusOldCrdNo4() {
		return afSpusOldCrdNo4;
	}
	public void setAfSpusOldCrdNo4(String afSpusOldCrdNo4) {
		this.afSpusOldCrdNo4 = afSpusOldCrdNo4;
	}
	public String getAfEduYn() {
		return afEduYn;
	}
	public void setAfEduYn(String afEduYn) {
		this.afEduYn = afEduYn;
	}
	public String getAfSecdNltyYn() {
		return afSecdNltyYn;
	}
	public void setAfSecdNltyYn(String afSecdNltyYn) {
		this.afSecdNltyYn = afSecdNltyYn;
	}
	public String getOldCrdIsuceDd() {
		return oldCrdIsuceDd;
	}
	public void setOldCrdIsuceDd(String oldCrdIsuceDd) {
		this.oldCrdIsuceDd = oldCrdIsuceDd;
	}
	public String getAfOldCrdIsuceDd() {
		return afOldCrdIsuceDd;
	}
	public void setAfOldCrdIsuceDd(String afOldCrdIsuceDd) {
		this.afOldCrdIsuceDd = afOldCrdIsuceDd;
	}
	public String getOldCrdIsucePlceCd() {
		return oldCrdIsucePlceCd;
	}
	public void setOldCrdIsucePlceCd(String oldCrdIsucePlceCd) {
		this.oldCrdIsucePlceCd = oldCrdIsucePlceCd;
	}
	public String getAfOldCrdIsucePlceCd() {
		return afOldCrdIsucePlceCd;
	}
	public void setAfOldCrdIsucePlceCd(String afOldCrdIsucePlceCd) {
		this.afOldCrdIsucePlceCd = afOldCrdIsucePlceCd;
	}
	public String getCntTelNo2() {
		return cntTelNo2;
	}
	public void setCntTelNo2(String cntTelNo2) {
		this.cntTelNo2 = cntTelNo2;
	}
	public String getSpousCnt() {
		return spousCnt;
	}
	public void setSpousCnt(String spousCnt) {
		this.spousCnt = spousCnt;
	}
	public String getMrrgDvrcCnt() {
		return mrrgDvrcCnt;
	}
	public void setMrrgDvrcCnt(String mrrgDvrcCnt) {
		this.mrrgDvrcCnt = mrrgDvrcCnt;
	}
	public String getOthrRl() {
		return othrRl;
	}
	public void setOthrRl(String othrRl) {
		this.othrRl = othrRl;
	}
	public String getAfOthrRl() {
		return afOthrRl;
	}
	public void setAfOthrRl(String afOthrRl) {
		this.afOthrRl = afOthrRl;
	}
	public String getSrchCalTye() {
		return srchCalTye;
	}
	public void setSrchCalTye(String srchCalTye) {
		this.srchCalTye = srchCalTye;
	}
	public String getSrchBthDd() {
		return srchBthDd;
	}
	public void setSrchBthDd(String srchBthDd) {
		this.srchBthDd = srchBthDd;
	}
	public String getSrchAgGap() {
		return srchAgGap;
	}
	public void setSrchAgGap(String srchAgGap) {
		this.srchAgGap = srchAgGap;
	}
	public String getAfFthrRlCd() {
		return afFthrRlCd;
	}
	public void setAfFthrRlCd(String afFthrRlCd) {
		this.afFthrRlCd = afFthrRlCd;
	}
	public String getAfMthrRlCd() {
		return afMthrRlCd;
	}
	public void setAfMthrRlCd(String afMthrRlCd) {
		this.afMthrRlCd = afMthrRlCd;
	}
	public String getAfGfthrRlCd() {
		return afGfthrRlCd;
	}
	public void setAfGfthrRlCd(String afGfthrRlCd) {
		this.afGfthrRlCd = afGfthrRlCd;
	}
	public String getAfSpusRlCd() {
		return afSpusRlCd;
	}
	public void setAfSpusRlCd(String afSpusRlCd) {
		this.afSpusRlCd = afSpusRlCd;
	}
	public String getFgmhRsdtSeqNo() {
		return fgmhRsdtSeqNo;
	}
	public void setFgmhRsdtSeqNo(String fgmhRsdtSeqNo) {
		this.fgmhRsdtSeqNo = fgmhRsdtSeqNo;
	}	
	
}
