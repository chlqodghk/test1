package afnid.rm.rsdt.service;


/** 
 * This service interface is biz-class of common. <br>
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2013.01.04  		BH Choi				Create
 *
 * </pre>
 */
public interface RM1RsdtInfrService {


	int setXmlGenerate() throws Exception;
	
	void getXmlGenerate() throws Exception;	
}
