package afnid.rm.rsdt.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;



/** 
 * This service interface is biz-class of common. <br>
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2014.12.08  		BH Choi										Create
 *
 * </pre>
 */
public interface RsdtMberInfrService {

	/**	 
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return EgovMap
	 * @exception Exception
	 */
	EgovMap searchRsdtFmlyRela(RsdtInfrVO vo) throws Exception;
	
	/**	 
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return String
	 * @exception Exception
	 */
	String addRsdtMberInfr(RsdtInfrVO vo) throws Exception;
	
	/**	 
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return RsdtInfrVO
	 * @exception Exception
	 */
    RsdtInfrVO searchRsdtInfrView(RsdtInfrVO vo) throws Exception;
    
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 */
	List<RsdtInfrVO> searchListOthrNatLangInfr(RsdtInfrVO vo) throws Exception;

	/**
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List List
	 * @exception Exception
	 */
	List<RsdtInfrVO> searchListFrgnLangInfr(RsdtInfrVO vo) throws Exception;
	
	
	/**	 
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 */
	List<EgovMap> searchRsdtMberFmlyInfr(RsdtInfrVO vo) throws Exception;
	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param RsdtInfrVO
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	List<EgovMap> searchListRsdtMberInfrPop(RsdtInfrVO vo) throws Exception;
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo RsdtInfrVO
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListRsdtMberInfrPopTotCnt(RsdtInfrVO vo) throws Exception;
	
	
	/**	 
	 * Retrieves of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return RsdtInfrVO
	 * @exception Exception
	 */
    RsdtInfrVO searchRsdtInfrRcpt(RsdtInfrVO vo) throws Exception;
    
    /**
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 */
	List<RsdtInfrVO> searchListOthrNatLangInfrForRcpt(RsdtInfrVO vo) throws Exception;

	/**
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 */
	List<RsdtInfrVO> searchListFrgnLangInfrForRcpt(RsdtInfrVO vo) throws Exception;

    
	/**	 
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return int
	 * @exception Exception
	 */
	int modifyRsdtMberInfr(RsdtInfrVO vo) throws Exception;
	
	
	/**	 
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return EgovMap
	 * @exception Exception
	 */
	EgovMap searchRsdtMberBioAgeChk(RsdtInfrVO vo) throws Exception;
    
	
	
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 */
	List<EgovMap> searchListRsdtMberInfrAprv(RsdtInfrVO vo) throws Exception;

	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param RsdtInfrVO
	 * @return int
	 * @exception Exception
	 */
	int searchListRsdtMberInfrAprvTotCn(RsdtInfrVO vo) throws Exception;
	
	
	
	
	/**	 
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return RsdtInfrVO
	 * @exception Exception
	 */
    RsdtInfrVO searchRsdtInfrAprvView(RsdtInfrVO vo) throws Exception;
    
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 */
	List<RsdtInfrVO> searchListOthrNatLangInfrAprv(RsdtInfrVO vo) throws Exception;

	/**
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List List
	 * @exception Exception
	 */
	List<RsdtInfrVO> searchListFrgnLangInfrAprv(RsdtInfrVO vo) throws Exception;
	
	/**	 
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO, String
	 * @return int
	 * @exception Exception
	 */
	int modifyRsdtMberInfrAprv(RsdtInfrVO vo, String type) throws Exception;
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param RsdtInfrVO
	 * @return int
	 * @exception Exception
	 */
	EgovMap aprvRsdtMberInfr(RsdtInfrVO vo) throws Exception;
	
	
	/**
	 * Retrieves total count of program-list. <br>
	 * @param RsdtInfrVO
	 * @return int
	 * @exception Exception
	 */
	int searchRsdtMberInfrApvrState(RsdtInfrVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchListRsdtInfrPop(RsdtInfrVO vo) throws Exception;

	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(RsdtInfrVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListRsdtInfrPopTotCn(RsdtInfrVO vo) throws Exception;
	
	
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchRsdtFmlyBokLstPop(RsdtInfrVO vo) throws Exception;
	
	
	
	/**	 
	 * Retrieves list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return String
	 * @exception Exception
	 */
	String searchFmlyRsdtMberSelfGdr(RsdtInfrVO vo) throws Exception;
	
	
	
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchFmlyMberRsdtInfrList(EgovMap vo) throws Exception;
	
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchListFmlyInfrPop(RsdtInfrVO vo) throws Exception;
	
	
	
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchRsdtInfrMaleRlCn(EgovMap vo) throws Exception;
	
}
