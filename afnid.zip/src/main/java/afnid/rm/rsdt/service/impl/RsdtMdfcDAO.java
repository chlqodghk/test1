package afnid.rm.rsdt.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.rsdt.service.RsdtInfrVO;
import afnid.rm.rsdt.service.RsdtMdfcVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;



/** 
 * This class is Database Access Object of common
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04`
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.06.24  		BH Choi         		Create
 *
 * </pre>
 */
@Repository("rsdtMdfcDAO")
public class RsdtMdfcDAO extends EgovAbstractDAO {
	
	@Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }

	
	/**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return RsdtMdfcVO Retrieve of program
	 * @exception Exception
	 *
	 */
	public RsdtMdfcVO selectRsdtMdfcIsFlag(RsdtMdfcVO vo) throws Exception{
		return (RsdtMdfcVO)selectByPk("rsdtMdfcDAO.selectRsdtMdfcIsFlag", vo);
	}
	
	/**
	 * DAO-method for retrieving  of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 *
	 */
	public EgovMap selectRsdtInfr(RsdtMdfcVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setCrdReisuceDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
		delete("rsdtMdfcDAO.deleteRsdtImBioCaptTb", vo);
		return (EgovMap)selectByPk("rsdtMdfcDAO.selectRsdtInfo", vo);
	}
	
	/**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 *
	 */
	public EgovMap selectRsdtMdfctInfr(RsdtMdfcVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
		vo.setCrdReisuceDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
		return (EgovMap)selectByPk("rsdtMdfcDAO.selectRsdtMdfctInfo", vo);
	}
	
	
	/**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 *
	 */
	public EgovMap selectRsdtMdfctAprvInfo(RsdtMdfcVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
		vo.setCrdReisuceDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
		return (EgovMap)selectByPk("rsdtMdfcDAO.selectRsdtMdfctAprvInfo", vo);
	}
	
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtMdfcVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateRsdtMdfctInfr(RsdtMdfcVO vo){
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());		
		return update("rsdtMdfcDAO.updateRsdtMdfctInfo", vo);
	}
	
	
	/**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return String object of program
	 * @exception Exception
	 *
	 */
	public String selectRsdtInfrSeq(RsdtMdfcVO vo) throws Exception{
		return (String)selectByPk("rsdtMdfcDAO.selectRsdtInfoSeq", vo);
	}
	
	
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRmOthrNatLangTb(RsdtMdfcVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		return list("rsdtMdfcDAO.selectRmOthrNatLangTb", vo);
	}
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRmFrgnLangTb(RsdtMdfcVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		return list("rsdtMdfcDAO.selectRmFrgnLangTb", vo);
	}
	
	
	
	
	
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRmOthrNatLangBfTb(RsdtMdfcVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		return list("rsdtMdfcDAO.selectRmOthrNatLangBfTb", vo);
	}
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRmFrgnLangBfTb(RsdtMdfcVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		return list("rsdtMdfcDAO.selectRmFrgnLangBfTb", vo);
	}
	
	
	
	
	
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRmOthrNatLangAfTb(RsdtMdfcVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		return list("rsdtMdfcDAO.selectRmOthrNatLangAfTb", vo);
	}
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRmFrgnLangAfTb(RsdtMdfcVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		return list("rsdtMdfcDAO.selectRmFrgnLangAfTb", vo);
	}
	
	
	/**
	 * DAO-method for Residents save updated data.. <br>
	 * 
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return String object of program
	 * @exception Exception
	 */
    public String insertRsdtMdfctInfr(RsdtMdfcVO vo) {
    	String result = null;
    	synchronized(this){
    		result = (String)insert("rsdtMdfcDAO.insertRsdtMdfctInfo", vo);
    	}
        return result;
    }
    
    /**
	 * DAO-method for registering of program. <br>
	 * 
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return void
	 * @exception Exception
	 */
    public void insertRsdtMdfctNatLangBfTb(RsdtMdfcVO vo) {
        insert("rsdtMdfcDAO.insertRsdtMdfctNatLangBfTb", vo);
    }
    /**
	 * DAO-method for registering of program. <br>
	 * 
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return void
	 * @exception Exception
	 */
    public void insertRsdtMdfctNatLangAfTb(RsdtMdfcVO vo) {
        insert("rsdtMdfcDAO.insertRsdtMdfctNatLangAfTb", vo);
    }
    /**
	 * DAO-method for registering of program. <br>
	 * 
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return void
	 * @exception Exception
	 */
    public void insertRsdtMdfctFrgnLangBfTb(RsdtMdfcVO vo) {
        insert("rsdtMdfcDAO.insertRsdtMdfctFrgnLangBfTb", vo);
    }
    /**
	 * DAO-method for registering of program. <br>
	 * 
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return void
	 * @exception Exception
	 */
    public void insertRsdtMdfctFrgnLangAfTb(RsdtMdfcVO vo) {
        insert("rsdtMdfcDAO.insertRsdtMdfctFrgnLangAfTb", vo);
    }
    
    
    /**
	 * DAO-method for registering of program. <br>
	 *
	 * @param vo Input item for registering new program(RsdtMdfcVO).
	 * @return int count of program
	 * @exception Exception
	 */
	public int deleteRsdtMdfctNatLangAfTb(RsdtMdfcVO vo) throws Exception{
		return delete("rsdtMdfcDAO.deleteRsdtMdfctNatLangAfTb", vo);
	}
	
	/**
	 * DAO-method for registering of program.. <br>
	 *
	 * @param vo Input item for registering new program(RsdtMdfcVO).
	 * @return int count of program
	 * @exception Exception
	 */
	public int deleteRsdtMdfctFrgnLangAfTb(RsdtMdfcVO vo) throws Exception{
		return delete("rsdtMdfcDAO.deleteRsdtMdfctFrgnLangAfTb", vo);
	}
	
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListRsdtMdfcAprv(RsdtMdfcVO vo) throws Exception{
		
		vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword7(NidStringUtil.toNumberConvet(vo.getSearchKeyword7(), "g"));
		vo.setSearchKeyword8(NidStringUtil.toNumberConvet(vo.getSearchKeyword8(), "g"));
		vo.setSearchKeyword9(NidStringUtil.toNumberConvet(vo.getSearchKeyword9(), "g"));		
		return list("rsdtMdfcDAO.selectRsdtMdfcVfyLst", vo);
	}

	/**
	 * DAO-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListRsdtMdfcAprvTotCn(RsdtMdfcVO vo) {
    	
    	vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword7(NidStringUtil.toNumberConvet(vo.getSearchKeyword7(), "g"));
		vo.setSearchKeyword8(NidStringUtil.toNumberConvet(vo.getSearchKeyword8(), "g"));
		vo.setSearchKeyword9(NidStringUtil.toNumberConvet(vo.getSearchKeyword9(), "g"));
		
        return (Integer)selectByPk("rsdtMdfcDAO.selectRsdtMdfcVfyLstTotCnt", vo);
    }
    
    
    /**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtMdfcVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateRsdtMdfcAprv(RsdtMdfcVO vo){
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());		
		return update("rsdtMdfcDAO.updateRsdtMdfcVfy", vo);
	}
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtMdfcVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateRsdtMdfcToRsdtInfr(RsdtMdfcVO vo){
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());			
		return update("rsdtMdfcDAO.updateRsdtMdfcToRsdtInfo", vo);
	}
	
	
	/**
	 * DAO-method for registering  of program. <br>
	 * 
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return void
	 * @exception Exception
	 */
    public void insertRsdtInfrHst(RsdtMdfcVO vo) {
    	RsdtInfrVO vos = new RsdtInfrVO();
    	vos.setRsdtSeqNo(vo.getRsdtSeqNo());
    	vos.setUserId(vo.getUserId());
        insert("rsdtInfoDAO.insertRsdtInfoHst", vos);
        insert("rsdtInfoDAO.insertRsdtInfrOthrNatLangHst", vos);
        insert("rsdtInfoDAO.insertRsdtInfrFrgnLangHst", vos);
    }
    
    
    /**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
	 * @return int count of Progra
	 * @exception Exception
	 */
    public int selectRsdtMdfcCrdIssTo(RsdtMdfcVO vo) {
        return (Integer)selectByPk("rsdtMdfcDAO.selectRsdtMdfcCrdIssTo", vo);
    }
    
    
    /**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
	 * @return int count of Progra
	 * @exception Exception
	 */
    public int selectRsdtMdfcCrdIssToEng(RsdtMdfcVO vo) {
        return (Integer)selectByPk("rsdtMdfcDAO.selectRsdtMdfcCrdIssToEng", vo);
    }
    
    /**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
	 * @return int count of Progra
	 * @exception Exception
	 */
    public EgovMap selectRsdtInfoImBioCaptInfo(RsdtMdfcVO vo) {
        return (EgovMap)selectByPk("rsdtMdfcDAO.selectRsdtInfoImBioCaptInfo", vo);
    }
    
    /**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
	 * @return int count of Program
	 * @exception Exception
	 */
    public int selectIssueCrd(RsdtMdfcVO vo) {
        return (Integer)selectByPk("rsdtMdfcDAO.selectIssueACard", vo);
    }
    
    /**
	 * DAO-method for registering of program. <br>
	 *
	 * @param vo Input item for registering of program(RsdtMdfcVO).
	 * @return void
	 * @exception Exception
	 */
	public void deleteOthrNatLang(RsdtMdfcVO vo) throws Exception{
		delete("rsdtMdfcDAO.deleteOthrNatLang", vo);
	}
	/**
	 * DAO-method for registering of program. <br>
	 *
	 * @param vo Input item for registering of program(RsdtMdfcVO).
	 * @return void
	 * @exception Exception
	 */
	public void deleteFrgnLang(RsdtMdfcVO vo) throws Exception{
		delete("rsdtMdfcDAO.deleteFrgnLang", vo);
	}
    
	/**
	 * DAO-method for registering of program. <br>
	 * 
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return void
	 * @exception Exception
	 */
    public void insertOthrNatLangTb(RsdtMdfcVO vo) {
        insert("rsdtMdfcDAO.insertOthrNatLangTb", vo);
    }
    /**
	 * DAO-method for registering of program. <br>
	 * 
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return void
	 * @exception Exception
	 */
    public void insertFrgnLangTb(RsdtMdfcVO vo) {
        insert("rsdtMdfcDAO.insertFrgnLangTb", vo);
    }
    
    
    /**
	 * DAO-method for registering of program. <br>
	 * 
	 * @param RsdtMdfcVO, String
	 * @return void
	 * @exception Exception
	 */
    public void insertIfCrdIsuTb(RsdtMdfcVO vo, String pkiIfNum) {
    	RsdtInfrVO vos = new RsdtInfrVO();
    	vos.setRsdtNo(vo.getRsdtNo());
    	vos.setCrdCd("1");
    	vos.setAplCd(pkiIfNum);
    	vos.setFleNm("");
    	vos.setBsnCd("2");
    	vos.setBsnSeqNo(vo.getMdfctSeqNo());    	
        insert("rsdtInfoDAO.insertImCrdIsuTb", vos);
    }
    
    
    /**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtMdfcVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateRsdtInfrCrdStusCd(RsdtMdfcVO vo){
		return update("rsdtMdfcDAO.updateRsdtInfoCrdStusCd", vo);
	}
    
	
	
	/**
	 * DAO-method for  retrieving Receipt of Citizen Confirmation. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(RsdtMdfcVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
    public EgovMap selectRsdtMdfcCfmRcpt(RsdtMdfcVO vo) {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		vo.setOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());
		int adultAge = propertiesService.getInt("adultAge");
   		vo.setAdultAge(String.valueOf(adultAge));
        return (EgovMap)selectByPk("rsdtMdfcDAO.selectRsdtMdfcCfmReceipt", vo);
    }
    
    /**
	 * DAO-method for  retrieving Receipt of Citizen Confirmation. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(RsdtMdfcVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRsdtMdfcOthrCfmRcpt(RsdtMdfcVO vo) throws Exception{
		return list("rsdtMdfcDAO.selectRsdtMdfcOthrCfmReceipt", vo);
	}
	
	/**
	 * DAO-method for  retrieving Receipt of Citizen Confirmation. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(RsdtMdfcVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")	
    public List<EgovMap> selectRsdtMdfcFrgnCfmRcpt(RsdtMdfcVO vo) {
    	return list("rsdtMdfcDAO.selectRsdtMdfcFrgnCfmReceipt", vo);
    }	
	
	/**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
    public EgovMap selectRsdtMdfcChngFieldFlag(RsdtMdfcVO vo) {
        return (EgovMap)selectByPk("rsdtMdfcDAO.selectRsdtMdfcChangeFieldFlag", vo);
    }
    
    
    
    /**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return int count of Program
	 * @exception Exception
	 */
    public int selectRsdtMdfcChngIsFlag(RsdtMdfcVO vo) {
        return (Integer)selectByPk("rsdtMdfcDAO.selectRsdtMdfcChangeIsFlag", vo);
    }
    
    
    
    
    /**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 *
	 */
	public EgovMap selectRsdtMdfcRgstIsFlag(RsdtMdfcVO vo) throws Exception{
		return (EgovMap)selectByPk("rsdtMdfcDAO.selectRsdtMdfcRegIsFlag", vo);
	}
	
	
	
	
	/**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 *
	 */
	public EgovMap selectRmImgView(RsdtMdfcVO vo) throws Exception{
		return (EgovMap)selectByPk("rsdtMdfcDAO.selectRmImageView", vo);
	}
	
	/**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 *
	 */
	public int selectRsdtMdfctTbTeamYn(RsdtMdfcVO vo) throws Exception{
		return (Integer)selectByPk("rsdtMdfcDAO.selectRsdtMdfctTbTeamYn", vo);
	}
	
	
	/**
	 * DAO-method for Check expiration date of the card. <br>
	 *
	 * @param vo Input item for retrieving of program(String).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 *
	 */
	public EgovMap selectRsdtInfrCrdExpiry(String rsdtNo) throws Exception{
		RsdtMdfcVO vo = new RsdtMdfcVO();
		vo.setRsdtNo(rsdtNo);
		String crdReisuceDmBfExpr = String.valueOf(propertiesService.getInt("crdReisuceDmBfExpr"));
		int expr = -1;
		try{
			expr = Integer.parseInt(crdReisuceDmBfExpr);
		}catch(NumberFormatException nfe){
			expr = 1;
			crdReisuceDmBfExpr = String.valueOf(expr);
		}
		vo.setSearchKeyword(crdReisuceDmBfExpr);
		
		return (EgovMap)selectByPk("rsdtMdfcDAO.selectRsdtInfrCrdExpiry", vo);
	}
	
	
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtMdfcVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateRsdtMdfctTbCrdReisuceYn(RsdtMdfcVO vo){
		return update("rsdtMdfcDAO.updateRsdtMdfctTbCrdReisuceYn", vo);
	}
	
	
	
	/**
	 * DAO-method for Card issuing processing history results. <br>
	 *
	 * @param RsdtMdfcVO
	 * @return String
	 * @exception Exception
	 *
	 */
	public EgovMap selectRsdtInfrCrdProcErr(RsdtMdfcVO vo) throws Exception{
		return (EgovMap)selectByPk("rsdtMdfcDAO.selectRsdtInfrCrdProcErr", vo);
	}
	
	
	/**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return RsdtMdfcVO Retrieve of program
	 * @exception Exception
	 *
	 */
	public RsdtMdfcVO selectRsdtMdfcSeqIsFlag(RsdtMdfcVO vo) throws Exception{
		vo.setViewRsdtNo(NidStringUtil.toNumberConvet(vo.getViewRsdtNo(), "g"));
		return (RsdtMdfcVO)selectByPk("rsdtMdfcDAO.selectRsdtMdfcSeqIsFlag", vo);
	}
	
	/**
	 * DAO-method for retrieving list of citizen. <br>
	 *
	 * @param vo Input item for retrieving list of  citizen(RsdtMdfcVO).
	 * @return List Retrieve list of citizen
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtMdfcVO> selectListRsdtNmFnd(RsdtMdfcVO vo) throws Exception{	
		vo.setSearchKeyword4(NidStringUtil.toNumberConvet(vo.getSearchKeyword4(), "g"));
		vo.setSearchKeyword5(NidStringUtil.toNumberConvet(vo.getSearchKeyword5(), "g"));
		vo.setSearchKeyword6(NidStringUtil.toNumberConvet(vo.getSearchKeyword6(), "g"));
		return list("rsdtMdfcDAO.selectListRsdtNmFnd", vo);
	}

	/**
	 * DAO-method for retrieving total count of citizen list. <br>
	 *
	 * @param vo Input item for total count of citizen list(RsdtMdfcVO).
	 * @return int Total Count of citizen list
	 * @exception Exception
	 */
    public int selectListRsdtNmFndTotCn(RsdtMdfcVO vo) {
    	vo.setSearchKeyword4(NidStringUtil.toNumberConvet(vo.getSearchKeyword4(), "g"));
		vo.setSearchKeyword5(NidStringUtil.toNumberConvet(vo.getSearchKeyword5(), "g"));
		vo.setSearchKeyword6(NidStringUtil.toNumberConvet(vo.getSearchKeyword6(), "g"));
        return (Integer)selectByPk("rsdtMdfcDAO.selectListRsdtNmFndTotCn", vo);
    }
    
    /**
	 * DAO-method for retrieving citizen by eNID. <br>
	 * 
	 * @param vo Input item for retrieving citizen by eNID(RsdtMdfcVO).
	 * @return RsdtMdfcVO Retrieve citizen by eNID
	 * @exception Exception
	 */
    public RsdtMdfcVO selectRsdtNmFnd(RsdtMdfcVO vo) {
        return (RsdtMdfcVO)selectByPk("rsdtMdfcDAO.selectRsdtNmFnd", vo);
    }
    
    /**
	 * DAO-method for retrieving total count of citizen list. <br>
	 *
	 * @param vo Input item for total count of citizen list(RsdtMdfcVO).
	 * @return int Total Count of citizen list
	 * @exception Exception
	 */
    public int selectListMdfcMrrgDvrc(RsdtMdfcVO vo) {
        return (Integer)selectByPk("rsdtMdfcDAO.selectListMdfcMrrgDvrc", vo);
    }
    
    
    /**
	 * DAO-method for retrieving total count of citizen list. <br>
	 *
	 * @param vo Input item for total count of citizen list(RsdtMdfcVO).
	 * @return int Total Count of citizen list
	 * @exception Exception
	 */
    public int selectListMdfcMrrgCnt(RsdtMdfcVO vo) {
        return (Integer)selectByPk("rsdtMdfcDAO.selectListMdfcMrrgCnt", vo);
    }
    
    
    /**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
	 * @return int count of Progra
	 * @exception Exception
	 */
    public String selectRsdtMdfcCrdChipChange(RsdtMdfcVO vo) {
        return (String)selectByPk("rsdtMdfcDAO.selectRsdtMdfcCrdChipChange", vo);
    }
    
    
    
    /**
	 * DAO-method for retrieving total count of citizen list. <br>
	 *
	 * @param vo Input item for total count of citizen list(RsdtMdfcVO).
	 * @return int Total Count of citizen list
	 * @exception Exception
	 */
    public int selectBthRgst(RsdtMdfcVO vo) {
        return (Integer)selectByPk("rsdtMdfcDAO.selectBthRgst", vo);
    }
    
    /**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtMdfcVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateBthRgst(RsdtMdfcVO vo){
		return update("rsdtMdfcDAO.updateBthRgst", vo);
	}
    
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtMdfcVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateBthRgstMdfct(RsdtMdfcVO vo){
		return update("rsdtMdfcDAO.updateBthRgstMdfct", vo);
	}
	
	/**
	 * DAO-method for retrieving family member. <br>
	 * 
	 * @param vo Input item for retrieving family member(RsdtMdfcVO).
	 * @return int 
	 * @exception Exception
	 */
	public int selectMber(RsdtMdfcVO vo){
		return (Integer)selectByPk("rsdtMdfcDAO.selectMber", vo);
	}
	
    /**
	 * DAO-method for  <br>
	 * 
	 * @param vo Input item ).
	 * @return 
	 * @exception Exception
	 */
    public RsdtMdfcVO selectMberRsdtNo(RsdtMdfcVO vo) {
        return (RsdtMdfcVO)selectByPk("rsdtMdfcDAO.selectMberRsdtNo", vo);
    }	
	
	/**
	 * DAO-method for retrieving member row number. <br>
	 * 
	 * @param vo Input item for retrieving member row number(RsdtMdfcVO).
	 * @return int 
	 * @exception Exception
	 */
	public int selectMberRowNum(RsdtMdfcVO vo){
		return (Integer)selectByPk("rsdtMdfcDAO.selectMberRowNum", vo);
	}
	
}
