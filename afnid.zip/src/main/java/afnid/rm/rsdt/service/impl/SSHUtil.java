package afnid.rm.rsdt.service.impl;

import java.io.IOException;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.sshtools.j2ssh.SftpClient;
import com.sshtools.j2ssh.SshClient;
import com.sshtools.j2ssh.authentication.AuthenticationProtocolState;
import com.sshtools.j2ssh.authentication.PasswordAuthenticationClient;
import com.sshtools.j2ssh.sftp.SftpFile;
import com.sshtools.j2ssh.transport.IgnoreHostKeyVerification;

public class SSHUtil {
	
	private SshClient client;
	private SftpClient sftp;

	protected Log log = LogFactory.getLog(this.getClass());
	
	public SSHUtil(String serverIp,int port,String userId,String password) throws IOException {
		try {
			if (serverIp == null || port == 0 || userId == null || password == null) {
				log.debug("parameter is null...");
			}
			client = new SshClient();
			client.setSocketTimeout(70000);
			client.connect(serverIp, port, new IgnoreHostKeyVerification());

			PasswordAuthenticationClient auth = new PasswordAuthenticationClient();
			auth.setUsername(userId);
			auth.setPassword(password);
			int result = client.authenticate(auth);
			if (result != AuthenticationProtocolState.COMPLETE) {
				throw new IOException("Login to " + serverIp + ":" + port + userId + "/" + password
						+ " failed");
			}
			sftp = client.openSftpClient();
		}catch(IOException e){
			log.error(e);
		}
	}
	
	public boolean mkdir(String dirNm) throws Exception {
        boolean rtn = false;
        try    {
            if (sftp != null) {
            	sftp.mkdir(dirNm);
                rtn = true;
            }
        } catch(Exception e) {
            log.error(e);
        }
        return rtn;
    }
	
	public boolean put(String path) throws Exception {
        boolean rtn = false;
        try    {
            if (sftp != null) {
                sftp.put(path);
                rtn = true;
            }
        } catch(Exception e) {
            log.error(e);
        }
        return rtn;
    }

    public boolean get(String srcFile, String destFile) throws Exception {
        boolean rtn = false;
        try {
            if (sftp != null) {
                if (destFile == null){
                    sftp.get(srcFile);
                }else{
                    sftp.get(srcFile, destFile);
                }
                rtn = true;
            }
        } catch(Exception e) {
            log.error(e);
        }
        return rtn;
    }
    
    public boolean mget(String remotedir, String localdir) throws Exception {
        boolean rtn = false;
        try {
            if (sftp != null) {
            	sftp.copyRemoteDirectory(remotedir, localdir, true, true, true, null); 
            	rtn = true;
            }
        } catch(Exception e) {
            log.error(e);
        }
        return rtn;
    }

    public boolean lcd(String path) throws Exception {
        boolean rtn = false;
        try {
            if (sftp != null) {
                sftp.lcd(path);
                rtn = true;
            }
        } catch(Exception e) {
            log.error(e);
        }
        return rtn;
    }

    public boolean cd(String path) throws Exception {
        boolean rtn = false;
        try {
            if (sftp != null) {
                sftp.cd(path);
                rtn = true;
            }
        } catch(Exception e) {
            log.error(e);
        }
        return rtn;
    }

    public String pwd() throws Exception {
        String rtnStr = null;
        try {
            if (sftp != null) {
                rtnStr = sftp.pwd();
            }
        } catch(Exception e) {
            log.error(e);
        }
        return rtnStr;
    }

    public boolean chmod(int permissions, String path) throws Exception {
        boolean rtn = false;
        try {
            if (sftp != null) {
                sftp.chmod(permissions, path);
                rtn = true;
            }
        } catch(Exception e) {
            log.error(e);
        }
        return rtn;
    }

    public boolean isClosed() throws Exception {
        boolean rtn = false;
        try {
            if (sftp != null){
                rtn = sftp.isClosed();
            }
        } catch(Exception e) {
            log.error(e);
        }
        return rtn;
    }

    public boolean logout() throws Exception {
        boolean rtn = false;
        try {
            if (sftp != null){
                sftp.quit();
            }
            if (client != null){
                client.disconnect();
            }
            rtn = true;
        } catch(Exception e) {
            log.error(e);
        }
        return rtn;
    }
    
    public boolean rename(String oldName, String newName) throws Exception{
    	boolean rtn = false;
    	
    	try{
    		if(sftp !=null){
    			sftp.rename(oldName, newName);
    		}
    		rtn = true;
    	}catch(Exception e){
    		log.error(e);
    	}
    	
    	return rtn;
    }
    public boolean rm(String fileName) throws Exception{
    	boolean rtn = false;
    	
    	try{
    		if(sftp !=null){
    			sftp.rm(fileName);
    		}
    		rtn = true;
    	}catch(Exception e){
    		log.error(e);
    	}
    	
    	return rtn;
    }
    
    
    public List<SftpFile> ls() throws Exception{
    	return ls(null);
    }
    
    @SuppressWarnings("unchecked")
	public List<SftpFile> ls(String path) throws Exception{
    	List<SftpFile> rtn = null;
    	try{
    		if(sftp !=null){
    			if(path != null){
    				rtn = sftp.ls(path);
    			}else{
    				rtn = sftp.ls();
    			}
    		}
    	}catch(Exception e){
    		 log.error(e);
    	}
    	return rtn;
    }

    public String lpwd() throws Exception {
        String rtnStr = null;
        try {
            if (sftp != null) {
                rtnStr = sftp.lpwd();
            }
        } catch(Exception e) {
            log.error(e);
        }
        return rtnStr;
    }
	

}
