package afnid.rm.rsdt.service;

import afnid.cm.ComDefaultVO;

public class RsdtMntVO extends ComDefaultVO {
	private static final long serialVersionUID = 1L;
	
	//Information pop-up window
	private String rsdtNo;
	private String rsdtSeqNo;
	private String bioKey;
	private String rsdtRgstDd;	
	private String bioRgstDd;	
	private String bioDupDd;	
	private String crdIsuceRqstDd;	
	private String crdIsuceDd;	
	private String fmlyBokNoNum;
	private String fmlyMberNo;
	private String givNm;
	private String surnm;
	private String fthrNm;
	private String mthrNm;
	private String bthDd;
	private String enNm;
	private String pmntAdCdNm;
	private String pmntAdDtlCt;
	private String curtAdDtlCt;
	private String curtAdCdNm;
	private String gdrCdNm;
	
	private String enSurnm;
	private String enGivNm;
	
	private String bsnNm;
	private String dd;
	private String aprvId;
	private String biCfmDd;
	private String aplDd;
	private String fleRcivDd;
	private String crdDitbDd;
	private String crdDitbUserId;
	private String crdExpiryDd;
	private String gdrCd;
	private String hstCnt;
	private String crdDisuseDd;
	private String crdIsuceSrlNo;
	private String erorYn;
	private String crdDitbCd;
	private String crdArvlDd;
	
	
	private String hCrdIsuceRqstDd;
	private String hAplDd;
	private String hBiCfmDd;		
	private String hFleRcivDd;
	private String hCrdArvlDd;
	private String hCrdDitbDd;	
	private String hCrdExpiryDd;
	private String hCrdDisuseDd;
	
	private String gCrdIsuceRqstDd;
	private String gAplDd;
	private String gBiCfmDd;		
	private String gFleRcivDd;
	private String gCrdArvlDd;
	private String gCrdDitbDd;	
	private String gCrdExpiryDd;
	private String gCrdDisuseDd;
	
	private String crdArvlFailYn;
	
	private String gRsdtRgstDd;
	private String gBthDd;
	
	private String hRsdtRgstDd;
	private String hBthDd;
	
	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getBioKey() {
		return bioKey;
	}
	public void setBioKey(String bioKey) {
		this.bioKey = bioKey;
	}
	public String getRsdtRgstDd() {
		return rsdtRgstDd;
	}
	public void setRsdtRgstDd(String rsdtRgstDd) {
		this.rsdtRgstDd = rsdtRgstDd;
	}
	public String getBioRgstDd() {
		return bioRgstDd;
	}
	public void setBioRgstDd(String bioRgstDd) {
		this.bioRgstDd = bioRgstDd;
	}
	public String getBioDupDd() {
		return bioDupDd;
	}
	public void setBioDupDd(String bioDupDd) {
		this.bioDupDd = bioDupDd;
	}
	public String getCrdIsuceRqstDd() {
		return crdIsuceRqstDd;
	}
	public void setCrdIsuceRqstDd(String crdIsuceRqstDd) {
		this.crdIsuceRqstDd = crdIsuceRqstDd;
	}
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public String getCrdDitbDd() {
		return crdDitbDd;
	}
	public void setCrdDitbDd(String crdDitbDd) {
		this.crdDitbDd = crdDitbDd;
	}
	public String getFmlyMberNo() {
		return fmlyMberNo;
	}
	public void setFmlyMberNo(String fmlyMberNo) {
		this.fmlyMberNo = fmlyMberNo;
	}
	public String getGivNm() {
		return givNm;
	}
	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}
	public String getSurnm() {
		return surnm;
	}
	public void setSurnm(String surnm) {
		this.surnm = surnm;
	}
	public String getFthrNm() {
		return fthrNm;
	}
	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}
	public String getMthrNm() {
		return mthrNm;
	}
	public void setMthrNm(String mthrNm) {
		this.mthrNm = mthrNm;
	}
	public String getBthDd() {
		return bthDd;
	}
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	public String getEnNm() {
		return enNm;
	}
	public void setEnNm(String enNm) {
		this.enNm = enNm;
	}
	public String getPmntAdCdNm() {
		return pmntAdCdNm;
	}
	public void setPmntAdCdNm(String pmntAdCdNm) {
		this.pmntAdCdNm = pmntAdCdNm;
	}
	public String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}
	public void setPmntAdDtlCt(String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}
	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}
	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}
	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}
	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}

	public String getFmlyBokNoNum() {
		return fmlyBokNoNum;
	}
	public void setFmlyBokNoNum(String fmlyBokNoNum) {
		this.fmlyBokNoNum = fmlyBokNoNum;
	}
	public String getEnSurnm() {
		return enSurnm;
	}
	public void setEnSurnm(String enSurnm) {
		this.enSurnm = enSurnm;
	}
	public String getEnGivNm() {
		return enGivNm;
	}
	public void setEnGivNm(String enGivNm) {
		this.enGivNm = enGivNm;
	}
	public String getBsnNm() {
		return bsnNm;
	}
	public void setBsnNm(String bsnNm) {
		this.bsnNm = bsnNm;
	}
	public String getDd() {
		return dd;
	}
	public void setDd(String dd) {
		this.dd = dd;
	}
	public String getAprvId() {
		return aprvId;
	}
	public void setAprvId(String aprvId) {
		this.aprvId = aprvId;
	}
	public String getBiCfmDd() {
		return biCfmDd;
	}
	public void setBiCfmDd(String biCfmDd) {
		this.biCfmDd = biCfmDd;
	}
	public String getAplDd() {
		return aplDd;
	}
	public void setAplDd(String aplDd) {
		this.aplDd = aplDd;
	}
	public String getFleRcivDd() {
		return fleRcivDd;
	}
	public void setFleRcivDd(String fleRcivDd) {
		this.fleRcivDd = fleRcivDd;
	}
	public String getCrdDitbUserId() {
		return crdDitbUserId;
	}
	public void setCrdDitbUserId(String crdDitbUserId) {
		this.crdDitbUserId = crdDitbUserId;
	}
	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}
	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}
	public String getGdrCd() {
		return gdrCd;
	}
	
	public String getHstCnt() {
		return hstCnt;
	}
	public void setHstCnt(String hstCnt) {
		this.hstCnt = hstCnt;
	}
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	public String getCrdDisuseDd() {
		return crdDisuseDd;
	}
	public void setCrdDisuseDd(String crdDisuseDd) {
		this.crdDisuseDd = crdDisuseDd;
	}
	public String getCrdIsuceSrlNo() {
		return crdIsuceSrlNo;
	}
	public void setCrdIsuceSrlNo(String crdIsuceSrlNo) {
		this.crdIsuceSrlNo = crdIsuceSrlNo;
	}
	public String getErorYn() {
		return erorYn;
	}
	public void setErorYn(String erorYn) {
		this.erorYn = erorYn;
	}
	public String getCrdDitbCd() {
		return crdDitbCd;
	}
	public void setCrdDitbCd(String crdDitbCd) {
		this.crdDitbCd = crdDitbCd;
	}
	public String gethAplDd() {
		return hAplDd;
	}
	public void sethAplDd(String hAplDd) {
		this.hAplDd = hAplDd;
	}
	public String gethBiCfmDd() {
		return hBiCfmDd;
	}
	public void sethBiCfmDd(String hBiCfmDd) {
		this.hBiCfmDd = hBiCfmDd;
	}
	public String gethFleRcivDd() {
		return hFleRcivDd;
	}
	public void sethFleRcivDd(String hFleRcivDd) {
		this.hFleRcivDd = hFleRcivDd;
	}
	public String gethCrdArvlDd() {
		return hCrdArvlDd;
	}
	public void sethCrdArvlDd(String hCrdArvlDd) {
		this.hCrdArvlDd = hCrdArvlDd;
	}
	public String gethCrdDitbDd() {
		return hCrdDitbDd;
	}
	public void sethCrdDitbDd(String hCrdDitbDd) {
		this.hCrdDitbDd = hCrdDitbDd;
	}
	public String gethCrdExpiryDd() {
		return hCrdExpiryDd;
	}
	public void sethCrdExpiryDd(String hCrdExpiryDd) {
		this.hCrdExpiryDd = hCrdExpiryDd;
	}
	public String gethCrdDisuseDd() {
		return hCrdDisuseDd;
	}
	public void sethCrdDisuseDd(String hCrdDisuseDd) {
		this.hCrdDisuseDd = hCrdDisuseDd;
	}
	public String getgAplDd() {
		return gAplDd;
	}
	public void setgAplDd(String gAplDd) {
		this.gAplDd = gAplDd;
	}
	public String getgBiCfmDd() {
		return gBiCfmDd;
	}
	public void setgBiCfmDd(String gBiCfmDd) {
		this.gBiCfmDd = gBiCfmDd;
	}
	public String getgFleRcivDd() {
		return gFleRcivDd;
	}
	public void setgFleRcivDd(String gFleRcivDd) {
		this.gFleRcivDd = gFleRcivDd;
	}
	public String getgCrdArvlDd() {
		return gCrdArvlDd;
	}
	public void setgCrdArvlDd(String gCrdArvlDd) {
		this.gCrdArvlDd = gCrdArvlDd;
	}
	public String getgCrdDitbDd() {
		return gCrdDitbDd;
	}
	public void setgCrdDitbDd(String gCrdDitbDd) {
		this.gCrdDitbDd = gCrdDitbDd;
	}
	public String getgCrdExpiryDd() {
		return gCrdExpiryDd;
	}
	public void setgCrdExpiryDd(String gCrdExpiryDd) {
		this.gCrdExpiryDd = gCrdExpiryDd;
	}
	public String getgCrdDisuseDd() {
		return gCrdDisuseDd;
	}
	public void setgCrdDisuseDd(String gCrdDisuseDd) {
		this.gCrdDisuseDd = gCrdDisuseDd;
	}
	public String getCrdArvlDd() {
		return crdArvlDd;
	}
	public void setCrdArvlDd(String crdArvlDd) {
		this.crdArvlDd = crdArvlDd;
	}

	public String gethCrdIsuceRqstDd() {
		return hCrdIsuceRqstDd;
	}
	public void sethCrdIsuceRqstDd(String hCrdIsuceRqstDd) {
		this.hCrdIsuceRqstDd = hCrdIsuceRqstDd;
	}
	public String getgCrdIsuceRqstDd() {
		return gCrdIsuceRqstDd;
	}
	public void setgCrdIsuceRqstDd(String gCrdIsuceRqstDd) {
		this.gCrdIsuceRqstDd = gCrdIsuceRqstDd;
	}
	public String getCrdArvlFailYn() {
		return crdArvlFailYn;
	}
	public void setCrdArvlFailYn(String crdArvlFailYn) {
		this.crdArvlFailYn = crdArvlFailYn;
	}
	public String getgRsdtRgstDd() {
		return gRsdtRgstDd;
	}
	public void setgRsdtRgstDd(String gRsdtRgstDd) {
		this.gRsdtRgstDd = gRsdtRgstDd;
	}
	public String getgBthDd() {
		return gBthDd;
	}
	public void setgBthDd(String gBthDd) {
		this.gBthDd = gBthDd;
	}

	public String gethRsdtRgstDd() {
		return hRsdtRgstDd;
	}
	public void sethRsdtRgstDd(String hRsdtRgstDd) {
		this.hRsdtRgstDd = hRsdtRgstDd;
	}
	public String gethBthDd() {
		return hBthDd;
	}
	public void sethBthDd(String hBthDd) {
		this.hBthDd = hBthDd;
	}


}
