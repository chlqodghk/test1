package afnid.rm.rsdt.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import afnid.rm.rsdt.service.RsdtMntService;
import afnid.rm.rsdt.service.RsdtMntVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;

/** 
 * This service class is biz-class of monitor
 * and implements RsdtMntService class.
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.11.03
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.11.03  	    moon soo kim 		                   Create
 *
 * </pre>
 */
@Service("rsdtMntService")
public class RsdtMntServiceImpl extends AbstractServiceImpl implements RsdtMntService {
	/** RsdtMdfcDAO */
    @Resource(name="rsdtMntDAO")
    private RsdtMntDAO dao;

    /** ID Generation */
    //@Resource(name="egovIdGnrService")    
    //private EgovIdGnrService egovIdGnrService;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    
    
	/**
	 * Biz-method for retrieving be or not existence of citizen. <br>
	 *
	 * @param vo Input item for retrieving  be or not existence of citizen(RsdtMntVO).
	 * @return int 
	 * @exception Exception
	 */
    public int searchRsdtInfrCn(RsdtMntVO vo) throws Exception {
        return dao.selectRsdtInfrCn(vo);
    }
    
    /**
	 * Biz-method for retrieving of citizen card traceability information. <br>	 *
	 *
	 * @param vo Input item for retrieving citizen card traceability information(RsdtMntVO).
	 * @return List citizen card traceability information
	 * @exception Exception
	 */
	public RsdtMntVO searchRsdtPrcssStusInfr(RsdtMntVO vo) throws Exception {
   		return dao.selectRsdtPrcssStusInfr(vo);
	}
	
    /**
	 * Biz-method for retrieving of citizen card traceability information(history). <br>	 *
	 *
	 * @param vo Input item for retrieving of citizen card traceability information(history).RsdtMntVO).
	 * @return List citizen card traceability information(history)
	 * @exception Exception
	 */
	public List<RsdtMntVO> searchListRsdtPrcssHst(RsdtMntVO vo) throws Exception {
   		return dao.selectListRsdtPrcssHst(vo);
	}	
	
	/**
	 * Biz-method for retrieving be or not existence of citizen(bio duplication). <br>
	 *
	 * @param vo Input item for retrieving bbe or not existence of citizen(bio duplication)(RsdtMntVO).
	 * @return int 
	 * @exception Exception
	 */
    public int searchRsdtBiioDupCn(RsdtMntVO vo) throws Exception {
        return dao.selectRsdtBiioDupCn(vo);
    }	
	
}