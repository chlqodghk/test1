package afnid.rm.rsdt.service.impl;

import java.util.ArrayList;
import java.util.List;

public class MRZUtil {
	private final static char FILLER = '<';
	private final static int MRZ_LEN = 90;
	
	//MRZ string import
   	public static String getMrzStr(
   		String nationality
   		,String nid_1
   		,String nid_2
   		,String yyMmDd_birth
   		,String sex
   		,String yyMmDd_expiry
   		,String surName
   		,String givenName
   	) {
   		char[] mrzChars = getMrzChars(
   	   		nationality
   	   		,nid_1
   	   		,nid_2
   	   		,yyMmDd_birth
   	   		,sex
   	   		,yyMmDd_expiry
   	   		,surName
   	   		,givenName
   		);

   		
   		setChkDigit(mrzChars, 15, 6, 14); //first chk digit set
   		
   		setChkDigit(mrzChars, 37, 31, 36); //second chk digit set
   		
   		setChkDigit(mrzChars, 45, 39, 44); //third chk digit set
   		
   		setFourthChkDigit(mrzChars, 60, 6, 30, 31, 37, 39, 45, 49, 59); //fourth chk digit set
   		
   		return new String(mrzChars);

   	}
   	
   	//Creating MRZ char array to a given data (data given to make MRZ char array)
	private static char[] getMrzChars(
   		String nationality /* */
   		,String nid_1
   		,String nid_2
   		,String yyMmDd_birth
   		,String sex
   		,String yyMmDd_expiry
   		,String surName
   		,String givenName
	) {
   		char[] mrzChars = getDefaultChars();
   		
   		setValToMrzChars(mrzChars, 1, 1, "I");
   		setValToMrzChars(mrzChars, 3, 5, nationality);
   		setValToMrzChars(mrzChars, 6, 13, nid_1);
   		setValToMrzChars(mrzChars, 16, 20, nid_2);
   		setValToMrzChars(mrzChars, 31, 36, yyMmDd_birth);
   		setValToMrzChars(mrzChars, 38, 38, sex);
   		setValToMrzChars(mrzChars, 39, 44, yyMmDd_expiry);
   		setValToMrzChars(mrzChars, 46, 48, nationality);
   		setValToMrzChars(mrzChars, 61, 90, getFullNameForMrz(surName, givenName));

   		return mrzChars;
	}
	
	//Creating a basic MRZ char array (the default make MRZ char array)
	//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
	private static char[] getDefaultChars() {
	   	char[] defaultChars = new char[MRZ_LEN];
		for (int i = 0; i < defaultChars.length; i++) {
			defaultChars[i] = FILLER;
		}
		return defaultChars;
	}
	
	//To set the value at which the (a position corresponding to a value in the set)
   	private static void setValToMrzChars(char[] mrzChars, int fromScope, int toScope, String val) {
   		int curPosition = fromScope;
   		
   		if (val == null){
   			return;
   		}
   		
   		for (int i = 0; i < val.length(); i++) {
   			if (curPosition <= toScope) {
   	   			mrzChars[curPosition - 1] = val.charAt(i);
   	   			curPosition = curPosition + 1;   				
   			}
   		}
   	}
   	
   	//Chk digit in a position to set the (chk digit in the position corresponding to set)
   	private static void setChkDigit(
   		char[] mrzChars 
   		,int chkDigitPosition
   		,int fromScope
   		,int toScope
   	) {
   		List<Integer> numericVals = getNumericVals(mrzChars, fromScope, toScope);
   		
   		int chkDigit = 0;
   		chkDigit = getChkDigitVal(numericVals);
   		
   		setValToMrzChars(mrzChars, chkDigitPosition, chkDigitPosition, Integer.toString(chkDigit));
   	}
   	
   	//Chk digit to set the fourth (4th chk digit the scope of this dog. (Chk digit to set the fourth (4th chk digit the scope of this dog.)
   	private static void setFourthChkDigit(
   		char[] mrzChars 
   		,int chkDigitPosition
   		,int fromScope1
   		,int toScope1
   		,int fromScope2
   		,int toScope2
   		,int fromScope3
   		,int toScope3
   		,int fromScope4
   		,int toScope4
   	) {
   		List<Integer> numericVals = new ArrayList<Integer>();
   		addValsFromList(numericVals, getNumericVals(mrzChars, fromScope1, toScope1));
   		addValsFromList(numericVals, getNumericVals(mrzChars, fromScope2, toScope2));
   		addValsFromList(numericVals, getNumericVals(mrzChars, fromScope3, toScope3));
   		addValsFromList(numericVals, getNumericVals(mrzChars, fromScope4, toScope4));
   		
   		
   		int chkDigit = 0;
   		chkDigit = getChkDigitVal(numericVals);
   		
   		setValToMrzChars(mrzChars, chkDigitPosition, chkDigitPosition, Integer.toString(chkDigit));
   	}
   	
   	private static void addValsFromList(List<Integer> toList,  List<Integer> fromList) {
   		for (int val : fromList) {
   			toList.add(val);
   		}
   	}
   	
   	//chk digit save (chk digit save)
   	//ex >
   	//sample data element  :  A  B  2  1  3  4  <  <  <
   	//numeric values       : 10 11  2  1  3  4  0  0  0  
   	//weighting            :  7  3  1  7  3  1  7  3  1
   	//----------------------------------------------------
   	//products(numeric values * weighting)
   	//                     : 70 33  2  7  9  4  0  0  0
   	//sumOfProducts        : 70 + 33 + 2 + 7 + 9 + 4 + 0 + 0 = 125
   	//remainder            : 125/10 = 12, remainder 5
   	//check digit          : 5
   	private static int getChkDigitVal(List<Integer> numericVals) {
   		//weighting
   		List<Integer> weightingVals = getWeightingVals(numericVals.size());
   		
   		//products(numeric values * weighting)
   		List<Integer> productVals = new ArrayList<Integer>();
   		int productVal = 1;
   		for (int i = 0; i < numericVals.size(); i++) {
   			productVal = numericVals.get(i) * weightingVals.get(i);
   			productVals.add(productVal);
   		}
   		
   		
   		//sumOfProducts
   		int sumOfProducts = 0;
   		for (int i = 0; i < productVals.size(); i++) {
   			sumOfProducts = sumOfProducts + productVals.get(i);
   		}
   		
   		
   		//remainder
   		int remainder = 0;
   		remainder = sumOfProducts % 10;
   		
   		
   		return remainder;
   	}
   	
   	//Obtaining weights ..... 7317317317 (7317317317 obtain weights .....)
   	private static List<Integer> getWeightingVals(int len) {
   		List<Integer> weightingVals = new ArrayList<Integer>();
   		int weightingVal = 0;
   		//weights => 731731731....
   		for (int i = 0; i < len; i++) {
   			if ( i%3 == 0) {
   				weightingVal = 7;
   			} else if ( i%3 == 1) {
   				weightingVal = 3;
   			} else if ( i%3 == 2) {
   				weightingVal = 1;
   			}
   			weightingVals.add(weightingVal);
   		}
   		return weightingVals;
   	}
   	
   	//chk digit range to save the equivalent of between 10 to 35 A ~ Z, '<' changed to 0 and list extraction (chk digit range to save the equivalent of between 10 to 35 A ~ Z, '<' to 0 extract the list of changes)
   	private static List<Integer> getNumericVals(char[] mrzChars, int fromScope, int toScope) {
   		int asciiVal = 0;
   		int num = 0;
   		List<Integer> numericVals = new ArrayList<Integer>(toScope - fromScope);

   		for (int i = fromScope; i <= toScope; i++) {
   			asciiVal = (int) mrzChars[i - 1];
   			//0 ~ 9 => 0 ~ 9
   			//A ~ Z => 10 ~ 35
   			//< => 0
   			if (mrzChars[i - 1] == FILLER) {
   				num = 0;
   			} else if (asciiVal >= 48 && asciiVal <= 57) { // 0 ~ 9
   				num = asciiVal - 48;
   			} else if (asciiVal >= 65 && asciiVal <= 90) { //A ~ Z
   				num = asciiVal - 55;
   			}
   			numericVals.add(num);
   		}
   		return numericVals;
   	}
   	
   	//Get full name for MRZ (MRZ full name for the import)
   	private static String getFullNameForMrz(String surName, String givenName) {
   		/*
   		String name = names;
   		if (name == null){
   			name = "";
   		}
   		
        int lastIndexOf = name.lastIndexOf(' ');
        
        
        String surName = "";
        String givenName = "";
        String fullName = "";
        
        if (lastIndexOf > 0) {
        	surName = name.substring(lastIndexOf + 1, name.length());
        	givenName = name.substring(0, lastIndexOf);
        	fullName = surName + FILLER + FILLER + givenName;
        } else {
        	fullName = name;
        }
        
        fullName = fullName.replace(' ', FILLER);
		
   		*/
   		String fullName = "";
   		String surNm = surName;
   		String givenNm = givenName;
   		
   		if (surNm == null){
   			surNm = "";
   		}
   		if (givenNm == null){
   			givenNm = "";
   		}

   		if("".equals(surNm) ){
   			fullName = givenNm;
   			
   		} else {
   			fullName = surNm + "  "  + givenNm;
   		}
   		
   		fullName = fullName.replace(' ', FILLER);
   		
   		return fullName;
   	}

}
