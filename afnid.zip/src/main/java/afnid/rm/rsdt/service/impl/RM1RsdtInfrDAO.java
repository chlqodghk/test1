package afnid.rm.rsdt.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.rm.rsdt.service.RsdtInfrVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;



/** 
 * This class is Database Access Object of common
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04`
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.04  		BH Choi         		Create
 *
 * </pre>
 */
@Repository("RM1rsdtInfoDAO")
public class RM1RsdtInfrDAO extends EgovAbstractDAO {
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }

	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RcptCardVO).
	 * @return RcptCardDAO Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<egovframework.rte.psl.dataaccess.util.EgovMap> selectXmlGenerate(RsdtInfrVO vo) throws Exception{
		return list("RM1rsdtInfoDAO.selectXmlGenerate", vo);
	}
    	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RcptCardVO).
	 * @return RcptCardDAO Retrieve list information of program
	 * @exception Exception
	 */
	public EgovMap selectXmlBlobDpp(RsdtInfrVO vo) throws Exception{
		return (EgovMap)selectByPk("RM1rsdtInfoDAO.selectXmlBlobDpp", vo);
	}
	
	
	/**
	 * DAO-method for registering information of new resident. <br>
	 *
	 * @param vo Input item for registering new program(RsdtInfoVO).
	 * @return RsdtInfoVO Primary Key value of registered resident
	 * @exception Exception
	 */
	public void insertIntoXmlBatchSend(RsdtInfrVO vo) throws Exception{
		insert("RM1rsdtInfoDAO.insertIntoXmlBatchSend", vo);
	}	
	
    /**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtInfrVO).
	 * @return int Registration number placed
	 * @exception Exception
	 */
    public String selectDppDbDatTime(RsdtInfrVO vo) {
        return (String)selectByPk("RM1rsdtInfoDAO.selectDppDbDatTime", vo);
    }
    
    
	/**
	 * DAO-method for registering information of new family book history. <br>
	 *
	 * @param vo Input item for registering new program(RsdtInfoVO).
	 * @return RsdtInfoVO Primary Key value of registered resident
	 * @exception Exception
	 */
	public void insertImCrdIsuTb(RsdtInfrVO vo) throws Exception{
		insert("RM1rsdtInfoDAO.insertImCrdIsuTb", vo);
	}
	
	/**
	 * DAO-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfoVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectIntoXmlBatch(RsdtInfrVO vo) {
        return (Integer)selectByPk("rsdtInfoDAO.selectIntoXmlBatch", vo);
    }
    
	/**
	 * DAO-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfoVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectImCrdDlvrTb(RsdtInfrVO vo) {
        return (Integer)selectByPk("rsdtInfoDAO.selectImCrdDlvrTb", vo);
    }
    
    /**
	 * DAO-method for registering information of new resident. <br>
	 *
	 * @param vo Input item for registering new program(RsdtInfoVO).
	 * @return RsdtInfoVO Primary Key value of registered resident
	 * @exception Exception
	 */
	public void insertImCrdDlvrTb(RsdtInfrVO vo) throws Exception{
		insert("rsdtInfoDAO.insertImCrdDlvrTb", vo);
	}    
}
