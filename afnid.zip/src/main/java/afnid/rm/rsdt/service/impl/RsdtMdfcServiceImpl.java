package afnid.rm.rsdt.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.cmm.error.NidException;
import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.pkiif.ccm.RMCCM;
import afnid.pkiif.ccm.RMCCM_Service;
import afnid.rm.bioif.service.BioIfInfrService;
import afnid.rm.crd.service.CrdFndService;
import afnid.rm.rsdt.service.RsdtInfrService;
import afnid.rm.rsdt.service.RsdtInfrVO;
import afnid.rm.rsdt.service.RsdtMdfcService;
import afnid.rm.rsdt.service.RsdtMdfcVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of common
 * and implements FmlyInfoService class.
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.04  		BH Choi         		Create
 *
 * </pre>
 */
@Service("rsdtMdfcService")
public class RsdtMdfcServiceImpl extends AbstractServiceImpl implements RsdtMdfcService {
	/** RsdtMdfcDAO */
    @Resource(name="rsdtMdfcDAO")
    private RsdtMdfcDAO dao;
    
    @Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtDao;
    
    @Resource(name="lgDAO")
    private LgDAO lgDao;
    
    /** ID Generation */
    //@Resource(name="egovIdGnrService")    
    //private EgovIdGnrService egovIdGnrService;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    @Resource(name = "bioIfInfrService")
    private BioIfInfrService bioIfService;
    
    @Resource(name = "rsdtInfoService")
    private RsdtInfrService rsdtInfrService;

    @Resource(name = "crdFndService")
    private CrdFndService crdFndService;
    
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    private int sendCnt = 0;
    /**
   	 * Biz-method for retrieving of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
   	 * @return EgovMap object of program
   	 * @exception Exception
   	 */
   	public EgovMap searchRsdtMdfc(RsdtMdfcVO vo) throws Exception {
   		EgovMap result = null;
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
   		
   		if(vo != null && vo.getRsdtSeqNo() != null && vo.getMdfctSeqNo() != null && !vo.getRsdtSeqNo().equals("") && !vo.getMdfctSeqNo().equals("")){
   			vo.setTamCd(user.getTamCd());
   			result = dao.selectRsdtMdfctInfr(vo);
   		}else{
   			RsdtMdfcVO mdfc = dao.selectRsdtMdfcIsFlag(vo);
	   		if(mdfc != null){//edit
	   			if(mdfc.getRsdtSeqNo() != null && mdfc.getMdfctSeqNo() != null){
	   				vo.setTamCd(user.getTamCd());
	   				result = dao.selectRsdtMdfctInfr(mdfc);
	   			}
	   		}else{//new
	   			mdfc = new RsdtMdfcVO();
	   			mdfc.setRsdtSeqNo(vo.getDescRsdtSeqNo());
	   			result = dao.selectRsdtInfr(mdfc);

	   			String msg = rsdtInfrService.searchRsdtCrdIsuAppStus(vo.getViewRsdtNo(), "msg", null);
	   			if(msg != null && !"".equals(msg)){
	   				result.put("crdIsuStusMsg", msg);
	   			}

	   			if("".equals(msg)){
	   				msg = rsdtInfrService.searchRsdtRvctgStus(vo.getViewRsdtNo(), "xcode");
	   				if(msg != null && !"".equals(msg)){
		   				result.put("crdIsuStusMsg", msg);
		   			}
	   			}
	   			
	   		}
   		}
   		return result;
   	}
   	
   	
    /**
   	 * Biz-method for retrieving of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
   	 * @return EgovMap object of program
   	 * @exception Exception
   	 */
   	public EgovMap searchRsdtMdfcAprv(RsdtMdfcVO vo) throws Exception {
   		EgovMap result = null;
		result = dao.selectRsdtMdfctAprvInfo(vo);

   		return result;
   	}
   	
   	/**
   	 * Biz-method for retrieving of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
   	 * @return String object of program
   	 * @exception Exception
   	 */
   	public String searchRsdtInfrSeq(RsdtMdfcVO vo) throws Exception {
   		String result = null;
   		result = dao.selectRsdtInfrSeq(vo);
   		return result;
   	}

   	
   	
   	
   	/**
   	 * Biz-method for retrieving of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
   	 * @return EgovMap Retrieve of program
   	 * @exception Exception
   	 */
   	public EgovMap searchListRsdtMdfcNatFrgnLang(RsdtMdfcVO vo) throws Exception {
   		EgovMap result = new EgovMap();
   		List<EgovMap> em = null;
   		RsdtMdfcVO mdfc = dao.selectRsdtMdfcIsFlag(vo);
   		if(mdfc != null){
   			if(mdfc.getRsdtSeqNo() != null && mdfc.getMdfctSeqNo() != null){
   				em = dao.selectRmOthrNatLangBfTb(mdfc);
   				result.put("othrNatLangList", em);
   				em = dao.selectRmOthrNatLangAfTb(mdfc);
   	   			result.put("afOthrNatLangList", em);
   	   			em = dao.selectRmFrgnLangBfTb(mdfc);
   	   			result.put("frgnLangList", em);
   	   			em = dao.selectRmFrgnLangAfTb(mdfc);
   	   			result.put("afFrgnLangList", em);
   			}
   		}else{
   			mdfc = new RsdtMdfcVO();
   			mdfc.setRsdtSeqNo(vo.getDescRsdtSeqNo());
   			em = dao.selectRmOthrNatLangTb(mdfc);
   			result.put("othrNatLangList", em);
   			result.put("afOthrNatLangList", em);
   			em = dao.selectRmFrgnLangTb(mdfc);
   			result.put("frgnLangList", em);
   			result.put("afFrgnLangList", em);
   		}
   		return result;
   	}
   	
   	
   	
   	
   	
   	
   	/**
   	 * Biz-method for retrieving of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
   	 * @return boolean Whether to register
   	 * @exception Exception
   	 */
   	public boolean addRsdtMdfc(RsdtMdfcVO vo) throws Exception {
   		boolean flag = false;
   		if(vo != null){
   			if(vo.getRsdtSeqNo() != null && vo.getMdfctSeqNo() != null){
   				LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
   				vo.setUserId(user.getUserId());
   				if(!vo.getRsdtSeqNo().equals("") && !vo.getMdfctSeqNo().equals("")){
   					//Existing update
   					dao.updateRsdtMdfctInfr(vo);
   					RsdtMdfcVO lst = new RsdtMdfcVO();
   					lst.setRsdtSeqNo(vo.getRsdtSeqNo());
   					lst.setMdfctSeqNo(vo.getMdfctSeqNo());
   					lst.setUserId(user.getUserId());
   					
   					boolean crdIssFlag = searchRsdtMdfcCrdIssTo(lst);
   					if(crdIssFlag){
   						lst.setCrdReisuceYn("Y");
   					}else{
   						lst.setCrdReisuceYn("N");
   					}
   					dao.updateRsdtMdfctTbCrdReisuceYn(lst);
   					
   					
   					dao.deleteRsdtMdfctNatLangAfTb(vo);
   					String[] afNatLangCd = vo.getAfNatLangCd();
   					if(afNatLangCd != null && afNatLangCd.length > 0){
   						for(int i = 0 ; i < afNatLangCd.length; i++){
   							if(afNatLangCd[i] != null && !afNatLangCd[i].equals("")){
   								lst.setLstLangCd(afNatLangCd[i]);
   								dao.insertRsdtMdfctNatLangAfTb(lst);
   							}
   						}
   					}
   					lst.setLstLangCd("");
   					dao.deleteRsdtMdfctFrgnLangAfTb(vo);
   					String[] afFrgnLangCd = vo.getAfFrgnLangCd();
   					if(afFrgnLangCd != null && afFrgnLangCd.length > 0){
   						for(int i = 0 ; i < afFrgnLangCd.length; i++){
   							if(afFrgnLangCd[i] != null && !afFrgnLangCd[i].equals("")){
   								lst.setLstLangCd(afFrgnLangCd[i]);
   								dao.insertRsdtMdfctFrgnLangAfTb(lst);
   							}
   						}
   					}
   					flag = true;
   				}else{
   					//New
   					vo.setTamLedrCfmYn("N");
   					String orgnzCd = user.getOrgnzCd();
   					String rgstOrgnzCd = user.getOrgnzClsCd()+orgnzCd+user.getTamCdNm();
   					vo.setRgstOrgnzCd(rgstOrgnzCd);
   					String mdfctSeqNo = dao.insertRsdtMdfctInfr(vo);
   					vo.setTamLedrCfmYn("");
   					RsdtMdfcVO lst = new RsdtMdfcVO();
   					lst.setRsdtSeqNo(vo.getRsdtSeqNo());
   					lst.setMdfctSeqNo(mdfctSeqNo);
   					lst.setUserId(user.getUserId());
   					
   					boolean crdIssFlag = searchRsdtMdfcCrdIssTo(lst);
   					if(crdIssFlag){
   						lst.setCrdReisuceYn("Y");
   					}else{
   						lst.setCrdReisuceYn("N");
   					}
   					dao.updateRsdtMdfctTbCrdReisuceYn(lst);
   					
   					String[] afNatLangCd = vo.getAfNatLangCd();
   					if(afNatLangCd != null && afNatLangCd.length > 0){
   						for(int i = 0 ; i < afNatLangCd.length; i++){
   							if(afNatLangCd[i] != null && !afNatLangCd[i].equals("")){
   								lst.setLstLangCd(afNatLangCd[i]);
   								dao.insertRsdtMdfctNatLangAfTb(lst);
   							}
   						}
   					}
   					lst.setLstLangCd("");
   					String[] afFrgnLangCd = vo.getAfFrgnLangCd();
   					if(afFrgnLangCd != null && afFrgnLangCd.length > 0){
   						for(int i = 0 ; i < afFrgnLangCd.length; i++){
   							if(afFrgnLangCd[i] != null && !afFrgnLangCd[i].equals("")){
	   							lst.setLstLangCd(afFrgnLangCd[i]);
	   							dao.insertRsdtMdfctFrgnLangAfTb(lst);
   							}
   						}
   					}
   					lst.setLstLangCd("");
   					String[] natLangCd = vo.getNatLangCd();
   					if(natLangCd != null && natLangCd.length > 0){
   						for(int i = 0 ; i < natLangCd.length; i++){
   							lst.setLstLangCd(natLangCd[i]);
   							dao.insertRsdtMdfctNatLangBfTb(lst);
   						}
   					}
   					lst.setLstLangCd("");
   					String[] frgnLangCd = vo.getFrgnLangCd();
   					if(frgnLangCd != null && frgnLangCd.length > 0){
   						for(int i = 0 ; i < frgnLangCd.length; i++){
   							lst.setLstLangCd(frgnLangCd[i]);
   							dao.insertRsdtMdfctFrgnLangBfTb(lst);
   						}
   					}
   					vo.setMdfctSeqNo(mdfctSeqNo);
   					flag = true;
   				}
   			}
   		}
   		return flag;
   	}
   	
   	
   	
   	
   	
   	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchListRsdtMdfcAprv(RsdtMdfcVO vo) throws Exception {
      		return dao.selectListRsdtMdfcAprv(vo);
   	}

   	/**
	 * Biz-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
   	public int searchListRsdtMdfcAprvTotCn(RsdtMdfcVO vo) throws Exception {
        return dao.selectListRsdtMdfcAprvTotCn(vo);
	}
   	
   	
   	
   	
   	
   	/**
	 * Biz-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return boolean Modification of Program
	 * @exception Exception
	 */
   	public boolean modifyRsdtMdfcVfy(RsdtMdfcVO vo) throws Exception {
        boolean result = false;
        LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUserId(user.getUserId());
		//Existing update
		int cnt = dao.updateRsdtMdfctInfr(vo);
		RsdtMdfcVO lst = new RsdtMdfcVO();
		lst.setRsdtSeqNo(vo.getRsdtSeqNo());
		lst.setMdfctSeqNo(vo.getMdfctSeqNo());
		lst.setUserId(user.getUserId());
		
		boolean crdIssFlag = searchRsdtMdfcCrdIssTo(lst);
		if(crdIssFlag){
			lst.setCrdReisuceYn("Y");
		}else{
			lst.setCrdReisuceYn("N");
		}
		dao.updateRsdtMdfctTbCrdReisuceYn(lst);
		
		dao.deleteRsdtMdfctNatLangAfTb(vo);
		String[] afNatLangCd = vo.getAfNatLangCd();
		if(afNatLangCd != null && afNatLangCd.length > 0){
			for(int i = 0 ; i < afNatLangCd.length; i++){
				if(afNatLangCd[i] != null && !afNatLangCd[i].equals("")){
					lst.setLstLangCd(afNatLangCd[i]);
					dao.insertRsdtMdfctNatLangAfTb(lst);
				}
			}
		}
		lst.setLstLangCd("");
		dao.deleteRsdtMdfctFrgnLangAfTb(vo);
		String[] afFrgnLangCd = vo.getAfFrgnLangCd();
		if(afFrgnLangCd != null && afFrgnLangCd.length > 0){
			for(int i = 0 ; i < afFrgnLangCd.length; i++){
				if(afFrgnLangCd[i] != null && !afFrgnLangCd[i].equals("")){
					lst.setLstLangCd(afFrgnLangCd[i]);
					dao.insertRsdtMdfctFrgnLangAfTb(lst);
				}
			}
		}

		if(cnt > 0){
			result = true;
		}	
        return result;
	}
   	
	/**
	 * Biz-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return boolean For approval of Program
	 * @exception Exception
	 */
   	public EgovMap aprvRsdtMdfc(RsdtMdfcVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
   		String userId = user.getUserId();
   		EgovMap apEm = new EgovMap();
   		String[] msg ={"","","",""};
   		
   		sendCnt = 0;
   		String rsdtNo = null;
		String bioKey = null;
		String dupYn = null;
		byte [] bioFle = null;        
        ArrayList<String> result = new ArrayList<String>();
        String pkiIfNum = "";
        //String pkiEnid = "";
        //int status = 0;
        String insUpd = "i";
		vo.setUserId(user.getUserId());
		vo.setTamLedrCfmYn("Y");
		try{
			
			//Existing update
			int cnt = dao.updateRsdtMdfctInfr(vo);
			RsdtMdfcVO lst = new RsdtMdfcVO();
			lst.setRsdtSeqNo(vo.getRsdtSeqNo());
			lst.setMdfctSeqNo(vo.getMdfctSeqNo());
			lst.setUserId(user.getUserId());
			
			boolean crdIssFlag = searchRsdtMdfcCrdIssTo(lst);
			if(crdIssFlag){
				lst.setCrdReisuceYn("Y");
			}else{
				lst.setCrdReisuceYn("N");
			}
			dao.updateRsdtMdfctTbCrdReisuceYn(lst);
			
			dao.deleteRsdtMdfctNatLangAfTb(vo);
			String[] afNatLangCd = vo.getAfNatLangCd();
			if(afNatLangCd != null && afNatLangCd.length > 0){
				for(int i = 0 ; i < afNatLangCd.length; i++){
					if(afNatLangCd[i] != null && !afNatLangCd[i].equals("")){
						lst.setLstLangCd(afNatLangCd[i]);
						dao.insertRsdtMdfctNatLangAfTb(lst);
					}
				}
			}
			lst.setLstLangCd("");
			dao.deleteRsdtMdfctFrgnLangAfTb(vo);
			String[] afFrgnLangCd = vo.getAfFrgnLangCd();
			if(afFrgnLangCd != null && afFrgnLangCd.length > 0){
				for(int i = 0 ; i < afFrgnLangCd.length; i++){
					if(afFrgnLangCd[i] != null && !afFrgnLangCd[i].equals("")){
						lst.setLstLangCd(afFrgnLangCd[i]);
						dao.insertRsdtMdfctFrgnLangAfTb(lst);
					}
				}
			}			
			
						
			boolean printFlag = searchRsdtMdfcCrdIssTo(vo);
			
    		if(printFlag){
    			msg[2]= nidMessageSource.getMessage("reisuceByInfrChng.msg");
    			
    			List<String> list = crdFndService.modifyCrdFndPrcssStus(vo.getRsdtNo(), "4", "", "39");
    			if(list != null && !list.isEmpty()){
    				StringBuffer sb = new StringBuffer();
    				for(int i = 0 ; i < list.size(); i++){
    					if(i < list.size()-1){
    						sb.append(", ");
    					}
    					String str = list.get(i);
    					sb.append(str);
    				}
    				msg[1]= nidMessageSource.getMessage("rgstDuseObjt.msg", new String[]{sb.toString()});
    				
    			}        			
    		}

    		int bhtRgst = dao.selectBthRgst(vo);
			if(bhtRgst == 1){
				int adultAge = propertiesService.getInt("adultAge");
		   		vo.setAdultAge(String.valueOf(adultAge));
				dao.updateBthRgstMdfct(vo);
			}
			
			int resultCnt = dao.updateRsdtMdfcAprv(vo);
			
			if(resultCnt > 0){
				//Residents history table
				dao.insertRsdtInfrHst(vo);
				//Residents change history table
				vo.setUdtWrkCd("2");
				vo.setOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd());	
				
				int cardisu = dao.selectRsdtMdfcCrdIssTo(vo);
				if(cardisu > 1){
					cardisu = dao.selectIssueCrd(vo);
					if(cardisu == 1){
						boolean cardisuFlag = true;
						EgovMap ems = rsdtDao.selectRsdtInfrDat(vo.getRsdtSeqNo());
						if(ems != null && ems.get("rsdtStusCd") != null){
				        	int rsdtStusCd = ((BigDecimal)ems.get("rsdtStusCd")).intValue();
				        	if(rsdtStusCd != 1){
				        		cardisuFlag = false;
				        	}
				        }
						if(cardisuFlag){
							vo.setCardisuFlag("true");
						}
					}
				}
				resultCnt = dao.updateRsdtMdfcToRsdtInfr(vo);

				dao.deleteOthrNatLang(vo);
				dao.deleteFrgnLang(vo);
				dao.insertOthrNatLangTb(vo);
				dao.insertFrgnLangTb(vo);
				
				if(bhtRgst == 1){
					String tamLedrCfmYn = vo.getTamLedrCfmYn();
					vo.setTamLedrCfmYn("Y");
					vo.setUserId(userId);
					int adultAge = propertiesService.getInt("adultAge");
			   		vo.setAdultAge(String.valueOf(adultAge));
					dao.updateBthRgst(vo);
					vo.setTamLedrCfmYn(tamLedrCfmYn);
				}
				
				if(resultCnt > 0){
					msg[2]= "OK";
				}
				
				int resultCrdIssCnt = dao.selectRsdtMdfcCrdIssTo(vo);
				if(resultCrdIssCnt > 1){
					pkiIfNum = "3";
					int chngEng = dao.selectRsdtMdfcCrdIssToEng(vo);
					if(chngEng > 1){
						pkiIfNum = "2";
					}
					//Replacement card is the target.
					resultCrdIssCnt = dao.selectIssueCrd(vo);
					if(resultCrdIssCnt == 1){
						boolean rsdtFlag = true;
						EgovMap ems = rsdtDao.selectRsdtInfrDat(vo.getRsdtSeqNo());
						if(ems != null && ems.get("rsdtStusCd") != null){
				        	int rsdtStusCd = ((BigDecimal)ems.get("rsdtStusCd")).intValue();
				        	if(rsdtStusCd != 1){
				        		rsdtFlag = false;
				        	}
				        }
						if(rsdtFlag){
							//Registration card Issuance Information
							dao.insertIfCrdIsuTb(vo, pkiIfNum);
							// 2 change to state residents cards on citizen table
							dao.updateRsdtInfrCrdStusCd(vo);
						}
					}
					if(bhtRgst == 1){
						//Registration card Issuance Information
						pkiIfNum = "1";
						dao.insertIfCrdIsuTb(vo, pkiIfNum);
						// 2 change to state residents cards on citizen table
						dao.updateRsdtInfrCrdStusCd(vo);
					}
				}else{
					String chipResult = dao.selectRsdtMdfcCrdChipChange(vo);
					if(chipResult != null && !"".equals(chipResult)){
						rsdtNo = vo.getRsdtNo();
						String lgSeqNo = lgDao.insertPubKeyIfLg(userId, rsdtNo, "20", "1", "2", chipResult);
						msg[3] = lgSeqNo;
					}
				}
				
				RsdtInfrVO vos = new RsdtInfrVO();
    			vos.setRsdtSeqNo(vo.getRsdtSeqNo());
    			vos.setSgnt(vo.getSgnt());
    			String resultSgnt = rsdtInfrService.getXmlData(vos.getSgnt(), "Signature");
    	   		if(resultSgnt != null && resultSgnt.length() > 0){
    		   		vos.setSgnt(resultSgnt);
    		   		rsdtDao.updateRsdtInfrSgnt(vos);
    	   		}
    	   		
    	   		EgovMap em = rsdtDao.selectRsdtInfrDat(vos.getRsdtSeqNo());
    	   		String hash = "";
    	   		if(em != null && !em.isEmpty()){
    	   			hash = rsdtDao.selectRsdtInfrHashDat(em, "2");
    	   			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
    				if(hash != null && hash.indexOf(reg) == -1){
    					String admTel = nidMessageSource.getMessage("admTelNo");
    					throw processException("pki.websrvcEror.msg", new String[]{hash, admTel});
    				}
    	   			resultSgnt = rsdtInfrService.getXmlData(hash, "ds:Signature");
    	   		}
    	   		if(resultSgnt != null && resultSgnt.length() > 0){
    	   			vos.setSysSgnt(resultSgnt);
    	   			rsdtDao.updateRsdtInfrSysSgnt(vos);
    	   		}
		   		
		   		int adultAge = propertiesService.getInt("adultAge");
		   		vo.setAdultAge(String.valueOf(adultAge));
		   		EgovMap tcpMap = rsdtDao.selectRsdtInfrTcpIpDat(vo.getRsdtSeqNo());
		   		if(tcpMap != null && !tcpMap.isEmpty()){
		   			rsdtNo = (String)tcpMap.get("rsdtNo");
		   			bioKey = (String)tcpMap.get("bioKey");
		   			dupYn = (String)tcpMap.get("age");
	   				EgovMap ImCapt = rsdtDao.selectImBioCaptTbInfr(bioKey);
	   				if(ImCapt != null && !ImCapt.isEmpty()){
	   					cnt = rsdtDao.selectBmBioTb(bioKey, rsdtNo);
	   					if(cnt > 0){
	   						insUpd = "u";
	   					}
	   					rsdtDao.deleteImBioCaptTb(bioKey);
	   		   			bioFle = (byte[])ImCapt.get("bioFle");
	   		   			if(bioFle != null){
	   		   				if(insUpd != null && "u".equals(insUpd)){
	   		   					dupYn = "N";
	   		   				}
	   		   				EgovMap bioEm = addRsdtInfrBioIf(bioKey, rsdtNo, dupYn, userId, insUpd, bioFle);
	   		   				apEm.put("bioEm", bioEm);
	   		   			}
	   				}
		   		}
			}
			
		}catch(Exception e){
	   		if(e instanceof IOException){
	   			log.error(e);
	   			throw e;
	   		}else if(e instanceof NidException){
	   			log.error(e);
	   			throw e;
	   		}else{
	   			log.error(e);
	   			throw e;
	   		}
	   	} 
		
		result.add(msg[0]);
		result.add(msg[1]);
		result.add(msg[2]);
		result.add(msg[3]);
		apEm.put("result", result);
        return apEm;
	}
   	
   	
   	/**
	 * Biz-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
	 * @return boolean Card replacement for data changes
	 * @exception Exception
	 */
   	public boolean searchRsdtMdfcCrdIssTo(RsdtMdfcVO vo) throws Exception {
        boolean result = false;
        int resultCnt = dao.selectRsdtMdfcCrdIssTo(vo);
        if(resultCnt > 1){
        	result = true;
        }
        int resultMdfcCnt = dao.selectRsdtMdfctTbTeamYn(vo);
        if(resultMdfcCnt > 0){
        	result = true;
        }
        
        EgovMap em = rsdtDao.selectRsdtInfrDat(vo.getRsdtSeqNo());
        if(em != null && em.get("rsdtStusCd") != null){
        	int rsdtStusCd = ((BigDecimal)em.get("rsdtStusCd")).intValue();
        	if(rsdtStusCd != 1){
        		result = false;
        	}
        }
        
        if(!result && resultMdfcCnt > 0){
        	result = true;
        }
        
        return result;
	}
   	
   	/**
	 * Biz-method for retrieving Receipt of Citizen Confirmation. <br>
	 *
	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(RsdtMdfcVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
   	public EgovMap searchRsdtMdfcCfmRcpt(RsdtMdfcVO vo) throws Exception {
        return dao.selectRsdtMdfcCfmRcpt(vo);
	}
   	
   	
   	/**
   	 * Biz-method for retrieving Receipt of Citizen Confirmation. <br>
   	 *
   	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(RsdtMdfcVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchRsdtMdfcOthrCfmRcpt(RsdtMdfcVO vo) throws Exception {
      		return dao.selectRsdtMdfcOthrCfmRcpt(vo);
   	}
   	
   	/**
   	 * Biz-method for retrieving Receipt of Citizen Confirmation. <br>
   	 *
   	 * @param vo Input item for  retrieving Receipt of Citizen Confirmation(RsdtMdfcVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchRsdtMdfcFrgnCfmRcpt(RsdtMdfcVO vo) throws Exception {
      		return dao.selectRsdtMdfcFrgnCfmRcpt(vo);
   	}  	
   	
   	/**
	 * Biz-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
   	public EgovMap searchRsdtMdfcChngFieldFlag(RsdtMdfcVO vo) throws Exception {
        return dao.selectRsdtMdfcChngFieldFlag(vo);
	}
   	
   	
   	
	/**
	 * Biz-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
	 * @return int Count of Program
	 * @exception Exception
	 */
   	public int searchRsdtMdfcChngIsFlag(RsdtMdfcVO vo) throws Exception {
        return dao.selectRsdtMdfcChngIsFlag(vo);
	}
   	
   	
   	
   	
   	
   	/**
	 * Biz-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
   	public EgovMap searchRsdtMdfcRgstIsFlag(RsdtMdfcVO vo) throws Exception {
        return dao.selectRsdtMdfcRgstIsFlag(vo);
	}
   	
   	
   	
   	/**
	 * Biz-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
   	public EgovMap searchRmImgView(RsdtMdfcVO vo) throws Exception {
        return dao.selectRmImgView(vo);
	}
   	
   	
   	
   	/**
	 * Biz-method for If you have registered biometric data of the bio-bio-info on the server brings. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
   	public String searchBioInfr(RsdtMdfcVO vo) throws Exception {
   		String result = null;
   		try{
   			int tamYn = dao.selectRsdtMdfctTbTeamYn(vo);
   			if(tamYn == 0){
	   			int captCnt = rsdtDao.selectRsdtInfrIsCapt(vo.getBioKey());
	   			if(captCnt < 1 || (vo != null && vo.getMdfctSeqNo() == null)){
			   		int cnt = rsdtDao.selectBmBioTb(vo.getBioKey(), vo.getRsdtNo());
			   		if(cnt > 0){
			   			result = searchRsdtInfrBioIf(vo.getBioKey(), vo.getRsdtNo(), "N", vo.getUserId(), null);
			   		}
	   			}
   			}
   		}catch(Exception e){
   			log.error(e);
   			throw e;
   		}
        return result;
	}
   	
   	
   	
   	/**
	 * Change the value of a byte array to hex string. <br>
	 * @param byte[]
	 * @return String
	 * @exception Exception
	 */
   	@SuppressWarnings("unused")
	private String getByteArrayToHex(byte[] arr){
		if (arr == null || arr.length == 0) {
			return null;
		}
		StringBuffer sb = new StringBuffer(arr.length * 2);
		String hexNumber = "";
		for (int x = 0; x < arr.length; x++) {
			hexNumber = "0" + Integer.toHexString(0xff & arr[x]);
			hexNumber = hexNumber.substring(hexNumber.length() - 2);
			sb.append(hexNumber);
		}
		return sb.toString();
	}
   	
   	/**
	 * Hex string to a byte array value changes. <br>
	 * @param String
	 * @return byte[]
	 * @exception Exception
	 */
   	@SuppressWarnings("unused")
	private byte[] getHexToByteArray(String hex) {
	    if (hex == null || hex.length() == 0) {
	        return null;
	    }
	    byte[] ba = new byte[hex.length() / 2];
	    for (int i = 0; i < ba.length; i++) {
	        ba[i] = (byte) Integer.parseInt(hex.substring(2 * i, 2 * i + 2), 16);
	    }
	    return ba;
	}
   	
   	
   	
   	
   	
   	
   	/**
	 * Bio bio-data sent to the server. <br>
	 * @param String, String, String, String, String, byte[]
	 * @return void
	 * @exception Exception
	 */
   	private EgovMap addRsdtInfrBioIf(String bioKey, String rsdtNo, String dupYn, String userId, String insUpd, byte [] bioFle) throws Exception {
   		int tcpCnt = propertiesService.getInt("rm.bio.socketReSend");
   		sendCnt++;
   		EgovMap em = null;
   		try{
   			em = bioIfService.addBioSocketIf(bioKey, rsdtNo, dupYn, userId, insUpd, bioFle);
   		}catch(IOException e){
   			log.error(e);
   			if(tcpCnt != sendCnt){
   				em = addRsdtInfrBioIf(bioKey, rsdtNo, dupYn, userId, insUpd, bioFle);
   			}else{
   				log.error(e);
   				sendCnt = 0;
   				throw e;
   			}
   		}catch(Exception e){
   			log.error(e);
   			sendCnt = 0;
   			throw e;
   		}finally{
   			try{
   				sendCnt = 0;
   			}catch(Exception e){
   				log.error(e);
   			}
   		}
   		return em;
   	}
   	
   	
   	
   	/**
	 * Bio bio-data sent to the server. <br>
	 * @param String, String, String, String, String, byte[]
	 * @return void
	 * @exception Exception
	 */
   	private String searchRsdtInfrBioIf(String bioKey, String rsdtNo, String dupYn, String userId, String xy) throws Exception {
   		int tcpCnt = propertiesService.getInt("rm.bio.socketReSend");
   		sendCnt++;
   		String result = "";
   		try{
   			if(xy == null || xy != null){
   				result = bioIfService.searchBioSocketIf(bioKey, rsdtNo, dupYn, userId, null);
   			}
   		}catch(IOException e){
   			log.error(e);
   			if(tcpCnt != sendCnt){
   				result = searchRsdtInfrBioIf(bioKey, rsdtNo, dupYn, userId, null);
   			}else{
   				log.error(e);
   				sendCnt = 0;
   				throw e;
   			}
   		}catch(Exception e){
   			log.error(e);
   			sendCnt = 0;
   			throw e;
   		}
   		return result;
   	}
   	
   	
   	/**
	 * Biz-method for Check expiration date of the card. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
   	public EgovMap searchRsdtInfrCrdExpiry(String rsdtNo) throws Exception {
   		return dao.selectRsdtInfrCrdExpiry(rsdtNo);
	}
   	
   	
   	
   	
   	/**
	 * Biz-method for Card issuing processing history results. <br>
	 *
	 * @param String, String
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
   	public EgovMap searchRsdtInfrCrdProcErr(String rsdtNo, String type) throws Exception {
   		RsdtMdfcVO vo = new RsdtMdfcVO();
   		vo.setRsdtNo(rsdtNo);
   		vo.setViewType(type);
   		return dao.selectRsdtInfrCrdProcErr(vo);
	}
   	
   	
   	/**
   	 * Biz-method for retrieving of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
   	 * @return RsdtMdfcVO
   	 * @exception Exception
   	 */
   	public RsdtMdfcVO searchRsdtMdfcSeqIsFlag(RsdtMdfcVO vo) throws Exception {
   		return dao.selectRsdtMdfcSeqIsFlag(vo);
   	}
   	
    /**
   	 * Biz-method for retrieving list of citizen. <br>
   	 *
   	 * @param vo Input item for retrieving list of citizen(RsdtMdfcVO).
   	 * @return List Retrieve list of citizen
   	 * @exception Exception
   	 */
   	public List<RsdtMdfcVO> searchListRsdtNmFnd(RsdtMdfcVO vo) throws Exception {
      		return dao.selectListRsdtNmFnd(vo);
   	}

   	/**
	 * Biz-method for retrieving total count  of citizen list. <br>
	 *
	 * @param vo Input item for total count of citizen list(RsdtMdfcVO).
	 * @return int Total Count of citizen list
	 * @exception Exception
	 */
   	public int searchListRsdtNmFndTotCn(RsdtMdfcVO vo) throws Exception {
        return dao.selectListRsdtNmFndTotCn(vo);
	}
   	
	/**
	 * Biz-method for retrieving citizen by eNID. <br>
	 * 
	 * @param vo Input item for retrieving citizen by eNID(RsdtMdfcVO).
	 * @return RsdtMdfcVO Retrieve citizen by eNID
	 * @exception Exception
	 */
	public RsdtMdfcVO searchRsdtNmFnd(RsdtMdfcVO vo) throws Exception{
		return dao.selectRsdtNmFnd(vo);
	}   	
	
	
	
	
	/**
	 * Biz-method for retrieving total count  of citizen list. <br>
	 *
	 * @param vo Input item for total count of citizen list(RsdtMdfcVO).
	 * @return int Total Count of citizen list
	 * @exception Exception
	 */
   	public int searchListMdfcMrrgDvrc(RsdtMdfcVO vo) throws Exception {
        return dao.selectListMdfcMrrgDvrc(vo);
	}
   	
   	
   	/**
	 * Biz-method for retrieving total count  of citizen list. <br>
	 *
	 * @param vo Input item for total count of citizen list(RsdtMdfcVO).
	 * @return int Total Count of citizen list
	 * @exception Exception
	 */
   	public int searchListMdfcMrrgCnt(RsdtMdfcVO vo) throws Exception {
        return dao.selectListMdfcMrrgCnt(vo);
	}
   	
   	
   	/**
	 * Biz-method for retrieving total count  of citizen list. <br>
	 *
	 * @param vo Input item for total count of citizen list(RsdtMdfcVO).
	 * @return int Total Count of citizen list
	 * @exception Exception
	 */
   	public int searchBthRgst(RsdtMdfcVO vo) throws Exception {
        return dao.selectBthRgst(vo);
	}
   	
   	
   	
   	/**
	 * Biz-method for chip write flag <br>
	 *
	 * @param RsdtMdfcVO
	 * @param boolean
	 * @param String
	 * @return boolean
	 * @exception Exception
	 */
   	public boolean searchIsChipWriteFlag(RsdtMdfcVO vo, boolean writeFlag, String lgSeqNo) throws Exception {
   		boolean flag = false;
   		
   		boolean cardisuFlag = true;
		EgovMap ems = rsdtDao.selectRsdtInfrDat(vo.getRsdtSeqNo());
		if(ems != null && ems.get("rsdtStusCd") != null){
        	int rsdtStusCd = ((BigDecimal)ems.get("rsdtStusCd")).intValue();
        	if(rsdtStusCd != 1){
        		cardisuFlag = false;
        	}
        }
		if(cardisuFlag){
	   		int resultCrdIssCnt = dao.selectRsdtMdfcCrdIssTo(vo);
			if(resultCrdIssCnt < 2){
				String chipResult = dao.selectRsdtMdfcCrdChipChange(vo);
				if(chipResult != null && !"".equals(chipResult)){
					flag = true;
					if(writeFlag){
						flag = false;
						RMCCM_Service ccmse= new RMCCM_Service();
						RMCCM ccm = ccmse.getRMCCMPort();
						String ccmResult = ccm.registerCardChanges(chipResult);
						log.debug("ccm.registerCardChanges(chipResult)");
						log.debug(ccmResult);
						String erorYn = "N";
						if(ccmResult != null && !"OK".equals(ccmResult)){
							erorYn = "Y";
							flag = true;
							//String admTel = nidMessageSource.getMessage("admTelNo");
	    					//throw processException("pki.websrvcEror.msg", new String[]{ccmResult, admTel});
						}
						lgDao.updatePubKeyIfLg(lgSeqNo, ccmResult, erorYn);
					}
				}
			}
		}
   		return flag;
	}
   	
   	/**
	 * Biz-method for retrieving family member. <br>
	 *
	 * @param vo Input item for retrieving family member(RsdtMdfcVO).
	 * @return int 
	 * @exception Exception
	 */
   	public int searchMber(RsdtMdfcVO vo) throws Exception {
        return dao.selectMber(vo);
	} 
   	
   	/**
   	 * Biz-method  <br>
   	 *
   	 * @param vo Input item .
   	 * @return 
   	 * @exception Exception
   	 */
   	public RsdtMdfcVO searchMberRsdtNo(RsdtMdfcVO vo) throws Exception {
   		return dao.selectMberRsdtNo(vo);
   	}  
   	
   	/**
	 * Biz-method for retrieving member row number. <br>
	 *
	 * @param vo Input item for retrieving member row number(RsdtMdfcVO).
	 * @return int member row number
	 * @exception Exception
	 */
   	public int searchMberRowNum(RsdtMdfcVO vo) throws Exception {
        return dao.selectMberRowNum(vo);
	}   	
}