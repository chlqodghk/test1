package afnid.rm.rsdt.service;

import afnid.cm.ComDefaultVO;

public class RsdtInfrVO extends ComDefaultVO {
	
	private String ctznRgstYnFlag;
	private String ctznRgstYn;
	private String fAge;
	private String mAge;
	private String gAge;
	
	private String othrRl;
	private String bioRgstDdG;
	private String bioRgstDdJ;
	private String bioRgstDd;
	private String bthDdApvrJ;
	private String bthDdApvrG;
	private String bioRgstApvrYn;
	private String aprvListTm;
	private String headNm;
	private String deadYn;
	private String initDthYn;
	private String udtWrkCd;
	private String crdIsuceLangCd;
	private String oldCrdIsucePlceCdNm;
	private String oldCrdIsucePlceCd;
	
	private String secdVefyOldCrdIsuceDd;
	private String secdVefyCrdIsucePlceCd;
	private String secdVefyCrdIsucePlceCdNm;
	private String fstVefyOldCrdIsuceDd;
	private String fstVefyOldCrdIsucePlceCd;
	private String fstVefyOldCrdIsucePlceCdNm;
	private String pkiCert;
	private String spusRsdtNo;
	private String fleRcdNo;
	private String hstSeqNo;
	private String sysSgnt;
	private String spousCnt;
	private String curtAdDtlCtD;
    private String curtAdDtlCtF;
	private String curtAdNatCdNm;
	private String curtAdDiv;
	private String curtAdNatCd;
	private String emlAd;
	private String mthrRsdtNo;
	private String fthrRsdtNo;
	private String gfthrRsdtNo;
	private static final long serialVersionUID = 1L;
	private String crdIsuceSrlNo;
	private String adultAge;
	private String userNm;
	private String crdDitbSeqNo;
	private String crdIsuceStusCd;
	private String fleRcivYmd;
	private String rcivFleNm;
	private String erorCd;
	private String erorMsg;
	private String erorPrcssYn;
	private String erorPrcssUserId;
	
	private String bioCaptYn;
	private String wrkEdDt;
	private String orgnzCd;
	private String prcssDivCd;
	private String fleLc;
	private String tgtCn;
	private String scsCn;
	private String erorCn;
	private String erorYn;
	private String msg;
	
	private String sndRcivDt;
	private String sndRcivDivCd;
	
	private String crdDitbCd;
	private String crdDitbDd;
	private String aplDd;
	
	private String fmlyBokSeqNo;
	private String crdIsucePlceCd;
	private String enNm;
	private String enSurnm;
	
	private String fthrNm;

	private String gfthrNm;
	private String bioRgstYnTmp;
	
	private String oldCrdIsucePlce;
	private String oldCrdIsucePlceNm;
	private String mthrNm;
	private String fthrRsdtSeqNo;
	private String mthrRsdtSeqNo;
	private String rsdtTyeCd;
	private String fstVefyIndiNm;
	private String secdVefyIndiNm;
	
	
	private String mrrgSeqNo;
	private String spusNm;
	
	private String [] rsdtSeqNos;
	private String [] mrrgSeqNos;
	private String [] spusNms;
	
	private String fmlyNoDis;
	private String gdrCdVal;
	
	
	private String poliCntrSeqNo;
	private String poliCntrSeqNoNm;
	
	private String sgnt;
	private String rsdtTyeCdNm;
	private String rgstYn;
	private String rsdtAccnSeqNo;
	
	
	
	private String mrrgDd;
	private String spusRsdtSeqNo;
	private String frngrYn;
	private String initialDatYn;
	private String rgstOrgnzCd;
	private String dltYn;
	
	private String spusDelList;
	private String aprvDd;
	private String crdIsuDueDdDay;
	private String crdIsuSeqNo;
	
	private String useLangCd;
	private String rn;
	private String rsdtNo;
	private String hstSrlNo;
	private String oldCrdNo;
	private String givNm;
	private String enGivNm;
	
	private String fthrGivNm;

	private String gfthrGivNm;

	private String bthDd;
	private String gdrCd;
	private String pmntAdPrviceCd;
	private String pmntAdDistrictCd;
	private String pmntAdVillagCd;
	private String pmntAdCd;
	private String pmntAdDtlCt;
	private String pmntAdPostCd;
	private String pmntAdCdNm;
	private String curtAdPrviceCd;
	private String curtAdDstrCd;
	private String curtAdVillagCd;
	private String curtAdCd;
	private String curtAdDtlCt;
	private String curtAdPostCd;
	private String curtAdCdNm;
	private String crdIsuceDd;
	private String crdExpiryDd;
	private String fmlyNm;
	private String bthPlcePrviceCd;
	private String bthPlceDstrCd;
	private String bthPlceVillagCd;
	private String bthPlceCd;
	private String bthPlceCdNm;
	private String bldTyeCd;
	private String mrrgCd;
	private String etncityCd;
	
	private String fmlyLangCd;
	private String smrRsdcPrviceCd;
	private String smrRsdcDstrCd;
	private String smrRsdcVillagCd;
	private String smrRsdcCd;
	private String smrRsdcDtlCt;
	private String smrRsdcCdNm;
	private String wtrRsdcPrviceCd;
	private String wtrRsdcDstrCd;
	private String wtrRsdcVillagCd;
	private String wtrRsdcCd;
	private String wtrRsdcDtlCt;
	private String wtrRsdcCdNm;
	private String rlgnCd;
	private String rlgnSect;
	private String ocpCd;
	private String eduCd;
	private String adChngYn;
	private String bfAdPrviceCd;
	private String bfAdDstrCd;
	private String bfAdVillagCd;
	private String bfAdCd;
	private String bfAdDtlCt;
	private String bfAdPostCd;
	private String bfAdCdNm;
	private String fmlyMberMlNo;
	private String fmlyMberFemlNo;
	private String mltSrvcCd;
	private String fmlyHadRsdtNo;
	private String chifRgstOficrRsdtNo;
	private String rgstOficrRsdtNo;	
	private String villagIndiVefyRsdtNo;
	private String fmlyHadYn;
	private String orphanYn;
	private String oficrYn;
	private String udtDd;
	private String udtReasionCd;
	private String udtReasionDtlCt;
	private String udtReasionDtlCd;
	private String useYn;
	private String fmlyBokRgstYn;
	private String fstRgstUserId;
	private String fstRgstDt;
	
	private String lstUdtUserId;
	private String lstUdtDt;
	private String natLangCd;
	private String frgnLangCd;
	private String dsbtCd;
	private String nltyCd;
	private String fmlyrlgnCd;
    private String nltyCdNm;
    private String frgnLangCdNm;
    private String natLangCdNm;
    private String dsbtCdNm;
    private String dsbtDtlCt;;
	
	//KIM ADD
    private String fmlyMberNo;
	private String fmlyBokNo;
	private String fmlyStusCd;
	private String fmlyBokHstSrlNo;
	private String rdCnt;
	private String fbCnt;
	private String rgstDd;
	private String gdrCdNm;
	private String rlCdNm;
	private String mrrgCdNm;
	private String etncityCdNm;
	private String fmlyLangCdNm;
	private String rlgnCdNm;
	private String rlgnSectCdNm;
	private String ocpCdNm;
	private String eduCdNm;
	private String mlSrvcCdNm;
	private String udtRsnCdNm;
	private String rsdtStusCdNm;
	private String ersrCdNm;
	private String frgnLangnCdNm;
	private String bldTyeCdNm;
	private String crdIsucePlceCdNm;
	private String mltSrvcCdNm;
	private String fmlyHadRsdtNm;
	private String chifRgstOficrRsdtNm;
	private String villagIndiVefyRsdtNm;		
	private String rgstOficrRsdtNm;
	private String udtRsnDtlCt;
	private String ersrDdNm;
	private String srchOficrYn;
	
	
    private	String fmlyBokNoNum;
    private	String rsdtRgstDd;
    private	String rsdtRgstYn;
    private	String teamLedrCfmYn;
    private	String cfmTeamLedrid;
    private	String encyCd;   
    private	String encyCdNm;    

	// add
	private String [] natLangCds;
	private String [] frgnLangCds;
	private String [] nltyCds;
	private String [] dsbtCds;
	private String [] dsbtDtlCts;
	private String rlCd;
	private String udtRsnCd;
	private String officerNo;
	private String fthrSurnm;
	
	
	private String fstVefyIndiGivNm;
	private String fstVefyIndiSurnm;
	private String secdVefyIndiGivNm;
	private String secdVefyIndiSurnm;
	private String surnm;
	private String pmntAdPrvicCd;
	private String adChngYnNm;
	private String fmlyHadYnNm;
	private String orphanYnNm;
	private String oficrYnNm;
	private String rsdtNoDp;
	private String rlgnSectCd;
	
	private String gfthrSurnm;
	private String pmntAdDstrCd;
	private String curtAdPrvicCd;
	private String bthPlcePrvicCd;
	private String secdNltyCd;
	private String secdNltyCdNm;
	private String smrRsdcPrvicCd;
	private String ocp;
	
	private String bfAdPrvicCd;
	private String userId; 
	
	private String tamLedrCfmYn;
	private String cfmTamLedrId;
	private String bioKey;
	private String bioRgstYn;
	
	private String cfmTamLedrIdNm;
	private String rsdtRgstIdNm;
	private String teamNm;
	private String crdIsuLangCd;
	private String crdIsuLangCdNm;
	
	private String crdIsuceDdNid;
	private String crdIsucePlceCdNid;
	private String crdIsucePlceCdNmNid;
	private String calTye;
	private String seRegOff;
	private String fstVefyTye;
    private String fstVefyRsdtNo;
    private String secdVefyTye;
    private String secdVefyRsdtNo;
    private String preAdCd;
    
    //add
    private String bthDdD;
    private String bthDdFa;
    private String crdIsuceDdD;
    private String crdIsuceDdFa;
    private String crdExpiryDdD;
    private String crdExpiryDdFa;
    
    private String crdIsuceDdGr;
    private String crdExpiryDdGr;
    private String pmntAdCdCt;
    private String curtAdCdCt;
    private String bthPlceCdCt;
    private String smrRsdcCdCt;
    private String wtrRsdcCdCt;
    private String bthDdGr;
    
    private String wrkTgtCn;
    private String wrkSucessCn;
    private String wrkErorCn;
    private String fleNm;
    
    private String crdIsuDd;
    private String crdIsuStusCd;
    private String crdIsuErorDd;
    private String crdIsuErorRsn;
    private String crdIsuDueDd;
    
    private String crdEncUsePin;
    private String crdEncSoPin;
    
    private String poliCntrCd;
    private String poliCntrCdNm;
    
    private String bthNatDiv;
    private String bthNatCd;
    private String bthNatCdNm;
    private String frgnBthCtyNm;
    
    private String poliOne;
    private String poliTwo;
    private String poliCntrCd1;
    private String poliCntrCd2;
    
    private String poliCntrCdNm1;
    private String poliCntrCdNm2;
    private String poliCntrCdNm3;
    
    private String wrkSttDt;
    
    private String crdCd;
    private String aplCd;
    
    private String srlNo;
    private String rsdtStusCd;
    private String rsdtSeqNo;
    private String sndRsut;
    private String descFleNm;
    private String sndDt;
    private String[] sndBox;
    
    private String useYns;
    private String ersrYns;
    
    private String gfthrRsdtSeqNo;
    private String fthrRgstTye;
    private String mthrRgstTye;

	private String gfthrRgstTye;
    private String spusRgstTye;
    private String fthrOldCrdNo;
    private String mthrOldCrdNo;
    private String gfthrOldCrdNo;
    private String spusOldCrdNo;
    private String rsdtCfmYn;
    private String bldTyeDocYn;
    private String eduLvDocYn;   	
    private String spusSurnm; 
    private String spusGivNm;     
    
    private String bldTyeDocVrfd;
    private String eduLvDocVrfd;
    private String aprvBtnClickYn;
    
	private String prntDd;
	
	private String oldCrdNo1;
	private String oldCrdNo2;
	private String oldCrdNo3;
	private String oldCrdNo4;
    private String fthrOldCrdNo1;
    private String fthrOldCrdNo2;
    private String fthrOldCrdNo3;
    private String fthrOldCrdNo4;
    private String mthrOldCrdNo1;
    private String mthrOldCrdNo2;
    private String mthrOldCrdNo3;
    private String mthrOldCrdNo4;
    
    private String gfthrOldCrdNo1;
    private String gfthrOldCrdNo2;
    private String gfthrOldCrdNo3;
    private String gfthrOldCrdNo4;
    private String spusOldCrdNo1;
    private String spusOldCrdNo2;
    private String spusOldCrdNo3;
    private String spusOldCrdNo4;
    
    private String crdIsuSrlNo;
    private String bsnCd;
    private String bsnSeqNo;
    
    private String oldCrdIsuceDd;
    private String eduYn;
    private String cntTelNo;
    private String cntTelNo2;
    private String emlAdNo;

    private String fstVefyFthrNm;
    private String fstVefyOldCrdNo1;
    private String fstVefyOldCrdNo2;
    private String fstVefyOldCrdNo3;
    private String fstVefyOldCrdNo4;
    
    private String secdVefyFthrNm;
    private String secdVefyOldCrdNo1;
    private String secdVefyOldCrdNo2;
    private String secdVefyOldCrdNo3;
    private String secdVefyOldCrdNo4;
    private String eml;
    private String secdNltyYn;
    private String bioCd;
    private String fgpCd;
    private String irisCd;
    private String sgntCd;
    private String ptCd;
    private String grnDd;
    private String age;
    private String bioInfr;
    private String nm;
    
    private String gBthDd;
    private String hBthDd;
    private String srchBthDd;
    private String srchCalTye;
    private String mode;
    private String srchRlCd;
    private String agGap;
    private String fthrAgGap;
    private String gfthrAgGap;
    private String mthrAgGap;
    private String selfAgGap;
    private String srchAgGap;
    private String fmlYHadGdrCd;
    private String flag;
    private String fullNm;
    private String mdtrRlCd;
    private String tye;
    private String rlFthrYn;
    private String rlGfthrYn;
    private String rlMthrYn;
    private String lgSeqNo;
    
    private String fthrRlCdCnt;
    private String gfthrRlCdCnt;
    private String mthrRlCdCnt;
    private String spusRlCdCnt;
    
    private String fthrModeYn;
    private String gfthrModeYn;
    private String mthrModeYn;
    private String spusModeYn;
    
    public String getFgpCd() {
		return fgpCd;
	}
	public void setFgpCd(String fgpCd) {
		this.fgpCd = fgpCd;
	}
	public String getIrisCd() {
		return irisCd;
	}
	public void setIrisCd(String irisCd) {
		this.irisCd = irisCd;
	}
	public String getAprvBtnClickYn() {
		return aprvBtnClickYn;
	}
	public void setAprvBtnClickYn(String aprvBtnClickYn) {
		this.aprvBtnClickYn = aprvBtnClickYn;
	}
	public String getGfthrRsdtSeqNo() {
		return gfthrRsdtSeqNo;
	}
	public void setGfthrRsdtSeqNo(String gfthrRsdtSeqNo) {
		this.gfthrRsdtSeqNo = gfthrRsdtSeqNo;
	}
	public String getFthrRgstTye() {
		return fthrRgstTye;
	}
	public void setFthrRgstTye(String fthrRgstTye) {
		this.fthrRgstTye = fthrRgstTye;
	}
	public String getMthrRgstTye() {
		return mthrRgstTye;
	}
	public void setMthrRgstTye(String mthrRgstTye) {
		this.mthrRgstTye = mthrRgstTye;
	}
	public String getGfthrRgstTye() {
		return gfthrRgstTye;
	}
	public void setGfthrRgstTye(String gfthrRgstTye) {
		this.gfthrRgstTye = gfthrRgstTye;
	}
	public String getSpusRgstTye() {
		return spusRgstTye;
	}
	public void setSpusRgstTye(String spusRgstTye) {
		this.spusRgstTye = spusRgstTye;
	}
	public String getFthrOldCrdNo() {
		return fthrOldCrdNo;
	}
	public void setFthrOldCrdNo(String fthrOldCrdNo) {
		this.fthrOldCrdNo = fthrOldCrdNo;
	}
	public String getMthrOldCrdNo() {
		return mthrOldCrdNo;
	}
	public void setMthrOldCrdNo(String mthrOldCrdNo) {
		this.mthrOldCrdNo = mthrOldCrdNo;
	}
	public String getGfthrOldCrdNo() {
		return gfthrOldCrdNo;
	}
	public void setGfthrOldCrdNo(String gfthrOldCrdNo) {
		this.gfthrOldCrdNo = gfthrOldCrdNo;
	}
	public String getSpusOldCrdNo() {
		return spusOldCrdNo;
	}
	public void setSpusOldCrdNo(String spusOldCrdNo) {
		this.spusOldCrdNo = spusOldCrdNo;
	}
	public String getRsdtCfmYn() {
		return rsdtCfmYn;
	}
	public void setRsdtCfmYn(String rsdtCfmYn) {
		this.rsdtCfmYn = rsdtCfmYn;
	}
	public String getBldTyeDocYn() {
		return bldTyeDocYn;
	}
	public void setBldTyeDocYn(String bldTyeDocYn) {
		this.bldTyeDocYn = bldTyeDocYn;
	}
	public String getEduLvDocYn() {
		return eduLvDocYn;
	}
	public void setEduLvDocYn(String eduLvDocYn) {
		this.eduLvDocYn = eduLvDocYn;
	}    
    
    public String getBthDdD() {
		return bthDdD;
	}
	public void setBthDdD(String bthDdD) {
		this.bthDdD = bthDdD;
	}
	public String getBthDdFa() {
		return bthDdFa;
	}
	public void setBthDdFa(String bthDdFa) {
		this.bthDdFa = bthDdFa;
	}
	public String getCrdIsuceDdD() {
		return crdIsuceDdD;
	}
	public void setCrdIsuceDdD(String crdIsuceDdD) {
		this.crdIsuceDdD = crdIsuceDdD;
	}
	public String getCrdIsuceDdFa() {
		return crdIsuceDdFa;
	}
	public void setCrdIsuceDdFa(String crdIsuceDdFa) {
		this.crdIsuceDdFa = crdIsuceDdFa;
	}
	public String getCrdExpiryDdD() {
		return crdExpiryDdD;
	}
	public void setCrdExpiryDdD(String crdExpiryDdD) {
		this.crdExpiryDdD = crdExpiryDdD;
	}
	public String getCrdExpiryDdFa() {
		return crdExpiryDdFa;
	}
	public void setCrdExpiryDdFa(String crdExpiryDdFa) {
		this.crdExpiryDdFa = crdExpiryDdFa;
	}
	public String getBthPlceCdEn() {
		return bthPlceCdEn;
	}
	public void setBthPlceCdEn(String bthPlceCdEn) {
		this.bthPlceCdEn = bthPlceCdEn;
	}
	public String getGdrCdEn() {
		return gdrCdEn;
	}
	public void setGdrCdEn(String gdrCdEn) {
		this.gdrCdEn = gdrCdEn;
	}
	private String bthPlceCdEn;
    private String gdrCdEn;
	
	public String getUseLangCd() {
		return useLangCd;
	}
	public void setUseLangCd(String useLangCd) {
		this.useLangCd = useLangCd;
	}
	public String getRn() {
		return rn;
	}
	public void setRn(String rn) {
		this.rn = rn;
	}
	public String getBioKey() {
		return bioKey;
	}
	public void setBioKey(String bioKey) {
		this.bioKey = bioKey;
	}
	public String getEnSurnm() {
		return enSurnm;
	}
	public void setEnSurnm(String enSurnm) {
		this.enSurnm = enSurnm;
	}
	public String getSecdNltyCdNm() {
		return secdNltyCdNm;
	}
	public void setSecdNltyCdNm(String secdNltyCdNm) {
		this.secdNltyCdNm = secdNltyCdNm;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getBfAdPrvicCd() {
		return bfAdPrvicCd;
	}
	public void setBfAdPrvicCd(String bfAdPrvicCd) {
		this.bfAdPrvicCd = bfAdPrvicCd;
	}
	public String getOcp() {
		return ocp;
	}
	public void setOcp(String ocp) {
		this.ocp = ocp;
	}
	public String getSmrRsdcPrvicCd() {
		return smrRsdcPrvicCd;
	}
	public void setSmrRsdcPrvicCd(String smrRsdcPrvicCd) {
		this.smrRsdcPrvicCd = smrRsdcPrvicCd;
	}
	public String getSecdNltyCd() {
		return secdNltyCd;
	}
	public void setSecdNltyCd(String secdNltyCd) {
		this.secdNltyCd = secdNltyCd;
	}
	public String getBthPlcePrvicCd() {
		return bthPlcePrvicCd;
	}
	public void setBthPlcePrvicCd(String bthPlcePrvicCd) {
		this.bthPlcePrvicCd = bthPlcePrvicCd;
	}
	public String getCurtAdPrvicCd() {
		return curtAdPrvicCd;
	}
	public void setCurtAdPrvicCd(String curtAdPrvicCd) {
		this.curtAdPrvicCd = curtAdPrvicCd;
	}
	public String getPmntAdDstrCd() {
		return pmntAdDstrCd;
	}
	public void setPmntAdDstrCd(String pmntAdDstrCd) {
		this.pmntAdDstrCd = pmntAdDstrCd;
	}
	public String getPmntAdPrvicCd() {
		return pmntAdPrvicCd;
	}
	public void setPmntAdPrvicCd(String pmntAdPrvicCd) {
		this.pmntAdPrvicCd = pmntAdPrvicCd;
	}
	public String getGfthrSurnm() {
		return gfthrSurnm;
	}
	public void setGfthrSurnm(String gfthrSurnm) {
		this.gfthrSurnm = gfthrSurnm;
	}

	public String getSurnm() {
		return surnm;
	}
	public void setSurnm(String surnm) {
		this.surnm = surnm;
	}
	public String getFthrSurnm() {
		return fthrSurnm;
	}
	public void setFthrSurnm(String fthrSurnm) {
		this.fthrSurnm = fthrSurnm;
	}
	public String getOfficerNo() {
		return officerNo;
	}
	public void setOfficerNo(String officerNo) {
		this.officerNo = officerNo;
	}
	public String getPmntAdCdNm() {
		return pmntAdCdNm;
	}
	public void setPmntAdCdNm(String pmntAdCdNm) {
		this.pmntAdCdNm = pmntAdCdNm;
	}
	public String getCurtAdCdNm() {
		return curtAdCdNm;
	}
	public void setCurtAdCdNm(String curtAdCdNm) {
		this.curtAdCdNm = curtAdCdNm;
	}
	public String getBthPlceCdNm() {
		return bthPlceCdNm;
	}
	public void setBthPlceCdNm(String bthPlceCdNm) {
		this.bthPlceCdNm = bthPlceCdNm;
	}
	public String getSmrRsdcCdNm() {
		return smrRsdcCdNm;
	}
	public void setSmrRsdcCdNm(String smrRsdcCdNm) {
		this.smrRsdcCdNm = smrRsdcCdNm;
	}
	public String getWtrRsdcCdNm() {
		return wtrRsdcCdNm;
	}
	public void setWtrRsdcCdNm(String wtrRsdcCdNm) {
		this.wtrRsdcCdNm = wtrRsdcCdNm;
	}
	public String getBfAdCdNm() {
		return bfAdCdNm;
	}
	public void setBfAdCdNm(String bfAdCdNm) {
		this.bfAdCdNm = bfAdCdNm;
	}
	public String getFmlyrlgnCd() {
		return fmlyrlgnCd;
	}
	public void setFmlyrlgnCd(String fmlyrlgnCd) {
		this.fmlyrlgnCd = fmlyrlgnCd;
	}

	public String getLstUdtDt() {
		return lstUdtDt;
	}
	public void setLstUdtDt(String lstUdtDt) {
		this.lstUdtDt = lstUdtDt;
	}
	

	public String getRsdtNo() {
		return rsdtNo;
	}
	public void setRsdtNo(String rsdtNo) {
		this.rsdtNo = rsdtNo;
	}
	public String getHstSrlNo() {
		return hstSrlNo;
	}
	public void setHstSrlNo(String hstSrlNo) {
		this.hstSrlNo = hstSrlNo;
	}
	public String getOldCrdNo() {
		return oldCrdNo;
	}
	public void setOldCrdNo(String oldCrdNo) {
		this.oldCrdNo = oldCrdNo;
	}
	public String getGivNm() {
		return givNm;
	}
	public void setGivNm(String givNm) {
		this.givNm = givNm;
	}
	public String getEnGivNm() {
		return enGivNm;
	}
	public void setEnGivNm(String enGivNm) {
		this.enGivNm = enGivNm;
	}


	public String getFthrGivNm() {
		return fthrGivNm;
	}
	public void setFthrGivNm(String fthrGivNm) {
		this.fthrGivNm = fthrGivNm;
	}

	public String getGfthrGivNm() {
		return gfthrGivNm;
	}
	public void setGfthrGivNm(String gfthrGivNm) {
		this.gfthrGivNm = gfthrGivNm;
	}

	public String getBthDd() {
		return bthDd;
	}
	public void setBthDd(String bthDd) {
		this.bthDd = bthDd;
	}
	public String getGdrCd() {
		return gdrCd;
	}
	public void setGdrCd(String gdrCd) {
		this.gdrCd = gdrCd;
	}
	public String getPmntAdPrviceCd() {
		return pmntAdPrviceCd;
	}
	public void setPmntAdPrviceCd(String pmntAdPrviceCd) {
		this.pmntAdPrviceCd = pmntAdPrviceCd;
	}
	public String getPmntAdDistrictCd() {
		return pmntAdDistrictCd;
	}
	public void setPmntAdDistrictCd(String pmntAdDistrictCd) {
		this.pmntAdDistrictCd = pmntAdDistrictCd;
	}
	public String getPmntAdVillagCd() {
		return pmntAdVillagCd;
	}
	public void setPmntAdVillagCd(String pmntAdVillagCd) {
		this.pmntAdVillagCd = pmntAdVillagCd;
	}
	public String getPmntAdCd() {
		return pmntAdCd;
	}
	public void setPmntAdCd(String pmntAdCd) {
		this.pmntAdCd = pmntAdCd;
	}
	public String getPmntAdDtlCt() {
		return pmntAdDtlCt;
	}
	public void setPmntAdDtlCt(String pmntAdDtlCt) {
		this.pmntAdDtlCt = pmntAdDtlCt;
	}
	public String getPmntAdPostCd() {
		return pmntAdPostCd;
	}
	public void setPmntAdPostCd(String pmntAdPostCd) {
		this.pmntAdPostCd = pmntAdPostCd;
	}
	public String getCurtAdPrviceCd() {
		return curtAdPrviceCd;
	}
	public void setCurtAdPrviceCd(String curtAdPrviceCd) {
		this.curtAdPrviceCd = curtAdPrviceCd;
	}
	public String getCurtAdDstrCd() {
		return curtAdDstrCd;
	}
	public void setCurtAdDstrCd(String curtAdDstrCd) {
		this.curtAdDstrCd = curtAdDstrCd;
	}
	public String getCurtAdVillagCd() {
		return curtAdVillagCd;
	}
	public void setCurtAdVillagCd(String curtAdVillagCd) {
		this.curtAdVillagCd = curtAdVillagCd;
	}
	public String getCurtAdCd() {
		return curtAdCd;
	}
	public void setCurtAdCd(String curtAdCd) {
		this.curtAdCd = curtAdCd;
	}
	public String getCurtAdDtlCt() {
		return curtAdDtlCt;
	}
	public void setCurtAdDtlCt(String curtAdDtlCt) {
		this.curtAdDtlCt = curtAdDtlCt;
	}
	public String getCurtAdPostCd() {
		return curtAdPostCd;
	}
	public void setCurtAdPostCd(String curtAdPostCd) {
		this.curtAdPostCd = curtAdPostCd;
	}
	public String getCrdIsuceDd() {
		return crdIsuceDd;
	}
	public void setCrdIsuceDd(String crdIsuceDd) {
		this.crdIsuceDd = crdIsuceDd;
	}
	public String getCrdExpiryDd() {
		return crdExpiryDd;
	}
	public void setCrdExpiryDd(String crdExpiryDd) {
		this.crdExpiryDd = crdExpiryDd;
	}
	public String getFmlyNm() {
		return fmlyNm;
	}
	public void setFmlyNm(String fmlyNm) {
		this.fmlyNm = fmlyNm;
	}
	public String getBthPlcePrviceCd() {
		return bthPlcePrviceCd;
	}
	public void setBthPlcePrviceCd(String bthPlcePrviceCd) {
		this.bthPlcePrviceCd = bthPlcePrviceCd;
	}
	public String getBthPlceDstrCd() {
		return bthPlceDstrCd;
	}
	public void setBthPlceDstrCd(String bthPlceDstrCd) {
		this.bthPlceDstrCd = bthPlceDstrCd;
	}
	public String getBthPlceVillagCd() {
		return bthPlceVillagCd;
	}
	public void setBthPlceVillagCd(String bthPlceVillagCd) {
		this.bthPlceVillagCd = bthPlceVillagCd;
	}
	public String getBthPlceCd() {
		return bthPlceCd;
	}
	public void setBthPlceCd(String bthPlceCd) {
		this.bthPlceCd = bthPlceCd;
	}
	public String getBldTyeCd() {
		return bldTyeCd;
	}
	public void setBldTyeCd(String bldTyeCd) {
		this.bldTyeCd = bldTyeCd;
	}
	public String getMrrgCd() {
		return mrrgCd;
	}
	public void setMrrgCd(String mrrgCd) {
		this.mrrgCd = mrrgCd;
	}
	public String getEtncityCd() {
		return etncityCd;
	}
	public void setEtncityCd(String etncityCd) {
		this.etncityCd = etncityCd;
	}
	public String getCrdIsucePlceCd() {
		return crdIsucePlceCd;
	}
	public void setCrdIsucePlceCd(String crdIsucePlceCd) {
		this.crdIsucePlceCd = crdIsucePlceCd;
	}
	public String getFmlyLangCd() {
		return fmlyLangCd;
	}
	public void setFmlyLangCd(String fmlyLangCd) {
		this.fmlyLangCd = fmlyLangCd;
	}
	public String getSmrRsdcPrviceCd() {
		return smrRsdcPrviceCd;
	}
	public void setSmrRsdcPrviceCd(String smrRsdcPrviceCd) {
		this.smrRsdcPrviceCd = smrRsdcPrviceCd;
	}
	public String getSmrRsdcDstrCd() {
		return smrRsdcDstrCd;
	}
	public void setSmrRsdcDstrCd(String smrRsdcDstrCd) {
		this.smrRsdcDstrCd = smrRsdcDstrCd;
	}
	public String getSmrRsdcVillagCd() {
		return smrRsdcVillagCd;
	}
	public void setSmrRsdcVillagCd(String smrRsdcVillagCd) {
		this.smrRsdcVillagCd = smrRsdcVillagCd;
	}
	public String getSmrRsdcCd() {
		return smrRsdcCd;
	}
	public void setSmrRsdcCd(String smrRsdcCd) {
		this.smrRsdcCd = smrRsdcCd;
	}
	public String getSmrRsdcDtlCt() {
		return smrRsdcDtlCt;
	}
	public void setSmrRsdcDtlCt(String smrRsdcDtlCt) {
		this.smrRsdcDtlCt = smrRsdcDtlCt;
	}
	public String getWtrRsdcPrviceCd() {
		return wtrRsdcPrviceCd;
	}
	public void setWtrRsdcPrviceCd(String wtrRsdcPrviceCd) {
		this.wtrRsdcPrviceCd = wtrRsdcPrviceCd;
	}
	public String getWtrRsdcDstrCd() {
		return wtrRsdcDstrCd;
	}
	public void setWtrRsdcDstrCd(String wtrRsdcDstrCd) {
		this.wtrRsdcDstrCd = wtrRsdcDstrCd;
	}
	public String getWtrRsdcVillagCd() {
		return wtrRsdcVillagCd;
	}
	public void setWtrRsdcVillagCd(String wtrRsdcVillagCd) {
		this.wtrRsdcVillagCd = wtrRsdcVillagCd;
	}
	public String getWtrRsdcCd() {
		return wtrRsdcCd;
	}
	public void setWtrRsdcCd(String wtrRsdcCd) {
		this.wtrRsdcCd = wtrRsdcCd;
	}
	public String getWtrRsdcDtlCt() {
		return wtrRsdcDtlCt;
	}
	public void setWtrRsdcDtlCt(String wtrRsdcDtlCt) {
		this.wtrRsdcDtlCt = wtrRsdcDtlCt;
	}
	public String getRlgnCd() {
		return rlgnCd;
	}
	public void setRlgnCd(String rlgnCd) {
		this.rlgnCd = rlgnCd;
	}
	public String getRlgnSect() {
		return rlgnSect;
	}
	public void setRlgnSect(String rlgnSect) {
		this.rlgnSect = rlgnSect;
	}
	public String getOcpCd() {
		return ocpCd;
	}
	public void setOcpCd(String ocpCd) {
		this.ocpCd = ocpCd;
	}
	public String getEduCd() {
		return eduCd;
	}
	public void setEduCd(String eduCd) {
		this.eduCd = eduCd;
	}
	public String getAdChngYn() {
		return adChngYn;
	}
	public void setAdChngYn(String adChngYn) {
		this.adChngYn = adChngYn;
	}
	public String getBfAdPrviceCd() {
		return bfAdPrviceCd;
	}
	public void setBfAdPrviceCd(String bfAdPrviceCd) {
		this.bfAdPrviceCd = bfAdPrviceCd;
	}
	public String getBfAdDstrCd() {
		return bfAdDstrCd;
	}
	public void setBfAdDstrCd(String bfAdDstrCd) {
		this.bfAdDstrCd = bfAdDstrCd;
	}
	public String getBfAdVillagCd() {
		return bfAdVillagCd;
	}
	public void setBfAdVillagCd(String bfAdVillagCd) {
		this.bfAdVillagCd = bfAdVillagCd;
	}
	public String getBfAdCd() {
		return bfAdCd;
	}
	public void setBfAdCd(String bfAdCd) {
		this.bfAdCd = bfAdCd;
	}
	public String getBfAdDtlCt() {
		return bfAdDtlCt;
	}
	public void setBfAdDtlCt(String bfAdDtlCt) {
		this.bfAdDtlCt = bfAdDtlCt;
	}
	public String getBfAdPostCd() {
		return bfAdPostCd;
	}
	public void setBfAdPostCd(String bfAdPostCd) {
		this.bfAdPostCd = bfAdPostCd;
	}
	public String getFmlyMberMlNo() {
		return fmlyMberMlNo;
	}
	public void setFmlyMberMlNo(String fmlyMberMlNo) {
		this.fmlyMberMlNo = fmlyMberMlNo;
	}
	public String getFmlyMberFemlNo() {
		return fmlyMberFemlNo;
	}
	public void setFmlyMberFemlNo(String fmlyMberFemlNo) {
		this.fmlyMberFemlNo = fmlyMberFemlNo;
	}
	public String getMltSrvcCd() {
		return mltSrvcCd;
	}
	public void setMltSrvcCd(String mltSrvcCd) {
		this.mltSrvcCd = mltSrvcCd;
	}
	public String getFmlyHadRsdtNo() {
		return fmlyHadRsdtNo;
	}
	public void setFmlyHadRsdtNo(String fmlyHadRsdtNo) {
		this.fmlyHadRsdtNo = fmlyHadRsdtNo;
	}
	public String getChifRgstOficrRsdtNo() {
		return chifRgstOficrRsdtNo;
	}
	public void setChifRgstOficrRsdtNo(String chifRgstOficrRsdtNo) {
		this.chifRgstOficrRsdtNo = chifRgstOficrRsdtNo;
	}
	public String getRgstOficrRsdtNo() {
		return rgstOficrRsdtNo;
	}
	public void setRgstOficrRsdtNo(String rgstOficrRsdtNo) {
		this.rgstOficrRsdtNo = rgstOficrRsdtNo;
	}
	public String getVillagIndiVefyRsdtNo() {
		return villagIndiVefyRsdtNo;
	}
	public void setVillagIndiVefyRsdtNo(String villagIndiVefyRsdtNo) {
		this.villagIndiVefyRsdtNo = villagIndiVefyRsdtNo;
	}
	public String getFmlyHadYn() {
		return fmlyHadYn;
	}
	public void setFmlyHadYn(String fmlyHadYn) {
		this.fmlyHadYn = fmlyHadYn;
	}
	public String getOrphanYn() {
		return orphanYn;
	}
	public void setOrphanYn(String orphanYn) {
		this.orphanYn = orphanYn;
	}
	public String getOficrYn() {
		return oficrYn;
	}
	public void setOficrYn(String oficrYn) {
		this.oficrYn = oficrYn;
	}
	public String getUdtDd() {
		return udtDd;
	}
	public void setUdtDd(String udtDd) {
		this.udtDd = udtDd;
	}
	public String getUdtReasionCd() {
		return udtReasionCd;
	}
	public void setUdtReasionCd(String udtReasionCd) {
		this.udtReasionCd = udtReasionCd;
	}
	
	public String getUdtReasionDtlCt() {
		return udtReasionDtlCt;
	}
	public void setUdtReasionDtlCt(String udtReasionDtlCt) {
		this.udtReasionDtlCt = udtReasionDtlCt;
	}
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	public String getFmlyBokRgstYn() {
		return fmlyBokRgstYn;
	}
	public void setFmlyBokRgstYn(String fmlyBokRgstYn) {
		this.fmlyBokRgstYn = fmlyBokRgstYn;
	}
	public String getFstRgstUserId() {
		return fstRgstUserId;
	}
	public void setFstRgstUserId(String fstRgstUserId) {
		this.fstRgstUserId = fstRgstUserId;
	}
	public String getFstRgstDt() {
		return fstRgstDt;
	}
	public void setFstRgstDt(String fstRgstDt) {
		this.fstRgstDt = fstRgstDt;
	}
	public String getLstUdtUserId() {
		return lstUdtUserId;
	}
	public void setLstUdtUserId(String lstUdtUserId) {
		this.lstUdtUserId = lstUdtUserId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	//KIM ADD
	public String getFmlyBokNo() {
		return fmlyBokNo;
	}

	public void setFmlyBokNo(String fmlyBokNo) {
		this.fmlyBokNo = fmlyBokNo;
	}



	
	public String getFmlyStusCd() {
		return fmlyStusCd;
	}

	public void setFmlyStusCd(String fmlyStusCd) {
		this.fmlyStusCd = fmlyStusCd;
	}

	public String getFmlyBokHstSrlNo() {
		return fmlyBokHstSrlNo;
	}

	public void setFmlyBokHstSrlNo(String fmlyBokHstSrlNo) {
		this.fmlyBokHstSrlNo = fmlyBokHstSrlNo;
	}
	
	public String getRdCnt() {
		return rdCnt;
	}
	public void setRdCnt(String rdCnt) {
		this.rdCnt = rdCnt;
	}

	public String getFbCnt() {
		return fbCnt;
	}

	public void setFbCnt(String fbCnt) {
		this.fbCnt = fbCnt;
	}

	public String getRgstDd() {
		return rgstDd;
	}
	
	public void setRgstDd(String rgstDd) {
		this.rgstDd = rgstDd;
	}
		
	public String getGdrCdNm() {
		return gdrCdNm;
	}
	public void setGdrCdNm(String gdrCdNm) {
		this.gdrCdNm = gdrCdNm;
	}
	public String getRlCdNm() {
		return rlCdNm;
	}
	
	public void setRlCdNm(String rlCdNm) {
		this.rlCdNm = rlCdNm;
	}
	
	public String getMrrgCdNm() {
		return mrrgCdNm;
	}
	
	public void setMrrgCdNm(String mrrgCdNm) {
		this.mrrgCdNm = mrrgCdNm;
	}
	
	public String getEtncityCdNm() {
		return etncityCdNm;
	}
	
	public void setEtncityCdNm(String etncityCdNm) {
		this.etncityCdNm = etncityCdNm;
	}
	
	public String getFmlyLangCdNm() {
		return fmlyLangCdNm;
	}
	
	public void setFmlyLangCdNm(String fmlyLangCdNm) {
		this.fmlyLangCdNm = fmlyLangCdNm;
	}
	
	public String getRlgnCdNm() {
		return rlgnCdNm;
	}
	
	public void setRlgnCdNm(String rlgnCdNm) {
		this.rlgnCdNm = rlgnCdNm;
	}
	
	public String getRlgnSectCdNm() {
		return rlgnSectCdNm;
	}
	
	public void setRlgnSectCdNm(String rlgnSectCdNm) {
		this.rlgnSectCdNm = rlgnSectCdNm;
	}
	
	public String getOcpCdNm() {
		return ocpCdNm;
	}
	
	public void setOcpCdNm(String ocpCdNm) {
		this.ocpCdNm = ocpCdNm;
	}
	
	public String getEduCdNm() {
		return eduCdNm;
	}
	
	public void setEduCdNm(String eduCdNm) {
		this.eduCdNm = eduCdNm;
	}
	
	public String getMlSrvcCdNm() {
		return mlSrvcCdNm;
	}
	
	public void setMlSrvcCdNm(String mlSrvcCdNm) {
		this.mlSrvcCdNm = mlSrvcCdNm;
	}
	
	
	
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	
	
	
	public String getUdtRsnCdNm() {
		return udtRsnCdNm;
	}
	
	public void setUdtRsnCdNm(String udtRsnCdNm) {
		this.udtRsnCdNm = udtRsnCdNm;
	}
	
	public String getRsdtStusCdNm() {
		return rsdtStusCdNm;
	}
	
	public void setRsdtStusCdNm(String rsdtStusCdNm) {
		this.rsdtStusCdNm = rsdtStusCdNm;
	}
	
	public String getErsrCdNm() {
		return ersrCdNm;
	}
	
	public void setErsrCdNm(String ersrCdNm) {
		this.ersrCdNm = ersrCdNm;
	}
	public String getNltyCdNm() {
		return nltyCdNm;
	}
	public void setNltyCdNm(String nltyCdNm) {
		this.nltyCdNm = nltyCdNm;
	}
	public String getFrgnLangnCdNm() {
		return frgnLangnCdNm;
	}
	public void setFrgnLangnCdNm(String frgnLangnCdNm) {
		this.frgnLangnCdNm = frgnLangnCdNm;
	}
	public String getNatLangCd() {
		return natLangCd;
	}
	public void setNatLangCd(String natLangCd) {
		this.natLangCd = natLangCd;
	}
	public String getFrgnLangCd() {
		return frgnLangCd;
	}
	public void setFrgnLangCd(String frgnLangCd) {
		this.frgnLangCd = frgnLangCd;
	}
	public String getDsbtCd() {
		return dsbtCd;
	}
	public void setDsbtCd(String dsbtCd) {
		this.dsbtCd = dsbtCd;
	}
	public String getNltyCd() {
		return nltyCd;
	}
	public void setNltyCd(String nltyCd) {
		this.nltyCd = nltyCd;
	}
	public String getFrgnLangCdNm() {
		return frgnLangCdNm;
	}
	public void setFrgnLangCdNm(String frgnLangCdNm) {
		this.frgnLangCdNm = frgnLangCdNm;
	}
	public String getNatLangCdNm() {
		return natLangCdNm;
	}
	public void setNatLangCdNm(String natLangCdNm) {
		this.natLangCdNm = natLangCdNm;
	}
	public String getDsbtCdNm() {
		return dsbtCdNm;
	}
	public void setDsbtCdNm(String dsbtCdNm) {
		this.dsbtCdNm = dsbtCdNm;
	}
	public String getDsbtDtlCt() {
		return dsbtDtlCt;
	}
	public void setDsbtDtlCt(String dsbtDtlCt) {
		this.dsbtDtlCt = dsbtDtlCt;
	}
	public String[] getNatLangCds() {
		return natLangCds;
	}
	public void setNatLangCds(String[] natLangCds) {
		this.natLangCds = natLangCds;
	}
	public String[] getFrgnLangCds() {
		return frgnLangCds;
	}
	public void setFrgnLangCds(String[] frgnLangCds) {
		this.frgnLangCds = frgnLangCds;
	}
	public String[] getNltyCds() {
		return nltyCds;
	}
	public void setNltyCds(String[] nltyCds) {
		this.nltyCds = nltyCds;
	}
	public String[] getDsbtCds() {
		return dsbtCds;
	}
	public void setDsbtCds(String[] dsbtCds) {
		this.dsbtCds = dsbtCds;
	}
	public String[] getDsbtDtlCts() {
		return dsbtDtlCts;
	}
	public void setDsbtDtlCts(String[] dsbtDtlCts) {
		this.dsbtDtlCts = dsbtDtlCts;
	}
	public String getRlCd() {
		return rlCd;
	}
	public void setRlCd(String rlCd) {
		this.rlCd = rlCd;
	}
	public String getBldTyeCdNm() {
		return bldTyeCdNm;
	}
	public void setBldTyeCdNm(String bldTyeCdNm) {
		this.bldTyeCdNm = bldTyeCdNm;
	}
	public String getCrdIsucePlceCdNm() {
		return crdIsucePlceCdNm;
	}
	public void setCrdIsucePlceCdNm(String crdIsucePlceCdNm) {
		this.crdIsucePlceCdNm = crdIsucePlceCdNm;
	}
	public String getMltSrvcCdNm() {
		return mltSrvcCdNm;
	}
	public void setMltSrvcCdNm(String mltSrvcCdNm) {
		this.mltSrvcCdNm = mltSrvcCdNm;
	}
	public String getFmlyHadRsdtNm() {
		return fmlyHadRsdtNm;
	}
	public void setFmlyHadRsdtNm(String fmlyHadRsdtNm) {
		this.fmlyHadRsdtNm = fmlyHadRsdtNm;
	}
	public String getChifRgstOficrRsdtNm() {
		return chifRgstOficrRsdtNm;
	}
	public void setChifRgstOficrRsdtNm(String chifRgstOficrRsdtNm) {
		this.chifRgstOficrRsdtNm = chifRgstOficrRsdtNm;
	}
	public String getVillagIndiVefyRsdtNm() {
		return villagIndiVefyRsdtNm;
	}
	public void setVillagIndiVefyRsdtNm(String villagIndiVefyRsdtNm) {
		this.villagIndiVefyRsdtNm = villagIndiVefyRsdtNm;
	}
	public String getRgstOficrRsdtNm() {
		return rgstOficrRsdtNm;
	}
	public void setRgstOficrRsdtNm(String rgstOficrRsdtNm) {
		this.rgstOficrRsdtNm = rgstOficrRsdtNm;
	}
	
	public String getUdtRsnDtlCt() {
		return udtRsnDtlCt;
	}
	public void setUdtRsnDtlCt(String udtRsnDtlCt) {
		this.udtRsnDtlCt = udtRsnDtlCt;
	}
	public String getErsrDdNm() {
		return ersrDdNm;
	}
	public void setErsrDdNm(String ersrDdNm) {
		this.ersrDdNm = ersrDdNm;
	}
	public String getUdtRsnCd() {
		return udtRsnCd;
	}
	public void setUdtRsnCd(String udtRsnCd) {
		this.udtRsnCd = udtRsnCd;
	}
	public String getUdtReasionDtlCd() {
		return udtReasionDtlCd;
	}
	public void setUdtReasionDtlCd(String udtReasionDtlCd) {
		this.udtReasionDtlCd = udtReasionDtlCd;
	}
	public String getAdChngYnNm() {
		return adChngYnNm;
	}
	public void setAdChngYnNm(String adChngYnNm) {
		this.adChngYnNm = adChngYnNm;
	}
	public String getFmlyHadYnNm() {
		return fmlyHadYnNm;
	}
	public void setFmlyHadYnNm(String fmlyHadYnNm) {
		this.fmlyHadYnNm = fmlyHadYnNm;
	}
	public String getOrphanYnNm() {
		return orphanYnNm;
	}
	public void setOrphanYnNm(String orphanYnNm) {
		this.orphanYnNm = orphanYnNm;
	}
	public String getOficrYnNm() {
		return oficrYnNm;
	}
	public void setOficrYnNm(String oficrYnNm) {
		this.oficrYnNm = oficrYnNm;
	}
	public String getRsdtNoDp() {
		return rsdtNoDp;
	}
	public void setRsdtNoDp(String rsdtNoDp) {
		this.rsdtNoDp = rsdtNoDp;
	}
	public String getRlgnSectCd() {
		return rlgnSectCd;
	}
	public void setRlgnSectCd(String rlgnSectCd) {
		this.rlgnSectCd = rlgnSectCd;
	}
	public String getSrchOficrYn() {
		return srchOficrYn;
	}
	public void setSrchOficrYn(String srchOficrYn) {
		this.srchOficrYn = srchOficrYn;
	}
	public String getFmlyBokNoNum() {
		return fmlyBokNoNum;
	}
	public void setFmlyBokNoNum(String fmlyBokNoNum) {
		this.fmlyBokNoNum = fmlyBokNoNum;
	}
	public String getRsdtRgstDd() {
		return rsdtRgstDd;
	}
	public void setRsdtRgstDd(String rsdtRgstDd) {
		this.rsdtRgstDd = rsdtRgstDd;
	}
	public String getRsdtRgstYn() {
		return rsdtRgstYn;
	}
	public void setRsdtRgstYn(String rsdtRgstYn) {
		this.rsdtRgstYn = rsdtRgstYn;
	}
	public String getTeamLedrCfmYn() {
		return teamLedrCfmYn;
	}
	public void setTeamLedrCfmYn(String teamLedrCfmYn) {
		this.teamLedrCfmYn = teamLedrCfmYn;
	}
	public String getCfmTeamLedrid() {
		return cfmTeamLedrid;
	}
	public void setCfmTeamLedrid(String cfmTeamLedrid) {
		this.cfmTeamLedrid = cfmTeamLedrid;
	}
	public String getEncyCd() {
		return encyCd;
	}
	public void setEncyCd(String encyCd) {
		this.encyCd = encyCd;
	}
	public String getEncyCdNm() {
		return encyCdNm;
	}
	public void setEncyCdNm(String encyCdNm) {
		this.encyCdNm = encyCdNm;
	}
	public String getFmlyMberNo() {
		return fmlyMberNo;
	}
	public void setFmlyMberNo(String fmlyMberNo) {
		this.fmlyMberNo = fmlyMberNo;
	}
	public String getFstVefyIndiGivNm() {
		return fstVefyIndiGivNm;
	}
	public void setFstVefyIndiGivNm(String fstVefyIndiGivNm) {
		this.fstVefyIndiGivNm = fstVefyIndiGivNm;
	}
	public String getFstVefyIndiSurnm() {
		return fstVefyIndiSurnm;
	}
	public void setFstVefyIndiSurnm(String fstVefyIndiSurnm) {
		this.fstVefyIndiSurnm = fstVefyIndiSurnm;
	}
	public String getSecdVefyIndiGivNm() {
		return secdVefyIndiGivNm;
	}
	public void setSecdVefyIndiGivNm(String secdVefyIndiGivNm) {
		this.secdVefyIndiGivNm = secdVefyIndiGivNm;
	}
	public String getSecdVefyIndiSurnm() {
		return secdVefyIndiSurnm;
	}
	public void setSecdVefyIndiSurnm(String secdVefyIndiSurnm) {
		this.secdVefyIndiSurnm = secdVefyIndiSurnm;
	}
	public String getTamLedrCfmYn() {
		return tamLedrCfmYn;
	}
	public void setTamLedrCfmYn(String tamLedrCfmYn) {
		this.tamLedrCfmYn = tamLedrCfmYn;
	}
	public String getCfmTamLedrId() {
		return cfmTamLedrId;
	}
	public void setCfmTamLedrId(String cfmTamLedrId) {
		this.cfmTamLedrId = cfmTamLedrId;
	}
	public String getBioRgstYn() {
		return bioRgstYn;
	}
	public void setBioRgstYn(String bioRgstYn) {
		this.bioRgstYn = bioRgstYn;
	}
	public String getCfmTamLedrIdNm() {
		return cfmTamLedrIdNm;
	}
	public void setCfmTamLedrIdNm(String cfmTamLedrIdNm) {
		this.cfmTamLedrIdNm = cfmTamLedrIdNm;
	}
	public String getRsdtRgstIdNm() {
		return rsdtRgstIdNm;
	}
	public void setRsdtRgstIdNm(String rsdtRgstIdNm) {
		this.rsdtRgstIdNm = rsdtRgstIdNm;
	}
	public String getTeamNm() {
		return teamNm;
	}
	public void setTeamNm(String teamNm) {
		this.teamNm = teamNm;
	}
	public String getCrdIsuLangCd() {
		return crdIsuLangCd;
	}
	public void setCrdIsuLangCd(String crdIsuLangCd) {
		this.crdIsuLangCd = crdIsuLangCd;
	}
	public String getCrdIsuLangCdNm() {
		return crdIsuLangCdNm;
	}
	public void setCrdIsuLangCdNm(String crdIsuLangCdNm) {
		this.crdIsuLangCdNm = crdIsuLangCdNm;
	}
	public String getCrdIsuceDdNid() {
		return crdIsuceDdNid;
	}
	public void setCrdIsuceDdNid(String crdIsuceDdNid) {
		this.crdIsuceDdNid = crdIsuceDdNid;
	}
	public String getCrdIsucePlceCdNid() {
		return crdIsucePlceCdNid;
	}
	public void setCrdIsucePlceCdNid(String crdIsucePlceCdNid) {
		this.crdIsucePlceCdNid = crdIsucePlceCdNid;
	}
	public String getCrdIsucePlceCdNmNid() {
		return crdIsucePlceCdNmNid;
	}
	public void setCrdIsucePlceCdNmNid(String crdIsucePlceCdNmNid) {
		this.crdIsucePlceCdNmNid = crdIsucePlceCdNmNid;
	}
	public String getCalTye() {
		return calTye;
	}
	public void setCalTye(String calTye) {
		this.calTye = calTye;
	}
	public String getSeRegOff() {
		return seRegOff;
	}
	public void setSeRegOff(String seRegOff) {
		this.seRegOff = seRegOff;
	}
	public String getFstVefyTye() {
		return fstVefyTye;
	}
	public void setFstVefyTye(String fstVefyTye) {
		this.fstVefyTye = fstVefyTye;
	}
	public String getFstVefyRsdtNo() {
		return fstVefyRsdtNo;
	}
	public void setFstVefyRsdtNo(String fstVefyRsdtNo) {
		this.fstVefyRsdtNo = fstVefyRsdtNo;
	}
	public String getSecdVefyTye() {
		return secdVefyTye;
	}
	public void setSecdVefyTye(String secdVefyTye) {
		this.secdVefyTye = secdVefyTye;
	}
	public String getSecdVefyRsdtNo() {
		return secdVefyRsdtNo;
	}
	public void setSecdVefyRsdtNo(String secdVefyRsdtNo) {
		this.secdVefyRsdtNo = secdVefyRsdtNo;
	}
	public String getPreAdCd() {
		return preAdCd;
	}
	public void setPreAdCd(String preAdCd) {
		this.preAdCd = preAdCd;
	}
	public String getCrdIsuceDdGr() {
		return crdIsuceDdGr;
	}
	public void setCrdIsuceDdGr(String crdIsuceDdGr) {
		this.crdIsuceDdGr = crdIsuceDdGr;
	}
	public String getCrdExpiryDdGr() {
		return crdExpiryDdGr;
	}
	public void setCrdExpiryDdGr(String crdExpiryDdGr) {
		this.crdExpiryDdGr = crdExpiryDdGr;
	}
	public String getPmntAdCdCt() {
		return pmntAdCdCt;
	}
	public void setPmntAdCdCt(String pmntAdCdCt) {
		this.pmntAdCdCt = pmntAdCdCt;
	}
	public String getCurtAdCdCt() {
		return curtAdCdCt;
	}
	public void setCurtAdCdCt(String curtAdCdCt) {
		this.curtAdCdCt = curtAdCdCt;
	}
	public String getBthPlceCdCt() {
		return bthPlceCdCt;
	}
	public void setBthPlceCdCt(String bthPlceCdCt) {
		this.bthPlceCdCt = bthPlceCdCt;
	}
	public String getSmrRsdcCdCt() {
		return smrRsdcCdCt;
	}
	public void setSmrRsdcCdCt(String smrRsdcCdCt) {
		this.smrRsdcCdCt = smrRsdcCdCt;
	}
	public String getWtrRsdcCdCt() {
		return wtrRsdcCdCt;
	}
	public void setWtrRsdcCdCt(String wtrRsdcCdCt) {
		this.wtrRsdcCdCt = wtrRsdcCdCt;
	}
	public String getBthDdGr() {
		return bthDdGr;
	}
	public void setBthDdGr(String bthDdGr) {
		this.bthDdGr = bthDdGr;
	}
	public String getWrkTgtCn() {
		return wrkTgtCn;
	}
	public void setWrkTgtCn(String wrkTgtCn) {
		this.wrkTgtCn = wrkTgtCn;
	}
	public String getWrkSucessCn() {
		return wrkSucessCn;
	}
	public void setWrkSucessCn(String wrkSucessCn) {
		this.wrkSucessCn = wrkSucessCn;
	}
	public String getWrkErorCn() {
		return wrkErorCn;
	}
	public void setWrkErorCn(String wrkErorCn) {
		this.wrkErorCn = wrkErorCn;
	}
	public String getFleNm() {
		return fleNm;
	}
	public void setFleNm(String fleNm) {
		this.fleNm = fleNm;
	}
	public String getCrdIsuDd() {
		return crdIsuDd;
	}
	public void setCrdIsuDd(String crdIsuDd) {
		this.crdIsuDd = crdIsuDd;
	}
	public String getCrdIsuStusCd() {
		return crdIsuStusCd;
	}
	public void setCrdIsuStusCd(String crdIsuStusCd) {
		this.crdIsuStusCd = crdIsuStusCd;
	}
	public String getCrdIsuErorDd() {
		return crdIsuErorDd;
	}
	public void setCrdIsuErorDd(String crdIsuErorDd) {
		this.crdIsuErorDd = crdIsuErorDd;
	}
	public String getCrdIsuErorRsn() {
		return crdIsuErorRsn;
	}
	public void setCrdIsuErorRsn(String crdIsuErorRsn) {
		this.crdIsuErorRsn = crdIsuErorRsn;
	}
	public String getCrdIsuDueDd() {
		return crdIsuDueDd;
	}
	public void setCrdIsuDueDd(String crdIsuDueDd) {
		this.crdIsuDueDd = crdIsuDueDd;
	}
	public String getCrdEncUsePin() {
		return crdEncUsePin;
	}
	public void setCrdEncUsePin(String crdEncUsePin) {
		this.crdEncUsePin = crdEncUsePin;
	}
	public String getCrdEncSoPin() {
		return crdEncSoPin;
	}
	public void setCrdEncSoPin(String crdEncSoPin) {
		this.crdEncSoPin = crdEncSoPin;
	}
	public String getPoliCntrCd() {
		return poliCntrCd;
	}
	public void setPoliCntrCd(String poliCntrCd) {
		this.poliCntrCd = poliCntrCd;
	}
	public String getPoliCntrCdNm() {
		return poliCntrCdNm;
	}
	public void setPoliCntrCdNm(String poliCntrCdNm) {
		this.poliCntrCdNm = poliCntrCdNm;
	}
	public String getBthNatDiv() {
		return bthNatDiv;
	}
	public void setBthNatDiv(String bthNatDiv) {
		this.bthNatDiv = bthNatDiv;
	}
	public String getBthNatCd() {
		return bthNatCd;
	}
	public void setBthNatCd(String bthNatCd) {
		this.bthNatCd = bthNatCd;
	}
	public String getBthNatCdNm() {
		return bthNatCdNm;
	}
	public void setBthNatCdNm(String bthNatCdNm) {
		this.bthNatCdNm = bthNatCdNm;
	}
	public String getFrgnBthCtyNm() {
		return frgnBthCtyNm;
	}
	public void setFrgnBthCtyNm(String frgnBthCtyNm) {
		this.frgnBthCtyNm = frgnBthCtyNm;
	}
	public String getPoliOne() {
		return poliOne;
	}
	public void setPoliOne(String poliOne) {
		this.poliOne = poliOne;
	}
	public String getPoliTwo() {
		return poliTwo;
	}
	public void setPoliTwo(String poliTwo) {
		this.poliTwo = poliTwo;
	}
	public String getPoliCntrCd1() {
		return poliCntrCd1;
	}
	public void setPoliCntrCd1(String poliCntrCd1) {
		this.poliCntrCd1 = poliCntrCd1;
	}
	public String getPoliCntrCd2() {
		return poliCntrCd2;
	}
	public void setPoliCntrCd2(String poliCntrCd2) {
		this.poliCntrCd2 = poliCntrCd2;
	}
	public String getPoliCntrCdNm1() {
		return poliCntrCdNm1;
	}
	public void setPoliCntrCdNm1(String poliCntrCdNm1) {
		this.poliCntrCdNm1 = poliCntrCdNm1;
	}
	public String getPoliCntrCdNm2() {
		return poliCntrCdNm2;
	}
	public void setPoliCntrCdNm2(String poliCntrCdNm2) {
		this.poliCntrCdNm2 = poliCntrCdNm2;
	}
	public String getPoliCntrCdNm3() {
		return poliCntrCdNm3;
	}
	public void setPoliCntrCdNm3(String poliCntrCdNm3) {
		this.poliCntrCdNm3 = poliCntrCdNm3;
	}
	public String getWrkSttDt() {
		return wrkSttDt;
	}
	public void setWrkSttDt(String wrkSttDt) {
		this.wrkSttDt = wrkSttDt;
	}
	public String getCrdCd() {
		return crdCd;
	}
	public void setCrdCd(String crdCd) {
		this.crdCd = crdCd;
	}
	public String getAplCd() {
		return aplCd;
	}
	public void setAplCd(String aplCd) {
		this.aplCd = aplCd;
	}
	public String getSrlNo() {
		return srlNo;
	}
	public void setSrlNo(String srlNo) {
		this.srlNo = srlNo;
	}
	public String getRsdtStusCd() {
		return rsdtStusCd;
	}
	public void setRsdtStusCd(String rsdtStusCd) {
		this.rsdtStusCd = rsdtStusCd;
	}
	public String getRsdtSeqNo() {
		return rsdtSeqNo;
	}
	public void setRsdtSeqNo(String rsdtSeqNo) {
		this.rsdtSeqNo = rsdtSeqNo;
	}
	public String getSndRsut() {
		return sndRsut;
	}
	public void setSndRsut(String sndRsut) {
		this.sndRsut = sndRsut;
	}
	public String getDescFleNm() {
		return descFleNm;
	}
	public void setDescFleNm(String descFleNm) {
		this.descFleNm = descFleNm;
	}
	public String getSndDt() {
		return sndDt;
	}
	public void setSndDt(String sndDt) {
		this.sndDt = sndDt;
	}
	public String[] getSndBox() {
		return sndBox;
	}
	public void setSndBox(String[] sndBox) {
		this.sndBox = sndBox;
	}
	public String getUseYns() {
		return useYns;
	}
	public void setUseYns(String useYns) {
		this.useYns = useYns;
	}
	public String getErsrYns() {
		return ersrYns;
	}
	public void setErsrYns(String ersrYns) {
		this.ersrYns = ersrYns;
	}

	public RsdtInfrVO init(){
		return new RsdtInfrVO();
	}
	public String getFmlyBokSeqNo() {
		return fmlyBokSeqNo;
	}
	public void setFmlyBokSeqNo(String fmlyBokSeqNo) {
		this.fmlyBokSeqNo = fmlyBokSeqNo;
	}
	public String getOldCrdIsucePlce() {
		return oldCrdIsucePlce;
	}
	public void setOldCrdIsucePlce(String oldCrdIsucePlce) {
		this.oldCrdIsucePlce = oldCrdIsucePlce;
	}
	public String getOldCrdIsucePlceNm() {
		return oldCrdIsucePlceNm;
	}
	public void setOldCrdIsucePlceNm(String oldCrdIsucePlceNm) {
		this.oldCrdIsucePlceNm = oldCrdIsucePlceNm;
	}
	public String getMthrNm() {
		return mthrNm;
	}
	public void setMthrNm(String mthrNm) {
		this.mthrNm = mthrNm;
	}
	public String getFthrRsdtSeqNo() {
		return fthrRsdtSeqNo;
	}
	public void setFthrRsdtSeqNo(String fthrRsdtSeqNo) {
		this.fthrRsdtSeqNo = fthrRsdtSeqNo;
	}
	public String getMthrRsdtSeqNo() {
		return mthrRsdtSeqNo;
	}
	public void setMthrRsdtSeqNo(String mthrRsdtSeqNo) {
		this.mthrRsdtSeqNo = mthrRsdtSeqNo;
	}
	public String getRsdtTyeCd() {
		return rsdtTyeCd;
	}
	public void setRsdtTyeCd(String rsdtTyeCd) {
		this.rsdtTyeCd = rsdtTyeCd;
	}
	public String getFstVefyIndiNm() {
		return fstVefyIndiNm;
	}
	public void setFstVefyIndiNm(String fstVefyIndiNm) {
		this.fstVefyIndiNm = fstVefyIndiNm;
	}
	public String getSecdVefyIndiNm() {
		return secdVefyIndiNm;
	}
	public void setSecdVefyIndiNm(String secdVefyIndiNm) {
		this.secdVefyIndiNm = secdVefyIndiNm;
	}
	public String getEnNm() {
		return enNm;
	}
	public void setEnNm(String enNm) {
		this.enNm = enNm;
	}
	public String getFthrNm() {
		return fthrNm;
	}
	public void setFthrNm(String fthrNm) {
		this.fthrNm = fthrNm;
	}
	public String getGfthrNm() {
		return gfthrNm;
	}
	public void setGfthrNm(String gfthrNm) {
		this.gfthrNm = gfthrNm;
	}
	public String getMrrgSeqNo() {
		return mrrgSeqNo;
	}
	public void setMrrgSeqNo(String mrrgSeqNo) {
		this.mrrgSeqNo = mrrgSeqNo;
	}
	public String getSpusNm() {
		return spusNm;
	}
	public void setSpusNm(String spusNm) {
		this.spusNm = spusNm;
	}
	public String[] getRsdtSeqNos() {
		return rsdtSeqNos;
	}
	public void setRsdtSeqNos(String[] rsdtSeqNos) {
		this.rsdtSeqNos = rsdtSeqNos;
	}
	public String[] getMrrgSeqNos() {
		return mrrgSeqNos;
	}
	public void setMrrgSeqNos(String[] mrrgSeqNos) {
		this.mrrgSeqNos = mrrgSeqNos;
	}
	public String[] getSpusNms() {
		return spusNms;
	}
	public void setSpusNms(String[] spusNms) {
		this.spusNms = spusNms;
	}
	public String getFmlyNoDis() {
		return fmlyNoDis;
	}
	public void setFmlyNoDis(String fmlyNoDis) {
		this.fmlyNoDis = fmlyNoDis;
	}
	public String getGdrCdVal() {
		return gdrCdVal;
	}
	public void setGdrCdVal(String gdrCdVal) {
		this.gdrCdVal = gdrCdVal;
	}
	public String getPoliCntrSeqNo() {
		return poliCntrSeqNo;
	}
	public void setPoliCntrSeqNo(String poliCntrSeqNo) {
		this.poliCntrSeqNo = poliCntrSeqNo;
	}
	public String getPoliCntrSeqNoNm() {
		return poliCntrSeqNoNm;
	}
	public void setPoliCntrSeqNoNm(String poliCntrSeqNoNm) {
		this.poliCntrSeqNoNm = poliCntrSeqNoNm;
	}
	public String getMrrgDd() {
		return mrrgDd;
	}
	public void setMrrgDd(String mrrgDd) {
		this.mrrgDd = mrrgDd;
	}
	public String getSpusRsdtSeqNo() {
		return spusRsdtSeqNo;
	}
	public void setSpusRsdtSeqNo(String spusRsdtSeqNo) {
		this.spusRsdtSeqNo = spusRsdtSeqNo;
	}
	public String getFrngrYn() {
		return frngrYn;
	}
	public void setFrngrYn(String frngrYn) {
		this.frngrYn = frngrYn;
	}
	public String getInitialDatYn() {
		return initialDatYn;
	}
	public void setInitialDatYn(String initialDatYn) {
		this.initialDatYn = initialDatYn;
	}
	public String getRgstOrgnzCd() {
		return rgstOrgnzCd;
	}
	public void setRgstOrgnzCd(String rgstOrgnzCd) {
		this.rgstOrgnzCd = rgstOrgnzCd;
	}
	public String getDltYn() {
		return dltYn;
	}
	public void setDltYn(String dltYn) {
		this.dltYn = dltYn;
	}
	public String getSpusDelList() {
		return spusDelList;
	}
	public void setSpusDelList(String spusDelList) {
		this.spusDelList = spusDelList;
	}
	public String getAprvDd() {
		return aprvDd;
	}
	public void setAprvDd(String aprvDd) {
		this.aprvDd = aprvDd;
	}
	public String getCrdIsuDueDdDay() {
		return crdIsuDueDdDay;
	}
	public void setCrdIsuDueDdDay(String crdIsuDueDdDay) {
		this.crdIsuDueDdDay = crdIsuDueDdDay;
	}
	public String getSgnt() {
		return sgnt;
	}
	public void setSgnt(String sgnt) {
		this.sgnt = sgnt;
	}
	public String getRsdtTyeCdNm() {
		return rsdtTyeCdNm;
	}
	public void setRsdtTyeCdNm(String rsdtTyeCdNm) {
		this.rsdtTyeCdNm = rsdtTyeCdNm;
	}
	public String getRgstYn() {
		return rgstYn;
	}
	public void setRgstYn(String rgstYn) {
		this.rgstYn = rgstYn;
	}
	public String getRsdtAccnSeqNo() {
		return rsdtAccnSeqNo;
	}
	public void setRsdtAccnSeqNo(String rsdtAccnSeqNo) {
		this.rsdtAccnSeqNo = rsdtAccnSeqNo;
	}
	public String getCrdIsuSeqNo() {
		return crdIsuSeqNo;
	}
	public void setCrdIsuSeqNo(String crdIsuSeqNo) {
		this.crdIsuSeqNo = crdIsuSeqNo;
	}
	public String getCrdDitbCd() {
		return crdDitbCd;
	}
	public void setCrdDitbCd(String crdDitbCd) {
		this.crdDitbCd = crdDitbCd;
	}
	public String getCrdDitbDd() {
		return crdDitbDd;
	}
	public void setCrdDitbDd(String crdDitbDd) {
		this.crdDitbDd = crdDitbDd;
	}
	public String getAplDd() {
		return aplDd;
	}
	public void setAplDd(String aplDd) {
		this.aplDd = aplDd;
	}
	public String getWrkEdDt() {
		return wrkEdDt;
	}
	public void setWrkEdDt(String wrkEdDt) {
		this.wrkEdDt = wrkEdDt;
	}
	public String getOrgnzCd() {
		return orgnzCd;
	}
	public void setOrgnzCd(String orgnzCd) {
		this.orgnzCd = orgnzCd;
	}
	public String getPrcssDivCd() {
		return prcssDivCd;
	}
	public void setPrcssDivCd(String prcssDivCd) {
		this.prcssDivCd = prcssDivCd;
	}
	public String getFleLc() {
		return fleLc;
	}
	public void setFleLc(String fleLc) {
		this.fleLc = fleLc;
	}
	public String getTgtCn() {
		return tgtCn;
	}
	public void setTgtCn(String tgtCn) {
		this.tgtCn = tgtCn;
	}
	public String getScsCn() {
		return scsCn;
	}
	public void setScsCn(String scsCn) {
		this.scsCn = scsCn;
	}
	public String getErorCn() {
		return erorCn;
	}
	public void setErorCn(String erorCn) {
		this.erorCn = erorCn;
	}
	public String getErorYn() {
		return erorYn;
	}
	public void setErorYn(String erorYn) {
		this.erorYn = erorYn;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getSndRcivDt() {
		return sndRcivDt;
	}
	public void setSndRcivDt(String sndRcivDt) {
		this.sndRcivDt = sndRcivDt;
	}
	public String getSndRcivDivCd() {
		return sndRcivDivCd;
	}
	public void setSndRcivDivCd(String sndRcivDivCd) {
		this.sndRcivDivCd = sndRcivDivCd;
	}
	public String getBioRgstYnTmp() {
		return bioRgstYnTmp;
	}
	public void setBioRgstYnTmp(String bioRgstYnTmp) {
		this.bioRgstYnTmp = bioRgstYnTmp;
	}
	public String getBioCaptYn() {
		return bioCaptYn;
	}
	public void setBioCaptYn(String bioCaptYn) {
		this.bioCaptYn = bioCaptYn;
	}
	public String getCrdIsuceStusCd() {
		return crdIsuceStusCd;
	}
	public void setCrdIsuceStusCd(String crdIsuceStusCd) {
		this.crdIsuceStusCd = crdIsuceStusCd;
	}
	public String getFleRcivYmd() {
		return fleRcivYmd;
	}
	public void setFleRcivYmd(String fleRcivYmd) {
		this.fleRcivYmd = fleRcivYmd;
	}
	public String getRcivFleNm() {
		return rcivFleNm;
	}
	public void setRcivFleNm(String rcivFleNm) {
		this.rcivFleNm = rcivFleNm;
	}
	public String getErorCd() {
		return erorCd;
	}
	public void setErorCd(String erorCd) {
		this.erorCd = erorCd;
	}
	public String getErorMsg() {
		return erorMsg;
	}
	public void setErorMsg(String erorMsg) {
		this.erorMsg = erorMsg;
	}
	public String getErorPrcssYn() {
		return erorPrcssYn;
	}
	public void setErorPrcssYn(String erorPrcssYn) {
		this.erorPrcssYn = erorPrcssYn;
	}
	public String getErorPrcssUserId() {
		return erorPrcssUserId;
	}
	public void setErorPrcssUserId(String erorPrcssUserId) {
		this.erorPrcssUserId = erorPrcssUserId;
	}
	public String getCrdDitbSeqNo() {
		return crdDitbSeqNo;
	}
	public void setCrdDitbSeqNo(String crdDitbSeqNo) {
		this.crdDitbSeqNo = crdDitbSeqNo;
	}
	public String getSpusSurnm() {
		return spusSurnm;
	}
	public void setSpusSurnm(String spusSurnm) {
		this.spusSurnm = spusSurnm;
	}
	public String getSpusGivNm() {
		return spusGivNm;
	}
	public void setSpusGivNm(String spusGivNm) {
		this.spusGivNm = spusGivNm;
	}
	public String getBldTyeDocVrfd() {
		return bldTyeDocVrfd;
	}
	public void setBldTyeDocVrfd(String bldTyeDocVrfd) {
		this.bldTyeDocVrfd = bldTyeDocVrfd;
	}
	public String getEduLvDocVrfd() {
		return eduLvDocVrfd;
	}
	public void setEduLvDocVrfd(String eduLvDocVrfd) {
		this.eduLvDocVrfd = eduLvDocVrfd;
	}
	public String getPrntDd() {
		return prntDd;
	}
	public void setPrntDd(String prntDd) {
		this.prntDd = prntDd;
	}
	public String getOldCrdNo1() {
		return oldCrdNo1;
	}
	public void setOldCrdNo1(String oldCrdNo1) {
		this.oldCrdNo1 = oldCrdNo1;
	}
	public String getOldCrdNo2() {
		return oldCrdNo2;
	}
	public void setOldCrdNo2(String oldCrdNo2) {
		this.oldCrdNo2 = oldCrdNo2;
	}
	public String getOldCrdNo3() {
		return oldCrdNo3;
	}
	public void setOldCrdNo3(String oldCrdNo3) {
		this.oldCrdNo3 = oldCrdNo3;
	}
	public String getFthrOldCrdNo1() {
		return fthrOldCrdNo1;
	}
	public void setFthrOldCrdNo1(String fthrOldCrdNo1) {
		this.fthrOldCrdNo1 = fthrOldCrdNo1;
	}
	public String getFthrOldCrdNo2() {
		return fthrOldCrdNo2;
	}
	public void setFthrOldCrdNo2(String fthrOldCrdNo2) {
		this.fthrOldCrdNo2 = fthrOldCrdNo2;
	}
	public String getFthrOldCrdNo3() {
		return fthrOldCrdNo3;
	}
	public void setFthrOldCrdNo3(String fthrOldCrdNo3) {
		this.fthrOldCrdNo3 = fthrOldCrdNo3;
	}
	public String getMthrOldCrdNo1() {
		return mthrOldCrdNo1;
	}
	public void setMthrOldCrdNo1(String mthrOldCrdNo1) {
		this.mthrOldCrdNo1 = mthrOldCrdNo1;
	}
	public String getMthrOldCrdNo2() {
		return mthrOldCrdNo2;
	}
	public void setMthrOldCrdNo2(String mthrOldCrdNo2) {
		this.mthrOldCrdNo2 = mthrOldCrdNo2;
	}
	public String getMthrOldCrdNo3() {
		return mthrOldCrdNo3;
	}
	public void setMthrOldCrdNo3(String mthrOldCrdNo3) {
		this.mthrOldCrdNo3 = mthrOldCrdNo3;
	}
	public String getGfthrOldCrdNo1() {
		return gfthrOldCrdNo1;
	}
	public void setGfthrOldCrdNo1(String gfthrOldCrdNo1) {
		this.gfthrOldCrdNo1 = gfthrOldCrdNo1;
	}
	public String getGfthrOldCrdNo2() {
		return gfthrOldCrdNo2;
	}
	public void setGfthrOldCrdNo2(String gfthrOldCrdNo2) {
		this.gfthrOldCrdNo2 = gfthrOldCrdNo2;
	}
	public String getGfthrOldCrdNo3() {
		return gfthrOldCrdNo3;
	}
	public void setGfthrOldCrdNo3(String gfthrOldCrdNo3) {
		this.gfthrOldCrdNo3 = gfthrOldCrdNo3;
	}
	public String getSpusOldCrdNo1() {
		return spusOldCrdNo1;
	}
	public void setSpusOldCrdNo1(String spusOldCrdNo1) {
		this.spusOldCrdNo1 = spusOldCrdNo1;
	}
	public String getSpusOldCrdNo2() {
		return spusOldCrdNo2;
	}
	public void setSpusOldCrdNo2(String spusOldCrdNo2) {
		this.spusOldCrdNo2 = spusOldCrdNo2;
	}
	public String getSpusOldCrdNo3() {
		return spusOldCrdNo3;
	}
	public void setSpusOldCrdNo3(String spusOldCrdNo3) {
		this.spusOldCrdNo3 = spusOldCrdNo3;
	}
	public String getCrdIsuSrlNo() {
		return crdIsuSrlNo;
	}
	public void setCrdIsuSrlNo(String crdIsuSrlNo) {
		this.crdIsuSrlNo = crdIsuSrlNo;
	}
	public String getBsnCd() {
		return bsnCd;
	}
	public void setBsnCd(String bsnCd) {
		this.bsnCd = bsnCd;
	}
	public String getBsnSeqNo() {
		return bsnSeqNo;
	}
	public void setBsnSeqNo(String bsnSeqNo) {
		this.bsnSeqNo = bsnSeqNo;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	public String getAdultAge() {
		return adultAge;
	}
	public void setAdultAge(String adultAge) {
		this.adultAge = adultAge;
	}
	public String getCrdIsuceSrlNo() {
		return crdIsuceSrlNo;
	}
	public void setCrdIsuceSrlNo(String crdIsuceSrlNo) {
		this.crdIsuceSrlNo = crdIsuceSrlNo;
	}
	public String getOldCrdNo4() {
		return oldCrdNo4;
	}
	public void setOldCrdNo4(String oldCrdNo4) {
		this.oldCrdNo4 = oldCrdNo4;
	}
	public String getMthrOldCrdNo4() {
		return mthrOldCrdNo4;
	}
	public void setMthrOldCrdNo4(String mthrOldCrdNo4) {
		this.mthrOldCrdNo4 = mthrOldCrdNo4;
	}
	public String getGfthrOldCrdNo4() {
		return gfthrOldCrdNo4;
	}
	public void setGfthrOldCrdNo4(String gfthrOldCrdNo4) {
		this.gfthrOldCrdNo4 = gfthrOldCrdNo4;
	}
	public String getSpusOldCrdNo4() {
		return spusOldCrdNo4;
	}
	public void setSpusOldCrdNo4(String spusOldCrdNo4) {
		this.spusOldCrdNo4 = spusOldCrdNo4;
	}
	public String getOldCrdIsuceDd() {
		return oldCrdIsuceDd;
	}
	public void setOldCrdIsuceDd(String oldCrdIsuceDd) {
		this.oldCrdIsuceDd = oldCrdIsuceDd;
	}
	public String getEduYn() {
		return eduYn;
	}
	public void setEduYn(String eduYn) {
		this.eduYn = eduYn;
	}
	public String getCntTelNo() {
		return cntTelNo;
	}
	public void setCntTelNo(String cntTelNo) {
		this.cntTelNo = cntTelNo;
	}
	public String getEmlAdNo() {
		return emlAdNo;
	}
	public void setEmlAdNo(String emlAdNo) {
		this.emlAdNo = emlAdNo;
	}
	public String getFstVefyOldCrdNo1() {
		return fstVefyOldCrdNo1;
	}
	public void setFstVefyOldCrdNo1(String fstVefyOldCrdNo1) {
		this.fstVefyOldCrdNo1 = fstVefyOldCrdNo1;
	}
	public String getFstVefyOldCrdNo2() {
		return fstVefyOldCrdNo2;
	}
	public void setFstVefyOldCrdNo2(String fstVefyOldCrdNo2) {
		this.fstVefyOldCrdNo2 = fstVefyOldCrdNo2;
	}
	public String getFstVefyOldCrdNo3() {
		return fstVefyOldCrdNo3;
	}
	public void setFstVefyOldCrdNo3(String fstVefyOldCrdNo3) {
		this.fstVefyOldCrdNo3 = fstVefyOldCrdNo3;
	}
	public String getFstVefyOldCrdNo4() {
		return fstVefyOldCrdNo4;
	}
	public void setFstVefyOldCrdNo4(String fstVefyOldCrdNo4) {
		this.fstVefyOldCrdNo4 = fstVefyOldCrdNo4;
	}
	public String getSecdVefyOldCrdNo1() {
		return secdVefyOldCrdNo1;
	}
	public void setSecdVefyOldCrdNo1(String secdVefyOldCrdNo1) {
		this.secdVefyOldCrdNo1 = secdVefyOldCrdNo1;
	}
	public String getSecdVefyOldCrdNo2() {
		return secdVefyOldCrdNo2;
	}
	public void setSecdVefyOldCrdNo2(String secdVefyOldCrdNo2) {
		this.secdVefyOldCrdNo2 = secdVefyOldCrdNo2;
	}
	public String getSecdVefyOldCrdNo3() {
		return secdVefyOldCrdNo3;
	}
	public void setSecdVefyOldCrdNo3(String secdVefyOldCrdNo3) {
		this.secdVefyOldCrdNo3 = secdVefyOldCrdNo3;
	}
	public String getSecdVefyOldCrdNo4() {
		return secdVefyOldCrdNo4;
	}
	public void setSecdVefyOldCrdNo4(String secdVefyOldCrdNo4) {
		this.secdVefyOldCrdNo4 = secdVefyOldCrdNo4;
	}
	public String getEml() {
		return eml;
	}
	public void setEml(String eml) {
		this.eml = eml;
	}
	public String getSecdNltyYn() {
		return secdNltyYn;
	}
	public void setSecdNltyYn(String secdNltyYn) {
		this.secdNltyYn = secdNltyYn;
	}
	public String getFstVefyFthrNm() {
		return fstVefyFthrNm;
	}
	public void setFstVefyFthrNm(String fstVefyFthrNm) {
		this.fstVefyFthrNm = fstVefyFthrNm;
	}
	public String getSecdVefyFthrNm() {
		return secdVefyFthrNm;
	}
	public String getBioCd() {
		return bioCd;
	}
	public void setBioCd(String bioCd) {
		this.bioCd = bioCd;
	}
	public String getSgntCd() {
		return sgntCd;
	}
	public void setSgntCd(String sgntCd) {
		this.sgntCd = sgntCd;
	}
	public String getPtCd() {
		return ptCd;
	}
	public void setPtCd(String ptCd) {
		this.ptCd = ptCd;
	}
	public void setSecdVefyFthrNm(String secdVefyFthrNm) {
		this.secdVefyFthrNm = secdVefyFthrNm;
	}
	public String getFthrRsdtNo() {
		return fthrRsdtNo;
	}
	public void setFthrRsdtNo(String fthrRsdtNo) {
		this.fthrRsdtNo = fthrRsdtNo;
	}
	public String getGfthrRsdtNo() {
		return gfthrRsdtNo;
	}
	public void setGfthrRsdtNo(String gfthrRsdtNo) {
		this.gfthrRsdtNo = gfthrRsdtNo;
	}
	public String getFthrOldCrdNo4() {
		return fthrOldCrdNo4;
	}
	public void setFthrOldCrdNo4(String fthrOldCrdNo4) {
		this.fthrOldCrdNo4 = fthrOldCrdNo4;
	}
	public String getMthrRsdtNo() {
		return mthrRsdtNo;
	}
	public void setMthrRsdtNo(String mthrRsdtNo) {
		this.mthrRsdtNo = mthrRsdtNo;
	}
	public String getEmlAd() {
		return emlAd;
	}
	public void setEmlAd(String emlAd) {
		this.emlAd = emlAd;
	}
	public String getCurtAdDiv() {
		return curtAdDiv;
	}
	public void setCurtAdDiv(String curtAdDiv) {
		this.curtAdDiv = curtAdDiv;
	}
	public String getCurtAdNatCd() {
		return curtAdNatCd;
	}
	public void setCurtAdNatCd(String curtAdNatCd) {
		this.curtAdNatCd = curtAdNatCd;
	}
	public String getCurtAdNatCdNm() {
		return curtAdNatCdNm;
	}
	public void setCurtAdNatCdNm(String curtAdNatCdNm) {
		this.curtAdNatCdNm = curtAdNatCdNm;
	}
	public String getCurtAdDtlCtD() {
		return curtAdDtlCtD;
	}
	public void setCurtAdDtlCtD(String curtAdDtlCtD) {
		this.curtAdDtlCtD = curtAdDtlCtD;
	}
	public String getCurtAdDtlCtF() {
		return curtAdDtlCtF;
	}
	public void setCurtAdDtlCtF(String curtAdDtlCtF) {
		this.curtAdDtlCtF = curtAdDtlCtF;
	}
	public String getSpousCnt() {
		return spousCnt;
	}
	public void setSpousCnt(String spousCnt) {
		this.spousCnt = spousCnt;
	}
	public String getGrnDd() {
		return grnDd;
	}
	public void setGrnDd(String grnDd) {
		this.grnDd = grnDd;
	}
	public String getSysSgnt() {
		return sysSgnt;
	}
	public void setSysSgnt(String sysSgnt) {
		this.sysSgnt = sysSgnt;
	}
	public String getHstSeqNo() {
		return hstSeqNo;
	}
	public void setHstSeqNo(String hstSeqNo) {
		this.hstSeqNo = hstSeqNo;
	}
	public String getFleRcdNo() {
		return fleRcdNo;
	}
	public void setFleRcdNo(String fleRcdNo) {
		this.fleRcdNo = fleRcdNo;
	}
	public String getCntTelNo2() {
		return cntTelNo2;
	}
	public void setCntTelNo2(String cntTelNo2) {
		this.cntTelNo2 = cntTelNo2;
	}
	public String getSpusRsdtNo() {
		return spusRsdtNo;
	}
	public void setSpusRsdtNo(String spusRsdtNo) {
		this.spusRsdtNo = spusRsdtNo;
	}
	public String getPkiCert() {
		return pkiCert;
	}
	public void setPkiCert(String pkiCert) {
		this.pkiCert = pkiCert;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getBioInfr() {
		return bioInfr;
	}
	public void setBioInfr(String bioInfr) {
		this.bioInfr = bioInfr;
	}
	public String getSecdVefyOldCrdIsuceDd() {
		return secdVefyOldCrdIsuceDd;
	}
	public void setSecdVefyOldCrdIsuceDd(String secdVefyOldCrdIsuceDd) {
		this.secdVefyOldCrdIsuceDd = secdVefyOldCrdIsuceDd;
	}
	public String getSecdVefyCrdIsucePlceCd() {
		return secdVefyCrdIsucePlceCd;
	}
	public void setSecdVefyCrdIsucePlceCd(String secdVefyCrdIsucePlceCd) {
		this.secdVefyCrdIsucePlceCd = secdVefyCrdIsucePlceCd;
	}
	public String getSecdVefyCrdIsucePlceCdNm() {
		return secdVefyCrdIsucePlceCdNm;
	}
	public void setSecdVefyCrdIsucePlceCdNm(String secdVefyCrdIsucePlceCdNm) {
		this.secdVefyCrdIsucePlceCdNm = secdVefyCrdIsucePlceCdNm;
	}
	public String getFstVefyOldCrdIsuceDd() {
		return fstVefyOldCrdIsuceDd;
	}
	public void setFstVefyOldCrdIsuceDd(String fstVefyOldCrdIsuceDd) {
		this.fstVefyOldCrdIsuceDd = fstVefyOldCrdIsuceDd;
	}
	public String getFstVefyOldCrdIsucePlceCd() {
		return fstVefyOldCrdIsucePlceCd;
	}
	public void setFstVefyOldCrdIsucePlceCd(String fstVefyOldCrdIsucePlceCd) {
		this.fstVefyOldCrdIsucePlceCd = fstVefyOldCrdIsucePlceCd;
	}
	public String getFstVefyOldCrdIsucePlceCdNm() {
		return fstVefyOldCrdIsucePlceCdNm;
	}
	public void setFstVefyOldCrdIsucePlceCdNm(String fstVefyOldCrdIsucePlceCdNm) {
		this.fstVefyOldCrdIsucePlceCdNm = fstVefyOldCrdIsucePlceCdNm;
	}
	public String getOldCrdIsucePlceCdNm() {
		return oldCrdIsucePlceCdNm;
	}
	public void setOldCrdIsucePlceCdNm(String oldCrdIsucePlceCdNm) {
		this.oldCrdIsucePlceCdNm = oldCrdIsucePlceCdNm;
	}
	public String getOldCrdIsucePlceCd() {
		return oldCrdIsucePlceCd;
	}
	public void setOldCrdIsucePlceCd(String oldCrdIsucePlceCd) {
		this.oldCrdIsucePlceCd = oldCrdIsucePlceCd;
	}
	public String getCrdIsuceLangCd() {
		return crdIsuceLangCd;
	}
	public void setCrdIsuceLangCd(String crdIsuceLangCd) {
		this.crdIsuceLangCd = crdIsuceLangCd;
	}
	public String getUdtWrkCd() {
		return udtWrkCd;
	}
	public void setUdtWrkCd(String udtWrkCd) {
		this.udtWrkCd = udtWrkCd;
	}
	public String getInitDthYn() {
		return initDthYn;
	}
	public void setInitDthYn(String initDthYn) {
		this.initDthYn = initDthYn;
	}
	public String getDeadYn() {
		return deadYn;
	}
	public void setDeadYn(String deadYn) {
		this.deadYn = deadYn;
	}
	public String getHeadNm() {
		return headNm;
	}
	public void setHeadNm(String headNm) {
		this.headNm = headNm;
	}
	public String getAprvListTm() {
		return aprvListTm;
	}
	public void setAprvListTm(String aprvListTm) {
		this.aprvListTm = aprvListTm;
	}
	public String getBioRgstApvrYn() {
		return bioRgstApvrYn;
	}
	public void setBioRgstApvrYn(String bioRgstApvrYn) {
		this.bioRgstApvrYn = bioRgstApvrYn;
	}
	public String getBthDdApvrJ() {
		return bthDdApvrJ;
	}
	public void setBthDdApvrJ(String bthDdApvrJ) {
		this.bthDdApvrJ = bthDdApvrJ;
	}
	public String getBthDdApvrG() {
		return bthDdApvrG;
	}
	public void setBthDdApvrG(String bthDdApvrG) {
		this.bthDdApvrG = bthDdApvrG;
	}
	public String getBioRgstDd() {
		return bioRgstDd;
	}
	public void setBioRgstDd(String bioRgstDd) {
		this.bioRgstDd = bioRgstDd;
	}
	public String getBioRgstDdG() {
		return bioRgstDdG;
	}
	public void setBioRgstDdG(String bioRgstDdG) {
		this.bioRgstDdG = bioRgstDdG;
	}
	public String getBioRgstDdJ() {
		return bioRgstDdJ;
	}
	public void setBioRgstDdJ(String bioRgstDdJ) {
		this.bioRgstDdJ = bioRgstDdJ;
	}
	public String getOthrRl() {
		return othrRl;
	}
	public void setOthrRl(String othrRl) {
		this.othrRl = othrRl;
	}
	public String getNm() {
		return nm;
	}
	public void setNm(String nm) {
		this.nm = nm;
	}
	public String getfAge() {
		return fAge;
	}
	public void setfAge(String fAge) {
		this.fAge = fAge;
	}
	public String getmAge() {
		return mAge;
	}
	public void setmAge(String mAge) {
		this.mAge = mAge;
	}
	public String getgAge() {
		return gAge;
	}
	public void setgAge(String gAge) {
		this.gAge = gAge;
	}

	public String getgBthDd() {
		return gBthDd;
	}
	public void setgBthDd(String gBthDd) {
		this.gBthDd = gBthDd;
	}
	public String gethBthDd() {
		return hBthDd;
	}
	public void sethBthDd(String hBthDd) {
		this.hBthDd = hBthDd;
	}
	public String getSrchBthDd() {
		return srchBthDd;
	}
	public void setSrchBthDd(String srchBthDd) {
		this.srchBthDd = srchBthDd;
	}
	public String getSrchCalTye() {
		return srchCalTye;
	}
	public void setSrchCalTye(String srchCalTye) {
		this.srchCalTye = srchCalTye;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getSrchRlCd() {
		return srchRlCd;
	}
	public void setSrchRlCd(String srchRlCd) {
		this.srchRlCd = srchRlCd;
	}
	public String getAgGap() {
		return agGap;
	}
	public void setAgGap(String agGap) {
		this.agGap = agGap;
	}
	public String getFthrAgGap() {
		return fthrAgGap;
	}
	public void setFthrAgGap(String fthrAgGap) {
		this.fthrAgGap = fthrAgGap;
	}
	public String getGfthrAgGap() {
		return gfthrAgGap;
	}
	public void setGfthrAgGap(String gfthrAgGap) {
		this.gfthrAgGap = gfthrAgGap;
	}
	public String getMthrAgGap() {
		return mthrAgGap;
	}
	public void setMthrAgGap(String mthrAgGap) {
		this.mthrAgGap = mthrAgGap;
	}
	public String getSelfAgGap() {
		return selfAgGap;
	}
	public void setSelfAgGap(String selfAgGap) {
		this.selfAgGap = selfAgGap;
	}
	public String getSrchAgGap() {
		return srchAgGap;
	}
	public void setSrchAgGap(String srchAgGap) {
		this.srchAgGap = srchAgGap;
	}
	public String getFmlYHadGdrCd() {
		return fmlYHadGdrCd;
	}
	public void setFmlYHadGdrCd(String fmlYHadGdrCd) {
		this.fmlYHadGdrCd = fmlYHadGdrCd;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getFullNm() {
		return fullNm;
	}
	public void setFullNm(String fullNm) {
		this.fullNm = fullNm;
	}
	public String getMdtrRlCd() {
		return mdtrRlCd;
	}
	public void setMdtrRlCd(String mdtrRlCd) {
		this.mdtrRlCd = mdtrRlCd;
	}
	public String getTye() {
		return tye;
	}
	public void setTye(String tye) {
		this.tye = tye;
	}
	public String getRlFthrYn() {
		return rlFthrYn;
	}
	public void setRlFthrYn(String rlFthrYn) {
		this.rlFthrYn = rlFthrYn;
	}
	public String getRlGfthrYn() {
		return rlGfthrYn;
	}
	public void setRlGfthrYn(String rlGfthrYn) {
		this.rlGfthrYn = rlGfthrYn;
	}
	public String getRlMthrYn() {
		return rlMthrYn;
	}
	public void setRlMthrYn(String rlMthrYn) {
		this.rlMthrYn = rlMthrYn;
	}
	public String getLgSeqNo() {
		return lgSeqNo;
	}
	public void setLgSeqNo(String lgSeqNo) {
		this.lgSeqNo = lgSeqNo;
	}
	public String getCtznRgstYn() {
		return ctznRgstYn;
	}
	public void setCtznRgstYn(String ctznRgstYn) {
		this.ctznRgstYn = ctznRgstYn;
	}
	public String getFthrRlCdCnt() {
		return fthrRlCdCnt;
	}
	public void setFthrRlCdCnt(String fthrRlCdCnt) {
		this.fthrRlCdCnt = fthrRlCdCnt;
	}
	public String getGfthrRlCdCnt() {
		return gfthrRlCdCnt;
	}
	public void setGfthrRlCdCnt(String gfthrRlCdCnt) {
		this.gfthrRlCdCnt = gfthrRlCdCnt;
	}
	public String getMthrRlCdCnt() {
		return mthrRlCdCnt;
	}
	public void setMthrRlCdCnt(String mthrRlCdCnt) {
		this.mthrRlCdCnt = mthrRlCdCnt;
	}
	public String getSpusRlCdCnt() {
		return spusRlCdCnt;
	}
	public void setSpusRlCdCnt(String spusRlCdCnt) {
		this.spusRlCdCnt = spusRlCdCnt;
	}
	public String getFthrModeYn() {
		return fthrModeYn;
	}
	public void setFthrModeYn(String fthrModeYn) {
		this.fthrModeYn = fthrModeYn;
	}
	public String getGfthrModeYn() {
		return gfthrModeYn;
	}
	public void setGfthrModeYn(String gfthrModeYn) {
		this.gfthrModeYn = gfthrModeYn;
	}
	public String getMthrModeYn() {
		return mthrModeYn;
	}
	public void setMthrModeYn(String mthrModeYn) {
		this.mthrModeYn = mthrModeYn;
	}
	public String getSpusModeYn() {
		return spusModeYn;
	}
	public void setSpusModeYn(String spusModeYn) {
		this.spusModeYn = spusModeYn;
	}
	public String getCtznRgstYnFlag() {
		return ctznRgstYnFlag;
	}
	public void setCtznRgstYnFlag(String ctznRgstYnFlag) {
		this.ctznRgstYnFlag = ctznRgstYnFlag;
	}

}
