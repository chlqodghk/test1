package afnid.rm.rsdt.service.impl;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import afnid.cm.NidMessageSource;
import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.bioif.service.BioIfInfrService;
import afnid.rm.rsdt.service.RsdtInfrService;
import afnid.rm.rsdt.service.RsdtInfrVO;
import afnid.rm.rsdt.service.RsdtMberInfrService;

import com.dongdo.etazkira.ABS.ABSSocket;

import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of common
 * and implements FmlyInfoService class.
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2014.12.08
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2014.12.08  		BH Choi         							Create
 *
 * </pre>
 */
@Service("rsdtMberInfrService")
public class RsdtMberInfrServiceImpl extends AbstractServiceImpl implements RsdtMberInfrService {
	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
	/** RsdtMberInfrDAO */
    @Resource(name="rsdtMberInfrDAO")
    private RsdtMberInfrDAO dao;
    
    @Resource(name="lgDAO")
    private LgDAO lgDao;
    
    @Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO rsdtInfrDAO;
    
    @Resource(name = "bioIfInfrService")
    private BioIfInfrService bioIfService;
    
    @Resource(name = "rsdtInfoService")
    private RsdtInfrService rsdtInfrService;
    
    /** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    private int sendCnt = 0;
    
	/**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return EgovMap
	 * @exception Exception
	 */
	public EgovMap searchRsdtFmlyRela(RsdtInfrVO vo) throws Exception {
   		return dao.selectRsdtFmlyRela(vo);
	}
	
	
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return String
	 * @exception Exception
	 */
	public String addRsdtMberInfr(RsdtInfrVO vo) throws Exception {
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		String crdIsucePlceCd = user.getOrgnzClsCd()+ user.getOrgnzCd();
		String crdIsuceLangCd = user.getUseLangCd();
		vo.setCrdIsucePlceCd(crdIsucePlceCd);
		vo.setCrdIsuceLangCd(crdIsuceLangCd);
		vo.setFmlyHadYn("N");
		vo.setUdtWrkCd("25");
		vo.setUserId(user.getUserId());
		vo.setRsdtRgstYn("Y");
		vo.setTamLedrCfmYn("N");
		vo.setUseYn("Y");
		vo.setInitDthYn("N");
		if("Y".equals(vo.getDeadYn())){
			vo.setUseYn("N");
			vo.setInitDthYn("Y");
		}
		if("Y".equals(vo.getFrngrYn())){
			vo.setUseYn("N");
		}
		
		if(vo.getFrngrYn() == null){
			vo.setFrngrYn("N");
		}
		
		if("Y".equals(vo.getEduYn()) && vo.getEduLvDocYn() == null){
			vo.setEduLvDocYn("N");
		}
		
		if(vo.getBldTyeDocYn() == null){
			vo.setBldTyeDocYn("N");
		}
		
		vo.setDltYn("N");
		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
		
		String rsdtSeqNo = null;
		boolean modFlag = false;
		if(vo != null && vo.getRsdtSeqNo() != null && !"".equals(vo.getRsdtSeqNo())){
			int result = dao.updateRsdtInfrExi(vo);
			if(result == 0){
				throw processException("udtFail.msg");
			}
			rsdtSeqNo = vo.getRsdtSeqNo();
			modFlag = true;
		}else{
			rsdtSeqNo = dao.insertRsdtInfr(vo);
			vo.setRsdtSeqNo(rsdtSeqNo);
			dao.insertRmRgstWrkTb(vo);
		}
		vo.setRsdtSeqNo(rsdtSeqNo);
		dao.deleteOthrNatLang(vo);
		dao.deleteFrgnLang(vo);
		String [] natLangCds = vo.getNatLangCds();
		String [] frgnLangCds = vo.getFrgnLangCds();
		RsdtInfrVO result = new RsdtInfrVO();
		if(natLangCds != null && natLangCds.length > 0){
			for(int i = 0; i < natLangCds.length; i++){
				if(natLangCds[i].trim().length() > 0){
					result = result.init();
					result.setRsdtSeqNo(rsdtSeqNo);
					result.setUserId(user.getUserId());
					result.setNatLangCd(natLangCds[i]);
					dao.insertOthrNatLang(result);
				}
			}
		}
		if(frgnLangCds != null && frgnLangCds.length > 0){
			for(int i = 0; i < frgnLangCds.length; i++){
				if(frgnLangCds[i].trim().length() > 0){
					result = result.init();
					result.setRsdtSeqNo(rsdtSeqNo);
					result.setUserId(user.getUserId());
					result.setFrgnLangCd(frgnLangCds[i]);
					dao.insertFrgnLang(result);
				}
			}
		}
		vo.setCrdCd("1");
		if(!modFlag){
			dao.insertImBioTb(vo);
		}
		return rsdtSeqNo;
	}
	
	
	/**
	 * Biz-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return RsdtInfrVO object of program
	 * @exception Exception
	 */
	public RsdtInfrVO searchRsdtInfrView(RsdtInfrVO vo) throws Exception {
		int adultAge = propertiesService.getInt("adultAge");
   		vo.setAdultAge(String.valueOf(adultAge));
   		return dao.selectRsdtInfrView(vo);
	}
	
    /**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<RsdtInfrVO> searchListOthrNatLangInfr(RsdtInfrVO vo) throws Exception {
   		return dao.selectListOthrNatLangInfr(vo);
	}

    /**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<RsdtInfrVO> searchListFrgnLangInfr(RsdtInfrVO vo) throws Exception {
   		return dao.selectListFrgnLangInfr(vo);
	}
	
	/**
	 * Biz-method for retrieving of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 */
	public List<EgovMap> searchRsdtMberFmlyInfr(RsdtInfrVO vo) throws Exception {
		vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword3(NidStringUtil.toNumberConvet(vo.getSearchKeyword3(), "g"));
		vo.setSearchKeyword4(NidStringUtil.toNumberConvet(vo.getSearchKeyword4(), "g"));
   		return dao.selectRsdtMberFmlyInfr(vo);
	}
	
	
	/**
   	 * Biz-method for retrieving of program. <br>
   	 *
   	 * @param RsdtInfrVO
   	 * @return List
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchListRsdtMberInfrPop(RsdtInfrVO vo) throws Exception {
   		vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword3(NidStringUtil.toNumberConvet(vo.getSearchKeyword3(), "g"));
		vo.setSearchKeyword4(NidStringUtil.toNumberConvet(vo.getSearchKeyword4(), "g"));
      	return dao.selectListRsdtMberInfrPop(vo);
   	}
   	
   	/**
   	 * Biz-method for retrieving of program. <br>
   	 *
   	 * @param RsdtInfrVO
   	 * @return int
   	 * @exception Exception
   	 */
   	public int searchListRsdtMberInfrPopTotCnt(RsdtInfrVO vo) throws Exception {
   		vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword3(NidStringUtil.toNumberConvet(vo.getSearchKeyword3(), "g"));
		vo.setSearchKeyword4(NidStringUtil.toNumberConvet(vo.getSearchKeyword4(), "g"));
      	return dao.selectListRsdtMberInfrPopTotCnt(vo);
   	}
   	
   	
   	
   	/**
	 * Biz-method for Receipt to inquire of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return RsdtInfrVO
	 * @exception Exception
	 */
	public RsdtInfrVO searchRsdtInfrRcpt(RsdtInfrVO vo) throws Exception {
		int adultAge = propertiesService.getInt("adultAge");
   		vo.setAdultAge(String.valueOf(adultAge));
   		return dao.selectRsdtInfoRcpt(vo);
	}
	
   	/**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 */
	public List<RsdtInfrVO> searchListOthrNatLangInfrForRcpt(RsdtInfrVO vo) throws Exception {
   		return dao.selectListOthrNatLangInfrForRcpt(vo);
	}

    /**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 */
	public List<RsdtInfrVO> searchListFrgnLangInfrForRcpt(RsdtInfrVO vo) throws Exception {
   		return dao.selectListFrgnLangInfrForRcpt(vo);
	}
	
	
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return int
	 * @exception Exception
	 */
	public int modifyRsdtMberInfr(RsdtInfrVO vo) throws Exception {
		int resultInt = 0;
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUserId(user.getUserId());
		vo.setUseYn("Y");
		vo.setInitDthYn("N");
		if("Y".equals(vo.getDeadYn())){
			vo.setUseYn("N");
			vo.setInitDthYn("Y");
		}
		if("Y".equals(vo.getFrngrYn())){
			vo.setUseYn("N");
		}
		if(vo.getFrngrYn() == null){
			vo.setFrngrYn("N");
		}
		if(vo.getRsdtCfmYn() == null){
			vo.setRsdtCfmYn("N");
		}
		if("Y".equals(vo.getEduYn()) && vo.getEduLvDocYn() == null){
			vo.setEduLvDocYn("N");
		}
		
		if(vo.getBldTyeDocYn() == null){
			vo.setBldTyeDocYn("N");
		}
		
		if(vo != null && vo.getCtznRgstYnFlag() != null && vo.getCtznRgstYn() != null && "N".equals(vo.getCtznRgstYnFlag()) && "N".equals(vo.getCtznRgstYn()) ){
			String crdIsucePlceCd = user.getOrgnzClsCd()+ user.getOrgnzCd();
			String crdIsuceLangCd = user.getUseLangCd();
			vo.setCrdIsucePlceCd(crdIsucePlceCd);
			vo.setCrdIsuceLangCd(crdIsuceLangCd);
			vo.setFmlyHadYn("N");
			vo.setUdtWrkCd("25");
			vo.setUserId(user.getUserId());
			vo.setRsdtRgstYn("Y");
			vo.setTamLedrCfmYn("N");
			vo.setUseYn("Y");
			vo.setInitDthYn("N");
			vo.setDltYn("N");
			vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
			resultInt = dao.updateRsdtInfrExi(vo);
			if(resultInt == 0){
				throw processException("udtFail.msg");
			}
		}else{
			resultInt = dao.updateRsdtInfr(vo);
		}
		
		dao.deleteOthrNatLang(vo);
		dao.deleteFrgnLang(vo);
		String [] natLangCds = vo.getNatLangCds();
		String [] frgnLangCds = vo.getFrgnLangCds();
		RsdtInfrVO result = new RsdtInfrVO();
		if(natLangCds != null && natLangCds.length > 0){
			for(int i = 0; i < natLangCds.length; i++){
				if(natLangCds[i].trim().length() > 0){
					result = result.init();
					result.setRsdtSeqNo(vo.getRsdtSeqNo());
					result.setUserId(user.getUserId());
					result.setNatLangCd(natLangCds[i]);
					dao.insertOthrNatLang(result);
				}
			}
		}
		if(frgnLangCds != null && frgnLangCds.length > 0){
			for(int i = 0; i < frgnLangCds.length; i++){
				if(frgnLangCds[i].trim().length() > 0){
					result = result.init();
					result.setRsdtSeqNo(vo.getRsdtSeqNo());
					result.setUserId(user.getUserId());
					result.setFrgnLangCd(frgnLangCds[i]);
					dao.insertFrgnLang(result);
				}
			}
		}
		int adultAge = propertiesService.getInt("adultAge");
   		vo.setAdultAge(String.valueOf(adultAge));
   		EgovMap em = dao.selectRsdtMberBioAgeChk(vo);
   		if(em != null && !em.isEmpty()){
   			String msg = NidStringUtil.isNullToString(em.get("msg"));
   			if(msg != null && "MSG".equals(msg)){
   				String age = NidStringUtil.isNullToString(em.get("age"));
   				int reAge = -1;
   				try{
   					reAge = Integer.parseInt(age);
   				}catch(Exception e){
   					e.printStackTrace();
   				}
   				ABSSocket abs = new ABSSocket();
   				boolean resultFlag = false;
				String lgMsg = "";
				String erorYn = "N";
   				if(reAge > adultAge-1){
   					resultFlag = abs.Age18OverChange(vo.getBioKey());
   					lgMsg = "Age18OverChange";
   				}else{
   					resultFlag = abs.Age18UnderChange(vo.getBioKey());
   					lgMsg = "Age18UnderChange";
   				}
   				if(!resultFlag){
					erorYn = "N";
				}
				try{
					lgDao.insertBioIfLg(user.getUserId(), "1", erorYn, lgMsg, vo.getBioKey());
				}catch(Exception e){
					log.error(e);
				}
				log.debug(lgMsg + " : " + resultFlag);
				if(!resultFlag){
					throw processException("fail");
				}
   			}
   		}
		return resultInt;
	}
	
	
	/**
	 * Biz-method for Receipt to inquire of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return RsdtInfrVO
	 * @exception Exception
	 */
	public EgovMap searchRsdtMberBioAgeChk(RsdtInfrVO vo) throws Exception {
		int adultAge = propertiesService.getInt("adultAge");
   		vo.setAdultAge(String.valueOf(adultAge));
   		return dao.selectRsdtMberBioAgeChk(vo);
	}
	
	
	
	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param RsdtInfrVO
   	 * @return List
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchListRsdtMberInfrAprv(RsdtInfrVO vo) throws Exception {
   		int adultAge = propertiesService.getInt("adultAge");
   		vo.setAdultAge(String.valueOf(adultAge));
      	return dao.selectListRsdtMberInfrAprv(vo);
   	}   

   	/**
	 * Biz-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
   	public int searchListRsdtMberInfrAprvTotCn(RsdtInfrVO vo) throws Exception {
   		int adultAge = propertiesService.getInt("adultAge");
   		vo.setAdultAge(String.valueOf(adultAge));
        return dao.selectListRsdtMberInfrAprvTotCn(vo);
	}
   	
   	
   	
   	
   	
   	
   	/**
	 * Biz-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return RsdtInfrVO object of program
	 * @exception Exception
	 */
	public RsdtInfrVO searchRsdtInfrAprvView(RsdtInfrVO vo) throws Exception {
		int adultAge = propertiesService.getInt("adultAge");
   		vo.setAdultAge(String.valueOf(adultAge));
   		return dao.selectRsdtInfrAprvView(vo);
	}
	
    /**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<RsdtInfrVO> searchListOthrNatLangInfrAprv(RsdtInfrVO vo) throws Exception {
   		return dao.selectListOthrNatLangInfrAprv(vo);
	}

    /**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<RsdtInfrVO> searchListFrgnLangInfrAprv(RsdtInfrVO vo) throws Exception {
   		return dao.selectListFrgnLangInfrAprv(vo);
	}
	
	
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param RsdtInfrVO, String
	 * @return int
	 * @exception Exception
	 */
	public int modifyRsdtMberInfrAprv(RsdtInfrVO vo, String type) throws Exception {
		int resultInt = 0;
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUserId(user.getUserId());
		vo.setUseYn("Y");
		vo.setInitDthYn("N");
		if("Y".equals(vo.getDeadYn())){
			vo.setUseYn("N");
			vo.setInitDthYn("Y");
		}
		if("Y".equals(vo.getFrngrYn())){
			vo.setUseYn("N");
		}
		if(vo.getFrngrYn() == null){
			vo.setFrngrYn("N");
		}
		if("Y".equals(vo.getEduYn()) && vo.getEduLvDocYn() == null){
			vo.setEduLvDocYn("N");
		}
		if(vo.getBldTyeDocYn() == null){
			vo.setBldTyeDocYn("N");
		}
		if(vo != null && vo.getCtznRgstYnFlag() != null && vo.getCtznRgstYn() != null && "N".equals(vo.getCtznRgstYnFlag()) && "N".equals(vo.getCtznRgstYn()) ){
			String crdIsucePlceCd = user.getOrgnzClsCd()+ user.getOrgnzCd();
			String crdIsuceLangCd = user.getUseLangCd();
			vo.setCrdIsucePlceCd(crdIsucePlceCd);
			vo.setCrdIsuceLangCd(crdIsuceLangCd);
			vo.setFmlyHadYn("N");
			vo.setUdtWrkCd("25");
			vo.setUserId(user.getUserId());
			vo.setRsdtRgstYn("Y");
			vo.setTamLedrCfmYn("N");
			vo.setUseYn("Y");
			vo.setInitDthYn("N");
			vo.setDltYn("N");
			vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
			resultInt = dao.updateRsdtInfrExi(vo);
			if(resultInt == 0){
				throw processException("udtFail.msg");
			}
		}else{
			resultInt = dao.updateRsdtInfr(vo);
		}
		
		dao.deleteOthrNatLang(vo);
		dao.deleteFrgnLang(vo);
		String [] natLangCds = vo.getNatLangCds();
		String [] frgnLangCds = vo.getFrgnLangCds();
		RsdtInfrVO result = new RsdtInfrVO();
		if(natLangCds != null && natLangCds.length > 0){
			for(int i = 0; i < natLangCds.length; i++){
				if(natLangCds[i].trim().length() > 0){
					result = result.init();
					result.setRsdtSeqNo(vo.getRsdtSeqNo());
					result.setUserId(user.getUserId());
					result.setNatLangCd(natLangCds[i]);
					dao.insertOthrNatLang(result);
				}
			}
		}
		if(frgnLangCds != null && frgnLangCds.length > 0){
			for(int i = 0; i < frgnLangCds.length; i++){
				if(frgnLangCds[i].trim().length() > 0){
					result = result.init();
					result.setRsdtSeqNo(vo.getRsdtSeqNo());
					result.setUserId(user.getUserId());
					result.setFrgnLangCd(frgnLangCds[i]);
					dao.insertFrgnLang(result);
				}
			}
		}
		
		if(type == null){
			int adultAge = propertiesService.getInt("adultAge");
	   		vo.setAdultAge(String.valueOf(adultAge));
	   		EgovMap em = dao.selectRsdtMberBioAgeChk(vo);
	   		if(em != null && !em.isEmpty()){
	   			String msg = NidStringUtil.isNullToString(em.get("msg"));
	   			if(msg != null && "MSG".equals(msg)){
	   				String age = NidStringUtil.isNullToString(em.get("age"));
	   				int reAge = -1;
	   				try{
	   					reAge = Integer.parseInt(age);
	   				}catch(Exception e){
	   					e.printStackTrace();
	   				}
	   				ABSSocket abs = new ABSSocket();
	   				boolean resultFlag = false;
					String lgMsg = "";
					String erorYn = "N";
	   				if(reAge > adultAge-1){
	   					resultFlag = abs.Age18OverChange(vo.getBioKey());
	   					lgMsg = "Age18OverChange";
	   				}else{
	   					resultFlag = abs.Age18UnderChange(vo.getBioKey());
	   					lgMsg = "Age18UnderChange";
	   				}
	   				if(!resultFlag){
						erorYn = "N";
					}
					try{
						lgDao.insertBioIfLg(user.getUserId(), "1", erorYn, lgMsg, vo.getBioKey());
					}catch(Exception e){
						log.error(e);
					}
					log.debug(lgMsg + " : " + resultFlag);
					if(!resultFlag){
						throw processException("fail");
					}
	   			}
	   		}
		}
		return resultInt;
	}
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return EgovMap
	 * @exception Exception
	 */
	public EgovMap aprvRsdtMberInfr(RsdtInfrVO vo) throws Exception {
		EgovMap reMap = new EgovMap();
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		int resultInt = 0;
		resultInt = modifyRsdtMberInfrAprv(vo, "aprv");
		if(resultInt > 0){
			String rsdtNo = dao.selectRsdtMberRsdtNo(vo);
			vo.setRsdtNo(rsdtNo);
			vo.setTamLedrCfmYn("Y");
			vo.setRsdtCfmYn("Y");
			vo.setUserId(user.getUserId());
			vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
			int adultAge = propertiesService.getInt("adultAge");
	   		vo.setAdultAge(String.valueOf(adultAge));
			resultInt = dao.updateVerification(vo);
			if(resultInt > 0){
				RsdtInfrVO vos = new RsdtInfrVO();
				vos.setRsdtSeqNo(vo.getRsdtSeqNo());
				vos.setSgnt(vo.getSgnt());
				String resultSgnt = rsdtInfrService.getXmlData(vos.getSgnt(), "Signature");
		   		if(resultSgnt != null && resultSgnt.length() > 0){
			   		vos.setSgnt(resultSgnt);
			   		rsdtInfrDAO.updateRsdtInfrSgnt(vos);
		   		}
		   		
		   		EgovMap em = rsdtInfrDAO.selectRsdtInfrDat(vos.getRsdtSeqNo());
		   		String hash = "";
		   		if(em != null && !em.isEmpty()){
		   			hash = rsdtInfrDAO.selectRsdtInfrHashDat(em, "25");
		   			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
					if(hash != null && hash.indexOf(reg) == -1){
						String admTel = nidMessageSource.getMessage("admTelNo");
						throw processException("pki.websrvcEror.msg", new String[]{hash, admTel});
					}
		   			resultSgnt = rsdtInfrService.getXmlData(hash, "ds:Signature");
		   		}
		   		if(resultSgnt != null && resultSgnt.length() > 0){
		   			vos.setSysSgnt(resultSgnt);
		   			rsdtInfrDAO.updateRsdtInfrSysSgnt(vos);
		   		}
		   		
		   		EgovMap tcpMap = rsdtInfrDAO.selectRsdtInfrTcpIpDat(vo.getRsdtSeqNo());
		   		if(tcpMap != null && !tcpMap.isEmpty()){
		   			String userId = user.getUserId();
		   			String rsdtNoa = (String)tcpMap.get("rsdtNo");
		   			String bioKey = (String)tcpMap.get("bioKey");
		   			String dupYn = (String)tcpMap.get("age");
		   			String insUpd = "i";
		   			byte [] bioFle = null;
	   				EgovMap ImCapt = rsdtInfrDAO.selectImBioCaptTbInfr(bioKey);
	   				if(ImCapt != null && !ImCapt.isEmpty()){
	   					int cnt = rsdtInfrDAO.selectBmBioTb(bioKey, rsdtNoa);
	   					if(cnt > 0){
	   						insUpd = "u";
	   					}
	   					rsdtInfrDAO.deleteImBioCaptTb(bioKey);
	   		   			bioFle = (byte[])ImCapt.get("bioFle");
	   		   			if(bioFle != null){
	   		   				dupYn = "N";
	   		   				EgovMap bioEm = addRsdtInfrBioIf(bioKey, rsdtNoa, dupYn, userId, insUpd, bioFle);
	   		   				reMap.put("bioEm", bioEm);
	   		   			}
	   				}
		   		}
			}else{
				String helpTelNo = nidMessageSource.getMessage("admTelNo");
				throw processException("apvFail.msg", new String[]{helpTelNo});
			}
		}
		reMap.put("result", new Integer(resultInt));
		return reMap;
	}
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return int
	 * @exception Exception
	 */
	public int searchRsdtMberInfrApvrState(RsdtInfrVO vo) throws Exception {
		int result = 0;
		result = dao.selectRsdtMberInfrApvrState(vo);
		return result;
	}
	
	
	/**
	 * Bio bio-data sent to the server. <br>
	 * @param String, String, String, String, String, byte[]
	 * @return void
	 * @exception Exception
	 */
   	private EgovMap addRsdtInfrBioIf(String bioKey, String rsdtNo, String dupYn, String userId, String insUpd, byte [] bioFle) throws Exception {
   		int tcpCnt = propertiesService.getInt("rm.bio.socketReSend");
   		sendCnt++;
   		EgovMap em = null;
   		try{
   			em = bioIfService.addBioSocketIf(bioKey, rsdtNo, dupYn, userId, insUpd, bioFle);
   		}catch(IOException e){
   			log.error(e);
   			if(tcpCnt != sendCnt){
   				em = addRsdtInfrBioIf(bioKey, rsdtNo, dupYn, userId, insUpd, bioFle);
   			}else{
   				log.error(e);
   				sendCnt = 0;
   				throw e;
   			}
   		}catch(Exception e){
   			log.error(e);
   			sendCnt = 0;
   			throw e;
   		}finally{
   			try{
   				sendCnt = 0;
   			}catch(Exception e){
   				log.error(e);
   			}
   		}
   		return em;
   	}
   	
   	
   	
   	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchListRsdtInfrPop(RsdtInfrVO vo) throws Exception {
      		return dao.selectListRsdtInfrPop(vo);
   	}

   	/**
	 * Biz-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
   	public int searchListRsdtInfrPopTotCn(RsdtInfrVO vo) throws Exception {
        return dao.selectListRsdtInfrPopTotCn(vo);
	}
	
   	
   	
   	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchRsdtFmlyBokLstPop(RsdtInfrVO vo) throws Exception {
      	return dao.selectRsdtFmlyBokLstPop(vo);	
   	}
   	
   	
   	
   	/**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return String
	 * @exception Exception
	 */
	public String searchFmlyRsdtMberSelfGdr(RsdtInfrVO vo) throws Exception {
		return dao.selectFmlyRsdtMberSelfGdr(vo);
	}
	
	
	
	
	
	
	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchFmlyMberRsdtInfrList(EgovMap vo) throws Exception {
      	return dao.selectFmlyMberRsdtInfrList(vo);
   	}
   	
   	
   	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchListFmlyInfrPop(RsdtInfrVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
   		vo.setUseLangCd(user.getUseLangCd());
    	return dao.selectListFmlyInfrPop(vo);
   	}
   	
   	
   	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchRsdtInfrMaleRlCn(EgovMap vo) throws Exception {
      	return dao.selectRsdtInfrMaleRlCn(vo);
   	}
   	
   	
   	
}