package afnid.rm.rsdt.service;

import java.util.List;

import egovframework.rte.psl.dataaccess.util.EgovMap;


/** 
 * This service interface is biz-class of common. <br>
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2013.01.04  		BH Choi				Create
 *
 * </pre>
 */
public interface RsdtMdfcService {

	/**
	 * Retrieves of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 */
	EgovMap searchRsdtMdfc(RsdtMdfcVO vo) throws Exception;
	
	
	/**
	 * Retrieves of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 */
	EgovMap searchRsdtMdfcAprv(RsdtMdfcVO vo) throws Exception;
	
	
	/**
	 * Retrieves of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return String object of program
	 * @exception Exception
	 */
	String searchRsdtInfrSeq(RsdtMdfcVO vo) throws Exception;
	
	
	
	
	/**
	 * Retrieves of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 */
	EgovMap searchListRsdtMdfcNatFrgnLang(RsdtMdfcVO vo) throws Exception;
	
	
	/**
	 * Retrieves of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return boolean Whether to register
	 * @exception Exception
	 */
	boolean addRsdtMdfc(RsdtMdfcVO vo) throws Exception;
	
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtMdfcVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchListRsdtMdfcAprv(RsdtMdfcVO vo) throws Exception;

	/**
	 * Retrieves total count of program-list. <br>
	 * @param vo Input item for retrieving total count list of program.(RsdtMdfcVO)
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
	int searchListRsdtMdfcAprvTotCn(RsdtMdfcVO vo) throws Exception;
	
	/**
	 * Retrieves  of program. <br>
	 * @param vo Input item for retrieving of program.(RsdtMdfcVO)
	 * @return boolean Modification of Program
	 * @exception Exception
	 */
	boolean modifyRsdtMdfcVfy(RsdtMdfcVO vo) throws Exception;
	
	/**
	 * Retrieves of program. <br>
	 * @param vo Input item for retrieving of program.(RsdtMdfcVO)
	 * @return EgovMap
	 * @exception Exception
	 */
	EgovMap aprvRsdtMdfc(RsdtMdfcVO vo) throws Exception;
	
	
	/**
	 * Retrieves of program. <br>
	 * @param vo Input item for retrieving of program.(RsdtMdfcVO)
	 * @return boolean retrieves of Program
	 * @exception Exception
	 */
	boolean searchRsdtMdfcCrdIssTo(RsdtMdfcVO vo) throws Exception;
	
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 * @param vo Input item for retrieving Receipt of Citizen Confirmation.(RsdtMdfcVO)
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
	EgovMap searchRsdtMdfcCfmRcpt(RsdtMdfcVO vo) throws Exception;
	
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 *
	 * @param vo Input item for retrieving Receipt of Citizen ConfirmationRsdtMdfcVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap> searchRsdtMdfcOthrCfmRcpt(RsdtMdfcVO vo) throws Exception;
	
	/**
	 * Retrieves of Citizen Confirmation Receipt. <br>
	 *
	 * @param vo Input item for retrieving Receipt of Citizen Confirmation(RsdtMdfcVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	List<EgovMap>  searchRsdtMdfcFrgnCfmRcpt(RsdtMdfcVO vo) throws Exception;
		
	
	/**
	 * Retrieves of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap object of Program
	 * @exception Exception
	 */
	EgovMap searchRsdtMdfcChngFieldFlag(RsdtMdfcVO vo) throws Exception;
	
	
	
	/**
	 * Retrievesof program. <br>
	 * @param vo Input item for retrieving of program.(RsdtMdfcVO)
	 * @return int Count of Program
	 * @exception Exception
	 */
	int searchRsdtMdfcChngIsFlag(RsdtMdfcVO vo) throws Exception;
	
	
	
	/**
	 * Retrieves of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 */
	EgovMap searchRsdtMdfcRgstIsFlag(RsdtMdfcVO vo) throws Exception;
	
	
	
	
	/**
	 * Retrieves of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 */
	EgovMap searchRmImgView(RsdtMdfcVO vo) throws Exception;
	
	
	
	
	/**
	 * If you have registered biometric data of the bio-bio-info on the server brings. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtMdfcVO).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 */
	String searchBioInfr(RsdtMdfcVO vo) throws Exception;
	
	
	
	/**
	 * Check expiration date of the card. <br>
	 *
	 * @param vo Input item for retrieving of program(String).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 */
	EgovMap searchRsdtInfrCrdExpiry(String rsdtNo) throws Exception;
	
	/**
	 * Card issuing processing history results. <br>
	 *
	 * @param String, String
	 * @return EgovMap
	 * @exception Exception
	 */
	EgovMap searchRsdtInfrCrdProcErr(String rsdtNo, String type) throws Exception;
	
	
	/**
	 * Card issuing processing history results. <br>
	 *
	 * @param String, String
	 * @return EgovMap
	 * @exception Exception
	 */
	RsdtMdfcVO searchRsdtMdfcSeqIsFlag(RsdtMdfcVO vo) throws Exception;
	
	/**
	 * Retrieves list of program. <br>
	 *
	 * @param vo Input item for retrieving list of citizen(RsdtMdfcVO).
	 * @return List Retrieve list of citizen
	 * @exception Exception
	 */
	List<RsdtMdfcVO> searchListRsdtNmFnd(RsdtMdfcVO vo) throws Exception;

	/**
	 * Retrieves total count of citizen list. <br>
	 * @param vo Input item for retrieving total count of citizen list.(RsdtMdfcVO)
	 * @return int Total Count of citizen list
	 * @exception Exception
	 */
	int searchListRsdtNmFndTotCn(RsdtMdfcVO vo) throws Exception;
	
	/**
	 * Retrieves citizen by eNID. <br>
	 * @param vo Input item for retrieving citizen by eNID(RsdtMdfcVO).
	 * @return RsdtMdfcVO Retrieve citizen by eNID
	 * @exception Exception
	 */
	RsdtMdfcVO searchRsdtNmFnd(RsdtMdfcVO vo) throws Exception;

	
	
	/**
	 * Retrieves total count of citizen list. <br>
	 * @param vo Input item for retrieving total count of citizen list.(RsdtMdfcVO)
	 * @return int Total Count of citizen list
	 * @exception Exception
	 */
	int searchListMdfcMrrgDvrc(RsdtMdfcVO vo) throws Exception;
	
	
	/**
	 * Retrieves total count of citizen list. <br>
	 * @param vo Input item for retrieving total count of citizen list.(RsdtMdfcVO)
	 * @return int Total Count of citizen list
	 * @exception Exception
	 */
	int searchListMdfcMrrgCnt(RsdtMdfcVO vo) throws Exception;
	
	/**
	 * Retrieves chip write flag <br>
	 * @param RsdtMdfcVO
	 * @param boolean
	 * @param String
	 * @return boolean
	 * @exception Exception
	 */
	boolean searchIsChipWriteFlag(RsdtMdfcVO vo, boolean writeFlag, String lgSeqNo) throws Exception;
	
	
	/**
	 * Retrieves total count of citizen list. <br>
	 * @param vo Input item for retrieving total count of citizen list.(RsdtMdfcVO)
	 * @return int Total Count of citizen list
	 * @exception Exception
	 */
	int searchBthRgst(RsdtMdfcVO vo) throws Exception;
	
	/**
	 * Retrieves family member. <br>
	 * @param vo Input item for retrieving family member.(RsdtMdfcVO)
	 * @return int 
	 * @exception Exception
	 */
	int searchMber(RsdtMdfcVO vo) throws Exception;	
	
	/**
	 * <br>
	 *
	 * @param 
	 * @return 
	 * @exception Exception
	 */
	RsdtMdfcVO searchMberRsdtNo(RsdtMdfcVO vo) throws Exception;	
	
	/**
	 * Retrieves member row number. <br>
	 * @param vo Input item for member row number.(RsdtMdfcVO)
	 * @return int 
	 * @exception Exception
	 */
	int searchMberRowNum(RsdtMdfcVO vo) throws Exception;		
}
