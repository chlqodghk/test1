package afnid.rm.rsdt.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import afnid.rm.rsdt.service.RsdtMntVO;
import com.ibatis.sqlmap.client.SqlMapClient;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import java.util.List;

/** 
 * This class is Database Access Object of monitor
 * 
 * @author Afghanistan National ID Card System Application Team moon soo kim 
 * @since 2013.11.03
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *  2013.11.03      	moon soo kim 		                   Create
 *
 * </pre>
 */
@Repository("rsdtMntDAO")
public class RsdtMntDAO extends EgovAbstractDAO {
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }

	
	/**
	 * DAO-method for retrieving  be or not existence of citizen. <br>
	 * 
	 * @param vo Input item for retrieving be or not existence of citizen.(RsdtMntVO).
	 * @return int 
	 * @exception Exception
	 */
	public int selectRsdtInfrCn(RsdtMntVO vo) throws Exception{
		return (Integer)selectByPk("rsdtMntDAO.selectRsdtInfrCn", vo);
	}
	
	
	/**
	 * DAO-method for retrieving citizen card traceability information. <br>
	 *
	 * @param vo Input item for retrieving citizen card traceability information(RsdtMntVO).
	 * @return RsdtMdfcVO 
	 * @exception Exception
	 *
	 */
	public RsdtMntVO selectRsdtPrcssStusInfr(RsdtMntVO vo) throws Exception{
		return (RsdtMntVO)selectByPk("rsdtMntDAO.selectRsdtPrcssStusInfr", vo);
	}
	
	
	/**
	 * DAO-method for retrieving citizen card traceability information(history). <br>
	 *
	 * @param vo Input item for retrieving citizen card traceability information(history)(RsdtMntVO).
	 * @return RsdtMdfcVO 
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtMntVO> selectListRsdtPrcssHst(RsdtMntVO vo) throws Exception{
		return list("rsdtMntDAO.selectListRsdtPrcssHst", vo);
	}
	
	/**
	 * DAO-method for retrieving  be or not existence of citizen(bio duplication). <br>
	 * 
	 * @param vo Input item for retrieving be or not existence of citizen(bio duplication).(RsdtMntVO).
	 * @return int
	 * @exception Exception
	 */
	public int selectRsdtBiioDupCn(RsdtMntVO vo) throws Exception{
		return (Integer)selectByPk("rsdtMntDAO.selectRsdtBiioDupCn", vo);
	}
	
}
