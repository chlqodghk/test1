package afnid.rm.rsdt.service.impl;

import java.io.Reader;
import java.io.Writer;
import java.util.List;

import javax.annotation.Resource;

import oracle.sql.CLOB;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import si.osi.dsig.XMLSignerP11;
import afnid.cm.log.service.impl.LgDAO;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.rsdt.service.RsdtInfrVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;



/** 
 * This class is Database Access Object of common
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04`
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.04  		BH Choi         		Create
 *
 * </pre>
 */
@Repository("rsdtInfoDAO")
public class RsdtInfrDAO extends EgovAbstractDAO {
	
	protected Log log = LogFactory.getLog(this.getClass());
	
	/** LgDAO */
    @Resource(name="lgDAO")
    private LgDAO lgDao;
	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }

	
	
	/**
	 * DAO-method for registering information of new family book history. <br>
	 *
	 * @param vo Input item for registering new program(RsdtInfrVO).
	 * @return void
	 * @exception Exception
	 */
	public void insertRsdtInfrHst(RsdtInfrVO vo) throws Exception{
		insert("rsdtInfoDAO.insertRsdtInfoHst", vo);
		insert("rsdtInfoDAO.insertRsdtInfrOthrNatLangHst", vo);
		insert("rsdtInfoDAO.insertRsdtInfrFrgnLangHst", vo);
	}
	/**
	 * DAO-method for registering information of new resident history. <br>
	 *
	 * @param seqNo Input item for registering new program(String).
	 * @param userId Input item for registering new program(String).
	 * @return void
	 * @exception Exception
	 */
	public void insertRsdtInfrHst(String seqNo, String userId) throws Exception{
		if(seqNo != null && !seqNo.equals("") && userId != null && !userId.equals("")){
			RsdtInfrVO vo = new RsdtInfrVO();
			vo.setRsdtSeqNo(seqNo);
			vo.setUserId(userId);
			insert("rsdtInfoDAO.insertRsdtInfoHst", vo);
			insert("rsdtInfoDAO.insertRsdtInfrOthrNatLangHst", vo);
			insert("rsdtInfoDAO.insertRsdtInfrFrgnLangHst", vo);
		}
	}

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListRsdtInfr(RsdtInfrVO vo) throws Exception{
		
		vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword7(NidStringUtil.toNumberConvet(vo.getSearchKeyword7(), "g"));
		vo.setSearchKeyword8(NidStringUtil.toNumberConvet(vo.getSearchKeyword8(), "g"));
		vo.setSearchKeyword9(NidStringUtil.toNumberConvet(vo.getSearchKeyword9(), "g"));
		
		vo.setStartDay(NidStringUtil.toNumberConvet(vo.getStartDay(), "g"));
		vo.setEndDay(NidStringUtil.toNumberConvet(vo.getEndDay(), "g"));
		
		return list("rsdtInfoDAO.selectRsdtInfoLst", vo);
	}

	/**
	 * DAO-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selecthListRsdtInfrTotCn(RsdtInfrVO vo) {
    	
    	vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword7(NidStringUtil.toNumberConvet(vo.getSearchKeyword7(), "g"));
		vo.setSearchKeyword8(NidStringUtil.toNumberConvet(vo.getSearchKeyword8(), "g"));
		vo.setSearchKeyword9(NidStringUtil.toNumberConvet(vo.getSearchKeyword9(), "g"));
		
		vo.setStartDay(NidStringUtil.toNumberConvet(vo.getStartDay(), "g"));
		vo.setEndDay(NidStringUtil.toNumberConvet(vo.getEndDay(), "g"));
		
        return (Integer)selectByPk("rsdtInfoDAO.selectRsdtInfoLstTotCnt", vo);
    }
    
    
	
	
	

    // KIM ADD
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return RsdtInfrVO Retrieve of program
	 * @exception Exception
	 *
	 */
	public RsdtInfrVO selectRsdtInfrView(RsdtInfrVO vo) throws Exception{
		return (RsdtInfrVO)selectByPk("rsdtInfoDAO.selectRsdtInfoView", vo);
	}

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListOthrNatLangInfr(RsdtInfrVO vo) throws Exception{
		return list("rsdtInfoDAO.selectOthrNatLangInfoList", vo);
	}

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListFrgnLangInfr(RsdtInfrVO vo) throws Exception{
		return list("rsdtInfoDAO.selectFrgnLangInfoList", vo);
	}

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListOthrNatLangInfrForRcpt(RsdtInfrVO vo) throws Exception{
		return list("rsdtInfoDAO.selectOthrNatLangInfoListForRcpt", vo);
	}

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListFrgnLangInfrForRcpt(RsdtInfrVO vo) throws Exception{
		return list("rsdtInfoDAO.selectFrgnLangInfoListForRcpt", vo);
	}

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListSpus(RsdtInfrVO vo) throws Exception{
		return list("rsdtInfoDAO.selectSpusList", vo);
	}
	
	
	/**
	 * DAO-method for registering information <br>
	 *
	 * @param vo Input item for registering new program(RsdtInfrVO).
	 * @return void
	 * @exception Exception
	 */
	public void insertRsdtInfrMrrgInfr(RsdtInfrVO vo) throws Exception{
		insert("rsdtInfoDAO.insertRsdtInfrMrrgInfr", vo);
	}
	
	/**
	 * DAO-method for registering information <br>
	 *
	 * @param vo Input item for registering new program(RsdtInfrVO).
	 * @return void
	 * @exception Exception
	 */
	public void updateRsdtInfrMrrgInfr(RsdtInfrVO vo) throws Exception{
		insert("rsdtInfoDAO.updateRsdtInfrMrrgInfr", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return RsdtInfrVO Retrieve of program
	 * @exception Exception
	 *
	 */
	public String selectRsdtInfrDvrcInfr(RsdtInfrVO vo) throws Exception{
		return (String)selectByPk("rsdtInfoDAO.selectRsdtInfrDvrcInfr", vo);
	}
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return RsdtInfrVO Retrieve of program
	 * @exception Exception
	 *
	 */
	public String selectRsdtInfrMrrgInfrTarget(RsdtInfrVO vo) throws Exception{
		return (String)selectByPk("rsdtInfoDAO.selectRsdtInfrMrrgInfrTarget", vo);
	}
	
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(String).
	 * @return RsdtInfrVO Retrieve of program
	 * @exception Exception
	 *
	 */
	public EgovMap selectRsdtInfrDat(String rsdtSeqNo) throws Exception{
		EgovMap em = null;
		if(rsdtSeqNo != null){
			RsdtInfrVO vo = new RsdtInfrVO();
			vo.setRsdtSeqNo(rsdtSeqNo);
			em = (EgovMap)selectByPk("rsdtInfoDAO.selectRsdtInfoHashDat", vo);
		}
		return em;
		
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(String) (String).
	 * @return RsdtInfrVO Retrieve of program
	 * @exception Exception
	 *
	 */
	public EgovMap selectRsdtHstInfrDat(String rsdtSeqNo, String hstSeqNo) throws Exception{
		EgovMap em = null;
		if(rsdtSeqNo != null){
			RsdtInfrVO vo = new RsdtInfrVO();
			vo.setRsdtSeqNo(rsdtSeqNo);
			vo.setHstSeqNo(hstSeqNo);
			em = (EgovMap)selectByPk("rsdtInfoDAO.selectRsdtHstInfrDat", vo);
		}
		return em;
		
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(String).
	 * @return RsdtInfrVO Retrieve of program
	 * @exception Exception
	 *
	 */
	public String selectRsdtInfrHashDat(EgovMap em, String bsnCd) throws Exception{

		String result = "";
		if(em != null && !em.isEmpty()){
			result = setRsdtInfrHashDat(em);
			log.debug("##############################setRsdtInfrHashDat start");
			log.debug(result);
			log.debug("##############################setRsdtInfrHashDat end");
			
			//setting parameter
			Object obj = NidUserDetailsHelper.getAuthenticatedUser();
   			String userId = "SYSTEM";
   			if(obj != null && obj instanceof LgnVO){
   				LgnVO user = (LgnVO)obj;
   				userId = user.getUserId();
   			}
			String rsdtNo = NidStringUtil.nullConvert(em.get("rsdtNo"));
			
			String seq = lgDao.insertPubKeyIfLg(userId,rsdtNo,"18","1",bsnCd, "");
			
			result = XMLSignerP11.spkiIFRmStringDigitalSignature(result);
			
			String msg = result;
			String errYn = "Y";
			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
			if(msg == null ){
				errYn = "Y";
				msg = "-1";
			}else if(msg.indexOf(reg) == -1){
				errYn = "Y";	
			}else{
				errYn = "N";
				msg = "OK";
			}
			lgDao.updatePubKeyIfLg(seq, msg, errYn);
			
			log.debug("##############################spkiIFRmStringDigitalSignature start");
			log.debug(result);
			log.debug("##############################spkiIFRmStringDigitalSignature end");
		}
		return result;
	}
	
	
	/**
	 * DAO-method for Residents Info Hash data generation of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(EgovMap).
	 * @return String
	 *
	 */
	public String setRsdtInfrHashDat(EgovMap em){
		String result = "";
		if(em != null){
			StringBuffer sb = new StringBuffer();
			String dim = "|";
			if(!em.isEmpty()){
				sb.append(em.get("rsdtSeqNo")).append(dim);
				sb.append(em.get("fmlyBokSeqNo")).append(dim);
				sb.append(em.get("fmlyBokNo")).append(dim);
				sb.append(em.get("fmlyMberNo")).append(dim);
				sb.append(em.get("oldCrdNo1")).append(dim);
				sb.append(em.get("oldCrdNo2")).append(dim);
				sb.append(em.get("oldCrdNo3")).append(dim);
				sb.append(em.get("oldCrdNo4")).append(dim);
				sb.append(em.get("oldCrdIsucePlceCd")).append(dim);
				sb.append(em.get("oldCrdIsuceDd")).append(dim);
				sb.append(em.get("rsdtNo")).append(dim);
				sb.append(em.get("rlCd")).append(dim);
				sb.append(em.get("givNm")).append(dim);
				sb.append(em.get("surnm")).append(dim);
				sb.append(em.get("enGivNm")).append(dim);
				sb.append(em.get("enSurnm")).append(dim);
				sb.append(em.get("fthrNm")).append(dim);
				sb.append(em.get("fthrRsdtSeqNo")).append(dim);
				sb.append(em.get("mthrNm")).append(dim);
				sb.append(em.get("mthrRsdtSeqNo")).append(dim);
				sb.append(em.get("gfthrNm")).append(dim);
				sb.append(em.get("gfthrRsdtSeqNo")).append(dim);
				sb.append(em.get("spusNm")).append(dim);
				sb.append(em.get("spusRsdtSeqNo")).append(dim);
				sb.append(em.get("bthDd")).append(dim);
				sb.append(em.get("bthPlceCd")).append(dim);
				sb.append(em.get("bthNatDiv")).append(dim);
				sb.append(em.get("bthNatCd")).append(dim);
				sb.append(em.get("frgnBthCtyNm")).append(dim);
				sb.append(em.get("pmntAdCd")).append(dim);
				sb.append(em.get("pmntAdDtlCt")).append(dim);
				sb.append(em.get("curtAdCd")).append(dim);
				sb.append(em.get("curtAdDtlCt")).append(dim);
				sb.append(em.get("bldTyeCd")).append(dim);
				sb.append(em.get("mrrgCd")).append(dim);
				sb.append(em.get("gdrCd")).append(dim);
				sb.append(em.get("encyCd")).append(dim);
				sb.append(em.get("fmlyLangCd")).append(dim);
				sb.append(em.get("secdNltyYn")).append(dim);
				sb.append(em.get("secdNltyCd")).append(dim);
				sb.append(em.get("dsbtCd")).append(dim);
				sb.append(em.get("ocp")).append(dim);
				sb.append(em.get("rlgnCd")).append(dim);
				sb.append(em.get("rlgnSectCd")).append(dim);
				sb.append(em.get("eduYn")).append(dim);
				sb.append(em.get("eduCd")).append(dim);
				sb.append(em.get("mltSrvcCd")).append(dim);
				sb.append(em.get("smrRsdcCd")).append(dim);
				sb.append(em.get("wtrRsdcCd")).append(dim);
				sb.append(em.get("fmlyMberMlNo")).append(dim);
				sb.append(em.get("fmlyMberFemlNo")).append(dim);
				sb.append(em.get("crdIsucePlceCd")).append(dim);
				sb.append(em.get("crdIsuceLangCd")).append(dim);
				sb.append(em.get("crdIsuceDd")).append(dim);
				sb.append(em.get("crdIsuceSrlNo")).append(dim);
				sb.append(em.get("crdExpiryDd")).append(dim);
				sb.append(em.get("crdIsuDueDd")).append(dim);
				sb.append(em.get("crdStusCd")).append(dim);
				sb.append(em.get("calTye")).append(dim);
				sb.append(em.get("adChngYn")).append(dim);
				sb.append(em.get("chngRsnDtlCt")).append(dim);
				sb.append(em.get("fmlyHadYn")).append(dim);
				sb.append(em.get("fmlyHadRsdtNo")).append(dim);
				sb.append(em.get("rsdtTyeCd")).append(dim);
				sb.append(em.get("rsdtStusCd")).append(dim);
				sb.append(em.get("bioKey")).append(dim);
				sb.append(em.get("poliCntrSeqNo")).append(dim);
				sb.append(em.get("udtWrkCd")).append(dim);
				log.debug("setRsdtInfrHashDat");
				Object obj = em.get("sgnt");
				String sgnt = "";
				log.debug("obj start : " + obj);
				if(obj != null){
					log.debug("obj class: " + obj.getClass());
					log.debug("obj class name: " + obj.getClass().getName());
					if("oracle.sql.CLOB".equals(obj.getClass().getName()) ){
						CLOB clob = (CLOB)obj;
						sgnt = ClobToString(clob);
						log.debug("oracle.sql.CLOB : " + sgnt);
					}else if("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB".equals(obj.getClass().getName()) ){
						weblogic.jdbc.vendor.oracle.OracleThinClob clob = (weblogic.jdbc.vendor.oracle.OracleThinClob)obj;
						sgnt = ClobToString(clob);
						log.debug("weblogic.jdbc.wrapper.Clob_oracle_sql_CLOB : " + sgnt);
					}
				}
				log.debug("obj end");
				sb.append(sgnt).append(dim);
				
				sb.append(em.get("ersrCd")).append(dim);
				sb.append(em.get("mberRgstId")).append(dim);
				sb.append(em.get("rsdtRgstYn")).append(dim);
				sb.append(em.get("rsdtRgstDd")).append(dim);
				sb.append(em.get("rsdtRgstId")).append(dim);
				sb.append(em.get("tamLedrCfmYn")).append(dim);
				sb.append(em.get("cfmTamLedrId")).append(dim);
				sb.append(em.get("useYn")).append(dim);
				sb.append(em.get("frngrYn")).append(dim);
				sb.append(em.get("fthrRgstTye")).append(dim);
				sb.append(em.get("mthrRgstTye")).append(dim);
				sb.append(em.get("gfthrRgstTye")).append(dim);
				sb.append(em.get("spusRgstTye")).append(dim);
				sb.append(em.get("fthrOldCrdNo1")).append(dim);
				sb.append(em.get("fthrOldCrdNo2")).append(dim);
				sb.append(em.get("fthrOldCrdNo3")).append(dim);
				sb.append(em.get("fthrOldCrdNo4")).append(dim);
				sb.append(em.get("mthrOldCrdNo1")).append(dim);
				sb.append(em.get("mthrOldCrdNo2")).append(dim);
				sb.append(em.get("mthrOldCrdNo3")).append(dim);
				sb.append(em.get("mthrOldCrdNo4")).append(dim);
				sb.append(em.get("gfthrOldCrdNo1")).append(dim);
				sb.append(em.get("gfthrOldCrdNo2")).append(dim);
				sb.append(em.get("gfthrOldCrdNo3")).append(dim);
				sb.append(em.get("gfthrOldCrdNo4")).append(dim);
				sb.append(em.get("spusOldCrdNo1")).append(dim);
				sb.append(em.get("spusOldCrdNo2")).append(dim);
				sb.append(em.get("spusOldCrdNo3")).append(dim);
				sb.append(em.get("spusOldCrdNo4")).append(dim);
				sb.append(em.get("rsdtCfmYn")).append(dim);
				sb.append(em.get("bldTyeDocYn")).append(dim);
				sb.append(em.get("eduLvDocYn")).append(dim);
				sb.append(em.get("initDthYn")).append(dim);
				sb.append(em.get("vrfrYn")).append(dim);
				//sb.append(em.get("sysSgnt")).append(dim);
				sb.append(em.get("trstId")).append(dim);
				sb.append(em.get("dltYn")).append(dim);
				sb.append(em.get("cntTelNo")).append(dim);
				sb.append(em.get("cntTelNo2")).append(dim);
				sb.append(em.get("emlAd")).append(dim);
				sb.append(em.get("fstVefyIndiNm")).append(dim);
				sb.append(em.get("fstVefyTye")).append(dim);
				sb.append(em.get("fstVefyRsdtNo")).append(dim);
				sb.append(em.get("fstVefyOldCrdNo1")).append(dim);
				sb.append(em.get("fstVefyOldCrdNo2")).append(dim);
				sb.append(em.get("fstVefyOldCrdNo3")).append(dim);
				sb.append(em.get("fstVefyOldCrdNo4")).append(dim);
				sb.append(em.get("fstVefyFthrNm")).append(dim);
				sb.append(em.get("secdVefyIndiNm")).append(dim);
				sb.append(em.get("secdVefyTye")).append(dim);
				sb.append(em.get("secdVefyRsdtNo")).append(dim);
				sb.append(em.get("secdVefyOldCrdNo1")).append(dim);
				sb.append(em.get("secdVefyOldCrdNo2")).append(dim);
				sb.append(em.get("secdVefyOldCrdNo3")).append(dim);
				sb.append(em.get("secdVefyOldCrdNo4")).append(dim);
				sb.append(em.get("secdVefyFthrNm")).append(dim);
				sb.append(em.get("rgstOrgnzCd")).append(dim);
				sb.append(em.get("curtAdDiv")).append(dim);
				sb.append(em.get("curtAdNatCd")).append(dim);
				sb.append(em.get("fstVefyOldCrdIsucePlceCd")).append(dim);
				sb.append(em.get("fstVefyOldCrdIsuceDd")).append(dim);
				sb.append(em.get("secdVefyCrdIsucePlceCd")).append(dim);
				sb.append(em.get("secdVefyOldCrdIsuceDd")).append(dim);
				sb.append(em.get("ctznRgstYn")).append(dim);
				sb.append(em.get("othrRl")).append(dim);
				sb.append(em.get("fstRgstUserId")).append(dim);
				sb.append(em.get("fstRgstDt")).append(dim);
				sb.append(em.get("lstUdtUserId")).append(dim);
				sb.append(em.get("lstUdtDt"));
			}
			byte [] array = Base64.encodeBase64(sb.toString().getBytes());
			String rex = new String(array);
			result = rex;
		}
		return result;
	}

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListRsdtRgstAprvInfr(RsdtInfrVO vo) throws Exception{
		
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword3(NidStringUtil.toNumberConvet(vo.getSearchKeyword3(), "g"));
		vo.setSearchKeyword4(NidStringUtil.toNumberConvet(vo.getSearchKeyword4(), "g"));
		
		return list("rsdtInfoDAO.selectRsdtRegVfyInfoLst", vo);
	}	

	/**
	 * DAO-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListRsdtRgstAprvInfrTotCn(RsdtInfrVO vo) {
    	
    	vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword3(NidStringUtil.toNumberConvet(vo.getSearchKeyword3(), "g"));
		vo.setSearchKeyword4(NidStringUtil.toNumberConvet(vo.getSearchKeyword4(), "g"));
		
        return (Integer)selectByPk("rsdtInfoDAO.selectRsdtRegVfyInfoLstTotCnt", vo);
    }
    
    
    
    
    /**
	 * DAO-method for registering information of new OthrNat language. <br>
	 *
	 * @param vo Input item for registering new program(RsdtInfrVO).
	 * @return void
	 * @exception Exception
	 */
	public void insertOthrNatLang(RsdtInfrVO vo) throws Exception{
		insert("rsdtInfoDAO.insertOthrNatLang", vo);
	}
	/**
	 * DAO-method for registering information of new Frgn language. <br>
	 *
	 * @param vo Input item for registering new program(RsdtInfrVO).
	 * @return void
	 * @exception Exception
	 */
	public void insertFrgnLang(RsdtInfrVO vo) throws Exception{
		insert("rsdtInfoDAO.insertFrgnLang", vo);
	}

	/**
	 * DAO-method for delete information of  OthrNat language. <br>
	 *
	 * @param vo Input item for registering new program(RsdtInfrVO).
	 * @return void
	 * @exception Exception
	 */
	public void deleteOthrNatLang(RsdtInfrVO vo) throws Exception{
		delete("rsdtInfoDAO.deleteOthrNatLang", vo);
	}
	/**
	 * DAO-method for delete information of  Frgn language. <br>
	 *
	 * @param vo Input item for registering new program(RsdtInfrVO).
	 * @return void
	 * @exception Exception
	 */
	public void deleteFrgnLang(RsdtInfrVO vo) throws Exception{
		delete("rsdtInfoDAO.deleteFrgnLang", vo);
	}
	
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateRsdtInfr(RsdtInfrVO vo){
		return update("rsdtInfoDAO.updateRsdtInfo", vo);
	}
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return String update of program
	 * @exception Exception
	 */
	public String updateAprv(RsdtInfrVO vo) throws Exception{
		String rsdtNo = null;
		synchronized(this){

			rsdtNo = (String)selectByPk("rsdtInfoDAO.selectVerificationEnidNo", vo);
			if(rsdtNo == null ||  (rsdtNo != null && rsdtNo.length() == 0)){
				rsdtNo = (String)selectByPk("rsdtInfoDAO.selectVerification", vo);
				if(rsdtNo != null && rsdtNo.equals("fail")){
					return rsdtNo;
				}
			}
			vo.setRsdtNo(rsdtNo);
			update("rsdtInfoDAO.updateVerification", vo);
			rsdtNo = (String)selectByPk("rsdtInfoDAO.selectVerificationConvert", vo);
		}
		return rsdtNo;
	}
	
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateRsdtInfrSgnt(RsdtInfrVO vo){
		return update("rsdtInfoDAO.updateRsdtInfrSgnt", vo);
	}
	
	/**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int updateRsdtInfrSysSgnt(RsdtInfrVO vo){
		return update("rsdtInfoDAO.updateRsdtInfrSysSgnt", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	public RsdtInfrVO selectRsdtInfrPer(RsdtInfrVO vo) throws Exception{
		return (RsdtInfrVO)selectByPk("rsdtInfoDAO.selectRsdtInfrPer", vo);
	}

    
    
    /**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return String object of Program
	 * @exception Exception
	 */
	public String selectRsdtBioRgstStus(RsdtInfrVO vo) throws Exception{
		return (String)selectByPk("rsdtInfoDAO.selectRsdtBioRegStat", vo);
	}
	
	 /**
	 * DAO-method for Check Date of Birth of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return String object of Program
	 * @exception Exception
	 */
	public String selectRsdtBthCheck(RsdtInfrVO vo) throws Exception{
		return (String)selectByPk("rsdtInfoDAO.selectRsdtBirthCheck", vo);
	}
	/**
	 * DAO-method for Date Conversion of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return String object of Program
	 * @exception Exception
	 */
	 public String selectDatConvert(RsdtInfrVO vo) {
		 return (String)selectByPk("rsdtInfoDAO.selectDateConver", vo);
	 }
	
	
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<egovframework.rte.psl.dataaccess.util.EgovMap> selectXmlGenerate(RsdtInfrVO vo) throws Exception{
		return list("rsdtInfoDAO.selectXmlGenerate", vo);
	}
    
	
	
	
	/**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return RsdtInfrVO Retrieve  of program
	 * @exception Exception
	 *
	 */
	public RsdtInfrVO selectRsdtInfoRcpt(RsdtInfrVO vo) throws Exception{
		return (RsdtInfrVO)selectByPk("rsdtInfoDAO.selectRsdtInfoReceipt", vo);
	}
	
	
	/**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtInfrVO).
	 * @return int Registration number placed
	 * @exception Exception
	 */
    public int selectIntoXmlBatch(RsdtInfrVO vo) {
        return (Integer)selectByPk("rsdtInfoDAO.selectIntoXmlBatch", vo);
    }
   
	
    
    
    
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListPoliCntrCd(RsdtInfrVO vo) throws Exception{
		return list("rsdtInfoDAO.selectPoliCntrCdLst", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectPoliCntrDstrPrvicLst(RsdtInfrVO vo) throws Exception{
		return list("rsdtInfoDAO.selectPoliCntrDstrPrvicLst", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectPoliCntrDstrPrvicAreaLst(RsdtInfrVO vo) throws Exception{
		return list("rsdtInfoDAO.selectPoliCntrDstrPrvicAreaLst", vo);
	}

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectPoliStatLst(RsdtInfrVO vo) throws Exception{
		return list("rsdtInfoDAO.selectPoliStatLst", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectVtrLst(RsdtInfrVO vo) throws Exception{
		return list("rsdtInfoDAO.selectVtrLst", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListPoliCntrCdTwo(RsdtInfrVO vo) throws Exception{
		return list("rsdtInfoDAO.selectPoliCntrCdTwoLst", vo);
	}
	
	
	
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListRsdtInfrPop(RsdtInfrVO vo) throws Exception{
		
		vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword7(NidStringUtil.toNumberConvet(vo.getSearchKeyword7(), "g"));
		vo.setSearchKeyword8(NidStringUtil.toNumberConvet(vo.getSearchKeyword8(), "g"));
		vo.setSearchKeyword9(NidStringUtil.toNumberConvet(vo.getSearchKeyword9(), "g"));
		
		return list("rsdtInfoDAO.selectRsdtInfoLstPop", vo);
	}

	/**
	 * DAO-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListRsdtInfrPopTotCn(RsdtInfrVO vo) {
    	
    	vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword7(NidStringUtil.toNumberConvet(vo.getSearchKeyword7(), "g"));
		vo.setSearchKeyword8(NidStringUtil.toNumberConvet(vo.getSearchKeyword8(), "g"));
		vo.setSearchKeyword9(NidStringUtil.toNumberConvet(vo.getSearchKeyword9(), "g"));
		
        return (Integer)selectByPk("rsdtInfoDAO.selectRsdtInfoLstPopTotCnt", vo);
    }
	
	/**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(String).
	 * @return int Registration number placed
	 * @exception Exception
	 */
    public EgovMap selectImBioCaptTbInfr(String vo) {
        return (EgovMap)selectByPk("rsdtInfoDAO.selectImBioCaptTbInfr", vo);
    }
    
    
    /**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(String).
	 * @return int Registration number placed
	 * @exception Exception
	 */
    public EgovMap selectRsdtInfrTcpIpDat(String vo) {
    	
    	RsdtInfrVO vos = new RsdtInfrVO();
    	vos.setRsdtSeqNo(vo);
    	int adultAge = propertiesService.getInt("adultAge");
    	vos.setAdultAge(String.valueOf(adultAge));
        return (EgovMap)selectByPk("rsdtInfoDAO.selectRsdtInfrTcpIpDat", vos);
    }
    
    
    /**
	 * DAO-method for Bio-capture data deletion <br>
	 *
	 * @param vo Input item for registering new program(String).
	 * @return void
	 * @exception Exception
	 */
	public void deleteImBioCaptTb(String vo) throws Exception{
		delete("rsdtInfoDAO.deleteImBioCaptTb", vo);
	}
	
	
	
	/**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving of program(String, String).
	 * @return int Registration number placed
	 * @exception Exception
	 */
    public int selectBmBioTb(String bioKey, String rsdtNo) {
    	RsdtInfrVO rsdtVo = new RsdtInfrVO();
    	rsdtVo.setBioKey(bioKey);
    	rsdtVo.setRsdtNo(rsdtNo);
        return (Integer)selectByPk("rsdtInfoDAO.selectBmBioTb", rsdtVo);
    }
    
    
    /**
	 * DAO-method for bio card info  <br>
	 *
	 * @param vo Input item for registering new program(RsdtInfrVO).
	 * @return void
	 * @exception Exception
	 */
	public void insertImBIOCrdIsuTb(RsdtInfrVO vo) throws Exception{
		insert("rsdtInfoDAO.insertImBIOCrdIsuTb", vo);
	}
	
	
	/**
	 * DAO-method for Check a bio-capture data.  <br>
	 *
	 * @param vo Input item for registering new program(String).
	 * @return void
	 * @exception Exception
	 */
	public int selectRsdtInfrIsCapt(String vo) throws Exception{
		return (Integer)selectByPk("rsdtInfoDAO.selectRsdtInfrIsCapt", vo);
	}


	/**
	 * DAO-method for retrieving bio dup citizen list <br>
	 *
	 * @param vo Input item for retrieving detail information of program(String).
	 * @return RsdtInfrVO Retrieve of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRsdtCrdIsuAppStus(String rsdtNo) throws Exception{
		return list("rsdtInfoDAO.selectRsdtCrdIsuAppStus", rsdtNo);
	}
	
	
	/**
	 * DAO-method for Check Citizen Revocation Status. <br>
	 *
	 * @param rsdtNo Input item for retrieving Citizen Revocation Status(String).
	 * @return EgovMap Retrieve of program
	 * @exception Exception
	 *
	 */
	public EgovMap selectRsdtRvctgStus(String rsdtNo) throws Exception{
		return (EgovMap)selectByPk("rsdtInfoDAO.selectRsdtRvctgStus", rsdtNo);
	}
	
	/**
	 * DAO-method for retrieving card issuing status. <br>
	 * 
	 * @param rsdtNo Input item for retrieving card issuing status(String).
	 * @return Integer Retrieve Card issuing count
	 * @exception Exception
	 */
	public int selectRsdtCrdIsuStus(String rsdtNo) throws Exception{
		
		String rsdtNos = NidStringUtil.toNumberConvet(rsdtNo, "g");
		
		return (Integer)selectByPk("rsdtInfoDAO.selectRsdtCrdIsuStus", rsdtNos);
	}
	
	
	
	/**
	 * DAO-method for retrieving list of Spouse. <br>
	 *
	 * @param vo Input item for retrieving Spouse(RsdtInfrVO).
	 * @return int
	 * @exception Exception
	 *
	 */
	public int selectSpusListApp(RsdtInfrVO vo) throws Exception{
		return (Integer)selectByPk("rsdtInfoDAO.selectSpusListApp", vo);
	}
	
	/**
	 * DAO-method for retrieving of Citizen's detail information. <br>
	 *
	 * @param vo Input item for retrieving Citizen's detail information (RsdtInfrVO).
	 * @return RsdtInfrVO Retrieve 
	 * @exception Exception
	 *
	 */
	public RsdtInfrVO selectRsdtInfrDtlView(RsdtInfrVO vo) throws Exception{
		return (RsdtInfrVO)selectByPk("rsdtInfoDAO.selectRsdtInfoDtlView", vo);
	}	
	
	

    /**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return String object of Program
	 * @exception Exception
	 */
	public RsdtInfrVO selectRsdtBioRgstDtlStus(String bioKey) throws Exception{
		return (RsdtInfrVO)selectByPk("rsdtInfoDAO.selectRsdtBioRgstDtlStus", bioKey);
	}	
	
	
	/**
	 * DAO-method for retrieving bio dup citizen list <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return RsdtInfrVO Retrieve of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListFmlyInfrPop(RsdtInfrVO vo) throws Exception{
		return list("rsdtInfoDAO.selectListFmlyInfrPop", vo);
	}
	
	/**
	 * ClobToString <br>
	 *
	 * @param CLOB
	 * @return String
	 *
	 */
	private String ClobToString(CLOB clob) {
		String result = "";
		if(clob != null){
			try{
				Reader reader = clob.getCharacterStream();
				StringBuffer sb = new StringBuffer();
				int size = 0;
				char[] array = new char[10];
				while(( size = reader.read(array)) != -1){
					sb.append(array, 0, size);
				}
				result = sb.toString();
			}catch(Exception e){
				log.error(e);
			}
		}
		return result;
	}
	
	/**
	 * ClobToString <br>
	 *
	 * @param CLOB
	 * @return String
	 *
	 */
	private String ClobToString(weblogic.jdbc.vendor.oracle.OracleThinClob clob) {
		String result = "";
		if(clob != null){
			try{
				Writer clobWriter = clob.getCharacterOutputStream();
				log.debug("ClobToString : " +clobWriter);
				StringBuffer sb = new StringBuffer();
				if(clobWriter != null){
					char buf [] = new char[clob.getChunkSize()];
					buf[0] = '\0';
					clob.getChars(1, clob.getChunkSize(), buf);
					sb.append(buf);
				}
				result = sb.toString();
			}catch(Exception e){
				log.error(e);
			}
		}
		return result;
	}
	
	/**
	 * DAO-method for retrieving count of program. <br>
	 * 
	 * @param rsdtSeqNo Input item for retrieving program(String).
	 * @return int count
	 * @exception Exception
	 */
	public int selectPkiCrtIsuceCn(String rsdtSeqNo) throws Exception{
		return (Integer)selectByPk("rsdtInfoDAO.selectPkiCrtIsuceCn", rsdtSeqNo);
	}
	
	/**
	 * DAO-method for retrieving list of Family Members. <br>
	 *
	 * @param vo Input item for retrieving list of Family Members(RsdtInfrVO).
	 * @return List Retrieve list of Family Members
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListFmlyMber(RsdtInfrVO vo) throws Exception{
		return list("rsdtInfoDAO.selectListFmlyMber", vo);
	}

	/**
	 * DAO-method for retrieving total count list of Family Members. <br>
	 *
	 * @param vo Input item for retrieving total count list of Family Members(RsdtInfrVO).
	 * @return int Total Count of Family Members List
	 * @exception Exception
	 */
    public int selectListFmlyMberTotCn(RsdtInfrVO vo) {
        return (Integer)selectByPk("rsdtInfoDAO.selectListFmlyMberTotCn", vo);
    }	
    
    /**
	 * DAO-method for modifying information of program. <br>
	 * 
	 * @param vo Input item for modifying program(RsdtInfrVO).
	 * @return String object of Program
	 * @exception Exception
	 */
	public RsdtInfrVO selectAgGap(RsdtInfrVO vo) throws Exception{
		return (RsdtInfrVO)selectByPk("rsdtInfoDAO.selectAgGap", vo);
	}  
	
	/**
	 * DAO-method for retrieving age gap. <br>
	 *
	 * @param vo Input item for retrieving age gap(RsdtInfrVO).
	 * @return String age gap
	 * @exception Exception
	 *
	 */
	public String selectChkAgGap(RsdtInfrVO vo) throws Exception{
		return (String)selectByPk("rsdtInfoDAO.selectChkAgGap", vo);
	}	
	
	/**
	 * DAO-method for retrieving same family book Y/N. <br>
	 *
	 * @param vo Input item for retrieving same family book Y/N(RsdtInfrVO).
	 * @return String Y/N
	 * @exception Exception
	 *
	 */
	public String selectSameFmlyBokYn(RsdtInfrVO vo) throws Exception{
		return (String)selectByPk("rsdtInfoDAO.selectSameFmlyBokYn", vo);
	}	
	
	/**
	 * DAO-method for retrieving family head gender code. <br>
	 *
	 * @param vo Input item for retrieving family head gender code(RsdtInfrVO).
	 * @return String family head gender code
	 * @exception Exception
	 *
	 */
	public String selectFmlYHadGdrCd(RsdtInfrVO vo) throws Exception{
		return (String)selectByPk("rsdtInfoDAO.selectFmlYHadGdrCd", vo);
	}	
	
	/**
	 * DAO-method for retrieving validation of relationship. <br>
	 *
	 * @param vo Input item for retrieving validation of relationship(RsdtInfrVO).
	 * @return String validation of relationship
	 * @exception Exception
	 *
	 */
	public String selectChkRl(RsdtInfrVO vo) throws Exception{
		return (String)selectByPk("rsdtInfoDAO.selectChkRl", vo);
	}	
	
	/**
	 * DAO-method for retrieving mandatory relationship. <br>
	 *
	 * @param vo Input item for retrieving mandatory relationship(RsdtInfrVO).
	 * @return String mandatory relationship code
	 * @exception Exception
	 *
	 */
	public String selectMdtrRlCd(RsdtInfrVO vo) throws Exception{
		return (String)selectByPk("rsdtInfoDAO.selectMdtrRlCd", vo);
	}
	
	/**
	 * DAO-method for retrieving mandatory relationship Y/N. <br>
	 *
	 * @param vo Input item for retrieving mandatory relationship Y/N(RsdtInfrVO).
	 * @return String mandatory relationship Y/N
	 * @exception Exception
	 *
	 */
	public String selectMdtrRlCdYn(RsdtInfrVO vo) throws Exception{
		return (String)selectByPk("rsdtInfoDAO.selectMdtrRlCdYn", vo);
	}
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListMdtrRsdt(RsdtInfrVO vo) throws Exception{
		return list("rsdtInfoDAO.selectListMdtrRsdt", vo);
	}	
	
	
	/**
	 * DAO-method for retrieving change member. <br>
	 *
	 * @param vo Input item for retrieving change member(RsdtInfrVO).
	 * @return  RsdtInfrVO
	 * @exception Exception
	 *
	 */
	public RsdtInfrVO selectChngMber(RsdtInfrVO vo) throws Exception{
		return (RsdtInfrVO)selectByPk("rsdtInfoDAO.selectChngMber", vo);
	}
	
	/**
	 * DAO-method  <br>
	 *
	 * @param vo 
	 * @return int
	 * @exception Exception
	 */
    public RsdtInfrVO selectRlCdCnt(RsdtInfrVO vo) {
        return (RsdtInfrVO)selectByPk("rsdtInfoDAO.selectRlCdCnt", vo);
    }
    
	/**
	 * DAO-method for retrieving member mapped  with me.. <br>
	 *
	 * @param vo Input item for retrieving member mapped  with me.(RsdtInfrVO).
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListRlForMe(RsdtInfrVO vo) throws Exception{		
		return list("rsdtInfoDAO.selectListRlForMe", vo);
	}
	
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return RsdtInfrVO Retrieve of program
	 * @exception Exception
	 *
	 */
	public String selectGetCtznRgstYn(RsdtInfrVO vo) throws Exception{
		return (String)selectByPk("rsdtInfoDAO.selectGetCtznRgstYn", vo);
	}
	
	
	
	
}
