package afnid.rm.rsdt.service.impl;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import afnid.cm.NidMessageSource;
import afnid.rm.rsdt.service.RM1RsdtInfrService;
import afnid.rm.rsdt.service.RsdtInfrVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of common
 * and implements FmlyInfoService class.
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.04  		BH Choi         		Create
 *
 * </pre>
 */
@Service("RM1RsdtInfrService")
public class RM1RsdtInfrServiceImpl extends AbstractServiceImpl implements RM1RsdtInfrService {
	/** RsdtInfoDao */
    @Resource(name="RM1rsdtInfoDAO")
    private RM1RsdtInfrDAO dao;
    
    /** ID Generation */
    //@Resource(name="egovIdGnrService")    
    //private EgovIdGnrService egovIdGnrService;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    

    
    
    
    
    
   	public int setXmlGenerate() throws Exception {
   		
   		String wrkSttDt = dao.selectDppDbDatTime(new RsdtInfrVO());
		
   		String ddMmYyyy = getDdMmYyyy();
   		String hhMmSi = getHhMmSi();
   		
   		String dirCardSv = propertiesService.getString("local.card.send.base");
   		String subDirCardSv = dirCardSv + File.separator + ddMmYyyy;
   		log.debug("▷▷▷▷ subDirCardSv : " + subDirCardSv);
   		String fileCardSv = ddMmYyyy+hhMmSi+"_card_print.txt";

   		String dirChipSv = propertiesService.getString("local.chip.send.base");
   		String subDirChipSv = dirChipSv + File.separator + ddMmYyyy;
   		log.debug("▷▷▷▷ dirChipSv : " + dirChipSv);
   		String fileChipSv = ddMmYyyy+hhMmSi+"_chip_save.xml";
   		
   		
   		
   		RsdtInfrVO vo = new RsdtInfrVO();
   		Document doc;
   		Transformer transformer = null;
		List<EgovMap> resultLst = dao.selectXmlGenerate(vo);
		
		File subCardDir = new File(subDirCardSv);
		File subChipDir = new File(subDirChipSv);
		//전송할 데이터가 있으면 디렉토리 생성
		if(resultLst != null && !resultLst.isEmpty()){
			if(!subCardDir.isDirectory()){
				subCardDir.mkdir();
	  	   	}
			if(!subChipDir.isDirectory()){
				subChipDir.mkdir();
	  	   	}
		} else {
			return resultLst.size(); //없으면 종료
		}

		//xml 작업 시작
   		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
   	   	DocumentBuilder docBuilder = null;
   	   	docBuilder = docFactory.newDocumentBuilder();
   	   	doc = docBuilder.newDocument();
   	   	TransformerFactory transformerFactory = TransformerFactory.newInstance();
   	   	transformer = transformerFactory.newTransformer();
   	   	transformer.setOutputProperty(OutputKeys.ENCODING,"UTF-8");
   	   	transformer.setOutputProperty(OutputKeys.INDENT,"yes");
   	   	Element rootElement = doc.createElement("Card");
   	   	doc.appendChild(rootElement);
   	   	
   		for(int i = 0; i < resultLst.size(); i++){
   			if(i == 0){
   				Element header = addElement(doc, rootElement,  "Head", null);
   		  	   		addElement(doc, header,  "Date", ddMmYyyy);
   		  	   		addElement(doc, header,  "Data_Count", String.valueOf(resultLst.size()));
   			}
   			Element list = addElement(doc, rootElement, "Person", null);
   			EgovMap egov = (EgovMap)resultLst.get(i);
   			
   			addElement(doc, list, "e-TazkeraNumber", toNumPerConvet((String)egov.get("rsdtNoDp")));
   			
   			String surnm = (String)egov.get("surnm");
   			String givNm = (String)egov.get("givNm");
   			
   			if(surnm != null){
   				if("null".equals(surnm)){
   					surnm = "";
   				}
   			}else{
   				surnm = "";
   			}
   			
   			if(surnm != null && !"".equals(surnm)){
   				surnm = "\"" + surnm;
   				givNm = "\"" + givNm;
   			}
   			
   			String fullName = surnm.length() > 0 ? givNm + " " + surnm : givNm;
   			addElement(doc, list, "FullName", fullName);
   			addElement(doc, list, "EnglishName", (String)egov.get("enNm"));
   			addElement(doc, list, "FatherName", (String)egov.get("fthrNm"));
   			addElement(doc, list, "DateOfBirth", toNumPerConvet((String)egov.get("bthDdFa")));
   			addElement(doc, list, "DateOfBirth_EN", (String)egov.get("bthDdD"));
   			addElement(doc, list, "PermanentAddress", (String)egov.get("pmntAdCDCr"));
   			String presentAddress = (String)egov.get("curtAdCd");
   			String curtAdDtlCt = (String)egov.get("curtAdDtlCt");
   			if (curtAdDtlCt != null) {
   				presentAddress = curtAdDtlCt + "/" + presentAddress;
   			}
   			addElement(doc, list, "PresentAddress", presentAddress);
   			addElement(doc, list, "DateOfIssue", toNumPerConvet((String)egov.get("crdIsuceDdFa")));
   			addElement(doc, list, "DateOfExpiry", toNumPerConvet((String)egov.get("crdExpiryDdFa")));
   			addElement(doc, list, "GrandfatherName", (String)egov.get("gfthrNm"));
   			addElement(doc, list, "PlaceOfBirth", (String)egov.get("bthPlceCd"));
   			addElement(doc, list, "BloodGroup", (String)egov.get("bldTyeCd"));
   			addElement(doc, list, "Gender", (String)egov.get("gdrCd"));
   			addElement(doc, list, "Ethnicity", (String)egov.get("encyCd"));
   			addElement(doc, list, "MotherTongue", (String)egov.get("fmlyLangCd"));
   			addElement(doc, list, "TypeOfDisabilities", (String)egov.get("dsbtDtlCt"));
   			addElement(doc, list, "SummerResidence", (String)egov.get("smrRsdcCd"));
   			addElement(doc, list, "WinterResidence", (String)egov.get("wtrRsdcCd"));
   			addElement(doc, list, "Religion", (String)egov.get("rlgnCd"));
   			addElement(doc, list, "ReligionSect", (String)egov.get("rlgnSectCd"));
   			
   			RsdtInfrVO vos = new RsdtInfrVO();
   			vos.setRsdtNo((String)egov.get("rsdtNo"));
   			vos.setBioKey((String)egov.get("bioKey"));
   			
   			EgovMap eBlob = dao.selectXmlBlobDpp(vos);//get fingerprint
   			if(eBlob != null){
   				addElement(doc, list, "FingerPrint", (byte[])eBlob.get("fgpCt"));
   			}else{
   				addElement(doc, list, "FingerPrint", "");
   			}
   			
   			addElement(doc, list, "e-TazkeraNumber_EN", (String)egov.get("rsdtNo"));
   			
   			String crdIsuceSrlNo = getEgovMapValue(egov, "crdIsuceSrlNo");
   			if(crdIsuceSrlNo != null){
   				if(crdIsuceSrlNo.length() == 1){
   					crdIsuceSrlNo = "0"+crdIsuceSrlNo;
   				}
   			}
   			
   			addElement(doc, list, "SequenceOfIssuance", crdIsuceSrlNo);
   		}
   		StreamResult result = new StreamResult(new FileOutputStream(new File(subChipDir, fileChipSv)));
   		DOMSource source = new DOMSource(doc);
   		transformer.transform(source, result);
   		
   		//xml 작업 종료
   		
   		String wrkEdDt = dao.selectDppDbDatTime(new RsdtInfrVO());
   		//batch log chip
   		RsdtInfrVO sendFilevo = new RsdtInfrVO();
   		
   		if(resultLst.size() > 0){
	        sendFilevo.setWrkSttDt(wrkSttDt);
	   		sendFilevo.setWrkEdDt(wrkEdDt);
	   		sendFilevo.setOrgnzCd("");
	   		sendFilevo.setFleLc(subChipDir+File.separator+fileChipSv);
	   		sendFilevo.setTgtCn(String.valueOf(resultLst.size()));
	   		sendFilevo.setScsCn(String.valueOf(resultLst.size()));
	   		sendFilevo.setErorCn(String.valueOf(resultLst.size()));
	   		sendFilevo.setErorYn("N");
	   		sendFilevo.setMsg("");
	   		sendFilevo.setUserId("SYSTEM");
	   		sendFilevo.setPrcssDivCd("1");
	   		dao.insertIntoXmlBatchSend(sendFilevo);   			
   		}
   		/*
   		RsdtInfrVO sendFilevo = new RsdtInfrVO();
   		sendFilevo.setWrkTgtCn(String.valueOf(resultLst.size()));
   		sendFilevo.setWrkSucessCn(String.valueOf(resultLst.size()));
   		sendFilevo.setWrkErorCn("0");
   		sendFilevo.setUserId("batch");
   		sendFilevo.setFleNm(subChipDir+File.separator+fileChipSv);
   		dao.insertIntoXmlBatchSend(sendFilevo); //CM_DPP_FLE_PRCSS_LG_TB에 로그 기록
   		*/
   		
   		//card 작업 시작
   		String eof = "[###EOR###]\r\n";

  		File targetFile = new File(subCardDir, fileCardSv);
   		targetFile.createNewFile();
   		BufferedWriter output = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(targetFile.getPath()), "UTF8"));

		for(int i = 0; i < resultLst.size(); i++){
			EgovMap egov = (EgovMap)resultLst.get(i);
			StringBuffer sb = new StringBuffer();
			String rsdtNo = (String)egov.get("rsdtNo");
			String rsdtNoDp = (String)egov.get("rsdtNoDp");
			String cnt = String.valueOf(i+1);
			String cntTmp = "";
			for(int j = cnt.length(); j <= 5; j++){
				cntTmp += "0";
			}
			String impNum = cntTmp+cnt;
			sb.append(impNum);
		
			sb.append(getTagMake(toNumPerConvet(rsdtNoDp), "e-TazkeraNumber"));
			
			String surnm = (String)egov.get("surnm");
   			String givNm = (String)egov.get("givNm");
   			if(surnm != null){
   				if("null".equals(surnm)){
   					surnm = "";
   				}
   			}else{
   				surnm = "";
   			}
   			if(surnm != null && !"".equals(surnm)){
   				surnm = "\"" + surnm ;
   				givNm = "\"" + givNm;
   			}
   			String fullName = surnm.length() > 0 ? givNm + " " + surnm : givNm;
			
   			/*   			
  			String enFullNm = "";
   			String enSurNm  = "";
   			int lastWordPos = 0;
   			String enNmTmp = (String)egov.get("enGivNm");
   			enNmTmp = enNmTmp.trim();   		
   			String[] enNmArry = enNmTmp.split(" ");
   			

   			for(int k=0; k<enNmArry.length ; k++){   				
   				if(enNmArry[k].length() > 0){
   					lastWordPos = k;
   				}
   			}
   			
   			if(lastWordPos > 0){
   				enSurNm = enNmArry[lastWordPos].toUpperCase();
   			}
   			
   			for(int k=0; k<enNmArry.length ; k++){   				
   				if(enNmArry[k].length() > 0){ 
   					if(lastWordPos == 0){
   						enFullNm = enNmArry[k];
   					} else {
	   					if(k != lastWordPos){
	   						enFullNm = enFullNm + enNmArry[k] + " ";   						
	   					} else {
	   						enFullNm = enFullNm + enSurNm;
	   					}   						
   						
   					}
   				}
   			}  
   			*/
   			
			sb.append(getTagMake(fullName, "FullName"));
			sb.append(getTagMake((String)egov.get("fthrNm"), "FatherName"));
			sb.append(getTagMake((String)egov.get("gfthrNm"), "GrandfatherName"));
			sb.append(getTagMake(toNumPerConvet((String)egov.get("bthDdFa")), "DateOfBirth"));
			
			//sb.append(getTagMake((String)egov.get("bthPlceCd"), "PlaceOfBirth"));
			sb.append(getTagMake((String)egov.get("bthPlceCdCr"), "PlaceOfBirth"));
			
			sb.append(getTagMake((String)egov.get("curtAdCdPro"), "PresentAddress"));
			//sb.append(getTagMake((String)egov.get("pmntAdCd"), "PermanentAddress"));
			sb.append(getTagMake((String)egov.get("pmntAdCDCr"), "PermanentAddress"));
			
			//sb.append(getTagMake(toNumPerConvet((String)egov.get("crdIsuceDdFa")), "DateOfIssue"));
			//sb.append(getTagMake(toNumPerConvet((String)egov.get("crdExpiryDdFa")), "DateOfExpiry"));
			
			String photoFileName = ddMmYyyy+hhMmSi+"_"+impNum+"_photo.jpg";
			sb.append(getTagMake(photoFileName, "PhotographOfCardHolder"));
   				
			sb.append(getTagMake(rsdtNoDp, "e-TazkeraNumber_EN"));
			sb.append(getTagMake((String)egov.get("enNm"), "EnglishName"));
			sb.append(getTagMake((String)egov.get("bthDdD"), "DateOfBirth_EN"));
			//sb.append(getTagMake((String)egov.get("bthPlceCdEn"), "PlaceOfBirth_EN"));
			sb.append(getTagMake((String)egov.get("bthPlceCdCrEn"), "PlaceOfBirth_EN"));
			sb.append(getTagMake((String)egov.get("gdrCdEn"), "Gender_EN"));
			
			sb.append(getTagMake((String)egov.get("crdIsuceDdD"), "DateOfIssue_EN"));
			sb.append(getTagMake(toNumPerConvet((String)egov.get("crdIsuceDdFa")), "DateOfIssue"));
			//sb.append(getTagMake((String)egov.get("crdExpiryDdD"), "DateOfExpiry_EN"));
			String signFileName = ddMmYyyy+hhMmSi+"_"+impNum+"_sign.bmp";
			
			
			RsdtInfrVO vos = new RsdtInfrVO();
   			vos.setRsdtNo((String)egov.get("rsdtNo"));
   			vos.setBioKey((String)egov.get("bioKey"));
   			EgovMap eBlob = dao.selectXmlBlobDpp(vos);
   			
   			if(eBlob != null){
   				if(eBlob.get("sgntImg") == null){
   					signFileName = "";
   				}
   			}
						
			sb.append(getTagMake(signFileName, "SignatureOfCardHolder"));
			
			String mrz = MRZUtil.getMrzStr(
				"AFG"	
				,(String)egov.get("mrzNid1")
				,(String)egov.get("mrzNid2")
				,(String)egov.get("mrzDateOfBirth")
				,(String)egov.get("mrzSex")
				,(String)egov.get("mrzDateOfExpiry")
				,(String)egov.get("mrzSurName")
				,(String)egov.get("mrzGivenName")
			);
			
			sb.append(getTagMake(mrz.substring(0, 30), "MRZ1"));
			sb.append(getTagMake(mrz.substring(30, 60), "MRZ2"));
			sb.append(getTagMake(mrz.substring(60, 90), "MRZ3"));
			
			sb.append(getTagMake((String)egov.get("emlAd"), "email"));	
			
			sb.append(eof);
			output.write(sb.toString());

			//인터페이스테이블에등록
   			BigDecimal rsdtSeqNoBig = (BigDecimal)egov.get("rsdtSeqNo");
   			String rsdtSeqNo = rsdtSeqNoBig.toString();
			
   			RsdtInfrVO imVo = new RsdtInfrVO();
   			imVo.setRsdtNo(rsdtNo);
   			imVo.setCrdCd("1");
   			imVo.setAplCd("1");
   			imVo.setAplDd("");
   			imVo.setCrdDitbCd("");
   			imVo.setCrdDitbDd("");  
   			imVo.setBsnCd("1");
   			imVo.setBsnSeqNo(rsdtSeqNo);
   			
   			StringBuffer xsb = new StringBuffer();
   			xsb.append(subChipDir);
   			xsb.append(File.separator);
   			xsb.append(fileChipSv);
   			xsb.append(",");
   			xsb.append(subCardDir);
   			xsb.append(File.separator);
   			xsb.append(fileCardSv);
   			imVo.setFleNm(xsb.toString());
   			
   			dao.insertImCrdIsuTb(imVo);
   				
   			//이미지파일생성 시작
   			if(eBlob != null){
	   	   		if(eBlob.get("phImg") != null){
	   	   			imageMake((byte[])eBlob.get("phImg"), subCardDir + File.separator + photoFileName);
	   	   		}
	   	   		if(eBlob.get("sgntImg") != null){
	   	   			//imageMake((byte[])eBlob.get("sgntImg"), subCardDir + File.separator + signFileName);
	   	   			//signFileName = impNum+"_sign";
	   	   			String tmpBmp = ddMmYyyy+hhMmSi+"_"+impNum+"_sign";
	   	   			imageMakeBmp((byte[])eBlob.get("sgntImg"), subCardDir + File.separator + tmpBmp);
	   	   		}
   			}
   		}
		output.close();
		//card 작업 종료
		
		//batch log card
		if(resultLst.size() > 0){
			sendFilevo.setFleLc(subCardDir+File.separator+fileCardSv);
	   		dao.insertIntoXmlBatchSend(sendFilevo);
		}
		
		//파일 전송 작업 시작
		
		sendCardData(ddMmYyyy);
		sendChipData(ddMmYyyy);
		//중계서버 send 폴더 생성
   		String remoteSendBasePath = propertiesService.getString("remote.chip.send.base");
   		String remoteServerIp = propertiesService.getString("remote.server.ip");
   		int remoteServerPort = Integer.parseInt(propertiesService.getString("remote.server.port"));
   		String remoteServerId = propertiesService.getString("remote.server.id");
   		String remoteServerPw = propertiesService.getString("remote.server.pw");
   		SSHUtil sftp = new	SSHUtil(remoteServerIp, remoteServerPort, remoteServerId, remoteServerPw);
   		sftp.cd(remoteSendBasePath);
   		sftp.mkdir(ddMmYyyy);
   		sftp.logout();
   		
   		return resultLst.size();

	}	
   	
   	
   	
   	//ddMmYyyy String 만들기
   	private String getDdMmYyyy() {
   		StringBuffer calString = new StringBuffer();
   		Calendar cal = Calendar.getInstance();
   		String date = ""+cal.get(Calendar.DATE);
   		calString.append(date.length() == 1 ? "0"+date : date);
   		String month = ""+(cal.get(Calendar.MONTH)+1);
   		calString.append(month.length() == 1 ? "0"+month : month);
   		calString.append(cal.get(Calendar.YEAR));
   		
   		return calString.toString();
   	}
   	
   	//ddMmYyyy String 만들기
   	private String getHhMmSi() {
   		StringBuffer calString = new StringBuffer();
   		Calendar cal = Calendar.getInstance();
   		
   		calString.append("_");
   		String hour = ""+cal.get(Calendar.HOUR_OF_DAY);
   		calString.append(hour.length() == 1 ? "0"+hour : hour);
   		String minute = ""+cal.get(Calendar.MINUTE);
   		calString.append(minute.length() == 1 ? "0"+minute : minute);
   		String second = ""+cal.get(Calendar.SECOND);
   		calString.append(second.length() == 1 ? "0"+second : second);
   		//calString.append("_");
   		return calString.toString();
   	} 
   	
  	//xml 노드 추가
   	private Element addElement(Document doc, Element parElement, String eleName, Object eleValue){
   		Element element = doc.createElement(eleName);
   		if(eleValue != null){
   				String strEleValue = (String)eleValue;
   				if(strEleValue.equals("null")){
   					strEleValue = "";
   				}else if(strEleValue.equals("null null")){
   					strEleValue = "";
   				}
   			element.appendChild(doc.createTextNode(strEleValue));
   		}
   		parElement.appendChild(element);
   		return element;
   	}
   	
   	//blob 데이터 hex 값으로 변경.
   	private Element addElement(Document doc, Element parElement, String eleName, byte [] eleValue){
   		Element element = doc.createElement(eleName);
   		if(eleValue != null){
   			
   			String hexstr = Integer.toString(eleValue.length, 16);
   			String lim = "";
   			if(hexstr != null && hexstr.length() == 3){
   				lim = "0";
   			}else if(hexstr != null && hexstr.length() == 2){
   				lim = "00";
   			}else if(hexstr != null && hexstr.length() == 1){
   				lim = "000";
   			}else if(hexstr != null && hexstr.length() == 0){
   				lim = "0000";
   			}
   			lim = lim+hexstr;
   			hexstr = lim.toUpperCase();
   			
   			//element.appendChild(doc.createTextNode(new BigInteger(eleValue).toString(16)));
   			element.appendChild(doc.createTextNode(hexstr+byteArrToHexStr(eleValue)));
   		}
   		parElement.appendChild(element);
   		return element;
   	}
   	
   	//xml 속성설정
   	@SuppressWarnings("unused")
	private boolean addAttribute(Element element, String attrName, String attrValue){
   		element.setAttribute(attrName, attrValue);
   		return true;
   	}
   	
   	// byte array to hex string
   	private String byteArrToHexStr(byte[] arr){
   		StringBuffer hexStr = new StringBuffer();
		if(arr != null && arr.length > 0){
			for( int x=0;x<arr.length;x++ ){
				String tmp = Integer.toHexString( 0xff & arr[x] );
				String hexaDecimal= (tmp != null && tmp.length() < 2) ? "0"+tmp : tmp;
				hexStr.append( hexaDecimal );
			}
		}
		return hexStr.toString().toUpperCase();
	}
   	
   	// byte array to hex string
   	@SuppressWarnings("unused")
   	private byte [] hexStrToByteArr(String aop){
   		byte[] buffer = new byte[aop.length()/2];
	    for( int i=0;i<buffer.length;i++ ){
	         buffer[i] = (byte)Integer.parseInt(aop.substring(2*i, 2*i+2), 16);
	    }
		return buffer;
	}   	
   	
   	// 아라비아숫자 현지 숫자로변경
   	private String toNumPerConvet(String number){
   		String [] persianNumberArray = new String[]{"۰","۱","۲","۳","۴","۵","۶","۷","۸","۹"};
   		StringBuffer sb = new StringBuffer();
   		if(number != null){
	   		for(int i = 0;  i < number.length(); i++){
	   			String numChat = number.substring(i,i+1);
	   			if(Pattern.matches("^[0-9]*$", numChat)){
	   				sb.append(persianNumberArray[Integer.parseInt(numChat)]);
	   			}else{
	   				sb.append(numChat);
	   			}
	   		}
   		}
   		return sb.toString();
   	}  
   	
   	//태그 만들기
   	private String getTagMake(String value, String tag){
   		StringBuffer sb = new StringBuffer();
   		sb.append("<"+tag+">");
   		String values = value;
   		if(values != null && values.length() > 0){
   			if(values.equals("null")){
   				values = "";
   			}else if(values.equals("null null")){
   				values = "";
   			}
   			
   			sb.append(values);
   		}
   		sb.append("</"+tag+">");
   		return sb.toString();
   	}
   	
   	@SuppressWarnings("unused")
	private String getTagMake(byte [] value, String tag){
   		StringBuffer sb = new StringBuffer();
   		sb.append("<"+tag+">");
   		if(value != null && value.length > 0){
   			
   			sb.append(new BigInteger(value).toString(16));
   		}
   		sb.append("</"+tag+">");
   		return sb.toString();
   	}
   	
   	//sftp card 전송
   	private void sendCardData(String dirNm) throws Exception {
   		String localSendBasePath = propertiesService.getString("local.card.send.base");
   		String remoteRecvBasePath = propertiesService.getString("remote.card.recv.base");
   		sendData(localSendBasePath, remoteRecvBasePath, dirNm);
   	}
   	
   	//sftp chip 전송
   	private void sendChipData(String dirNm) throws Exception {
   		String localSendBasePath = propertiesService.getString("local.chip.send.base");
   		String remoteRecvBasePath = propertiesService.getString("remote.chip.recv.base");
   		sendData(localSendBasePath, remoteRecvBasePath, dirNm);
   	}  	
   	
   	//sftp 전송
   	private void sendData(String localSendBasePath, String remoteRecvBasePath, String dirNm) throws Exception {
   		log.debug("▷▷▷▷ directory : " + dirNm);
   		log.debug("▷▷▷▷ localSendBasePath : " + localSendBasePath);
   		log.debug("▷▷▷▷ remoteRecvBasePath : " + remoteRecvBasePath);
   		
   		String remoteServerIp = propertiesService.getString("remote.server.ip");
   		int remoteServerPort = Integer.parseInt(propertiesService.getString("remote.server.port"));
   		String remoteServerId = propertiesService.getString("remote.server.id");
   		String remoteServerPw = propertiesService.getString("remote.server.pw");
   		
   		SSHUtil sftp = new	SSHUtil(remoteServerIp, remoteServerPort, remoteServerId, remoteServerPw);
   		sftp.cd(remoteRecvBasePath);
   		sftp.mkdir(dirNm);
   		//sftp.cd(remoteRecvBasePath + "/" + dirNm);
   		//상대경로일때
   		sftp.cd(dirNm);
   		
//   		String dirPath = localSendBasePath + File.separator + dirNm;
   		String dirPath = localSendBasePath + "/" + dirNm;
		File dir = new File(dirPath);
		
   		log.debug("▷▷▷▷ dirPath : " + dir.getAbsolutePath());

		sftp.lcd(dir.getAbsolutePath());
   		
   		File[] files = dir.listFiles();
   		for (int i = 0; i < files.length; i++) {
   			log.debug("▷▷▷▷ " + files[i].getName());
   			sftp.put(files[i].getName());
//   			sftp.put(dirPath + "/" + files[i].getName());
   		}
   		sftp.logout();
   		
   	}
   	
   	//file image save
   	private void imageMake(byte[] arr, String file){
   		FileOutputStream outstream = null;
		try {
			outstream = new FileOutputStream(new File(file));
			outstream.write(arr);
		} catch (FileNotFoundException fe) {
			fe.printStackTrace();
		} catch (IOException ie) {
			ie.printStackTrace();
		}finally{
			try{
				if(outstream != null) {
					outstream.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
   	}
   	
   	private void imageMakeBmp(byte[] arr, String file){
   		FileOutputStream outstream = null;
		try {
			String files = file+".bmp";
			outstream = new FileOutputStream(new File(files));
			outstream.write(arr);
			outstream.close();
			
		} catch (FileNotFoundException fe) {
			fe.printStackTrace();
		} catch (IOException ie) {
			ie.printStackTrace();
		}finally{
			try{
				if(outstream != null) {
					outstream.close();
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
   	}   	
   	   	
   	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param EgovMap, String
	 * @return String
	 * @exception Exception
	 */
	private String getEgovMapValue(EgovMap obj, String value){
		String result = "";
		if(obj != null && !obj.isEmpty() && value != null){
			Object object = obj.get(value);
			if(object != null){
				if(object instanceof BigDecimal){
					BigDecimal big = (BigDecimal)object;
					int bigInt = big.intValue();
					result = String.valueOf(bigInt);
				}else if(object instanceof String){
					result = (String)object;
				}
			}
		}
		return result;
	}
	   	
 //=============================================================================================  	
   	//파일 수신
   	public void getXmlGenerate() throws Exception {
   		String ddMmYyyy = getDdMmYyyy();
   		
		recvCardData(ddMmYyyy);
		recvChipData(ddMmYyyy);
   	}
   	
   	//sftp card 수신
   	private void recvCardData(String dirNm) throws Exception {
   		String localRecvBasePath = propertiesService.getString("local.card.recv.base");
   		String remoteSendBasePath = propertiesService.getString("remote.card.send.base");
   		recvData(localRecvBasePath, remoteSendBasePath, dirNm, "card");
   	}
   	
   	//sftp chip 수신
   	private void recvChipData(String dirNm) throws Exception {
   		String localRecvBasePath = propertiesService.getString("local.chip.recv.base");
   		String remoteSendBasePath = propertiesService.getString("remote.chip.send.base");
   		recvData(localRecvBasePath, remoteSendBasePath, dirNm ,"chip");
   	}   	
   	
   	//sftp 수신
   	private void recvData(String localRecvBasePath, String remoteSendBasePath, String dirNm, String type) throws Exception {
   		log.debug("▷▷▷▷ directory : " + dirNm);
   		log.debug("▷▷▷▷ localRecvBasePath : " + localRecvBasePath);
   		log.debug("▷▷▷▷ remoteSendBasePath : " + remoteSendBasePath);
   		
   		String remoteServerIp = propertiesService.getString("remote.server.ip");
   		int remoteServerPort = Integer.parseInt(propertiesService.getString("remote.server.port"));
   		String remoteServerId = propertiesService.getString("remote.server.id");
   		String remoteServerPw = propertiesService.getString("remote.server.pw");
   		
   		if(type != null && type.equals("card")){
   			SSHUtil sftp = new	SSHUtil(remoteServerIp, remoteServerPort, remoteServerId, remoteServerPw);
					   		
	   		String dirPath = localRecvBasePath;
	   		File localDir = new File(dirPath);
	   		if(!localDir.isDirectory()){
	   			localDir.mkdir();
	  	   	}
	   		String remotedir = remoteSendBasePath + "/" + dirNm;
	   		String localdir = localDir.getAbsolutePath();
	
	   		log.debug("▷▷▷▷ remotedir : " + remotedir);
	   		log.debug("▷▷▷▷ localdir : " + localdir);
	   		sftp.mget(remotedir, localdir);
	   		sftp.logout();
   		}else if(type != null && type.equals("chip")){
   		
	   		RsdtInfrVO vo = new RsdtInfrVO();
	   		vo.setSearchKeyword(dirNm); // mmddyyyy
	   		vo.setSearchKeyword2("0001"); //배치타입 수신. 0001 chip
	   		
	   		int result = dao.selectIntoXmlBatch(vo);
	   		result = 0;
	   		if(result == 0){
		   		SSHUtil sftp = new	SSHUtil(remoteServerIp, remoteServerPort, remoteServerId, remoteServerPw);
		   		String dirPath = localRecvBasePath;
		   		File localDir = new File(dirPath);
		   		if(!localDir.isDirectory()){
		   			localDir.mkdir();
		  	   	}
		   		String remotedir = remoteSendBasePath + "/" + dirNm;
		   		String localdir = localDir.getAbsolutePath();
		
		   		log.debug("▷▷▷▷ remotedir : " + remotedir);
		   		log.debug("▷▷▷▷ localdir : " + localdir);
		   		boolean flag = sftp.mget(remotedir, localdir);
		   		sftp.logout();
		   		
		   		if(flag){
		   			//String fileNm = "Card_Chip_Result.xml";
		   			//boolean result = getXmlParsing(localdir, dirNm, fileNm);
		   			//StringBuffer yyyymmdd = new StringBuffer();
		   			//if(dirNm != null && dirNm.length() == 8){
		   			//	yyyymmdd.append(dirNm.substring(4, 8));
		   			//	yyyymmdd.append(dirNm.substring(2, 4));
		   			//	yyyymmdd.append(dirNm.substring(0, 2));
		   			//}
		   			//fileNm = yyyymmdd.toString() + fileNm;
		   			File file = new File(localdir+File.separator+dirNm);
		   			File [] fileList = file.listFiles();
		   			for(int i = 0 ;i < fileList.length; i++){
		   				File fileTmp = fileList[i];
		   				if(fileTmp.isFile()){
		   					String nameTmp = fileTmp.getName();
		   					if(nameTmp.indexOf(".xml") != -1){
		   						log.debug("▷▷▷▷ localdir file: " + nameTmp);
		   						getXmlParsing(localdir, dirNm, nameTmp);
		   					}
		   				}
		   			}
		   		}
	   		}
   		}
   	}   	   	
 
	//xml 파일 파싱하기
	private void getXmlParsing(String localdir,  String dirNm, String fileNm) throws Exception {
		
		String fleNm = localdir+File.separator+dirNm+File.separator+fileNm;
		int totCnt = 0;
		int sccCnt = 0;
		int errCnt = 0;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance(); 
		DocumentBuilder parser = factory.newDocumentBuilder(); 
		Document doc = parser.parse(localdir+File.separator+dirNm+File.separator+fileNm);
		Element rootElement = doc.getDocumentElement(); 
		NodeList memberList = rootElement.getChildNodes(); 
		for(int i=0; i < memberList.getLength(); i++){
			Node node = memberList.item(i); 
			if(node.getNodeType() == Node.ELEMENT_NODE) { 
				if(node.getNodeName().equals("Person")){
					String nid = null;
					String date = null;
					String status = null;
					String encUsePin = null;
					String encSoPin = null;
					NodeList childNodeList = node.getChildNodes();
					for(int k=0; k < childNodeList.getLength(); k++){
		   				Node childNode = childNodeList.item(k); 
		   				if(childNode.getNodeType() == Node.ELEMENT_NODE) { 
		   					if(childNode.getNodeName().equals("NID")){
		   						nid = getXmlNodeValue(childNode);
		   					}else if(childNode.getNodeName().equals("Card_Issue_Date")){
		   						date = getXmlNodeValue(childNode);
		   					}else if(childNode.getNodeName().equals("Card_Issue_Status")){
		   						status = getXmlNodeValue(childNode);
		   					}else if(childNode.getNodeName().equals("ENCRYPTION_USERPIN")){
		   						encUsePin = getXmlNodeValue(childNode);
		   					}else if(childNode.getNodeName().equals("ENCRYPTION_SOPIN")){
		   						encSoPin = getXmlNodeValue(childNode);
		   					}
		   				}
					}
					// 디비 IM_CRD_DLVR_TB 인서트 및 업데이트 IM_CRD_ISU_TB  APL_CD 발급상태 0001 -> 다른 코드로 수정필요
					// nid, date, status
					nid = toPerConvetNum(nid);
					RsdtInfrVO vo = new RsdtInfrVO();
					vo.setRsdtNo(nid);
					totCnt++;
					if(status != null && status.equals("0001")){
						sccCnt++;
					}else{
						vo.setCrdIsuErorDd(date);
						vo.setCrdIsuErorRsn("");
						errCnt++;
					}
					vo.setCrdIsuDd(date);
					vo.setCrdIsuStusCd(status);
					vo.setCrdEncUsePin(encUsePin);
					vo.setCrdEncSoPin(encSoPin);
					//등록된 자료가 없을경우만 인서트
					if(dao.selectImCrdDlvrTb(vo) == 0){
						dao.insertImCrdDlvrTb(vo);
					}
				}
			}
			
			
			/**
   			// 자식 노드가 요소일 경우에만 실행한다. 
   			if(node.getNodeType() == Node.ELEMENT_NODE) { 
   				System.out.println("########### node.getNodeName() : " + node.getNodeName()); // tag이름 
   				NodeList childNodeList = node.getChildNodes(); 
	   			for(int k=0; k < childNodeList.getLength(); i++){
	   				Node childNode = childNodeList.item(k); 
		   			NamedNodeMap attrMap = childNode.getAttributes(); 
		   			if(attrMap != null) { 
		   				Node minNode = attrMap.getNamedItem("min"); 
		   				Node maxNode = attrMap.getNamedItem("max"); 
		   			// min Node가 있는경우 
						if(minNode != null) { 
							if(minNode != null && minNode.getNodeType() == Node.ATTRIBUTE_NODE) { 
								System.out.println("##### min : Attribute Node"); 
							} else if(minNode != null && minNode.getNodeType() == Node.ELEMENT_NODE) { 
							System.out.println("##### min : Element Node"); 
							} 
							System.out.println("##### min : " + minNode.getNodeValue()); 
						} 
			   			// max Node가 있는경우 
			   			if(maxNode != null) { 
			   				System.out.println("##### max : " + maxNode.getNodeValue()); 
			   			} 
			   		} 
		   			if(childNode.getNodeType() == Node.ELEMENT_NODE) { 
			   			System.out.print("##### " + childNode.getNodeName()); 
			   			System.out.print(" : "); 
			   			System.out.println(childNode.getFirstChild().getNodeValue()); 
		   			} 
			   	}
   			}
   			*/
		}
		RsdtInfrVO vo = new RsdtInfrVO();
		vo.setWrkTgtCn(String.valueOf(totCnt));
		vo.setWrkSucessCn(String.valueOf(sccCnt));
		vo.setWrkErorCn(String.valueOf(errCnt));
		vo.setFleNm(fleNm);
		vo.setUserId("batch");
		dao.insertIntoXmlBatchSend(vo);
		//return false;
	}   	
   	
	//xml node value
	private String getXmlNodeValue(Node node){
		String result = null;
		if(node.getFirstChild() != null){
			result = node.getFirstChild().getNodeValue();
		}else{
			result = "";
		}	
		return result;
	}
	
	//현지어 숫자를 아라비아숫자로 변경
	private String toPerConvetNum(String number){
   		String [] persianNumberArray = new String[]{"۰","۱","۲","۳","۴","۵","۶","۷","۸","۹"};
   		StringBuffer sb = new StringBuffer();
   		if(number != null){
   			boolean flag = false;
	   		for(int i = 0;  i < number.length(); i++){
	   			String numChat = number.substring(i,i+1);
	   			for(int j = 0; j < persianNumberArray.length; j++){
	   				if(numChat.equals(persianNumberArray[j])){
	   					sb.append(String.valueOf(j));
	   					flag = true;
	   					break;
	   				}
	   			}
	   			if(!flag){
	   				sb.append(numChat);
	   			}
	   			flag = false;
	   		}
   		}
   		return sb.toString();
   	}	
}