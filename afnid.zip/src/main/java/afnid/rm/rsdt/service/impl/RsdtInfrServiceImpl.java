package afnid.rm.rsdt.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.ConnectException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.w3c.dom.Element;

import afnid.cm.NidMessageSource;
import afnid.cm.cmm.error.NidException;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.bioif.service.BioIfInfrService;
import afnid.rm.hst.service.RsdtInfrLgService;
import afnid.rm.rsdt.service.RsdtInfrService;
import afnid.rm.rsdt.service.RsdtInfrVO;
import egovframework.rte.fdl.cmmn.AbstractServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;

/** 
 * This service class is biz-class of common
 * and implements FmlyInfoService class.
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.01.04
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2013.01.04  		BH Choi         		Create
 *
 * </pre>
 */
@Service("rsdtInfoService")
public class RsdtInfrServiceImpl extends AbstractServiceImpl implements RsdtInfrService {
	/** RsdtInfoDao */
    @Resource(name="rsdtInfoDAO")
    private RsdtInfrDAO dao;
    
    /** ID Generation */
    //@Resource(name="egovIdGnrService")    
    //private EgovIdGnrService egovIdGnrService;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
	@Resource(name = "bioIfInfrService")
    private BioIfInfrService bioIfService;
	
    @Resource(name = "rsdtInfrLgService")
    private RsdtInfrLgService rsdtInfrLgService;
	
	private int sendCnt = 0;
    /**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<RsdtInfrVO> searchListRsdtInfr(RsdtInfrVO vo) throws Exception {
      		return dao.selectListRsdtInfr(vo);
   	}

   	/**
	 * Biz-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
   	public int searchListRsdtInfrTotCn(RsdtInfrVO vo) throws Exception {
        return dao.selecthListRsdtInfrTotCn(vo);
	}
   	
   	
	
    /**
	 * Biz-method for retrieving of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return RsdtInfrVO object of program
	 * @exception Exception
	 */
	public RsdtInfrVO searchRsdtInfrView(RsdtInfrVO vo) throws Exception {
		int adultAge = propertiesService.getInt("adultAge");
   		vo.setAdultAge(String.valueOf(adultAge));
   		return dao.selectRsdtInfrView(vo);
	}
	
	 

    /**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<RsdtInfrVO> searchListOthrNatLangInfr(RsdtInfrVO vo) throws Exception {
   		return dao.selectListOthrNatLangInfr(vo);
	}

    /**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<RsdtInfrVO> searchListFrgnLangInfr(RsdtInfrVO vo) throws Exception {
   		return dao.selectListFrgnLangInfr(vo);
	}

	/**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<RsdtInfrVO> searchListOthrNatLangInfrForRcpt(RsdtInfrVO vo) throws Exception {
   		return dao.selectListOthrNatLangInfrForRcpt(vo);
	}

    /**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<RsdtInfrVO> searchListFrgnLangInfrForRcpt(RsdtInfrVO vo) throws Exception {
   		return dao.selectListFrgnLangInfrForRcpt(vo);
	}
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public List<RsdtInfrVO> searchListSpus(RsdtInfrVO vo) throws Exception {
   		return dao.selectListSpus(vo);
	}
	
	
	
	
	/**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public EgovMap searchRsdtInfrDat(String rsdtSeqNo) throws Exception {
   		return dao.selectRsdtInfrDat(rsdtSeqNo);
	}
	/**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public String searchRsdtInfrHashDat(EgovMap em, String bsnCd) throws Exception {
   		return dao.selectRsdtInfrHashDat(em, bsnCd);
	}

    /**
	 * Biz-method for registering information of new resident. <br>
	 * 
	 * @param vo Input item for registering new resident(RsdtInfrVO).
	 * @return int update of program
	 * @exception Exception
	 */
	public int modifyRsdtInfr(RsdtInfrVO vo) throws Exception {
		
		/** Loading session information  */
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setFstRgstUserId(user.getUserId());
		String useLangCd = user.getUseLangCd();
		vo.setUseLangCd(useLangCd);
		
		String userId = user.getUserId();
		vo.setUserId(userId);		
		vo.setOfficerNo(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());	
		
		int resultValue = 0;
		
		//dao.insertRsdtInfrHst(vo);
			
		resultValue = dao.updateRsdtInfr(vo);
		String fmlyBokNo  = vo.getFmlyBokNo();
		String fmlyMberNo = vo.getFmlyMberNo();
	
		//After deleting the existing data register
		dao.deleteOthrNatLang(vo);
		dao.deleteFrgnLang(vo);

		String [] natLangCds = vo.getNatLangCds();
		String [] frgnLangCds = vo.getFrgnLangCds();
		
		RsdtInfrVO result = new RsdtInfrVO();
		if(natLangCds != null && natLangCds.length > 0){
			for(int i = 0; i < natLangCds.length; i++){
				if(natLangCds[i].trim().length() > 0){
					result = result.init();
					result.setFmlyBokNo(fmlyBokNo);
					result.setFmlyMberNo(fmlyMberNo);
					result.setFstRgstUserId(user.getUserId());
					result.setNatLangCd(natLangCds[i]);
					dao.insertOthrNatLang(result);
				}
			}
		}
		if(frgnLangCds != null && frgnLangCds.length > 0){
			for(int i = 0; i < frgnLangCds.length; i++){
				if(frgnLangCds[i].trim().length() > 0){
					result = result.init();
					result.setFmlyBokNo(fmlyBokNo);
					result.setFmlyMberNo(fmlyMberNo);
					result.setFstRgstUserId(user.getUserId());
					result.setFrgnLangCd(frgnLangCds[i]);
					dao.insertFrgnLang(result);
				}
			}
		}

    	return resultValue;
	}
	
	
	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public String searchRsdtInfrDvrcInfr(RsdtInfrVO vo) throws Exception {
      		return dao.selectRsdtInfrDvrcInfr(vo);
   	}
	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public String searchRsdtInfrMrrgInfrTarget(RsdtInfrVO vo) throws Exception {
      		return dao.selectRsdtInfrMrrgInfrTarget(vo);
   	}

	
	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<RsdtInfrVO> searchListRsdtRgstAprvInfr(RsdtInfrVO vo) throws Exception {
      		return dao.selectListRsdtRgstAprvInfr(vo);
   	}   

   	/**
	 * Biz-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
   	public int searchListRsdtRgstAprvInfrTotCn(RsdtInfrVO vo) throws Exception {
        return dao.selectListRsdtRgstAprvInfrTotCn(vo);
	}  
   	
   	/**
	 * Biz-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return String object of Program
	 * @exception Exception
	 */
   	public EgovMap modifyAprv(RsdtInfrVO vo) throws Exception {
   		EgovMap aprvEm = new EgovMap();
   		String result = null;
   		String rsdtNo = null;
		String bioKey = null;
		String dupYn = null;
		byte [] bioFle = null;
		EgovMap emResult = null;
   		try{
   			
	   		vo.setTamLedrCfmYn("Y");
	   		//dao.insertRsdtInfrHst(vo);
	   		vo.setRsdtStusCd("1");
	   		
	   		modifyRsdtInfr(vo);
	   		
   			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
   	   		String userId = user.getUserId();
	   		vo.setUserId(userId);	   		
	   		vo.setOfficerNo(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());
	   		
	   		int adultAge = propertiesService.getInt("adultAge");
	   		vo.setAdultAge(String.valueOf(adultAge));
	   		
	   		result = dao.updateAprv(vo);
	   		log.debug("getXmlData(vo.getSgnt(), Signature)");
	   		log.debug(vo.getSgnt());
	   		String resultSgnt = getXmlData(vo.getSgnt(), "Signature");
	   		if(resultSgnt != null && resultSgnt.length() > 0){
		   		vo.setSgnt(resultSgnt);
		   		dao.updateRsdtInfrSgnt(vo);
	   		}
	   		
	   		EgovMap em = dao.selectRsdtInfrDat(vo.getRsdtSeqNo());
	   		String hash = "";
	   		if(em != null && !em.isEmpty()){
	   			hash = dao.selectRsdtInfrHashDat(em, "1");
	   			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
				if(hash != null && hash.indexOf(reg) == -1){
					String admTel = nidMessageSource.getMessage("admTelNo");
					throw processException("pki.websrvcEror.msg", new String[]{hash, admTel});
				}
	   			resultSgnt = getXmlData(hash, "ds:Signature");
	   		}
	   		if(resultSgnt != null && resultSgnt.length() > 0){
	   			vo.setSysSgnt(resultSgnt);
		   		dao.updateRsdtInfrSysSgnt(vo);
	   		}
	   		
	   		EgovMap tcpMap = dao.selectRsdtInfrTcpIpDat(vo.getRsdtSeqNo());
	   		if(tcpMap != null && !tcpMap.isEmpty()){
	   			rsdtNo = (String)tcpMap.get("rsdtNo");
	   			bioKey = (String)tcpMap.get("bioKey");
	   			dupYn = (String)tcpMap.get("age");
	   			
   				EgovMap ImCapt = dao.selectImBioCaptTbInfr(bioKey);
   				if(ImCapt != null && !ImCapt.isEmpty()){
   					dao.deleteImBioCaptTb(bioKey);
   		   			bioFle = (byte[])ImCapt.get("bioFle");
   		   			if(bioFle != null){
   		   				log.debug("addRsdtInfrBioIf info");
   		   				log.debug("bioKey : " + bioKey + " rsdtNo : " + rsdtNo +" dupYn : " + dupYn +" userId : " + userId);
   		   				emResult = addRsdtInfrBioIf(bioKey, rsdtNo, dupYn, userId, "i", bioFle);
   		   				aprvEm.put("emResult", emResult);
   		   			}
   				}
	   		}
	   	}catch(Exception e){
	   		if(e instanceof IOException){
	   			log.error(e);
	   			throw e;
	   		}else if(e instanceof NidException){
	   			log.error(e);
	   			throw e;
	   		}else{
	   			log.error(e);
	   			throw e;
	   		}
	   	}
	   	aprvEm.put("result", result);
   		return aprvEm;
	}  
   	
   	
   	/**
	 * Biz-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
   	public RsdtInfrVO searchRsdtInfrPer(RsdtInfrVO vo) throws Exception {
   		
   		rsdtInfrLgService.addRsdtInfrLg(vo.getSearchKeyword9(),"17");
        return dao.selectRsdtInfrPer(vo);
	}  

   	
   	/**
	 * Biz-method for retrieving  list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return String object of Program
	 * @exception Exception
	 */
   	public String searchRsdtBioRgstStus(RsdtInfrVO vo) throws Exception {
        return dao.selectRsdtBioRgstStus(vo);
	}  
   	
   	/**
	 * Biz-method for Check Date of Birth of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtInfrVO).
	 * @return String object of Program
	 * @exception Exception
	 */
   	public String searchRsdtBthCheck(RsdtInfrVO vo) throws Exception {
        return dao.selectRsdtBthCheck(vo);
	}  
   	
   	/**
	 * Biz-method for Date Conversion of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtInfrVO).
	 * @return String object of Program
	 * @exception Exception
	 */
   	public String searchDateConvert(RsdtInfrVO vo) throws Exception {
        return dao.selectDatConvert(vo);
	}  
   	
   	
   	
   	/**
	 * Create Tag. <br>
	 *
	 * @param value Input item for retrieving of program(byte[]).
	 * @param tag Input item for retrieving of program(String).
	 * @return String object of Program
	 * @exception Exception
	 */
   	@SuppressWarnings("unused")
	private String getTagMake(byte [] value, String tag){
   		StringBuffer sb = new StringBuffer();
   		sb.append("<"+tag+">");
   		if(value != null && value.length > 0){
   			
   			sb.append(new BigInteger(value).toString(16));
   		}
   		sb.append("</"+tag+">");
   		return sb.toString();
   	}
   	
   	

   	
	/**
	 * xml property set. <br>
	 *
	 * @param element Input item for retrieving of program(Element).
	 * @param attrName Input item for retrieving of program(String).
	 * @param attrValue Input item for retrieving of program(String).
	 * @return boolean For changes
	 * @exception Exception
	 */
   	@SuppressWarnings("unused")
	private boolean addAttribute(Element element, String attrName, String attrValue){
   		element.setAttribute(attrName, attrValue);
   		return true;
   	}
   	

   	
   	/**
	 * byte array to hex string. <br>
	 *
	 * @param aop Input item for retrieving of program(String).
	 * @return byte[] object of program
	 * @exception Exception
	 */
   	@SuppressWarnings("unused")
   	private byte [] getHexStrToByteArr(String aop){
   		byte[] buffer = new byte[aop.length()/2];
	    for( int i=0;i<buffer.length;i++ ){
	         buffer[i] = (byte)Integer.parseInt(aop.substring(2*i, 2*i+2), 16);
	    }
		return buffer;
	}
   	
   	
   	
   	
    /**
	 * Biz-method for Receipt to inquire of program. <br>
	 *
	 * @param vo Input item for retrieving of program(RsdtInfrVO).
	 * @return RsdtInfrVO object of program
	 * @exception Exception
	 */
	public RsdtInfrVO searchRsdtInfrRcpt(RsdtInfrVO vo) throws Exception {
   		return dao.selectRsdtInfoRcpt(vo);
	}
	
	
	
	
	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchListPoliCntrCd(RsdtInfrVO vo) throws Exception {
   		List<EgovMap> list = null;
   		if(vo != null){
   			if(vo.getSearchKeyword10() != null && "r".equals(vo.getSearchKeyword10())){
   				list = dao.selectListPoliCntrCd(vo);
   			}else if(vo.getSearchKeyword10() != null && "dp".equals(vo.getSearchKeyword10())){
   				list = dao.selectPoliCntrDstrPrvicLst(vo);
   			}else if(vo.getSearchKeyword10() != null && "area".equals(vo.getSearchKeyword10())){
   				list = dao.selectPoliCntrDstrPrvicAreaLst(vo);
   			}else if(vo.getSearchKeyword10() != null && "view".equals(vo.getSearchKeyword10())){
   				list = dao.selectPoliStatLst(vo);
   			}else if(vo.getSearchKeyword10() != null && "vtrView".equals(vo.getSearchKeyword10())){
   				list = dao.selectVtrLst(vo);
   			}
   		}
    	return list;
   	}
   	
   
   	
   	/**
	 * file delete of program. <br>
	 *
	 * @param path Input item for retrieving list of program(File).
	 * @return boolean Deletion
	 * @exception Exception
	 */
   	@SuppressWarnings("unused")
	private boolean isDltDir(File path) { 
   		if(!path.exists()) { 
   			return false; 
   		} 
		File[] files = path.listFiles(); 
		for (File file : files) { 
			if (file.isDirectory()) { 
				isDltDir(file); 
			} else { 
				file.delete(); 
			} 
		} 
		return path.delete(); 
    }
   	
	/**
	 * file copy of program. <br>
	 *
	 * @param path Input item for retrieving list of program(File).
	 * @param target Input item for retrieving list of program(File).
	 * @return void
	 */
	private void isChDir( File path , File target){
		if(!path.exists()) { 
   			return; 
   		}
		if(!target.exists()) { 
			target.mkdir();
   		} 
		File[] files = path.listFiles(); 
		for (File file : files) { 
			if (file.isDirectory()) {
				getChDir(file, target);
			} else { 
				getFileCopy(path, file, target);
			} 
		} 
	}
	
	/**
	 * file copy of program. <br>
	 *
	 * @param file Input item for retrieving list of program(File).
	 * @param target Input item for retrieving list of program(File).
	 * @return void
	 */
	private void getChDir(File file, File target){
		isChDir(file, new File(target.getAbsolutePath(), file.getName())); 
	}
	/**
	 * file copy of program. <br>
	 *
	 * @param path Input item for retrieving list of program(File).
	 * @param file Input item for retrieving list of program(File).
	 * @param target Input item for retrieving list of program(File).
	 * @return void
	 */
	private void getFileCopy(File path, File file, File target){
		isFileCopy(new File(path, file.getName()), new File(target, file.getName()));
	}
	

	/**
	 * file copy of program. <br>
	 *
	 * @param source Input item for retrieving list of program(File).
	 * @param target Input item for retrieving list of program(File).
	 * @return void
	 */
	private void isFileCopy(File source, File target){
		FileOutputStream fos = null;
		FileInputStream fis = null;
		byte b[] = new byte[1024];
		try{
			fos = new FileOutputStream(target);
			fis = new FileInputStream(source);
			int i = 0;
			while (i != -1) {
				i = fis.read(b);
	            fos.write(b, 0, i);
	            fos.flush();
	            fos.getFD().sync();
	        }
		}catch(Exception e){
			log.error(e);
		}finally{
			try{
				if(fos != null){
					fos.close();
				}
				if(fis != null){
					fis.close();
				}
			}catch(Exception e){
				log.error(e);
			}
		}
	}
	
   	
   	/**
	 * Actual sftp transfer of program. <br>
	 *
	 * @param sftp Input item for retrieving list of program(SSHUtil).
	 * @param dir Input item for retrieving list of program(File).
	 * @return void
	 * @exception Exception
	 */
   	@SuppressWarnings("unused")
	private void setFilePut( SSHUtil sftp , File dir) throws Exception {
		File[] files = dir.listFiles(); 
		for (File file : files) { 
			if (file.isDirectory()) {
				sftp.mkdir(file.getName());
				sftp.cd(file.getName());
				setFilePut(sftp, file); 
			} else { 
				sftp.lcd(file.getParent());
				sftp.put(file.getName());
			} 
		}
		sftp.cd("..");
	}
   	
   	
   	
   	
   	
   	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchListRsdtInfrPop(RsdtInfrVO vo) throws Exception {
      		return dao.selectListRsdtInfrPop(vo);
   	}

   	/**
	 * Biz-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
   	public int searchListRsdtInfrPopTotCn(RsdtInfrVO vo) throws Exception {
        return dao.selectListRsdtInfrPopTotCn(vo);
	}
   	
   	
   	
   	
   	
    
    
    
   	
	
	/**
	 * Bio bio-data sent to the server. <br>
	 * @param String, String, String, String, String, byte[]
	 * @return void
	 * @exception Exception
	 */
   	private EgovMap addRsdtInfrBioIf(String bioKey, String rsdtNo, String dupYn, String userId, String insUpd, byte [] bioFle) throws Exception {
   		int tcpCnt = propertiesService.getInt("rm.bio.socketReSend");
   		sendCnt++;
   		EgovMap em = null;
   		try{
   			em = bioIfService.addBioSocketIf(bioKey, rsdtNo, dupYn, userId, insUpd, bioFle);
   		}catch(ConnectException e){
   			log.error(e);
   			if(tcpCnt != sendCnt){
   				em = addRsdtInfrBioIf(bioKey, rsdtNo, dupYn, userId, insUpd, bioFle);
   			}else{
   				log.error(e);
   				sendCnt = 0;
   				throw e;
   			}
   		}catch(IOException e){
   			log.error(e);
   			if(tcpCnt != sendCnt){
   				em = addRsdtInfrBioIf(bioKey, rsdtNo, dupYn, userId, insUpd, bioFle);
   			}else{
   				log.error(e);
   				sendCnt = 0;
   				throw e;
   			}
   		}catch(Exception e){
   			log.error(e);
   			sendCnt = 0;
   			throw e;
   		}finally{
   			try{
   				sendCnt = 0;
   			}catch(Exception e){
   				log.error(e);
   			}
   		}
   		return em;
   	}
	
   	   		
	/**
	 * Biz-method for Delete directories and files <br>
	 *
	 * @param String
	 * @return void
	 */
	@SuppressWarnings("unused")
	private void removeDIR(String source){
		File[] listFile = new File(source).listFiles(); 
		try{
			if(listFile.length > 0){
				for(int i = 0 ; i < listFile.length ; i++){
					if(listFile[i].isFile()){
						listFile[i].delete(); 
					}else{
						removeDIR(listFile[i].getPath());
					}
					listFile[i].delete();
				}
			}
		}catch(Exception e){
			log.error(e);
		}
	}
   	
	
	
	
	
	/**
	 * Biz-method for Check whether the card replacement application. <br>
	 *
	 * @param String, String
	 * @return String
	 * @exception Exception
	 */
	public String searchRsdtCrdIsuAppStus(String rsdtNo, String tye, String str) throws Exception { 
		List<EgovMap>  list = dao.selectRsdtCrdIsuAppStus(rsdtNo);
		String resultValue = "";
		String ign = "";
		if(str != null){
			if("l".equals(str)){
				ign = "LostApl";
			}else if("da".equals(str)){
				ign = "DmagApl";
			}else if("rh".equals(str)){
				ign = "RhbltApl";
			}else if("r".equals(str)){
				ign = "RnwlApl";
			}else if("m".equals(str)){
				ign = "MrrgApl";
			}else if("d".equals(str)){
				ign = "DvrcApl";
			}else if("md".equals(str)){
				ign = "MdfctApl";
			}else if("i".equals(str)){
				ign = "Isuce";
			}else if("etc".equals(str)){
				ign = "EtcApl";
			}
		}
		if(list != null && !list.isEmpty()){
			EgovMap tmp = null;
			int count = 0;
			for(int i = 0 ; i < list.size(); i++){
				tmp = list.get(i);
				BigDecimal cnt = (BigDecimal)tmp.get("cnt");
				count = cnt.intValue();
				if(count > 0){
					String ignStr = (String)tmp.get("nm");
					//ignStr = ignStr.toUpperCase();
					if(!ign.equals(ignStr)){
						resultValue = ignStr;
						//resultValue = resultValue.toLowerCase();
						if(tye != null && !"code".equals(tye)){
							StringBuffer sb = new StringBuffer();
							sb.append("nRgstBy");
							sb.append(resultValue);
							sb.append(".msg");
							resultValue = sb.toString();
						}
						break;
					}
				}
			}
		}
		return resultValue;
	}   
	
	/**
	 * Biz-method for Check Citizen Revocation Status. <br>
	 *
	 * @param String
	 * @return String
	 * @exception Exception
	 */
	public String searchRsdtRvctgStus(String rsdtNo , String tye) throws Exception { 
		EgovMap result = dao.selectRsdtRvctgStus(rsdtNo);
		String resultValue = "";
		String stus = "";
		if(null != result){
			String rsdtStusCd = NidStringUtil.nullConvert(result.get("rsdtStusCd")); 
			String isNotApl = NidStringUtil.nullConvert(result.get("isNotApl"));
			
			if("1".equals(rsdtStusCd)){
				if("N".equals(isNotApl)){
					stus = "rvctgApl";
				}
			}else{
				stus = "rvctg";
			}
			
		}else{
			stus = "nExist";
		}
		
		if("code".equals(tye)){
			resultValue = stus;
		}else{
			if("rvctgApl".equals(stus)){
				resultValue = "nRgstByCcltApl.msg";
			}else if("rvctg".equals(stus)){
				resultValue = "nCtznHst.msg";
			}else if("nExist".equals(stus)){
				resultValue = "nRgstEnid.msg";
			}
		}
		
		return resultValue;
	}
	/**
	 * Biz-method for Check card issuing status <br>
	 *
	 * @param String 
	 * @return int
	 * @exception Exception
	 */
	public int searchRsdtCrdIsuStus(String rsdtNo) throws Exception { 
	
		int resultCnt = dao.selectRsdtCrdIsuStus(rsdtNo);
		
		return resultCnt;
	}
	
	/**
	 * Biz-method for  byte array to hex string. <br>
	 *
	 * @param byte[]
	 * @return String
	 * @exception Exception
	 */
   	@SuppressWarnings("unused")
	private String byteArrToHexStr(byte[] arr){
   		StringBuffer hexStr = new StringBuffer();
		if(arr != null && arr.length > 0){
			for( int x=0;x<arr.length;x++ ){
				String tmp = Integer.toHexString( 0xff & arr[x] );
				String hexaDecimal= (tmp != null && tmp.length() < 2) ? "0"+tmp : tmp;
				hexStr.append( hexaDecimal );
			}
		}
		return hexStr.toString().toUpperCase();
	}
   	
   	/**
	 * Biz-method for  byte array to hex string. <br>
	 *
	 * @param String
	 * @return byte[]
	 * @exception Exception
	 */
   	@SuppressWarnings("unused")
   	private byte [] hexStrToByteArr(String aop){
   		byte[] buffer = new byte[aop.length()/2];
	    for( int i=0;i<buffer.length;i++ ){
	         buffer[i] = (byte)Integer.parseInt(aop.substring(2*i, 2*i+2), 16);
	    }
		return buffer;
	}
   	
   	
   	
   	/**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public int searchListSpusApp(RsdtInfrVO vo) throws Exception {
   		return dao.selectSpusListApp(vo);
	}
   	
    /**
	 * Biz-method for retrieving of Citizen's detail information. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return RsdtInfrVO object of Citizen's detail information
	 * @exception Exception
	 */
	public RsdtInfrVO searchRsdtInfrDtlView(RsdtInfrVO vo) throws Exception {
		String bioInfr = null;
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());// Setting Use Language Code
		

		RsdtInfrVO rsdtInfo = dao.selectRsdtInfrDtlView(vo);
		log.debug("========================================================");
		log.debug("rsdtInfo.getBioKey() : "+ rsdtInfo.getBioKey());
		log.debug("rsdtInfo.getRsdtNo() : "+rsdtInfo.getRsdtNo());
		log.debug("========================================================");		
		int cnt = dao.selectBmBioTb(rsdtInfo.getBioKey(), rsdtInfo.getRsdtNo());
		if(cnt > 0){
			bioInfr = bioIfService.searchBioSocketIf(rsdtInfo.getBioKey(), rsdtInfo.getRsdtNo(),"N", user.getUserId(),null);
			rsdtInfo.setBioInfr(bioInfr);
			rsdtInfo.setBioRgstYn("Y");
		}			
		
   		return rsdtInfo;
	}
	
	
   	
   	/**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param EgovMap, String
	 * @return String
	 * @exception Exception
	 */
	@SuppressWarnings("unused")
	private String getEgovMapValue(EgovMap obj, String value){
		String result = "";
		if(obj != null && !obj.isEmpty() && value != null){
			Object object = obj.get(value);
			if(object != null){
				if(object instanceof BigDecimal){
					BigDecimal big = (BigDecimal)object;
					int bigInt = big.intValue();
					result = String.valueOf(bigInt);
				}else if(object instanceof String){
					result = (String)object;
				}
			}
		}
		
		return result;
	}
	

   	/**
	 * Biz-method for retrieving  information of bio registration. <br>
	 *
	 * @param vo Input item for retrieving information of bio registration.
	 * @return RsdtInfrVO
	 * @exception Exception
	 */
   	public RsdtInfrVO searchRsdtBioRgstDtlStus(String bioKey) throws Exception {
        return dao.selectRsdtBioRgstDtlStus(bioKey);
	} 
   	
   	
   	
   	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
   	 * @return List Retrieve list of program
   	 * @exception Exception
   	 */
   	public List<EgovMap> searchListFmlyInfrPop(RsdtInfrVO vo) throws Exception {
   		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
   		vo.setUseLangCd(user.getUseLangCd());
    	return dao.selectListFmlyInfrPop(vo);
   	}
   	
   	/**
   	 * Biz-method for retrieving list of program. <br>
   	 *
   	 * @param String, String
   	 * @return String
   	 * @exception Exception
   	 */
   	public String getXmlData(String xml, String tag) throws Exception{
    	String result = "";
    	if(xml != null && tag != null && xml.length() > 0 && tag.length() > 0){
        	result = xml;
        	int str = result.indexOf("<"+tag);
        	int end = result.lastIndexOf("</"+tag+">");
        	result = result.substring(str, end+3+tag.length());
    	}
    	return result;
    }
   	
   	/**
   	 * Biz-method for update Digital Signature. <br>
   	 *
   	 * @param String, String
   	 * @return void
   	 * @exception Exception
   	 */
   	public void updateDigitalSgnt(String rsdtSeqNo, String sgnt , String bsnCd) throws Exception{

    	int udtResult = 0;
    	RsdtInfrVO vos = new RsdtInfrVO();
		vos.setRsdtSeqNo(rsdtSeqNo);
		vos.setSgnt(sgnt);
		
		String resultSgnt = getXmlData(vos.getSgnt(), "Signature");
   		if(resultSgnt != null && resultSgnt.length() > 0){
	   		vos.setSgnt(resultSgnt);
	   		udtResult = dao.updateRsdtInfrSgnt(vos);
	   		
	   		if(udtResult != 1 ){
	   			throw processException("bsnEcpt.msg");
   			}
   		}else{
   			throw processException("bsnEcpt.msg");
   		}
   			
   		EgovMap em = dao.selectRsdtInfrDat(vos.getRsdtSeqNo());
   		String hash = "";
   		if(em != null && !em.isEmpty()){
   			hash = dao.selectRsdtInfrHashDat(em, bsnCd);
   			String reg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>";
			if(hash != null && hash.indexOf(reg) == -1){
				String admTel = nidMessageSource.getMessage("admTelNo");
				throw processException("pki.websrvcEror.msg", new String[]{hash, admTel});
			}
   			resultSgnt = getXmlData(hash, "ds:Signature");
   		}else{
   			throw processException("bsnEcpt.msg");
   		}
   		
   		if(resultSgnt != null && resultSgnt.length() > 0){
   			udtResult = 0;
   			vos.setSysSgnt(resultSgnt);
   			udtResult = dao.updateRsdtInfrSysSgnt(vos);
   			
   			if(udtResult != 1 ){
	   			throw processException("bsnEcpt.msg");
   			}
   			
   		}else{
   			String admTel = nidMessageSource.getMessage("admTelNo");
   			String none = nidMessageSource.getMessage("none");
			throw processException("pki.websrvcEror.msg", new String[]{none, admTel});
   		}
    }
   	
   	/**
   	 * Biz-method for retrieving count of program. <br>
   	 *
   	 * @param String
   	 * @return int
   	 * @exception Exception
   	 */
   	public int searchPkiCrtIsuceCn(String rsdtSeqNo) throws Exception{
    	int result = 0;
    	result = dao.selectPkiCrtIsuceCn(rsdtSeqNo);
    	return result;
    }
   	
   	
    /**
   	 * Biz-method for retrieving list of Family Members. <br>
   	 *
   	 * @param vo Input item for retrieving list of Family Members(RsdtInfrVO).
   	 * @return List Retrieve list of Family Members
   	 * @exception Exception
   	 */
   	public List<RsdtInfrVO> searchListFmlyMber(RsdtInfrVO vo) throws Exception {
      		return dao.selectListFmlyMber(vo);
   	}

   	/**
	 * Biz-method for retrieving total count list of Family Members. <br>
	 *
	 * @param vo Input item for retrieving list of Family Members(RsdtInfrVO).
	 * @return int Total Count of Family Members List
	 * @exception Exception
	 */
   	public int searchListFmlyMberTotCn(RsdtInfrVO vo) throws Exception {
        return dao.selectListFmlyMberTotCn(vo);
	}
   	
   	/**
	 * Biz-method for retrieving  Age Gap. <br>
	 *
	 * @param vo Input item for retrieving Age Gap.
	 * @return RsdtInfrVO
	 * @exception Exception
	 */
   	public RsdtInfrVO searchAgGap(RsdtInfrVO vo) throws Exception {
        return dao.selectAgGap(vo);
	}   	
   	
   	/**
	 * Biz-method for retrieving age gap. <br>
	 *
	 * @param vo Input item for retrieving age gap(RsdtInfrVO).
	 * @return String age gap
	 * @exception Exception
	 */
   	public String searchChkAgGap(RsdtInfrVO vo) throws Exception {
        return dao.selectChkAgGap(vo);
	}
   	
   	/**
	 * Biz-method for retrieving validation of relationship. <br>
	 *
	 * @param vo Input item for retrieving validation of relationship(RsdtInfrVO).
	 * @return String validation value
	 * @exception Exception
	 */
   	public String searchChkRl(RsdtInfrVO vo) throws Exception {
   		String flag ="N";
   		//same family book
   		String sameFmlyBokYn = dao.selectSameFmlyBokYn(vo);
   		
   		if("Y".equals(sameFmlyBokYn)){
   			//get family head gender code
   			String fmlYHadGdrCd = dao.selectFmlYHadGdrCd(vo);   			
   			vo.setFmlYHadGdrCd(fmlYHadGdrCd);
   			
   			// value of relationship validation
   			flag = dao.selectChkRl(vo);
   		} else {   			
   			flag ="Y";
   		}
   		
        return flag;
	} 
   	
   	/**
	 * Biz-method for retrieving validation of relationship. <br>
	 *
	 * @param vo Input item for retrieving validation of relationship(RsdtInfrVO).
	 * @return String validation value
	 * @exception Exception
	 */
   	public RsdtInfrVO searchNmLink(RsdtInfrVO vo) throws Exception {

   		RsdtInfrVO result = new RsdtInfrVO();
   		
		String fmlYHadGdrCd = dao.selectFmlYHadGdrCd(vo);   			
		vo.setFmlYHadGdrCd(fmlYHadGdrCd);
			
   		String mdtrRlCd = dao.selectMdtrRlCd(vo);
	
   		if(mdtrRlCd == null || "".equals(mdtrRlCd)){  			
   			result.setFlag("Y");
   			result.setRsdtSeqNo("");
   			result.setRlCd("");
   		} else {  			
   			vo.setMdtrRlCd(mdtrRlCd);
   			
   	   		String mdtrRlCdYn = dao.selectMdtrRlCdYn(vo);
   	   		
   	   		if("Y".equals(mdtrRlCdYn)){
				result.setFlag("N");
				result.setRsdtSeqNo("");
				result.setRlCd("");
				
   	   			List<RsdtInfrVO> mdtrRsdtList = dao.selectListMdtrRsdt(vo);
   	   			
   	   		    RsdtInfrVO rowDat = new RsdtInfrVO();
   	   		    String fullNm = "";
   	   		    
   	   			for(int i=0; i<mdtrRsdtList.size();i++){
   	   				rowDat = mdtrRsdtList.get(i);
   	   				log.debug("============================================================");
   	   				log.debug("screen full name : "  +vo.getFullNm());
   	   				log.debug("============================================================");   	   				
   	   				fullNm = NidStringUtil.makeOneSpace(rowDat.getFullNm());
   	   				log.debug("============================================================");
   	   				log.debug("db name - space delete: "  + fullNm);
   	   				log.debug("============================================================");
   	   				
   	   				if( (vo.getFullNm()).equals(fullNm)){
   	   					result.setFlag("Y");
   	   					result.setRsdtSeqNo(rowDat.getRsdtSeqNo());
   	   					result.setRlCd(rowDat.getRlCd());
   	   					break;
   	   				}
   	   			}
   	   			
   	   		} else {
   	   			result.setFlag("Y");
   	   			result.setRsdtSeqNo("");
   	   			result.setRlCd("");
   	   		}   			
   		}

        return result;
	}   
   	
   	/**
	 * Biz-method for retrieving member mapped  with me. <br>
	 *
	 * @param vo Input item for retrieving member mapped  with me.(RsdtInfrVO).
	 * @return RsdtInfrVO 
	 * @exception Exception
	 */
   	public List<RsdtInfrVO> searchListRlForMe(RsdtInfrVO vo) throws Exception {

   		List<RsdtInfrVO> forMeList = null;
   		
		String fmlYHadGdrCd = dao.selectFmlYHadGdrCd(vo);   			
		vo.setFmlYHadGdrCd(fmlYHadGdrCd);
		
		RsdtInfrVO rlCnt = dao.selectRlCdCnt(vo);
		
		if("0".equals(rlCnt.getFthrRlCdCnt())){
			vo.setFthrModeYn("N");
		} else{
			vo.setFthrModeYn("Y");
		}
			
		if("0".equals(rlCnt.getMthrRlCdCnt())){
			vo.setMthrModeYn("N");
		} else{
			vo.setMthrModeYn("Y");
		}
		
		if("0".equals(rlCnt.getGfthrRlCdCnt())){
			vo.setGfthrModeYn("N");
		} else{
			vo.setGfthrModeYn("Y");
		}
		
		if("0".equals(rlCnt.getSpusRlCdCnt())){
			vo.setSpusModeYn("N");
		} else{
			vo.setSpusModeYn("Y");
		}
		
		if("Y".equals(vo.getFthrModeYn()) || "Y".equals(vo.getMthrModeYn()) || "Y".equals(vo.getGfthrModeYn()) || "Y".equals(vo.getSpusModeYn())){
			forMeList = dao.selectListRlForMe(vo);
		}
		
        return forMeList;
	}    	
   	/**
	 * Biz-method for retrieving change membere. <br>
	 *
	 * @param vo Input item for retrieving change member.(RsdtInfrVO).
	 * @return RsdtInfrVO 
	 * @exception Exception
	 */
   	public RsdtInfrVO searchChngMber(RsdtInfrVO vo) throws Exception {
        return dao.selectChngMber(vo);
	}   	
   	
   	
   	
   	/**
	 * Biz-method for retrieving list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return List Retrieve list of program
	 * @exception Exception
	 */
	public String searchGetCtznRgstYn(RsdtInfrVO vo) throws Exception {
   		return dao.selectGetCtznRgstYn(vo);
	}
	
	
	
}