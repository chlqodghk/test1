package afnid.rm.rsdt.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Repository;

import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.rsdt.service.RsdtInfrVO;

import com.ibatis.sqlmap.client.SqlMapClient;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.dataaccess.util.EgovMap;



/** 
 * This class is Database Access Object of common
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2014.12.08
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2014.12.08  		BH Choi         							Create
 *
 * </pre>
 */
@Repository("rsdtMberInfrDAO")
public class RsdtMberInfrDAO extends EgovAbstractDAO {
	
	protected Log log = LogFactory.getLog(this.getClass());
	
	@Resource(name = "sqlMapClientRm")
	 public void setSuperSqlMapClient(SqlMapClient sqlMapClient) {
		 super.setSuperSqlMapClient(sqlMapClient);
	 }
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return EgovMap
	 * @exception Exception
	 */
	public EgovMap selectRsdtFmlyRela(RsdtInfrVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		return (EgovMap)selectByPk("rsdtMberInfrDAO.selectRsdtFmlyRela", vo);
	}

	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return String
	 * @exception Exception
	 */
	public String insertRsdtInfr(RsdtInfrVO vo) {
    	String result = null;
    	synchronized(this){
    		result = (String)insert("rsdtMberInfrDAO.insertRsdtInfr", vo);
    	}
        return result;
    }
	
	
	/**
	 * DAO-method for registering information of new OthrNat language. <br>
	 *
	 * @param RsdtInfrVO
	 * @return void
	 * @exception Exception
	 */
	public void insertOthrNatLang(RsdtInfrVO vo) throws Exception{
		insert("rsdtMberInfrDAO.insertOthrNatLang", vo);
	}
	/**
	 * DAO-method for registering information of new Frgn language. <br>
	 *
	 * @param RsdtInfrVO
	 * @return void
	 * @exception Exception
	 */
	public void insertFrgnLang(RsdtInfrVO vo) throws Exception{
		insert("rsdtMberInfrDAO.insertFrgnLang", vo);
	}
	
	/**
	 * DAO-method for delete information of  OthrNat language. <br>
	 *
	 * @param RsdtInfrVO
	 * @return void
	 * @exception Exception
	 */
	public void deleteOthrNatLang(RsdtInfrVO vo) throws Exception{
		delete("rsdtMberInfrDAO.deleteOthrNatLang", vo);
	}
	/**
	 * DAO-method for delete information of  Frgn language. <br>
	 *
	 * @param RsdtInfrVO
	 * @return void
	 * @exception Exception
	 */
	public void deleteFrgnLang(RsdtInfrVO vo) throws Exception{
		delete("rsdtMberInfrDAO.deleteFrgnLang", vo);
	}
	
	
	/**
	 * DAO-method for registering information. <br>
	 *
	 * @param RsdtInfrVO
	 * @return void
	 * @exception Exception
	 */
	public void insertImBioTb(RsdtInfrVO vo) throws Exception{
		insert("rsdtMberInfrDAO.insertImBioTb", vo);
	}
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return RsdtInfrVO
	 * @exception Exception
	 *
	 */
	public RsdtInfrVO selectRsdtInfrView(RsdtInfrVO vo) throws Exception{
		return (RsdtInfrVO)selectByPk("rsdtMberInfrDAO.selectRsdtInfoView", vo);
	}

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListOthrNatLangInfr(RsdtInfrVO vo) throws Exception{
		return list("rsdtMberInfrDAO.selectOthrNatLangInfoList", vo);
	}

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListFrgnLangInfr(RsdtInfrVO vo) throws Exception{
		return list("rsdtMberInfrDAO.selectFrgnLangInfoList", vo);
	}
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRsdtMberFmlyInfr(RsdtInfrVO vo) throws Exception{
		return list("rsdtMberInfrDAO.selectRsdtMberFmlyInfr", vo);
	}
	
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListRsdtMberInfrPop(RsdtInfrVO vo) throws Exception{
		return list("rsdtMberInfrDAO.selectListRsdtMberInfrPop", vo);		
	}
	/**
	 * DAO-method for retrieving total count list of program. <br>
	 * 
	 * @param RsdtInfrVO
	 * @return int
	 * @exception Exception
	 */
    public int selectListRsdtMberInfrPopTotCnt(RsdtInfrVO vo) {
        return (Integer)selectByPk("rsdtMberInfrDAO.selectListRsdtMberInfrPopTotCnt", vo);
    }
	
    
    /**
	 * DAO-method for retrieving of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return RsdtInfrVO
	 * @exception Exception
	 *
	 */
	public RsdtInfrVO selectRsdtInfoRcpt(RsdtInfrVO vo) throws Exception{
		return (RsdtInfrVO)selectByPk("rsdtMberInfrDAO.selectRsdtInfoReceipt", vo);
	}
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListOthrNatLangInfrForRcpt(RsdtInfrVO vo) throws Exception{
		return list("rsdtMberInfrDAO.selectOthrNatLangInfoListForRcpt", vo);
	}

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListFrgnLangInfrForRcpt(RsdtInfrVO vo) throws Exception{
		return list("rsdtMberInfrDAO.selectFrgnLangInfoListForRcpt", vo);
	}
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return int
	 * @exception Exception
	 */
	public int updateRsdtInfr(RsdtInfrVO vo) {
    	int result = update("rsdtMberInfrDAO.updateRsdtInfr", vo);
        return result;
    }
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return EgovMap
	 * @exception Exception
	 */
	public EgovMap selectRsdtMberBioAgeChk(RsdtInfrVO vo) throws Exception{
		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		vo.setUseLangCd(user.getUseLangCd());
		return (EgovMap)selectByPk("rsdtMberInfrDAO.selectRsdtMberBioAgeChk", vo);
	}
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListRsdtMberInfrAprv(RsdtInfrVO vo) throws Exception{
		vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword3(NidStringUtil.toNumberConvet(vo.getSearchKeyword3(), "g"));
		vo.setSearchKeyword4(NidStringUtil.toNumberConvet(vo.getSearchKeyword4(), "g"));
		return list("rsdtMberInfrDAO.selectListRsdtMberInfrAprv", vo);
	}	

	/**
	 * DAO-method for retrieving total count list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return int
	 * @exception Exception
	 */
    public int selectListRsdtMberInfrAprvTotCn(RsdtInfrVO vo) {
    	vo.setSearchKeyword(NidStringUtil.toNumberConvet(vo.getSearchKeyword(), "g"));
		vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword3(NidStringUtil.toNumberConvet(vo.getSearchKeyword3(), "g"));
		vo.setSearchKeyword4(NidStringUtil.toNumberConvet(vo.getSearchKeyword4(), "g"));
        return (Integer)selectByPk("rsdtMberInfrDAO.selectListRsdtMberInfrAprvTotCn", vo);
    }
    
    
    
    
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return RsdtInfrVO
	 * @exception Exception
	 *
	 */
	public RsdtInfrVO selectRsdtInfrAprvView(RsdtInfrVO vo) throws Exception{
		return (RsdtInfrVO)selectByPk("rsdtMberInfrDAO.selectRsdtInfrAprvView", vo);
	}

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListOthrNatLangInfrAprv(RsdtInfrVO vo) throws Exception{
		return list("rsdtMberInfrDAO.selectListOthrNatLangInfrAprv", vo);
	}

	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return List
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<RsdtInfrVO> selectListFrgnLangInfrAprv(RsdtInfrVO vo) throws Exception{
		return list("rsdtMberInfrDAO.selectListFrgnLangInfrAprv", vo);
	}
	
	
	
	/**
	 * DAO-method for retrieving total count list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return int
	 * @exception Exception
	 */
    public int selectRsdtMberInfrApvrState(RsdtInfrVO vo) {
        return (Integer)selectByPk("rsdtMberInfrDAO.selectRsdtMberInfrApvrState", vo);
    }
    
    
    /**
	 * DAO-method for retrieving total count list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return String
	 * @exception Exception
	 */
    public String selectRsdtMberRsdtNo(RsdtInfrVO vo) {
        return (String)selectByPk("rsdtMberInfrDAO.selectRsdtMberRsdtNo", vo);
    }
    
    
    
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return int
	 * @exception Exception
	 */
	public int updateVerification(RsdtInfrVO vo) {
    	int result = update("rsdtMberInfrDAO.updateVerification", vo);
        return result;
    }
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListRsdtInfrPop(RsdtInfrVO vo) throws Exception{
		vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword7(NidStringUtil.toNumberConvet(vo.getSearchKeyword7(), "g"));
		vo.setSearchKeyword8(NidStringUtil.toNumberConvet(vo.getSearchKeyword8(), "g"));
		vo.setSearchKeyword9(NidStringUtil.toNumberConvet(vo.getSearchKeyword9(), "g"));
		return list("rsdtMberInfrDAO.selectRsdtInfoLstPop", vo);
	}

	/**
	 * DAO-method for retrieving total count list of program. <br>
	 *
	 * @param vo Input item for retrieving list of program(RsdtInfrVO).
	 * @return int Total Count of Program List
	 * @exception Exception
	 */
    public int selectListRsdtInfrPopTotCn(RsdtInfrVO vo) {
    	vo.setSearchKeyword2(NidStringUtil.toNumberConvet(vo.getSearchKeyword2(), "g"));
		vo.setSearchKeyword7(NidStringUtil.toNumberConvet(vo.getSearchKeyword7(), "g"));
		vo.setSearchKeyword8(NidStringUtil.toNumberConvet(vo.getSearchKeyword8(), "g"));
		vo.setSearchKeyword9(NidStringUtil.toNumberConvet(vo.getSearchKeyword9(), "g"));
        return (Integer)selectByPk("rsdtMberInfrDAO.selectRsdtInfoLstPopTotCnt", vo);
    }
    
    
    
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRsdtFmlyBokLstPop(RsdtInfrVO vo) throws Exception{
		return list("rsdtMberInfrDAO.selectRsdtFmlyBokLstPop", vo);
	}
	
	
	
	/**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return int
	 * @exception Exception
	 */
	public int updateRsdtInfrExi(RsdtInfrVO vo) {
    	int result = update("rsdtMberInfrDAO.updateRsdtInfrExi", vo);
        return result;
    }
	
	
	
	/**
	 * DAO-method for retrieving total count list of program. <br>
	 *
	 * @param RsdtInfrVO
	 * @return String
	 * @exception Exception
	 */
    public String selectFmlyRsdtMberSelfGdr(RsdtInfrVO vo) {
        return (String)selectByPk("rsdtMberInfrDAO.selectFmlyRsdtMberSelfGdr", vo);
    }
    
    
    
    /**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectFmlyMberRsdtInfrList(EgovMap vo) throws Exception{
		return list("rsdtMberInfrDAO.selectFmlyMberRsdtInfrList", vo);
	}
	
	
	/**
	 * DAO-method for retrieving bio dup citizen list <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return RsdtInfrVO Retrieve of program
	 * @exception Exception
	 *
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectListFmlyInfrPop(RsdtInfrVO vo) throws Exception{
		return list("rsdtMberInfrDAO.selectListFmlyInfrPop", vo);
	}
	
	 /**
	 * DAO-method for retrieving list Information of program. <br>
	 *
	 * @param vo Input item for retrieving detail information of program(RsdtInfrVO).
	 * @return List Retrieve list information of program
	 * @exception Exception
	 */
	@SuppressWarnings("unchecked")
	public List<EgovMap> selectRsdtInfrMaleRlCn(EgovMap vo) throws Exception{
		return list("rsdtMberInfrDAO.selectRsdtInfrMaleRlCn", vo);
	}
	
	/**
	 * DAO-method for registering information of new work . <br>
	 *
	 * @param RsdtInfrVO
	 * @return void
	 * @exception Exception
	 */
	public void insertRmRgstWrkTb(RsdtInfrVO vo) throws Exception{
		insert("rsdtMberInfrDAO.insertRmRgstWrkTb", vo);
	}
	
}
