package afnid.rm.rsdt.service;

import java.util.List;




/** 
 * This service interface is biz-class of monitor. <br>
 * 
 * @author Afghanistan National ID Card System Application Team BH Choi
 * @since 2013.11.03
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers									Revisions
 *   2013.11.03  		moon soo kim 		                   Create
 *
 * </pre>
 */
public interface RsdtMntService {

	
	/**
	 * retrieving be or not existence of citizen.<br>
	 * @param vo Input item for retrieving be or not existence of citizen.(RsdtMntVO)
	 * @return int 
	 * @exception Exception
	 */
	public int searchRsdtInfrCn(RsdtMntVO vo) throws Exception;	
	
	
	/**
	 * retrieving of citizen card traceability information . <br>	 
	 *
	 * @param vo Input item for retrieving of citizen card traceability information(RsdtMntVO).
	 * @return List Retrieve of citizen card traceability information
	 * @exception Exception
	 */
	public RsdtMntVO searchRsdtPrcssStusInfr(RsdtMntVO vo) throws Exception;
	
	/**
	 * retrieving of citizen card traceability information(history). <br>	 
	 *
	 * @param vo Input item for retrieving of citizen card traceability information(history).(RsdtMntVO).
	 * @return List Retrieve of citizen card traceability information(history).
	 * @exception Exception
	 */
	public List<RsdtMntVO> searchListRsdtPrcssHst(RsdtMntVO vo) throws Exception;	
	
	/**
	 * retrieving be or not existence of citizen(bio duplication).<br>
	 * @param vo Input item for retrieving be or not existence of citizen(bio duplication).(RsdtMntVO)
	 * @return int 
	 * @exception Exception
	 */
	public int searchRsdtBiioDupCn(RsdtMntVO vo) throws Exception;		
	
}
