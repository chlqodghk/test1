package afnid.rm.rsdt.web;

/* java API */
import java.io.StringWriter;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.bioif.service.BioIfInfrService;
import afnid.rm.fmly.service.FmlyInfrService;
import afnid.rm.rsdt.service.RsdtInfrVO;
import afnid.rm.rsdt.service.RsdtMberInfrService;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;



/** 
 * This Controller class processes request of resident-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Team BH CHOI
 * @since 2014.12.08
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2014.12.08  		BH CHOI          		                    Create
 *
 * </pre>
 */

@Controller
public class RsdtMberInfrController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdManagerService;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** NidCommonService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCommonService;
	
	/** NidProgrmManageService */
	@Resource(name = "rsdtMberInfrService")
    private RsdtMberInfrService service;
	
	@Resource(name = "lgService")
    private LgService lgService;
	
	@Resource(name = "bioIfInfrService")
    private BioIfInfrService bioIfService;
	
	@Resource(name = "fmlyInfoService")
	private FmlyInfrService fmlyInfrService;
    
	/**
     * Moved to Resident registration-screen of program. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtMberInfrIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/addRsdtMberInfrView.do")
    public String addRsdtMberInfrView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> bldTyeCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("bldTyeCd", bldTyeCd); 
    		cmCmmCd.setGrpCd("12"); // Setting Group Code
    		List<CmCmmCdVO> mrrgCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("mrrgCd", mrrgCd); 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		List<CmCmmCdVO> etncityCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("etncityCd", etncityCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> fmlyLangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("fmlyLangCd", fmlyLangCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> nallangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("nallangCd", nallangCd);
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		List<CmCmmCdVO> rlgnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlgnCd", rlgnCd);
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		List<CmCmmCdVO> rlgnSect = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlgnSect", rlgnSect);
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		List<CmCmmCdVO> mltSrvcCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("mltSrvcCd", mltSrvcCd);	    		
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> eduYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("eduYnCd", eduYnCd);	    		
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> secdNltyYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("secdNltyYnCd", secdNltyYnCd);
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("nltyCd", nltyCd);
    		cmCmmCd.setGrpCd("8"); // Setting Group Code
    		List<CmCmmCdVO> frgnLang = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("frgnLang", frgnLang);
    		cmCmmCd.setGrpCd("64"); // Setting Group Code
    		List<CmCmmCdVO> rsdtTypCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rsdtTypCd", rsdtTypCd);
    		cmCmmCd.setGrpCd("5"); // Setting Group Code
    		List<CmCmmCdVO> eduCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("eduCd", eduCd);
    		cmCmmCd.setGrpCd("68"); 
    		List<CmCmmCdVO> dsbtCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);  
    		model.addAttribute("dsbtCd", dsbtCd);  
    		
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdManagerService.searchListCmmCd(cmCmmCd); 
    		model.addAttribute("rlCd", codeLst);
    		
    		model.addAttribute("useLangCd", user.getUseLangCd());
	        model.addAttribute("userId", user.getUserId());
	        
	        int frgnInt = propertiesService.getInt("frgnLangOthrLangRgstNo");
	        model.addAttribute("frgnLangOthrLangRgstNo", frgnInt);
	        
	        int kochiAdCd = propertiesService.getInt("kochiAdCd");
	        model.addAttribute("kochiAdCd", kochiAdCd);
	        
	        int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		
    		RsdtInfrVO vos = vo.init();
    		model.addAttribute("rsdtInfoVO", vos);
    		
    		List<EgovMap> rmRlLst = fmlyInfrService.searchRmRlTb(new String("")); 
	        model.addAttribute("rmRlLst", rmRlLst);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/rsdt/RsdtMberInfrIns";
    }
    
    
    
    /**
     * Moved to Resident registration-screen of program. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtMberInfrIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/addRsdtMberInfr.do")   
    public String addRsdtMberInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	String result = "/rm/rsdt/RsdtMberInfrIns";
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
    		vo.setUseLangCd(user.getUseLangCd());
    		vo.setUserNm(user.getNm());
    		
    		String crdIsuDueDd = vo.getCrdIsuDueDd();
    		
    		
    		vo.setCrdIsuDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
    		RsdtInfrVO rsdtInfoVO = service.searchRsdtInfrView(vo); 
    		if(rsdtInfoVO != null && rsdtInfoVO.getCtznRgstYn() != null && rsdtInfoVO.getTamLedrCfmYn() != null && ( "Y".equals(rsdtInfoVO.getCtznRgstYn()) || "Y".equals(rsdtInfoVO.getTamLedrCfmYn()) )){
	        	RsdtInfrVO vos = vo.init();
	    		model.addAttribute("rsdtInfoVO", vos);
	    		model.addAttribute("othrNatLangList", null);
	 	        model.addAttribute("frgnLangList", null);
	 	        model.addAttribute("resultMsg", nidMessageSource.getMessage("nAlIndiRgstError.msg"));
	 	        return "forward:/rm/rsdt/addRsdtMberInfrView.do";
	        }
	        
	        vo.setCrdIsuDueDd(crdIsuDueDd);
    		String rsdtSeqNo = service.addRsdtMberInfr(vo);
    		
    		result = "forward:/rm/rsdt/searchRsdtMberInfr.do?rsdtSeqNo="+rsdtSeqNo+"&searchKeyword2="+vo.getFmlyBokNo().substring(0, 4)+"&searchKeyword3="+vo.getFmlyBokNo().substring(4, 6)+"&searchKeyword4="+vo.getFmlyBokNo().substring(6, vo.getFmlyBokNo().length());
    		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return result;
    }
    
    
    
    
    /**
     * Moved to Resident registration-screen of program. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtMberInfrUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtMberInfrView.do")   
    public String searchRsdtMberInfrView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> bldTyeCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("bldTyeCd", bldTyeCd); 
    		cmCmmCd.setGrpCd("12"); // Setting Group Code
    		List<CmCmmCdVO> mrrgCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("mrrgCd", mrrgCd); 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		List<CmCmmCdVO> etncityCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("etncityCd", etncityCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> fmlyLangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("fmlyLangCd", fmlyLangCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> nallangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("nallangCd", nallangCd);
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		List<CmCmmCdVO> rlgnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlgnCd", rlgnCd);
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		List<CmCmmCdVO> rlgnSect = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlgnSect", rlgnSect);
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		List<CmCmmCdVO> mltSrvcCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("mltSrvcCd", mltSrvcCd);	    		
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> eduYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("eduYnCd", eduYnCd);	    		
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> secdNltyYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("secdNltyYnCd", secdNltyYnCd);
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("nltyCd", nltyCd);
    		cmCmmCd.setGrpCd("8"); // Setting Group Code
    		List<CmCmmCdVO> frgnLang = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("frgnLang", frgnLang);
    		cmCmmCd.setGrpCd("64"); // Setting Group Code
    		List<CmCmmCdVO> rsdtTypCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rsdtTypCd", rsdtTypCd);
    		cmCmmCd.setGrpCd("5"); // Setting Group Code
    		List<CmCmmCdVO> eduCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("eduCd", eduCd);
    		cmCmmCd.setGrpCd("68"); 
    		List<CmCmmCdVO> dsbtCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);  
    		model.addAttribute("dsbtCd", dsbtCd);  
    		
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdManagerService.searchListCmmCd(cmCmmCd); 
    		model.addAttribute("rlCd", codeLst);
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		model.addAttribute("useLangCd", user.getUseLangCd());
	        model.addAttribute("userId", user.getUserId());
	        
	        int frgnInt = propertiesService.getInt("frgnLangOthrLangRgstNo");
	        model.addAttribute("frgnLangOthrLangRgstNo", frgnInt);
	        
	        int kochiAdCd = propertiesService.getInt("kochiAdCd");
	        model.addAttribute("kochiAdCd", kochiAdCd);
	        
	        int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		
    		RsdtInfrVO vos = vo.init();
    		model.addAttribute("rsdtInfoVO", vos);
    		
    		List<EgovMap> rmRlLst = fmlyInfrService.searchRmRlTb(new String("")); 
	        model.addAttribute("rmRlLst", rmRlLst);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/rsdt/RsdtMberInfrUdt";
    }
    
    
    
    /**
     * Moved to Resident registration-screen of program. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtMberInfrUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtMberInfr.do")   
    public String searchRsdtMberInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> bldTyeCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("bldTyeCd", bldTyeCd); 
    		cmCmmCd.setGrpCd("12"); // Setting Group Code
    		List<CmCmmCdVO> mrrgCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("mrrgCd", mrrgCd); 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		List<CmCmmCdVO> etncityCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("etncityCd", etncityCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> fmlyLangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("fmlyLangCd", fmlyLangCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> nallangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("nallangCd", nallangCd);
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		List<CmCmmCdVO> rlgnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlgnCd", rlgnCd);
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		List<CmCmmCdVO> rlgnSect = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlgnSect", rlgnSect);
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		List<CmCmmCdVO> mltSrvcCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("mltSrvcCd", mltSrvcCd);	    		
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> eduYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("eduYnCd", eduYnCd);	    		
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> secdNltyYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("secdNltyYnCd", secdNltyYnCd);
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("nltyCd", nltyCd);
    		cmCmmCd.setGrpCd("8"); // Setting Group Code
    		List<CmCmmCdVO> frgnLang = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("frgnLang", frgnLang);
    		cmCmmCd.setGrpCd("64"); // Setting Group Code
    		List<CmCmmCdVO> rsdtTypCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rsdtTypCd", rsdtTypCd);
    		cmCmmCd.setGrpCd("5"); // Setting Group Code
    		List<CmCmmCdVO> eduCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("eduCd", eduCd);
    		cmCmmCd.setGrpCd("68"); 
    		List<CmCmmCdVO> dsbtCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);  
    		model.addAttribute("dsbtCd", dsbtCd);  
    		
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdManagerService.searchListCmmCd(cmCmmCd); 
    		model.addAttribute("rlCd", codeLst);
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		model.addAttribute("useLangCd", user.getUseLangCd());
	        model.addAttribute("userId", user.getUserId());
	        
	        int frgnInt = propertiesService.getInt("frgnLangOthrLangRgstNo");
	        model.addAttribute("frgnLangOthrLangRgstNo", frgnInt);
	        
	        int kochiAdCd = propertiesService.getInt("kochiAdCd");
	        model.addAttribute("kochiAdCd", kochiAdCd);
	        
	        int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		
    		
    		
    		String rsdtSeqNoTmp = vo.getRsdtSeqNo();
    		if(rsdtSeqNoTmp != null && !"".equals(rsdtSeqNoTmp)){
    			String [] arr = rsdtSeqNoTmp.split(",");
    			if(arr != null && arr.length > 0){
    				vo.setRsdtSeqNo(arr[0]);
    			}
    		}
    		
    		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
    		vo.setUseLangCd(user.getUseLangCd());
    		vo.setUserNm(user.getNm());
    		vo.setCrdIsuDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
    		
    		if(vo.getRsdtSeqNo() != null && !"".equals(vo.getRsdtSeqNo())){
    			RsdtInfrVO rsdtInfoVO = service.searchRsdtInfrView(vo); 
		        List<RsdtInfrVO> othrNatLangList = service.searchListOthrNatLangInfr(vo);
		        List<RsdtInfrVO> frgnLangList = service.searchListFrgnLangInfr(vo);
		        model.addAttribute("rsdtInfoVO", rsdtInfoVO);
		        model.addAttribute("othrNatLangList", othrNatLangList);
		        model.addAttribute("frgnLangList", frgnLangList);
		        
		        if(comDefaultVO != null){
		        	if(comDefaultVO.getSearchKeyword2() == null || "".equals(comDefaultVO.getSearchKeyword2())){
		        		String fmlyBokNo = rsdtInfoVO.getFmlyBokNo();
		        		if(fmlyBokNo != null && fmlyBokNo.length() == 10){
		        			comDefaultVO.setSearchKeyword2(fmlyBokNo.substring(0, 4));
		        			comDefaultVO.setSearchKeyword3(fmlyBokNo.substring(4, 6));
		        			comDefaultVO.setSearchKeyword4(fmlyBokNo.substring(6, 10));
		        			model.addAttribute("searchVO", comDefaultVO);
		        		}
		        	}else{
		        		String fmlyBokNo = rsdtInfoVO.getFmlyBokNo();
		        		StringBuffer sb = new StringBuffer();
		        		sb.append(comDefaultVO.getSearchKeyword2()).append(comDefaultVO.getSearchKeyword3()).append(comDefaultVO.getSearchKeyword4());
		        		if(fmlyBokNo != null && !fmlyBokNo.equals(sb.toString())){
		        			comDefaultVO.setSearchKeyword2(fmlyBokNo.substring(0, 4));
		        			comDefaultVO.setSearchKeyword3(fmlyBokNo.substring(4, 6));
		        			comDefaultVO.setSearchKeyword4(fmlyBokNo.substring(6, 10));
		        			model.addAttribute("searchVO", comDefaultVO);
		        		}
		        	}
		        }
    		}else{
    			List<EgovMap> em = service.searchRsdtMberFmlyInfr(vo);
    			if(em != null && !em.isEmpty()){
    				if(em.size() > 1){
    					model.addAttribute("mberPopup", "mberPopup");
    					RsdtInfrVO vos = vo.init();
            			model.addAttribute("rsdtInfoVO", vos);
    				}else{
    					String rsdtSeqNo = NidStringUtil.nullConvert(em.get(0).get("rsdtSeqNo"));
    					vo.setRsdtSeqNo(rsdtSeqNo);
    					if(rsdtSeqNo != null && !"".equals(rsdtSeqNo)){
    						RsdtInfrVO rsdtInfoVO = service.searchRsdtInfrView(vo); 
    				        List<RsdtInfrVO> othrNatLangList = service.searchListOthrNatLangInfr(vo);
    				        List<RsdtInfrVO> frgnLangList = service.searchListFrgnLangInfr(vo);
    				        model.addAttribute("rsdtInfoVO", rsdtInfoVO);
    				        model.addAttribute("othrNatLangList", othrNatLangList);
    				        model.addAttribute("frgnLangList", frgnLangList);
    				        
    				        if(comDefaultVO != null){
    				        	if(comDefaultVO.getSearchKeyword2() == null || "".equals(comDefaultVO.getSearchKeyword2())){
    				        		String fmlyBokNo = rsdtInfoVO.getFmlyBokNo();
    				        		if(fmlyBokNo != null && fmlyBokNo.length() == 10){
    				        			comDefaultVO.setSearchKeyword2(fmlyBokNo.substring(0, 4));
    				        			comDefaultVO.setSearchKeyword3(fmlyBokNo.substring(4, 6));
    				        			comDefaultVO.setSearchKeyword4(fmlyBokNo.substring(6, 10));
    				        			model.addAttribute("searchVO", comDefaultVO);
    				        		}
    				        	}
    				        }
    				        
    					}
    				}
    			}else{
    				model.addAttribute("resultMsg", nidMessageSource.getMessage("nMberRgstHst.msg"));
    				RsdtInfrVO vos = vo.init();
        			model.addAttribute("rsdtInfoVO", vos);
    			}
    		}
    		
    		List<EgovMap> rmRlLst = fmlyInfrService.searchRmRlTb(new String("")); 
	        model.addAttribute("rmRlLst", rmRlLst);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/rsdt/RsdtMberInfrUdt";
    }
    
    
    /**
     * Bio for registration inquiry.<br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param rsdtInfoVO Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtFmlyRela.do")
    public void searchRsdtFmlyRela(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		EgovMap em = service.searchRsdtFmlyRela(vo);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		if(em != null && !em.isEmpty()){
    			Element eleInfo = doc.createElement("rsdt_info");
        		Element ele = null;
    			root.appendChild(eleInfo);
    			
    			ele = doc.createElement("givNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("givNm"))));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("surnm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("surnm")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("enGivNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("enGivNm")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("enSurnm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("enSurnm")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("pmntAdCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("pmntAdCd")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("pmntAdCdNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("pmntAdCdNm")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("pmntAdDtlCt");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("pmntAdDtlCt")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("curtAdCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdCd")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("curtAdDtlCt");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdDtlCt")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("curtAdCdNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdCdNm")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("curtAdDiv");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdDiv")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("curtAdNatCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdNatCd")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("curtAdDtlCtD");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdDtlCtD")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("curtAdDtlCtF");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("curtAdDtlCtF")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("nm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("nm")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("rsdtSeqNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("rsdtSeqNo")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("rsdtRgstTye");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("rsdtRgstTye")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("oldCrdNo1");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("oldCrdNo1")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("oldCrdNo2");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("oldCrdNo2")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("oldCrdNo3");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("oldCrdNo3")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("oldCrdNo4");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("oldCrdNo4")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("rsdtNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("rsdtNo")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("fthrNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fthrNm")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("fthrRsdtSeqNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fthrRsdtSeqNo")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("fthrRgstTye");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fthrRgstTye")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("fthrOldCrdNo1");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fthrOldCrdNo1"))));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("fthrOldCrdNo2");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fthrOldCrdNo2")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("fthrOldCrdNo3");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fthrOldCrdNo3")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("fthrOldCrdNo4");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fthrOldCrdNo4")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("fthrRsdtNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fthrRsdtNo")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("gfthrNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("gfthrNm")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("gfthrRsdtSeqNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("gfthrRsdtSeqNo")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("gfthrRgstTye");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("gfthrRgstTye")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("gfthrOldCrdNo1");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("gfthrOldCrdNo1")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("gfthrOldCrdNo2");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("gfthrOldCrdNo2")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("gfthrOldCrdNo3");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("gfthrOldCrdNo3")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("gfthrOldCrdNo4");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("gfthrOldCrdNo4")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("gfthrRsdtNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("gfthrRsdtNo")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("mthrCount");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("mthrCount")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("mthrNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("mthrNm")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("mthrRsdtSeqNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("mthrRsdtSeqNo")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("mthrRgstTye");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("mthrRgstTye")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("mthrOldCrdNo1");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("mthrOldCrdNo1")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("mthrOldCrdNo2");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("mthrOldCrdNo2")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("mthrOldCrdNo3");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("mthrOldCrdNo3")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("mthrOldCrdNo4");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("mthrOldCrdNo4")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("mthrRsdtNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("mthrRsdtNo")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("fstVefyIndiNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fstVefyIndiNm")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fstVefyTye");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fstVefyTye")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fstVefyRsdtNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fstVefyRsdtNo")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fstVefyOldCrdNo1");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fstVefyOldCrdNo1")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fstVefyOldCrdNo2");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fstVefyOldCrdNo2")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fstVefyOldCrdNo3");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fstVefyOldCrdNo3")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fstVefyOldCrdNo4");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fstVefyOldCrdNo4")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fstVefyFthrNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fstVefyFthrNm")) ));
    			eleInfo.appendChild(ele);
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fstVefyOldCrdIsucePlceCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fstVefyOldCrdIsucePlceCd")) ));
    			eleInfo.appendChild(ele);
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fstVefyOldCrdIsucePlceNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fstVefyOldCrdIsucePlceNm")) ));
    			eleInfo.appendChild(ele);
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("fstVefyOldCrdIsuceDd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fstVefyOldCrdIsuceDd")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("secdVefyIndiNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("secdVefyIndiNm")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("secdVefyTye");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("secdVefyTye")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("secdVefyRsdtNo");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("secdVefyRsdtNo")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("secdVefyOldCrdNo1");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("secdVefyOldCrdNo1")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("secdVefyOldCrdNo2");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("secdVefyOldCrdNo2")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("secdVefyOldCrdNo3");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("secdVefyOldCrdNo3")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("secdVefyOldCrdNo4");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("secdVefyOldCrdNo4")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("secdVefyFthrNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("secdVefyFthrNm")) ));
    			eleInfo.appendChild(ele);
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("secdVefyCrdIsucePlceCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("secdVefyCrdIsucePlceCd")) ));
    			eleInfo.appendChild(ele);
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("secdVefyCrdIsucePlceNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("secdVefyCrdIsucePlceNm")) ));
    			eleInfo.appendChild(ele);
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("secdVefyOldCrdIsuceDd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("secdVefyOldCrdIsuceDd")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("wtrRsdcCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("wtrRsdcCd")) ));
    			eleInfo.appendChild(ele);
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("wtrRsdcCdNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("wtrRsdcCdNm")) ));
    			eleInfo.appendChild(ele);
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("smrRsdcCd");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("smrRsdcCd")) ));
    			eleInfo.appendChild(ele);
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("smrRsdcCdNm");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("smrRsdcCdNm")) ));
    			eleInfo.appendChild(ele);
    			
    			ele = doc.createElement("fAge");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("fAge")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("gAge");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("gAge")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("mAge");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("mAge")) ));
    			eleInfo.appendChild(ele);
    			ele = doc.createElement("sAge");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("sAge")) ));
    			eleInfo.appendChild(ele);
    		}
    		
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }	
    
    
    
    
    
    
    /**
     * Moved to Resident registration-screen of program. <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: "/rm/rsdt/p_RsdtMberList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchListRsdtMberPop.do")
    public String searchListRsdtMberPop(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));
	    	//** pageing *//*
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());
			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
			vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
    		vo.setUseLangCd(user.getUseLangCd());
    		
	        List<EgovMap> lstProgram = service.searchListRsdtMberInfrPop(vo);
	        
	        if(lstProgram != null){
	        	String key = "bthDdJ";
		        for(int i = 0; i < lstProgram.size(); i++){
		        	EgovMap em = lstProgram.get(i);
		        	if(em != null && em.get(key) != null){
		        		String bthDdJ = (String)em.get(key);
		        		bthDdJ = NidStringUtil.toNumberConvet(bthDdJ, "j");
		        		em.remove(key);
		        		em.put(key, bthDdJ);
		        		key = "regDdJ";
		        		if(em != null && em.get(key) != null){
		        			bthDdJ = (String)em.get(key);
			        		bthDdJ = NidStringUtil.toNumberConvet(bthDdJ, "j");
			        		em.remove(key);
			        		em.put(key, bthDdJ);
		        		}
		        		lstProgram.set(i, em);
		        	}
		        	key = "bthDdJ";
		        }
	        }
	        model.addAttribute("lstProgram", lstProgram);
	        int totCnt = service.searchListRsdtMberInfrPopTotCnt(vo);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        model.addAttribute("useLangCd", user.getUseLangCd());
	        
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/rsdt/p_RsdtMberList";
    }
    
    
    
    /**
     * Receipt for Citizen Confirmation. <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "/rm/rsdt/p_RsdtMberInfrCfmRcpt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtMberInfrCfmRcpt.do")
    public String searchRsdtMberInfrCfmRcpt(
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo, 
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    		String orgnzClsCd = user.getOrgnzClsCd();
    		String orgnzCd = user.getOrgnzCd();
    		vo.setOfficerNo(orgnzClsCd+orgnzCd);	  
    		RsdtInfrVO rsdtInfoVO = service.searchRsdtInfrRcpt( vo); 
	        List<RsdtInfrVO> othrNatLangList = service.searchListOthrNatLangInfrForRcpt(vo);
	        List<RsdtInfrVO> frgnLangList = service.searchListFrgnLangInfrForRcpt(vo);
	        if(user != null && !user.getUseLangCd().equals("3")){
		        rsdtInfoVO.setOldCrdNo1(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo1(),"j"));
		        rsdtInfoVO.setOldCrdNo2(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo2(),"j"));
		        rsdtInfoVO.setOldCrdNo3(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo3(),"j"));
		        rsdtInfoVO.setOldCrdNo4(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo4(),"j"));
		        rsdtInfoVO.setFmlyMberNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyMberNo(),"j"));
		        rsdtInfoVO.setFmlyBokNoNum(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyBokNoNum(),"j"));
		        rsdtInfoVO.setRsdtNoDp(NidStringUtil.toNumberConvet(rsdtInfoVO.getRsdtNoDp(),"j"));
		        rsdtInfoVO.setCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getCrdIsuceDd(),"j"));
		        rsdtInfoVO.setCrdExpiryDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getCrdExpiryDd(),"j"));
		        rsdtInfoVO.setBthDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getBthDd(),"j"));
		        rsdtInfoVO.setFmlyMberMlNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyMberMlNo(),"j"));
		        rsdtInfoVO.setFmlyMberFemlNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyMberFemlNo(),"j"));
		        rsdtInfoVO.setFstVefyRsdtNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFstVefyRsdtNo(),"j"));
		        rsdtInfoVO.setSecdVefyRsdtNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getSecdVefyRsdtNo(),"j"));
		        rsdtInfoVO.setRsdtRgstDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getRsdtRgstDd(),"j"));
		        rsdtInfoVO.setCrdIsuDueDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getCrdIsuDueDd(),"j"));
		        rsdtInfoVO.setPrntDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getPrntDd(),"j"));
		        rsdtInfoVO.setOldCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdIsuceDd(),"j"));
		        rsdtInfoVO.setFstVefyOldCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getFstVefyOldCrdIsuceDd(),"j"));
		        rsdtInfoVO.setSecdVefyOldCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getSecdVefyOldCrdIsuceDd(),"j"));
		        rsdtInfoVO.setFstVefyOldCrdNo1(NidStringUtil.toNumberConvet(rsdtInfoVO.getFstVefyOldCrdNo1(),"j"));
		        rsdtInfoVO.setSecdVefyOldCrdNo1(NidStringUtil.toNumberConvet(rsdtInfoVO.getSecdVefyOldCrdNo1(),"j"));
	        }
	        model.addAttribute("useLangCd",user.getUseLangCd());
	        model.addAttribute("rsdtInfoVO", rsdtInfoVO);
	        model.addAttribute("othrNatLangList", othrNatLangList);
	        model.addAttribute("frgnLangList", frgnLangList);
	        model.addAttribute("userNm",user.getNm());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/rsdt/p_RsdtMberInfrCfmRcpt";
    }
    
    /**
     * Receipt to inquire. <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "/rm/rsdt/p_RsdtMberInfrRcpt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtMberInfrRcpt.do")
    public String searchRsdtMberInfrRcpt(
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo, 
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    		String orgnzClsCd = user.getOrgnzClsCd();
    		String orgnzCd = user.getOrgnzCd();
    		vo.setOfficerNo(orgnzClsCd+orgnzCd);
    		RsdtInfrVO rsdtInfoVO = service.searchRsdtInfrRcpt( vo);
	        List<RsdtInfrVO> othrNatLangList = service.searchListOthrNatLangInfrForRcpt(vo);
	        List<RsdtInfrVO> frgnLangList = service.searchListFrgnLangInfrForRcpt(vo);
	        if(user != null && !user.getUseLangCd().equals("3")){
		        rsdtInfoVO.setOldCrdNo1(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo1(), "j"));
		        rsdtInfoVO.setOldCrdNo2(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo2(), "j"));
		        rsdtInfoVO.setOldCrdNo3(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo3(), "j"));
		        rsdtInfoVO.setOldCrdNo4(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo4(),"j"));
		        rsdtInfoVO.setFmlyMberNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyMberNo(), "j"));
		        rsdtInfoVO.setFmlyBokNoNum(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyBokNoNum(), "j"));
		        rsdtInfoVO.setRsdtNoDp(NidStringUtil.toNumberConvet(rsdtInfoVO.getRsdtNoDp(), "j"));
		        rsdtInfoVO.setCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getCrdIsuceDd(), "j"));
		        rsdtInfoVO.setCrdExpiryDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getCrdExpiryDd(), "j"));
		        rsdtInfoVO.setBthDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getBthDd(), "j"));
		        rsdtInfoVO.setFmlyMberMlNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyMberMlNo(), "j"));
		        rsdtInfoVO.setFmlyMberFemlNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyMberFemlNo(), "j"));
		        rsdtInfoVO.setFstVefyRsdtNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFstVefyRsdtNo(), "j"));
		        rsdtInfoVO.setSecdVefyRsdtNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getSecdVefyRsdtNo(), "j"));
		        rsdtInfoVO.setRsdtRgstDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getRsdtRgstDd(), "j"));
		        rsdtInfoVO.setCrdIsuDueDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getCrdIsuDueDd(), "j"));
		        rsdtInfoVO.setOldCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdIsuceDd(),"j"));
		        rsdtInfoVO.setFstVefyOldCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getFstVefyOldCrdIsuceDd(),"j"));
		        rsdtInfoVO.setSecdVefyOldCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getSecdVefyOldCrdIsuceDd(),"j"));
		        rsdtInfoVO.setFstVefyOldCrdNo1(NidStringUtil.toNumberConvet(rsdtInfoVO.getFstVefyOldCrdNo1(),"j"));
		        rsdtInfoVO.setSecdVefyOldCrdNo1(NidStringUtil.toNumberConvet(rsdtInfoVO.getSecdVefyOldCrdNo1(),"j"));
	        }
	        model.addAttribute("useLangCd",user.getUseLangCd());	        
	        model.addAttribute("rsdtInfoVO", rsdtInfoVO);
	        model.addAttribute("othrNatLangList", othrNatLangList);
	        model.addAttribute("frgnLangList", frgnLangList);
	        model.addAttribute("userNm",user.getNm());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/rsdt/p_RsdtMberInfrRcpt";
    }
    
    
    
    
    /**
     * Moved to Resident registration-screen of program. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtMberInfrUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/modifyRsdtMberInfr.do")   
    public String modifyRsdtMberInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	String result = "forward:/rm/rsdt/searchRsdtMberInfr.do";
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
    		vo.setUseLangCd(user.getUseLangCd());
    		vo.setUserNm(user.getNm());
    		String crdIsuDueDd = vo.getCrdIsuDueDd();
    		vo.setCrdIsuDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
    		RsdtInfrVO rsdtInfoVOx = service.searchRsdtInfrView(vo); 
	        if(rsdtInfoVOx != null && rsdtInfoVOx.getCtznRgstYn() != null && rsdtInfoVOx.getTamLedrCfmYn() != null && ( ("Y".equals(rsdtInfoVOx.getCtznRgstYn()) && !vo.getRgstOrgnzCd().equals(rsdtInfoVOx.getRgstOrgnzCd()) ) || "Y".equals(rsdtInfoVOx.getTamLedrCfmYn() ) )){
	        	RsdtInfrVO vos = vo.init();
	    		model.addAttribute("rsdtInfoVO", vos);
	    		model.addAttribute("othrNatLangList", null);
	 	        model.addAttribute("frgnLangList", null);
	 	        model.addAttribute("resultMsg", nidMessageSource.getMessage("nAlIndiRgstError.msg"));
	 	       result = "forward:/rm/rsdt/searchRsdtMberInfr.do";
	        }else{
	        	vo.setCrdIsuDueDd(crdIsuDueDd);
	        	int resultCnt = service.modifyRsdtMberInfr(vo);
	    		if(resultCnt > 0){
	        		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
	    		}else{
	    			model.addAttribute("resultMsg", nidMessageSource.getMessage("udtFail.msg"));
	    		}
	        }
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return result;
    }
    
    
    
    
    
    
    
    /**
     * Bio for registration inquiry.<br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param rsdtInfoVO Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtMberBioAgeChk.do")
    public void searchRsdtMberBioAgeChk(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		EgovMap em = service.searchRsdtMberBioAgeChk(vo);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		if(em != null && !em.isEmpty()){
    			Element eleInfo = doc.createElement("rsdt_info");
        		Element ele = null;
    			root.appendChild(eleInfo);
    			ele = doc.createElement("msg");
    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(em.get("msg"))));
    			eleInfo.appendChild(ele);
    		}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
    
    /**
     * Moved to list-screen of confirm. <br>
     *
     * @param searchVO Value-object of resident to be parsed request(ComDefaultVO)
     * @param rsdtInfoVO Value-object of program to be parsed request(RsdtInfrVO)     * 
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/rsdt/RsdtMberInfrAprvList.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchListRsdtMberInfrAprvView.do")
    public String searchListRsdtMberInfrAprvView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO rsdtInfoVO, 
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(), rsdtInfoVO.getCurMnId());
    		rsdtInfoVO.setUseLangCd(user.getUseLangCd());
    		model.addAttribute("rsdtInfoVO", rsdtInfoVO);
    		searchVO.setSearchKeyword9("N");
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "/rm/rsdt/RsdtMberInfrAprvList";

    }

    /**
     * Retrieves list of program.  <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param rsdtInfoVO Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: " rm/rsdt/RsdtMberInfrAprvList.jsp "
     * @exception Exception
     */
	@RequestMapping(value="/rm/rsdt/searchListRsdtMberInfrAprv.do")
    public String searchListRsdtMberInfrAprv (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO rsdtInfoVO, 
    		ModelMap model)
            throws Exception {
    	try {
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		rsdtInfoVO.setUseLangCd(user.getUseLangCd());
	
    		String orgnzClsCd = user.getOrgnzClsCd();
    		String orgnzCd = user.getOrgnzCd();
    		String teamCd = user.getTamCdNm();
    		rsdtInfoVO.setRgstOrgnzCd(orgnzClsCd+orgnzCd+teamCd);
    		
	    	//** list Paging Setting *//*
    		rsdtInfoVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		rsdtInfoVO.setPageSize(propertiesService.getInt("pageSize"));
	    	//** pageing *//*
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(rsdtInfoVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(rsdtInfoVO.getPageUnit());
			paginationInfo.setPageSize(rsdtInfoVO.getPageSize());

			rsdtInfoVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			rsdtInfoVO.setLastIndex(paginationInfo.getLastRecordIndex());
			rsdtInfoVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
			rsdtInfoVO.setAprvListTm(String.valueOf(propertiesService.getInt("aprvListTm")));

	        List<EgovMap> lstProgram = service.searchListRsdtMberInfrAprv(rsdtInfoVO);
	        model.addAttribute("lstProgram", lstProgram);

	        int totCnt = service.searchListRsdtMberInfrAprvTotCn(rsdtInfoVO);
	        
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "/rm/rsdt/RsdtMberInfrAprvList";
    }
	
	
	
    
	
	/**
     * Moved to Resident registration-screen of program. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtMberInfrAprvUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtMberInfrAprv.do")   
    public String searchRsdtMberInfrAprv(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> bldTyeCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("bldTyeCd", bldTyeCd); 
    		cmCmmCd.setGrpCd("12"); // Setting Group Code
    		List<CmCmmCdVO> mrrgCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("mrrgCd", mrrgCd); 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		List<CmCmmCdVO> etncityCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("etncityCd", etncityCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> fmlyLangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("fmlyLangCd", fmlyLangCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> nallangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("nallangCd", nallangCd);
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		List<CmCmmCdVO> rlgnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlgnCd", rlgnCd);
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		List<CmCmmCdVO> rlgnSect = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlgnSect", rlgnSect);
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		List<CmCmmCdVO> mltSrvcCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("mltSrvcCd", mltSrvcCd);	    		
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> eduYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("eduYnCd", eduYnCd);	    		
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> secdNltyYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("secdNltyYnCd", secdNltyYnCd);
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("nltyCd", nltyCd);
    		cmCmmCd.setGrpCd("8"); // Setting Group Code
    		List<CmCmmCdVO> frgnLang = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("frgnLang", frgnLang);
    		cmCmmCd.setGrpCd("64"); // Setting Group Code
    		List<CmCmmCdVO> rsdtTypCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rsdtTypCd", rsdtTypCd);
    		cmCmmCd.setGrpCd("5"); // Setting Group Code
    		List<CmCmmCdVO> eduCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("eduCd", eduCd);
    		cmCmmCd.setGrpCd("68"); 
    		List<CmCmmCdVO> dsbtCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);  
    		model.addAttribute("dsbtCd", dsbtCd);  
    		
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdManagerService.searchListCmmCd(cmCmmCd); 
    		model.addAttribute("rlCd", codeLst);
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		model.addAttribute("useLangCd", user.getUseLangCd());
	        model.addAttribute("userId", user.getUserId());
	        
	        int frgnInt = propertiesService.getInt("frgnLangOthrLangRgstNo");
	        model.addAttribute("frgnLangOthrLangRgstNo", frgnInt);
	        
	        int kochiAdCd = propertiesService.getInt("kochiAdCd");
	        model.addAttribute("kochiAdCd", kochiAdCd);
	        
	        int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		
    		
    		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
    		vo.setUseLangCd(user.getUseLangCd());
    		vo.setUserNm(user.getNm());
    		vo.setCrdIsuDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
    		
			RsdtInfrVO rsdtInfoVO = service.searchRsdtInfrAprvView(vo);
	        List<RsdtInfrVO> othrNatLangList = service.searchListOthrNatLangInfrAprv(vo);
	        List<RsdtInfrVO> frgnLangList = service.searchListFrgnLangInfrAprv(vo);
	        model.addAttribute("rsdtInfoVO", rsdtInfoVO);
	        model.addAttribute("othrNatLangList", othrNatLangList);
	        model.addAttribute("frgnLangList", frgnLangList);
    		
	        List<EgovMap> rmRlLst = fmlyInfrService.searchRmRlTb(new String("")); 
	        model.addAttribute("rmRlLst", rmRlLst);
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/rsdt/RsdtMberInfrAprvUdt";
    }
    
    
    
    /**
     * Moved to Resident registration-screen of program. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtMberInfrAprvUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/modifyRsdtMberInfrAprv.do")   
    public String modifyRsdtMberInfrAprv(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	String result = "forward:/rm/rsdt/searchRsdtMberInfrAprv.do";
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
    		vo.setUseLangCd(user.getUseLangCd());
    		vo.setUserNm(user.getNm());
    		String crdIsuDueDd = vo.getCrdIsuDueDd();
    		vo.setCrdIsuDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
    		RsdtInfrVO rsdtInfoVOx = service.searchRsdtInfrView(vo); 
	        if(rsdtInfoVOx != null && rsdtInfoVOx.getCtznRgstYn() != null && rsdtInfoVOx.getTamLedrCfmYn() != null && ( ("Y".equals(rsdtInfoVOx.getCtznRgstYn()) && !vo.getRgstOrgnzCd().equals(rsdtInfoVOx.getRgstOrgnzCd()) ) || "Y".equals(rsdtInfoVOx.getTamLedrCfmYn() ) )){
	        	RsdtInfrVO vos = vo.init();
	    		model.addAttribute("rsdtInfoVO", vos);
	    		model.addAttribute("othrNatLangList", null);
	 	        model.addAttribute("frgnLangList", null);
	 	        model.addAttribute("resultMsg", nidMessageSource.getMessage("nAlIndiRgstError.msg"));
	 	      	result = "forward:/rm/rsdt/searchRsdtMberInfrAprv.do";
	        }else{
	        	vo.setCrdIsuDueDd(crdIsuDueDd);
	        	int resultCnt = service.modifyRsdtMberInfrAprv(vo, null);
	    		if(resultCnt > 0){
	        		model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
	    		}else{
	    			model.addAttribute("resultMsg", nidMessageSource.getMessage("udtFail.msg"));
	    		}
	        }
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return result;
    }
    
    
    
    
    /**
     * Moved to Resident registration-screen of program. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtMberInfrAprvList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/aprvRsdtMberInfr.do")
    public String aprvRsdtMberInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	String result = "forward:/rm/rsdt/searchRsdtMberInfrAprv.do";
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
    		vo.setUseLangCd(user.getUseLangCd());
    		vo.setUserNm(user.getNm());
    		String crdIsuDueDd = vo.getCrdIsuDueDd();
    		vo.setCrdIsuDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
    		RsdtInfrVO rsdtInfoVOx = service.searchRsdtInfrView(vo); 
	        if(rsdtInfoVOx != null && rsdtInfoVOx.getCtznRgstYn() != null && rsdtInfoVOx.getTamLedrCfmYn() != null && ( ("Y".equals(rsdtInfoVOx.getCtznRgstYn()) && !vo.getRgstOrgnzCd().equals(rsdtInfoVOx.getRgstOrgnzCd()) ) || "Y".equals(rsdtInfoVOx.getTamLedrCfmYn() ) )){
	        	RsdtInfrVO vos = vo.init();
	    		model.addAttribute("rsdtInfoVO", vos);
	    		model.addAttribute("othrNatLangList", null);
	 	        model.addAttribute("frgnLangList", null);
	 	        model.addAttribute("resultMsg", nidMessageSource.getMessage("nAlIndiRgstError.msg"));
	 	       result = "forward:/rm/rsdt/searchRsdtMberInfrAprv.do";
	        }else{
	        	vo.setCrdIsuDueDd(crdIsuDueDd);
	        	int resultCnt = service.searchRsdtMberInfrApvrState(vo);
	    		if(resultCnt > 0){
	    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nAprvByApvd.msg"));
	    		}else{
	    			EgovMap em = service.aprvRsdtMberInfr(vo);
	    			resultCnt = -1;
	    			if(em != null && !em.isEmpty()){
		    			if(em.get("result") != null && em.get("result") instanceof Integer){
		    				resultCnt = ((Integer)em.get("result")).intValue();
		    			}
		    			if(em.get("bioEm") != null && em.get("bioEm") instanceof EgovMap){
		    				EgovMap bioEm = (EgovMap)em.get("bioEm");
		    				bioIfService.addBioInterfaceLog(bioEm);
		    			}
		    		}
	        		if(resultCnt > 0){
	        			model.addAttribute("resultMsg", nidMessageSource.getMessage("apvScsfl.msg"));
	        			result = "forward:/rm/rsdt/searchListRsdtMberInfrAprv.do";
	        		}else{
	        			String helpTelNo = nidMessageSource.getMessage("admTelNo");
	        			model.addAttribute("resultMsg", nidMessageSource.getMessage("apvFail.msg", new String[]{helpTelNo}));
	        		}
	    		}
	        }
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return result;
    }
    
    
    
    
    /**
     * Moved to list-screen of resident. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/p_RsdtMberInfrFnd.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchListRsdtMberInfrPopView.do")
    public String searchListRsdtInfrPopView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		@RequestParam(value="fmlyBokNos" ,required=false) String fmlyBokNos,
    		@RequestParam(value="rgstMod" ,required=false) String rgstMod,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();

    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();// 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		model.addAttribute("useLangCd",  user.getUseLangCd());
    		model.addAttribute("rgstMod", rgstMod);
    		
    		List<EgovMap> fmlyList = service.searchRsdtFmlyBokLstPop(vo);
    		model.addAttribute("fmlyList", fmlyList);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/rsdt/p_RsdtMberInfrFnd";
    }
    
    
    /**
     * Retrieves list of program.  <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/p_RsdtMberInfrFnd.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/rsdt/searchListRsdtMberInfrPop.do")
    public String searchListRsdtInfrPop (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		@RequestParam(value="callbacks" ,required=false) String callback,
    		@RequestParam(value="rgstMod" ,required=false) String rgstMod,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    		String orgnzCd = user.getOrgnzCd();
    		String district = orgnzCd.substring(0, 4); //String str1 = "L123456789"; 467
    		String teamCd = user.getTamCdNm();
    		vo.setOfficerNo(district+teamCd);
	    	
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));
	    	//** pageing *//*
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());
			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
	        List<EgovMap> lstProgram = service.searchListRsdtInfrPop(vo);
	        model.addAttribute("lstProgram", lstProgram);
	        int totCnt = service.searchListRsdtInfrPopTotCn(vo);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		
    		model.addAttribute("callbacks", callback);//callback function
    		
    		model.addAttribute("useLangCd",  user.getUseLangCd());
    		model.addAttribute("rgstMod", rgstMod);
    		
    		model.addAttribute("rgstOrgnzCd", user.getOrgnzClsCd()+ user.getOrgnzCd());
    		
    		List<EgovMap> fmlyList = service.searchRsdtFmlyBokLstPop(vo);
    		model.addAttribute("fmlyList", fmlyList);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/rsdt/p_RsdtMberInfrFnd";   	
    }
	
	
	
	
	
	
	/**
     * Moved to Resident registration-screen of program. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtMberInfrIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/addExiRsdtMberInfr.do")
    public String addExiRsdtMberInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> bldTyeCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("bldTyeCd", bldTyeCd); 
    		cmCmmCd.setGrpCd("12"); // Setting Group Code
    		List<CmCmmCdVO> mrrgCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("mrrgCd", mrrgCd); 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		List<CmCmmCdVO> etncityCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("etncityCd", etncityCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> fmlyLangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("fmlyLangCd", fmlyLangCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> nallangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("nallangCd", nallangCd);
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		List<CmCmmCdVO> rlgnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlgnCd", rlgnCd);
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		List<CmCmmCdVO> rlgnSect = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlgnSect", rlgnSect);
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		List<CmCmmCdVO> mltSrvcCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("mltSrvcCd", mltSrvcCd);	    		
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> eduYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("eduYnCd", eduYnCd);	    		
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> secdNltyYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("secdNltyYnCd", secdNltyYnCd);
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("nltyCd", nltyCd);
    		cmCmmCd.setGrpCd("8"); // Setting Group Code
    		List<CmCmmCdVO> frgnLang = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("frgnLang", frgnLang);
    		cmCmmCd.setGrpCd("64"); // Setting Group Code
    		List<CmCmmCdVO> rsdtTypCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rsdtTypCd", rsdtTypCd);
    		cmCmmCd.setGrpCd("5"); // Setting Group Code
    		List<CmCmmCdVO> eduCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("eduCd", eduCd);
    		cmCmmCd.setGrpCd("68"); 
    		List<CmCmmCdVO> dsbtCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);  
    		model.addAttribute("dsbtCd", dsbtCd);  
    		
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdManagerService.searchListCmmCd(cmCmmCd); 
    		model.addAttribute("rlCd", codeLst);
    		
    		model.addAttribute("useLangCd", user.getUseLangCd());
	        model.addAttribute("userId", user.getUserId());
	        
	        int frgnInt = propertiesService.getInt("frgnLangOthrLangRgstNo");
	        model.addAttribute("frgnLangOthrLangRgstNo", frgnInt);
	        
	        int kochiAdCd = propertiesService.getInt("kochiAdCd");
	        model.addAttribute("kochiAdCd", kochiAdCd);
	        
	        int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		
    		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
    		vo.setUseLangCd(user.getUseLangCd());
    		vo.setUserNm(user.getNm());
    		vo.setCrdIsuDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
    		RsdtInfrVO rsdtInfoVO = service.searchRsdtInfrView(vo); 
	        List<RsdtInfrVO> othrNatLangList = service.searchListOthrNatLangInfr(vo);
	        List<RsdtInfrVO> frgnLangList = service.searchListFrgnLangInfr(vo);
	        model.addAttribute("rsdtInfoVO", rsdtInfoVO);
	        model.addAttribute("othrNatLangList", othrNatLangList);
	        model.addAttribute("frgnLangList", frgnLangList);
	        
	        if(rsdtInfoVO != null && rsdtInfoVO.getCtznRgstYn() != null && rsdtInfoVO.getTamLedrCfmYn() != null && ( "Y".equals(rsdtInfoVO.getCtznRgstYn()) || "Y".equals(rsdtInfoVO.getTamLedrCfmYn()) )){
	        	RsdtInfrVO vos = vo.init();
	    		model.addAttribute("rsdtInfoVO", vos);
	    		model.addAttribute("othrNatLangList", null);
	 	        model.addAttribute("frgnLangList", null);
	 	        model.addAttribute("resultMsg", nidMessageSource.getMessage("nAlIndiRgstError.msg"));
	        }
	        List<EgovMap> rmRlLst = fmlyInfrService.searchRmRlTb(new String("")); 
	        model.addAttribute("rmRlLst", rmRlLst);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/rsdt/RsdtMberInfrIns";
    }
    
    
    
    
    
    
    /**
     * Moved to Resident registration-screen of program. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtMberInfrUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchExiRsdtMberInfr.do")   
    public String searchExiRsdtMberInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> bldTyeCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("bldTyeCd", bldTyeCd); 
    		cmCmmCd.setGrpCd("12"); // Setting Group Code
    		List<CmCmmCdVO> mrrgCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("mrrgCd", mrrgCd); 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		List<CmCmmCdVO> etncityCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("etncityCd", etncityCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> fmlyLangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("fmlyLangCd", fmlyLangCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> nallangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("nallangCd", nallangCd);
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		List<CmCmmCdVO> rlgnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlgnCd", rlgnCd);
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		List<CmCmmCdVO> rlgnSect = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlgnSect", rlgnSect);
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		List<CmCmmCdVO> mltSrvcCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("mltSrvcCd", mltSrvcCd);	    		
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> eduYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("eduYnCd", eduYnCd);	    		
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> secdNltyYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("secdNltyYnCd", secdNltyYnCd);
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("nltyCd", nltyCd);
    		cmCmmCd.setGrpCd("8"); // Setting Group Code
    		List<CmCmmCdVO> frgnLang = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("frgnLang", frgnLang);
    		cmCmmCd.setGrpCd("64"); // Setting Group Code
    		List<CmCmmCdVO> rsdtTypCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rsdtTypCd", rsdtTypCd);
    		cmCmmCd.setGrpCd("5"); // Setting Group Code
    		List<CmCmmCdVO> eduCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("eduCd", eduCd);
    		cmCmmCd.setGrpCd("68"); 
    		List<CmCmmCdVO> dsbtCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);  
    		model.addAttribute("dsbtCd", dsbtCd);  
    		
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdManagerService.searchListCmmCd(cmCmmCd); 
    		model.addAttribute("rlCd", codeLst);
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		model.addAttribute("useLangCd", user.getUseLangCd());
	        model.addAttribute("userId", user.getUserId());
	        
	        int frgnInt = propertiesService.getInt("frgnLangOthrLangRgstNo");
	        model.addAttribute("frgnLangOthrLangRgstNo", frgnInt);
	        
	        int kochiAdCd = propertiesService.getInt("kochiAdCd");
	        model.addAttribute("kochiAdCd", kochiAdCd);
	        
	        int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		
    		String rsdtSeqNoTmp = vo.getRsdtSeqNo();
    		if(rsdtSeqNoTmp != null && !"".equals(rsdtSeqNoTmp)){
    			String [] arr = rsdtSeqNoTmp.split(",");
    			if(arr != null && arr.length > 0){
    				vo.setRsdtSeqNo(arr[0]);
    			}
    		}
    		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
    		vo.setUseLangCd(user.getUseLangCd());
    		vo.setUserNm(user.getNm());
    		vo.setCrdIsuDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
    		RsdtInfrVO rsdtInfoVOx = service.searchRsdtInfrView(vo); 
	        
	        if(rsdtInfoVOx != null && rsdtInfoVOx.getCtznRgstYn() != null && rsdtInfoVOx.getTamLedrCfmYn() != null && ( ("Y".equals(rsdtInfoVOx.getCtznRgstYn()) && !vo.getRgstOrgnzCd().equals(rsdtInfoVOx.getRgstOrgnzCd()) ) || "Y".equals(rsdtInfoVOx.getTamLedrCfmYn() ) )){
	        	RsdtInfrVO vos = vo.init();
	    		model.addAttribute("rsdtInfoVO", vos);
	    		model.addAttribute("othrNatLangList", null);
	 	        model.addAttribute("frgnLangList", null);
	 	        model.addAttribute("resultMsg", nidMessageSource.getMessage("nAlIndiRgstError.msg"));
	        }else{
	        	vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
	    		vo.setUseLangCd(user.getUseLangCd());
	    		vo.setUserNm(user.getNm());
	    		vo.setCrdIsuDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
	    		
	    		if(vo.getRsdtSeqNo() != null && !"".equals(vo.getRsdtSeqNo())){
	    			RsdtInfrVO rsdtInfoVO = service.searchRsdtInfrView(vo); 
			        List<RsdtInfrVO> othrNatLangList = service.searchListOthrNatLangInfr(vo);
			        List<RsdtInfrVO> frgnLangList = service.searchListFrgnLangInfr(vo);
			        model.addAttribute("rsdtInfoVO", rsdtInfoVO);
			        model.addAttribute("othrNatLangList", othrNatLangList);
			        model.addAttribute("frgnLangList", frgnLangList);
			        
			        if(comDefaultVO != null){
			        	if(comDefaultVO.getSearchKeyword2() == null || "".equals(comDefaultVO.getSearchKeyword2())){
			        		String fmlyBokNo = rsdtInfoVO.getFmlyBokNo();
			        		if(fmlyBokNo != null && fmlyBokNo.length() == 10){
			        			comDefaultVO.setSearchKeyword2(fmlyBokNo.substring(0, 4));
			        			comDefaultVO.setSearchKeyword3(fmlyBokNo.substring(4, 6));
			        			comDefaultVO.setSearchKeyword4(fmlyBokNo.substring(6, 10));
			        			model.addAttribute("searchVO", comDefaultVO);
			        		}
			        	}else{
			        		String fmlyBokNo = rsdtInfoVO.getFmlyBokNo();
			        		StringBuffer sb = new StringBuffer();
			        		sb.append(comDefaultVO.getSearchKeyword2()).append(comDefaultVO.getSearchKeyword3()).append(comDefaultVO.getSearchKeyword4());
			        		if(fmlyBokNo != null && !fmlyBokNo.equals(sb.toString())){
			        			comDefaultVO.setSearchKeyword2(fmlyBokNo.substring(0, 4));
			        			comDefaultVO.setSearchKeyword3(fmlyBokNo.substring(4, 6));
			        			comDefaultVO.setSearchKeyword4(fmlyBokNo.substring(6, 10));
			        			model.addAttribute("searchVO", comDefaultVO);
			        		}
			        	}
			        }
	    		}else{
	    			List<EgovMap> em = service.searchRsdtMberFmlyInfr(vo);
	    			if(em != null && !em.isEmpty()){
	    				if(em.size() > 1){
	    					model.addAttribute("mberPopup", "mberPopup");
	    					RsdtInfrVO vos = vo.init();
	            			model.addAttribute("rsdtInfoVO", vos);
	    				}else{
	    					String rsdtSeqNo = NidStringUtil.nullConvert(em.get(0).get("rsdtSeqNo"));
	    					vo.setRsdtSeqNo(rsdtSeqNo);
	    					if(rsdtSeqNo != null && !"".equals(rsdtSeqNo)){
	    						RsdtInfrVO rsdtInfoVO = service.searchRsdtInfrView(vo); 
	    				        List<RsdtInfrVO> othrNatLangList = service.searchListOthrNatLangInfr(vo);
	    				        List<RsdtInfrVO> frgnLangList = service.searchListFrgnLangInfr(vo);
	    				        model.addAttribute("rsdtInfoVO", rsdtInfoVO);
	    				        model.addAttribute("othrNatLangList", othrNatLangList);
	    				        model.addAttribute("frgnLangList", frgnLangList);
	    				        
	    				        if(comDefaultVO != null){
	    				        	if(comDefaultVO.getSearchKeyword2() == null || "".equals(comDefaultVO.getSearchKeyword2())){
	    				        		String fmlyBokNo = rsdtInfoVO.getFmlyBokNo();
	    				        		if(fmlyBokNo != null && fmlyBokNo.length() == 10){
	    				        			comDefaultVO.setSearchKeyword2(fmlyBokNo.substring(0, 4));
	    				        			comDefaultVO.setSearchKeyword3(fmlyBokNo.substring(4, 6));
	    				        			comDefaultVO.setSearchKeyword4(fmlyBokNo.substring(6, 10));
	    				        			model.addAttribute("searchVO", comDefaultVO);
	    				        		}
	    				        	}
	    				        }
	    				        
	    					}
	    				}
	    			}else{
	    				model.addAttribute("resultMsg", nidMessageSource.getMessage("nMberRgstHst.msg"));
	    				RsdtInfrVO vos = vo.init();
	        			model.addAttribute("rsdtInfoVO", vos);
	    			}
	    		}
	        }
	        List<EgovMap> rmRlLst = fmlyInfrService.searchRmRlTb(new String("")); 
	        model.addAttribute("rmRlLst", rmRlLst);
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/rsdt/RsdtMberInfrUdt";
    }
    
    
    
    
    
    /**
     * Moved to Resident registration-screen of program. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtMberInfrAprvUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchExiRsdtMberInfrAprv.do")   
    public String searchExiRsdtMberInfrAprv(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	String resultJsp = "/rm/rsdt/RsdtMberInfrAprvUdt";
    	try {
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> bldTyeCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("bldTyeCd", bldTyeCd); 
    		cmCmmCd.setGrpCd("12"); // Setting Group Code
    		List<CmCmmCdVO> mrrgCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("mrrgCd", mrrgCd); 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		List<CmCmmCdVO> etncityCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("etncityCd", etncityCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> fmlyLangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("fmlyLangCd", fmlyLangCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> nallangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("nallangCd", nallangCd);
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		List<CmCmmCdVO> rlgnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlgnCd", rlgnCd);
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		List<CmCmmCdVO> rlgnSect = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rlgnSect", rlgnSect);
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		List<CmCmmCdVO> mltSrvcCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("mltSrvcCd", mltSrvcCd);	    		
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> eduYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("eduYnCd", eduYnCd);	    		
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> secdNltyYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("secdNltyYnCd", secdNltyYnCd);
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("nltyCd", nltyCd);
    		cmCmmCd.setGrpCd("8"); // Setting Group Code
    		List<CmCmmCdVO> frgnLang = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("frgnLang", frgnLang);
    		cmCmmCd.setGrpCd("64"); // Setting Group Code
    		List<CmCmmCdVO> rsdtTypCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("rsdtTypCd", rsdtTypCd);
    		cmCmmCd.setGrpCd("5"); // Setting Group Code
    		List<CmCmmCdVO> eduCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("eduCd", eduCd);
    		cmCmmCd.setGrpCd("68"); 
    		List<CmCmmCdVO> dsbtCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);  
    		model.addAttribute("dsbtCd", dsbtCd);  
    		
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdManagerService.searchListCmmCd(cmCmmCd); 
    		model.addAttribute("rlCd", codeLst);
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		model.addAttribute("useLangCd", user.getUseLangCd());
	        model.addAttribute("userId", user.getUserId());
	        
	        int frgnInt = propertiesService.getInt("frgnLangOthrLangRgstNo");
	        model.addAttribute("frgnLangOthrLangRgstNo", frgnInt);
	        
	        int kochiAdCd = propertiesService.getInt("kochiAdCd");
	        model.addAttribute("kochiAdCd", kochiAdCd);
	        
	        int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		
    		
    		
    		vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
    		vo.setUseLangCd(user.getUseLangCd());
    		vo.setUserNm(user.getNm());
    		vo.setCrdIsuDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
    		RsdtInfrVO rsdtInfoVOx = service.searchRsdtInfrView(vo); 
	        
	        if(rsdtInfoVOx != null && rsdtInfoVOx.getCtznRgstYn() != null && rsdtInfoVOx.getTamLedrCfmYn() != null && ( ("Y".equals(rsdtInfoVOx.getCtznRgstYn()) && !vo.getRgstOrgnzCd().equals(rsdtInfoVOx.getRgstOrgnzCd()) ) || "Y".equals(rsdtInfoVOx.getTamLedrCfmYn() ) )){
	        	RsdtInfrVO vos = vo.init();
	    		model.addAttribute("rsdtInfoVO", vos);
	    		model.addAttribute("othrNatLangList", null);
	 	        model.addAttribute("frgnLangList", null);
	 	        model.addAttribute("resultMsg", nidMessageSource.getMessage("nAlIndiRgstError.msg"));
	 	        resultJsp = "forward:/rm/rsdt/searchListRsdtMberInfrAprv.do";
	        }else{
	        	vo.setRgstOrgnzCd(user.getOrgnzClsCd()+ user.getOrgnzCd());
	    		vo.setUseLangCd(user.getUseLangCd());
	    		vo.setUserNm(user.getNm());
	    		vo.setCrdIsuDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
	    		
				RsdtInfrVO rsdtInfoVO = service.searchRsdtInfrAprvView(vo);
		        List<RsdtInfrVO> othrNatLangList = service.searchListOthrNatLangInfrAprv(vo);
		        List<RsdtInfrVO> frgnLangList = service.searchListFrgnLangInfrAprv(vo);
		        model.addAttribute("rsdtInfoVO", rsdtInfoVO);
		        model.addAttribute("othrNatLangList", othrNatLangList);
		        model.addAttribute("frgnLangList", frgnLangList);
	        }
	        
	        List<EgovMap> rmRlLst = fmlyInfrService.searchRmRlTb(new String("")); 
	        model.addAttribute("rmRlLst", rmRlLst);
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return resultJsp;
    }
    
    
    
    
    
    
    
    
    
    
    
    /**
     * Bio for registration inquiry.<br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param rsdtInfoVO Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchFmlyRsdtMberSelfGdr.do")
    public void searchFmlyRsdtMberSelfGdr(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		String gdrCd = service.searchFmlyRsdtMberSelfGdr(vo);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		if(gdrCd != null && !"".equals(gdrCd)){
    			Element el = doc.createElement("gdrCd");
    			el.appendChild(doc.createTextNode(gdrCd));
	    		root.appendChild(el);
    		}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
    
    
    
    /**
     * self and the birth date of check <br>
     *
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchFmlyMberRsdtInfrList.do")
    public void searchFmlyMberRsdtInfrList(
    		ModelMap model,
    		HttpServletResponse response,
    		@RequestParam(value="rsdtSeqNo" ,required=false) String rsdtSeqNo,
    		@RequestParam(value="fmlyBokNo" ,required=false) String fmlyBokNo)
            throws Exception {
    	try{
    		EgovMap em = new EgovMap();
    		em.put("rsdtSeqNo", rsdtSeqNo);
    		em.put("fmlyBokNo", fmlyBokNo);
    		List<EgovMap> list = service.searchFmlyMberRsdtInfrList(em);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element eleInfo = null;
    		Element ele = null;
    		if(list != null){
    			for(int i=0; i<list.size(); i++){
        			EgovMap ems = list.get(i);
        			if(ems != null){
    	    			eleInfo = doc.createElement("person");
    	    			root.appendChild(eleInfo);
    	    			ele = doc.createElement("rlCd");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("rlCd")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("bthDd");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("bthDd")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("calTye");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("calTye")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("frngrYn");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("frngrYn")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("initDthYn");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("initDthYn")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("rsdtSeqNo");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("rsdtSeqNo")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("fthrRsdtSeqNo");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("fthrRsdtSeqNo")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("gfthrRsdtSeqNo");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("gfthrRsdtSeqNo")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("mthrRsdtSeqNo");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("mthrRsdtSeqNo")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("spusRsdtSeqNo");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("spusRsdtSeqNo")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("fthrRsdtNo");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("fthrRsdtNo")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("gfthrRsdtNo");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("gfthrRsdtNo")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("mthrRsdtNo");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("mthrRsdtNo")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("spusRsdtNo");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("spusRsdtNo")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("fthrRgstTye");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("fthrRgstTye")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("gfthrRgstTye");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("gfthrRgstTye")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("mthrRgstTye");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("mthrRgstTye")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("spusRgstTye");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("spusRgstTye")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("fthrNm");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("fthrNm")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("gfthrNm");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("gfthrNm")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("mthrNm");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("mthrNm")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("spusNm");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("spusNm")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("givNm");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("givNm")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("surnm");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("surnm")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("rsdtNo");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("rsdtNo")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("oldCrdNo1");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("oldCrdNo1")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("oldCrdNo2");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("oldCrdNo2")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("oldCrdNo3");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("oldCrdNo3")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("oldCrdNo4");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("oldCrdNo4")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("gdrCd");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("gdrCd")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("tamLedrCfmYn");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("tamLedrCfmYn")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("bthDdS");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.nullConvert(ems.get("bthDdS")) ));
    	    			eleInfo.appendChild(ele);
        			}
    	    	}
    		}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
    
    
    
    
    
    /**
     * Retrieves list of program.  <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/p_RsdtFmlyMberInfrFnd.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchListFmlyMberInfrPopView.do")
    public String searchListFmlyMberInfrPopView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("useLangCd",  user.getUseLangCd());
    		model.addAttribute("rsdtXxx", "start");
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/rsdt/p_RsdtFmlyMberInfrFnd";
    }
	
    /**
     * Retrieves list of program.  <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/p_RsdtFmlyMberInfrFnd.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchListFmlyMberInfrPop.do")
    public String searchListFmlyMberInfrPop(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		@RequestParam(value="mode" ,required=false) String mode,
    		@RequestParam(value="srchAgGap" ,required=false) String srchAgGap,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("useLangCd",  user.getUseLangCd());
			vo.setSrchAgGap(srchAgGap);
    		List<EgovMap> list =  service.searchListFmlyInfrPop(vo);
    		model.addAttribute("lstProgram", list);
    		model.addAttribute("lstProgramCnt", list != null ? list.size() : 0);
    		model.addAttribute("rsdtXxx", "end");
    		model.addAttribute("mode", mode);
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/rsdt/p_RsdtFmlyMberInfrFnd";
    }
    
    
    
    
    /**
     * self and the birth date of check <br>
     *
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtInfrMaleRlCn.do")
    public void searchRsdtInfrMaleRlCn(
    		ModelMap model,
    		HttpServletResponse response,
    		@RequestParam(value="rsdtSeqNo" ,required=false) String rsdtSeqNo,
    		@RequestParam(value="mode" ,required=false) String mode)
            throws Exception {
    	try{
    		EgovMap em = new EgovMap();
    		em.put("rsdtSeqNo", rsdtSeqNo);
    		em.put("mode", mode);
    		List<EgovMap> list = service.searchRsdtInfrMaleRlCn(em);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element eleInfo = null;
    		Element ele = null;
    		if(list != null){
    			for(int i=0; i<list.size(); i++){
        			EgovMap ems = list.get(i);
        			if(ems != null){
    	    			eleInfo = doc.createElement("person");
    	    			root.appendChild(eleInfo);
    	    			ele = doc.createElement("fmlyBokNo");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)ems.get("fmlyBokNo")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("fmlyBokNoDp");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)ems.get("fmlyBokNoDp")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("givNm");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)ems.get("givNm")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("surnm");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)ems.get("surnm")) ));
    	    			eleInfo.appendChild(ele);
    	    			ele = doc.createElement("name");
    	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)ems.get("name")) ));
    	    			eleInfo.appendChild(ele);
        			}
    	    	}
    		}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
}