package afnid.rm.rsdt.web;

/* java API */
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.rm.rsdt.service.RM1RsdtInfrService;
import afnid.rm.rsdt.service.RsdtInfrVO;
import egovframework.rte.fdl.property.EgovPropertyService;




/** 
 * This Controller class processes request of resident-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Team Ha Na YIM
 * @since 2011.04.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.04.19  		Ha Na YIM          		                    Create
 *
 * </pre>
 */

@Controller
public class RM1RsdtInfrController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    @Resource(name = "RM1RsdtInfrService")
    private RM1RsdtInfrService service;
    
    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdMngService;
	

 	/**
     * Moved to list-screen of resident. <br>
     *
     * @param bioCheckVO Value-object of resident to be parsed request(rsdtInfoVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/batch/RsdtMualBatch.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/setXmlGenerate.do")
    public String setXmlGenerate(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfrVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
        	CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("71"); 
    		List<CmCmmCdVO> batchLst = cmmCdMngService.searchListCmmCd(cmCmmCd);     		
    		model.addAttribute("batchLst", batchLst);
    		
    		int cnt = service.setXmlGenerate();

    		
      		if (cnt == 0){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nDat"));

    		} else {
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("bachPrcss.msg"));

    		}

    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    	return "/rm/batch/RsdtMualBatch"; 
    	
    }
     
}