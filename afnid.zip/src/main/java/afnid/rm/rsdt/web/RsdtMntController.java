package afnid.rm.rsdt.web;

/* java API */


import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.rm.rsdt.service.RsdtMntService;
import afnid.rm.rsdt.service.RsdtMntVO;
import egovframework.rte.fdl.property.EgovPropertyService;

/** 
 * This Controller class processes request of resident-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Team moon soo kim
 * @since 2011.04.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *  2013.11.03 		   moon soo kim        		             Create
 *
 * </pre>
 */

@Controller
public class RsdtMntController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	
	@Resource(name = "rsdtMntService")
    private RsdtMntService service;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    @Resource(name = "lgService")
    private LgService lgService;
	
 	/**
     * Residents move to display information changes. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param rsdtMdfcVO Value-object of program to be parsed request(RsdtMntVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/RsdtPrcssStusDtl.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtPrcssStusView.do")
    public String searchRsdtPrcssStusView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtPrcssStusVO") RsdtMntVO rsdtPrcssStusVO,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(), rsdtPrcssStusVO.getCurMnId());
    		searchVO.setSearchKeyword2("j");
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/rsdt/RsdtPrcssStusDtl";
    }
    
    
    
    
    /**
     * Resident updated registration screen. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtPrcssStusVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/rsdt/RsdtPrcssStusDtl.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/rsdt/searchRsdtPrcssStus.do")
    public String searchRsdtPrcssStus(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtPrcssStusVO") RsdtMntVO vo,
    		ModelMap model)
            throws Exception {
    	try{

    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    		
    		int result =  service.searchRsdtInfrCn(vo);
    		
    		if (result  > 0) {
    			RsdtMntVO rsdtInfr = service.searchRsdtPrcssStusInfr(vo);
    	        model.addAttribute("rsdtInfr", rsdtInfr);  
    	        
    	        vo.setGdrCd(rsdtInfr.getGdrCd());
    	        vo.setHstCnt(rsdtInfr.getHstCnt());
    	        
    	        List<RsdtMntVO> lstRsdtHst = service.searchListRsdtPrcssHst(vo);
    	        model.addAttribute("lstRsdtHst", lstRsdtHst);     	        
    			
    		} else {
    			int cnt = service.searchRsdtBiioDupCn(vo);
    					
    			if(cnt > 0){ 
    				model.addAttribute("resultMsg", nidMessageSource.getMessage("nCrdTrace.msg"));    				
    			} else {
    				model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstEnid.msg"));
    			}
    		}

    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/rsdt/RsdtPrcssStusDtl";
    }
    
    
    
 
	
	
}