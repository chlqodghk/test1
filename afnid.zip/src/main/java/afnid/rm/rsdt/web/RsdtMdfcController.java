package afnid.rm.rsdt.web;

/* java API */
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.net.ConnectException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.error.ErrorHandler;
import afnid.cm.cmm.error.NidException;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.bioif.service.BioIfInfrService;
import afnid.rm.rsdt.service.RsdtInfrService;
import afnid.rm.rsdt.service.RsdtInfrVO;
import afnid.rm.rsdt.service.RsdtMdfcService;
import afnid.rm.rsdt.service.RsdtMdfcVO;
import egovframework.rte.fdl.cmmn.exception.BaseException;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;



/** 
 * This Controller class processes request of resident-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Team Ha Na YIM
 * @since 2011.04.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.04.19  		Ha Na YIM          		                    Create
 *
 * </pre>
 */

@Controller
public class RsdtMdfcController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	/** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService  cmmCdManagerService;
	
	
	@Resource(name = "rsdtMdfcService")
    private RsdtMdfcService service;
	
	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    /** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    @Resource(name = "lgService")
    private LgService lgService;
    
    /** NidCommonService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCommonService;
	
	@Resource(name = "bioIfInfrService")
    private BioIfInfrService bioIfService;

	@Resource(name = "rsdtInfoService")
    private RsdtInfrService rsdtInfoService;
    
 	/**
     * Residents move to display information changes. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param rsdtMdfcVO Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/RsdtMdfcIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtMdfcView.do")
    public String searchRsdtMdfcView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtMdfcVO") RsdtMdfcVO rsdtMdfcVO,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(), rsdtMdfcVO.getCurMnId());
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> bldTyeCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("bldTyeCd", bldTyeCd); 
    		cmCmmCd.setGrpCd("12"); // Setting Group Code
    		List<CmCmmCdVO> mrrgCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("mrrgCd", mrrgCd); 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("gdrCd", gdrCd);
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		List<CmCmmCdVO> etncityCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("etncityCd", etncityCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> fmlyLangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("fmlyLangCd", fmlyLangCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> nallangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("nallangCd", nallangCd);
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		List<CmCmmCdVO> rlgnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("rlgnCd", rlgnCd);
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		List<CmCmmCdVO> rlgnSect = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("rlgnSect", rlgnSect);
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		List<CmCmmCdVO> mltSrvcCd = NidStringUtil.setListReverse( cmmCdManagerService.searchListCmmCd(cmCmmCd) );
    		model.addAttribute("mltSrvcCd", mltSrvcCd);
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("nltyCd", nltyCd);
    		cmCmmCd.setGrpCd("8"); // Setting Group Code
    		List<CmCmmCdVO> frgnLang = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("frgnLang", frgnLang);
    		
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, ""); 
    		model.addAttribute("rlCd", codeLst); 
    		
    		cmCmmCd.setGrpCd("64"); // Setting Group Code
    		List<CmCmmCdVO> rsdtTypCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, ""); 
    		model.addAttribute("rsdtTypCd", rsdtTypCd); 
    		
    		cmCmmCd.setGrpCd("5"); // Setting Group Code
    		List<CmCmmCdVO> eduCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("eduCd", eduCd);
    		
    		cmCmmCd.setGrpCd("68"); // Setting Group Code
    		List<CmCmmCdVO> dsbtCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("dsbtCd", dsbtCd);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/rsdt/RsdtMdfcIns";
    }
    
    
    
    
    /**
     * Resident updated registration screen. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/rsdt/RsdtMdfcIns.jsp"
     * @exception Exception
     */
    @SuppressWarnings("unchecked")
	@RequestMapping(value="/rm/rsdt/searchRsdtMdfc.do")
    public String searchRsdtMdfc(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtMdfcVO") RsdtMdfcVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> bldTyeCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("bldTyeCd", bldTyeCd); 
    		cmCmmCd.setGrpCd("12"); // Setting Group Code
    		List<CmCmmCdVO> mrrgCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("mrrgCd", mrrgCd); 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("gdrCd", gdrCd);
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		List<CmCmmCdVO> etncityCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("etncityCd", etncityCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> fmlyLangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("fmlyLangCd", fmlyLangCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> nallangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("nallangCd", nallangCd);
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		List<CmCmmCdVO> rlgnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("rlgnCd", rlgnCd);
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		List<CmCmmCdVO> rlgnSect = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("rlgnSect", rlgnSect);
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		List<CmCmmCdVO> mltSrvcCd = NidStringUtil.setListReverse( cmmCdManagerService.searchListCmmCd(cmCmmCd) );
    		model.addAttribute("mltSrvcCd", mltSrvcCd);
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("nltyCd", nltyCd);
    		cmCmmCd.setGrpCd("8"); // Setting Group Code
    		List<CmCmmCdVO> frgnLang = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("frgnLang", frgnLang);
    		
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, ""); 
    		model.addAttribute("rlCd", codeLst); 
    		
    		cmCmmCd.setGrpCd("64"); // Setting Group Code
    		List<CmCmmCdVO> rsdtTypCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, ""); 
    		model.addAttribute("rsdtTypCd", rsdtTypCd); 
    		
    		cmCmmCd.setGrpCd("5"); // Setting Group Code
    		List<CmCmmCdVO> eduCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("eduCd", eduCd);
    		
    		cmCmmCd.setGrpCd("68"); // Setting Group Code
    		List<CmCmmCdVO> dsbtCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("dsbtCd", dsbtCd);
    		
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd));
    		EgovMap ems = cmmCdManagerService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAdCd", ems);
    		
    		String rsdtSeq = null;
    		boolean flag = true;
    		String viewRsdtNo = "";
    		if(vo != null){
    			viewRsdtNo = vo.getViewRsdtNo();
    			vo.setViewRsdtNo(NidStringUtil.toNumberConvet(vo.getViewRsdtNo(), "g"));
    			if(vo.getViewRsdtNo() != null && !vo.getViewRsdtNo().equals("")){
    				EgovMap egov = service.searchRsdtInfrCrdExpiry(vo.getViewRsdtNo());
    				if(egov != null){
    					Object obj = egov.get("expiryYn");
    					Object obj2 = egov.get("expiryDayYn");
    					Object obj3 = egov.get("expiryDay");
    					Object obj4 = egov.get("crdExpiryDdCom");
    					Object obj5 = egov.get("mon");
    					if(obj != null && obj instanceof String && obj2 != null && obj2 instanceof String && obj3 != null && obj3 instanceof BigDecimal && obj4 != null && obj4 instanceof String && obj5 != null && obj5 instanceof BigDecimal){
    						String expiryYn = (String)obj;
    						String expiryDayYn = (String)obj2;
    						//int expiryDay = ((BigDecimal)obj3).intValue();
    						//String crdExpiryDdCom = (String)obj4;
    						//int mon = ((BigDecimal)obj5).intValue();
    						String crdReisuceDmBfExpr = String.valueOf(propertiesService.getInt("crdReisuceDmBfExpr"));
    						int expr = -1;
    						try{
    							expr = Integer.parseInt(crdReisuceDmBfExpr);
    						}catch(NumberFormatException nfe){
    							expr = 1;
    							crdReisuceDmBfExpr = String.valueOf(expr);
    						}
    						if(expiryYn != null && "Y".equals(expiryYn)){
    							//mon = 0;
    							model.addAttribute("resultMsg", nidMessageSource.getMessage("crdExpReisuce.msg", new String[]{String.valueOf(crdReisuceDmBfExpr)} ));
    						}else if(expiryDayYn != null && "Y".equals(expiryDayYn)){
    							model.addAttribute("resultMsg", nidMessageSource.getMessage("crdExpReisuce.msg", new String[]{String.valueOf(crdReisuceDmBfExpr)} ));
    						}
    					}
    				}
    				rsdtSeq = service.searchRsdtInfrSeq(vo);
    				if(rsdtSeq == null){
    					flag = false;
    					
    					if(!flag){
    						RsdtMdfcVO mdfcVO = new RsdtMdfcVO();
    						mdfcVO.setViewRsdtNo(vo.getViewRsdtNo());
    						mdfcVO = service.searchRsdtMdfcSeqIsFlag(mdfcVO);
    						if(mdfcVO != null && mdfcVO.getRsdtSeqNo() != null){
    							rsdtSeq = mdfcVO.getRsdtSeqNo();
    							flag = true;
    						}
    					}
    					
    				}
    			}else{
    				if(vo.getDescRsdtSeqNo() != null && !vo.getDescRsdtSeqNo().equals("")){
    					rsdtSeq = vo.getDescRsdtSeqNo();
    				}
    			}
    		}
    		
    		if(flag && rsdtSeq != null && rsdtSeq.length() > 0){
    			RsdtMdfcVO isFlag = new RsdtMdfcVO();
        		isFlag.setRsdtSeqNo(rsdtSeq);
    			int count = service.searchRsdtMdfcChngIsFlag(isFlag);
    			
    			model.addAttribute("bthRgstFlag", "");
    			if(count == 0){
    				vo.setRsdtSeqNo(rsdtSeq);
    				count = service.searchBthRgst(vo);
    				model.addAttribute("bthRgstFlag", count);
    			}
    			
        		if(count == 1){
        			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
        			RsdtMdfcVO tmp = new RsdtMdfcVO();
        			tmp.setDescRsdtSeqNo(rsdtSeq);
        			tmp.setTamCd(user.getTamCdNm());
        			tmp.setViewRsdtNo(vo.getViewRsdtNo());
        			EgovMap result = service.searchRsdtMdfc(tmp);
        			
        			//Must check whether other institutions registered.
        			//Registered in the same team, just to show
        			
        			String orgnzCd = user.getOrgnzCd();
            		String rgstOrgnzCd = user.getOrgnzClsCd()+orgnzCd;
            		
            		RsdtMdfcVO regFlag = new RsdtMdfcVO();
            		regFlag.setRsdtSeqNo(((BigDecimal)result.get("rsdtSeqNo")).toString());
            		regFlag.setRgstOrgnzCd(rgstOrgnzCd);
            		regFlag.setUseLangCd(user.getUseLangCd());
            		regFlag.setTamCd(user.getTamCdNm());
            		//Registered in the same team, just to show the end.
        			int seqCount = 0;
        			int seqSubCount = 0;
        			String tamCount ="";
        			String orgnzCdNm = "";
        			EgovMap regIsFlag = service.searchRsdtMdfcRgstIsFlag(regFlag);
        			if(regIsFlag != null && !regIsFlag.isEmpty()){
        				BigDecimal seqNo = (BigDecimal)regIsFlag.get("rsdtSeqNo");
        				BigDecimal seqNoSub = (BigDecimal)regIsFlag.get("rsdtSeqNoSub");
        				orgnzCdNm = (String)regIsFlag.get("orgnzCd");
        				tamCount= (String)regIsFlag.get("tamCd");
        				seqCount = seqNo.intValue();
        				seqSubCount = seqNoSub.intValue();
        			}
        			if(seqCount == 1 && seqSubCount == 0){
        				model.addAttribute("resultMsg", "regIsFlag");
        				model.addAttribute("orgnzCdNm", orgnzCdNm);
        				model.addAttribute("tamCount", tamCount);
        			}else{
        				if(result != null && result.get("crdIsuStusMsg") != null && !"".equals((String)result.get("crdIsuStusMsg")) ){
        					model.addAttribute("resultMsg", nidMessageSource.getMessage((String)result.get("crdIsuStusMsg")));
        				}else{
        					Object obj = model.get("resultMsg");
        					
        					if(obj != null && result.get("mdfctSeqNo") != null){
        						model.remove("resultMsg");
        						obj = null;
        					}
        					
        	    			if(obj == null){
			        			model.addAttribute("resultVO", result);
			        			EgovMap resultEm = service.searchListRsdtMdfcNatFrgnLang(tmp);
			        			if(resultEm != null && !resultEm.isEmpty()){
			        				List<EgovMap> em = null;
			        				em = (List<EgovMap>)resultEm.get("othrNatLangList");
			        				model.addAttribute("othrNatLangList", em);
			        				em = (List<EgovMap>)resultEm.get("afOthrNatLangList");
			        				model.addAttribute("afOthrNatLangList", em);
			        				em = (List<EgovMap>)resultEm.get("frgnLangList");
			        				model.addAttribute("frgnLangList", em);
			        				em = (List<EgovMap>)resultEm.get("afFrgnLangList");
			        				model.addAttribute("afFrgnLangList", em);
			        			}
			        			if(result != null && result.get("rsdtSeqNo") != null && result.get("mdfctSeqNo") != null){
			        				tmp.setRsdtSeqNo(((BigDecimal)result.get("rsdtSeqNo")).toString());
			        				tmp.setMdfctSeqNo(((BigDecimal)result.get("mdfctSeqNo")).toString());
			        				EgovMap changeFlag = service.searchRsdtMdfcChngFieldFlag(tmp);
			        				model.addAttribute("changeFlag", changeFlag);
			        			}
			        			
			        			String rsdtSeqNo = getEgovMapValue(result, "rsdtSeqNo");
			        			String spusRsdtSeqNo = getEgovMapValue(result, "spusRsdtSeqNo");
			        			RsdtMdfcVO vos = new RsdtMdfcVO();
			        			vos.setHsbdRsdtSeqNo(spusRsdtSeqNo);
			        			vos.setWifeRsdtSeqNo(rsdtSeqNo);
			        			int mrrgDvrcCnt = service.searchListMdfcMrrgDvrc(vos);
			        			model.addAttribute("mrrgDvrcCnt", mrrgDvrcCnt);
			        			
			        			model.addAttribute("useLangCd", user.getUseLangCd());
			        			model.addAttribute("userId", user.getUserId());
			        			
			        			//String mdfctSeqNo
			        			Object mdfcSeq = result.get("bsnSeqNo");
			        			String mdfctSeqNo = null;
			        			if(mdfcSeq != null){
			        				if(mdfcSeq instanceof String){
			        					mdfctSeqNo = (String)mdfcSeq;
			        				}else if(mdfcSeq instanceof BigDecimal){
			        					mdfctSeqNo = ((BigDecimal)mdfcSeq).toString();
			        				}
			        			}else{
			        				mdfctSeqNo = "";
			        			}
			        			//error msg
			        			if(result.get("mdfctSeqNo") == null || (mdfcSeq != null && mdfctSeqNo != null && !"".equals(mdfctSeqNo))){
				        			EgovMap errorMsg = service.searchRsdtInfrCrdProcErr((String)result.get("rsdtNo"), mdfctSeqNo);
			        				model.addAttribute("errorMsg", errorMsg);
			        			}
			        			
			        			int frgnInt = propertiesService.getInt("frgnLangOthrLangRgstNo");
		        		        model.addAttribute("frgnLangOthrLangRgstNo", frgnInt);
		        		        
		        		        int alwWifeNo = propertiesService.getInt("alwWifeNo");
		        		        model.addAttribute("alwWifeNo", alwWifeNo);
			        			
		        		        ComDefaultVO comVo = new ComDefaultVO();
			            		comVo = nidCommonService.searchPerToDay(vo);
			            		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
			            		
			            		comVo = nidCommonService.searchGreToDay(vo);
			            		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
			            		
			            		int koUprCd = propertiesService.getInt("kochiUprAdCd");
			    	    		model.addAttribute("koUprCd", koUprCd);
			    	    		
			        			vo.setBioKey((String)result.get("bioKey"));
			        			vo.setRsdtNo((String)result.get("rsdtNo"));
			        			vo.setUserId(user.getUserId());
			        			if((vo.getRsdtSeqNo() == null || "".equals(vo.getRsdtSeqNo())) && (vo.getMdfctSeqNo() == null || "".equals(vo.getMdfctSeqNo()))){
			        				vo.setRsdtSeqNo(((BigDecimal)result.get("rsdtSeqNo")).toString());
			        				if(result.get("mdfctSeqNo") != null){
			        					vo.setMdfctSeqNo(((BigDecimal)result.get("mdfctSeqNo")).toString());
			        				}
			        			}
			        			model.addAttribute("bioInfo", service.searchBioInfr(vo));
			        			
			        			
			        			int femlMrrgAge = propertiesService.getInt("femlMrrgAge");
		        		        model.addAttribute("femlMrrgAge", femlMrrgAge);
		        		        int mlMrrgAge = propertiesService.getInt("mlMrrgAge");
		        		        model.addAttribute("mlMrrgAge", mlMrrgAge);
			        			
        	    			}
        				}
        			}
        		}else{
        			model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstByIsuce.msg"));
        		}
    		}else{
    			Object obj = model.get("resultMsg");
    			if(obj == null){
    				model.addAttribute("resultMsg", nidMessageSource.getMessage("nCtznHst.msg"));
    			}
    		}
    		vo.setViewRsdtNo(viewRsdtNo);
    	}catch(Exception e){
    		if(e instanceof IOException || e instanceof ConnectException || e instanceof BaseException){
    			model.addAttribute("timeout", "Y");
    		}else{
    			model.addAttribute("resultMsgs", new ErrorHandler(e).getLoadMessage());
    		}
    		log.error(e.getMessage(), e);
    		
    	}
        return "/rm/rsdt/RsdtMdfcIns";
    }
    
    
    
    
    /**
     * Residents save updated data. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/rsdt/RsdtMdfcIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/addRsdtMdfc.do")
    public String addRsdtMdfc(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtMdfcVO") RsdtMdfcVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		if(!"Y".equals(vo.getAfEduLvDocYn())){
    			vo.setAfEduLvDocYn("N");
    		}
    		
    		if(!"Y".equals(vo.getAfBldTyeDocYn())){
    			vo.setAfBldTyeDocYn("N");
    		}
    		
    		if(!"Y".equals(vo.getRsdtCfmYn())){
    			vo.setRsdtCfmYn("N");
    		}
    		
    		boolean result = service.addRsdtMdfc(vo);
    		if(result){
    			//model.addAttribute("rsdtMdfcVO", vo);
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}
    		
    		boolean chipResult = service.searchIsChipWriteFlag(vo, false, "");
    		if(chipResult){
    			String param = vo.getGivNm() + " " + vo.getSurnm();
    			param = param.trim();
    			model.addAttribute("resultChipMsg", nidMessageSource.getMessage("datSavWithWriteVal.msg", new String[]{param} ));
    		}
    		
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "forward:/rm/rsdt/searchRsdtMdfc.do";
    }
    
    
    
    
    
    
    /**
     * Updated list of approved residents to move to the screen.  <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/RsdtMdfcAprvList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/rsdt/searchListRsdtMdfcAprvView.do")
    public String searchListRsdtMdfcAprvView (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtMdfcVO") RsdtMdfcVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
    		
    		//String orgnzCd = user.getOrgnzCd();
    		//String district = orgnzCd.substring(0, 4); //String str1 = "L123456789"; 467
    		//String teamCd = user.getTamCdNm();
    		//searchVO.setSearchKeyword7(district);
    		//searchVO.setSearchKeyword8(teamCd);
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("gdrCd", gdrCd);
    		searchVO.setSearchKeyword6("N");
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/rsdt/RsdtMdfcAprvList";   	
    }
	
	
	/**
     * Retrieves list of program.  <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/RsdtMdfcAprvList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/rsdt/searchListRsdtMdfcAprv.do")
    public String searchListRsdtMdfcAprv (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtMdfcVO") RsdtMdfcVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		String orgnzCd = user.getOrgnzCd();
    		//String district = orgnzCd.substring(0, 4); //String str1 = "L123456789"; 467
    		//String teamCd = user.getTamCdNm();
    		//searchVO.setSearchKeyword7(district);
    		//searchVO.setSearchKeyword8(teamCd);
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("gdrCd", gdrCd);
    		
    		vo.setUseLangCd(user.getUseLangCd());
    		//Registered in the same team, just to show
    		String rgstOrgnzCd = user.getOrgnzClsCd()+orgnzCd;
    		vo.setRgstOrgnzCd(rgstOrgnzCd);
    		//Registered in the same team, just to show the end.
    		
    		
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));

	    	//** pageing *//*
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());

			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

			vo.setAprvListTm(String.valueOf(propertiesService.getInt("aprvListTm")));
			
	        List<EgovMap> lstProgram = service.searchListRsdtMdfcAprv(vo);
	        model.addAttribute("lstProgram", lstProgram);

	        int totCnt = service.searchListRsdtMdfcAprvTotCn(vo);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/rsdt/RsdtMdfcAprvList";   	
    }
	
	
	
	/**
     * Retrieves detail of program.  <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/RsdtMdfcAprvUdt.jsp"
     * @exception Exception
     */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/rm/rsdt/searchRsdtMdfcAprv.do")
    public String searchRsdtMdfcAprv (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtMdfcVO") RsdtMdfcVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> bldTyeCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("bldTyeCd", bldTyeCd); 
    		cmCmmCd.setGrpCd("12"); // Setting Group Code
    		List<CmCmmCdVO> mrrgCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("mrrgCd", mrrgCd); 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);
    		model.addAttribute("gdrCd", gdrCd);
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		List<CmCmmCdVO> etncityCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("etncityCd", etncityCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> fmlyLangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("fmlyLangCd", fmlyLangCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> nallangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("nallangCd", nallangCd);
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		List<CmCmmCdVO> rlgnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("rlgnCd", rlgnCd);
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		List<CmCmmCdVO> rlgnSect = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("rlgnSect", rlgnSect);
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		List<CmCmmCdVO> mltSrvcCd = NidStringUtil.setListReverse( cmmCdManagerService.searchListCmmCd(cmCmmCd) );
    		model.addAttribute("mltSrvcCd", mltSrvcCd);
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("nltyCd", nltyCd);
    		cmCmmCd.setGrpCd("8"); // Setting Group Code
    		List<CmCmmCdVO> frgnLang = cmmCdManagerService.searchListCmmCd(cmCmmCd);
    		model.addAttribute("frgnLang", frgnLang);
    		
    		cmCmmCd.setGrpCd("9"); // Setting Group Code
    		List<CmCmmCdVO> codeLst = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, ""); 
    		model.addAttribute("rlCd", codeLst); 
    		
    		cmCmmCd.setGrpCd("64"); // Setting Group Code
    		List<CmCmmCdVO> rsdtTypCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, ""); 
    		model.addAttribute("rsdtTypCd", rsdtTypCd); 
    		
    		cmCmmCd.setGrpCd("5"); // Setting Group Code
    		List<CmCmmCdVO> eduCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("eduCd", eduCd);
    		
    		cmCmmCd.setGrpCd("68"); // Setting Group Code
    		List<CmCmmCdVO> dsbtCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("dsbtCd", dsbtCd);
    		
    		int kochiAdCd = propertiesService.getInt("kochiAdCd");
    		cmCmmCd.setCmmCd(String.valueOf(kochiAdCd));
    		EgovMap ems = cmmCdManagerService.searchAdCdNm(cmCmmCd);
    		model.addAttribute("kochiAdCd", ems);
    		
    		vo.setDescRsdtSeqNo(vo.getRsdtSeqNo());
    		
    		EgovMap result = service.searchRsdtMdfcAprv(vo);
			model.addAttribute("resultVO", result);
						
			EgovMap resultEm = service.searchListRsdtMdfcNatFrgnLang(vo);
			
			if(resultEm != null && !resultEm.isEmpty()){
				List<EgovMap> em = null;
				em = (List<EgovMap>)resultEm.get("othrNatLangList");
				model.addAttribute("othrNatLangList", em);
				em = (List<EgovMap>)resultEm.get("afOthrNatLangList");
				model.addAttribute("afOthrNatLangList", em);
				em = (List<EgovMap>)resultEm.get("frgnLangList");
				model.addAttribute("frgnLangList", em);
				em = (List<EgovMap>)resultEm.get("afFrgnLangList");
				model.addAttribute("afFrgnLangList", em);
			}
			
			if(vo != null && vo.getRsdtSeqNo() != null && vo.getMdfctSeqNo() != null){
				EgovMap changeFlag = service.searchRsdtMdfcChngFieldFlag(vo);
				model.addAttribute("changeFlag", changeFlag);
			}
			
			String rsdtSeqNo = getEgovMapValue(result, "rsdtSeqNo");
			String spusRsdtSeqNo = getEgovMapValue(result, "spusRsdtSeqNo");
			RsdtMdfcVO vos = new RsdtMdfcVO();
			vos.setHsbdRsdtSeqNo(spusRsdtSeqNo);
			vos.setWifeRsdtSeqNo(rsdtSeqNo);
			int mrrgDvrcCnt = service.searchListMdfcMrrgDvrc(vos);
			model.addAttribute("mrrgDvrcCnt", mrrgDvrcCnt);
			
			boolean flag = service.searchRsdtMdfcCrdIssTo(vo);
    		if(flag){
    			model.addAttribute("resultCrdMsg", nidMessageSource.getMessage("reisuceByInfrChng.msg"));
    		}
    		
    		int count = service.searchRsdtMdfcChngIsFlag(vo);
    		
    		
    		model.addAttribute("bthRgstFlag", "");
			if(count == 0){
				count = service.searchBthRgst(vo);
				model.addAttribute("bthRgstFlag", count);
			}
    		
    		if(count == 0){
    			model.addAttribute("resultMsgIsFlag", nidMessageSource.getMessage("nRgstByIsuce.msg"));
    			model.addAttribute("isFlag", "Y");
    		}
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		
    		model.addAttribute("useLangCd", user.getUseLangCd());
			model.addAttribute("userId", user.getUserId());
			
			
			//String mdfctSeqNo
			Object mdfcSeq = result.get("bsnSeqNo");
			String mdfctSeqNo = null;
			if(mdfcSeq != null){
				if(mdfcSeq instanceof String){
					mdfctSeqNo = (String)mdfcSeq;
				}else if(mdfcSeq instanceof BigDecimal){
					mdfctSeqNo = ((BigDecimal)mdfcSeq).toString();
				}
			}else{
				mdfctSeqNo = "";
			}
			//error msg
			if(result.get("mdfctSeqNo") == null || (mdfcSeq != null && mdfctSeqNo != null && !"".equals(mdfctSeqNo))){
				EgovMap errorMsg = service.searchRsdtInfrCrdProcErr((String)result.get("rsdtNo"), mdfctSeqNo);
				model.addAttribute("errorMsg", errorMsg);
			}
			
			int frgnInt = propertiesService.getInt("frgnLangOthrLangRgstNo");
	        model.addAttribute("frgnLangOthrLangRgstNo", frgnInt);
    		
    		vo.setDescRsdtSeqNo("");
    		vo.setBioKey((String)result.get("bioKey"));
			vo.setRsdtNo((String)result.get("rsdtNo"));
			vo.setUserId(user.getUserId());
			
			int alwWifeNo = propertiesService.getInt("alwWifeNo");
		    model.addAttribute("alwWifeNo", alwWifeNo);
			
			
			ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		
    		int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    		if(result.get("tamLedrCfmYn") != null && "N".equals((String)result.get("tamLedrCfmYn"))){
				model.addAttribute("bioInfo", service.searchBioInfr(vo));
			}
			
    		int femlMrrgAge = propertiesService.getInt("femlMrrgAge");
	        model.addAttribute("femlMrrgAge", femlMrrgAge);
	        int mlMrrgAge = propertiesService.getInt("mlMrrgAge");
	        model.addAttribute("mlMrrgAge", mlMrrgAge);
	        
    	} catch (Exception e) {
    		if(e instanceof IOException || e instanceof ConnectException || e instanceof BaseException){
    			model.addAttribute("timeout", "Y");
    		}else{
    			model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    		}
    		log.error(e.getMessage(), e);
    		
    	}
   		return "/rm/rsdt/RsdtMdfcAprvUdt";   	
    }
    
	/**
     * Retrieves update of program.  <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/RsdtMdfcAprvUdt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/rsdt/modifyRsdtMdfc.do")
    public String modifyRsdtMdfc (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtMdfcVO") RsdtMdfcVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		
    		if(!"Y".equals(vo.getAfEduLvDocYn())){
    			vo.setAfEduLvDocYn("N");
    		}
    		
    		if(!"Y".equals(vo.getAfBldTyeDocYn())){
    			vo.setAfBldTyeDocYn("N");
    		}
    		
    		if(!"Y".equals(vo.getRsdtCfmYn())){
    			vo.setRsdtCfmYn("N");
    		}
    		
    		boolean result = service.modifyRsdtMdfcVfy(vo);
    		if(result){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg"));
    		}else{
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("udtFail.msg"));
    		}
    		
    		boolean chipResult = service.searchIsChipWriteFlag(vo, false, "");
    		if(chipResult){
    			String param = vo.getGivNm() + " " + vo.getSurnm();
    			param = param.trim();
    			model.addAttribute("resultChipMsg", nidMessageSource.getMessage("datSavWithWriteVal.msg", new String[]{param} ));
    		}
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "forward:/rm/rsdt/searchRsdtMdfcAprv.do";   	
    }
	/**
     * Retrieves Approved of program.  <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/RsdtMdfcAprvUdt.jsp"
     * @exception Exception
     */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/rm/rsdt/aprvRsdtMdfc.do")
    public String aprvRsdtMdfc (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtMdfcVO") RsdtMdfcVO vo,
    		ModelMap model)
            throws Exception {
		String returnPage = "forward:/rm/rsdt/searchRsdtMdfcAprv.do";
    	try {
    		int count = service.searchRsdtMdfcChngIsFlag(vo);
    		
    		model.addAttribute("bthRgstFlag", "");
			if(count == 0){
				count = service.searchBthRgst(vo);
				model.addAttribute("bthRgstFlag", count);
			}
    		
    		if(count != 0){
    			
        		if(!"Y".equals(vo.getAfEduLvDocYn())){
        			vo.setAfEduLvDocYn("N");
        		}
        		
        		if(!"Y".equals(vo.getAfBldTyeDocYn())){
        			vo.setAfBldTyeDocYn("N");
        		}
        		
        		if(!"Y".equals(vo.getRsdtCfmYn())){
        			vo.setRsdtCfmYn("N");
        		}  
        		EgovMap apEm = service.aprvRsdtMdfc(vo);
        		ArrayList<String> result = null;
        		if(apEm != null && !apEm.isEmpty()){
        			Object obj = apEm.get("result");
        			if(obj != null && obj instanceof ArrayList){
        				result = (ArrayList<String>)obj;
        			}
        			
        			obj = apEm.get("bioEm");
        			if(obj != null && obj instanceof EgovMap){
        				EgovMap em = (EgovMap)obj;
        				bioIfService.addBioInterfaceLog(em);
        			}
        			
        			if(!"".equals(result.get(0))){
            			model.addAttribute("printFlag", result.get(0));        			        			
            		}
            		if(!"".equals(result.get(1))){
            			model.addAttribute("crdFndList", result.get(1));        			        			
            		}
            		if("OK".equals(result.get(2))){
            			model.addAttribute("resultMsg", nidMessageSource.getMessage("apvScsfl.msg"));
            		}else{
            			String helpTelNo = nidMessageSource.getMessage("admTelNo");
            			model.addAttribute("resultMsg", nidMessageSource.getMessage("apvFail.msg", new String[]{helpTelNo}));
            		}
            		boolean chipResult = service.searchIsChipWriteFlag(vo, true, result.get(3));
            		if(chipResult){
            			String param = vo.getGivNm() + " " + vo.getSurnm();
            			param = param.trim();
            			model.addAttribute("resultChipMsg", nidMessageSource.getMessage("datSavWithWriteVal.msg", new String[]{param} ));
            		}
            		returnPage = "forward:/rm/rsdt/searchListRsdtMdfcAprv.do";
        		}else{
        			String helpTelNo = nidMessageSource.getMessage("admTelNo");
        			model.addAttribute("resultMsg", nidMessageSource.getMessage("apvFail.msg", new String[]{helpTelNo}));
        		}
    		}
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		if(e instanceof IOException){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nValdBioInfr.msg"));
    		}else if(e instanceof NidException){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nValdBioInfr.msg"));
    		} else if( "mrrgEror".equals(e.getMessage()) ){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nChngSpusNm.msg")); 
    		}else{
	    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    		}
    	}
   		return returnPage;
    }
	
	
	
	
	
	
	
	/**
     * Replacement card receipts of program.  <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/p_RsdtMdfcRcpt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/rsdt/searchRsdtMdfcRcpt.do")
    public String searchRsdtMdfcRcpt (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtMdfcVO") RsdtMdfcVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
       		vo.setUseLangCd(user.getUseLangCd());
    		
    		EgovMap result = service.searchRsdtMdfcCfmRcpt(vo);
			model.addAttribute("resultVO", result);
			
			List<EgovMap> list = service.searchRsdtMdfcOthrCfmRcpt(vo);
			model.addAttribute("othrNatLangList", list);
			
			list = service.searchRsdtMdfcFrgnCfmRcpt(vo);
			model.addAttribute("frgnLangList", list);
			
			model.addAttribute("useLangCd", user.getUseLangCd());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/rsdt/p_RsdtMdfcRcpt";   	
    }
	
	
	/**
     * Receipt for Citizen Confirmation <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/p_RsdtMdfcCfmRcpt.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/rsdt/searchRsdtMdfcCfmRcpt.do")
    public String searchRsdtMdfcCfmRcpt (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtMdfcVO") RsdtMdfcVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
       		vo.setUseLangCd(user.getUseLangCd());
    		
    		EgovMap result = service.searchRsdtMdfcCfmRcpt(vo);
			model.addAttribute("resultVO", result);
			
			List<EgovMap> list = service.searchRsdtMdfcOthrCfmRcpt(vo);
			model.addAttribute("othrNatLangList", list);
			
			list = service.searchRsdtMdfcFrgnCfmRcpt(vo);
			model.addAttribute("frgnLangList", list);
			
			model.addAttribute("useLangCd", user.getUseLangCd());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/rsdt/p_RsdtMdfcCfmRcpt";   	
    }
	
	/**
     * On receipt of a replacement card image output.  <br>
     *
     * @param bioKey Value-object of program to be parsed request(String)
     * @param rsdtNo Value-object of program to be parsed request(String)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
	@RequestMapping(value="/rm/rsdt/searchRmImgView.do")
    public void searchRmImgView (
    		@RequestParam(value="bioKey" ,required=false) String bioKey,
    		@RequestParam(value="rsdtNo" ,required=false) String rsdtNo,
    		HttpServletResponse response
    		)
            throws Exception {
		OutputStream output = null;
    	try {
    		RsdtMdfcVO vo = new RsdtMdfcVO();
    		vo.setBioKey(bioKey);
    		vo.setRsdtNo(rsdtNo);
    		EgovMap map = service.searchRmImgView(vo);
    		if(map != null && !map.isEmpty()){
    			byte [] phImg = (byte[])map.get("phImg");
    			if(phImg != null){
	    			output = response.getOutputStream(); 
	    			output.write(phImg); 
	    			output.flush(); 
	    			output.close(); 
	    			response.setContentType("text/html"); 
    			}
    		}
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    	}finally{
    		try{
    			if(output != null){
    				output.close();
    			}
    		}catch(Exception e){
    			log.error(e.getMessage(), e);
    		}
    	}
    }
	
	
	
	
	/**
     * Check expiration date of the card.  <br>
     * 
     * @param vo Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:""
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchRsdtInfrCrdExpiry.do")
    public void searchRsdtInfrCrdExpiry(
    		@RequestParam(value="rsdtNo" ,required=false) String rsdtNo,
			HttpServletResponse response) throws Exception {
    	try {
    		if(rsdtNo != null){
	    		EgovMap egov = service.searchRsdtInfrCrdExpiry(rsdtNo);
	    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
	    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
	    		Document doc = docBuilder.newDocument();
	    		Element root = doc.createElement("root");
	    		doc.appendChild(root);
	    		Element eleInfo = null;
	    		Element ele = null;
    			if(egov != null){
	    			eleInfo = doc.createElement("expiry_infr");
	    			root.appendChild(eleInfo);
	    			ele = doc.createElement("crdExpiryDd");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)egov.get("crdExpiryDd")) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("crdExpiryDdCom");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)egov.get("crdExpiryDdCom")) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("expiryDayYn");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)egov.get("expiryDayYn")) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("expiryDay");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString( (BigDecimal)egov.get("expiryDay") ) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("expiryYn");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)egov.get("expiryYn")) ));
	    			eleInfo.appendChild(ele);
    			}
	    		Properties output = new Properties();
	    	    output.setProperty(OutputKeys.INDENT, "yes");
	    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
	    	    TransformerFactory tf = TransformerFactory.newInstance();
	    		Transformer t = tf.newTransformer();
	    	    t.setOutputProperties(output);
	    		StringWriter sw = new StringWriter();
	    		StreamResult result = new StreamResult(sw);
	    		DOMSource source = new DOMSource(doc);
	    		t.transform(source, result);    		
	    		response.setContentType("text/xml; charset=utf-8");
	    		response.getWriter().write(sw.toString());
    		}
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    	}
    }
	
 	/**
     * Residents move to display information changes. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param rsdtMdfcVO Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/RsdtMdfcIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchListRsdtNmFndView.do")
    public String searchListRsdtNmFndView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtMdfcVO") RsdtMdfcVO rsdtNmFndVo,
    		@RequestParam(value="fndTye" ,required=false) String fndTye,
    		@RequestParam(value="selfRsdtSeqNo" ,required=false) String selfRsdtSeqNo,
    		@RequestParam(value="selfFmlyBokNo" ,required=false) String selfFmlyBokNo,
    		@RequestParam(value="srchBthDd" ,required=false) String srchBthDd,
    		@RequestParam(value="srchCalTye" ,required=false) String srchCalTye,
    		@RequestParam(value="rlCd" ,required=false) String rlCd,
    		@RequestParam(value="fgmhRsdtSeqNo" ,required=false) String fgmhRsdtSeqNo,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		log.debug("searchListRsdtNmFndView xxxx");
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		rsdtNmFndVo.setUseLangCd(user.getUseLangCd());    		
    		rsdtNmFndVo.setSearchKeyword("1");
    		rsdtNmFndVo.setFndTye(fndTye);
    		rsdtNmFndVo.setSelfRsdtSeqNo(selfRsdtSeqNo);
    		rsdtNmFndVo.setSrchBthDd(srchBthDd);
    		rsdtNmFndVo.setSrchCalTye(srchCalTye);
    		rsdtNmFndVo.setSearchKeyword9(srchCalTye);
    		rsdtNmFndVo.setRlCd(rlCd);
    		
    		model.addAttribute("useLangCd", user.getUseLangCd());
    		
    		if(selfFmlyBokNo != null && selfFmlyBokNo.length() > 10 && rsdtNmFndVo != null){
    			
    			rsdtNmFndVo.setSearchKeyword4(selfFmlyBokNo.substring(0, 4));
    			rsdtNmFndVo.setSearchKeyword5(selfFmlyBokNo.substring(4, 6));
    			rsdtNmFndVo.setSearchKeyword6(selfFmlyBokNo.substring(6, 11));
    		}

    		log.debug("searchListRsdtNmFndView start");
    		rsdtNmFndVo.setPageUnit(5);
    		rsdtNmFndVo.setPageSize(propertiesService.getInt("pageSize"));
	    	//** pageing *//*
	    	PaginationInfo paginationInfo = new PaginationInfo();			
			paginationInfo.setRecordCountPerPage(rsdtNmFndVo.getPageUnit());
			paginationInfo.setPageSize(rsdtNmFndVo.getPageSize());
			rsdtNmFndVo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			rsdtNmFndVo.setLastIndex(paginationInfo.getLastRecordIndex());
			rsdtNmFndVo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
			
			RsdtInfrVO infrVo = new RsdtInfrVO();
			infrVo.setFmlyBokNo(selfFmlyBokNo);
			infrVo.setRlCd(rlCd);
    		RsdtInfrVO agGap = rsdtInfoService.searchAgGap(infrVo);
    		
			if("1".equals(rsdtNmFndVo.getFndTye())){
				rsdtNmFndVo.setSrchAgGap(agGap.getFthrAgGap());
			} else if ("4".equals(rsdtNmFndVo.getFndTye())){
				rsdtNmFndVo.setSrchAgGap(agGap.getGfthrAgGap());
			} else if ("2".equals(rsdtNmFndVo.getFndTye())){
				rsdtNmFndVo.setSrchAgGap(agGap.getMthrAgGap());
			} 
			
			rsdtNmFndVo.setFgmhRsdtSeqNo(fgmhRsdtSeqNo);
			
			List<RsdtMdfcVO> lstProgram = null;
			int totCnt = 0;
			int mberRowNum =1;
			int firstIndex = 0;
			
	        if(fgmhRsdtSeqNo == null || "".equals(fgmhRsdtSeqNo)){
	        	rsdtNmFndVo.setSearchKeyword("3");
	        } else {
	        	int mberCnt = service.searchMber(rsdtNmFndVo);
	        	
	        	if(mberCnt > 0){
	        		rsdtNmFndVo.setSearchKeyword("2");
	        		
        			mberRowNum =  service.searchMberRowNum(rsdtNmFndVo);      
        			
        			if( (mberRowNum % rsdtNmFndVo.getRecordCountPerPage()) == 0 ){
        				firstIndex = (mberRowNum / rsdtNmFndVo.getRecordCountPerPage()) - 1;
        			} else {
        				firstIndex = mberRowNum / rsdtNmFndVo.getRecordCountPerPage();
        			}
        			rsdtNmFndVo.setFirstIndex(firstIndex * rsdtNmFndVo.getRecordCountPerPage()); 
        			
	        		lstProgram = service.searchListRsdtNmFnd(rsdtNmFndVo);
	        		totCnt = service.searchListRsdtNmFndTotCn(rsdtNmFndVo);
	        	} else {
	        		RsdtMdfcVO mber = service.searchMberRsdtNo(rsdtNmFndVo);
	        		if(mber != null){
		        		if("".equals(mber.getRsdtNo())){
		        			rsdtNmFndVo.setSearchKeyword("2");	        			
		        			rsdtNmFndVo.setSearchKeyword4(mber.getFmlyBokNo().substring(0, 4));
		        			rsdtNmFndVo.setSearchKeyword5(mber.getFmlyBokNo().substring(4, 6));
		        			rsdtNmFndVo.setSearchKeyword6(mber.getFmlyBokNo().substring(6, 11));
		        			
		        			mberRowNum =  service.searchMberRowNum(rsdtNmFndVo);   

		        			if( (mberRowNum % rsdtNmFndVo.getRecordCountPerPage()) == 0 ){
		        				firstIndex = (mberRowNum / rsdtNmFndVo.getRecordCountPerPage()) - 1;
		        			} else {
		        				firstIndex = mberRowNum / rsdtNmFndVo.getRecordCountPerPage();
		        			}
		        			rsdtNmFndVo.setFirstIndex(firstIndex * rsdtNmFndVo.getRecordCountPerPage()); 		        			
		        					
			        		lstProgram = service.searchListRsdtNmFnd(rsdtNmFndVo);
			        		totCnt = service.searchListRsdtNmFndTotCn(rsdtNmFndVo);	        			
		        		} else {
		        			rsdtNmFndVo.setSearchKeyword("1");
		        			rsdtNmFndVo.setSearchKeyword2(mber.getRsdtNo());
		        			rsdtNmFndVo.setSearchKeyword3(mber.getRsdtNm());
		        		}	        			
	        		}
	        	}
	        }
			
	        int curtPage = (mberRowNum / rsdtNmFndVo.getRecordCountPerPage()) + 1;
    		paginationInfo.setCurrentPageNo(curtPage);
    		
	        model.addAttribute("lstProgram", lstProgram);	        
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        
	        model.addAttribute("fgmhRsdtSeqNo", fgmhRsdtSeqNo);
	        model.addAttribute("rsdtNmFndVo", rsdtNmFndVo);
	        
	        log.debug("searchListRsdtNmFndView end");
    		
    	}catch(Exception e){
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    		log.debug(e.getMessage());
    	}
        return "/rm/rsdt/p_RsdtNmFndList";
    }	
   	
 	/**
     * Residents move to display information changes. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param rsdtMdfcVO Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/RsdtMdfcIns.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchListRsdtNmFnd.do")
    public String searchListRsdtNmFnd(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtNmFndVo") RsdtMdfcVO rsdtNmFndVo,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		rsdtNmFndVo.setUseLangCd(user.getUseLangCd());    	
    		//vo.setOrgnzCd(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());
    		
    		if("".equals(rsdtNmFndVo.getSearchKeyword9())){
    			rsdtNmFndVo.setSearchKeyword9("j");    			
    		}
    		
    		rsdtNmFndVo.setPageUnit(5);
    		rsdtNmFndVo.setPageSize(propertiesService.getInt("pageSize"));
	    	//** pageing *//*
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(rsdtNmFndVo.getPageIndex());
			paginationInfo.setRecordCountPerPage(rsdtNmFndVo.getPageUnit());
			paginationInfo.setPageSize(rsdtNmFndVo.getPageSize());
			rsdtNmFndVo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			rsdtNmFndVo.setLastIndex(paginationInfo.getLastRecordIndex());
			rsdtNmFndVo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
			
			RsdtInfrVO infrVo = new RsdtInfrVO();
			infrVo.setFmlyBokNo(rsdtNmFndVo.getSearchKeyword4()+rsdtNmFndVo.getSearchKeyword5()+rsdtNmFndVo.getSearchKeyword6());
			infrVo.setRlCd(rsdtNmFndVo.getRlCd());
    		RsdtInfrVO agGap = rsdtInfoService.searchAgGap(infrVo);
    		
    		if(agGap != null){
				if("1".equals(rsdtNmFndVo.getFndTye())){
					rsdtNmFndVo.setSrchAgGap(agGap.getFthrAgGap());
				} else if ("4".equals(rsdtNmFndVo.getFndTye())){
					rsdtNmFndVo.setSrchAgGap(agGap.getGfthrAgGap());
				} else if ("2".equals(rsdtNmFndVo.getFndTye())){
					rsdtNmFndVo.setSrchAgGap(agGap.getMthrAgGap());
				}
    		}
    		
	        List<RsdtMdfcVO> lstProgram = service.searchListRsdtNmFnd(rsdtNmFndVo);
	        model.addAttribute("lstProgram", lstProgram);
	        int totCnt = service.searchListRsdtNmFndTotCn(rsdtNmFndVo);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
  		
    		model.addAttribute("useLangCd", user.getUseLangCd());
    		model.addAttribute("rsdtNmFndVo", rsdtNmFndVo);
    		
    	}catch(Exception e){
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/rsdt/p_RsdtNmFndList";
    }
    
    /**
     *Social security number, name search. <br>
     *
     * @param vo Value-object of program to be parsed request(FmlyInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtNmFnd.do")
    public void searchRsdtNm(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtNmFndVo") RsdtMdfcVO rsdtNmFndVo,
    		HttpServletResponse response,
    		ModelMap model)
            throws Exception {
    	try{
    		
    		RsdtMdfcVO rsdtInfr = service.searchRsdtNmFnd(rsdtNmFndVo);
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		
    		String rsdtNm    = "";
    		String rsdtSeqNo = "";
    		String bthDd     = "";
    		String oldAge    = "";
    		String rlCd      = "";
    		String gdrCd     = "";
    		
    		if( rsdtInfr != null ){
    			rsdtNm    = rsdtInfr.getRsdtNm();
    			rsdtSeqNo = rsdtInfr.getRsdtSeqNo();
    			bthDd     = rsdtInfr.getBthDd();
    			oldAge    = rsdtInfr.getOldAge();
    			rlCd      = rsdtInfr.getRlCd();
    			gdrCd     = rsdtInfr.getGdrCd();
    		}
    		
    		Element child = doc.createElement("rsdtNm");
    		child.appendChild(doc.createTextNode(rsdtNm));
    		root.appendChild(child);
    		
    		child = doc.createElement("rsdtSeqNo");
    		child.appendChild(doc.createTextNode(rsdtSeqNo));
    		root.appendChild(child);
    		
    		child = doc.createElement("bthDd");
    		child.appendChild(doc.createTextNode(bthDd));
    		root.appendChild(child);
    		
    		child = doc.createElement("oldAge");
    		child.appendChild(doc.createTextNode(oldAge));
    		root.appendChild(child);
    		
    		child = doc.createElement("rlCd");
    		child.appendChild(doc.createTextNode(rlCd));
    		root.appendChild(child);
    		
    		child = doc.createElement("gdrCd");
    		child.appendChild(doc.createTextNode(gdrCd));
    		root.appendChild(child);    		
    		
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }    
    
    
    /**
     * Check expiration date of the card.  <br>
     * 
     * @param vo Value-object of program to be parsed request(RsdtMdfcVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:""
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchListMdfcMrrgDvrc.do")
    public void searchListMdfcMrrgDvrc(
    		@RequestParam(value="hsbdRsdtSeqNo" ,required=false) String hsbdRsdtSeqNo,
    		@RequestParam(value="wifeRsdtSeqNo" ,required=false) String wifeRsdtSeqNo,
			HttpServletResponse response) throws Exception {
    	try {
    		if(hsbdRsdtSeqNo != null && wifeRsdtSeqNo != null){
    			RsdtMdfcVO vo = new RsdtMdfcVO();
    			vo.setHsbdRsdtSeqNo(hsbdRsdtSeqNo);
    			vo.setWifeRsdtSeqNo(wifeRsdtSeqNo);
	    		int count = service.searchListMdfcMrrgDvrc(vo);
	    		int mrrgCnt = service.searchListMdfcMrrgCnt(vo);
	    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
	    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
	    		Document doc = docBuilder.newDocument();
	    		Element root = doc.createElement("root");
	    		doc.appendChild(root);
	    		Element ele = null;
	    		ele = doc.createElement("count");
	    		ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(new Integer(count) )));
	    		root.appendChild(ele);
	    		
	    		ele = doc.createElement("mrrgCnt");
	    		ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString(new Integer(mrrgCnt) )));
	    		root.appendChild(ele);
    			
	    		Properties output = new Properties();
	    	    output.setProperty(OutputKeys.INDENT, "yes");
	    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
	    	    TransformerFactory tf = TransformerFactory.newInstance();
	    		Transformer t = tf.newTransformer();
	    	    t.setOutputProperties(output);
	    		StringWriter sw = new StringWriter();
	    		StreamResult result = new StreamResult(sw);
	    		DOMSource source = new DOMSource(doc);
	    		t.transform(source, result);    		
	    		response.setContentType("text/xml; charset=utf-8");
	    		response.getWriter().write(sw.toString());
    		}
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    	}
    }
    
    
    /**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param EgovMap, String
	 * @return String
	 * @exception Exception
	 */
	private String getEgovMapValue(EgovMap obj, String value){
		String result = "";
		if(obj != null && !obj.isEmpty() && value != null){
			Object object = obj.get(value);
			if(object != null){
				if(object instanceof BigDecimal){
					BigDecimal big = (BigDecimal)object;
					int bigInt = big.intValue();
					result = String.valueOf(bigInt);
				}else if(object instanceof String){
					result = (String)object;
				}
			}
		}
		return result;
	}
    
    
}