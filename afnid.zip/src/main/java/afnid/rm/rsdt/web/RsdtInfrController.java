package afnid.rm.rsdt.web;

/* java API */
import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.net.ConnectException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import afnid.cm.ComDefaultVO;
import afnid.cm.NidEcptMsgHndlr;
import afnid.cm.NidMessageSource;
import afnid.cm.cmm.service.NidCmmService;
import afnid.cm.code.service.CmCmmCdVO;
import afnid.cm.code.service.CmmCdMngService;
import afnid.cm.log.service.LgService;
import afnid.cm.sec.security.util.NidUserDetailsHelper;
import afnid.cm.uat.service.LgnVO;
import afnid.cm.util.service.NidStringUtil;
import afnid.rm.bioif.service.BioIfInfrService;
import afnid.rm.rsdt.service.RsdtInfrService;
import afnid.rm.rsdt.service.RsdtInfrVO;
import egovframework.rte.fdl.cmmn.exception.BaseException;
import egovframework.rte.fdl.cmmn.exception.EgovBizException;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.psl.dataaccess.util.EgovMap;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;



/** 
 * This Controller class processes request of resident-management and call Interface biz-method. <br>
 * 
 * @author Afghanistan National ID RM Application Team Ha Na YIM
 * @since 2011.04.19
 * @see Ver 1.0.0
 *
 * <pre>
 * << Modification Information >>
 *   
 *   Modified      		Modifiers           						Revisions
 *   2011.04.19  		Ha Na YIM          		                    Create
 *
 * </pre>
 */

@Controller
public class RsdtInfrController {

	/** Log4j Initialize */
	protected Log log = LogFactory.getLog(this.getClass());

	
	/** PropertyService */
    @Resource(name = "propertiesService")
    protected EgovPropertyService propertiesService;
    
    /** NidProgrmManageService */
	@Resource(name = "rsdtInfoService")
    private RsdtInfrService service;
	
    /** CmmCdManagerServiceImpl */
	@Resource(name = "cmmCdMngService")
    private CmmCdMngService cmmCdManagerService;
	
	/** NidCommonService */
	@Resource(name = "nidCmmService")
	private NidCmmService nidCommonService;

	/** NidMessageSource */
    @Resource(name="nidMessageSource")
    NidMessageSource nidMessageSource;
    
    @Resource(name = "lgService")
    private LgService lgService;
    
    @Resource(name = "bioIfInfrService")
    private BioIfInfrService bioIfService;
    
    
    
 	/**
     * Moved to list-screen of resident. <br>
     *
     *@param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param rsdtInfoVO Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/RsdtInfrList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchListRsdtInfrView.do")
    public String searchListRsdtInfrView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO rsdtInfoVO,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(), rsdtInfoVO.getCurMnId());
    		
    		String orgnzCd = user.getOrgnzCd();
    		String district = orgnzCd.substring(0, 4); //String str1 = "L123456789"; 467
    		String teamCd = user.getTamCdNm();
    		searchVO.setSearchKeyword7(district);
    		searchVO.setSearchKeyword8(teamCd);
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		
    		String fromToDdDrnLmt = propertiesService.getString("fromToDdDrnLmt");
    		if(fromToDdDrnLmt == null && "".equals(fromToDdDrnLmt) ){
    			fromToDdDrnLmt = "0";
    		}
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo.setAddDay(fromToDdDrnLmt);
    		comVo = nidCommonService.searchAddToDay(comVo);
    		
    		model.addAttribute("startDay", comVo.getStartDay());
    		model.addAttribute("endDay", comVo.getEndDay());
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}

        return "/rm/rsdt/RsdtInfrList";
    	
    }

    /**
     * Retrieves list of program.  <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param rsdtInfoVO Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/RsdtInfrList.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/rsdt/searchListRsdtInfr.do")
    public String searchListRsdtInfr (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO rsdtInfoVO,
    		ModelMap model)
            throws Exception {

    	try {
    		
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		rsdtInfoVO.setUseLangCd(user.getUseLangCd());
    		String orgnzClsCd = user.getOrgnzClsCd();
    		String orgnzCd = user.getOrgnzCd();
    		String teamCd = user.getTamCdNm();
    		rsdtInfoVO.setOfficerNo(orgnzClsCd+orgnzCd+teamCd);
    		
	    	
    		rsdtInfoVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		rsdtInfoVO.setPageSize(propertiesService.getInt("pageSize"));

	    	//** pageing *//*
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(rsdtInfoVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(rsdtInfoVO.getPageUnit());
			paginationInfo.setPageSize(rsdtInfoVO.getPageSize());

			rsdtInfoVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			rsdtInfoVO.setLastIndex(paginationInfo.getLastRecordIndex());
			rsdtInfoVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

	        List<RsdtInfrVO> lstProgram = service.searchListRsdtInfr(rsdtInfoVO);
	        
	        
	        lstProgram = setGridDataConvert(lstProgram, "j", "list");
	        
	        model.addAttribute("lstProgram", lstProgram);

	        int totCnt = service.searchListRsdtInfrTotCn(rsdtInfoVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        
	        CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		
    		String fromToDdDrnLmt = propertiesService.getString("fromToDdDrnLmt");
    		if(fromToDdDrnLmt == null && "".equals(fromToDdDrnLmt) ){
    			fromToDdDrnLmt = "0";
    		}
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo.setAddDay(fromToDdDrnLmt);
    		comVo = nidCommonService.searchAddToDay(comVo);
    		
    		model.addAttribute("startDay", comVo.getStartDay());
    		model.addAttribute("endDay", comVo.getEndDay());
    		
	        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/rsdt/RsdtInfrList";   	
    }
	
	/**
     * Moved to Resident registration-screen of program. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtInfrUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtInfrView.do")   
    public String addRsdtInfrView(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	
    	try {
    		
	    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
	    		
	    		cmCmmCd.setGrpCd("2"); // Setting Group Code
	    		List<CmCmmCdVO> bldTyeCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
	    		model.addAttribute("bldTyeCd", bldTyeCd); 
	    		cmCmmCd.setGrpCd("12"); // Setting Group Code
	    		List<CmCmmCdVO> mrrgCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, false, "");     		
	    		model.addAttribute("mrrgCd", mrrgCd); 
	    		cmCmmCd.setGrpCd("10"); // Setting Group Code
	    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
	    		model.addAttribute("gdrCd", gdrCd);
	    		cmCmmCd.setGrpCd("6"); // Setting Group Code
	    		List<CmCmmCdVO> etncityCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
	    		model.addAttribute("etncityCd", etncityCd);
	    		cmCmmCd.setGrpCd("11"); // Setting Group Code
	    		List<CmCmmCdVO> fmlyLangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
	    		model.addAttribute("fmlyLangCd", fmlyLangCd);
	    		cmCmmCd.setGrpCd("11"); // Setting Group Code
	    		List<CmCmmCdVO> nallangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
	    		model.addAttribute("nallangCd", nallangCd);
	    		cmCmmCd.setGrpCd("17"); // Setting Group Code
	    		List<CmCmmCdVO> rlgnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
	    		model.addAttribute("rlgnCd", rlgnCd);
	    		cmCmmCd.setGrpCd("18"); // Setting Group Code
	    		List<CmCmmCdVO> rlgnSect = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
	    		model.addAttribute("rlgnSect", rlgnSect);
	    		cmCmmCd.setGrpCd("13"); // Setting Group Code
	    		List<CmCmmCdVO> mltSrvcCd = NidStringUtil.setListReverse( cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "") );
	    		model.addAttribute("mltSrvcCd", mltSrvcCd);	    		
	    		cmCmmCd.setGrpCd("26"); // Setting Group Code
	    		List<CmCmmCdVO> eduYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
	    		model.addAttribute("eduYnCd", eduYnCd);	    		
	    		cmCmmCd.setGrpCd("26"); // Setting Group Code
	    		List<CmCmmCdVO> secdNltyYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
	    		model.addAttribute("secdNltyYnCd", secdNltyYnCd);
	    		
	    		cmCmmCd.setGrpCd("14"); // Setting Group Code
	    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
	    		model.addAttribute("nltyCd", nltyCd);
	    		
	    		cmCmmCd.setGrpCd("8"); // Setting Group Code
	    		List<CmCmmCdVO> frgnLang = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
	    		model.addAttribute("frgnLang", frgnLang);
	    		
	    		cmCmmCd.setGrpCd("64"); // Setting Group Code
	    		List<CmCmmCdVO> rsdtTypCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
	    		model.addAttribute("rsdtTypCd", rsdtTypCd);

	    		cmCmmCd.setGrpCd("5"); // Setting Group Code
	    		List<CmCmmCdVO> eduCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
	    		model.addAttribute("eduCd", eduCd);
	    		
	    		cmCmmCd.setGrpCd("68"); 
	    		List<CmCmmCdVO> dsbtCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");  
	    		model.addAttribute("dsbtCd", dsbtCd);  
	    		
	    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
	    		String useLangCd = user.getUseLangCd();
	    		String orgnzClsCd = user.getOrgnzClsCd();
	    		String orgnzCd = user.getOrgnzCd();
	    		String teamCd = user.getTamCdNm();	
	    		
	    		vo.setUseLangCd(useLangCd);	    			    	
	    		vo.setOfficerNo(orgnzClsCd+orgnzCd+teamCd);
	    		vo.setCrdIsuDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
	    		vo.setUserNm(user.getNm());
	    		
	    		RsdtInfrVO rsdtInfoVO = service.searchRsdtInfrView(vo);	    			    		
		        List<RsdtInfrVO> othrNatLangList = service.searchListOthrNatLangInfr(vo);
		        List<RsdtInfrVO> frgnLangList = service.searchListFrgnLangInfr(vo);

		        model.addAttribute("rsdtInfoVO", rsdtInfoVO);
		        model.addAttribute("othrNatLangList", othrNatLangList);
		        model.addAttribute("frgnLangList", frgnLangList);
		        
		        model.addAttribute("useLangCd", useLangCd);
		        
		        model.addAttribute("userId", user.getUserId());
		        
		        String ofcalPsnCd = "";
   	    		List<String> lstAthr = NidUserDetailsHelper.getAuthorities();
   	    		if(lstAthr != null && lstAthr.size() == 1){
   	    			ofcalPsnCd = lstAthr.get(0);
   	    		}else if(lstAthr != null && lstAthr.size() > 1){
   	    			/*for(int j = 0; j < lstAthr.size(); j++){
   	    				String athr = lstAthr.get(j);
   	    				if("1".equals(athr) || "3".equals(athr)){
   	    					ofcalPsnCd = athr;
   	    					if("3".equals(athr)){
   	        					break;
   	        				}
   	    				}
   	    			}*/
   	    			String [] srt = lstAthr.toArray(new String[0]);
   	    			if(srt != null){
   	    				int [] srti = new int[lstAthr.size()];
   	   	    			for(int i = 0, j = 0; i < srt.length; i++,j++){
   	   	    				try{
   	   	    					srti[j] = Integer.parseInt(srt[i]);
   	   	    				}catch(Exception e){
   	   	    					srti[j] = -1;
   	   	    				}
   	   	    			}
   	   	    			Arrays.sort(srti);
   	   	    			if(srti != null){
   	   	    				ofcalPsnCd = String.valueOf(srti[srti.length-1]);
   	   	    			}
   	    			}
   	    			
   	    		}
		        model.addAttribute("ofcalPsnCd", ofcalPsnCd);
		        
		        int frgnInt = propertiesService.getInt("frgnLangOthrLangRgstNo");
		        model.addAttribute("frgnLangOthrLangRgstNo", frgnInt);
		        
		        
		        int kochiAdCd = propertiesService.getInt("kochiAdCd");
		        model.addAttribute("kochiAdCd", kochiAdCd);
		        
		        String bioServer = propertiesService.getString("bioServer");
		        model.addAttribute("bioServer", bioServer);
		        
		        int koUprCd = propertiesService.getInt("kochiUprAdCd");
	    		model.addAttribute("koUprCd", koUprCd);
	    		
	    		ComDefaultVO comVo = new ComDefaultVO();
	    		comVo = nidCommonService.searchPerToDay(vo);
	    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
	    		
	    		comVo = nidCommonService.searchGreToDay(vo);
	    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
		        
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/rsdt/RsdtInfrUdt";
    }
    
    /**
     * Residents to register data. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtInfrList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/modifyRsdtInfrUdt.do")   
    public String modifyRsdtInfrUdt(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try {
    			
    			String ctznRgstYn = service.searchGetCtznRgstYn(vo);
    			if(ctznRgstYn != null && "Y".equals(ctznRgstYn)){
    				model.addAttribute("resultMsg", nidMessageSource.getMessage("nAlIndiRgstMassError.msg")); 
    			}else{
    				LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
        			String useLangCd = user.getUseLangCd();
        			vo.setCrdIsuLangCd(useLangCd);
        			
            		if(!"Y".equals(vo.getEduLvDocYn())){
            			vo.setEduLvDocYn("N");
            		}
            		
            		if(!"Y".equals(vo.getBldTyeDocYn())){
            			vo.setBldTyeDocYn("N");
            		}
            		
    	    		int result = service.modifyRsdtInfr(vo);
    	    		if(result > 0){
    	    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); 
    	    			model.addAttribute("getCudDate", nidCommonService.searchDateTime(vo));
    	    		}
    			}
    			
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "forward:/rm/rsdt/searchRsdtInfrView.do";
    }
    
    
    
    
    
    /**
     * Retrieves list of region.  <br>
     * 
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtInfrDvrcInfr.do")
    public void searchRsdtInfrDvrcInfr(
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
			ModelMap model,
			HttpServletResponse response) throws Exception {
    	try {
    		String resut = service.searchRsdtInfrDvrcInfr(vo);
    		if (resut == null){
    			resut = "";
    		}
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element eleInfo = null;
    		Element ele = null;
			eleInfo = doc.createElement("info");
			root.appendChild(eleInfo);
			ele = doc.createElement("result");
			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString( resut )));
			eleInfo.appendChild(ele);
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    /**
     * Retrieves list of region.  <br>
     * 
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtInfrMrrgInfrTarget.do")
    public void searchRsdtInfrMrrgInfrTarget(
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
			ModelMap model,
			HttpServletResponse response) throws Exception {
    	try {
    		String resut = service.searchRsdtInfrMrrgInfrTarget(vo);
    		if (resut == null){
    			resut = "";
    		}
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element eleInfo = null;
    		Element ele = null;
			eleInfo = doc.createElement("info");
			root.appendChild(eleInfo);
			ele = doc.createElement("result");
			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString( resut )));
			eleInfo.appendChild(ele);
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
     
    /**
     * Moved to list-screen of confirm. <br>
     *
     * @param searchVO Value-object of resident to be parsed request(ComDefaultVO)
     * @param rsdtInfoVO Value-object of program to be parsed request(RsdtInfrVO)     * 
     * @param model Object to be parsed http request(ModelMap)
     * @@return Printed out JSP: "rm/rsdt/RsdtRgstAprvList.jsp "
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchListRsdtRgstInfrAprvView.do")
    public String searchListRsdtRgstInfrAprvView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO rsdtInfoVO, ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		
    		lgService.addUserWrkLg(user.getUserId(), rsdtInfoVO.getCurMnId());
    		
    		rsdtInfoVO.setUseLangCd(user.getUseLangCd());
    		
    		model.addAttribute("rsdtInfoVO", rsdtInfoVO);
    		
    		String orgnzCd = user.getOrgnzCd();
    		String district = orgnzCd.substring(0, 4); //String str1 = "L123456789"; 467
    		String teamCd = user.getTamCdNm();
    		searchVO.setSearchKeyword(district);
    		searchVO.setSearchKeyword2(teamCd);
    		
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		
    		//rsdtInfoVO.setSearchKeyword10("GDR0001");
    		
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "/rm/rsdt/RsdtRgstAprvList";

    }

    /**
     * Retrieves list of program.  <br>
     *
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param rsdtInfoVO Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: " rm/rsdt/RsdtRgstAprvList.jsp "
     * @exception Exception
     */
	@RequestMapping(value="/rm/rsdt/searchListRsdtRgstInfrAprv.do")
    public String searchListRsdtRgstInfrAprv (
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO rsdtInfoVO, ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		rsdtInfoVO.setUseLangCd(user.getUseLangCd());
	
    		String orgnzClsCd = user.getOrgnzClsCd();
    		String orgnzCd = user.getOrgnzCd();
    		String teamCd = user.getTamCdNm();
    		rsdtInfoVO.setOfficerNo(orgnzClsCd+orgnzCd+teamCd);
    		
    		
	    	//** list Paging Setting *//*
    		rsdtInfoVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		rsdtInfoVO.setPageSize(propertiesService.getInt("pageSize"));
	    	//** pageing *//*
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(rsdtInfoVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(rsdtInfoVO.getPageUnit());
			paginationInfo.setPageSize(rsdtInfoVO.getPageSize());

			rsdtInfoVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			rsdtInfoVO.setLastIndex(paginationInfo.getLastRecordIndex());
			rsdtInfoVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

	        List<RsdtInfrVO> lstProgram = service.searchListRsdtRgstAprvInfr(rsdtInfoVO);
	        model.addAttribute("lstProgram", lstProgram);

	        int totCnt = service.searchListRsdtRgstAprvInfrTotCn(rsdtInfoVO);
	        
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        
	        CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		
    		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	return "/rm/rsdt/RsdtRgstAprvList";
    }
    

	/**
     * Moved to Confirm-screen of RsdtRegVfy after Select <br>
     *
     *@param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "/rm/rsdt/RsdtRgstAprvUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtRgstAprvInfr.do")
    public String searchRsdtRgstAprvInfr(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo, ModelMap model)
            throws Exception {
    	try{
    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("2"); // Setting Group Code
    		List<CmCmmCdVO> bldTyeCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("bldTyeCd", bldTyeCd); 
    		cmCmmCd.setGrpCd("12"); // Setting Group Code
    		List<CmCmmCdVO> mrrgCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, false, "");     		
    		model.addAttribute("mrrgCd", mrrgCd); 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		cmCmmCd.setGrpCd("6"); // Setting Group Code
    		List<CmCmmCdVO> etncityCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("etncityCd", etncityCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> fmlyLangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("fmlyLangCd", fmlyLangCd);
    		cmCmmCd.setGrpCd("11"); // Setting Group Code
    		List<CmCmmCdVO> nallangCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("nallangCd", nallangCd);
    		cmCmmCd.setGrpCd("17"); // Setting Group Code
    		List<CmCmmCdVO> rlgnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("rlgnCd", rlgnCd);
    		cmCmmCd.setGrpCd("18"); // Setting Group Code
    		List<CmCmmCdVO> rlgnSect = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("rlgnSect", rlgnSect);
    		cmCmmCd.setGrpCd("13"); // Setting Group Code
    		List<CmCmmCdVO> mltSrvcCd = NidStringUtil.setListReverse( cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "") );
    		model.addAttribute("mltSrvcCd", mltSrvcCd);
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> eduYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("eduYnCd", eduYnCd);
    		
    		cmCmmCd.setGrpCd("26"); // Setting Group Code
    		List<CmCmmCdVO> secdNltyYnCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("secdNltyYnCd", secdNltyYnCd);
    		
    		cmCmmCd.setGrpCd("14"); // Setting Group Code
    		List<CmCmmCdVO> nltyCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("nltyCd", nltyCd);
    		
    		cmCmmCd.setGrpCd("8"); // Setting Group Code
    		List<CmCmmCdVO> frgnLang = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("frgnLang", frgnLang);
    		
    		cmCmmCd.setGrpCd("64"); // Setting Group Code
    		List<CmCmmCdVO> rsdtTypCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("rsdtTypCd", rsdtTypCd);
    		
    		cmCmmCd.setGrpCd("5"); // Setting Group Code
    		List<CmCmmCdVO> eduCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");     		
    		model.addAttribute("eduCd", eduCd);
    		
    		cmCmmCd.setGrpCd("68"); 
    		List<CmCmmCdVO> dsbtCd = cmmCdManagerService.searchListCmmCd(cmCmmCd, true, "");  
    		model.addAttribute("dsbtCd", dsbtCd); 

    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		String useLangCd = user.getUseLangCd();   		
    		vo.setUseLangCd(useLangCd);	    			    	
    		vo.setOfficerNo(user.getOrgnzClsCd()+user.getOrgnzCd()+user.getTamCdNm());		
    		
    		String ofcalPsnCd = "";
    		List<String> lstAthr = NidUserDetailsHelper.getAuthorities();
    		if(lstAthr != null && lstAthr.size() == 1){
    			ofcalPsnCd = lstAthr.get(0);
    		}else if(lstAthr != null && lstAthr.size() > 1){
    			/*for(int j = 0; j < lstAthr.size(); j++){
    				String athr = lstAthr.get(j);
    				if("1".equals(athr) || "3".equals(athr)){
    					ofcalPsnCd = athr;
    					if("3".equals(athr)){
        					break;
        				}
    				}
    			}*/
    			String [] srt = lstAthr.toArray(new String[0]);
    			if(srt != null){
    				int [] srti = new int[lstAthr.size()];
   	    			for(int i = 0, j = 0; i < srt.length; i++,j++){
   	    				try{
   	    					srti[j] = Integer.parseInt(srt[i]);
   	    				}catch(Exception e){
   	    					srti[j] = -1;
   	    				}
   	    			}
   	    			Arrays.sort(srti);
   	    			if(srti != null){
   	    				ofcalPsnCd = String.valueOf(srti[srti.length-1]);
   	    			}
    			}
    		}
    		model.addAttribute("ofcalPsnCd", ofcalPsnCd);
    		
    		vo.setCrdIsuDueDd(String.valueOf(propertiesService.getInt("crdDlvrDd")));
    		
    		vo.setUserNm(user.getNm());
    		RsdtInfrVO rsdtInfoVO = service.searchRsdtInfrView(vo);    		
	        List<RsdtInfrVO> othrNatLangList = service.searchListOthrNatLangInfr(vo);
	        List<RsdtInfrVO> frgnLangList = service.searchListFrgnLangInfr(vo);
	       
	        
	        vo.setRsdtSeqNo(rsdtInfoVO.getRsdtSeqNo());
	        
	        model.addAttribute("rsdtInfoVO", rsdtInfoVO);
	        model.addAttribute("othrNatLangList", othrNatLangList);
	        model.addAttribute("frgnLangList", frgnLangList);
	        
	        model.addAttribute("userGivNm", user.getNm());
	        model.addAttribute("useLangCd", useLangCd);
	        
	        model.addAttribute("userId", user.getUserId());
	        
	        ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("crdIsuDueDdPa", comVo.getStartDay());
    		
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("crdIsuDueDdEn", comVo.getStartDay());
    		
    		comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		
	        int frgnInt = propertiesService.getInt("frgnLangOthrLangRgstNo");
	        model.addAttribute("frgnLangOthrLangRgstNo", frgnInt);
	        
	        String bioServer = propertiesService.getString("bioServer");
	        model.addAttribute("bioServer", bioServer);
    		
	        int kochiAdCd = propertiesService.getInt("kochiAdCd");
	        model.addAttribute("kochiAdCd", kochiAdCd);
	        
	        int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
	        
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/rsdt/RsdtRgstAprvUdt";
    }
    
    /**
     * Moved to list-screen of confirm after Save. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtRgstAprvUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/modifyRrsdtRgstAprvInfr.do")   
    public String modifyRrsdtRgstAprvInfr(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo, ModelMap model)
            throws Exception {
    	try {
    		String ctznRgstYn = service.searchGetCtznRgstYn(vo);
			if(ctznRgstYn != null && "Y".equals(ctznRgstYn)){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nAlIndiRgstMassError.msg")); 
			}else{
				LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
	    		String useLangCd = user.getUseLangCd();
	    		vo.setUseLangCd(useLangCd);
	    		
	    		if(!"Y".equals(vo.getEduLvDocYn())){
	    			vo.setEduLvDocYn("N");
	    		}
	    		
	    		if(!"Y".equals(vo.getBldTyeDocYn())){
	    			vo.setBldTyeDocYn("N");
	    		}
	    		
	    		if(!"Y".equals(vo.getRsdtCfmYn())){
	    			vo.setRsdtCfmYn("N");
	    		}
	    		
	    		int result = service.modifyRsdtInfr(vo);
	    		
	    		if(result > 0){
	    			model.addAttribute("resultMsg", nidMessageSource.getMessage("datSavScsfl.msg")); 
	    			model.addAttribute("getCudDate", nidCommonService.searchDateTime(vo));
	    		}	   
			}
	    		 		
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "forward:/rm/rsdt/searchRsdtRgstAprvInfr.do";
    }	
    
    
    /**
     * Moved to list-screen of confirm after Save. <br>
     * 
     * @param comDefaultVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP: "/rm/rsdt/RsdtRgstAprvUdt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/modifyAprv.do")   
    public String modifyAprv(
    		@ModelAttribute("searchVO") ComDefaultVO comDefaultVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo, ModelMap model)
            throws Exception {
    	String returnPage = "forward:/rm/rsdt/searchRsdtRgstAprvInfr.do";
    	try {
    		
    		String ctznRgstYn = service.searchGetCtznRgstYn(vo);
			if(ctznRgstYn != null && "Y".equals(ctznRgstYn)){
				model.addAttribute("resultMsg", nidMessageSource.getMessage("nAlIndiRgstMassError.msg")); 
			}else{
				vo.setAprvBtnClickYn("Y");
    		    
        		if(!"Y".equals(vo.getEduLvDocYn())){
        			vo.setEduLvDocYn("N");
        		}
        		
        		if(!"Y".equals(vo.getBldTyeDocYn())){
        			vo.setBldTyeDocYn("N");
        		}
        		
        		if(!"Y".equals(vo.getRsdtCfmYn())){
        			vo.setRsdtCfmYn("N");
        		}
        		
	    		EgovMap emp = service.modifyAprv(vo);
	    		
	    		if(emp != null && !emp.isEmpty()){
	    			String result = NidStringUtil.nullConvert(emp.get("result"));
	    			EgovMap emResult = (EgovMap)emp.get("emResult");
	    			bioIfService.addBioInterfaceLog(emResult);
	    			
	    			if(result != null && "-1".equals(result) ||  "-3".equals(result)){
		    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nValdBioInfr.msg") );
		    		}else if(result != null && ("fail".equals(result)|| "-2".equals(result)) ){
		    			model.addAttribute("resultMsg", nidMessageSource.getMessage("erorOcurd.msg") );
		    		}else if(result != null && result.length() > 0){
		    			LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
		    			if(user != null && !user.equals("3")){
		    				model.addAttribute("resultMsg", result + " : " +nidMessageSource.getMessage("enid"));
			    			model.addAttribute("getRsdtNo", result + " : " +nidMessageSource.getMessage("enid"));
		    			}else{
		    				model.addAttribute("resultMsg", nidMessageSource.getMessage("enid") + " : "+result);
			    			model.addAttribute("getRsdtNo", nidMessageSource.getMessage("enid") + " : "+result);
		    			}
		    			model.addAttribute("getCudDate", nidCommonService.searchDateTime(vo));
		    			
		    			model.addAttribute("resultMsg", nidMessageSource.getMessage("apvScsfl.msg"));
		    			//returnPage = "forward:/rm/rsdt/searchListRsdtRgstInfrAprv.do";
		    		}
	    		}else{
	    			String helpTelNo = nidMessageSource.getMessage("admTelNo");
        			model.addAttribute("resultMsg", nidMessageSource.getMessage("apvFail.msg", new String[]{helpTelNo}));
	    		}
			}
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		if(e instanceof EgovBizException){
    			model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    		}else if(e instanceof IOException || e instanceof ConnectException || e instanceof BaseException){
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nValdBioInfr.msg") );
    		}else{
    			model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    		}
    	}
      	return returnPage;
    }
    
	
	/**
     * Persnal Information Detail View <br>
     *
     *@param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "/rm/rsdt/RsdtPerInfrDtl.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtInfrDtlView.do")
    public String searchRsdtInfrDtlView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo, 
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		lgService.addUserWrkLg(user.getUserId(), vo.getCurMnId());
    		
    		vo.setUseLangCd(user.getUseLangCd());
    		vo.setUserId(user.getUserId());
	        
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/rsdt/RsdtPerInfrDtl";

    }
    /**
     * Persnal Information Detail View <br>
     *
     *@param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "/rm/rsdt/RsdtPerInfrDtl.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtInfrDtl.do")
    public String searchRsdtInfrDtl(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo, 
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    		RsdtInfrVO tmp = service.searchRsdtInfrPer(vo);
    		
    		RsdtInfrVO rsdtInfoVO = null;
    		List<RsdtInfrVO> frgnLangList = null;
    		List<RsdtInfrVO> othrNatLangList = null;
    		
    		if(tmp != null && tmp.getRsdtSeqNo() != null){
    			tmp.setUseLangCd(user.getUseLangCd());
	    		rsdtInfoVO = service.searchRsdtInfrDtlView(tmp); 
		        othrNatLangList = service.searchListOthrNatLangInfr(tmp);
		        frgnLangList = service.searchListFrgnLangInfr(tmp);
		        rsdtInfoVO.setUseLangCd(user.getUseLangCd());
		        rsdtInfoVO.setUserId(user.getUserId());

    		}else{
    			model.addAttribute("resultMsg", nidMessageSource.getMessage("nRgstEnid.msg"));
    		}
	        
	        model.addAttribute("rsdtInfoVO", rsdtInfoVO);
	        model.addAttribute("othrNatLangList", othrNatLangList);
	        model.addAttribute("frgnLangList", frgnLangList);
	        
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/rsdt/RsdtPerInfrDtl";

    }

    /**
     * Bio for registration inquiry.<br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param rsdtInfoVO Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtBioRgstStus.do")
    public void searchRsdtBioRgstStus(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO rsdtInfoVO,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		String bioRgstDd = (String)service.searchRsdtBioRgstStus(rsdtInfoVO);
    		if(bioRgstDd == null){
    			bioRgstDd = "N";
    		}
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element child = doc.createElement("bioRgstDd");
    		child.appendChild(doc.createTextNode(bioRgstDd));
    		root.appendChild(child);
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
    
    /**
     *Checks to see if the age can be registered. <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtBthCheck.do")
    public void searchRsdtBthCheck(
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		String count = (String)service.searchRsdtBthCheck(vo);
    		if(count == null){
    			count = "0";
    		}
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element child = doc.createElement("bthDdCk");
    		child.appendChild(doc.createTextNode(count));
    		root.appendChild(child);
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    
    
    
    
    
    
    
    
    /**
     * Receipt to inquire. <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "/rm/rsdt/p_RsdtInfrRcpt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtInfrRcpt.do")
    public String searchRsdtInfrRcpt(
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo, 
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());

    		String orgnzClsCd = user.getOrgnzClsCd();
    		String orgnzCd = user.getOrgnzCd();
    		String teamCd = user.getTamCdNm();	
    		vo.setOfficerNo(orgnzClsCd+orgnzCd+teamCd);	
    		
    		RsdtInfrVO rsdtInfoVO = service.searchRsdtInfrRcpt( vo); 
	        List<RsdtInfrVO> othrNatLangList = service.searchListOthrNatLangInfrForRcpt(vo);
	        List<RsdtInfrVO> frgnLangList = service.searchListFrgnLangInfrForRcpt(vo);
	        
	        if(user != null && !user.getUseLangCd().equals("3")){
		        rsdtInfoVO.setOldCrdNo1(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo1(), "j"));
		        rsdtInfoVO.setOldCrdNo2(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo2(), "j"));
		        rsdtInfoVO.setOldCrdNo3(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo3(), "j"));
		        rsdtInfoVO.setOldCrdNo4(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo4(),"j"));
		        rsdtInfoVO.setFmlyMberNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyMberNo(), "j"));
		        rsdtInfoVO.setFmlyBokNoNum(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyBokNoNum(), "j"));
		        rsdtInfoVO.setRsdtNoDp(NidStringUtil.toNumberConvet(rsdtInfoVO.getRsdtNoDp(), "j"));
		        rsdtInfoVO.setCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getCrdIsuceDd(), "j"));
		        rsdtInfoVO.setCrdExpiryDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getCrdExpiryDd(), "j"));
		        rsdtInfoVO.setBthDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getBthDd(), "j"));
		        rsdtInfoVO.setFmlyMberMlNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyMberMlNo(), "j"));
		        rsdtInfoVO.setFmlyMberFemlNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyMberFemlNo(), "j"));
		        rsdtInfoVO.setFstVefyRsdtNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFstVefyRsdtNo(), "j"));
		        rsdtInfoVO.setSecdVefyRsdtNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getSecdVefyRsdtNo(), "j"));
		        rsdtInfoVO.setRsdtRgstDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getRsdtRgstDd(), "j"));
		        rsdtInfoVO.setCrdIsuDueDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getCrdIsuDueDd(), "j"));
		        
		        rsdtInfoVO.setOldCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdIsuceDd(),"j"));
		        rsdtInfoVO.setFstVefyOldCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getFstVefyOldCrdIsuceDd(),"j"));
		        rsdtInfoVO.setSecdVefyOldCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getSecdVefyOldCrdIsuceDd(),"j"));
		        
		        rsdtInfoVO.setFstVefyOldCrdNo1(NidStringUtil.toNumberConvet(rsdtInfoVO.getFstVefyOldCrdNo1(),"j"));
		        rsdtInfoVO.setSecdVefyOldCrdNo1(NidStringUtil.toNumberConvet(rsdtInfoVO.getSecdVefyOldCrdNo1(),"j"));
	        }
	        
	        model.addAttribute("useLangCd",user.getUseLangCd());	        
	        model.addAttribute("rsdtInfoVO", rsdtInfoVO);
	        model.addAttribute("othrNatLangList", othrNatLangList);
	        model.addAttribute("frgnLangList", frgnLangList);
	        model.addAttribute("userNm",user.getNm());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/rsdt/p_RsdtInfrRcpt";

    }
    
    /**
     * Receipt for Citizen Confirmation. <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "/rm/rsdt/p_RsdtInfrCfmRcpt.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtInfrCfmRcpt.do")
    public String searchRsdtInfrCfmRcpt(
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo, 
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    	
    		String orgnzClsCd = user.getOrgnzClsCd();
    		String orgnzCd = user.getOrgnzCd();
    		String teamCd = user.getTamCdNm();	
    		vo.setOfficerNo(orgnzClsCd+orgnzCd+teamCd);	  
    		
    		RsdtInfrVO rsdtInfoVO = service.searchRsdtInfrRcpt( vo); 
	        List<RsdtInfrVO> othrNatLangList = service.searchListOthrNatLangInfrForRcpt(vo);
	        List<RsdtInfrVO> frgnLangList = service.searchListFrgnLangInfrForRcpt(vo);
	        
	        if(user != null && !user.getUseLangCd().equals("3")){
		        rsdtInfoVO.setOldCrdNo1(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo1(),"j"));
		        rsdtInfoVO.setOldCrdNo2(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo2(),"j"));
		        rsdtInfoVO.setOldCrdNo3(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo3(),"j"));
		        rsdtInfoVO.setOldCrdNo4(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdNo4(),"j"));
		        rsdtInfoVO.setFmlyMberNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyMberNo(),"j"));
		        rsdtInfoVO.setFmlyBokNoNum(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyBokNoNum(),"j"));
		        rsdtInfoVO.setRsdtNoDp(NidStringUtil.toNumberConvet(rsdtInfoVO.getRsdtNoDp(),"j"));
		        rsdtInfoVO.setCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getCrdIsuceDd(),"j"));
		        rsdtInfoVO.setCrdExpiryDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getCrdExpiryDd(),"j"));
		        rsdtInfoVO.setBthDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getBthDd(),"j"));
		        rsdtInfoVO.setFmlyMberMlNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyMberMlNo(),"j"));
		        rsdtInfoVO.setFmlyMberFemlNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFmlyMberFemlNo(),"j"));
		        rsdtInfoVO.setFstVefyRsdtNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getFstVefyRsdtNo(),"j"));
		        rsdtInfoVO.setSecdVefyRsdtNo(NidStringUtil.toNumberConvet(rsdtInfoVO.getSecdVefyRsdtNo(),"j"));
		        rsdtInfoVO.setRsdtRgstDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getRsdtRgstDd(),"j"));
		        rsdtInfoVO.setCrdIsuDueDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getCrdIsuDueDd(),"j"));
		        rsdtInfoVO.setPrntDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getPrntDd(),"j"));
		        
		        rsdtInfoVO.setOldCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getOldCrdIsuceDd(),"j"));
		        rsdtInfoVO.setFstVefyOldCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getFstVefyOldCrdIsuceDd(),"j"));
		        rsdtInfoVO.setSecdVefyOldCrdIsuceDd(NidStringUtil.toNumberConvet(rsdtInfoVO.getSecdVefyOldCrdIsuceDd(),"j"));
		        
		        rsdtInfoVO.setFstVefyOldCrdNo1(NidStringUtil.toNumberConvet(rsdtInfoVO.getFstVefyOldCrdNo1(),"j"));
		        rsdtInfoVO.setSecdVefyOldCrdNo1(NidStringUtil.toNumberConvet(rsdtInfoVO.getSecdVefyOldCrdNo1(),"j"));
	        }
	        
	        model.addAttribute("useLangCd",user.getUseLangCd());
	        
	        model.addAttribute("rsdtInfoVO", rsdtInfoVO);
	        model.addAttribute("othrNatLangList", othrNatLangList);
	        model.addAttribute("frgnLangList", frgnLangList);
	        model.addAttribute("userNm",user.getNm());
	        
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/rsdt/p_RsdtInfrCfmRcpt";

    }    
 	

   	/**
     * Retrieves list of region.  <br>
     * 
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap) 
     * @return Printed out JSP:""
     * @exception Exception
     */
    @RequestMapping(value="/cm/code/searchListPoliCntrCd.do")
    public void searchListPoliCntrCd(
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
			ModelMap model,
			HttpServletResponse response) throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		String useLangCd = user.getUseLangCd();
    		vo.setUseLangCd(useLangCd);
    		List<EgovMap> list = service.searchListPoliCntrCd(vo);
    		if (list == null){
    			list = new ArrayList<EgovMap>();
    		}
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		Element eleInfo = null;
    		Element ele = null;
    		for(int i=0; i<list.size(); i++){
    			EgovMap em = list.get(i);
    			if(em != null){
	    			eleInfo = doc.createElement("adcd_info");
	    			root.appendChild(eleInfo);
	    			ele = doc.createElement("adCd");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)em.get("cd")) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("uprAdCd");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)em.get("uprCd")) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("poliCntrSeqNo");
	    			
	    			Object result = em.get("poliCntrSeqNo");
	    			String resultStr = null;
	    			if(result != null){
	    				resultStr = ((BigDecimal)em.get("poliCntrSeqNo")).toString();
	    			}
	    			
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString( resultStr  )));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("fullNm");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)em.get("dplyNm")) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("fullNms");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)em.get("dplyNm")) ));
	    			eleInfo.appendChild(ele);
	    			ele = doc.createElement("poliCntrNm");
	    			ele.appendChild(doc.createTextNode( NidStringUtil.isNullToString((String)em.get("nm")) ));
	    			eleInfo.appendChild(ele);
    			}
	    	}
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    /**
     * Receipt to inquire. <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "/rm/rsdt/p_RsdtPoliCntr.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtInfrPoliCntr.do")
    public String searchRsdtInfrPoliCntr(
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo, 
    		ModelMap model)
            throws Exception {
    	try{
    		log.debug("");
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
      	return "/rm/rsdt/p_RsdtPoliCntr";

    }

    /**
     * Moved to list-screen of resident. <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/p_RsdtInfrFnd.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchListRsdtInfrPopView.do")
    public String searchListRsdtInfrPopView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		@RequestParam(value="fmlyBokNos" ,required=false) String fmlyBokNos,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();

    		CmCmmCdVO cmCmmCd = new CmCmmCdVO();// 
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		
    		model.addAttribute("useLangCd",  user.getUseLangCd());
    		//rsdtInfoVO.setSearchKeyword10("GDR0001");
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/rsdt/p_RsdtInfrFnd";
    }
    
    /**
     * Retrieves list of program.  <br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/p_RsdtInfrFnd.jsp"
     * @exception Exception
     */
	@RequestMapping(value="/rm/rsdt/searchListRsdtInfrPop.do")
    public String searchListRsdtInfrPop (
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		@RequestParam(value="callbacks" ,required=false) String callback,
    		ModelMap model)
            throws Exception {
    	try {
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    		String orgnzCd = user.getOrgnzCd();
    		String district = orgnzCd.substring(0, 4); //String str1 = "L123456789"; 467
    		String teamCd = user.getTamCdNm();
    		vo.setOfficerNo(district+teamCd);
	    	
    		vo.setPageUnit(propertiesService.getInt("pageUnit"));
    		vo.setPageSize(propertiesService.getInt("pageSize"));
	    	//** pageing *//*
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(vo.getPageIndex());
			paginationInfo.setRecordCountPerPage(vo.getPageUnit());
			paginationInfo.setPageSize(vo.getPageSize());
			vo.setFirstIndex(paginationInfo.getFirstRecordIndex());
			vo.setLastIndex(paginationInfo.getLastRecordIndex());
			vo.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());
	        List<EgovMap> lstProgram = service.searchListRsdtInfrPop(vo);
	        model.addAttribute("lstProgram", lstProgram);
	        int totCnt = service.searchListRsdtInfrPopTotCn(vo);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
	        CmCmmCdVO cmCmmCd = new CmCmmCdVO();
    		cmCmmCd.setGrpCd("10"); // Setting Group Code
    		List<CmCmmCdVO> gdrCd = cmmCdManagerService.searchListCmmCdDesc(cmCmmCd);     		
    		model.addAttribute("gdrCd", gdrCd);
    		
    		model.addAttribute("callbacks", callback);//callback function
    		
    		model.addAttribute("useLangCd",  user.getUseLangCd());
    	} catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
   		return "/rm/rsdt/p_RsdtInfrFnd";   	
    }
	
	
    /**
     * Bio for registration inquiry.<br>
     *
     * @param searchVO Value-object of program to be parsed request(ComDefaultVO)
     * @param rsdtInfoVO Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRsdtBioRgstDtlStus.do")
    public void searchRsdtBioRgstDtlStus(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO rsdtInfoVO,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		
    		String bioKey = rsdtInfoVO.getBioKey();
    		
    		RsdtInfrVO bioDtlStus = new RsdtInfrVO();
    		bioDtlStus = service.searchRsdtBioRgstDtlStus(bioKey);
    		/*
    		if(bioDtlStus == null){
    			bioDtlStus.setBioCd("N");
    			bioDtlStus.setPtCd("N");
    			bioDtlStus.setSgntCd("N");
    		}
    		*/
    		
    		if("".equals(bioDtlStus.getFgpCd())){
    			bioDtlStus.setBioCd("N");
    		}
    		
    		if("".equals(bioDtlStus.getIrisCd())){
    			bioDtlStus.setIrisCd("N");
    		}
    		
    		if("".equals(bioDtlStus.getSgntCd())){
    			bioDtlStus.setPtCd("N");
    		}
    		
    		if("".equals(bioDtlStus.getPtCd())){
    			bioDtlStus.setSgntCd("N");
    		}
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		doc.appendChild(root);
    		
    		Element fgpCd = doc.createElement("fgpCd");
    		fgpCd.appendChild(doc.createTextNode(bioDtlStus.getFgpCd()));
    		
    		Element irisCd = doc.createElement("irisCd");
    		irisCd.appendChild(doc.createTextNode(bioDtlStus.getIrisCd()));
    		
    		Element sgntCd = doc.createElement("sgntCd");
    		sgntCd.appendChild(doc.createTextNode(bioDtlStus.getSgntCd()));
    		
    		Element ptCd = doc.createElement("ptCd");
    		ptCd.appendChild(doc.createTextNode(bioDtlStus.getPtCd()));
    		
    		root.appendChild(fgpCd);
    		root.appendChild(irisCd);
    		root.appendChild(sgntCd);
    		root.appendChild(ptCd);
    		
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }	
	
    
    
    
    /**
     * Retrieves list of program.  <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/p_RsdtFmlyInfrFnd.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchListFmlyInfrPopView.do")
    public String searchListFmlyInfrPopView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("useLangCd",  user.getUseLangCd());
    		model.addAttribute("rsdtXxx", "start");
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/rsdt/p_RsdtFmlyInfrFnd";
    }
	
    /**
     * Retrieves list of program.  <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/p_RsdtFmlyInfrFnd.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchListFmlyInfrPop.do")
    public String searchListFmlyInfrPop(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		@RequestParam(value="mode" ,required=false) String mode,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		model.addAttribute("useLangCd",  user.getUseLangCd());
    		
    		RsdtInfrVO agGap = service.searchAgGap(vo);
    		
			if("4".equals(vo.getMode())){
				vo.setSrchAgGap(agGap.getFthrAgGap());
			} else if ("5".equals(vo.getMode())){
				vo.setSrchAgGap(agGap.getGfthrAgGap());
			} else if ("7".equals(vo.getMode())){
				vo.setSrchAgGap(agGap.getMthrAgGap());
			}
			
    		List<EgovMap> list =  service.searchListFmlyInfrPop(vo);
    		model.addAttribute("lstProgram", list);
    		model.addAttribute("lstProgramCnt", list != null ? list.size() : 0);
    		model.addAttribute("rsdtXxx", "end");
    		model.addAttribute("mode", mode);
    		
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("oldCrdIsuceDdPa", comVo.getStartDay());
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("oldCrdIsuceDdEn", comVo.getStartDay());
    		int koUprCd = propertiesService.getInt("kochiUprAdCd");
    		model.addAttribute("koUprCd", koUprCd);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/rsdt/p_RsdtFmlyInfrFnd";
    }
    
    
    
    /**
     * Retrieves list of program.  <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "NidRmValidator.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/nidRmValidator.do")
    public String nidRmValidator(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		@RequestParam(value="mode" ,required=false) String mode,
    		ModelMap model)
            throws Exception {
    	try{
    		ComDefaultVO comVo = new ComDefaultVO();
    		comVo = nidCommonService.searchPerToDay(vo);
    		model.addAttribute("todayPa", comVo.getStartDay());
    		comVo = nidCommonService.searchGreToDay(vo);
    		model.addAttribute("todayEn", comVo.getStartDay());
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/NidRmValidator";
    }
    
    
    /**
	 * Biz-method for retrieving list of program. <br>
	 * 
	 * @param List, String
	 * @return List
	 * @exception Exception
	 */
	private List<RsdtInfrVO> setGridDataConvert(List<RsdtInfrVO> list, String cal, String type){
		List<RsdtInfrVO> result = list;
		if(list != null && (cal != null && ("j".equals(cal.toLowerCase()) || "".equals(cal)) || cal == null) ){
			if(!list.isEmpty()){
				for(int i = 0; i < list.size(); i++){
					Object obj = list.get(i);
					if(obj instanceof RsdtInfrVO){
						RsdtInfrVO vo = (RsdtInfrVO)obj;
						if(type != null && "list".equals(type)){
							String str = vo.getBioRgstDdJ();
							str = NidStringUtil.toNumberConvet(str, "j");
							vo.setBioRgstDdJ(str);
						}
						result.set(i, vo);
					}
				}
			}
		}
		return result;
	}
    
	
    /**
     * Retrieves list of program.  <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @return Printed out JSP: "rm/rsdt/p_FmlyMberList.jsp"
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchListFmlyMberView.do")
    public String searchListFmlyMberView(
    		@ModelAttribute("searchVO") ComDefaultVO searchVO,
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO rsdtInfoVO,
    		@RequestParam(value="mode" ,required=false) String mode,
    		ModelMap model)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		rsdtInfoVO.setUseLangCd(user.getUseLangCd());
    		model.addAttribute("useLangCd", user.getUseLangCd());
    		
    		/** List Paging Setting */
    		rsdtInfoVO.setPageUnit(propertiesService.getInt("pageUnit"));
    		rsdtInfoVO.setPageSize(propertiesService.getInt("pageSize"));

    		/** pageing */
	    	PaginationInfo paginationInfo = new PaginationInfo();
			paginationInfo.setCurrentPageNo(rsdtInfoVO.getPageIndex());
			paginationInfo.setRecordCountPerPage(rsdtInfoVO.getPageUnit());
			paginationInfo.setPageSize(rsdtInfoVO.getPageSize());

			rsdtInfoVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
			rsdtInfoVO.setLastIndex(paginationInfo.getLastRecordIndex());
			rsdtInfoVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

	        List<RsdtInfrVO> lstFmlyMber = service.searchListFmlyMber(rsdtInfoVO);
	        model.addAttribute("lstFmlyMber", lstFmlyMber);

	        int totCnt = service.searchListFmlyMberTotCn(rsdtInfoVO);
			paginationInfo.setTotalRecordCount(totCnt);
	        model.addAttribute("paginationInfo", paginationInfo);
    		
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
        return "/rm/rsdt/p_FmlyMberList";
    }	
    
    /**
     * check age gap <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchChkAgGap.do")
    public void searchChkAgGap(
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		String flag = "Y";
    		RsdtInfrVO agGap = service.searchAgGap(vo); 
    		
    		if("1".equals(vo.getMode())){
    			vo.setAgGap(agGap.getSelfAgGap());    		
    		}else if("4".equals(vo.getMode())){
    			vo.setAgGap(agGap.getFthrAgGap());
    		} else if("5".equals(vo.getMode())){
    			vo.setAgGap(agGap.getGfthrAgGap());
    		} else if("7".equals(vo.getMode())){
    			vo.setAgGap(agGap.getMthrAgGap());
    		} else {
    			vo.setAgGap("");
    		}
    		
    		if(!"0".equals(vo.getAgGap())){
    			flag = service.searchChkAgGap(vo);
    		}
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		
    		doc.appendChild(root);
    		if(flag != null && !"".equals(flag)){
    			Element el = doc.createElement("flag");
    			el.appendChild(doc.createTextNode(flag));
	    		root.appendChild(el);
	    		
    			el = doc.createElement("selfAgGap");
    			el.appendChild(doc.createTextNode(agGap.getSelfAgGap()));
	    		root.appendChild(el);
	    		
    			el = doc.createElement("fthrAgGap");
    			el.appendChild(doc.createTextNode(agGap.getFthrAgGap()));
	    		root.appendChild(el);
	    		
    			el = doc.createElement("gfthrAgGap");
    			el.appendChild(doc.createTextNode(agGap.getGfthrAgGap()));
	    		root.appendChild(el);
	    		
    			el = doc.createElement("mthrAgGap");
    			el.appendChild(doc.createTextNode(agGap.getMthrAgGap()));
	    		root.appendChild(el);	    		
    		}
    		
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }
    
    /**
     * check validation of relationship <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchChkRl.do")
    public void searchChkRl(
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		String flag = service.searchChkRl(vo);
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		
    		doc.appendChild(root);
    		if(flag != null && !"".equals(flag)){
    			Element el = doc.createElement("flag");
    			el.appendChild(doc.createTextNode(flag));
	    		root.appendChild(el);
    		}
    		
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }    
    
    
    /**
     * check validation of relationship <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchNmLink.do")
    public void searchNmLink(
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		RsdtInfrVO rs = service.searchNmLink(vo);
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		
    		doc.appendChild(root);
    		
    		if(rs != null){
    			Element flagEl = doc.createElement("flag");
    			Element rsdtSeqNoEl = doc.createElement("rsdtSeqNo");
    			Element rlCdEl = doc.createElement("rlCd");
    			
    			flagEl.appendChild(doc.createTextNode(rs.getFlag()));
    			rsdtSeqNoEl.appendChild(doc.createTextNode(rs.getRsdtSeqNo()));
    			rlCdEl.appendChild(doc.createTextNode(rs.getRlCd()));
    			
	    		root.appendChild(flagEl);
	    		root.appendChild(rsdtSeqNoEl);
	    		root.appendChild(rlCdEl);
    		}
    		
    		
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }    

    /**
     * retrieving member mapped  with me <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchRlForMe.do")
    public void searchRlForMe(
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    		
    		List<RsdtInfrVO> rs = service.searchListRlForMe(vo);
    		
    		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
    		DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
    		Document doc = docBuilder.newDocument();
    		Element root = doc.createElement("root");
    		
    		doc.appendChild(root);
    		

    		String flagVal ="";    		
    		
    		if(rs != null && rs.size() > 0){
    			flagVal = "Y";
    		} else {
    			flagVal = "N";
    		}
    		
    		Element flag = doc.createElement("flag");        		
    		flag.appendChild(doc.createTextNode(flagVal));
    		root.appendChild(flag);
    		
    		Properties output = new Properties();
    	    output.setProperty(OutputKeys.INDENT, "yes");
    	    output.setProperty(OutputKeys.ENCODING, "UTF-8");
    	    TransformerFactory tf = TransformerFactory.newInstance();
    		Transformer t = tf.newTransformer();
    	    t.setOutputProperties(output);
    		StringWriter sw = new StringWriter();
    		StreamResult result = new StreamResult(sw);
    		DOMSource source = new DOMSource(doc);
    		t.transform(source, result);    		
    		response.setContentType("text/xml; charset=utf-8");
    		response.getWriter().write(sw.toString());
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    }   
    
    /**
     * retrieving member mapped  with me <br>
     *
     * @param vo Value-object of program to be parsed request(RsdtInfrVO)
     * @param model Object to be parsed http request(ModelMap)
     * @param response Value-object of program to be parsed request(HttpServletResponse)
     * @return Printed out JSP: ""
     * @exception Exception
     */
    @RequestMapping(value="/rm/rsdt/searchListRlForMe.do")
    public String searchListRlForMe(
    		@ModelAttribute("rsdtInfoVO") RsdtInfrVO vo,
    		ModelMap model,
    		HttpServletResponse response)
            throws Exception {
    	try{
    		LgnVO user = (LgnVO)NidUserDetailsHelper.getAuthenticatedUser();
    		vo.setUseLangCd(user.getUseLangCd());
    		model.addAttribute("useLangCd", user.getUseLangCd());
    		
    		RsdtInfrVO chngMber = service.searchChngMber(vo);
    		model.addAttribute("chngMber", chngMber);
    		
    		List<RsdtInfrVO> forMeList = service.searchListRlForMe(vo);
    		model.addAttribute("forMeList", forMeList);
    		
    	}catch (Exception e) {
    		log.error(e.getMessage(), e);
    		model.addAttribute("resultMsg", new NidEcptMsgHndlr().exceptionProcess(e, nidMessageSource));
    	}
    	
    	return "/rm/rsdt/p_RlMpErrMberList"; 
    } 
    
    
}